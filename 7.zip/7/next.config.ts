import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Next.js 16 — standalone output for the Docker deploy package
  output: "standalone",
  reactStrictMode: true,
  // Dev-only: allow HMR/dev resources when previewed via these hosts
  allowedDevOrigins: ["127.0.0.1", "localhost"],
  // Security headers per MASTER PROMPT §4 (nginx adds HSTS in production)
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Frame-Options", value: "DENY" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "X-DNS-Prefetch-Control", value: "on" },
        ],
      },
    ];
  },
};

export default nextConfig;
