#!/bin/bash
grep -rl 'جميع الحقوق محفوظة' /home/ahmedr/maydanerp/.next/static/chunks/ 2>/dev/null | head -2
echo '=== context ==='
grep -o '.\{0,20\}جميع الحقوق محفوظة.\{0,25\}' /home/ahmedr/maydanerp/.next/static/chunks/*.js 2>/dev/null | head -2