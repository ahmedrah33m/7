#!/bin/bash
PIDS=$(pgrep -f 'next start -p 3000')
if [ -n "$PIDS" ]; then kill $PIDS 2>/dev/null; fi
sleep 2
cd /home/ahmedr/maydanerp
nohup setsid npx next start -p 3000 >/home/ahmedr/maydanerp/app.log 2>&1 < /dev/null &
sleep 6
ss -tlnp 2>/dev/null | grep :3000
echo '---LOG---'
tail -6 /home/ahmedr/maydanerp/app.log
echo '---HEALTH---'
curl -s -o /dev/null -w 'HTTP %{http_code}\n' http://localhost:3000/api/v1/health