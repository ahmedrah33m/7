#!/bin/bash
echo "=== health ==="
curl -s http://127.0.0.1:3000/api/v1/health
echo ""
echo "=== support GET unauthenticated (expect 401) ==="
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:3000/api/v1/support
echo "=== login admin ==="
TOKEN=$(curl -s -X POST http://127.0.0.1:3000/api/v1/auth/login -H "Content-Type: application/json" -d '{"username":"admin","password":"Admin@123"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['access_token'])" 2>/dev/null)
echo "TOKEN_LEN=${#TOKEN}"
echo "=== support GET authed ==="
curl -s http://127.0.0.1:3000/api/v1/support -H "Authorization: Bearer $TOKEN" | head -c 400
echo ""
echo "=== support POST ==="
curl -s -X POST http://127.0.0.1:3000/api/v1/support -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" -d '{"subject":"تجربة","body":"رسالة تجريبية للتحقق من اتصال الدعم الفني"}'
echo ""
echo "=== support GET after post ==="
curl -s http://127.0.0.1:3000/api/v1/support -H "Authorization: Bearer $TOKEN" | head -c 400
echo ""