#!/usr/bin/env bash
# =============================================================
# install-kayan-service.sh — تثبيت نظام كايان كخدمة systemd دائمة
# (تلقائي الإقلاع + إعادة تشغيل تلقائية عند الانهيار أو إعادة التشغيل)
#
# الاستخدام:
#   cd ~/kayan          # مجلد النظام (يجب أن يكون البناء جاهزاً .next)
#   sudo bash deploy/install-kayan-service.sh
#
# المتطلبات: npm install && npm run build قبل التثبيت
# =============================================================
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NODE_BIN="$(command -v node)"
APP_USER="${SUDO_USER:-$(id -un)}"
KAYAN_PORT="${KAYAN_PORT:-3000}"
UNIT="/etc/systemd/system/kayan.service"

if [[ $EUID -ne 0 ]]; then
  echo "خطأ: شغّل السكربت بـ sudo (يحتاج كتابة وحدة systemd)"; exit 1
fi
if [[ ! -d "$APP_DIR/.next" ]]; then
  echo "خطأ: لا يوجد بناء إنتاج (.next) — نفّذ أولاً: npm run build"; exit 1
fi
if [[ ! -f "$APP_DIR/.env" ]]; then
  echo "خطأ: لا يوجد .env — تأكد من DATABASE_URL و JWT_ACCESS_SECRET"; exit 1
fi
if ! grep -q '^JWT_ACCESS_SECRET=' "$APP_DIR/.env"; then
  echo "==> إضافة أسرار JWT إلى .env (البوابة تشترطها في الإنتاج)"
  printf '\nJWT_ACCESS_SECRET=%s\nJWT_REFRESH_SECRET=%s\n' \
    "$(openssl rand -hex 32)" "$(openssl rand -hex 32)" >> "$APP_DIR/.env"
fi

echo "==> توليد الوحدة: $UNIT"
sed -e "s|__APP_USER__|$APP_USER|g" \
    -e "s|__APP_DIR__|$APP_DIR|g" \
    -e "s|__NODE_BIN__|$NODE_BIN|g" \
    "$APP_DIR/deploy/kayan.service" > "$UNIT"

# منفذ مخصص إن طُلب غير 3000
if [[ "$KAYAN_PORT" != "3000" ]]; then
  sed -i "s|^Environment=PORT=3000|Environment=PORT=$KAYAN_PORT|" "$UNIT"
fi

chown "$APP_USER:$APP_USER" "$APP_DIR/.env" 2>/dev/null || true

echo "==> daemon-reload + enable --now"
systemctl daemon-reload
systemctl enable --now kayan

sleep 3
echo "============================================================"
systemctl --no-pager -l status kayan | head -12 || true
echo "============================================================"
echo "تم — النظام يعمل الآن بشكل دائم على المنفذ $KAYAN_PORT"
echo "  السجلات الحية : journalctl -u kayan -f"
echo "  بعد أي بناء جديد: sudo systemctl restart kayan"
echo "  المتصفح        : http://localhost:$KAYAN_PORT  (admin / Admin@123)"
