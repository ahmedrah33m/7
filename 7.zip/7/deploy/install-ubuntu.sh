#!/usr/bin/env bash
# =============================================================
# SDS — مثبِّت تلقائي على Ubuntu 24.04 LTS
# شغّله من جذر المشروع بعد فك الضغط:
#   bash deploy/install-ubuntu.sh
# ينفّذ: فحص Node.js → npm ci → ضبط .env (مسار مطلق + سر JWT) →
#        prisma db push → build → تثبيت خدمة systemd وتشغيلها.
# =============================================================
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SERVICE_NAME="sds"
RUN_USER="sds"
PORT="3000"

say()  { echo -e "\n\033[1;36m==> $*\033[0m"; }
ok()   { echo -e "\033[1;32m✔ $*\033[0m"; }
die()  { echo -e "\033[1;31m✘ $*\033[0m"; exit 1; }

say "المجلد: $APP_DIR"
cd "$APP_DIR"

# ---------- 1) فحص Node.js ----------
command -v node >/dev/null 2>&1 || die "Node.js غير مثبّت — ثبّته أولاً (راجع DEPLOY-UBUNTU.md §3)"
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
[ "$NODE_MAJOR" -ge 20 ] || die "مطلوب Node.js 20+ والموجود: $(node -v)"
ok "Node.js $(node -v)"

# ---------- 2) الاعتماديات ----------
say "تثبيت الاعتماديات (npm ci)…"
npm ci --no-audit --no-fund || npm install --no-audit --no-fund
ok "الاعتماديات جاهزة"

# ---------- 3) ملف .env ----------
say "ضبط .env (مسار قاعدة بيانات مطلق + سر JWT)…"
if [ ! -f .env ]; then
  cat > .env <<EOF
DATABASE_URL=file:${APP_DIR}/db/custom.db
EOF
fi
# اجعل DATABASE_URL مطلقاً إن كان نسبياً
if grep -q '^DATABASE_URL=file:\.\.' .env 2>/dev/null || ! grep -q '^DATABASE_URL=' .env; then
  sed -i '/^DATABASE_URL=/d' .env
  echo "DATABASE_URL=file:${APP_DIR}/db/custom.db" >> .env
fi
# أضف سر JWT إن لم يوجد
if ! grep -q '^JWT_ACCESS_SECRET=' .env; then
  echo "JWT_ACCESS_SECRET=$(openssl rand -hex 32)" >> .env
  ok "تم توليد JWT_ACCESS_SECRET جديد"
fi
ok ".env جاهز: $(grep '^DATABASE_URL=' .env)"

# ---------- 4) قاعدة البيانات ----------
say "تحديث مخطط قاعدة البيانات (prisma db push)…"
npx prisma db push
# زرع البيانات الأساسية فقط عند قاعدة جديدة فارغة
if [ ! -s db/custom.db ]; then
  say "قاعدة جديدة — زرع البيانات الأساسية…"
  npx tsx prisma/seed.ts
fi
ok "قاعدة البيانات جاهزة"

# ---------- 5) البناء ----------
say "بناء نسخة الإنتاج (next build)…"
npm run build
ok "البناء نجح"

# ---------- 6) خدمة systemd (تحتاج sudo) ----------
say "تثبيت خدمة systemd…"
if ! id "$RUN_USER" >/dev/null 2>&1; then
  sudo useradd -r -s /usr/sbin/nologin "$RUN_USER"
fi
sudo chown -R "$RUN_USER":"$RUN_USER" "$APP_DIR"
mkdir -p "$APP_DIR/backups"
sudo chown "$RUN_USER":"$RUN_USER" "$APP_DIR/backups" 2>/dev/null || true

sed "s#/opt/sds#$APP_DIR#g" deploy/sds.service | sudo tee /etc/systemd/system/${SERVICE_NAME}.service >/dev/null
sudo systemctl daemon-reload
sudo systemctl enable --now "${SERVICE_NAME}" || sudo systemctl restart "${SERVICE_NAME}"
sleep 3
systemctl is-active --quiet "${SERVICE_NAME}" && ok "الخدمة تعمل (systemctl status ${SERVICE_NAME})" || die "الخدمة لا تعمل — راجع: journalctl -u ${SERVICE_NAME} -n 50"

say "اكتمل التثبيت 🎉"
echo "   التطبيق:  http://$(hostname -I 2>/dev/null | awk '{print $1}'):${PORT}"
echo "   الدخول:   admin / Admin@123  (غيّرها فوراً)"
echo "   سجلات:    journalctl -u ${SERVICE_NAME} -f"
echo "   Nginx:    راجع deploy/nginx-sds.conf (اختياري — راجع DEPLOY-UBUNTU.md §10)"
