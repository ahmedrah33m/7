#!/bin/bash
find /home/ahmedr/maydanerp/.next -name '*.css' 2>/dev/null | head -8
echo '---aurora in built css---'
grep -rl 'aurora' /home/ahmedr/maydanerp/.next 2>/dev/null | head -5
echo '---html css links---'
curl -s http://localhost:3000/ -o /tmp/h.html
grep -oE 'href="[^"]*css[^"]*"' /tmp/h.html | head
echo '---health---'
curl -s -o /dev/null -w 'HTTP %{http_code}\n' http://localhost:3000/api/v1/health