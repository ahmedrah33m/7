# دليل نشر نظام إدارة المبيعات والتوزيع على سيرفر Ubuntu 24.04.4 LTS

> هذه الحزمة هي النظام الكامل (الإصدار v4) وتشمل: كود المصدر، مخطط قاعدة البيانات،
> البيانات الأولية، قاعدة البيانات الحالية، سكربتات الاختبار، وملفات النشر الجاهزة في مجلد `deploy/`.
>
> **بيانات الدخول الافتراضية للمالك:** `admin` / `Admin@123` — ⚠️ غيّرها فوراً بعد أول دخول.

---

## 1) محتويات الحزمة

| المسار | الوصف |
|---|---|
| `src/` | كود التطبيق الكامل (Next.js 16 + API v1) |
| `prisma/` | مخطط قاعدة البيانات `schema.prisma` + البيانات الأولية `seed.ts` |
| `db/custom.db` | قاعدة بيانات SQLite جاهزة بكل بيانات النظام الحالية (شركات، مستخدمون، منتجات، فواتير…) |
| `deploy/` | ملفات جاهزة: خدمة systemd، إعداد Nginx، سكربت تثبيت تلقائي |
| `scripts/` | سكربتات التحقق والاختبار E2E |
| `docs/` | وثائق التدقيق |
| `DEPLOY-UBUNTU.md` | هذا الدليل |

النظام يستخدم **SQLite** (ملف واحد) — لا يحتاج تثبيت PostgreSQL أو MySQL على السيرفر،
وأي مسار آخر للملف يُضبط من متغير واحد في `.env`.

---

## 2) المتطلبات على السيرفر

- Ubuntu 24.04 LTS (أي حجم: يعمل على 1GB RAM، ويُنصح بـ 2GB).
- Node.js **20 LTS أو أحدث** (النظام مبني على Next.js 16).
- مساحة قراءة لا تقل عن 1GB.

## 3) تثبيت المتطلبات

```bash
sudo apt update
sudo apt install -y curl unzip ca-certificates openssl

# تثبيت Node.js 20 LTS (NodeSource)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

node -v    # يجب أن يظهر 20.x أو أحدث
npm -v
```

## 4) رفع الحزمة وفك الضغط

من جهازك (استبدل IP واسم المستخدم):

```bash
scp sales-distribution-system-full-v4-2026-09-16.zip user@SERVER_IP:/tmp/
```

على السيرفر:

```bash
sudo mkdir -p /opt/sds
sudo unzip -q /tmp/sales-distribution-system-full-v4-2026-09-16.zip -d /opt/sds
sudo chown -R $USER:$USER /opt/sds
cd /opt/sds
```

> يمكنك اختيار أي مجلد آخر بدل `/opt/sds` — فقط عدّل المسار في الخطوات التالية.

## 5) ضبط ملف `.env`

افتح `.env` الموجود في جذر المشروع وتأكد أن مسار قاعدة البيانات **مطلق** ويطابق مجلد النشر:

```env
DATABASE_URL=file:/opt/sds/db/custom.db

# أسرار التوكنات — مهمة للأمان (ولّدها مرة واحدة بهذا الأمر):
# openssl rand -hex 32
JWT_ACCESS_SECRET=<الصق هنا قيمة عشوائية بطول 64 حرف>
```

ولّد السر بأمان:

```bash
echo "JWT_ACCESS_SECRET=$(openssl rand -hex 32)" >> /opt/sds/.env
```

> ⚠️ ملف `.env` داخل الحزمة يستخدم مساراً نسبياً (`file:../db/custom.db`) صالحاً للتشغيل
> التجريبي من أي مجلد، لكن في الإنتاج استخدم المسار المطلق كما أعلاه حتى لا يتأثر النظام
> بتغيّر مجلد التشغيل (خاصة مع systemd و Nginx).

## 6) تثبيت الاعتماديات

```bash
cd /opt/sds
npm ci          # تثبيت نظيف مطابق للملف package-lock.json (أو: npm install)
```

سيُولَّد عميل Prisma تلقائياً مع التثبيت. إن أردت توليده يدوياً: `npx prisma generate`.

## 7) قاعدة البيانات — اختر أحد السيناريوهين

### (أ) الاستمرار ببيانات النظام الحالية (الأسهل — موصى به)
قاعدة `db/custom.db` مرفقة جاهزة بكل الشركات والمستخدمين والمنتجات والفواتير.
تأكد فقط أن المخطط محدّث (لا يغيّر شيئاً إن كان محدّثاً):

```bash
npx prisma db push
```

### (ب) البدء بقاعدة جديدة فارغة
```bash
rm -f db/custom.db
npx prisma db push          # إنشاء الجداول
npx tsx prisma/seed.ts      # زرع البيانات الأساسية (الأدوار، الصلاحيات، admin، شركة demo)
```
> `npx tsx prisma/seed.ts` هو بديل `npm run db:seed` بدون الحاجة لتثبيت Bun.

## 8) بناء نسخة الإنتاج

```bash
npm run build
```

يجب أن ينتهي بـ `Compiled successfully` مع تسجيل كل مسارات `/api/v1/...`.

## 9) التشغيل

### تشغيل تجريبي سريع (للتأكد أولاً)
```bash
npm start          # يعمل على المنفذ 3000
# من متصفح: http://SERVER_IP:3000
```
أوقفه بـ Ctrl+C ثم انتقل للتشغيل النظامي.

### التشغيل النظامي (systemd — يعمل تلقائياً بعد إعادة التشغيل)

```bash
# مستخدم نظام مخصص للخدمة
sudo useradd -r -s /usr/sbin/nologin sds || true
sudo chown -R sds:sds /opt/sds

# تثبيت وحدة الخدمة (الملف deploy/sds.service مضبوط على /opt/sds)
sudo cp deploy/sds.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now sds

sudo systemctl status sds --no-pager
```

أوامر مهمة:

```bash
sudo systemctl restart sds      # إعادة تشغيل
sudo systemctl stop sds         # إيقاف
journalctl -u sds -f            # متابعة السجلات مباشرة
```

## 10) Nginx كوكيل عكسي + HTTPS (اختياري لكن موصى به)

```bash
sudo apt install -y nginx
sudo cp deploy/nginx-sds.conf /etc/nginx/sites-available/sds
# إن كان لديك دومين: عدّل server_name داخل الملف
sudo ln -sf /etc/nginx/sites-available/sds /etc/nginx/sites-enabled/sds
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx
```

شهادة SSL مجانية (عند توفر دومين يشير للسيرفر):

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d YOUR_DOMAIN.COM
```

## 11) جدار الحماية

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
# إن كنت ستدخل مباشرة على منفذ التطبيق بدون Nginx فقط:
# sudo ufw allow 3000/tcp
sudo ufw enable
sudo ufw status
```

> مع Nginx لا تفتح المنفذ 3000 للخارج — تبقى الواجهة عبر 80/443 فقط.

## 12) خطوات ما بعد النشر (مهمة)

1. **غيّر كلمة مرور المالك** `admin` فوراً من واجهة النظام.
2. **JWT_ACCESS_SECRET**: تأكد أنه عشوائي (خطوة 5) — النظام يعمل بقيمة تطويرية افتراضية بدونه، لكن ذلك غير آمن للإنتاج. أعد تشغيل الخدمة بعد إضافته.
3. **نسخ احتياطي يومي** لقاعدة البيانات (ملف واحد):

```bash
sudo crontab -e
# أضف السطر التالي (نسخة يومية 3 صباحاً مع إيقاف لحظي للخدمة لضمان سلامة النسخة):
0 3 * * * systemctl stop sds; cp /opt/sds/db/custom.db /opt/sds/backups/custom-$(date +\%F).db; systemctl start sds
```

```bash
sudo mkdir -p /opt/sds/backups
```

## 13) التحديث بنسخة جديدة لاحقاً

```bash
sudo systemctl stop sds
cp /opt/sds/db/custom.db /opt/sds/backups/custom-before-upgrade.db   # احتياطي قبل التحديث
# فك الحزمة الجديدة فوق المجلد (دون الكتابة على db/ و .env)
cd /opt/sds && npm ci && npx prisma db push && npm run build
sudo systemctl start sds
```

## 14) حل المشاكل الشائعة

| المشكلة | الحل |
|---|---|
| `EADDRINUSE :3000` | منفذ مشغول: `sudo lsof -i :3000` ثم أوقف العملية، أو غيّر `PORT` في `deploy/sds.service` |
| الخطأ `P2021` / `P1003` (القاعدة غير موجودة) | مسار `DATABASE_URL` خاطئ في `.env` — يجب أن يكون مطلقاً ويشير لملف موجود |
| `JWT secret` فشل التحقق بعد إضافة السر | أعد تشغيل الخدمة `systemctl restart sds` (السر يُقرأ عند الإقلاع فقط) وسيضطر الجميع لإعادة الدخول |
| صفحة 502 من Nginx | الخدمة غير شغالة: `systemctl status sds`، وتأكد من `proxy_pass http://127.0.0.1:3000` |
| `prisma` يشتكي من OpenSSL | `sudo apt install -y openssl` |
| بطء أول بناء | طبيعي — `next build` يستغرق 1–3 دقائق حسب السيرفر |
| نسيت كلمة مرور admin | استعدها من القاعدة: شغّل `npx tsx prisma/seed.ts` (زرع شفاء idempotent يعيد كلمة admin الافتراضية إن حُذفت) أو أعد زرع قاعدة جديدة (سيناريو 7-ب) |

## 15) التحقق من صحة النشر

```bash
curl http://127.0.0.1:3000/api/v1/health
# المتوقع: {"success":true,"data":{"status":"ok",...,"database":"up","seeded":true,...}}
```

ثم افتح المتصفح وسجّل الدخول بـ `admin / Admin@123` (وغيّرها فوراً).

---

**الإصدار:** v4 — 2026-09-16 · يشمل آخر الإصلاحات: إدارة المستخدمين عبر كل الشركات للمالك،
رسائل 423 لانتهاء الاشتراك/التعليق في الواجهة، حالة كل شركة (مفتوحة/نشطة/ينتهي قريباً/منتهية/معلّقة)،
حذف فواتير الشراء بالعكس المحاسبي الكامل، حذف المنتجات والموردين والمستخدمين والمستودعات،
وإدارة اشتراكات الشركات وجلساتها.
