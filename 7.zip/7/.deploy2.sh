#!/bin/bash
cd /home/ahmedr/maydanerp
echo "Sparkles count: $(grep -c 'Sparkles' src/components/login-form.tsx)"
echo "auth-line count: $(grep -c 'مصادقة JWT' src/components/login-form.tsx)"
echo "midaniq count: $(grep -c 'midaniq' src/components/login-form.tsx)"
npx eslint src/components/login-form.tsx >/tmp/eslint.txt 2>&1
echo "LINT_EXIT=$?"
cat /tmp/eslint.txt
npm run build >/tmp/build.txt 2>&1
echo "BUILD_EXIT=$?"
tail -3 /tmp/build.txt