#!/bin/bash
echo '=== live page: check hidden phrases ==='
curl -s http://localhost:3000/ -o /tmp/live.html
grep -c 'argon2id' /tmp/live.html || echo 'argon2id not in page'
grep -c 'midaniq' /tmp/live.html || echo 'midaniq not in page'
grep -o 'مصادقة JWT' /tmp/live.html | head -1 || echo 'auth-line not in page'
echo '=== built SSR chunks (latest build) ==='
cd /home/ahmedr/maydanerp
grep -rl 'argon2id' .next/server/chunks/ssr/ 2>/dev/null | head -3
echo 'GREP_EXIT_DONE'
echo '=== health ==='
curl -s -o /dev/null -w 'HTTP %{http_code}\n' http://localhost:3000/api/v1/health