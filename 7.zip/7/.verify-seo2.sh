#!/bin/bash
echo "=== JSON-LD in home ==="
curl -s -H "Host: kayaniq.com" http://127.0.0.1:3000/ | grep -o 'application/ld+json' | head -1
echo "=== kayaniq.com external ==="
curl -s -o /dev/null -w 'KAYANIQ_HTTP=%{http_code}\n' --max-time 8 http://kayaniq.com/
echo "=== robots via domain ==="
curl -s -o /dev/null -w 'ROBOTS=%{http_code}\n' --max-time 8 http://kayaniq.com/robots.txt
echo "=== sitemap via domain ==="
curl -s -o /dev/null -w 'SITEMAP=%{http_code}\n' --max-time 8 http://kayaniq.com/sitemap.xml