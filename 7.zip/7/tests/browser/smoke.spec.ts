// =====================================================================
// RP3 §2 — Browser E2E (Playwright) — دخان الواجهة الحقيقية
// التدفق: صفحة الدخول → admin → (اختيار شركة إن ظهرت) → (اختيار فرع إن ظهر)
//         → لوحة المبيعات RTL («نظرة عامة»)
// (المصفوفة الكاملة: Order→Delivery→Invoice→Payment→Reports — بند متابعة موثق)
// =====================================================================
import { test, expect } from "@playwright/test";

const BASE = process.env.TEST_BASE_URL ?? "http://localhost:3000";

test("login page renders (RTL)", async ({ page }) => {
  await page.goto(BASE);
  await expect(page.getByLabel("اسم المستخدم")).toBeVisible({ timeout: 15000 });
});

test("admin login → company/branch pickers → sales dashboard", async ({ page }) => {
  await page.goto(BASE);
  await page.getByLabel("اسم المستخدم").fill("admin");
  await page.locator("input[type='password']").first().fill("Admin@123");
  await page.locator("button[type=submit]").click();

  // مُبدّل الشركات (admin متعدد الشركات) — اختر الأولى ثم «متابعة»
  const continueBtn = page.getByRole("button", { name: "متابعة" });
  try {
    await continueBtn.waitFor({ state: "visible", timeout: 8000 });
    await page.locator("button", { hasText: /اختبار|النخبة|شركة/ }).first().click();
    await continueBtn.click();
  } catch { /* مستخدم بشركة واحدة — لا شاشة اختيار */ }

  // مُبدّل الفروع — اختر أول فرع
  const branchPick = page.getByText("اختر الفرع");
  try {
    await branchPick.waitFor({ state: "visible", timeout: 8000 });
    await page.locator("button").filter({ hasText: /فرع|main|رئيسي|./ }).nth(0).click();
    await page.locator("button[type=submit], button", { hasText: /متابعة|دخول/ }).first().click();
  } catch { /* بلا شاشة فروع */ }

  // لوحة المبيعات
  await expect(page.getByText("نظرة عامة").first()).toBeVisible({ timeout: 25000 });
});
