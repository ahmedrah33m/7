// =====================================================================
// Phase 6 §3 — E2E: سيناريو الإنتاج الكامل (نطاق المرحلة 6 حرفياً)
//   Login → Company → Branch → Warehouse → Product → Customer →
//   Sales (أمر بيع مؤكد) → Delivery Note جزئي → تسليم → فاتورة (تحويل)
//   → Payment → Stock deduction → Customer balance
// كل خطوة تتحقق من أثرها الحقيقي في القاعدة.
// =====================================================================
import { describe, it, expect, beforeAll } from "vitest";
import { PrismaClient } from "@prisma/client";
import Decimal from "decimal.js";
import { adminToken, createTestCompany, setUsdRate, get, post, patch, makeProduct, makeCustomer, dec, type TestCompany } from "../integration/helpers";

Decimal.set({ precision: 40, rounding: Decimal.ROUND_HALF_UP, toExpNeg: -18, toExpPos: 48 });
const db = new PrismaClient();
let c: TestCompany;
let productId: number;
let customerId: number;
let orderId: number;
let dnId: number;
let invoiceId: number;
let cashboxId: number;
const ORDER_QTY = 100;
const FIRST_DELIVERY = 40;

beforeAll(async () => {
  c = await createTestCompany("E2E");
  await setUsdRate(c.auth, 1550);
  const p = await makeProduct(c.auth, "منتج السيناريو الكامل", { costPrice: 1000, salePrice: 1500 });
  productId = p.id;
  const cust = await makeCustomer(c.auth, "عميل السيناريو الكامل", 99999999);
  customerId = cust.id;
  const box = await db.cashbox.create({
    data: { companyId: c.companyId, branchId: c.branchId, code: "MAIN", name: "الصندوق", balance: new Decimal(0) },
  });
  cashboxId = box.id;
  await post("/inventory/movements", c.auth, {
    warehouse_id: c.warehouseId, product_id: productId, direction: "IN", qty: 300, unit_cost: 1000, note: "افتتاحي E2E",
  });
}, 120_000);

describe("§3 — السلسلة الكاملة من الدخول إلى رصيد العميل", () => {
  it("1) Login → جلسة صالحة", async () => {
    const token = await adminToken();
    expect(token).toBeTruthy();
  });

  it("2) Company selection → شركة الإختبار موصولة", async () => {
    const me = await get("/auth/me", c.auth);
    expect(me.ok).toBe(true);
    expect(Number(me.body.data?.user?.company_id ?? 0)).toBe(c.companyId);
  });

  it("3) Branch + Warehouse selection → الفرع والمستودع المخصصان", async () => {
    const wh = await db.warehouse.findUniqueOrThrow({ where: { id: c.warehouseId }, include: { branch: true } });
    expect(wh.branchId).toBe(c.branchId);
    expect(wh.companyId).toBe(c.companyId);
  });

  it("4) Product → منتج مرئي في نطاق الشركة", async () => {
    const res = await get("/products?per_page=200", c.auth);
    expect(res.ok).toBe(true);
    const p = (res.body.data ?? []).find((x: any) => x.id === productId);
    expect(p?.name).toContain("السيناريو");
  });

  it("5) Customer → عميل برصيد صفري", async () => {
    const res = await get("/customers?per_page=200", c.auth);
    expect(res.ok).toBe(true);
    const cust = (res.body.data ?? []).find((x: any) => x.id === customerId);
    expect(cust).toBeTruthy();
    expect(dec(cust?.balance ?? 0).toString()).toBe("0");
  });

  it("6) Sales → أمر بيع مؤكد 100 حبة", async () => {
    const o = await post("/sales/orders", c.auth, {
      customer_id: customerId, warehouse_id: c.warehouseId,
      lines: [{ product_id: productId, qty: ORDER_QTY }],
    });
    expect(o.ok).toBe(true);
    orderId = o.body.data.id;
    const conf = await post(`/sales/orders/${orderId}/confirm`, c.auth, {});
    expect(conf.ok).toBe(true);
    const stock = await db.stockBalance.findFirst({ where: { companyId: c.companyId, warehouseId: c.warehouseId, productId } });
    expect(Number(stock?.qty)).toBe(300); // الأوامر لا تلمس المخزون
  });

  it("7) Delivery Note جزئي: 40 من 100 → تسليم → PARTIAL", async () => {
    const detail = await get(`/sales/orders/${orderId}`, c.auth);
    const lineId = detail.body.data.lines[0].id;
    const dn = await post("/sales/delivery-notes", c.auth, {
      order_id: orderId, lines: [{ sales_order_line_id: lineId, qty: FIRST_DELIVERY }],
    });
    expect(dn.ok).toBe(true);
    dnId = dn.body.data.id;
    const delivered = await patch(`/sales/delivery-notes/${dnId}`, c.auth, { action: "deliver", received_by: "سائق E2E" });
    expect(delivered.ok).toBe(true);
    expect(delivered.body.data.status).toBe("PARTIAL");
    const prog = await get(`/sales/orders/${orderId}/delivery-progress`, c.auth);
    expect(prog.body.data.delivery_status).toBe("PARTIAL");
    expect(Number(prog.body.data.lines[0].remaining_qty)).toBe(ORDER_QTY - FIRST_DELIVERY);
  });

  it("8) Invoice → تحويل الإشعار المسلَّم لفاتورة (خصم المخزون الوحيد)", async () => {
    const stockBefore = await db.stockBalance.findFirst({ where: { companyId: c.companyId, warehouseId: c.warehouseId, productId } });
    const conv = await post(`/sales/delivery-notes/${dnId}/convert`, c.auth, { type: "CREDIT" });
    expect(conv.ok).toBe(true);
    invoiceId = conv.body.data.invoice_id;
    expect(Number(conv.body.data.grand_total)).toBe(FIRST_DELIVERY * 1500); // 40 × 1500
    const stockAfter = await db.stockBalance.findFirst({ where: { companyId: c.companyId, warehouseId: c.warehouseId, productId } });
    expect(Number(stockAfter?.qty)).toBe(Number(stockBefore?.qty) - FIRST_DELIVERY); // 300 → 260
    expect(Number(stockAfter?.qty)).toBe(260);
  });

  it("9) Payment → تحصيل جزئي 30000 على الصندوق", async () => {
    const pay = await post("/finance/transactions", c.auth, {
      kind: "collection", customer_id: customerId,
      cashbox_id: cashboxId, amount: 30000, invoice_id: invoiceId, note: "تحصيل E2E",
    });
    expect(pay.ok).toBe(true);
  });

  it("10) Stock deduction → الحركات تعكس خصم 40 بالضبط", async () => {
    const outs = await db.stockMovement.aggregate({
      where: { companyId: c.companyId, warehouseId: c.warehouseId, productId, direction: "OUT" },
      _sum: { qty: true },
    });
    expect(dec(outs._sum.qty ?? 0).toString()).toBe("40");
  });

  it("11) Customer balance → 60000 − 30000 = 30000 (فاتورة آجلة 40×1500 − التحصيل)", async () => {
    const res = await get("/customers?per_page=200", c.auth);
    expect(res.ok).toBe(true);
    const cust = (res.body.data ?? []).find((x: any) => x.id === customerId);
    expect(dec(cust?.balance ?? 0).toString()).toBe("30000");
  });

  it("12) إغلاق السلسلة: بقية الأمر (60) قابلة للتسليم لاحقاً", async () => {
    const prog = await get(`/sales/orders/${orderId}/delivery-progress`, c.auth);
    expect(Number(prog.body.data.lines[0].remaining_qty)).toBe(ORDER_QTY - FIRST_DELIVERY);
    const dn2 = await post("/sales/delivery-notes", c.auth, { order_id: orderId }); // كل المتبقي
    expect(dn2.ok).toBe(true);
    const lines = dn2.body.data.lines;
    expect(Number(lines[0].current_delivered_qty)).toBe(60);
    expect(Number(lines[0].previously_delivered_qty)).toBe(40);
  });
});
