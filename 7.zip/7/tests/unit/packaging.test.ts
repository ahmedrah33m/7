// =====================================================================
// Phase 6 §1 + §5 — Unit: التعبئة (packaging.ts) + انحدار التعبئة الإلزامي
// النطاق §5: 1 Carton = 11 Pieces · Carton = 26 USD
//            5 Cartons = 55 Pieces = 130 USD · 3 Pieces ≈ 7.090909 USD
// =====================================================================
import { describe, it, expect } from "vitest";
import { Decimal } from "@/lib/decimal";
import { packInfoOf, packSplit, fmtPackText, pluralOf, typeOfUnitLabel } from "@/lib/packaging";
import { derivePieceFromPackage } from "@/lib/product-pricing";

// نفس ضبط الدقة المعتمد في decimal.ts
const dec = (v: unknown) => new Decimal(String(v ?? 0));

describe("packaging — packInfoOf (§7)", () => {
  it("بلا تعبئة → hasPack=false و packQty=1", () => {
    const info = packInfoOf({ unit: "حبة", packUnit: null, packQty: null });
    expect(info.hasPack).toBe(false);
    expect(info.packQty).toBe(1);
    expect(info.packUnit).toBe("حبة");
  });

  it("packQty=1 يُعد بلا تعبئة (منع 1×1)", () => {
    const info = packInfoOf({ unit: "حبة", packUnit: "كرتونة", packQty: 1 });
    expect(info.hasPack).toBe(false);
  });

  it("كرتونة 11 → hasPack=true + CARTON", () => {
    const info = packInfoOf({ unit: "حبة", packUnit: "كرتونة", packQty: 11 });
    expect(info.hasPack).toBe(true);
    expect(info.packQty).toBe(11);
    expect(info.packageType).toBe("CARTON");
  });
});

describe("packaging — packSplit (§16)", () => {
  it("55 حبة @ 11 → 5 عبوات كاملة + 0 مفرد", () => {
    expect(packSplit(55, 11)).toEqual({ packages: 5, loose: 0 });
  });

  it("29 حبة @ 12 → 2 + 5 (مثال الوثيقة)", () => {
    expect(packSplit(29, 12)).toEqual({ packages: 2, loose: 5 });
  });

  it("25 حبة @ 11 → 2 + 3", () => {
    expect(packSplit(25, 11)).toEqual({ packages: 2, loose: 3 });
  });

  it("3 حبات @ 11 → 0 + 3 (لا عبوات كاملة)", () => {
    expect(packSplit(3, 11)).toEqual({ packages: 0, loose: 3 });
  });

  it("بلا تعبئة (packQty=1) → الكل loose", () => {
    expect(packSplit(7, 1)).toEqual({ packages: 0, loose: 7 });
  });
});

describe("packaging — تسميات (§45)", () => {
  it("fmtPackText يركّب نص العبوات", () => {
    const info = packInfoOf({ unit: "حبة", packUnit: "كرتونة", packQty: 11 });
    expect(fmtPackText(25, info)).toContain("2");
    expect(fmtPackText(25, info)).toContain("3");
  });

  it("pluralOf للوحدات العربية", () => {
    expect(pluralOf("كرتونة")).toBe("كراتين");
    expect(pluralOf("علبة")).toBe("علب");
    expect(pluralOf("حبة")).toBe("حبات");
  });

  it("typeOfUnitLabel يصنف الوحدات", () => {
    expect(typeOfUnitLabel("كرتونة")).toBe("CARTON");
    expect(typeOfUnitLabel("صندوق")).toBe("BOX");
    expect(typeOfUnitLabel("باكيت")).toBe("PACK");
    expect(typeOfUnitLabel("box")).toBe("BOX");
  });
});

// =====================================================================
// §5 — انحدار التعبئة الإلزامي (أرقام النطاق الحرفية)
// =====================================================================
describe("§5 packaging regression — الأرقام الإلزامية", () => {
  const PACK = 11;
  const CARTON_USD = "26";

  it("5 كراتين = 55 حبة بالضبط", () => {
    expect(dec(5).mul(PACK).toString()).toBe("55");
    expect(packSplit(55, PACK).packages).toBe(5);
  });

  it("5 كراتين = 130 USD بالضبط", () => {
    expect(dec(5).mul(dec(CARTON_USD)).toString()).toBe("130");
  });

  it("سعر الحبة المشتق = 26/11 = 2.363636 (§9 derivePieceFromPackage)", () => {
    expect(derivePieceFromPackage(26, 11)).toBe(2.363636);
  });

  it("3 حبات ≈ 7.090909 USD (بدقة 6dp من الحساب الدقيق)", () => {
    const piece = dec(CARTON_USD).div(PACK); // 2.36363636... بدقة كاملة
    const three = piece.mul(3); // 7.0909090909...
    expect(three.toDecimalPlaces(6, Decimal.ROUND_HALF_UP).toString()).toBe("7.090909");
  });

  it("الاتساق الدائري: الحبة×11 تعيد الكرتونة (بلا تقريب تراكمي)", () => {
    const piece = dec(CARTON_USD).div(PACK);
    expect(piece.mul(PACK).toString()).toBe("26");
  });

  it("derivePieceFromPackage يرفض المدخلات غير القابلة للاشتقاق", () => {
    expect(derivePieceFromPackage(26, null)).toBeNull();
    expect(derivePieceFromPackage(0, 11)).toBeNull();
    expect(derivePieceFromPackage(26, 1)).toBeNull();
  });
});
