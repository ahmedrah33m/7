// =====================================================================
// Phase 6 §1 — Unit: سياسة Decimal R1-R10 (src/lib/decimal.ts)
// العقد الحرج: isPositive(0) ≡ gt(0) — الترقيع الدلالي من المرحلة 3.
// =====================================================================
import { describe, it, expect } from "vitest";
import { Decimal, dec, moneyR, qtyR, rateR, pctR, sumOf, num, nOrNull } from "@/lib/decimal";

describe("decimal — dec() parsing", () => {
  it("يحلل الأرقام والنصوص و Decimal", () => {
    expect(dec(10).toNumber()).toBe(10);
    expect(dec("10.5").toNumber()).toBe(10.5);
    expect(dec(new Decimal("7.25")).toNumber()).toBe(7.25);
  });

  it("null/undefined/نص فارغ → 0", () => {
    expect(num(dec(null))).toBe(0);
    expect(num(dec(undefined))).toBe(0);
    expect(num(dec(""))).toBe(0);
  });

  it("لا انحراف float: 0.1 + 0.2 = 0.3 بالضبط", () => {
    // القاعدة R1 — أي حساب مالي عبر Decimal لا عبر float
    const a = dec("0.1").plus(dec("0.2"));
    expect(a.toString()).toBe("0.3");
    expect(a.eq(dec("0.3"))).toBe(true);
  });
});

describe("decimal — قواعد التقريب (R2-R4)", () => {
  it("moneyR: 4 منازل HALF_UP للمال", () => {
    expect(moneyR("1.00005").toString()).toBe("1.0001");
    expect(moneyR("33799.99999").toString()).toBe("33800");
    expect(moneyR("26").toString()).toBe("26");
  });

  it("qtyR: 6 منازل للكميات", () => {
    expect(qtyR("2.3636363").toString()).toBe("2.363636");
    expect(qtyR("55").toString()).toBe("55");
  });

  it("rateR: 6 منازل لأسعار الصرف", () => {
    expect(rateR("1300").toString()).toBe("1300");
    expect(rateR("1300.1234567").toString()).toBe("1300.123457");
  });

  it("pctR: 4 منازل للنسب", () => {
    expect(pctR("10").toString()).toBe("10");
    expect(pctR("99.99999").toString()).toBe("100"); // 4dp HALF_UP
  });
});

describe("decimal — تجميع وحدود الاستجابة (R10)", () => {
  it("sumOf يجمع بدقة بدون تراكم خطأ", () => {
    const rows = ["0.1", "0.2", "0.3"];
    expect(sumOf(rows).toString()).toBe("0.6");
    const items = [{ q: "2.5" }, { q: "7.5" }];
    expect(sumOf(items, (x) => x.q).toString()).toBe("10");
  });

  it("num يخرج number للواجهة و nOrNull يحفظ عقد null", () => {
    expect(num(dec("12.5"))).toBe(12.5);
    expect(nOrNull(null)).toBeNull();
    expect(nOrNull(undefined)).toBeNull();
    expect(nOrNull("3.25")).toBe(3.25);
  });
});

describe("decimal — العقد الدلالي isPositive (انحدار المرحلة 3)", () => {
  it("isPositive(0) = false — ≡ gt(0) وليس فحص الإشارة", () => {
    // مكمن خطأ تاريخي: decimal.js الأصلية تعيد true لـ 0 (تفحص الإشارة)
    // والترقيع في decimal.ts يعيد العقد الأصلي — يجب أن يبقى صامداً.
    const zero = new Decimal(0);
    expect(zero.isPositive()).toBe(false);
    expect(dec("0.0000001").isPositive()).toBe(true);
    expect(dec("-1").isPositive()).toBe(false);
  });

  it("isPositive إيجابية للمبالغ الحقيقية فقط", () => {
    expect(dec("0.01").isPositive()).toBe(true);
    expect(dec("26").isPositive()).toBe(true);
    expect(dec("-0.01").isPositive()).toBe(false);
  });
});
