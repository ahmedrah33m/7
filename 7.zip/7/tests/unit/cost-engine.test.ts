// =====================================================================
// Phase 6 §1 — Unit: محرك التكلفة (cost-engine.ts)
//   · normalizeCostMethod: التطبيع والرفض الصريح (لا تخمين)
//   · العقد الحسابي للأمثلة الإلزامية من وثيقة المرحلة 4 (§3):
//     طبقتا 100@1000 و 50@1200 وبيع 120 →
//       FIFO = 100×1000 + 20×1200 = 124000 بالضبط
//       WAVG = 120 × (160000/150) = 128000 بالضبط
//     (سلوك القاعدة الفعلي مغطى E2E في phase4-verify 53 فحصاً +
//      integration/migration؛ هنا نثبت العقد الرياضي الذي ينفذه المحرك)
// =====================================================================
import { describe, it, expect } from "vitest";
import { Decimal } from "@/lib/decimal";
import { normalizeCostMethod } from "@/lib/cost-engine";

const dec = (v: unknown) => new Decimal(String(v ?? 0));
const moneyR = (v: unknown) => dec(v).toDecimalPlaces(4, Decimal.ROUND_HALF_UP);

describe("cost-engine — normalizeCostMethod", () => {
  it("WAVG والمرادفات → WEIGHTED_AVERAGE", () => {
    expect(normalizeCostMethod("WAVG")).toBe("WEIGHTED_AVERAGE");
    expect(normalizeCostMethod("WEIGHTED_AVERAGE")).toBe("WEIGHTED_AVERAGE");
    expect(normalizeCostMethod("wavg")).toBe("WEIGHTED_AVERAGE");
    expect(normalizeCostMethod("AVG")).toBe("WEIGHTED_AVERAGE");
    expect(normalizeCostMethod("WEIGHTED AVG")).toBe("WEIGHTED_AVERAGE");
  });

  it("FIFO / STANDARD / LAST وتطبيعها", () => {
    expect(normalizeCostMethod("FIFO")).toBe("FIFO");
    expect(normalizeCostMethod("fifo")).toBe("FIFO");
    expect(normalizeCostMethod("STANDARD")).toBe("STANDARD_COST");
    expect(normalizeCostMethod("STANDARD_COST")).toBe("STANDARD_COST");
    expect(normalizeCostMethod("LAST")).toBe("LAST_COST");
    expect(normalizeCostMethod("LAST_COST")).toBe("LAST_COST");
  });

  it("غير المعروف أو الفارغ يُرفض صراحة (لا تخمين)", () => {
    expect(() => normalizeCostMethod("MAGIC")).toThrow();
    expect(() => normalizeCostMethod("")).toThrow();
    expect(() => normalizeCostMethod(null)).toThrow();
    expect(() => normalizeCostMethod(undefined)).toThrow();
  });
});

describe("cost-engine — العقد الحسابي لمثال الوثيقة (§3)", () => {
  const L1_QTY = "100", L1_COST = "1000";
  const L2_QTY = "50", L2_COST = "1200";
  const SALE = "120";

  it("FIFO: صرف من الأقدم أولاً → 100×1000 + 20×1200 = 124000 بالضبط", () => {
    let remaining = dec(SALE);
    let cogs = new Decimal(0);
    const layers = [
      { qty: dec(L1_QTY), cost: dec(L1_COST) },
      { qty: dec(L2_QTY), cost: dec(L2_COST) },
    ];
    for (const layer of layers) {
      if (remaining.lte(0)) break;
      const take = Decimal.min(remaining, layer.qty);
      cogs = cogs.plus(take.mul(layer.cost));
      remaining = remaining.minus(take);
    }
    expect(moneyR(cogs).toString()).toBe("124000");
    expect(remaining.toString()).toBe("0"); // 150 متاح − 120 مطلوب
  });

  it("WAVG: قيمة الطبقات ÷ كمياتها بدقة كاملة → 120 × (160000/150) = 128000 بالضبط", () => {
    const totalQty = dec(L1_QTY).plus(L2_QTY); // 150
    const totalValue = dec(L1_QTY).mul(L1_COST).plus(dec(L2_QTY).mul(L2_COST)); // 160000
    const wavg = totalValue.div(totalQty); // 1066.666666...
    const cogs = dec(SALE).mul(wavg);
    expect(moneyR(cogs).toString()).toBe("128000");
    // لا تقريب وسيط: المتوسط يبقى كسرية دقيقة (toFixed يثبت 10 منازل)
    expect(wavg.mul(3).toFixed(10)).toBe("3200.0000000000");
  });

  it("STANDARD_COST: الكمية × التكلفة المعيارية من المنتج", () => {
    const std = dec("1100");
    expect(moneyR(dec("30").mul(std)).toString()).toBe("33000");
  });

  it("LAST_COST: الكمية × آخر تكلفة شراء", () => {
    const last = dec("1200");
    expect(moneyR(dec("20").mul(last)).toString()).toBe("24000");
  });

  it("متبقي الطبقات بعد الصرف = الرصيد (الثابت الذهبي)", () => {
    // 150 − 120 = 30 متبقية على الطبقة الثانية
    const layer2Remaining = dec(L2_QTY).minus(dec(SALE).minus(dec(L1_QTY)));
    expect(layer2Remaining.toString()).toBe("30");
  });
});
