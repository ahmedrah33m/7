// =====================================================================
// Phase 6 §1 — Unit: العملة المزدوجة (currency.ts) — IQD أساس + USD عرض
// القاعدة §7: IQD = moneyR(USD × rate) · USD للعرض = amount ÷ rate
// =====================================================================
import { describe, it, expect } from "vitest";
import { isCurrency, asCurrency, assertExchangeRate, rateOf, toIqd, fromIqd, round6, roundMoney, moneyOf, displayUsd } from "@/lib/currency";

describe("currency — كشف العملة", () => {
  it("isCurrency يقبل IQD/USD فقط", () => {
    expect(isCurrency("IQD")).toBe(true);
    expect(isCurrency("USD")).toBe(true);
    expect(isCurrency("EUR")).toBe(false);
    expect(isCurrency("")).toBe(false);
    expect(isCurrency(null)).toBe(false);
  });

  it("asCurrency يرجع fallback للقيم الغريبة", () => {
    expect(asCurrency("USD")).toBe("USD");
    expect(asCurrency("garbage", "IQD")).toBe("IQD");
    expect(asCurrency(undefined)).toBe("IQD");
  });
});

describe("currency — سعر الصرف (بلا تخمين §7)", () => {
  it("assertExchangeRate يقبل الموجب ويرجعه 6dp", () => {
    expect(assertExchangeRate(1300)).toBe(1300);
    expect(assertExchangeRate("1550.123456")).toBe(1550.123456);
  });

  it("assertExchangeRate يرفض الصفر والسالب وغير الأرقام", () => {
    expect(() => assertExchangeRate(0)).toThrow();
    expect(() => assertExchangeRate(-1300)).toThrow();
    expect(() => assertExchangeRate("abc")).toThrow();
    expect(() => assertExchangeRate(null)).toThrow();
    expect(() => assertExchangeRate(Infinity)).toThrow();
  });

  it("rateOf يعيد Decimal 6dp صالح", () => {
    expect(rateOf(1300).toString()).toBe("1300");
  });
});

describe("currency — التحويل USD↔IQD (R5)", () => {
  it("toIqd: 26 USD × 1300 = 33800 IQD بالضبط", () => {
    expect(toIqd(26, "USD", 1300).toString()).toBe("33800");
  });

  it("toIqd: IQD يمر بتقريب المال فقط", () => {
    expect(toIqd("33800.00005", "IQD", 1300).toString()).toBe("33800.0001");
  });

  it("fromIqd: 33800 IQD ÷ 1300 = 26 USD بالضبط", () => {
    expect(fromIqd(33800, "USD", 1300).toString()).toBe("26");
  });

  it("fromIqd: قسمة غير كاملة تحتفظ بدقة Decimal (بلا float)", () => {
    // 10000/1300 = 7.692307692... — لا نحصل على إشارات float
    const v = fromIqd(10000, "USD", 1300);
    expect(v.toDecimalPlaces(6).toString()).toBe("7.692308");
  });

  it("displayUsd للعرض بست منازل", () => {
    expect(displayUsd(33800, 1300).toString()).toBe("26");
  });
});

describe("currency — دوال التقريب العرضية", () => {
  it("round6 و roundMoney", () => {
    expect(round6("2.3636363")).toBe(2.363636);
    // roundMoney = moneyR (4dp HALF_UP) ثم number
    expect(roundMoney("26.126")).toBe(26.126);
    expect(roundMoney("26.123456")).toBe(26.1235);
  });

  it("moneyOf يرجع Decimal 4dp", () => {
    expect(moneyOf("7.09090909").toString()).toBe("7.0909");
  });
});
