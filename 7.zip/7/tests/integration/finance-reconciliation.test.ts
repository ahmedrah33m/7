// =====================================================================
// Phase 6 §7 — Integration: المطابقة المالية (Financial Reconciliation)
// تقاطع: الفاتورة ↔ الدفعات ↔ رصيد العميل ↔ الصندوق ↔ COGS ↔ الربح
// ↔ تقييم المخزون (كلها تُقرأ من القاعدة ويُطابق بعضها بعضاً بالضبط)
// =====================================================================
import { describe, it, expect, beforeAll } from "vitest";
import { PrismaClient } from "@prisma/client";
import Decimal from "decimal.js";
import { createTestCompany, setUsdRate, post, makeProduct, makeCustomer, dec, type TestCompany } from "./helpers";

Decimal.set({ precision: 40, rounding: Decimal.ROUND_HALF_UP, toExpNeg: -18, toExpPos: 48 });
const db = new PrismaClient();
let c: TestCompany;
let productId: number;
let customerId: number;
let cashboxId: number;

beforeAll(async () => {
  c = await createTestCompany("FIN");
  await setUsdRate(c.auth, 1550);
  const p = await makeProduct(c.auth, "منتج المطابقة", { costPrice: 1000, salePrice: 1600 });
  productId = p.id;
  const cust = await makeCustomer(c.auth, "عميل المطابقة", 99999999);
  customerId = cust.id;
  const box = await db.cashbox.create({
    data: { companyId: c.companyId, branchId: c.branchId, code: "MAIN", name: "الصندوق", balance: new Decimal(0) },
  });
  cashboxId = box.id;
  // مخزون افتتاحي 100 @ 1000
  await post("/inventory/movements", c.auth, {
    warehouse_id: c.warehouseId, product_id: productId, direction: "IN", qty: 100, unit_cost: 1000, note: "افتتاحي",
  });
}, 120_000);

describe("§7 — المطابقة عبر فاتورتين وتحصيل", () => {
  let cashInvoiceId: number;
  let creditInvoiceId: number;

  it("الترتيب: فاتورة نقدية مدفوعة كاملة + فاتورة آجلة بتحصيل جزئي", async () => {
    const inv1 = await post("/sales/invoices", c.auth, {
      customer_id: customerId, warehouse_id: c.warehouseId, type: "CASH",
      lines: [{ product_id: productId, qty: 10 }], // 16000 مدفوعة كاملة
    });
    expect(inv1.ok).toBe(true);
    cashInvoiceId = inv1.body.data.id;

    const inv2 = await post("/sales/invoices", c.auth, {
      customer_id: customerId, warehouse_id: c.warehouseId, type: "CREDIT",
      lines: [{ product_id: productId, qty: 20 }], // 32000 آجلة
    });
    expect(inv2.ok).toBe(true);
    creditInvoiceId = inv2.body.data.id;

    const pay = await post("/finance/transactions", c.auth, {
      kind: "collection", customer_id: customerId,
      cashbox_id: cashboxId, amount: 12000, invoice_id: creditInvoiceId, note: "تحصيل جزئي",
    });
    expect(pay.ok).toBe(true);
  });

  it("م1: المدفوع على كل فاتورة = حركات الصندوق المرتبطة بها", async () => {
    for (const invId of [cashInvoiceId, creditInvoiceId]) {
      const inv = await db.salesInvoice.findUniqueOrThrow({ where: { id: invId } });
      const txs = await db.cashTransaction.findMany({
        where: { companyId: c.companyId, refType: { in: ["SALES_INVOICE", "SALES_INVOICE_CASH"] }, refId: invId, direction: "IN" },
      });
      const paid = txs.reduce((a, t) => a.plus(dec(t.amount)), new Decimal(0));
      expect(paid.toString()).toBe(dec(inv.paidAmount).toString());
    }
  });

  it("م2: رصيد العميل = Σ (الإجمالي − المدفوع) لفواتيره غير الملغاة", async () => {
    const cust = await db.customer.findUniqueOrThrow({ where: { id: customerId } });
    const invs = await db.salesInvoice.findMany({
      where: { companyId: c.companyId, customerId, status: { not: "VOID" }, deletedAt: null },
    });
    const unpaid = invs.reduce((a, i) => a.plus(dec(i.grandTotal).minus(dec(i.paidAmount))), new Decimal(0));
    expect(dec(cust.balance).toString()).toBe(unpaid.toString());
  });

  it("م3: رصيد الصندوق = آخر balanceAfter = Σ (IN − OUT)", async () => {
    const box = await db.cashbox.findUniqueOrThrow({ where: { id: cashboxId } });
    const txs = await db.cashTransaction.findMany({ where: { cashboxId }, orderBy: { id: "asc" } });
    const sum = txs.reduce((a, t) => a.plus(t.direction === "IN" ? dec(t.amount) : dec(t.amount).negated()), new Decimal(0));
    const lastAfter = txs.length ? dec(txs[txs.length - 1].balanceAfter) : new Decimal(0);
    expect(dec(box.balance).toString()).toBe(sum.toString());
    expect(lastAfter.toString()).toBe(sum.toString());
  });

  it("م4: COGS للفاتورة = Σ تكاليف بنودها (لقطة المرحلة 4)", async () => {
    for (const invId of [cashInvoiceId, creditInvoiceId]) {
      const inv = await db.salesInvoice.findUniqueOrThrow({
        where: { id: invId }, include: { lines: true },
      });
      const sum = inv.lines.reduce((a, l) => a.plus(dec(l.cogsTotal ?? 0)), new Decimal(0));
      expect(dec(inv.cogsTotal ?? 0).toString()).toBe(sum.toString());
      // تكلفة الوحدة = 1000 (طبقة الافتتاحي) — 10 و 20 حبة
      expect(sum.toString()).toBe(dec(inv.lines.reduce((a, l) => a.plus(Number(l.qty)), new Decimal(0))).mul(1000).toString());
    }
  });

  it("م5: الربح الإجمالي = Σ (الإيراد − COGS) عبر الفواتير المرحّلة", async () => {
    const invs = await db.salesInvoice.findMany({
      where: { companyId: c.companyId, status: "POSTED", deletedAt: null },
    });
    const revenue = invs.reduce((a, i) => a.plus(dec(i.grandTotal)), new Decimal(0));
    const cogs = invs.reduce((a, i) => a.plus(dec(i.cogsTotal ?? 0)), new Decimal(0));
    const grossProfit = revenue.minus(cogs);
    // 30 حبة × (1600 − 1000) = 18000
    expect(grossProfit.toString()).toBe("18000");
  });

  it("م6: تقييم المخزون = Σ متبقي الطبقات × تكلفتها = Σ أرصدة المخزون", async () => {
    const layers = await db.costLayer.findMany({ where: { companyId: c.companyId, status: "ACTIVE" } });
    const valuation = layers.reduce((a, l) => a.plus(dec(l.remainingQuantity).mul(dec(l.unitCost))), new Decimal(0));
    const balances = await db.stockBalance.findMany({ where: { companyId: c.companyId } });
    const totalQty = balances.reduce((a, b) => a.plus(dec(b.qty)), new Decimal(0));
    // 100 − 30 = 70 حبة @ 1000 = 70000
    expect(valuation.toString()).toBe("70000");
    expect(totalQty.toString()).toBe("70");
  });
});
