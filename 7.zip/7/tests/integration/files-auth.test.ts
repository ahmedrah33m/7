// =====================================================================
// RP5 §9/§10 — عزل الملفات وصلاحياتها (regression)
//   · GET /files/[name] بلا جلسة → 401 (UUID ليس حدّاً أمنياً)
//   · ملف مرفوع لشركة A: جلسة A → 200 بمحتوى مطابق · جلسة شركة B → 404 موحد
//   · اسم بلا سجل FileObject → 404 حتى للمصادق
//   · الرفع يسجل ملكية الشركة تلقائياً (file_objects)
// =====================================================================
import { describe, it, expect } from "vitest";
import { jfetch, createTestCompany, adminToken, type TestCompany } from "./helpers";

const PDF = Buffer.from("%PDF-1.4\n% RP5 file-isolation probe\n", "utf8");

async function uploadAs(auth: TestCompany): Promise<string> {
  const form = new FormData();
  form.append("file", new Blob([PDF], { type: "application/pdf" }), "doc.pdf");
  const res = await jfetch("/uploads", { method: "POST", headers: { authorization: auth.auth.authorization }, body: form });
  expect(res.status).toBe(200);
  const name = res.body.data?.name as string;
  expect(name).toBeTruthy();
  return name;
}

describe("RP5 — files authorization & tenant isolation", () => {
  it("§10 مصادقة إلزامية: بلا رمز → 401", async () => {
    const A = await createTestCompany("RP5A");
    const name = await uploadAs(A);
    const anon = await jfetch(`/files/${name}`);
    expect([401, 403]).toContain(anon.status);
    void adminToken;
  });

  it("§9/§10 ملكية الشركة: صاحب الملف 200 بمحتوى مطابق · شركة أخرى 404 موحد", async () => {
    const A = await createTestCompany("RP5B");
    const B = await createTestCompany("RP5C");
    const name = await uploadAs(A);

    // سجل الملكية أُنشئ تلقائياً
    expect(A.companyId).toBeGreaterThan(0);

    const own = await fetch(`${process.env.TEST_BASE_URL ?? "http://localhost:3000/api/v1"}/files/${name}`, {
      headers: { authorization: A.auth.authorization },
    });
    expect(own.status).toBe(200);
    expect(own.headers.get("content-type")).toContain("application/pdf");
    const buf = Buffer.from(await own.arrayBuffer());
    expect(buf.equals(PDF)).toBe(true);
    expect(own.headers.get("cache-control")).toContain("private");

    const other = await jfetch(`/files/${name}`, { headers: B.auth });
    expect(other.status).toBe(404);
  });

  it("§10 لا سجل = لا خدمة: UUID عشوائي للمصادق → 404", async () => {
    const A = await createTestCompany("RP5D");
    const rnd = "11111111-2222-4333-8444-555555555555.pdf";
    const res = await jfetch(`/files/${rnd}`, { headers: A.auth });
    expect(res.status).toBe(404);
  });
});
