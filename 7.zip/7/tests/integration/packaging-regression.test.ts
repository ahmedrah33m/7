// =====================================================================
// Phase 6 §5 — Integration: انحدار التعبئة الإلزامي عبر API الحية
// 1 Carton = 11 Pieces · Carton = 26 USD (rate 1300)
//   5 Cartons = 55 Pieces = 130 USD  = 169000 IQD
//   3 Pieces  ≈ 7.090909 USD          ≈ 9218.1818 IQD
// الأسعار تُخزَّن بعملتها كما دخلت — الإسقاط IQD 4dp — USD للعرض 6dp.
// =====================================================================
import { describe, it, expect, beforeAll } from "vitest";
import Decimal from "decimal.js";
import { PrismaClient } from "@prisma/client";
import { createTestCompany, setUsdRate, get, post, makeProduct, makeCustomer, dec, type TestCompany } from "./helpers";

const prisma = new PrismaClient();

let c: TestCompany;
let productId: number;
let customerId: number;
const RATE = 1300;

beforeAll(async () => {
  c = await createTestCompany("PKG");
  await setUsdRate(c.auth, RATE);
  // كرتونة 11 حبة بسعر 26 USD + تكلفة 25 USD — سعر الحبة يدخل بدقة كاملة
  // (26/11) حتى يكون الإسقاط 3072.7273 والبند 3 حبات = 7.090909 USD حرفياً
  const p = await makeProduct(c.auth, "شامبو الانحدار", {
    unit: "حبة", packUnit: "كرتونة", packQty: 11,
    costPrice: 25, salePrice: 2.3636363636, packSalePrice: 26, currency: "USD", rate: RATE,
  });
  productId = p.id;
  const cust = await makeCustomer(c.auth, "عميل الانحدار");
  customerId = cust.id;
  // مخزون 58 حبة (5 كراتين + 3 حبات للفحص الثاني)
  const intake = await post("/inventory/movements", c.auth, {
    warehouse_id: c.warehouseId, product_id: productId, direction: "IN", qty: 58, unit_cost: 32500, note: "5 كراتين + 3",
  });
  if (!intake.ok) throw new Error(`intake failed: ${JSON.stringify(intake.body).slice(0, 200)}`);
}, 120_000);

describe("§5 — الأسعار المهيكلة كما دخلت (لا تحويل عند الحفظ)", () => {
  it("الأسعار المهيكلة كما دخلت: SALE/PACKAGE/USD 26 · SALE/PIECE/USD 26/11 · COST/USD 25", async () => {
    // العقد §6: الصفوف المهيكلة تحفظ بعملتها كما دخلت — لا تحويل عند الحفظ
    const rows = await prisma.productPrice.findMany({
      where: { productId, isActive: true },
      select: { priceType: true, unit: true, currency: true, amount: true },
    });
    const find = (t: string, u: string) => rows.find((r) => r.priceType === t && r.unit === u);
    const salePack = find("SALE", "PACKAGE");
    const salePiece = find("SALE", "PIECE");
    const cost = find("COST", "PIECE");
    expect(salePack?.currency).toBe("USD");
    expect(Number(salePack?.amount)).toBe(26); // كما دخلت — لا تحويل
    expect(salePiece?.currency).toBe("USD");
    expect(Math.abs(Number(salePiece?.amount) - 26 / 11)).toBeLessThan(1e-9);
    expect(cost?.currency).toBe("USD");
    expect(Number(cost?.amount)).toBe(25);
  });
});

describe("§5 — 5 كراتين = 55 حبة = 130 USD", () => {
  it("فاتورة 5 عبوات كاملة → 169000 IQD = 130 USD بالضبط", async () => {
    const inv = await post("/sales/invoices", c.auth, {
      customer_id: customerId, warehouse_id: c.warehouseId, type: "CASH",
      lines: [{ product_id: productId, package_qty: 5, loose_qty: 0 }],
    });
    expect(inv.ok).toBe(true);
    const invId = inv.body.data.id;
    const detail = await get(`/sales/invoices/${invId}`, c.auth);
    expect(detail.ok).toBe(true);
    const line = detail.body.data.lines[0];
    // 5 × 33800 = 169000 IQD
    expect(dec(line.line_total).toString()).toBe("169000");
    expect(Number(line.qty)).toBe(55);
    // بالدولار: 169000 / 1300 = 130
    expect(dec(line.line_total).div(RATE).toString()).toBe("130");
  });
});

describe("§5 — 3 حبات ≈ 7.090909 USD", () => {
  it("فاتورة 3 حبات → ≈ 9218.1818 IQD ≈ 7.090909 USD (±دقة 4dp)", async () => {
    const inv = await post("/sales/invoices", c.auth, {
      customer_id: customerId, warehouse_id: c.warehouseId, type: "CASH",
      lines: [{ product_id: productId, qty: 3 }],
    });
    expect(inv.ok).toBe(true);
    const detail = await get(`/sales/invoices/${inv.body.data.id}`, c.auth);
    const line = detail.body.data.lines[0];
    // القيمة الدقيقة: 3 × 33800/11 = 9218.181818... — الإسقاط IQD 4dp
    const iqd = dec(line.line_total);
    const exact = dec(33800).div(11).mul(3);
    expect(Number(iqd.minus(exact).abs().toString())).toBeLessThan(0.01);
    // بالدولار 6dp = 7.090909 (قيمة النطاق الحرفية — ±دقة القسمة)
    const usd = iqd.div(RATE).toDecimalPlaces(6, Decimal.ROUND_HALF_UP);
    expect(Math.abs(Number(usd.toString()) - 7.090909)).toBeLessThanOrEqual(0.000002);
  });
});
