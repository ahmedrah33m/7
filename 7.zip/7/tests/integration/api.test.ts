// =====================================================================
// Phase 6 §2 — Integration: APIs الأساسية (مصادقة · منتجات · إعدادات · عملاء)
// =====================================================================
import { describe, it, expect, beforeAll } from "vitest";
import { adminToken, get, post, put, createTestCompany, setUsdRate, type TestCompany } from "./helpers";

let company: TestCompany;

beforeAll(async () => {
  company = await createTestCompany("API");
  await setUsdRate(company.auth, 1550);
}, 90_000);

describe("§2 — المصادقة والبوابات", () => {
  it("health يفتح بدون مصادقة", async () => {
    const res = await get("/health", {});
    expect(res.ok).toBe(true);
  });

  it("دخول خاطئ → 401/400 بدون رمز", async () => {
    const res = await post("/auth/login", {}, { username: "admin", password: "wrong-pass" });
    expect(res.ok).toBe(false);
    expect([400, 401, 422]).toContain(res.status);
  });

  it("دخول صحيح → access_token", async () => {
    const token = await adminToken();
    expect(token).toBeTruthy();
  });

  it("API محمي بدون رمز → 401", async () => {
    const res = await get("/products", {});
    expect(res.ok).toBe(false);
    expect(res.status).toBe(401);
  });

  it("API محمي برمز فاسد → 401", async () => {
    const res = await get("/products", { authorization: "Bearer garbage.token.here" });
    expect(res.status).toBe(401);
  });
});

describe("§2 — المنتجات والعملاء والإعدادات", () => {
  it("GET /products → عقد {success,data} بقائمة", async () => {
    const res = await get("/products?per_page=5", company.auth);
    expect(res.ok).toBe(true);
    expect(res.body.success).toBe(true);
    expect(Array.isArray(res.body.data)).toBe(true);
  });

  it("GET /customers → قائمة", async () => {
    const res = await get("/customers?per_page=5", company.auth);
    expect(res.ok).toBe(true);
    expect(Array.isArray(res.body.data)).toBe(true);
  });

  it("PUT /settings/usd-rate → 1550 يُقرأ كما حُفظ (بلا تخمين)", async () => {
    const res = await get("/settings/usd-rate", company.auth);
    expect(res.ok).toBe(true);
    expect(Number(res.body.data?.rate)).toBe(1550);
  });

  it("PUT /settings/usd-rate بقيمة غير صالحة → 422/400 (PRD_006)", async () => {
    const res = await put("/settings/usd-rate", company.auth, { rate: -5 });
    expect(res.ok).toBe(false);
    expect([400, 422]).toContain(res.status);
  });

  it("إعدادات طريقة التكلفة: GET الافتراضي WEIGHTED_AVERAGE (تطبيع WAVG)", async () => {
    const res = await get("/settings/costing-method", company.auth);
    expect(res.ok).toBe(true);
    expect(res.body.data?.costing_method).toBe("WEIGHTED_AVERAGE");
  });

  it("إعدادات طريقة التكلفة: PUT غير معروف → رفض صريح", async () => {
    const res = await put("/settings/costing-method", company.auth, { costing_method: "MAGIC" });
    expect(res.ok).toBe(false);
    expect([400, 422]).toContain(res.status);
  });
});
