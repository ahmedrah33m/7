// =====================================================================
// Phase 6 — أدوات مشتركة لاختبارات التكامل (ضد الخادم الحي :3000)
// نمط معتمد: شركة معزولة لكل ملف اختبار + رمز admin مُخزَّن مؤقتاً.
// =====================================================================
import Decimal from "decimal.js";

Decimal.set({ precision: 40, rounding: Decimal.ROUND_HALF_UP, toExpNeg: -18, toExpPos: 48 });

export const BASE = process.env.TEST_BASE_URL ?? "http://localhost:3000/api/v1";

export const dec = (v: unknown) => new Decimal(String(v ?? 0));
export const qtyR = (v: unknown) => dec(v).toDecimalPlaces(6, Decimal.ROUND_HALF_UP);
export const eq = (a: unknown, b: unknown) => dec(a).toString() === dec(b).toString();

export interface JRes {
  ok: boolean;
  status: number;
  body: { success?: boolean; data?: any; message?: string; code?: string; meta?: any; [k: string]: any };
}

export async function jfetch(path: string, init?: RequestInit, retries = 4): Promise<JRes> {
  for (let attempt = 0; ; attempt++) {
    const res = await fetch(`${BASE}${path}`, init);
    const body = await res.json().catch(() => ({}));
    // حد المعدل (RATE_001) — انتظار ذكي حسب ثواني الخادم ثم إعادة المحاولة
    if (body?.code === "RATE_001" && attempt < retries) {
      const m = String(body.message ?? "").match(/(\d+)/);
      const wait = Math.min(30, (m ? Number(m[1]) : 10) + 1);
      await new Promise((r) => setTimeout(r, wait * 1000));
      continue;
    }
    return { ok: res.ok, status: res.status, body };
  }
}

export const post = (path: string, auth: Record<string, string>, data: unknown) =>
  jfetch(path, { method: "POST", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(data) });
export const put = (path: string, auth: Record<string, string>, data: unknown) =>
  jfetch(path, { method: "PUT", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(data) });
export const patch = (path: string, auth: Record<string, string>, data: unknown) =>
  jfetch(path, { method: "PATCH", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(data) });
export const get = (path: string, auth: Record<string, string>) => jfetch(path, { headers: auth });

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

let cachedAdminToken: string | null = null;

/** دخول admin مرة واحدة لكل worker */
export async function adminToken(): Promise<string> {
  if (cachedAdminToken) return cachedAdminToken;
  const res = await post("/auth/login", {}, { username: "admin", password: "Admin@123" });
  const token = res.body.data?.access_token;
  if (!token) throw new Error(`login failed: ${JSON.stringify(res.body).slice(0, 200)}`);
  cachedAdminToken = token;
  return token;
}

export interface TestCompany {
  companyId: number;
  warehouseId: number;
  branchId: number;
  auth: Record<string, string>;
}

/** شركة معزولة كاملة التجهيز (شركة + فرع + مستودع + صندوق) + جلسة موصولة */
export async function createTestCompany(prefix: string): Promise<TestCompany> {
  const token = await adminToken();
  const sfx = Date.now().toString().slice(-6) + Math.floor(Math.random() * 900 + 100);
  const comp = await post("/admin/companies", { authorization: `Bearer ${token}` }, {
    code: `${prefix}${sfx}`, name: `شركة اختبار ${prefix} ${sfx}`,
  });
  if (comp.status !== 201 || !comp.body.data?.companyId) {
    throw new Error(`company provisioning failed: ${JSON.stringify(comp.body).slice(0, 200)}`);
  }
  const { companyId, warehouseId, branchId } = comp.body.data;
  const sw = await post("/auth/switch-company", { authorization: `Bearer ${token}` }, { company_id: companyId });
  const session = sw.body.data?.access_token;
  if (!session) throw new Error(`switch-company failed: ${JSON.stringify(sw.body).slice(0, 200)}`);
  return { companyId, warehouseId, branchId, auth: { authorization: `Bearer ${session}` } };
}

export async function setUsdRate(auth: Record<string, string>, rate: number) {
  await put("/settings/usd-rate", auth, { rate });
}

/** إنشاء عميل */
export async function makeCustomer(auth: Record<string, string>, name: string, creditLimit = 99999999) {
  const res = await post("/customers", auth, { name, phone: "07700000000", credit_limit: creditLimit });
  if (!res.ok) throw new Error(`customer failed: ${JSON.stringify(res.body).slice(0, 200)}`);
  return res.body.data as { id: number; code: string; name: string };
}

/** منتج (بدون تعبئة افتراضياً) */
export async function makeProduct(
  auth: Record<string, string>,
  name: string,
  opts: { unit?: string; packUnit?: string; packQty?: number; packSalePrice?: number; costPrice?: number; salePrice?: number; currency?: "IQD" | "USD"; rate?: number } = {}
) {
  const cur = opts.currency ?? "IQD";
  const body: Record<string, unknown> = {
    name,
    unit: opts.unit ?? "حبة",
    cost_price: opts.costPrice ?? 1000,
    sale_price: opts.salePrice ?? 1500,
    min_stock: 0,
  };
  if (opts.packUnit) { body.pack_unit = opts.packUnit; body.pack_qty = opts.packQty ?? 11; }
  if (cur === "USD") {
    body.cost_currency = "USD";
    body.sale_currency = "USD";
    body.exchange_rate = opts.rate ?? 1300;
    if (opts.packSalePrice != null) { body.pack_sale_price = opts.packSalePrice; body.pack_sale_currency = "USD"; }
  }
  const res = await post("/products", auth, body);
  if (!res.ok) throw new Error(`product failed: ${JSON.stringify(res.body).slice(0, 220)}`);
  return res.body.data as { id: number; name: string; unit: string; sale_price: number };
}
