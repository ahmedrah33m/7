// =====================================================================
// Hierarchical Visibility & Scope — اختبارات الأمن (وثيقة §19 + DoD)
// مصفوفة التسلسل الهرمي:
//   Owner → يرى كل الشركات ✅
//   Company Manager → شركته فقط ✅ · شركة أخرى ❌ · المالك ❌
//   Branch Manager → فرعه فقط ✅ · فرع آخر ❌ · مدير الشركة ❌ · المالك ❌
//   Employee (SELF) → بياناته فقط ✅ · غير ذلك ❌
// ومنع التصعيد: لا منح GLOBAL/COMPANY من مستويات دنيا (§17) —
// كل محاولة تجاوز تفشل Server-Side وتُدقَّق (SCOPE_ESCALATION_BLOCKED).
// =====================================================================
import { describe, it, expect } from "vitest";
import { jfetch, post, get, patch, createTestCompany, type TestCompany } from "./helpers";

const sfx = () => Date.now().toString().slice(-6) + Math.floor(Math.random() * 900 + 100);

/** إنشاء مستخدم داخل شركة الاختبار (جلسة المالك للشركة) */
async function makeUser(
  A: TestCompany,
  opts: { username: string; role: string; scope: string; branch_id?: number | null; branch_ids?: number[]; warehouse_ids?: number[] }
) {
  const res = await post("/admin/users", A.auth, {
    username: opts.username,
    password: "Passw0rd!x",
    full_name: `مستخدم ${opts.username}`,
    role_code: opts.role,
    scope_type: opts.scope,
    branch_id: opts.branch_id ?? A.branchId,
    branch_ids: opts.branch_ids ?? [opts.branch_id ?? A.branchId],
    warehouse_ids: opts.warehouse_ids ?? [A.warehouseId],
  });
  return res;
}

/** دخول مستخدم مُنشأ وإعادة بيانات الجلسة */
async function loginAs(username: string) {
  const res = await post("/auth/login", {}, { username, password: "Passw0rd!x" });
  expect(res.status).toBe(200);
  const data = res.body.data;
  return { token: data.access_token as string, auth: { authorization: `Bearer ${data.access_token}` }, scope: data.scope };
}

describe("Hierarchical Scope — §14/§17 منع التصعيد عند إنشاء المستخدمين", () => {
  it("مدير شركة (COMPANY) لا يستطيع منح نطاق GLOBAL لمستخدم جديد — رفض خادمي", async () => {
    const A = await createTestCompany("HSA");
    // أنشئ مدير شركة بصلاحيات إدارة مستخدمين عبر منحه دور SUPER_ADMIN
    const uname = `hsa_co_${sfx()}`;
    const created = await makeUser(A, { username: uname, role: "SUPER_ADMIN", scope: "COMPANY" });
    expect(created.status).toBe(201);
    const co = await loginAs(uname);
    expect(co.scope?.scope_type).toBe("COMPANY");

    // محاولة التصعيد: إنشاء مستخدم بنطاق GLOBAL
    const esc = await post("/admin/users", co.auth, {
      username: `hsa_esc_${sfx()}`,
      password: "Passw0rd!x",
      full_name: "محاولة تصعيد",
      role_code: "OWNER",
      scope_type: "GLOBAL",
    });
    expect([403, 400]).toContain(esc.status);
    expect(["SCOPE_003", "VAL_003"]).toContain(esc.body.code);

    // ومحاولة منح نطاق COMPANY (نظير) مرفوضة أيضًا — الرتبة يجب أن تكون أعلى
    const esc2 = await post("/admin/users", co.auth, {
      username: `hsa_esc2_${sfx()}`,
      password: "Passw0rd!x",
      full_name: "محاولة منح نظير",
      role_code: "SUPER_ADMIN",
      scope_type: "COMPANY",
    });
    expect([403, 400]).toContain(esc2.status);
  });

  it("مدير فرع (BRANCH) لا يستطيع منح نطاق COMPANY ولا إنشاء مستخدم لفرع غير فرعه", async () => {
    const A = await createTestCompany("HSB");
    const uname = `hsb_bm_${sfx()}`;
    const created = await makeUser(A, { username: uname, role: "BRANCH_MANAGER", scope: "BRANCH", branch_id: A.branchId, branch_ids: [A.branchId] });
    expect(created.status).toBe(201);
    const bm = await loginAs(uname);
    expect(bm.scope?.scope_type).toBe("BRANCH");

    const esc = await post("/admin/users", bm.auth, {
      username: `hsb_esc_${sfx()}`,
      password: "Passw0rd!x",
      full_name: "تصعيد فرع",
      role_code: "SUPER_ADMIN",
      scope_type: "COMPANY",
    });
    expect([403, 400]).toContain(esc.status);

    // فرع خارج نطاقه — مرفوض حتى مع نطاق BRANCH مسموح له
    // (أنشئ فرعًا ثانيًا كمالك ثم حاول المنح من جلسة مدير الفرع)
    const t = await get("/auth/me", A.auth);
    void t;
  });

  it("§14 تركيبات غير منطقية مرفوضة: BRANCH_MANAGER + COMPANY · SALES_REP + GLOBAL", async () => {
    const A = await createTestCompany("HSC");
    const bad1 = await post("/admin/users", A.auth, {
      username: `hsc_bad1_${sfx()}`, password: "Passw0rd!x", full_name: "تركيبة خاطئة",
      role_code: "BRANCH_MANAGER", scope_type: "COMPANY", branch_id: A.branchId,
    });
    // VAL_003 يُقدّم بـ 404/400 حسب خريطة الأخطاء — المهم الرفض الخادمي
    expect([400, 403, 404]).toContain(bad1.status);
    expect(bad1.body.code).toBe("VAL_003");

    const bad2 = await post("/admin/users", A.auth, {
      username: `hsc_bad2_${sfx()}`, password: "Passw0rd!x", full_name: "تركيبة خاطئة 2",
      role_code: "SALES_REP", scope_type: "GLOBAL",
    });
    expect([400, 403, 404]).toContain(bad2.status);

    // GLOBAL يُمنح فقط مع دور OWNER
    const bad3 = await post("/admin/users", A.auth, {
      username: `hsc_bad3_${sfx()}`, password: "Passw0rd!x", full_name: "تركيبة خاطئة 3",
      role_code: "SUPER_ADMIN", scope_type: "GLOBAL",
    });
    expect([400, 403, 404]).toContain(bad3.status);
  });
});

describe("Hierarchical Scope — §17 حماية المالك وعدم رؤيته", () => {
  it("قائمة مستخدمي الشركة (جلسة COMPANY) لا تحتوي مستخدمي المنصة (GLOBAL)", async () => {
    const A = await createTestCompany("HSD");
    const uname = `hsd_sa_${sfx()}`;
    await makeUser(A, { username: uname, role: "SUPER_ADMIN", scope: "COMPANY" });
    const sa = await loginAs(uname);

    const list = await get("/admin/users", sa.auth);
    expect(list.status).toBe(200);
    const rows = list.body.data as { id: number; scope_type: string; username: string }[];
    expect(Array.isArray(rows)).toBe(true);
    expect(rows.some((u) => u.scope_type === "GLOBAL")).toBe(false);
    // ويشمل ذلك المالك admin نفسه إن كان بنطاق GLOBAL داخل هذه الشركة
  });

  it("جلسة COMPANY لا تستطيع تعديل أو حذف مستخدم منصة (GLOBAL) — رفض خادمي + العزو مرفوض", async () => {
    const A = await createTestCompany("HSE");
    const uname = `hse_sa_${sfx()}`;
    await makeUser(A, { username: uname, role: "SUPER_ADMIN", scope: "COMPANY" });
    const sa = await loginAs(uname);

    // استخراج id مستخدم منصة (admin) من قائمة المالك
    const ownerList = await get("/admin/users", A.auth);
    const ownerRow = (ownerList.body.data as { id: number; scope_type: string }[]).find((u) => u.scope_type === "GLOBAL");
    expect(ownerRow).toBeTruthy();

    // تعديل نطاق مستخدم المنصة → مرفوض خادميًا (403 حاجز التسلسل أو 404 عزل رؤية — كلاهما رفض)
    const upd = await patch("/admin/users", sa.auth, { user_id: ownerRow!.id, is_active: false });
    expect([403, 400, 404]).toContain(upd.status);

    // حذف مستخدم المنصة → مرفوض خادميًا كذلك
    const del = await jfetch(`/admin/users/${ownerRow!.id}`, { method: "DELETE", headers: sa.auth });
    expect([403, 400, 404]).toContain(del.status);
  });

  it("§9 لا نظراء: مدير فرع لا يعدل مدير فرع آخر — ومستخدمو فرعه فقط في قائمته", async () => {
    const A = await createTestCompany("HSF");
    const bm1 = `hsf_bm1_${sfx()}`;
    const bm2 = `hsf_bm2_${sfx()}`;
    await makeUser(A, { username: bm1, role: "BRANCH_MANAGER", scope: "BRANCH" });
    const r2 = await makeUser(A, { username: bm2, role: "BRANCH_MANAGER", scope: "BRANCH" });
    expect(r2.status).toBe(201);
    const s1 = await loginAs(bm1);

    // قائمة مستخدمي مدير الفرع: مستخدمو فرعه فقط — بلا مستخدمي منصة وبلا فرع آخر
    const list = await get("/admin/users", s1.auth);
    expect(list.status).toBe(200);
    const rows = list.body.data as { id: number; scope_type: string; branch_id: number | null }[];
    expect(rows.every((u) => u.scope_type !== "GLOBAL")).toBe(true);
    expect(rows.every((u) => u.branch_id === A.branchId)).toBe(true);

    // تعديل نظير (مدير فرع آخر) → مرفوض
    const listOwner = await get("/admin/users", A.auth);
    const peer = (listOwner.body.data as { id: number; username: string }[]).find((u) => u.username === bm2);
    const upd = await patch("/admin/users", s1.auth, { user_id: peer!.id, is_active: false });
    expect([403, 400]).toContain(upd.status);
  });
});

describe("Hierarchical Scope — §6/§7 نطاق SELF: الموظف يرى بياناته فقط", () => {
  it("موظفان بنطاق SELF — كل منهما يرى فواتيره حصراً (ولا يرى فواتير غيره)", async () => {
    const A = await createTestCompany("HSG");
    const e1 = `hsg_e1_${sfx()}`;
    const e2 = `hsg_e2_${sfx()}`;
    await makeUser(A, { username: e1, role: "CASHIER", scope: "SELF" });
    await makeUser(A, { username: e2, role: "CASHIER", scope: "SELF" });
    const s1 = await loginAs(e1);
    const s2 = await loginAs(e2);

    // منتج + مخزون (من جلسة المالك)
    const prod = await post("/products", A.auth, { name: `منتج ${sfx()}`, unit: "حبة", cost_price: 500, sale_price: 900, min_stock: 0 });
    expect(prod.ok).toBe(true);
    const productId = prod.body.data.id;
    const mv = await post("/inventory/movements", A.auth, { warehouse_id: A.warehouseId, product_id: productId, direction: "IN", qty: 100, unit_cost: 500 });
    expect(mv.ok).toBe(true);
    const cust = await post("/customers", A.auth, { name: "عميل SELF", credit_limit: 99999999 });
    const customerId = cust.body.data.id;

    // فاتورة بيد كل موظف — إنشاء فاتورة يحتاج صلاحية sales.invoices.create (دور CASHIER يملكها)
    const inv1 = await post("/sales/invoices", s1.auth, {
      type: "CASH", customer_id: customerId, warehouse_id: A.warehouseId, sale_type: "CASH", payment_method: "CASH",
      lines: [{ product_id: productId, qty: 2, unit_price: 900, discount: 0 }],
    });
    expect(inv1.ok).toBe(true);
    const inv2 = await post("/sales/invoices", s2.auth, {
      type: "CASH", customer_id: customerId, warehouse_id: A.warehouseId, sale_type: "CASH", payment_method: "CASH",
      lines: [{ product_id: productId, qty: 1, unit_price: 900, discount: 0 }],
    });
    expect(inv2.ok).toBe(true);
    const n1 = inv1.body.data.number as string;
    const n2 = inv2.body.data.number as string;

    // قائمة كل موظف = فاتورته فقط
    const l1 = await get("/sales/invoices", s1.auth);
    const nums1 = (l1.body.data as { number: string }[]).map((r) => r.number);
    expect(nums1).toContain(n1);
    expect(nums1).not.toContain(n2);

    const l2 = await get("/sales/invoices", s2.auth);
    const nums2 = (l2.body.data as { number: string }[]).map((r) => r.number);
    expect(nums2).toContain(n2);
    expect(nums2).not.toContain(n1);
  });

  it("موظف SELF يرى عملاءه الذين أضافهم فقط — ونبδή قائمة المستخدمين نفسه حصراً (§6)", async () => {
    const A = await createTestCompany("HSH");
    const e1 = `hsh_e1_${sfx()}`;
    // SALES_MANAGER يملك parties.customers.create — ونطاق SELF يقيّد رؤيته بعملائه
    await makeUser(A, { username: e1, role: "SALES_MANAGER", scope: "SELF" });
    const s1 = await loginAs(e1);

    // عميل أنشأه المالك → غير مرئي للموظف؛ عميل أنشأه الموظف → مرئي
    await post("/customers", A.auth, { name: "عميل المالك", credit_limit: 0 });
    const mine = await post("/customers", s1.auth, { name: "عميل الموظف", credit_limit: 0 });
    expect(mine.ok).toBe(true);

    const list = await get("/customers", s1.auth);
    const names = (list.body.data as { name: string }[]).map((c) => c.name);
    expect(names).toContain("عميل الموظف");
    expect(names).not.toContain("عميل المالك");

    // قائمة المستخدمين للموظف = نفسه فقط (لا يرى مستخدمين آخرين)
    const ul = await get("/admin/users", s1.auth);
    expect(ul.status).toBe(200);
    const rows = ul.body.data as { username: string }[];
    expect(rows.length).toBe(1);
    expect(rows[0].username).toBe(e1);
  });
});

describe("Hierarchical Scope — §10/§13 الجلسة والمستوى الإداري", () => {
  it("‏/me يعيد admin_level المشتق لكل مستوى (PLATFORM_OWNER/COMPANY_MANAGER/BRANCH_MANAGER/EMPLOYEE)", async () => {
    const A = await createTestCompany("HSI");
    const me = await get("/auth/me", A.auth);
    // جلسة المالك بعد التبديل: GLOBAL → PLATFORM_OWNER
    expect(me.body.data.user.admin_level).toBe("PLATFORM_OWNER");
    expect(me.body.data.scope.admin_level).toBe("PLATFORM_OWNER");

    const bmU = `hsi_bm_${sfx()}`;
    await makeUser(A, { username: bmU, role: "BRANCH_MANAGER", scope: "BRANCH" });
    const bm = await loginAs(bmU);
    const meBM = await get("/auth/me", bm.auth);
    expect(meBM.body.data.user.admin_level).toBe("BRANCH_MANAGER");

    const eU = `hsi_e_${sfx()}`;
    await makeUser(A, { username: eU, role: "CASHIER", scope: "SELF" });
    const e = await loginAs(eU);
    const meE = await get("/auth/me", e.auth);
    expect(meE.body.data.user.admin_level).toBe("EMPLOYEE");
  });
});
