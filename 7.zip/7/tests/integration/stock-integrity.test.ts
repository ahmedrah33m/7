// =====================================================================
// Phase 6 §6 — Integration: سلامة المخزون (Stock Integrity)
// الثابت المعتمد: StockBalance = Σ الحركات الصحيحة (valid StockMovements)
// لكل زوج (مستودع، منتج) — عبر: Opening · Purchase · Transfer · Sale ·
// Return · Stocktake · Void · Delivery (الإشعار لا يلمس الرصيد)
// =====================================================================
import { describe, it, expect, beforeAll } from "vitest";
import { PrismaClient } from "@prisma/client";
import { createTestCompany, setUsdRate, get, post, patch, makeProduct, makeCustomer, type TestCompany } from "./helpers";

const db = new PrismaClient();
let c: TestCompany;
let wh2Id: number;
let productId: number;
let customerId: number;
let saleInvoiceId: number;

/** Σ الحركات الموقعة لزوج (مستودع، منتج) */
async function movementSum(companyId: number, warehouseId: number, productId: number) {
  const rows = await db.stockMovement.findMany({
    where: { companyId, warehouseId, productId },
    select: { direction: true, qty: true },
  });
  return rows.reduce((acc, m) => {
    const q = Number(m.qty);
    return acc + (m.direction === "IN" ? q : -q);
  }, 0);
}

/** الثابت: الرصيد = Σ الحركات — على كل (مستودع، منتج) بالشركة */
async function assertLedgerInvariant() {
  const balances = await db.stockBalance.findMany({ where: { companyId: c.companyId } });
  expect(balances.length).toBeGreaterThan(0);
  for (const b of balances) {
    const sum = await movementSum(c.companyId, b.warehouseId, b.productId);
    expect(Math.abs(sum - Number(b.qty))).toBeLessThan(1e-6);
  }
}

beforeAll(async () => {
  c = await createTestCompany("STK");
  await setUsdRate(c.auth, 1550);
  const p = await makeProduct(c.auth, "منتج سلامة المخزون", { costPrice: 1000, salePrice: 1500 });
  productId = p.id;
  const cust = await makeCustomer(c.auth, "عميل سلامة المخزون");
  customerId = cust.id;
  // مستودع ثانٍ للتحويل
  const wh2 = await post("/admin/warehouses", c.auth, {
    code: "WH2", name: "مستودع الفحص الثاني", branch_id: c.branchId,
  });
  if (wh2.ok) wh2Id = wh2.body.data.id;
}, 120_000);

describe("§6 — دورة حياة المخزون الكاملة تحفظ الثابت", () => {
  it("1) Opening: +500 — الرصيد = Σ الحركات", async () => {
    const r = await post("/inventory/movements", c.auth, {
      warehouse_id: c.warehouseId, product_id: productId, direction: "IN", qty: 500, unit_cost: 1000, note: "افتتاحي",
    });
    expect(r.ok).toBe(true);
    await assertLedgerInvariant();
  });

  it("2) Purchase: +40 — الرصيد = Σ الحركات", async () => {
    const sup = await post("/suppliers", c.auth, { name: "مورد السلامة", phone: "0770" });
    expect(sup.ok).toBe(true);
    const r = await post("/purchases/invoices", c.auth, {
      supplier_id: sup.body.data.id, warehouse_id: c.warehouseId, type: "CASH",
      lines: [{ product_id: productId, qty: 40, unit_cost: 1100 }],
    });
    expect(r.ok).toBe(true);
    await assertLedgerInvariant();
  });

  it("3) Transfer: −10 من الرئيسي +10 للثاني — الطرفان متوازنان", async () => {
    if (!wh2Id) { expect(true).toBe(true); return; } // لا مستودع ثانٍ — يتخطى
    const r = await post("/inventory/transfers", c.auth, {
      from_warehouse_id: c.warehouseId, to_warehouse_id: wh2Id,
      lines: [{ product_id: productId, qty: 10 }],
    });
    expect(r.ok).toBe(true);
    const trId = r.body.data.id;
    const receive = await post(`/inventory/transfers/${trId}/receive`, c.auth, {});
    expect(receive.ok).toBe(true);
    const sumMain = await movementSum(c.companyId, c.warehouseId, productId);
    const sumWh2 = await movementSum(c.companyId, wh2Id, productId);
    expect(sumMain).toBe(530); // 500 + 40 − 10
    expect(sumWh2).toBe(10); // الواردة
    await assertLedgerInvariant();
  });

  it("4) Sale: −25 — الرصيد = Σ الحركات", async () => {
    const inv = await post("/sales/invoices", c.auth, {
      customer_id: customerId, warehouse_id: c.warehouseId, type: "CASH",
      lines: [{ product_id: productId, qty: 25 }],
    });
    expect(inv.ok).toBe(true);
    saleInvoiceId = inv.body.data.id;
    await assertLedgerInvariant();
  });

  it("5) Return: +5 — الرصيد = Σ الحركات", async () => {
    const detail = await get(`/sales/invoices/${saleInvoiceId}`, c.auth);
    expect(detail.ok).toBe(true);
    // فاتورة ببند واحد (25 حبة) — مسار تفاصيل الفاتورة لا يعرض product.id
    const line = detail.body.data.lines[0];
    expect(line).toBeTruthy();
    const ret = await post("/sales/returns", c.auth, {
      invoice_id: saleInvoiceId,
      lines: [{ invoice_line_id: line.id, qty: 5 }],
    });
    expect(ret.ok).toBe(true);
    await assertLedgerInvariant();
  });

  it("6) Stocktake: جرد عدّ وزيادة — الرصيد = Σ الحركات", async () => {
    const bal = await db.stockBalance.findFirst({ where: { companyId: c.companyId, warehouseId: c.warehouseId, productId } });
    const st = await post("/inventory/stocktakes", c.auth, { warehouse_id: c.warehouseId, notes: "جرد الفحص" });
    expect(st.ok).toBe(true);
    const stId = st.body.data.id;
    const counted = Number(bal?.qty) + 7;
    const saved = await patch("/inventory/stocktakes", c.auth, {
      id: stId, counts: [{ product_id: productId, counted_qty: counted }],
    });
    expect(saved.ok).toBe(true);
    const posted = await post(`/inventory/stocktakes/${stId}`, c.auth, { action: "post" });
    expect(posted.ok).toBe(true);
    await assertLedgerInvariant();
  });

  it("7) Void: فاتورة جديدة ثم إبطالها يعيد كميتها — الرصيد = Σ الحركات", async () => {
    const inv = await post("/sales/invoices", c.auth, {
      customer_id: customerId, warehouse_id: c.warehouseId, type: "CASH",
      lines: [{ product_id: productId, qty: 12 }],
    });
    expect(inv.ok).toBe(true);
    const voided = await post(`/sales/invoices/${inv.body.data.id}/void`, c.auth, { reason: "إبطال فحص السلامة" });
    expect(voided.ok).toBe(true);
    await assertLedgerInvariant();
  });

  it("8) Delivery: إنشاء وتسليم إشعار — الرصيد ثابت تماماً (قاعدة المرحلة 5)", async () => {
    const before = await db.stockBalance.findFirst({ where: { companyId: c.companyId, warehouseId: c.warehouseId, productId } });
    const dn = await post("/sales/delivery-notes", c.auth, {
      customer_id: customerId, warehouse_id: c.warehouseId,
      lines: [{ product_id: productId, qty: 2 }],
    });
    expect(dn.ok).toBe(true);
    const delivered = await patch(`/sales/delivery-notes/${dn.body.data.id}`, c.auth, { action: "deliver", received_by: "فحص" });
    expect(delivered.ok).toBe(true);
    const after = await db.stockBalance.findFirst({ where: { companyId: c.companyId, warehouseId: c.warehouseId, productId } });
    expect(Number(after?.qty)).toBe(Number(before?.qty)); // لا خصم ولا رد
    await assertLedgerInvariant();
  });
});
