// =====================================================================
// Integration — السعران المستقلان على بند الفاتورة (§18/§19 جولة 2)
// السيناريو المطلوب من الميدان: 1 كرتونة = 12 حبة · سعر الحبة 6000 ·
// سعر الكرتونة 72000 · بند يدمج 1 كرتونة + 2 حبة = 72000 + 12000 = 84000
// الأولوية: package_price/piece_price الصريحان يتجاوزان unit_price القديم.
// =====================================================================
import { describe, it, expect, beforeAll } from "vitest";
import { PrismaClient } from "@prisma/client";
import { createTestCompany, get, post, makeProduct, makeCustomer, type TestCompany } from "./helpers";

const prisma = new PrismaClient();

let c: TestCompany;
let productId: number;
let customerId: number;
let warehouseId: number;

async function intake(qty: number) {
  const r = await post("/inventory/movements", c.auth, {
    warehouse_id: warehouseId, product_id: productId, direction: "IN", qty, unit_cost: 4000, note: "تجهيز اختبار",
  });
  if (!r.ok) throw new Error(`intake failed: ${JSON.stringify(r.body).slice(0, 200)}`);
}

async function sell(lines: unknown[]) {
  const r = await post("/sales/invoices", c.auth, {
    customer_id: customerId, warehouse_id: warehouseId, type: "CASH", lines,
  });
  return r;
}

async function lineOf(invoiceId: number) {
  const d = await get(`/sales/invoices/${invoiceId}`, c.auth);
  if (!d.ok) throw new Error(`detail failed: ${JSON.stringify(d.body).slice(0, 200)}`);
  return d.body.data.lines[0] as {
    package_qty: number; loose_qty: number; package_price: number | null;
    unit_price: number; line_total: number; qty: number;
  };
}

beforeAll(async () => {
  c = await createTestCompany("DPR");
  warehouseId = c.warehouseId;
  // منتج الميدان الحرفي: حبة 6000 · كرتونة 12 حبة بسعر 72000
  const p = await makeProduct(c.auth, "منتج السعرين", {
    unit: "حبة", packUnit: "كرتونة", packQty: 12,
    salePrice: 6000, packSalePrice: 72000, costPrice: 4000,
  });
  productId = p.id;
  const cust = await makeCustomer(c.auth, "عميل السعرين");
  customerId = cust.id;
  await intake(100);
}, 120_000);

describe("§18/§19 جولة 2 — سعر الكرتونة وسعر الحبة في بند واحد", () => {
  it("1 كرتونة + 2 حبة بسعرين صريحين = 72000 + 12000 = 84000", async () => {
    const r = await sell([{ product_id: productId, package_qty: 1, loose_qty: 2, package_price: 72000, piece_price: 6000 }]);
    expect(r.ok).toBe(true);
    const ln = await lineOf(r.body.data.id);
    expect(ln.package_qty).toBe(1);
    expect(ln.loose_qty).toBe(2);
    expect(ln.package_price).toBe(72000);
    expect(ln.line_total).toBe(84000);
  });

  it("كراتين فقط: 2 × 72000 = 144000 — بلا حبات", async () => {
    const r = await sell([{ product_id: productId, package_qty: 2, loose_qty: 0, package_price: 72000, piece_price: 6000 }]);
    expect(r.ok).toBe(true);
    const ln = await lineOf(r.body.data.id);
    expect(ln.loose_qty).toBe(0);
    expect(ln.line_total).toBe(144000);
  });

  it("حبات فقط: 5 × 6000 = 30000 — السعر الصريح يتجاوز الافتراضي", async () => {
    const r = await sell([{ product_id: productId, package_qty: 0, loose_qty: 5, package_price: 72000, piece_price: 6100 }]);
    expect(r.ok).toBe(true);
    const ln = await lineOf(r.body.data.id);
    expect(ln.package_qty).toBe(0);
    expect(ln.line_total).toBe(30500);
  });

  it("بلا أسعار صريحة → الافتراضي من المنتج: 1 كرتونة + 3 حبة = 72000 + 18000 = 90000", async () => {
    const r = await sell([{ product_id: productId, package_qty: 1, loose_qty: 3 }]);
    expect(r.ok).toBe(true);
    const ln = await lineOf(r.body.data.id);
    expect(ln.package_price).toBe(72000);
    expect(ln.line_total).toBe(90000);
  });

  it("تجاوز سعر الكرتونة فقط: كرتونة بسعر 70000 (عرض المندوب) = 70000", async () => {
    const r = await sell([{ product_id: productId, package_qty: 1, loose_qty: 0, package_price: 70000 }]);
    expect(r.ok).toBe(true);
    const ln = await lineOf(r.body.data.id);
    expect(ln.package_price).toBe(70000);
    expect(ln.line_total).toBe(70000);
  });

  it("unit_price القديم بأساسه ما يزال مدعومًا (توافق خلفي): PACKAGE 72000", async () => {
    const r = await sell([{ product_id: productId, package_qty: 1, loose_qty: 0, unit_price: 72000, price_unit: "PACKAGE" }]);
    expect(r.ok).toBe(true);
    const ln = await lineOf(r.body.data.id);
    expect(ln.package_price).toBe(72000);
    expect(ln.line_total).toBe(72000);
  });
});
