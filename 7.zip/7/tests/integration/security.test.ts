// =====================================================================
// Phase 6 §4 — Integration: أمان Multi-Tenant
// شركتان A وB ببيانات متطابقة الأسماء — كل محاولات العبور A→B يجب أن تُرفض:
//   product · customer · warehouse · invoice · transfer · reports · search
// =====================================================================
import { describe, it, expect, beforeAll } from "vitest";
import { adminToken, get, post, patch, createTestCompany, makeProduct, makeCustomer, type TestCompany } from "./helpers";

let A: TestCompany;
let B: TestCompany;
let bProductId: number;
let bCustomerId: number;
let bInvoiceId: number;
let bProductIdForSearch: number;

const SHARED_PRODUCT = "منتج مشترك بين الشركتين";
const SHARED_CUSTOMER = "عميل مشترك بين الشركتين";

beforeAll(async () => {
  const token = await adminToken();
  A = await createTestCompany("SEC");
  B = await createTestCompany("SEB");

  // بيانات B (متطابقة الأسماء مع ما سيُنشأ في A)
  const bProd = await makeProduct(B.auth, SHARED_PRODUCT);
  bProductId = bProd.id;
  const bCust = await makeCustomer(B.auth, SHARED_CUSTOMER);
  bCustomerId = bCust.id;

  // مخزون B ثم فاتورة في B — هدف محاولات القراءة العابرة
  const bStock = await post("/inventory/movements", B.auth, {
    warehouse_id: B.warehouseId, product_id: bProductId, direction: "IN", qty: 10, unit_cost: 1000, note: "افتتاحي B",
  });
  if (!bStock.ok) throw new Error(`B stock failed: ${JSON.stringify(bStock.body).slice(0, 200)}`);
  const bInv = await post("/sales/invoices", B.auth, {
    customer_id: bCustomerId, warehouse_id: B.warehouseId, type: "CASH",
    lines: [{ product_id: bProductId, qty: 3 }],
  });
  if (!bInv.ok) throw new Error(`B invoice failed: ${JSON.stringify(bInv.body).slice(0, 200)}`);
  bInvoiceId = bInv.body.data.id;

  // بيانات A المطابقة الأسماء
  await makeProduct(A.auth, SHARED_PRODUCT);
  await makeCustomer(A.auth, SHARED_CUSTOMER);
  void token;
}, 120_000);

describe("§4.1 — عبور المنتج A→B", () => {
  it("GET /products/{B.id} → لا يعرض بيانات B (المسار PATCH/DELETE فقط — 405)", async () => {
    const res = await get(`/products/${bProductId}`, A.auth);
    expect(res.ok).toBe(false);
    expect(res.status).not.toBe(200);
  });

  it("PATCH /products/{B.id} → مرفوض", async () => {
    const res = await patch(`/products/${bProductId}`, A.auth, { name: "اختراق" });
    expect(res.ok).toBe(false);
    expect([403, 404]).toContain(res.status);
  });
});

describe("§4.2 — عبور العميل A→B", () => {
  it("GET /customers/{B.id} → غير موجود", async () => {
    const res = await get(`/customers/${bCustomerId}`, A.auth);
    expect(res.ok).toBe(false);
    expect([403, 404]).toContain(res.status);
  });
});

describe("§4.3 — عبور المستودع A→B", () => {
  it("أمر بيع على مستودع B → مرفوض (SCOPE/غير موجود)", async () => {
    const aCust = await get("/customers?per_page=5", A.auth);
    const custId = aCust.body.data?.[0]?.id;
    const aProd = await get("/products?per_page=5", A.auth);
    const prodId = aProd.body.data?.[0]?.id;
    const res = await post("/sales/orders", A.auth, {
      customer_id: custId, warehouse_id: B.warehouseId,
      lines: [{ product_id: prodId, qty: 1 }],
    });
    expect(res.ok).toBe(false);
  });

  it("حركة مخزون IN على مستودع B → مرفوض", async () => {
    const aProd = await get("/products?per_page=5", A.auth);
    const prodId = aProd.body.data?.[0]?.id;
    const res = await post("/inventory/movements", A.auth, {
      warehouse_id: B.warehouseId, product_id: prodId, direction: "IN", qty: 5,
    });
    expect(res.ok).toBe(false);
  });
});

describe("§4.4 — عبور الفاتورة A→B", () => {
  it("إنشاء فاتورة في A بعميل B → مرفوض", async () => {
    const aProd = await get("/products?per_page=5", A.auth);
    const prodId = aProd.body.data?.[0]?.id;
    const res = await post("/sales/invoices", A.auth, {
      customer_id: bCustomerId, warehouse_id: A.warehouseId, type: "CASH",
      lines: [{ product_id: prodId, qty: 1 }],
    });
    expect(res.ok).toBe(false);
  });

  it("قراءة فاتورة B من جلسة A → غير موجود", async () => {
    const res = await get(`/sales/invoices/${bInvoiceId}`, A.auth);
    expect(res.ok).toBe(false);
    expect([403, 404]).toContain(res.status);
  });

  it("إبطال فاتورة B من جلسة A → مرفوض", async () => {
    const res = await post(`/sales/invoices/${bInvoiceId}/void`, A.auth, { reason: "اختراق" });
    expect(res.ok).toBe(false);
  });
});

describe("§4.5 — عبور التحويل A→B", () => {
  it("تحويل من مستودع A إلى مستودع B → مرفوض", async () => {
    const aProd = await get("/products?per_page=5", A.auth);
    const prodId = aProd.body.data?.[0]?.id;
    const res = await post("/inventory/transfers", A.auth, {
      from_warehouse_id: A.warehouseId, to_warehouse_id: B.warehouseId,
      lines: [{ product_id: prodId, qty: 1 }],
    });
    expect(res.ok).toBe(false);
  });
});

describe("§4.6 — عبور التقارير A→B", () => {
  it("أرصدة مخزون A لا تُظهر منتج B أبداً", async () => {
    const res = await get("/inventory/balances?per_page=200", A.auth);
    expect(res.ok).toBe(true);
    const rows = res.body.data ?? [];
    const leaked = rows.some((r: any) => r.product_id === bProductId);
    expect(leaked).toBe(false);
  });
});

describe("§4.7 — عبور البحث A→B", () => {
  it("البحث في A عن الاسم المشترك لا يُرجع منتج B", async () => {
    bProductIdForSearch = bProductId;
    const res = await get(`/search?q=${encodeURIComponent(SHARED_PRODUCT)}`, A.auth);
    expect(res.ok).toBe(true);
    // مشيّة عميقة: لا عقدة في نتائج A تحمل معرّف منتج B
    const hitsId = (node: unknown): boolean => {
      if (node == null) return false;
      if (Array.isArray(node)) return node.some(hitsId);
      if (typeof node === "object") {
        const o = node as Record<string, unknown>;
        if (o.id === bProductIdForSearch) return true;
        return Object.values(o).some(hitsId);
      }
      return false;
    };
    expect(hitsId(res.body.data)).toBe(false);
    // لكن يجب أن يجد منتج A المطابق بالاسم
    expect(JSON.stringify(res.body.data)).toContain(SHARED_PRODUCT);
  });
});
