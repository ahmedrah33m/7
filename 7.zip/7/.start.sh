#!/bin/bash
cd /home/ahmedr/maydanerp
nohup setsid npx next start -p 3000 >/home/ahmedr/maydanerp/app.log 2>&1 < /dev/null &
sleep 8
ss -tlnp | grep ':3000'
echo '---LOG---'
tail -4 /home/ahmedr/maydanerp/app.log
curl -s -o /dev/null -w 'HEALTH HTTP %{http_code}\n' http://localhost:3000/api/v1/health