#!/bin/bash
CH=/home/ahmedr/maydanerp/.next/server/chunks/ssr/src_app_page_tsx_1chiuah._.js
echo '=== exact "مصادقة JWT" in chunk ==='
grep -c 'مصادقة JWT' "$CH"
echo '=== exact "midaniq" in chunk ==='
grep -c 'midaniq' "$CH"
echo '=== exact "جميع الحقوق" in chunk ==='
grep -c 'جميع الحقوق' "$CH"
echo '=== context around argon2id ==='
grep -o '.\{30\}argon2id.\{30\}' "$CH" | head -3