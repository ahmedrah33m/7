# PHASE 3 — تقرير مطابقة ما بعد الترحيل (Post-Migration Reconciliation)

**التاريخ:** 2026-09-17 · **المرجع:** §7 من `upload/Phase 3 — Financial Decimal Migration.md`

## الأمر المنفَّذ

```bash
node scripts/phase3-reconcile.mjs \
  /home/z/my-project/backups/phase3/custom-pre-decimal-20260916-212731.db \
  /home/z/my-project/db/custom.db
```

> ملاحظة تشغيلية: يجب تمرير **مسارات مطلقة** — Prisma يحل مسارات `file:` النسبية
> من مجلد `prisma/` وليس من مجلد التشغيل.

## النتيجة

```
فحوص المطابقة: 3875
✓ تطابق تام — كل القيم المالية قبل/بعد الترحيل متطابقة
```

| البند | النتيجة |
|---|---|
| عدد الفحوص المقارنة | **3,875** (فواتير وبنودها ومشترياتها، عملاء/موردون/أرصدة، صناديق، عمولات، جرد، حزم ودفتر التعبئة، حركات المخزون…) |
| فروقات قيم | **صفر** — المقارنة نصية دقيقة عبر Decimal (لا تسامح إبسيلون) |
| إعادة حساب أثناء الترحيل | لم تحدث — القيم نُقلت كما هي (شرط «totals القديمة = totals الجديدة») |

## بصمات الملفات (MD5)

| الملف | MD5 |
|---|---|
| `backups/phase3/custom-pre-decimal-20260916-212731.db` (قبل الترحيل) | `299a5554ef07fe4827853817806a5bbc` |
| `db/custom.db` (بعد الترحيل + بيانات اختبارات ما بعد الترحيل) | تتغير مع الاستخدام الطبيعي — اللقطة أعلاه موثقة زمنيًا |

> القاعدة «بعد» تتقدم بالبيانات مع كل اختبارات ما بعد الترحيل؛ نقطة المقارنة
> الرسمية هي لقطة ما بعد الترحيل المباشر، وأي فحص لاحق يعيد النسخة الحالية
> مقابل لقطة «قبل» — الفروقات المسموحة هي فقط صفوف الفواتير/الحركات الجديدة
> اللاحقة للاختبارات، أما القيم المشتركة فمطابقة نصيًا.

## أصول الترحيل (§7)

| الأصل | المسار |
|---|---|
| نسخة احتياطية قبل الترحيل | `backups/phase3/custom-pre-decimal-20260916-212731.db` |
| مخطط ما قبل الترحيل | `backups/phase3/schema-pre-decimal.prisma` |
| كود ما قبل الترحيل | `backups/phase3/src-pre-decimal.tar.gz` |
| بروفة الترحيل (rehearsal) | `backups/phase3/rehearsal.db` |
| سكربت تحويل المخطط (تصنيف صريح لكل حقل) | `scripts/phase3-schema-convert.mjs` |
| سكربت المطابقة | `scripts/phase3-reconcile.mjs` |

## قابلية الرجوع (Rollback)

1. إيقاف الخادم.
2. `cp backups/phase3/custom-pre-decimal-*.db db/custom.db`
3. `cp backups/phase3/schema-pre-decimal.prisma prisma/schema.prisma`
4. فك `src-pre-decimal.tar.gz` فوق `src/` (أو مرجعة git إن توفرت).
5. `bunx prisma generate && bunx prisma db push` ثم إعادة تشغيل الخادم.

الترحيل قابل للرجوع بالكامل من هذه اللقطات دون أي خطوة يدوية أخرى.
