# WALK-IN CUSTOMER AUDIT — تدقيق الزبون المتردد/النقدي/غير المعروف قبل التعديل

> المرحلة 0 من MASTER PROMPT · تاريخ التدقيق: 2026-09-15

## 1) What Exists — ما يخص العملاء اليوم

### جدول `customers` (12 عميلًا مزروعًا)
- حقول: code (C-00001)، name، phone، address، credit_limit، credit_days، **balance (ذمة +مدين)**، discount_pct، loyalty_points/lifetime، status (ACTIVE|BLOCKED|CREDIT_HOLD)، shop_name/whatsapp/area (بطاقة الفاتورة الذكية §2).
- قيد التفرد: `@@unique([companyId, code, deletedAt])` ✓ (المرحلة 39 محققة للعملاء).
- **لا يوجد `customer_type`** — كل العملاء ضمنيًا "مسجلون".
- **لا يوجد `branch_id`** — العملاء على مستوى الشركة فقط.

### فاتورة البيع `sales_invoices`
- `customerId` إجباري (FK) — لا يمكن إصدار فاتورة بلا عميل.
- لقطات الرصيد §42: previous/new/credit_limit_snap + credit_exceeded + stock_applied.
- saleType عرض (CASH|CREDIT|PARTIAL|SWAP|RETURN) + type مالي (CASH|CREDIT).
- **لا لقطة نوع العميل** ولا حقول معلومات متردد اختيارية.

### حراس البيع الحاليون (sales-service.createSalesInvoice)
- BLOCKED → منع بيع · CREDIT_HOLD → نقدي فقط ✓
- حرس ائتماني: projected > credit_limit → CREDIT_001 (BLOCK) أو CREDIT_002 (موافقة) ✓
- الذمة: `due > 0 → customer.balance += due` — **لا تمييز لنوع العميل**.

### الصندوق
- `collectFromCustomer` يحصّل من **ذمة العميل** فقط (يرفض تجاوز المديونية).
- **الفاتورة النقدية (CASH) لا تولّد أي CashTransaction** — الدخل النقدي المباشر لا يظهر في الصندوق (فجوة §31).

## 2) What Is Missing — الفجوات مقابل المراحل 18-33

| المرحلة | المطلوب | الحالة |
|---|---|---|
| 19 أنواع العملاء | REGISTERED / WALK_IN / CASH_CUSTOMER / GUEST + مسميات قابلة للضبط | ❌ غير موجود |
| 20 السجل الافتراضي | CASH-001 «زبون نقدي» جاهز للنقطة بيع | ❌ |
| 21 قيود المتردد | بيع نقدي فقط · بلا ذمة · بلا حد ائتماني · الآجل مرفوض برسالة محددة | ❌ (لا نوع أصلًا) |
| 22 التحويل لعميل مسجل | Convert to Customer + حفظ converted_from_walk_in دون حذف التاريخ | ❌ |
| 23 معلومات اختيارية | اسم/هاتف/عنوان اختيارية لا تعيق البيع السريع | ❌ |
| 24 فاتورة المتردد | اختيار سريع في POS + ظهور النوع | ❌ |
| 25 بيانات العميل بالفاتورة | الاسم/الكود/النوع/الهاتف/العنوان/المندوب/الفرع | جزئي (النوع مفقود) |
| 26 الرصيد السابق | مسجل → يظهر؛ متردد → 0/0 | يعمل للمسجل ✓ (0/0 تلقائية عند نقدي) |
| 27 ذمة المتردد | لا ذمة — الفواتير للتقارير/المرتجعات فقط | ❌ يحتاج نوعًا لحجب الآجل |
| 28 التقارير | تفريق مسجل/متردد/نقدي | ❌ |
| 29 التحليلات | KPIs: مبيعات المتردد، عدد العمليات، معدل التحويل | ❌ |
| 30 الترقيم | لا تغيير + WALK-IN/REGISTERED في metadata فقط | ✓ (سنضيف customer_type لقطة — الترقيم لم يُمس) |
| 31 الصندوق | Invoice → Payment → Cashbox إجباري للمتردد | ❌ فجوة قائمة حتى للمسجل النقدي |
| 32 مرتجع المتردد | مرتجع بمرجع الفاتورة الأصلية (مخزون+مبلغ+COGS) | ✓ يعمل (المرتجعات بمرجع فاتورة، الرد النقدي عبر الصندوق) |
| 33 البحث | اسم/هاتف/كود + منع تكرار سجلات المتردد الافتراضية | البحث موجود ✓ — المنع يحتاج ضبط الإنشاء |

## 3) What Must Change — التغييرات

### مخطط
```
Customer      + customer_type (REGISTERED|WALK_IN|CASH_CUSTOMER|GUEST, default REGISTERED)
              + converted_from_walk_in (bool) + converted_at (datetime)
SalesInvoice  + customer_type (لقطة عند الإنشاء) + walkin_name/walkin_phone/walkin_address (اختيارية §23)
Settings      + customers.labels JSON (المسميات الأربعة قابلة للتعديل من الإعدادات §19)
              + walkin.strategy = SHARED (سجل افتراضي واحد) — "استراتيجية موحدة يحددها النظام" §52
```

### منطق الخادم
- `lib/walkin.ts`: `ensureWalkInCustomer(companyId)` — يجد/ينشئ CASH-001 بنوع WALK_IN وائتمان 0؛ idempotent؛ يُستدعى من البذر ومن نقطة البيع.
- `createSalesInvoice`: أي عميل غير REGISTERED + `type=CREDIT` → **WALK_001** «لا يمكن تسجيل بيع آجل لزبون متردد...» + تدقيق WALKIN_CREDIT_ATTEMPT (المرحلة 21/48).
- لقطة `customerType` على الفاتورة + حقول walkin_* الاختيارية (§23/§25).
- **ربط الصندوق (§31)**: عند ترحيل أي فاتورة بمبلغ مدفوع > 0 → CashTransaction IN (refType=SALES_INVOICE) على صندوق الفرع الافتراضي؛ عند إلغاء فاتورة مرحّلة → OUT معاكس (استرداد للعميل).
- منع إنشاء WALK_IN/CASH_CUSTOMER/GUST يدويًا من واجهة العملاء (الأنواع الخاصة للنظام فقط — §33/§52): الإنشاء اليدوي يجبر REGISTERED.
- `POST /customers/[id]/convert`: المتردد/النقدي/الضيف → REGISTERED (اسم إلزامي، هاتف/عنوان/حد اختياري) + converted_from_walk_in=true + تدقيق WALKIN_CONVERTED؛ إذا كان المحوَّل هو السجل الافتراضي المشترك → يُنشأ سجل افتراضي جديد تلقائيًا (تاريخ المحوَّل يبقى سليمًا بفواتيره §52).

### الواجهة
- فاتورة جديدة: شريط عميل POS — [بحث] [زبون نقدي (افتراضي محدد)] [+ إنشاء عميل] + حقول اختيارية للمتردد + شارة نوع + حجب الآجل مسبقًا.
- العملاء: عمود/فلتر نوع + زر «تحويل لعميل مسجل» لغير المسجلين.
- الفواتير/التفاصيل/الطباعة: شارة النوع وبيانات المتردد الاختيارية.
- التقارير: تقرير «مبيعات حسب نوع العميل» + KPIs (مبيعات/عمليات المتردد، معدل التحويل).

## 4) Migration Risks & Backward Compatibility

| الخطر | التخفيف |
|---|---|
| عملاء حاليون يتحولون لمتردد خاطئًا | default REGISTERED — لا بذر يغيّر النوع الحالي (§41) |
| تعارض كود CASH-001 مع كود قائم | ensureWalkIn يتجاوز الأكواد المستعملة (CASH-00N التالي المتاح) |
| فواتير قديمة بلا customer_type | default REGISTERED في DB — كل الاستعلامات تعمل |
| حجب الآجل يكسر عمليات قائمة؟ | لا — كل العملاء الحاليون مسجلون؛ الحرس يستهدف الأنواع الخاصة فقط |
| ربط الصندوق يغيّر أرصدة تاريخية | يطبق على العمليات الجديدة فقط (لا إعادة احتساب) |
| ذمة المتردد | استحالة وصولها: due=0 دائمًا (نقدي إجباري) — ولا حركة balance |

## 5) Definition of Done (المستخلص §51)
Company/Branch/Warehouse scope ✓ · Switchers ✓ · Audit ✓ · Walk-In/Cash/Guest ✓ · Credit Restriction ✓ · Conversion ✓ · Invoice/Ledger/Cashbox/Reports Integration ✓ · Security Tests ✓ · E2E ✓
