# RP1 — Product Price Data Closure — تقرير الإتمام

_التاريخ: 2026-09-17 · المرجع: MASTER REPAIR PROMPT — PHASE 1 · الحالة: **COMPLETED — DoD 6/6**_

## 1. ما أُنجز

### §1 Audit (`scripts/rp1-audit.mjs` → `docs/RP1_PRICE_AUDIT.md`)
تدقيق كامل لكل الشركة/المنتج/الأسعار قبل الترحيل. النتيجة الحاسمة: شركة النخبة (#1) — **كل منتجاتها الثمانية (البذور القديمة) بلا أي ProductPrice نشط** (16 قيمة Legacy قابلة للترحيل: 8 SALE + 8 COST، كلها IQD)، وصفر تكرارات وصفر صفوف غير صالحة في بقية الشركات.

### §2 Legacy Migration (`scripts/rp1-migrate.mjs` → `docs/RP1_MIGRATION_REPORT.md`)
- 8 صفوف `SALE/PIECE/IQD` + 8 صفوف `COST/PIECE/IQD` أُنشئت من الأعمدة المسطحة.
- **قاعدة العملة موثّقة لا مُخمَّنة**: أعمدة products المسطحة معرّفة في السكيما كـ«إسقاط بالعملة الأساسية IQD» — لذا الترحيل IQD بالضرورة. لا حالات استثناء (لا منتج بلا عملة معروفة) — `exceptions = 0`.
- SALE/PACKAGE: صفر منتجات معبأة بلا سعر عبوة (D=0 قبل وبعد) — لا شيء للترحيل.
- **Idempotent**: التشغيل الثاني = صفر إنشاء (مُتحقق).

### §4 Duplicate Rule
- تدقيق: صفر مجموعات مكررة نشطة (E=0) + مسار الترحيل يتضمن إغلاق التكرارات (الأحدث يبقى).
- الحماية وقت الكتابة قائمة أصلاً في `syncProductPrices`: يغلق كل صف نشط بنفس (priceType, unit) قبل إنشاء الجديد (العملة جزء من الهوية) — effectiveFrom/effectiveTo تاريخ أسعار كامل.
- ملاحظة لـRP2: فهرس فريد جزئي `WHERE is_active` على (company, product, priceType, unit, currency) يُضاف في ترحيل PostgreSQL.

### §5 Source of Truth (`ProductPrice = Primary`)
الربط الفعلي عبر مساعد مركزي جديد `defaultPricesFromRows()` في `product-pricing.ts` (صفوف مهيكلة بعملتها كما خُزّنت → تحويل USD بسعر صرف معروف فقط → رفض PRD_006 بلا تخمين → سقوط Legacy موثّق):

| المسار | قبل | بعد |
|---|---|---|
| الفواتير (sales-service) | مهيكل أولاً + Legacy صامت | مهيكل أولاً + Legacy **مع تحذير تطويري** |
| العروض (quotation-service) | ❌ Legacy فقط | ✅ ProductPrice أولاً + Legacy محذّر |
| أوامر البيع (sales-order-service) | ❌ Legacy فقط | ✅ ProductPrice أولاً + Legacy محذّر |
| B2B (الكتالوج + الطلب) | ❌ Legacy فقط | ✅ ProductPrice أولاً + Legacy محذّر (سقوط فقط عند USD بلا صرف كي لا يُعطَّل الكتالوج — موثّق) |

`resolveDefaultSalePrices` أُعيدت هيكلته فوق المساعد نفسه (سلوكها المحفوظ حرفياً).

### §6 Mandatory Regression — 143 فحصاً أخضر
- Unit **52/52** (تسعير 26/11 = 2.363636 + تعبئة + عملة + decimal + cost)
- Integration **40/40** (المشية الذهبية: 5 كراتين = 55 حبة = 169,000 IQD = 130 USD بالضبط · 3 حبات = 7.090909 USD · مخزون · مالية · أمن)
- E2E **12/12** · phase3-verify **39/39** (السيناريو الحرفي بالأرقام الذهبية)
- **دخان حي مباشر** (`scripts/rp1-smoke.mjs`): عرض بلا سعر صريح → 8500 من ProductPrice · B2B list_price=8500 — **QUOTATION_FROM_PRODUCTPRICE=YES · B2B_FROM_PRODUCTPRICE=YES**
- tsc نظيف · لا انحدار في Multi-Tenant/Cost Layer/Delivery/Packaging (كل بطارياتها ضمن الـ143)

## 2. Definition of Done — 6/6

| البند | النتيجة |
|---|---|
| Products without active ProductPrice = 0 | ✅ 0 (كانت 8) |
| Invalid ProductPrice = 0 | ✅ 0 |
| Duplicate active ProductPrice = 0 | ✅ 0 |
| Currency-less active price = 0 | ✅ 0 |
| Packaged products with valid package pricing = 100% | ✅ 100% |
| Pricing regression = PASS | ✅ 143/143 + دخان حي |

## 3. ملفات المرحلة
- سكربتات: `scripts/rp1-audit.mjs` · `scripts/rp1-migrate.mjs` · `scripts/rp1-smoke.mjs`
- تقارير: `docs/RP1_PRICE_AUDIT.md` · `docs/RP1_MIGRATION_REPORT.md` · هذا التقرير
- كود: `src/lib/product-pricing.ts` (مساعد مركزي + تحذيرات) · `src/lib/quotation-service.ts` · `src/lib/sales-order-service.ts` · `src/lib/b2b-service.ts` · `src/lib/sales-service.ts`

## 4. بنود مسجلة لاحقاً
- الفهرس الفريد الجزئي على product_prices → ينفذ في RP2 (PostgreSQL يدعم partial unique index).
- `Product.costPrice` لم يُحذف (ممنوع حسب الأمر) — يبقى إسقاط IQG متزامناً عبر `syncProductPrices`.
