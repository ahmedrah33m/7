# ميدان (Kayan) — معمارية الرؤية والنطاق الهرمية
## Hierarchical Visibility & Scope Architecture — المعتمدة 2026-09-18

> المرجع: «Kayan — Hierarchical Visibility & Scope Architecture.md» (وثيقة المتطلبات)
> الحكم: **مُنفَّذة Server-Side بالكامل** — RBAC + Hierarchical Scope + Data Visibility

---

## 1. النموذج المعتمد

النظام لا يسأل فقط: *ما صلاحية هذا المستخدم؟* (RBAC — `module.action`)
بل يسأل أيضًا: *ما مستواه الإداري؟ وما البيانات التي تقع تحته؟* (Scope)

```text
الصلاحية (Permission) → ماذا أستطيع أن أفعل؟
النطاق (Scope)        → ماذا أرى؟ وعلى أي بيانات أفعله؟
```

## 2. المستويات الإدارية (§2)

| المستوى | scopeType المرتبط | الوصف |
|---|---|---|
| `PLATFORM_OWNER` | `GLOBAL` | مالك المنصة — يرى كل الشركات وينتقل بينها |
| `COMPANY_MANAGER` | `COMPANY` | مدير شركة — شركته فقط |
| `BRANCH_MANAGER` | `BRANCH` | مدير فرع — فروعه الممنوحة فقط |
| `EMPLOYEE` | `WAREHOUSE` / `SALES_REP` / `SELF` | موظف تشغيلي — نطاق ضيق/بياناته فقط |

المشتق آليًا في `adminLevelOf()` (src/lib/scope.ts) ويُعاد في:
`/auth/me` → `user.admin_level` و `scope.admin_level` (ولواجهة المستخدمين عمود «المستوى»).

## 3. رتب النطاقات — السلطة تنزل ولا تصعد (§9/§17)

```ts
SCOPE_RANK = { GLOBAL: 40, COMPANY: 30, BRANCH: 20, WAREHOUSE: 10, SALES_REP: 8, SELF: 5 }
```

**قاعدة المنح الصارمة**: منح نطاق يتطلب رتبة مانح **أعلى** من رتبة النطاق:

| الجلسة | يستطيع المنح |
|---|---|
| GLOBAL (40) | أي نطاق |
| COMPANY (30) | BRANCH · WAREHOUSE · SALES_REP · SELF |
| BRANCH (20) | WAREHOUSE · SALES_REP · SELF |
| WAREHOUSE/SALES_REP/SELF | لا شيء (لا إدارة مستخدمين من الأسفل) |

تنبيه: مدير الشركة **لا يستطيع** إنشاء نظير له (COMPANY آخر) ولا أي نطاق أعلى —
الإنشاء بين الشركات/للمنصة حصراً من مالك المنصة.

## 4. ScopeService المركزي (§15)

`src/lib/scope-service.ts` — لا يخترع أي API منطق نطاق خاصًا:

| الدالة | الوظيفة |
|---|---|
| `canGrantScope / assertGrantScope` | بوابة منح النطاق + تدقيق المحاولات المرفوضة |
| `validateRoleScopeCombo` | مصفوفة الدور ↔ النطاق (§14) |
| `canManageUser / assertManageUser` | من يدير من؟ (لا رؤساء ولا نظراء) |
| `ownRowsWhere / invoiceOwnRowsWhere` | تصفية «بياناتي فقط» لجلسات الموظفين |
| `usersListWhere` | where قائمة المستخدمين وفق التسلسل |
| `canAccessCompany / Branch / Warehouse / Record` | فحوص الموارد (§16) |

### مصفوفة الدور ↔ النطاق (سقوف)

OWNER→GLOBAL حصراً · SUPER_ADMIN/SALES_MANAGER/ACCOUNTANT/PURCHASING_OFFICER/AUDITOR/VIEWER ≤ COMPANY ·
BRANCH_MANAGER/CASHIER ≤ BRANCH · WAREHOUSE_MANAGER ≤ WAREHOUSE · SALES_REP ≤ SALES_REP.
كل تركيبة مخالفة تُرفض `VAL_003` وتُدقَّق.

## 5. نطاق SELF — الموظف (§6/§7)

`scopeType = SELF`: هيكليًا كالفرع (كي يعمل: مستودعه، صندوقه) — لكن **صفوف البيانات**
تُضيَّق إلى ما أنشأه حصرًا:

| نقطة | فلتر SELF |
|---|---|
| `GET /sales/invoices` | `createdById = self OR repId = self` |
| `GET /sales/orders` · `/quotations` · `/returns` · `/delivery-notes` | `createdById = self` |
| `GET /customers` | `createdBy = self` (+ فلتر الفرع القائم) |
| `GET /admin/users` | نفسه حصراً (لا يرى مستخدمين آخرين) |

التمييز الإلزامي §7: Scope=SELF لا يعني عجز الموظف عن تشغيل النظام —
إنشاؤه للفواتير/الطلبات/العملاء يعمل بكامل صلاحياته الممنوحة؛ الرؤية فقط هي المقيدة.
(دليل: اختبار «موظفان بنطاق SELF يرى كل منهما فواتيره حصراً» — الإنشاء نجاح، والقوائم معزولة).

## 6. حماية المالك (§17)

- مستخدمو المنصة (`scopeType=GLOBAL`) **غير مرئيين** في قوائم مستخدمي كل المستويات الدنيا.
- لا يمكن لأي جلسة أدنى من GLOBAL تعديل/حذف/نقل مستخدم منصة — `SCOPE_003`.
- لا يمكن منح `GLOBAL` أو دور OWNER عبر API إلا من جلسة مالك المنصة.
- شعار النظام (هوية المنصة، `system_brand`) أصل من مستوى PLATFORM_OWNER:
  رفع/إزالته عبر `/admin/system-logo` بصلاحية `system.settings.edit` —
  يظهر بطاقة رفعه في حساب مالك المنصة فقط، ولا يلمسه مديرو الشركات.

## 7. التدقيق (§18)

كل تغيير نطاق/أدوار/شركة يُدقَّق (`USER_SCOPE_CHANGED` / `USER_ROLES_CHANGED` /
`USER_COMPANY_CHANGED`) — **وكل محاولة تجاوز مرفوضة تُدقَّق أيضًا**:
`SCOPE_ESCALATION_BLOCKED` (الفاعل، مستواه، النطاق المطلوب، الهدف، السبب).

## 8. الفرض الخادمي — الطبقات الخمس (§11/§20)

1. **API**: `guard()` (مصادقة + صلاحية) ثم بوابات ScopeService.
2. **Service/Query**: فلاتر الشركة/الفرع/المستودع مشتقة من الجلسة (لا من الجسم) —
   `branchWhere/warehouseWhere/ownRowsWhere`.
3. **Resource-level**: ملكية السجل (شركة/فرع/منشئ) قبل العرض أو التعديل.
4. **Frontend**: إخفاء القوائم والخيارات (تقييد قائمة النطاقات المنحة حسب مستوى الجلسة) —
   تجميلي فقط، الحماية خلفية.
5. **اختبارات آلية**: `tests/integration/hierarchy-scope.test.ts`.

## 9. مصفوفة الأمن المنفذة (§19 — 9/9 خضراء)

```text
Owner → يرى كل الشركات ✅
Company Manager → شركته ✅ · شركة أخرى ❌ · المالك ❌ (غير مرئي + رفض تعديل/حذف)
Branch Manager → فرعه ✅ · مستخدمو فرعه فقط ✅ · مدير الشركة ❌ · نظراؤه ❌ · المالك ❌
Employee (SELF) → بياناته فقط ✅ · فواتير غيره ❌ · عملاء غيره ❌ · المستخدمون الآخرون ❌
التصعيد: COMPANY→GLOBAL ❌ · COMPANY→COMPANY ❌ · BRANCH→COMPANY ❌ (مع تدقيق المحاولة)
التركيبات: BRANCH_MANAGER+COMPANY ❌ · SALES_REP+GLOBAL ❌ · SUPER_ADMIN+GLOBAL ❌ · OWNER+غير GLOBAL ❌
```

## 10. لوحة التحكم حسب المستوى (§13)

التنقل والشاشات **مولّدة من الصلاحيات** (`navGroups` بفلاتر `can*`) — فيتغير شكل
اللوحة تلقائيًا حسب المستوى: المالك يرى «النظام والأمان» (شركات/اشتراكات/هوية المنصة)،
ومدير الشركة شركته، ومدير الفرع فرعه، والموظف شاشاته التشغيلية فقط.

## 11. DoD — حالة الإنجاز

| البند | الحالة |
|---|---|
| Owner sees all companies | ✅ (نطاق GLOBAL قائم + مبدّل شركات) |
| Company Manager sees only his company | ✅ (عزل صارم قائم) |
| Branch Manager sees only his branch | ✅ (branchWhere قائم + سد تسريب قائمة المستخدمين بلا سياق نشط) |
| Employee sees only self/assigned | ✅ (نطاق SELF جديد + فلاتر الصفوف) |
| منع رؤية المستوى الأعلى | ✅ (usersListWhere + إخفاء GLOBAL) |
| منع الوصول لشركة/فرع آخر | ✅ (بوابات قائمة) |
| منع تجاوز Scope عبر API | ✅ (ScopeService على كل مسارات المستخدمين) |
| منع تغيير Scope/Role لنفسه | ✅ (قائم: PERM_001) |
| تدقيق كل محاولة تجاوز | ✅ (SCOPE_ESCALATION_BLOCKED) |
| اختبارات آلية | ✅ 9 اختبارات — البطارية الكاملة 116/116 |
