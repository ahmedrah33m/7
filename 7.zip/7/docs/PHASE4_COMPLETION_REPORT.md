# تقرير إتمام المرحلة 4 — محرك طبقات التكلفة (Cost Layer · FIFO · WAVG · COGS Engine)

**التاريخ:** 2026-09-17 · **الحالة:** مكتملة بمعايير Definition of Done الخمسة
**ملف النطاق:** `upload/Phase 4 — Cost Layer, FIFO, WAVG & COGS Engine.md`

---

## 1) Definition of Done — 5/5

| معيار الوثيقة | التنفيذ | الدليل |
|---|---|---|
| real calculation engine | `src/lib/cost-engine.ts` — استهلاك فيزيائي من الطبقات بالطرق الأربعة | T3/T9/T10/T11 (أرقام الوثيقة حرفياً) |
| real database persistence | جدولا `cost_layers` + `cost_consumptions` (SQLite/PG متطابقان) | 53 طبقة افتتاحية + كل ترحيل جديد يكتب طبقات |
| real COGS | لقطة COGS غير قابلة للتغيير على البند والترويسة | `cogs_unit_cost/cogs_total/cogs_method/cogs_layers` |
| real report | 4 تقارير جديدة §9 | `/reports/costing-{layers,inventory,cogs,variance}` |
| automated tests | بطارية E2E رسمية | `scripts/phase4-verify.mjs` — **53/53 ✓** |

## 2) ما أُنجز

### §1-§2 — CostLayer والمصادر
- نموذج `CostLayer`: companyId/warehouseId/productId/sourceType/sourceId/sourceLineId/quantity/**remainingQuantity**/unitCost/currency/status — طبقة لكل دخول للبضاعة.
- المصادر المطبقة: `PURCHASE` (استلام شراء) · `OPENING_BALANCE` (إدخال يدوي) · `STOCK_ADJUSTMENT` (زيادة جرد) · `TRANSFER_RECEIPT` (استلام تحويل) · `SALES_RETURN` (مرتجع عميل) · `VOID_RESTORE` (إلغاء فاتورة) — و`PRODUCTION` مدعوم في المحرك دون نقطة ربط (لا توجد وحدة إنتاج بعد).
- سجل صرف غير قابل للتغيير `CostConsumption`: يوثق كل قطعة صرفت (layerId/qty/unitCost/totalCost/refType/refId/refLineId) — مرجع محاسبي دائم.

### §3 — FIFO
- استهلاك الأقدم أولاً (createdAt,id) بتكلفة كل طبقة الفعلية.
- **مثال الوثيقة حرفياً:** 100@1000 + 50@1200 ثم بيع 120 → COGS = 100×1000 + 20×1200 = **124000 بالضبط** (T3a، مراجع الطبقات قطعتان T3e).

### §4 — Weighted Average
- avg = إجمالي قيمة الطبقات المتبقية ÷ إجمالي كمياتها، يُعاد حسابه بعد كل استلام مؤهل (تحديث الشراء يحدث costPrice المتوسط كما سابقاً — إسقاط WAVG).
- الحساب بدقة كاملة 40 خانة بلا تقريب وسيط (R9): 120 × (160000/150) = **128000 بالضبط** (T9c) — التقريب فقط عند حدود التخزين (R2/R6).
- الصرف الفيزيائي ينزل remainingQuantity بالترتيب الأقدم حتى تحت WAVG (الطبقات مرآة المخزون).

### §5 — Standard Cost / Last Cost
- `Product.standardCost` (تكلفة معيارية منفصلة) + `Product.lastCost` (آخر تكلفة شراء فعلية، يضبطها محرك الشراء) — كلاهما مستقل عن costPrice المتوسط.
- STANDARD_COST: COGS = الكمية × المعيارية (30×1100 = 33000 بالضبط، T10c) · LAST_COST: الكمية × آخر شراء (20×1200 = 24000 بالضبط، T11a).
- ضبط المعيارية عبر PATCH `/products/[id]` بـ`standard_cost` (null = إلغاء).

### §6 — COGS Snapshot غير قابل للتغيير
- البند: `cogsUnitCost` + `cogsTotal` + `cogsMethod` + `cogsLayers` (JSON [{layer_id, qty, unit_cost}]).
- الترويسة: `costMethod` + `cogsTotal`.
- `SalesInvoiceLine.unitCost` صار يحمل التكلفة الفعلية من الطبقات (تقارير الربح والمرتجعات تستخدمها).
- T12: تغيير تكلفة المنتج لاحقاً (99999) لا يمس فواتير قديمة — أُعيد التحقق من القاعدة.

### §7 — Returns
- المرتجع يعيد دخول الطبقات بتكلفة صرفه الفعلية من سجل `cost_consumptions` (طبقة SALES_RETURN 10@1000 من الطبقة الأصلية، T4b) — لا تكلفة اليوم عند تكلفة الأمس.
- حارس ازدواج مدمج: كل سجل صرف يُسترجع مرة واحدة (يُقاس من الطبقات المولدة من نفس سجل الصرف).

### §8 — Transfers
- الإرسال: استهلاك فيزيائي FIFO-order دائماً (هوية التكلفة تحفظ في TRANSFER_OUT consumptions).
- الاستلام: طبقات وجهة بنفس تكاليف الإرسال — **لا تكلفة جديدة عشوائية** (طبقة الوجهة 20@1200 مطابقة للمصدر، T5c).
- استلام جزئي مدعوم (حارس «المستلم سابقاً» لكل سجل صرف).

### §9 — Reports (عبر `/api/v1/reports/[type]`)
- `costing-layers`: طبقات FIFO الحية (بقايا/تكلفة/عمر/مصدر) + summary قيمة.
- `costing-inventory`: قيمة المخزون من الطبقات + wavg الفعلي + standard + last لكل منتج.
- `costing-cogs`: الإيراد/COGS/الربح الإجمالي/الهامش لكل منتج خلال فترة (from/to) من لقطات البنود.
- `costing-variance`: انحراف المعيارية (وحدة/نسبة/قيمة على المخزون القائم) + آخر شراء.

### الإعدادات
- `GET/PUT /api/v1/settings/costing-method` — FIFO · WEIGHTED_AVERAGE · STANDARD_COST · LAST_COST (WAVG قديم → مُطبَّع)، رفض القيم غير المعروفة، audit، معزل بالشركة.
- التغيير يطبق على الترحيلات الجديدة فقط (اللقطة تحمي القديم).

## 3) نقاط الربط (كلها داخل معاملة المستدعي)
| المستند | الاستلام (طبقة) | الصرف (استهلاك) |
|---|---|---|
| شراء `purchasing-service` | PURCHASE + lastCost | — |
| حذف شراء | — | إبطال الطبقات المتبقية (VOID) |
| بيع `sales-service` | — | SALES_INVOICE + لقطة §6 |
| إلغاء فاتورة | VOID_RESTORE بتكلفة الصرف | — |
| اعتماد فاتورة معلقة | — | نفس مسار البيع |
| مرتجع `returns-service` | SALES_RETURN بتكلفة الصرف | — |
| تحويل `transfers-service` | TRANSFER_RECEIPT بنفس التكاليف | TRANSFER_OUT فيزيائي |
| جرد `stocktake-service` | زيادة = STOCK_ADJUSTMENT | عجز = ADJUSTMENT بطريقة الشركة |
| حركات يدوية `movements` | OPENING_BALANCE | ADJUSTMENT |

## 4) Backfill المخزون القائم
- `scripts/phase4-backfill.mjs` (idempotent): **53 طبقة افتتاحية** لأرصدة 53 (مستودع، منتج) بتكلفة المتوسط الساري — المخزون القديم صار قابل للصرف FIFO.

## 5) الاختبارات — النتائج
- **بطارية §10 الجديدة: 53/53 ✓** تغطي كل بنود القائمة الإلزامية: FIFO · WAVG · Opening Balance · Purchase · Sale · Return · Transfer · Stocktake (زيادة/عجز) · Void Invoice · Negative stock prevention (STOCK_001) · Historical invoice + الثابت الذهبي «Σ متبقي الطبقات = رصيد المخزون» بعد كل عملية + سلامة سجل الصرف.
- **الانحدار الكامل: 289 فحصاً سابقاً ✓** — phase3 39/39 · phase2 42/42 · phase0 25/25 · multi-branch 65/65 · invoice-smart 50/50 · phase1-security 43/43 · phase1-scope 6/6 · currency-edit 19/19.
- **المجموع: 342 فحصاً أخضر** · `bunx tsc --noEmit` نظيف · ملفات المرحلة بلا أخطاء lint جديدة.

## 6) قرارات تصميمية موثقة
1. **WAVG بلا تقريب وسيط** — المتوسط يُحسب بدقة 40 خانة والقطع تُخزَّن moneyR؛ المجاميع تطابق «القيمة ÷ الكمية» حرفياً (128000 لا 128000.004).
2. **الاسترجاع بطبقات جديدة** بتكلفة الصرف بدل إرجاع remaining للطبقات الأصلية — تكافئ محاسبي كامل (نفس القيمة والكمية) وبلا خطر ازدواج.
3. **الصرف الفيزيائي دائماً FIFO-order** حتى تحت WAVG/STD/LAST — الطبقات تبقى مرآة المخزون والتكلفة المطبقة تُسجل في consumptions.
4. **عجز الطبقات** (مخزون سالب مسموح سياسياً/مخزون قديم): صف consumption بlayerId=null بتكلفة المتوسط الساري — لا انهيار.
5. حذف فاتورة شراء لا يمس consumptions التاريخية (§6) — يبطل remaining فقط.

## 7) ملفات المرحلة
- جديد: `src/lib/cost-engine.ts` · `src/app/api/v1/settings/costing-method/route.ts` · `scripts/phase4-verify.mjs` · `scripts/phase4-backfill.mjs` · هذا التقرير.
- مخطط: CostLayer/CostConsumption + Product(standardCost,lastCost) + SalesInvoice(costMethod,cogsTotal) + SalesInvoiceLine(cogsUnitCost,cogsTotal,cogsMethod,cogsLayers).
- معدل: purchasing/sales/returns/transfers/stocktake services · movements route · products/[id] · reports-extra (+4 تقارير).

## 8) خطوات الرجوع (Rollback)
1. نسخة القاعدة قبل المرحلة: `backups/phase3/` (ما قبل phase4 = نفس آخر نسخة phase3 — لا تغيير بيانات هابط).
2. revert المخطط (حذف الجدولين والأعمدة الجديدة) + `db push` — الجداول الجديدة معزولة تماماً ولا تُغير سلوك القديم إن أُهملت (المحرك يعيد fallback لـcostPrice حين لا طبقات).
