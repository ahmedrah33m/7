# الملحق التقني الكامل — Kayan Financial Cashbox System
## Technical Specification Addendum

> هذا الملحق يكمّل ملف `MASTER PROMPT — Kayan Financial Cashbox & Receipt Management System.md`
> يغطّي كل الفجوات التقنية المكتشفة في المراحل 0–73.

---

## 1. تعريف النماذج البرمجية (Prisma Models)

### 1.1 نموذج Cashbox الموسّع

```prisma
model Cashbox {
  id              Int       @id @default(autoincrement())
  uuid            String    @unique @default(uuid())
  companyId       Int       @map("company_id")
  branchId        Int       @map("branch_id")
  code            String    // regex: ^[A-Z]{2,4}-[A-Z0-9]{2,6}$
  name            String    // 2-120 chars
  type            CashboxType @default(BRANCH)
  ownerUserId     Int?      @map("owner_user_id")
  warehouseId     Int?      @map("warehouse_id")
  currency        String    @default("IQD") @db.VarChar(3) // ISO 4217
  status          CashboxStatus @default(ACTIVE)
  openingBalance  Decimal   @default(0) @map("opening_balance") @db.Decimal(18,4)
  balance         Decimal   @default(0) @db.Decimal(18,4) // derived projection
  minBalance      Decimal?  @map("min_balance") @db.Decimal(18,4) // alert threshold
  maxBalance      Decimal?  @map("max_balance") @db.Decimal(18,4) // handover threshold
  description     String?   @db.Text
  version         Int       @default(0) // optimistic locking
  // std columns
  createdAt       DateTime  @default(now()) @map("created_at")
  updatedAt       DateTime  @default(now()) @updatedAt @map("updated_at")
  createdBy       Int?      @map("created_by")
  updatedBy       Int?      @map("updated_by")
  deletedAt       DateTime? @map("deleted_at")

  // Relations
  company         Company   @relation(fields: [companyId], references: [id])
  branch          Branch    @relation(fields: [branchId], references: [id])
  owner           User?     @relation("CashboxOwner", fields: [ownerUserId], references: [id])
  warehouse       Warehouse? @relation(fields: [warehouseId], references: [id])
  transactions    CashTransaction[]
  receipts        ReceiptVoucher[]
  paymentVouchers PaymentVoucher[]
  transfersOut    CashTransfer[] @relation("TransfersOut")
  transfersIn     CashTransfer[] @relation("TransfersIn")
  closings        CashboxClosing[]
  denominations   CashboxDenominationCount[]
  journalLines    JournalLine[]  @relation("JournalLineCashbox")

  // Constraints
  @@unique([companyId, code, deletedAt])
  @@index([branchId])
  @@index([type])
  @@index([status])
  @@index([companyId, status])
  @@map("cashboxes")
}

enum CashboxType {
  MAIN        // الصندوق الرئيسي للشركة
  BRANCH      // صندوق فرع
  REP          // صندوق مندوب
  CUSTOM       // صندوق مخصص
  BANK         // صندوق بنكي (وهمي للحساب البنكي)
}

enum CashboxStatus {
  ACTIVE       // فعّال — يقبل الحركات
  SUSPENDED    // معلّق مؤقتًا (لا يقبل حركات جديدة)
  CLOSED       // مغلق نهائيًا (لا يقبل أي حركة)
}
```

**قواعد انتقال الحالة:**
| من | إلى | بواسطة | شرط |
|---|---|---|---|
| ACTIVE | SUSPENDED | COMPANY_MANAGER+ | سبب إلزامي + تدقيق |
| SUSPENDED | ACTIVE | COMPANY_MANAGER+ | سبب إلزامي + تدقيق |
| ACTIVE/SUSPENDED | CLOSED | COMPANY_OWNER | سبب إلزامي + لا حركات معلّقة |
| CLOSED | ACTIVE (REOPEN) | PLATFORM_OWNER | موافقة الإشراف + سبب + تدقيق |

**قاعدة سلامة الرصيد:** `balance = openingBalance + Σ(IN transactions) − Σ(OUT transactions)` — يُتحقّق يوميًا عبر cron.

---

### 1.2 نموذج CashTransaction الموسّع

```prisma
model CashTransaction {
  id                  Int       @id @default(autoincrement())
  uuid                String    @unique @default(uuid())
  companyId           Int       @map("company_id")
  cashboxId           Int       @map("cashbox_id")
  direction           TransactionDirection // IN | OUT
  category            TransactionCategory
  transactionType     TransactionType?  @map("transaction_type")
  transactionNumber   String?   @map("transaction_number") // RCPT-.../PAY-.../TRF-...
  referenceNumber     String?   @map("reference_number") // snapshot: فاتورة/وصل/إيصال
  balanceBefore       Decimal?  @map("balance_before") @db.Decimal(18,4)
  balanceAfter        Decimal   @map("balance_after") @db.Decimal(18,4)
  amount              Decimal   @db.Decimal(18,4)
  currency            String?   @db.VarChar(3)
  exchangeRate        Decimal?  @map("exchange_rate") @db.Decimal(18,6)
  sourceCurrency      String?   @map("source_currency") @db.VarChar(3)
  targetCurrency      String?   @map("target_currency") @db.VarChar(3)
  // Links
  invoiceId           Int?      @map("invoice_id")
  purchaseInvoiceId   Int?      @map("purchase_invoice_id")
  paymentId           Int?      @map("payment_id")
  receiptId           Int?      @map("receipt_id")
  paymentVoucherId    Int?      @map("payment_voucher_id")
  cashTransferId      Int?      @map("cash_transfer_id")
  approvedById        Int?      @map("approved_by_id")
  idempotencyKey      String?   @map("idempotency_key") // UNIQUE per company
  // Reversal
  isReversed          Boolean   @default(false) @map("is_reversed")
  reversalOfId       Int?      @map("reversal_of_id")
  // std
  note               String?   @db.Text
  createdBy           Int?      @map("created_by")
  createdAt           DateTime  @default(now()) @map("created_at")

  // Relations (see schema.prisma for full relation definitions)
  company             Company          @relation(fields: [companyId], references: [id])
  cashbox             Cashbox          @relation(fields: [cashboxId], references: [id])
  customer            Customer?        @relation(fields: [customerId], references: [id])
  supplier            Supplier?        @relation(fields: [supplierId], references: [id])
  payment             Payment?         @relation(fields: [paymentId], references: [id])
  receipt             ReceiptVoucher?  @relation(fields: [receiptId], references: [id])
  paymentVoucher      PaymentVoucher?  @relation(fields: [paymentVoucherId], references: [id])
  cashTransfer        CashTransfer?    @relation(fields: [cashTransferId], references: [id])
  creator             User?            @relation("CashTxCreator", fields: [createdBy], references: [id])
  reversalOf          CashTransaction? @relation("CashTxReversal", fields: [reversalOfId], references: [id])
  reversedBy         CashTransaction[] @relation("CashTxReversal")

  @@unique([companyId, idempotencyKey])
  @@index([companyId, createdAt])
  @@index([cashboxId, createdAt])
  @@index([transactionType])
  @@index([transactionNumber])
  @@index([refType, refId])
  @@map("cash_transactions")
}

enum TransactionDirection { IN | OUT }
enum TransactionCategory {
  COLLECTION | SUPPLIER_PAYMENT | EXPENSE | OPENING | REFUND | OTHER
  | CUSTOMER_PAYMENT | CASH_TRANSFER_IN | CASH_TRANSFER_OUT
  | BANK_DEPOSIT | BANK_WITHDRAWAL | ADJUSTMENT_IN | ADJUSTMENT_OUT | REVERSAL
}
enum TransactionType {
  OPENING_BALANCE | RECEIPT | PAYMENT | EXPENSE | CUSTOMER_PAYMENT
  | SUPPLIER_PAYMENT | CASH_TRANSFER_IN | CASH_TRANSFER_OUT
  | BANK_DEPOSIT | BANK_WITHDRAWAL | ADJUSTMENT_IN | ADJUSTMENT_OUT | REFUND | REVERSAL
}
```

---

### 1.3 نموذج Payment (موحّد)

```prisma
model Payment {
  id                Int       @id @default(autoincrement())
  uuid              String    @unique @default(uuid())
  companyId         Int       @map("company_id")
  branchId          Int       @map("branch_id")
  number            String    // UPAY-2026-000001 (داخلي)
  paymentType       PaymentType @map("payment_type")
  partyType         PartyType  @map("party_type")
  customerId        Int?      @map("customer_id")
  supplierId        Int?      @map("supplier_id")
  cashboxId         Int?      @map("cash_box_id") // null للمصروف المحمّل
  totalAmount       Decimal   @map("total_amount") @db.Decimal(18,4)
  currency          String    @default("IQD") @db.VarChar(3)
  exchangeRate      Decimal?  @map("exchange_rate") @db.Decimal(18,6)
  paymentMethod     PaymentMethod @map("payment_method")
  paymentDate       DateTime  @default(now()) @map("payment_date")
  status            PaymentStatus @default(POSTED)
  idempotencyKey    String?   @map("idempotency_key")
  // تفصيل الدفع المختلط
  cashAmount        Decimal?  @map("cash_amount") @db.Decimal(18,4)
  cardAmount        Decimal?  @map("card_amount") @db.Decimal(18,4)
  bankAmount        Decimal?  @map("bank_amount") @db.Decimal(18,4)
  onAccountAmount   Decimal?  @map("on_account_amount") @db.Decimal(18,4)
  // تفاصيل بنكية
  referenceNumber   String?   @map("reference_number") @db.VarChar(80)
  bankName          String?   @map("bank_name") @db.VarChar(80)
  bankAccount       String?   @map("bank_account") @db.VarChar(80)
  cardLast4         String?   @map("card_last_4") @db.VarChar(4)
  // Metadata
  description       String?   @db.Text
  notes             String?   @db.Text
  cancelReason      String?   @map("cancel_reason") @db.Text
  cancelledById     Int?      @map("cancelled_by_id")
  cancelledAt       DateTime? @map("cancelled_at")
  createdById       Int       @map("created_by_id")
  approvedById      Int?      @map("approved_by_id")
  createdAt         DateTime  @default(now()) @map("created_at")
  updatedAt         DateTime  @default(now()) @updatedAt @map("updated_at")
  deletedAt         DateTime? @map("deleted_at")

  @@unique([companyId, number, deletedAt])
  @@unique([companyId, idempotencyKey])
  @@index([companyId, paymentDate])
  @@index([customerId, paymentDate])
  @@index([supplierId, paymentDate])
  @@index([cashboxId])
  @@map("payments")
}

enum PaymentType { CUSTOMER_PAYMENT | SUPPLIER_PAYMENT | EXPENSE_PAYMENT | ADVANCE_PAYMENT }
enum PartyType { CUSTOMER | SUPPLIER | OTHER }
enum PaymentMethod { CASH | CARD | BANK_TRANSFER | ELECTRONIC | MIXED | ON_ACCOUNT }
enum PaymentStatus { DRAFT | POSTED | CANCELLED }
```

---

### 1.4 نموذج PaymentAllocation

```prisma
model PaymentAllocation {
  id              Int      @id @default(autoincrement())
  uuid            String   @unique @default(uuid())
  companyId       Int      @map("company_id")
  paymentId       Int      @map("payment_id")
  invoiceType     AllocationInvoiceType @map("invoice_type")
  salesInvoiceId     Int?  @map("sales_invoice_id")
  purchaseInvoiceId  Int?  @map("purchase_invoice_id")
  allocatedAmount Decimal @map("allocated_amount") @db.Decimal(18,4)
  // Snapshot (Phase 50 — لا تتغير مع تعديل الفاتورة)
  invoiceNumber   String?  @map("invoice_number") @db.VarChar(40)
  invoiceTotal    Decimal? @map("invoice_total") @db.Decimal(18,4)
  previouslyPaid  Decimal? @map("previously_paid") @db.Decimal(18,4)
  remainingAfter Decimal? @map("remaining_after") @db.Decimal(18,4)
  createdAt       DateTime @default(now()) @map("created_at")

  @@unique([paymentId, invoiceType, salesInvoiceId, purchaseInvoiceId])
  @@index([salesInvoiceId])
  @@index([purchaseInvoiceId])
  @@map("payment_allocations")
}

enum AllocationInvoiceType { SALES_INVOICE | PURCHASE_INVOICE }
```

---

### 1.5 نموذج ReceiptVoucher (وصل القبض)

```prisma
model ReceiptVoucher {
  id                Int       @id @default(autoincrement())
  uuid              String    @unique @default(uuid())
  companyId         Int       @map("company_id")
  branchId          Int       @map("branch_id")
  number            String    // RCPT-2026-000001
  receiptDate       DateTime  @default(now()) @map("receipt_date")
  cashboxId         Int       @map("cashbox_id")
  recipientName     String    @map("recipient_name") @db.VarChar(120)
  customerId        Int?      @map("customer_id")
  supplierId        Int?      @map("supplier_id")
  amount            Decimal   @db.Decimal(18,4)
  currency          String    @default("IQD") @db.VarChar(3)
  exchangeRate      Decimal?  @map("exchange_rate") @db.Decimal(18,6)
  amountInCashbox   Decimal?  @map("amount_in_cashbox") @db.Decimal(18,4)
  paymentMethod     PaymentMethod @map("payment_method")
  paymentId         Int?      @unique @map("payment_id")
  referenceNumber   String?   @map("reference_number") @db.VarChar(80)
  bankName          String?   @map("bank_name") @db.VarChar(80)
  bankAccount       String?   @map("bank_account") @db.VarChar(80)
  // Snapshot
  invoiceSnapshot   String?   @map("invoice_snapshot") @db.Text // JSON
  grandTotalSnapshot   Decimal? @map("grand_total_snapshot") @db.Decimal(18,4)
  previouslyPaidSnapshot Decimal? @map("previously_paid_snapshot") @db.Decimal(18,4)
  currentPaymentSnapshot  Decimal? @map("current_payment_snapshot") @db.Decimal(18,4)
  remainingSnapshot      Decimal? @map("remaining_snapshot") @db.Decimal(18,4)
  // State
  status            ReceiptStatus @default(POSTED)
  cancelReason      String?   @map("cancel_reason") @db.Text
  cancelledById     Int?      @map("cancelled_by_id")
  cancelledAt       DateTime? @map("cancelled_at")
  // QR
  verifyToken       String    @unique @default(uuid())
  qrData            String?   @map("qr_data") @db.Text
  printCount        Int       @default(0) @map("print_count")
  lastPrintedAt     DateTime? @map("last_printed_at")
  lastPrintedById   Int?      @map("last_printed_by_id")
  // Idempotency
  idempotencyKey    String?   @map("idempotency_key")
  // Metadata
  description       String?   @db.Text
  notes             String?   @db.Text
  receivedBy        String?   @map("received_by") @db.VarChar(120)
  createdById       Int       @map("created_by_id")
  approvedById      Int?      @map("approved_by_id")
  createdAt         DateTime  @default(now()) @map("created_at")
  updatedAt         DateTime  @default(now()) @updatedAt @map("updated_at")
  deletedAt         DateTime? @map("deleted_at")

  @@unique([companyId, number, deletedAt])
  @@unique([companyId, idempotencyKey])
  @@index([cashboxId, receiptDate])
  @@index([customerId, receiptDate])
  @@index([status])
  @@map("receipt_vouchers")
}

enum ReceiptStatus { DRAFT | POSTED | CANCELLED }
```

**آلة حالة الوصل:**
```
DRAFT ──(post)──→ POSTED ──(cancel + reason)──→ CANCELLED
  │                    │
  └──(cancel)──→ CANCELLED   ──(reverse cascade)──→ REVERSED
```
- `DRAFT → POSTED`: فقط المُنشئ أو الموافق
- `POSTED → CANCELLED`: يتطلب سبب + عكس كامل (reverse transaction + customer.balance ↑ + invoice.paidAmount ↓)
- `DRAFT → CANCELLED`: مباشر، لا عكس
- `CANCELLED` لا يُعاد → إنشاء وصل جديد

---

### 1.6 نموذج PaymentVoucher (وصل الصرف)

نفس بنية ReceiptVoucher مع الاختلافات التالية:
- `number`: `PAY-2026-000001`
- `beneficiaryName` بدل `recipientName`
- `reason`: `PAYMENT_TO_SUPPLIER | EXPENSE | ADVANCE | DIRECT_PURCHASE | REFUND | OPERATING_EXPENSE | BANK_TRANSFER | OTHER`
- `expenseCategory` + `expenseCategoryId`
- `purchaseInvoiceId`
- `chargeToCustomerId` (للمصروف المحمّل على العميل)
- `cashboxId` nullable (للمصروف المحمّل — لا خصم من الصندوق)
- `paidTo` (اسم المستلم)

---

### 1.7 نموذج CashTransfer

```prisma
model CashTransfer {
  id                Int       @id @default(autoincrement())
  uuid              String    @unique @default(uuid())
  companyId         Int       @map("company_id")
  branchId          Int       @map("branch_id")
  number            String    // CASH-TRF-2026-000001
  fromCashboxId     Int       @map("from_cashbox_id")
  toCashboxId       Int       @map("to_cashbox_id")
  amount            Decimal   @db.Decimal(18,4)
  currency          String    @default("IQD") @db.VarChar(3)
  fromCurrency      String?   @map("from_currency") @db.VarChar(3)
  toCurrency        String?   @map("to_currency") @db.VarChar(3)
  exchangeRate      Decimal?  @map("exchange_rate") @db.Decimal(18,6)
  sourceAmount      Decimal?  @map("source_amount") @db.Decimal(18,4)
  targetAmount      Decimal?  @map("target_amount") @db.Decimal(18,4)
  transferDate      DateTime  @default(now()) @map("transfer_date")
  status            TransferStatus @default(POSTED)
  isBankDeposit     Boolean   @default(false) @map("is_bank_deposit")
  isBankWithdrawal  Boolean   @default(false) @map("is_bank_withdrawal")
  bankDepositRef   String?   @map("bank_deposit_ref") @db.VarChar(80)
  bankWithdrawalRef String?   @map("bank_withdrawal_ref") @db.VarChar(80)
  cancelReason      String?   @map("cancel_reason") @db.Text
  cancelledById     Int?      @map("cancelled_by_id")
  cancelledAt       DateTime? @map("cancelled_at")
  idempotencyKey    String?   @map("idempotency_key")
  description       String?   @db.Text
  notes             String?   @db.Text
  createdById       Int       @map("created_by_id")
  approvedById      Int?      @map("approved_by_id")
  createdAt         DateTime  @default(now()) @map("created_at")
  updatedAt         DateTime  @default(now()) @updatedAt @map("updated_at")
  deletedAt         DateTime? @map("deleted_at")

  @@unique([companyId, number, deletedAt])
  @@unique([companyId, idempotencyKey])
  @@index([fromCashboxId, transferDate])
  @@index([toCashboxId, transferDate])
  @@index([status])
  @@map("cash_transfers")
}

enum TransferStatus { DRAFT | POSTED | CANCELLED }
```

**آلة حالة التحويل:**
```
DRAFT ──(post: 2 atomic tx)──→ POSTED ──(cancel: reverse both)──→ CANCELLED
```
- العكس ذري: حركتان عكستان (IN للأصل + OUT للهدف)
- رصيد المصدر يجب أن يكفي
- لا يمكن إلغاء تحويل POSTED إذا كان ضمن فترة مغلقة

---

### 1.8 نموذج CashboxClosing

```prisma
model CashboxClosing {
  id                Int       @id @default(autoincrement())
  uuid              String    @unique @default(uuid())
  companyId         Int       @map("company_id")
  branchId          Int       @map("branch_id")
  cashboxId         Int       @map("cashbox_id")
  number            String    // CLOS-2026-000001
  closingDate       DateTime  @default(now()) @map("closing_date")
  // الرصيد الدفتري
  openingBalance    Decimal   @map("opening_balance") @db.Decimal(18,4)
  totalReceipts     Decimal   @default(0) @map("total_receipts") @db.Decimal(18,4)
  totalPayments     Decimal   @default(0) @map("total_payments") @db.Decimal(18,4)
  transfersIn       Decimal   @default(0) @map("transfers_in") @db.Decimal(18,4)
  transfersOut      Decimal   @default(0) @map("transfers_out") @db.Decimal(18,4)
  bookBalance       Decimal   @map("book_balance") @db.Decimal(18,4)
  // النقد الفعلي + الفرق
  actualCash        Decimal   @map("actual_cash") @db.Decimal(18,4)
  difference        Decimal   @default(0) @db.Decimal(18,4)
  differenceReason  String?   @map("difference_reason") @db.Text
  differenceCategory String?  @map("difference_category") // THEFT | ERROR | MIS_COUNTING | SYSTEM_ERROR | OTHER
  // الحالة
  status            ClosingStatus @default(DRAFT)
  closedById        Int?      @map("closed_by_id")
  closedAt          DateTime? @map("closed_at")
  reopenedById      Int?      @map("reopened_by_id")
  reopenedAt        DateTime? @map("reopened_at")
  reopenReason      String?   @map("reopen_reason") @db.Text
  denominationTotal Decimal?  @map("denomination_total") @db.Decimal(18,4)
  notes             String?   @db.Text
  createdById       Int       @map("created_by_id")
  createdAt         DateTime  @default(now()) @map("created_at")
  updatedAt         DateTime  @default(now()) @updatedAt @map("updated_at")
  deletedAt         DateTime? @map("deleted_at")

  @@unique([companyId, cashboxId, closingDate])
  @@index([cashboxId, closingDate])
  @@index([status])
  @@map("cashbox_closings")
}

enum ClosingStatus { DRAFT | CLOSED | REOPENED }
```

---

### 1.9 نموذج CashboxDenominationCount

```prisma
model CashboxDenominationCount {
  id                Int       @id @default(autoincrement())
  companyId         Int       @map("company_id")
  cashboxId         Int       @map("cashbox_id")
  cashboxClosingId  Int?      @map("cashbox_closing_id")
  currency          String    @default("IQD") @db.VarChar(3)
  denomination      Decimal   @db.Decimal(18,4) // 25000 | 10000 | 5000 | 1000 | 500 | 250
  count             Int
  total             Decimal   @db.Decimal(18,4) // denomination × count
  countedAt         DateTime  @default(now()) @map("counted_at")
  countedById       Int       @map("counted_by_id")

  @@unique([cashboxClosingId, currency, denomination])
  @@index([cashboxId])
  @@map("cashbox_denomination_counts")
}
```

---

### 1.10 نموذج BankAccount

```prisma
model BankAccount {
  id              Int       @id @default(autoincrement())
  uuid            String    @unique @default(uuid())
  companyId       Int       @map("company_id")
  branchId        Int?      @map("branch_id")
  code            String    // BNK-RASFIDAIN
  name            String    @db.VarChar(120)
  bankName        String    @map("bank_name") @db.VarChar(120)
  iban            String?   @db.VarChar(60)
  accountNumber   String    @map("account_number") @db.VarChar(40)
  currency        String    @default("IQD") @db.VarChar(3)
  balance         Decimal    @default(0) @db.Decimal(18,4)
  status          String    @default("ACTIVE") // ACTIVE | SUSPENDED | CLOSED
  description     String?   @db.Text
  createdAt       DateTime  @default(now()) @map("created_at")
  updatedAt       DateTime  @default(now()) @updatedAt @map("updated_at")
  createdBy       Int?
  updatedBy       Int?
  deletedAt       DateTime? @map("deleted_at")

  @@unique([companyId, code, deletedAt])
  @@index([companyId, status])
  @@map("bank_accounts")
}
```

---

### 1.11 نموذج Check (الشيكات)

```prisma
model Check {
  id              Int       @id @default(autoincrement())
  uuid            String    @unique @default(uuid())
  companyId       Int       @map("company_id")
  branchId        Int?      @map("branch_id")
  number          String    // CHK-2026-IN-000001 / CHK-2026-OUT-000001
  checkType       String    @map("check_type") // RECEIVED | ISSUED
  checkNumber     String    @map("check_number") @db.VarChar(40) // الرقم الأصلي
  direction       String    // IN | OUT
  issuingBankId   Int?      @map("issuing_bank_id")
  receivingBankId Int?      @map("receiving_bank_id")
  customerId      Int?      @map("customer_id")
  supplierId      Int?      @map("supplier_id")
  beneficiaryName String?   @map("beneficiary_name") @db.VarChar(120)
  amount          Decimal   @db.Decimal(18,4)
  currency        String    @default("IQD") @db.VarChar(3)
  issueDate       DateTime  @default(now()) @map("issue_date")
  dueDate         DateTime  @map("due_date")
  clearedAt       DateTime? @map("cleared_at")
  paymentVoucherId Int?      @map("payment_voucher_id")
  receiptVoucherId Int?     @map("receipt_voucher_id")
  status          CheckStatus @default(PENDING)
  bounceReason    String?   @map("bounce_reason") @db.Text
  notes           String?   @db.Text
  createdById     Int       @map("created_by_id")
  createdAt       DateTime  @default(now()) @map("created_at")
  updatedAt       DateTime  @default(now()) @updatedAt @map("updated_at")
  deletedAt       DateTime? @map("deleted_at")

  @@unique([companyId, number, deletedAt])
  @@index([companyId, dueDate])
  @@index([status])
  @@index([checkType])
  @@map("checks")
}

enum CheckStatus { PENDING | DEPOSITED | CLEARED | BOUNCED | CANCELLED }
```

---

### 1.12 نموذج ExpenseCategory

```prisma
model ExpenseCategory {
  id              Int       @id @default(autoincrement())
  uuid            String    @unique @default(uuid())
  companyId       Int       @map("company_id")
  code            String    // SALARY, RENT, UTILITIES, MARKETING
  name            String    @db.VarChar(120)
  nameEn          String?   @map("name_en") @db.VarChar(120)
  description     String?   @db.Text
  monthlyBudget   Decimal?  @map("monthly_budget") @db.Decimal(18,4)
  type            String    @default("EXPENSE") // EXPENSE | INCOME
  isActive        Boolean   @default(true) @map("is_active")
  createdAt       DateTime  @default(now()) @map("created_at")
  updatedAt       DateTime  @default(now()) @updatedAt @map("updated_at")
  createdBy       Int?
  updatedBy       Int?
  deletedAt       DateTime? @map("deleted_at")

  @@unique([companyId, code, deletedAt])
  @@index([companyId, type])
  @@map("expense_categories")
}
```

---

## 2. آلة حالة كاملة للوصل (Receipt State Machine)

```
                    ┌─────────┐
                    │  DRAFT  │
                    └────┬────┘
                         │ post()
                         │ → إنشاء Payment
                         │ → إنشاء PaymentAllocation[]
                         │ → تحديث invoice.paidAmount
                         │ → تحديث customer.balance
                         │ → إنشاء CashTransaction (IN)
                         │ → Audit Log
                         ▼
                    ┌─────────┐
        ┌───────────│ POSTED  │───────────┐
        │           └────┬────┘            │
        │ cancel(reason) │                 │ reprint
        │ → reverse      │                 │ → printCount++
        │   CashTx       │                 │ → lastPrintedAt
        │ → restore      │                 │ → لا وصل جديد
        │   customer     │                 │
        │   balance       │                 │
        │ → restore      │                 │
        │   invoice       │                 │
        │   paidAmount    │                 │
        │ → mark         │                 │
        │   Payment       │                 │
        │   CANCELLED     │                 │
        │ → Audit         │                 │
        ▼                ▼                 ▼
  ┌───────────┐   ┌───────────┐   ┌───────────┐
  │ CANCELLED │   │ CANCELLED │   │  POSTED   │
  │ (from     │   │ (from     │   │ (still)   │
  │  DRAFT)   │   │  POSTED)  │   │           │
  └───────────┘   └───────────┘   └───────────┘
```

---

## 3. كتالوج أكواد الأخطاء الكامل

| الكود | HTTP | الرسالة (عربي) | الفئة |
|---|---|---|---|
| `AUTH_001` | 401 | لم يتم إرسال رمز الدخول | مصادقة |
| `AUTH_002` | 401 | رمز الدخول غير صالح أو منتهي | مصادقة |
| `AUTH_003` | 401 | بيانات الدخول غير صحيحة | مصادقة |
| `AUTH_004` | 423 | الحساب مقفول مؤقتًا | مصادقة |
| `PERM_001` | 403 | ليست لديك الصلاحية | صلاحيات |
| `SCOPE_001` | 403 | الكيان خارج نطاقك | نطاق |
| `SCOPE_002` | 403 | لا تملك نفاذًا للمستودع | نطاق |
| `SCOPE_003` | 403 | خرق نطاق الفرع | نطاق |
| `SCOPE_004` | 403 | خرق نطاق الشركة | نطاق |
| `SCOPE_005` | 403 | لا تملك نفاذًا للفرع | نطاق |
| `SCOPE_006` | 403 | مرجع عابر للشركات | نطاق |
| `VAL_001` | 422 | بيانات الطلب غير صالحة | تحقق |
| `VAL_002` | 409 | قيمة مكررة | تحقق |
| `VAL_003` | 404 | السجل غير موجود | تحقق |
| `VAL_004` | 409 | لا يمكن تنفيذ العملية على سجل مقفل | تحقق |
| `CASHBOX_001` | 404 | الصندوق غير موجود | صناديق |
| `CASHBOX_002` | 403 | لا توجد صلاحية للوصول للصندوق | صناديق |
| `CASHBOX_003` | 409 | الرصيد غير كافٍ | صناديق |
| `CASHBOX_004` | 409 | الصندوق مغلق | صناديق |
| `CASHBOX_005` | 409 | الصندوق معلّق | صناديق |
| `CASHBOX_006` | 409 | عملات غير متوافقة | صناديق |
| `RECEIPT_001` | 409 | المبلغ يتجاوز المتبقي | وصولات قبض |
| `RECEIPT_002` | 409 | الوصل مرحّل — استخدم الإلغاء | وصولات قبض |
| `RECEIPT_003` | 409 | الوصل ملغى مسبقًا | وصولات قبض |
| `PV_001` | 409 | المبلغ يتجاوز المستحق للمورد | وصولات صرف |
| `PV_002` | 409 | الوصل مرحّل — استخدم الإلغاء | وصولات صرف |
| `PV_003` | 409 | الوصل ملغى مسبقًا | وصولات صرف |
| `CASH_001` | 422 | طريقة الدفع نقدي تتطلب صندوق | نقد |
| `CASH_002` | 422 | العملة غير متوافقة | نقد |
| `PAYMENT_001` | 409 | الدفعة تتجاوز المبلغ المستحق | دفعات |
| `PAYMENT_002` | 409 | الدفعة مكررة | دفعات |
| `PAYMENT_003` | 422 | التخصيص يتجاوز المبلغ الإجمالي | دفعات |
| `CASH_TRF_001` | 409 | تحويل مكرر | تحويلات |
| `CASH_TRF_002` | 422 | سعر صرف مطلوب | تحويلات |
| `CLOSING_001` | 409 | إغلاق سابق لنفس اليوم | إغلاق |
| `CLOSING_002` | 409 | الإغلاق مرحّل | إغلاق |
| `FINANCE_001` | 500 | فشل إنشاء الحركة المالية | خادم |
| `RATE_001` | 429 | عدد طلبات كبير | معدل |
| `SRV_001` | 500 | خطأ داخلي غير متوقع | خادم |
| `SRV_002` | 503 | الخدمة غير متاحة | خادم |

---

## 4. كتالوج نقاط API الكامل

| # | Method | Path | Permission | الوصف |
|---|---|---|---|---|
| 1 | GET | `/api/v1/finance/cashboxes` | `finance.cashboxes.view` | قائمة صناديق + KPIs اليوم |
| 2 | POST | `/api/v1/finance/cashboxes` | `finance.cashboxes.create` | إنشاء صندوق + OPENING_BALANCE tx |
| 3 | GET | `/api/v1/finance/receipts` | `finance.receipts.view` | قائمة وصولات القبض |
| 4 | POST | `/api/v1/finance/receipts` | `finance.receipts.create` | إنشاء وصل قبض (atomic) |
| 5 | GET | `/api/v1/finance/receipts/[id]` | `finance.receipts.view` | تفاصيل الوصل |
| 6 | POST | `/api/v1/finance/receipts/[id]/cancel` | `finance.receipts.cancel` | إلغاء + عكس ذري |
| 7 | GET | `/api/v1/finance/payment-vouchers` | `finance.payment_vouchers.view` | قائمة وصولات الصرف |
| 8 | POST | `/api/v1/finance/payment-vouchers` | `finance.payment_vouchers.create` | إنشاء وصل صرف |
| 9 | GET | `/api/v1/finance/payment-vouchers/[id]` | `finance.payment_vouchers.view` | تفاصيل الوصل |
| 10 | POST | `/api/v1/finance/payment-vouchers/[id]/cancel` | `finance.payment_vouchers.cancel` | إلغاء + عكس |
| 11 | GET | `/api/v1/finance/cash-transfers` | `finance.cash_transfers.view` | قائمة تحويلات |
| 12 | POST | `/api/v1/finance/cash-transfers` | `finance.cash_transfers.create` | إنشاء تحويل (atomic 2-tx) |
| 13 | POST | `/api/v1/finance/cash-transfers/[id]/cancel` | `finance.cash_transfers.cancel` | عكس التحويل |
| 14 | GET | `/api/v1/finance/cash-closings` | `finance.cash_closings.view` | قائمة إغلاقات |
| 15 | POST | `/api/v1/finance/cash-closings` | `finance.cash_closings.create` | إغلاق يومي + جرد |
| 16 | GET | `/api/v1/finance/cash-closings/[id]` | `finance.cash_closings.view` | تفاصيل الإغلاق |
| 17 | POST | `/api/v1/finance/cash-closings/[id]/reopen` | `finance.cash_closings.edit` | إعادة فتح |
| 18 | GET | `/api/v1/finance/statements/customer/[id]` | `finance.statements.view` | كشف حساب عميل |
| 19 | GET | `/api/v1/finance/statements/supplier/[id]` | `finance.statements.view` | كشف حساب مورد |
| 20 | GET | `/api/v1/finance/aging?type=customers` | `finance.aging.view` | أعمار ديون العملاء |
| 21 | GET | `/api/v1/finance/aging?type=suppliers` | `finance.aging.view` | أعمار ديون الموردين |
| 22 | GET | `/api/v1/finance/customers/[id]/outstanding` | `finance.receipts.view` | فواتير العميل المستحقة |
| 23 | GET | `/api/v1/finance/customers/[id]/payment-summary` | `finance.receipts.view` | ملخص دفعات العميل |
| 24 | POST | `/api/v1/finance/quick-receipt` | `finance.receipts.create` | وصل قبض سريع + FIFO |
| 25 | POST | `/api/v1/finance/charged-expense` | `finance.payment_vouchers.create` | مصروف محمّل على العميل |
| 26 | GET | `/api/v1/finance/expense-categories` | `finance.expenses.view` | بنود المصروفات |
| 27 | POST | `/api/v1/finance/expense-categories` | `finance.expenses.create` | إنشاء بند |
| 28 | GET | `/api/v1/finance/bank-accounts` | `finance.cashboxes.view` | الحسابات البنكية |
| 29 | POST | `/api/v1/finance/bank-accounts` | `finance.cashboxes.create` | إنشاء حساب بنكي |
| 30 | GET | `/api/v1/finance/checks` | `finance.cash_transfers.view` | الشيكات |
| 31 | POST | `/api/v1/finance/checks/[id]/clear` | `finance.receipts.create` | تحصيل شيك |
| 32 | POST | `/api/v1/finance/checks/[id]/bounce` | `finance.cash_transfers.cancel` | ارتداد شيك |
| 33 | POST | `/api/v1/finance/bank-deposits` | `finance.cash_transfers.create` | إيداع بنكي |
| 34 | POST | `/api/v1/finance/bank-withdrawals` | `finance.cash_transfers.create` | سحب بنكي |
| 35 | GET | `/api/v1/finance/cashier-shifts` | `finance.cashboxes.view` | ورديات الكاشير |
| 36 | POST | `/api/v1/finance/cashier-shifts` | `finance.receipts.create` | clock-in |
| 37 | POST | `/api/v1/finance/cashier-shifts/[id]/clock-out` | `finance.receipts.create` | clock-out + إحصائيات |
| 38 | GET | `/api/v1/finance/recurring-expenses` | `finance.expenses.view` | المصروفات المتكررة |
| 39 | POST | `/api/v1/finance/recurring-expenses` | `finance.expenses.create` | إنشاء مصروف متكرر |
| 40 | GET | `/api/v1/finance/accounts` | `finance.statements.view` | دليل الحسابات |
| 41 | POST | `/api/v1/finance/accounts` | `system.settings.edit` | تهيئة الحسابات القياسية |
| 42 | GET | `/api/v1/finance/journal-entries` | `finance.statements.view` | قيود اليومية |
| 43 | POST | `/api/v1/finance/journal-entries` | `finance.statements.view` | إنشاء قيد يدوي متوازن |
| 44 | GET | `/api/v1/finance/budgets` | `finance.statements.view` | الميزانيات |
| 45 | POST | `/api/v1/finance/budgets` | `system.settings.edit` | إنشاء/تحديث ميزانية |
| 46 | GET | `/api/v1/finance/financial-periods` | `finance.statements.view` | الفترات المالية |
| 47 | POST | `/api/v1/finance/financial-periods` | `system.settings.edit` | إنشاء فترة |
| 48 | POST | `/api/v1/finance/financial-periods/[id]/close` | `system.settings.edit` | قفل فترة |
| 49 | POST | `/api/v1/finance/financial-periods/[id]/reopen` | `system.settings.edit` | إعادة فتح فترة |
| 50 | GET | `/api/v1/finance/reports/trial-balance` | `finance.statements.view` | ميزان المراجعة |
| 51 | GET | `/api/v1/finance/reports/balance-sheet` | `finance.statements.view` | الميزانية العمومية |
| 52 | GET | `/api/v1/finance/reports/income-statement` | `finance.statements.view` | قائمة الدخل |
| 53 | GET | `/api/v1/finance/reports/cashbox-movement` | `finance.statements.view` | حركة الصندوق |
| 54 | GET | `/api/v1/finance/reports/daily-receipts` | `finance.statements.view` | المقبوضات اليومية |
| 55 | GET | `/api/v1/finance/reports/daily-payments` | `finance.statements.view` | المدفوعات اليومية |
| 56 | GET | `/api/v1/finance/reports/expense-by-category` | `finance.statements.view` | تحليل المصروفات |
| 57 | GET | `/api/v1/finance/reports/collection-rate` | `finance.statements.view` | نسبة التحصيل |
| 58 | GET | `/api/v1/finance/reports/cashier-shift` | `finance.statements.view` | تقرير وردية الكاشير |

---

## 5. مصفوفة الدقة العشرية (Decimal Precision Matrix)

| الفئة | الحقل | الدقة (precision) | المقياس (scale) | مكتبة JS | أمثلة |
|---|---|---|---|---|---|
| **Money** | amount, balance, totalAmount, paidAmount, grandTotal, etc. | 18 | 4 | decimal.js | 1,234,567.8901 |
| **Quantity** | qty, packageQty, looseQty, count | 18 | 6 | decimal.js | 55.123456 |
| **Exchange Rate** | exchangeRate | 18 | 6 | decimal.js | 1300.123456 |
| **Percentage** | discountPct, taxRatePct, commissionPct | 9 | 4 | decimal.js | 15.5000 |
| **GPS** | lat, lng | 10 | 7 | Float (built-in) | 33.3152000 |

**قواعد التقريب:** `ROUND_HALF_UP` (تقريب النصف للأعلى) — الموافق للمعايير المحاسبية العراقية.

**قواعد المقارنة:** ممنوع `===` على Decimal. استخدم `.equals()`, `.gt()`, `.lt()`, `.isPositive()`, `.isZero()`.

**التسلسل لـ JSON:** حوّل Decimal إلى number عبر `num()` فقط عند حدود JSON (الردود). داخليًا، استخدم Decimal دائمًا.

---

## 6. خطة ترحيل البيانات (Data Migration Plan)

### المرحلة 1: نسخة احتياطية
```bash
cp db/custom.db db/backups/pre-migration-$(date +%Y%m%d-%H%M%S).db
```

### المرحلة 2: ترحيل المخطط
```bash
npx prisma db push --accept-data-loss
# أو: npx prisma migrate deploy (للإنتاج)
```

### المرحلة 3: تهيئة البيانات الأساسية
```bash
npx tsx prisma/seed.ts  # ينشئ: الأدوار + الصلاحيات + الحسابات القياسية + المثال التجريبي
```

### المرحلة 4: ترحيل البيانات الموجودة
للسجلات الموجودة في `cash_transactions` و `cashboxes`:
- الحقول الجديدة (transactionType, balanceBefore, idempotencyKey, etc.) تُترك null
- الحقول الموجودة (amount, balanceAfter, direction, category) تبقى كما هي
- لا حاجة لترحيل بيانات — الإضافات اختيارية

### المرحلة 5: التحقق
```bash
# تحقق من سلامة الأرصدة
npx tsx scripts/verify-balances.ts

# تحقق من عدم وجود حركات مكررة
npx tsx scripts/check-duplicates.ts

# تحقق من العزل متعدد المستأجرين
npx tsx scripts/verify-strict-company-isolation.mjs
```

---

## 7. قواعد التزامن (Concurrency Rules)

### القفل المتفائل (Optimistic Locking)
كل نموذج يحتوي على حقل `version Int @default(0)`. عند التحديث:
```typescript
const result = await db.cashbox.update({
  where: { id: cashboxId, version: currentVersion },
  data: { ...updates, version: { increment: 1 } },
});
if (!result) throw new ApiError("CONFLICT_001", "تم تعديل السجل من قبل مستخدم آخر");
```

### القفل المتشائم (Pessimistic Locking)
للعمليات الحرجة (تحديث رصيد الصندوق):
```typescript
await db.$transaction(async (tx) => {
  // Prisma + SQLite: serialization garantueed via serializable isolation
  // PostgreSQL: SELECT ... FOR UPDATE via raw query
  const box = await tx.cashbox.findFirst({ where: { id } });
  const newBalance = dec(box.balance).plus(amount);
  await tx.cashTransaction.create({ data: { ..., balanceBefore: box.balance, balanceAfter: newBalance } });
  await tx.cashbox.update({ where: { id }, data: { balance: newBalance } });
});
```

---

## 8. مواصفات الـ Idempotency

### التوليد
```typescript
const idempotencyKey = req.headers.get("Idempotency-Key") ?? crypto.randomUUID();
```

### التخزين
حقل `idempotencyKey String?` على: Payment, ReceiptVoucher, PaymentVoucher, CashTransfer.
قيد فريد: `@@unique([companyId, idempotencyKey])`.

### السلوك عند التكرار
```typescript
const existing = await db.receiptVoucher.findFirst({ where: { companyId, idempotencyKey } });
if (existing) {
  return ok({ id: existing.id, number: existing.number, status: existing.status, idempotent: true, message: "SYNC_001" });
}
```

### الانتهاء
لا انتهاء — المفتاح يبقى للأبد (للسجلات المالية). الحذف الناعم فقط.

---

## 9. خطة النسخ الاحتياطي والاسترجاع (Backup & DR)

### النسخ الاحتياطي اليومي
```bash
# cron: 0 3 * * * 
systemctl stop maydanerp
cp /opt/maydanerp/db/custom.db /opt/maydanerp/backups/$(date +%Y%m%d).db
systemctl start maydanerp
```

### الاحتفاظ
- يومي: آخر 30 نسخة
- أسبوعي: آخر 12 نسخة
- شهري: آخر 12 نسخة
- سنوي: دائم

### الاسترجاع
```bash
systemctl stop maydanerp
cp /opt/maydanerp/backups/2026-09-23.db /opt/maydanerp/db/custom.db
systemctl start maydanerp
```

### RTO/RPO
- **RTO** (Recovery Time Objective): < 5 دقائق
- **RPO** (Recovery Point Objective): < 24 ساعة (نسخة يومية)

---

## 10. مواصفات المراقبة (Observability)

### المقاييس (Metrics)
- `http_requests_total{route,method,status}` — عدّاد Prometheus
- `http_request_duration_seconds{route}` — مدرّاس زمني
- `db_query_duration_seconds{table,operation}` — زمن استعلامات DB
- `cashbox_balance{cashbox_id,currency}` — مقياس رصيد الصندوق
- `active_sessions_total` — جلسات نشطة

### التسجيل المنظّم (Structured Logging)
```json
{
  "level": "info",
  "timestamp": "2026-09-23T10:30:00Z",
  "requestId": "req-abc123",
  "userId": 1,
  "companyId": 1,
  "action": "CREATE_RECEIPT",
  "entityId": 42,
  "amount": 50000,
  "currency": "IQD",
  "ip": "192.168.1.1",
  "userAgent": "Mozilla/5.0...",
  "durationMs": 125
}
```

### التنبيهات (Alerts)
- معدل أخطاء > 5% → تنبيه فوري
- زمن الاستجابة P95 > 2 ثانية → تنبيه
- رصيد صندوق سالب → تنبيه حرج
- فشل التزامن (DB) → تنبيه حرج
- محاولة تجاوز صلاحية → تنبيه أمني

---

## 11. مواصفات الأمان المتقدمة

### قفل الحساب
- 5 محاولات فاشلة → قفل 15 دقيقة
- عدّاد `failedLoginCount` + `lockedUntil`
- تدقيق `LOGIN_FAILED` + `LOCKOUT`

### حدود المعدل (Rate Limiting)
- عام: 120 طلب/دقيقة/مستخدم
- المزامنة: 600 طلب/دقيقة
- تسجيل الدخول: 5 محاولات/دقيقة/IP
- التحقق العام (QR): 60 طلب/دقيقة/IP

### تشفير البيانات
- **في النقل**: HTTPS/TLS 1.2+
- **في الراحة**: تشفير قاعدة البيانات على مستوى القرص (LUKS/dm-crypt)
- **الأسرار**: متغيرات بيئية، لا في الكود
- **كلمات المرور**: argon2id (19MiB / 3 iterations / 32 bytes hash)
- **JWT**: HS256 مع سر 32+ حرفًا

### منع الحقن
- Prisma ORM يمنع SQL injection بطبيعته
- Zod يمنع XSS عبر التحقق من المدخلات
- عناوين الأمان: X-Frame-Options: DENY, X-Content-Type-Options: nosniff, Referrer-Policy, CSP

---

## 12. قائمة الاختبارات الكاملة (50+ سيناريو)

### اختبارات الوحدة (Unit Tests)
1. حساب الرصيد بعد الحركة
2. حساب المتبقي على الفاتورة
3. تخصيص الدفعة على فاتورة واحدة
4. تخصيص الدفعة على عدة فواتير (FIFO)
5. الدفع الجزئي → PARTIALLY_PAID
6. الدفع الكامل → PAID
7. الدفع المختلط (cash + card + bank)
8. تحويل بين صندوقين (atomicity)
9. استرجاع تكلفة الإرجاع (restore at original cost)
10. تحويل العملة (IQD ↔ USD)
11. إغلاق الصندوق اليومي (bookBalance vs actualCash)
12. جرد الصندوق بالفئات
13. مقاومة Idempotency (نفس الطلب مرتين)
14. منع التجاوز (payment > remaining)
15. حساب أعمار الديون (5 buckets)
16. كشف حساب العميل (running balance)
17. قيد مزدوج متوازن (Σ debit = Σ credit)
18. ميزان المراجعة (Total debit = Total credit)
19. الميزانية العمومية (Assets = Liabilities + Equity)
20. قائمة الدخل (Revenue − Expenses = Net Income)

### اختبارات التكامل (Integration Tests)
21. فاتورة → دفعة → وصل قبض → كشف حساب → صندوق
22. فاتورة شراء → دفعة مورد → وصل صرف → كشف مورد → صندوق
23. مصروف → موافقة → وصل صرف → صندوق
24. تحويل → صندوق مصدر (−) → صندوق هدف (+)
25. إيداع بنكي → صندوق (−) → بنك (+)
26. سحب بنكي → بنك (−) → صندوق (+)
27. شيك وارد → تحصيل → وصل قبض → صندوق
28. شيك صادر → صرف → وصل صرف → صندوق
29. وردية كاشير → clock-in → حركات → clock-out → تقرير
30. مصروف متكرر → إنشاء → جدولة → nextRunAt

### اختبارات الأمان (Security Tests)
31. شركة A لا ترى صناديق شركة B
32. فرع A لا يصل لصندوق فرع B
33. موظف لا يصل لصندوق مالك آخر
34. مدير فرع لا يعدّل مستخدم GLOBAL
35. cashier لا يرى التقارير المالية
36. محاولة IDOR (وصول مباشر بـ ID) → 404
37. محاولة mass assignment → رفض
38. محاولة SQL injection → رفض
39. محاولة XSS → تنظيف
40. تكرار وصل عبر idempotencyKey → نفس النتيجة

### اختبارات التسوية المالية (Reconciliation Tests)
41. رصيد الصندوق = افتتاحي + IN − OUT
42. رصيد العميل = سابق + فواتير − دفعات − مرتجعات
43. رصيد المورد = سابق + مشتريات − دفعات − مرتجعات
44. COGS = Σ line snapshots
45. ميزان المراجعة متوازن
46. الميزانية العمومية متوازنة

### سيناريوهات القبول الكاملة
47. سيناريو العميل: فاتورة 1.2M → دفعة 500K → متبقي 700K → دفعة 700K → PAID
48. سيناريو الدفع الجزئي: فاتورة 1M → 300K → 200K → 500K → PAID
49. سيناريو عدة فواتير: 3 فواتير → دفعة 600K → تخصيص FIFO
50. سيناريو الإلغاء: وصل 500K → إلغاء → عكس كامل
51. سيناريو المندوب: تحصيل 1M → وردية كاشير → تسليم 1M
52. سيناريو المصروف المحمّل: مصروف 25K → على ذمة العميل
53. سيناريو التحوال بعملة مختلفة: USD → IQD مع سعر صرف
54. سيناريو قيد محاسبي: Dr Cash 1M, Cr Capital 1M → متوازن
55. سيناريو الإغلاق اليومي: افتتاحي + مقبوضات − مدفوعات = دفتري vs فعلي

---

## 13. خطة النشر (Deployment Spec)

### Docker
```yaml
# docker-compose.production.yml
services:
  app:
    build: .
    ports: ["3000:3000"]
    env_file: .env.production
    volumes:
      - uploads:/app/db/uploads
    depends_on: [postgres, redis]
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/api/v1/readiness"]
      interval: 30s
      retries: 5
  postgres:
    image: postgres:16-alpine
    volumes: [pgdata:/var/lib/postgresql/data]
  redis:
    image: redis:7-alpine
    volumes: [redisdata:/data]
  nginx:
    image: nginx:1.27-alpine
    ports: ["80:80", "443:443"]
    volumes: [./deploy/nginx/kayan.conf:/etc/nginx/conf.d/default.conf]
    depends_on: [app]
```

### متغيرات البيئة الإلزامية
```env
DATABASE_URL=postgresql://kayan:CHANGE_ME@postgres:5432/kayan
JWT_ACCESS_SECRET=<32+ hex>
JWT_REFRESH_SECRET=<32+ hex>
NODE_ENV=production
PORT=3000
REDIS_URL=redis://:CHANGE_ME@redis:6379
```

### باب أمان الإقلاع (Boot Gate)
```typescript
// instrumentation.ts
if (process.env.NODE_ENV === "production") {
  const s = process.env.JWT_ACCESS_SECRET ?? "";
  if (!s || s.length < 32) {
    throw new Error("[boot] JWT_ACCESS_SECRET مطلوب (32+ حرفًا) في الإنتاج");
  }
}
```

---

هذا الملحق يكمّل كل الفجوات التقنية المكتشفة في المراحل 0–73 من الـ Master Prompt الأصلي. يجب استخدامه كمرجع تقني أثناء التنفيذ.
