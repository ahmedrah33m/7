# تقرير إتمام المرحلة الثانية — إصلاح الوحدات والتعبئة والأسعار والعملات

**التاريخ:** 2026-09-16 · **المرجع:** upload/Phase 2 — Product Units, Packaging & Multi-Currency Pricing Repair.md
**الحالة:** ✅ مكتملة — جميع معايير Definition of Done متحققة ومُثبتة بالاختبارات

---

## 1. الملخص التنفيذي

نفّذت المرحلة الثانية إصلاح طبقة المنتجات والأسعار والتعبئة الموجودة دون إعادة بناء النظام،
وفق توجيه الوثيقة. النتيجة: طبقة تسعير مهيكلة (ProductPrice) تحفظ كل سعر بعملته كما دخل
(26 USD تبقى 26 — لا تحويل عند الحفظ ثم معاملته كأنه USD)، وتحقق مركزي من التعبئة مُفرض
في الخادم (POST/PATCH/import/seed) وليس في الواجهة فقط، ولقطة فاتورة غير قابلة للتغيير
تصون الفواتير التاريخية من أي تعديل لاحق للأسعار، ومحرك عبوات يستهلك الكراتين الكاملة
كوحدات صحيحة (بلا 1.2727 كرتون كمصدر حقيقة).

## 2. ما نُفّذ — حسب أقسام الوثيقة

| § | المتطلب | التنفيذ |
|---|---------|---------|
| 1 | Base Unit | `Product.unit` = الوحدة الأساسية (حبة/علبة) — معروضة في الجدول وسطر الفاتورة |
| 2 | Package Unit + منع unit==packUnit | `packUnit`/`packQty` + قاعدة `baseUnit !== packageUnit` مع مطابقة عائلات الوحدات (كرتون/كرتونة/كراتين وحدة واحدة) |
| 3 | Validation في POST/PATCH/import/seed | وحدة مركزية `src/lib/product-validation.ts` ترفض: packQty≤1 (PRD_002) · packUnit==unit (PRD_003) · سعر عبوة بلا وحدة (PRD_004) · وحدة بلا كمية (PRD_005) |
| 4 | Pricing Model (amount/currency/unit/priceType/effectiveFrom/To) | جدول `product_prices` الجديد بهذه الحقول كلها + isActive |
| 5 | طبقة ProductPrice | أنواع الأسعار: SALE·COST·WHOLESALE·RETAIL·SPECIAL·PROMOTIONAL × وحدتَي PIECE·PACKAGE |
| 6 | حفظ USD كما هو | `syncProductPrices` يخزن 26 USD/PACKAGE كما دخل — الأعمدة المسطحة بالدينار إسقاط موثّق فقط |
| 7 | قاعدة التحويل | وحدة `src/lib/currency.ts`: USD→IQD ×rate · IQD→USD ÷rate · سعر صرف الشركة إعداد `currency.usd_rate_iqd` (=1550) بلا تخمين 1300 إطلاقاً |
| 8 | Invoice Snapshot | أعمدة جديدة بسطر الفاتورة: priceCurrency · priceExchangeRate · baseUnitLabel · packageUnitLabel · costCurrency + الفاتورة تحمل currencyCode/exchangeRate منذ قدم |
| 9 | المثال الإلزامي | مُثبت باختبارات M1-M5: 5 كراتين = $130.00 بالضبط · 3 حبات ≈ $7.090909 · مختلط 1+3 = $33.0909 |
| 10 | Open Carton | محرك العبوات طُوّر: الكراتين الكاملة تُسحب من **المغلقات كوحدات** (EMPTY «سُحبت كرتونة مغلقة كاملة») وتُفتح كرتونة واحدة فقط للحبات المفردة — بند الفاتورة يسجّلها في دفتر التعبئة غير القابل للتغيير |
| 11 | UI | كتلة كاملة: «الوحدة الأساسية: علبة / التعبئة: كارتون / الكرتونة: 11 علبة / سعر الحبة / سعر الكرتون: $26» — ولا تُظهر «1 كرتون = 11 كرتون» أبداً (حارس تسوية عائلات الوحدات) |
| 12 | Data Repair | تقرير تدقيق شامل `scripts/phase2-data-repair.mjs` (8 أنواع مخالفات A1-C2) + ترميم تزامن العبوات `phase2-repair-packages.mjs` (قراءة/تطبيق، أرشفة JSON قابلة للعكس، صف ADJUSTMENT موثق في دفتر التعبئة) |
| 13 | Tests | بطارية E2E كاملة `scripts/phase2-verify.mjs` — **42/42** |

## 3. Definition of Done — الإثبات

| المعيار | الحالة | الدليل |
|---------|--------|--------|
| No unit == packUnit invalid state | ✅ | رفض API (V1/V2/V2b/V8) + تدقيق D1: صفر مخالفات في الكتالوج |
| No currency-less product pricing | ✅ | كل منتج لديه صفوف ProductPrice بعملة صريحة (D2/D3) |
| No incorrect USD/1300 => 0.02 display | ✅ | لا تخمين: أسعار الدولار تُعرض من قيمتها المخزنة (26 → $26.00) وتحويل الدينار بسعر الشركة الموثق 1550 (V6 + S5 + عرض الشاشة الحي) |
| No fractional package as physical source of truth | ✅ | كل صفوف packages أعداد صحيحة (O4) والرصيد بالحبات الصحيحة (O5: 38 وليس 3.45 كرتون) |
| Invoice snapshot immutable | ✅ | تعديل سعر الكرتونة 26→30 USD: الفاتورة القديمة لم تتغير بيتاً (H2) والجديدة $30 (H3) + تاريخ أسعار بصف مغلق وساري (H4) |
| All packaging tests pass | ✅ | 42/42 phase2 + انحدار كامل أخضر (§5 أدناه) |

## 4. التغييرات التقنية

**قاعدة البيانات (Prisma):**
- جدول `product_prices` الجديد (فهرس: productId+priceType+unit+currency)
- أعمدة لقطة في `sales_invoice_lines`: price_currency · price_exchange_rate · base_unit_label · package_unit_label · cost_currency
- إعداد `currency.usd_rate_iqd` لكل شركة (القيمة المعتمدة: 1550)

**وحدات lib جديدة:**
- `src/lib/currency.ts` — التحويل الموحد + سعر صرف الشركة (getCompanyUsdRate/setCompanyUsdRate)
- `src/lib/product-validation.ts` — validatePackaging المركزي (POST/PATCH/import/seed) + sameUnit لعائلات الوحدات
- `src/lib/product-pricing.ts` — syncProductPrices (تاريخ أسعار بإغلاق/فتح صفوف) · getEffectivePrices · resolveDefaultSalePrices

**واجهات API:**
- POST/PATCH `/api/v1/products`: حقول العملة (cost/sale/pack_sale_currency) + exchange_rate + التحقق المركزي + مزامنة الطبقة المهيكلة؛ إزالة التعبئة بحقل فارغ تُسقط كميتها وسعرها ضمنياً
- GET `/api/v1/products`: يعيد `prices` المهيكلة + عملة كل سعر كما خُزّنت + company_usd_rate
- POST `/api/v1/products/import`: أعمدة تعبئة (pack_unit, pack_qty, pack_sale_price) + تحقق لكل صف — الفاسد يُبلّغ ولا يوقف الصالح + كشف رأس CSV عربي
- `PUT/GET /api/v1/settings/usd-rate` جديد — سعر صرف الشركة المعتمد
- `sales-service`: الافتراضيات من الطبقة المهيكلة، أسعار USD تُحوَّل بسعر فاتورة الدولار أو سعر الشركة (وإلا PRD_006 صريح بلا تخمين)، ولقطة §8 تُكتب في كل بند
- `packaging.ts`: consumeFromPackages(fullPackages, loosePieces) — السحب الكامل قبل الاستعلامات (إصلاح سباق اللقطة القديمة)

**الواجهة:**
- products-tab: مبدّلات عملة لكل سعر (د.ع/$) + أسعار تُخزَّن بعملتها + عرض التكلفة/الحبة/الكرتونة بعملتيها + شريط سعر الصرف يُحفظ إعداداً للشركة
- new-invoice-tab: كتلة §11 الكاملة في البند + إظهار السعر المصدر بالدولار (26$) بجوار المكافئ

## 5. الاختبارات والانحدار

| المجموعة | النتيجة |
|----------|---------|
| **phase2-verify.mjs** (§3/§9/§10/§7/§8/DoD) | **42/42** ✅ |
| phase0-verify (الأساس) | 25/25 ✅ (أُصلحت هشاشة قديمة: قفل الاختبار زمني التبعية — مستخدم فريد لكل تشغيل + توقعات سلوك Phase 1 المحدَّث) |
| invoice-smart-verify (الفاتورة الذكية) | 50/50 ✅ |
| multi-branch-verify | 65/65 ✅ |
| phase1-security-verify | 43/43 ✅ |
| phase1-company-scope-verify | 6/6 ✅ |
| verify-currency-and-product-edit | 19/19 ✅ (حُدّث لتوقعات §3 الجديدة) |

**تحقق المتصفح الحي (agent-browser):** شركة لوميره → جدول المنتجات يعرض «الأساسية: علبة / التعبئة: كارتون = 11 علبة» + سعر الكرتونة $26.00 · نموذج فاتورة USD: كتلة §11 حرفياً + 2 كرتون + 5 حبات = **$63.82** بالضبط (2×26 + 5×2.3636) + المتاح «30 كارتون كاملة + 1 مفتوحة (1 علبة)». لقطات في download/screenshots/.

## 6. تقرير إصلاح البيانات (§12)

**أدوات:** `phase2-data-repair.mjs` (تدقيق قراءة فقط 8 أنواع) · `phase2-repair-packages.mjs` (--apply مع أرشفة قابلة للعكس)

**النتائج على قاعدة البيانات الحية:**
- ترحيل أسعار: 52 صف ProductPrice أُنشئت لـ22 منتجاً من الأعمدة القديمة (IQD)
- unit==packUnit: **صفر مخالفات** (إصلاح جلسة سابقة أثبته التدقيق)
- تزامن العبوات: 11 زوجاً (مستودع، منتج) أعيدت مواءمته — 9 منها منتجات لوميره كان مخزونها بلا صفوف عبوات (تأجيل سليم بالتصميم، مُوادّأ مبكراً كتحسين) + 2 منتجا اختباريين مصابان بخلل اللقطة القديمة المؤقت، رُمّما بالكامل
- الأرشفة: backups/package-repair-2026-09-16T15-56-03-579Z.json (كل الصفوف القديمة محفوظة — الاسترجاع ممكن) + صفوف RESTOCK/ADJUSTMENT موثقة في دفتر التعبئة
- الحالة النهائية: **صفر مخالفات** في كل الفحوص الثمانية

## 7. قرارات معمارية موثقة

1. **الأعمدة المسطحة تبقى إسقاطاً بالدينار** (وليست الحذف) — المخزون والأرباح والتقارير وWAVG تعمل بلا انقطاع؛ الطبقة المهيكلة هي مصدر الحقيقة العملوي.
2. **تاريخ الأسعار** — تغيير سعر يغلق الصف السابق (effectiveTo) ويفتح جديداً: تدقيق كامل دون جداول إضافية.
3. **رفض صريح بدل تخمين** — منتج مسعّر بالدولار + فاتورة دينار بلا سعر صرف للشركة → PRD_006 يطلب التحديد (كان 1300 يُخمَّن صامتاً).
4. **السحب الكامل من المغلقات** (§10) — الكرتونة الكاملة المباعة تُستهلك كوحدة صحيحة مغلقة، والفتح لحبات المفردة فقط؛ توافق كامل مع المتصلين القدامى (عطائل/تحويلات/عروض أسعار) بالسلوك الجشع القديم حين لا تُمرر fullPackages.
5. **idempotent seed** — منتجات العرض امتثلت §1/§2 (زيت: حبة+كرتون×4 · مياه: قنينة+كرتون×12) وبأسعار مهيكلة.

## 8. الملفات المضافة/المعدلة

```
src/lib/currency.ts · product-validation.ts · product-pricing.ts (جديدة)
src/lib/errors.ts (PRD_002..006) · sales-service.ts · packaging.ts · seed.ts
src/app/api/v1/products/{route,[id]/route,import/route}.ts
src/app/api/v1/settings/usd-rate/route.ts (جديد)
src/components/sales/products-tab.tsx · new-invoice-tab.tsx
prisma/schema.prisma (ProductPrice + لقطة البنود)
scripts/phase2-{migrate-prices,data-repair,repair-packages,verify,check-schema,diag}.*
docs/phase2-audit.json · download/screenshots/p2-*.png
```
