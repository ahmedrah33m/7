# PHASE 1 §9 — تدقيق نقاط النهاية (Endpoint Audit)

> مولّد آلياً من الكود (scripts/gen-endpoint-audit.mjs) بتاريخ 2026-09-16 —
> كل مسارات `src/app/api/**/route.ts` مع الصلاحية المطلوبة ونطاقات العزل.
>
> **القواعد الثابتة في كل النظام:**
> - `companyId` يأتي من الجلسة (JWT) **دائماً** — العميل لا يستطيع تجاوزه (§4).
> - الفرع النشط (`brn` في JWT) يضيّق القراءة والكتابة إلى فرعه (§5).
> - المستودعات تُتحقق: `warehouse.companyId === session.companyId` + ضمن نطاق الجلسة (§6).
> - المرجع العابر للشركات يُرفض بـ `SCOPE_006` أو 404 (منع تسريب الوجود) (§7).
> - مالك المنصة (GLOBAL) يرى كل شركات نطاقه في مسارات الإدارة **عمداً** (إدارة المنصة) —
>   مستخدمو نطاق COMPANY/BRANCH/WAREHOUSE معزولون تماماً (مثبت بـ phase1-security-verify.mjs).

| Endpoint | Methods | Required Permission | Company Scope | Branch Scope | Warehouse Scope | Cross-company |
|---|---|---|---|---|---|---|
| `/v1/admin/audit-logs` | GET | audit.audit_logs.view | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/admin/backup` | GET | system.settings.edit | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/admin/branches` | GET POST | system.branches.view, system.branches.create | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/admin/branches/[id]` | PATCH DELETE | system.branches.edit, system.branches.delete | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/admin/companies` | GET POST | system.company.view, system.company.edit | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/admin/companies/[id]` | PATCH | system.company.edit | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/admin/permissions` | GET | system.roles.view | غير مخصص | — | — | — |
| `/v1/admin/roles` | GET PATCH | system.roles.view, system.roles.edit | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/admin/users` | GET POST PATCH | system.users.view, system.users.create, system.users.edit | session.companyId | نطاق الفروع + activeBranch | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/admin/users/[id]` | DELETE | system.users.delete | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/admin/warehouses` | GET POST PATCH DELETE | system.branches.view, system.branches.create, system.warehouses.delete | session.companyId | نطاق الفروع + activeBranch | — | SCOPE_006 صريح |
| `/v1/alerts` | GET | مصادقة فقط | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/auth/login` | POST | — عام (بدون توكن) | session.companyId | نطاق الفروع + activeBranch | — | 404 ضمن الشركة |
| `/v1/auth/logout` | POST | — عام (بدون توكن) | غير مخصص | — | — | — |
| `/v1/auth/me` | GET | مصادقة فقط | session.companyId | نطاق الفروع + activeBranch | — | 404 ضمن الشركة |
| `/v1/auth/refresh` | POST | — عام (بدون توكن) | غير مخصص | نطاق الفروع + activeBranch | — | — |
| `/v1/auth/refresh-scope` | POST | مصادقة فقط | session.companyId | نطاق الفروع + activeBranch | — | 404 ضمن الشركة |
| `/v1/auth/switch-branch` | POST | مصادقة فقط | session.companyId | نطاق الفروع + activeBranch | — | 404 ضمن الشركة |
| `/v1/auth/switch-company` | POST | مصادقة فقط | session.companyId | نطاق الفروع + activeBranch | — | 404 ضمن الشركة |
| `/v1/b2b/admin/orders` | GET | b2b.orders.view | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/b2b/admin/orders/[id]/confirm` | POST | b2b.orders.approve | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/b2b/admin/orders/[id]/reject` | POST | b2b.orders.reject | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/b2b/auth` | POST | — عام (بدون توكن) | غير مخصص | — | — | — |
| `/v1/b2b/catalog` | GET | B2B token | غير مخصص | — | — | — |
| `/v1/b2b/orders` | POST | B2B token | غير مخصص | — | — | — |
| `/v1/b2b/statement` | GET | B2B token | غير مخصص | — | — | — |
| `/v1/categories` | GET POST | products.products.view, products.products.create | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/customers` | GET POST | parties.customers.view, parties.customers.create | session.companyId | نطاق الفروع + activeBranch | — | 404 ضمن الشركة |
| `/v1/customers/[id]/convert` | POST | parties.customers.edit | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/customers/[id]/loyalty` | GET POST | parties.customers.view, parties.customers.edit | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/customers/default-walkin` | GET | parties.customers.view | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/customers/import` | POST | parties.customers.import | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/dashboard/stats` | GET | system.company.view | session.companyId | نطاق الفروع + activeBranch | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/field/commissions` | GET | field.commissions.view | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/field/commissions/[id]/approve` | POST | field.commissions.approve | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/field/commissions/[id]/pay` | POST | field.commissions.approve | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/field/routes` | GET POST | field.routes.view, field.routes.create | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/field/summary` | GET | مصادقة فقط | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/field/targets` | GET POST | field.targets.view, field.targets.create | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/field/visits` | GET POST | field.visits.view, field.visits.create | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/field/visits/[id]/cancel` | POST | field.visits.cancel | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/field/visits/[id]/checkin` | POST | field.visits.edit | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/field/visits/[id]/complete` | POST | field.visits.edit | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/finance/cashboxes` | GET | finance.cashboxes.view | session.companyId | نطاق الفروع + activeBranch | — | 404 ضمن الشركة |
| `/v1/finance/transactions` | GET POST | finance.payments.view, finance.expenses.create, finance.payments.create | session.companyId | نطاق الفروع + activeBranch | — | 404 ضمن الشركة |
| `/v1/health` | — | — عام (بدون توكن) | غير مخصص | — | — | — |
| `/v1/inventory/balances` | GET | inventory.stock.view | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/inventory/movements` | GET POST | inventory.movements.view, inventory.movements.create | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/inventory/packages` | GET | inventory.stock.view | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/inventory/stocktakes` | GET POST PATCH | inventory.stocktakes.view, inventory.stocktakes.create, inventory.stocktakes.edit | session.companyId | نطاق الفروع + activeBranch | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/inventory/stocktakes/[id]` | GET POST | inventory.stocktakes.view, inventory.stocktakes.post | session.companyId | نطاق الفروع + activeBranch | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/inventory/transfers` | GET POST | inventory.transfers.view, inventory.transfers.create | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/inventory/transfers/[id]/cancel` | POST | inventory.transfers.create | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/inventory/transfers/[id]/receive` | POST | inventory.transfers.create | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/openapi` | — | — عام (بدون توكن) | غير مخصص | — | — | — |
| `/v1/products` | GET POST | products.products.view, products.products.create | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/products/[id]` | PATCH DELETE | products.products.edit, products.products.delete | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/products/import` | POST | products.products.import | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/purchases/invoices` | GET POST | purchasing.purchase_invoices.view, purchasing.purchase_invoices.create | session.companyId | نطاق الفروع + activeBranch | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/purchases/invoices/[id]` | DELETE | purchasing.purchase_invoices.delete | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/reports/[type]` | GET | reports.reports.view | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/sales/delivery-notes` | GET POST | sales.delivery_notes.view, sales.delivery_notes.create | session.companyId | نطاق الفروع + activeBranch | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sales/delivery-notes/[id]` | GET PATCH | sales.delivery_notes.view, sales.delivery_notes.edit | session.companyId | نطاق الفروع + activeBranch | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sales/invoices` | GET POST | sales.invoices.view, sales.invoices.create | session.companyId | نطاق الفروع + activeBranch | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sales/invoices/[id]` | GET | sales.invoices.view | session.companyId | نطاق الفروع + activeBranch | — | 404 ضمن الشركة |
| `/v1/sales/invoices/[id]/approve` | POST | sales.invoices.approve | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sales/invoices/[id]/confirm-receipt` | POST | sales.invoices.edit | session.companyId | نطاق الفروع + activeBranch | — | 404 ضمن الشركة |
| `/v1/sales/invoices/[id]/qr` | GET | sales.invoices.view | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/sales/invoices/[id]/reject` | POST | sales.invoices.reject | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sales/invoices/[id]/void` | POST | sales.invoices.cancel | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sales/invoices/preview` | POST | sales.invoices.view | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/sales/orders` | GET POST | sales.orders.view, sales.orders.create | session.companyId | نطاق الفروع + activeBranch | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sales/orders/[id]` | GET | sales.orders.view | session.companyId | نطاق الفروع + activeBranch | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sales/orders/[id]/cancel` | POST | sales.orders.cancel | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sales/orders/[id]/confirm` | POST | sales.orders.edit | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sales/orders/[id]/convert` | POST | sales.invoices.create | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sales/quotations` | GET POST | sales.quotations.view, sales.quotations.create | session.companyId | نطاق الفروع + activeBranch | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sales/quotations/[id]` | GET POST PATCH | sales.quotations.view, sales.quotations.edit, sales.quotations.post | session.companyId | نطاق الفروع + activeBranch | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sales/returns` | GET POST | sales.returns.view, sales.returns.create | session.companyId | نطاق الفروع + activeBranch | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/search` | GET | مصادقة فقط | session.companyId | نطاق الفروع + activeBranch | — | 404 ضمن الشركة |
| `/v1/suppliers` | GET POST | parties.suppliers.view, parties.suppliers.create | session.companyId | — | — | 404 ضمن الشركة |
| `/v1/sync/pull` | GET | products.products.view | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/sync/push` | POST | مصادقة فقط | session.companyId | — | نطاق المستودعات | 404 ضمن الشركة |
| `/v1/verify/[token]` | GET | — عام (بدون توكن) | غير مخصص | — | — | — |
