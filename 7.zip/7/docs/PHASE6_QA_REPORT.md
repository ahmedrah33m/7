# Phase 6 Report — Production QA Architecture

**التاريخ:** 2026-09-17 · **الحكم:** ★ PRODUCTION READY — البوابات الثماني PASS + انحدار 414 فحصاً

---

## 1. البنية (`vitest.config.ts` + `tests/`)

| الطبقة | الموقع | العدّاد |
|---|---|---|
| Unit (دوال نقية) | `tests/unit/` — decimal · packaging · currency · pricing · cost-engine | **52** |
| Integration (APIs الحية) | `tests/integration/` — api · security · packaging-regression · stock-integrity · finance-reconciliation | **39** |
| E2E (السيناريو الكامل) | `tests/e2e/pipeline.test.ts` — 12 خطوة من Login إلى Customer balance | **12** |
| **مجموع Vitest** | | **103** |

- **Vitest 5.0.1** مثبت dev — سكربتات: `test` / `test:unit` / `test:integration` / `test:e2e` / `gate`.
- `fileParallelism: false` إلزامي — الخادم الحي يطبّق حد معدل (RATE_001) والتشغيل المتوازي يضربه.
- `jfetch` في `tests/integration/helpers.ts` **يتحمل حد المعدل ذاتياً**: يقرأ ثواني RATE_001 ويعيد المحاولة (4 مرات كحد أقصى).
- Supertest غير مناسب لـ App Router (لا app instance قابلة للتوصيل) — فحوصات API الحية عبر fetch ضد `TEST_BASE_URL` (افتراضي `http://localhost:3000/api/v1`) — تكافؤ وظيفي كامل.
- Playwright UI-driving: مؤجل عمداً (تنزيل المتصفح ضخم) — التحقق البصري يتم عبر Agent Browser (تم: تسجيل دخول + تبويب التسليم الجديد بلا أخطاء كونسول)، وسيناريو E2E المعتمد في النطاق هو تسلسل API أصلاً.

## 2. تغطية منهج النطاق

**§1 Unit:** packaging (packInfoOf/packSplit/fmtPackText/pluralOf + منع 1×1) · currency (تحويل R5، رفض الصفر/السالب، لا تخمين) · pricing (derivePieceFromPackage 26/11=2.363636) · Decimal (R1-R4، sumOf، عقد nOrNull، **انحدار isPositive(0)=false**) · cost-engine (normalizeCostMethod بلا تخمين + العقد الرياضي: FIFO 124000 · WAVG 128000 بالضبط).

**§2 Integration:** المصادقة (دخول خاطئ، رمز فاسد، 401) · المنتجات/العملاء/الإعدادات (عقد `{success,data}`، usd-rate بلا تخمين، رفض طريقة تكلفة مجهولة).

**§3 E2E:** Login → Company (switch) → Branch+Warehouse → Product → Customer → Order مؤكد → **DN جزئي 40/100 → تسليم PARTIAL** → **تحويل لفاتورة** (خصم 300→260 والفاتورة 40×1500) → Payment تحصيل 30000 → Stock deduction = 40 بالضبط → Customer balance = 30000 → إغلاق السلسلة (بقية 60 قابلة للتسليم).

**§4 Multi-Tenant Security:** شركتان ببيانات متطابقة الأسماء — العبور A→B في: product (PATCH/GET) · customer · warehouse (أمر/حركة) · invoice (إنشاء بعميل B/قراءة/إبطال) · transfer · reports (أرصدة A بلا منتج B) · search (مشيّة عميقة) — **كلها تُرفض/لا تسرّب** (11 فحصاً).

**§5 Packaging Regression (إلزامي):** عبر API حي: منتج كرتونة 11 بسعر 26 USD + تكلفة 25 USD (rate 1300) → الأسعار المهيكلة تُحفظ كما دخلت (ProductPrice: SALE/PACKAGE/USD/26 · SALE/PIECE/USD/26÷11 · COST/USD/25) → **5 كراتين = 55 حبة = 169000 IQD = 130 USD بالضبط** → **3 حبات = ≈ 9218.1818 IQD = 7.090909 USD** (±دقة الإسقاط 4dp).

**§6 Stock Integrity:** الثابت `StockBalance = Σ الحركات الموقعة` يُفحص بعد **كل** خطوة من: Opening (+500) · Purchase (+40) · Transfer (530/10 متوازنان) · Sale (−25) · Return (+5) · Stocktake (+7) · Void (يعيد الكمية) · **Delivery (الرصيد ثابت تماماً — قاعدة المرحلة 5)** — 8 فحوصات دورة حياة.

**§7 Financial Reconciliation:** م1 المدفوع = حركات الصندوق للفاتورة · م2 رصيد العميل = Σ(grand−paid) · م3 رصيد الصندوق = آخر balanceAfter = Σ(IN−OUT) · م4 COGS الفاتورة = Σ بنودها (طبقة الافتتاحي 1000) · م5 الربح الإجمالي = 18000 بالضبط · م6 تقييم المخزون = 70000 = الطبقات = الأرصدة.

## 3. بوابة الإنتاج (`scripts/phase6-gate.mjs` — §9)

```
node scripts/phase6-gate.mjs          # البوابات الثماني (~4 دقائق مع التهدين)
node scripts/phase6-gate.mjs --full   # + 10 جناحات انحدار تاريخية
```

| البوابة | الأداة | النتيجة |
|---|---|---|
| 1 Unit | vitest tests/unit | **PASS — 52** |
| 2 Integration | vitest api + packaging-regression | **PASS — 14** |
| 3 E2E | vitest tests/e2e | **PASS — 12** |
| 4 Security | vitest security.test.ts | **PASS — 11** |
| 5 Inventory | vitest stock-integrity.test.ts | **PASS — 8** |
| 6 Finance | vitest finance-reconciliation.test.ts | **PASS — 7** |
| 7 Migration | `prisma db push` idempotent + 55 جدول @@map موجود + `integrity_check ok` (python3 sqlite3 readonly) | **PASS** |
| 8 Backup/Restore | نسخة `backups/phase6/gate-backup-*.db` + integrity + تطابق 10 جداول مفتاحية صفاً بصف | **PASS** |
| 9 Regression (--full) | 10 جناحات تاريخية | **PASS — 414** (phase5 72 · phase4 53 · phase3 39 · phase2 42 · phase0 25 · multi-branch 65 · invoice-smart 50 · p1sec 43 · p1scope 6 · currency 19) |

**★ PRODUCTION READY — المجموع الكلي: 518 فحصاً آلياً أخضر.**

## 4. ملاحظات تشغيلية

1. **حد المعدل**: البوابة تهدأ 20 ثانية بين البوابات، و`jfetch` يعيد المحاولة عند RATE_001 — شغّل البوابة كاملة لا بالتوازي مع بطاريات أخرى.
2. **إعادة تشغيل الخادم بعد db push**: عميل Prisma في ذاكرة `next dev` يتقادم بعد أي `db push` — أعد التشغيل (نمط معروف) وإلا SRV_001 على الجداول الجديدة.
3. `scripts/topup-test-cashbox.mjs`: تعبئة صناديق الشركة الحية قبل multi-branch (شراء نقدي يُخصم من الصندوق عبر الجولات — نضوب تراكمي ليس خطأ نظاماً).
4. الإغلاق الدائم للانحدار: البوابة بـ `--full` تحتاج ~12 دقيقة؛ شغّلها خارج ساعات الذروة.
