# Phase 3 — Decimal Conversion Spec (مواصفة التحويل الإلزامية)

المرجع التنفيذي: `src/lib/decimal.ts` (سياسة R1-R10) + **النموذج المحوَّل**: `src/lib/sales-service.ts` و`src/lib/inventory.ts` و`src/lib/packaging.ts`.

## الممنوعات المطلقة
- ممنوع `+ - * / += -=` على أي قيمة مالية/كمية (حقول Prisma Decimal الآن).
- ممنوع `Math.round/Math.min/Math.max/Math.abs/Number()/parseFloat` على قيم مالية.
- ممنوع `round2()` من utils-server في أي حساب جديد.
- ممنوع مقارنات `> < >= <= ===` مباشرة على Decimal (كائنات!) — استخدم `.gt() .lt() .gte() .lte() .equals() .isPositive() .isNegative() .isZero()`.

## الأدوات (استوردها من `@/lib/decimal` أو `./decimal`)
```ts
import { Decimal, dec, moneyR, qtyR, pctR, sumOf, num } from "./decimal";
```
- `dec(x)` — تحويل آمن من Prisma.Decimal | number | string | null → Decimal (مدخل أي حساب).
- `moneyR(x)` — تقريب مال HALF_UP 4dp (تخزين: أسعار/مبالغ/أرصدة).
- `qtyR(x)` — تقريب كمية 6dp (كميات/تحويلات تعبئة/أرصدة مخزون).
- `pctR(x)` — تقريب نسبة 4dp (خصم% / ضريبة% / عمولة%).
- `sumOf(items, fn?)` — مجموع Decimal (بديل `reduce((s,x)=>s+x,0)`).
- `num(x)` — **للحدود فقط**: تحويل إلى number للـJSON/العرض — لا يُعاد استخدامه في حساب مالي.
- `Decimal.min/max(a, b)` — بدل Math.min/max.
- القيم الثابتة: `new Decimal(0)`, `new Decimal(100)`.

## خرائط التحويل
| القديم (Float) | الجديد (Decimal) |
|---|---|
| `a + b` | `dec(a).plus(dec(b))` أو `dec(a).plus(b)` |
| `a - b` | `dec(a).minus(b)` |
| `a * b` | `dec(a).mul(b)` |
| `a / b` | `dec(a).div(b)` |
| `round2(x)` للتخزين | `moneyR(dec(x))` |
| `Math.max(0, x)` | `Decimal.max(new Decimal(0), dec(x))` |
| `x > 0` | `dec(x).isPositive()` |
| `x < 0` | `dec(x).isNegative()` |
| `x > y` | `dec(x).gt(y)` |
| `sum += item.amount` | `acc = acc.plus(dec(item.amount))` أو `sumOf(items, i => i.amount)` |
| `item.amount.toFixed(2)` | `num(item.amount).toFixed(2)` (عرض فقط) |
| `Number(item.amount)` | `dec(item.amount)` للحساب، `num(item.amount)` للعرض/النقل |
| Intl format مباشر | `dec(x).toNumber()` ثم Intl (عرض فقط) |

## Prisma
- الحقول المالية الآن تعيد `Prisma.Decimal` — مرّرها عبر `dec()` قبل أي حساب.
- الكتابة: Prisma يقبل `Decimal | number | string` — مرّر قيم `moneyR/qtyR/pctR` مباشرة.
- `{ increment: due }` / `{ decrement: x }` يقبلان Decimal — لا حاجة للتحويل.
- `aggregate({ _sum: { field: true } })` يعيد Decimal|null → استخدم `dec(rows._sum.field)`.

## حدود JSON/الاستجابات (قاعدة R10)
- داخل الخدمة: احسب بـDecimal.
- في **حمولة الاستجابة** (الشيء الذي يعود من route/service إلى الواجهة): حوّل للعرض بـ`num(...)` حتى تبقى الواجهة تستقبل numbers كما كانت.
- النصوص المدمجة (template literals) للرسائل: `num(x)` أو `x.toString()`.

## تقريب سياسة البنود (نفّس مثل sales-service المحوَّل)
```
gross      = moneyR(packageQty × packagePrice + looseQty × piecePrice)
lineTotal  = moneyR(gross × (1 − discountPct/100) − discountAmount)  (≥ 0)
taxAmount  = moneyR(lineTotal × taxRatePct/100)
subtotal   = moneyR(Σ gross)   discountTotal = moneyR(subtotal − Σ lineTotal)
taxTotal   = moneyR(Σ taxAmount)
grandTotal = moneyR(subtotal − discountTotal + taxTotal)
COGS بند   = moneyR(qty × unitCost)
```

## تحقق الإنجاز لكل ملف
1. `bunx tsc --noEmit 2>&1 | grep <file>` → صفر أخطاء.
2. لا تبقى `round2(` ولا عمليات حسابية مباشرة على حقول مالية في الملف.
3. حافظ على سلوك الرسائل/الأكواد (ApiError codes unchanged).

## ملفاتك (لكل وكيل حسب التكليف) — عدّل الملفات نفسها فقط، لا تنشئ ملفات جديدة.
