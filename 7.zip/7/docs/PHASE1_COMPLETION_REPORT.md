# تقرير إنجاز المرحلة 1 — Multi-Tenant Security, Login & Data Isolation Repair

**التاريخ:** 2026-09-16 · **الحالة:** مكتملة — كل اختبارات المرحلة ناجحة

## التعريف بالمسألة والحل

### §1 Login Repair (الإصلاح الجوهري)
**قبل:** `db.user.findFirst({ username })` يلتقط أول صف عشوائياً — عند وجود نفس اسم المستخدم
في شركتين قد يدخل الجلسة بالشركة الخاطئة (خرق عزل كامل).

**بعد:** `findMany({ username })` لكل الحسابات المطابقة ثم:
- مرشّح واحد → سلوك تلقائي (auto select) كما كان.
- عدة مرشحين → التحقق من كلمة المرور ضدهم جميعاً:
  - لم يُمرَّر `company_id` → `requires_company_selection` (قائمة الشركات، **لا توكنز**) — إلزامي حتى لو طابقت كلمة المرور حساباً واحداً (لا نكشف أيّ شركة طابقت).
  - مُرِّر `company_id` → يُربط بصفّ الشركة نفسها إن وجد، وإلا مسار المنح (UserCompanyAccess) ويُتحقق ضمن `scope.companyIds`.
- كلمة المرور الخاطئة → رفض موحّد `AUTH_003` + عدّاد القفل يتراكم على **كل** المرشحين (منع تجاوز القفل بتنويع company_id).
- الحسابات المقفلة مستثناة من التحقق (`AUTH_004` إذا كلها مقفلة).

### §2 Role Isolation
`authenticate()` كان يجمع صلاحيات **كل** أدوار المستخدم عبر الشركات. الآن: أدوار
الشركة النشطة حصراً (`role.companyId === companyId`)، مع استثناء مالك المنصة
(GLOBAL — أدوار منصية بتصميم النظام). نفس الفلتر في `completeLogin` بالدخول.

### §3/§4 Company Scope + API Rule
الجلسة تحمل userId/companyId/branchIds/warehouseIds/roleIds/permissions كاملة.
تدقيق آلي لـ84 مساراً: **صفر** مسارات تأخذ companyId من العميل — كل الفلاتر من
`session.companyId` (والفرع النشط `brn` من JWT فقط).

### §5/§6/§7 Branch/Warehouse/Cross-company
مثبتة مسبقاً (scope.ts) وأُعيد إثباتها بالاختبارات: `assertBranchInScope` (SCOPE_003)،
`assertWarehouseInScope` (SCOPE_002)، المرجع العابر `SCOPE_006` أو 404 (منع تسريب الوجود).

### §8 Same Names
أسماء متطابقة عبر الشركات (فروع/مستودعات/مستخدمين) = كيانات منفصلة بمعرفات مستقلة —
مغطاة في الاختبارات (فرع البصرة موجود بنفس الاسم في A وB بمعرفات مختلفة).

### §9 Endpoint Audit
`docs/PHASE1_ENDPOINT_AUDIT.md` — 84 مساراً (مولّد آلياً: `scripts/gen-endpoint-audit.mjs`):
Endpoint / Methods / Required Permission / Company Scope / Branch Scope / Warehouse Scope / Cross-company.

### §10 Tests — النتائج
| المجموعة | النتيجة |
|---|---|
| `scripts/phase1-security-verify.mjs` (جديدة — 11 فئة اختبار) | **43/43 ✅** |
| `scripts/phase1-company-scope-verify.mjs` (جديدة — عزل COMPANY في مسارات الإدارة) | **6/6 ✅** |
| `scripts/multi-branch-verify.ts` (انحدار — كان 65/65) | **65/65 ✅** |
| `scripts/verify-strict-company-isolation.mjs` (انحدار) | 16/20 — الأربعة «الفاشلة» هي فحوص رؤية صارمة شُغّلت بحساب **مالك المنصة GLOBAL** الذي يرى كل شركات نطاقه **عمداً** (تصميم موثق في الكود)؛ المقابل الصارم لنطاق COMPANY أُثبت 6/6 في السكربت الجديد |

## الملفات المعدلة
| الملف | التغيير |
|---|---|
| `src/app/api/v1/auth/login/route.ts` | إعادة كتابة تحديد الحساب (findMany + تحقق متعدد + requires_company_selection) + فلتر الأدوار بالشركة النشطة في completeLogin + استثناء GLOBAL |
| `src/lib/auth.ts` | فلتر عزل الأدوار في authenticate() (role.companyId === الشركة النشطة، استثناء GLOBAL) + إعادة ترتيب بعد تحديد الشركة من الـ JWT |
| `src/components/login-form.tsx` | شاشة «اختر الشركة» (Company picker) تستجيب لـ requires_company_selection ثم تتابع (قد يليها اختيار فرع) |

## الملفات المضافة
| الملف | الغرض |
|---|---|
| `scripts/phase1-security-verify.mjs` | اختبارات المرحلة الرسمية (43 فحصاً) |
| `scripts/phase1-company-scope-verify.mjs` | عزل COMPANY في مسارات الإدارة (6 فحوص) |
| `scripts/gen-endpoint-audit.mjs` | مولّد تدقيق نقاط النهاية |
| `docs/PHASE1_ENDPOINT_AUDIT.md` | جدول تدقيق الـ84 مساراً |
| `docs/PHASE1_COMPLETION_REPORT.md` | هذا التقرير |

## Definition of Done — 10/10
1. ✅ نفس username يمكن وجوده في شركتين (p1.dual في A وB — كلمات مرور وأدوار مختلفة)
2. ✅ Login يحدد الشركة بشكل صحيح (selected_company أو اختيار إلزامي)
3. ✅ لا اختيار أول user عشوائياً (findMany + تفريق صريح)
4. ✅ Roles مرتبطة بالشركة النشطة (230 صلاحية في A مقابل 23 في B لنفس الاسم)
5. ✅ لا cross-company access (404/SCOPE_006 لمنتج/عميل/فاتورة/تقرير/بحث)
6. ✅ لا cross-branch access (قائمة الفواتير + كتابة المخزون SCOPE_002)
7. ✅ لا cross-warehouse write (حركات/تحويلات مرفوضة SCOPE_002/SCOPE_006)
8. ✅ كل الـ APIs تحترم Session Scope (تدقيق 84 مساراً — صفر تجاوز)
9. ✅ كل الاختبارات الجديدة ناجحة (43/43 + 6/6 + انحدار 65/65)
10. ✅ تقرير الملفات المعدلة (هذا المستند)
