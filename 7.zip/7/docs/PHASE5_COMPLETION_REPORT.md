# Phase 5 Completion Report — Delivery Note & Partial Delivery Engine

**التاريخ:** 2026-09-17 · **الحالة:** مكتملة بمعايير DoD الخمسة · **الفحوصات:** 72/72 بطارية + انحدار كامل أخضر

---

## 1. القاعدة الحاكمة (نطاق §5)

**قاعدة المخزون الوحيدة: الفاتورة تخصم المخزون.** إشعار التسليم مستند شحن/تسليم لوجستي لا يلمس المخزون ولا الطبقات إطلاقاً — لا يوجد double deduction بحكم التصميم (تُفحص صراحة في البطارية T1h/T6e/T7c).

## 2. المخطط (Prisma — db push ناجح)

| التغيير | التفصيل |
|---|---|
| `DeliveryNoteLine` (جديد) | الكميات الأربع المعتمدة: `orderedQty` · `previouslyDeliveredQty` · `currentDeliveredQty` · `remainingQty` (لقطات Decimal 18,6) + مرساة المصدر (`salesOrderLineId` / `invoiceLineId`) + لقطة تعبئة عرضية (`packageQty/looseQty/packageType/packageConversion`) |
| `DeliveryNote` (توسعة) | `salesOrderId` (المصدر الأساسي) · `deliveredById` · `cancelledById` · `cancelledAt` (Audit §7) |
| `SalesOrderLine` (توسعة) | `deliveredQty` — عدّاد إسقاطي يُحدَّث معاملةً عند التسليم |
| أكواد أخطاء | `DLV_003` over-delivery ممنوع (422) · `DLV_004` انتقال حالة غير مسموح (409) |

## 3. المحرك (`src/lib/delivery-service.ts`)

- **المصادر الثلاثة للإنشاء:** أمر بيع مؤكد (أساسي — البنود الافتراضية = كل المتبقي) · فاتورة POSTED (بنود تلقائية من سطورها) · مستقل ببنود يدوية.
- **pool الكميات:** المسلَّم الفعلي = Σ `currentDeliveredQty` من إشعارات `DELIVERED/PARTIAL` فقط — الإشعارات PENDING لا تحجز (لا حجوزات ناعمة)، والملغى يُستبعد فيعود الكميات للمتبقي تلقائياً.
- **منع over-delivery (§4):** عند الإنشاء وعند التسليم معاً ضد المجموع المسلَّم الحي (يُعاد حسابه داخل المعاملة) — إشعاران متزامنان يخططان نفس المتبقي: الأول ينجح والثاني يُرفض `DLV_003` عند التسليم.
- **حالات (§6):** `PENDING → PARTIAL | DELIVERED` · `CANCELLED` من PENDING فقط — الحالة تُحتسب من المتبقي: أي بند متبقٍ > 0 → `PARTIAL`، لا متبقي → `DELIVERED` (يطابق مثال النطاق 100 = 40+30+30 حرفياً).
- **التحويل إلى فاتورة:** إشعار مسلَّم مرتبط بأمر → فاتورة **بالكميات المسلَّمة فعلاً** عبر `createSalesInvoice` (المحرك المعتمد: خصم مخزون + COGS + تعبئة + ائتمان) — نمط claim (`CONFIRMED → INVOICING`) ضد التحويل المزدوج؛ الأمر يُختم `INVOICED` فقط عند اكتمال تسليم كل بنوده وإلا يبقى `CONFIRMED` لبقية التسليمات.
- **تسليم فعلي جزئي داخل الإشعار:** `PATCH deliver` يقبل كميات فعلية لكل بند (0 = تخطي) — الفعلي > المخطط مرفوض `DLV_004`.
- **تقدم الأمر:** `GET /sales/orders/[id]/delivery-progress` — لكل بند: ordered/delivered/pending/remaining + حالة إجمالية + قائمة الإشعارات.

## 4. API

| المسار | الوصف |
|---|---|
| `POST /sales/delivery-notes` | `order_id` أو `invoice_id` أو مستقل `lines` — يرد بالبنود والكميات الأربعة + لقطة التعبئة |
| `GET /sales/delivery-notes` | قائمة + `sales_order` + `lines_count` + فلتر `status/order_id` (يدعم PARTIAL) |
| `GET /sales/delivery-notes/[id]` | التفصيل بالبنود + `deliverable_qty` + audit (created/delivered/cancelled by) |
| `PATCH /sales/delivery-notes/[id]` | `deliver` (بكميات فعلية اختيارية) أو `cancel` |
| `POST /sales/delivery-notes/[id]/convert` | → فاتورة `{type, paid_amount?}` |
| `GET /sales/orders/[id]/delivery-progress` | تقدم التسليم الجزئي |

## 5. الواجهة (`src/components/sales/delivery-tab.tsx` — إعادة بناء)

مصدر ثلاثي في نموذج الإنشاء + لوحة بنود الأمر الحية (أعمدة: المطلوب/المسلَّم سابقاً/قيد الإشعارات المعلقة/المتبقي/كمية هذا الإشعار — مدخل لكل بند، 0 يتخطى) + بنود مستقلة قابلة للإضافة + لوحة تسجيل تسليم بكميات فعلية + لوحة تفاصيل بالكميات الأربعة + شارات الحالة الأربع + زر تحويل لفاتورة للإشعارات المسلَّمة المرتبطة بأوامر. **تحقق متصفح:** دخول → تبويب التسليم → اختيار أمر حقيقي → لوحة التقدم تُعرض بكل أعمدتها — بلا أخطاء كونسول.

## 6. الاختبارات (`scripts/phase5-verify.mjs` — 72/72)

تغطية §8 كاملة: full (T1) · partial (T2) · multiple 40+30+30 (T2) · over-delivery إنشاء/تسليم/تزامن (T3) · cancel وإرجاع الكميات (T4) · invoice after delivery كامل وجزئي (T5) · delivery after invoice + لا ثانية للفاتورة (T6) · double stock deduction ثابت الدفتر (T6h) · cross-company ×7 (T8) · عدّادات `deliveredQty` (T9) + Audit §7 + لقطة التعبئة 2+3 (T7d).

## 7. الانحدار — 414 فحصاً أخضر

phase5 72 · phase4 53 · phase3 39 · phase2 42 · phase0 25 · multi-branch 65 · invoice-smart 50 · phase1-security 43 · phase1-scope 6 · currency-edit 19 — **tsc نظيف صفر أخطاء.**

## 8. قرارات معمارية موثقة

1. **الفاتورة تخصم** (لا الإشعار) — تحفظ محرك COGS/الطبقات (المرحلة 4) المربوط ببنود الفاتورة.
2. **لا حجوزات ناعمة** — منع over-delivery يُفرض عند التسليم ضد المسلَّم الحي (أبسط وأصح من حجوزات PENDING).
3. **الأمر الجزئي يبقى CONFIRMED** بعد تحويل جزئي — `order.invoiceId` يُربط عند الاكتمال فقط؛ الإشعار يحمل رابط فاتورته.
4. **الإشعار المستقل لا يخصم مخزوناً** حتى مع غياب فاتورة — القاعدة واحدة بلا استثناءات.
