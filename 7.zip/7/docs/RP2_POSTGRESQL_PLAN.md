# RP2 — PostgreSQL + Decimal Precision — خطة التنفيذ والأدوات

_التاريخ: 2026-09-17 · المرجع: MASTER REPAIR PROMPT — PHASE 2 · الحالة: **أدوات جاهزة ومُتحقق من السكيما — التنفيذ الفعلي على سيرفر الإنتاج** (لا PostgreSQL/Docker في بيئة التطوير — مذكور بصراحة وفق قواعد الصحة)_

## 1. سياسة الدقة المعتمدة (§2/§4)

| الفئة | الدقة | التصنيف بالاسم (نفس دلالات R1-R10) |
|---|---|---|
| MONEY | `Decimal(18,4)` | الافتراضي لكل Decimal مالي (أسعار/إجماليات/أرصدة/تكاليف) |
| QUANTITY | `Decimal(18,6)` | `*qty*` · `*quantity*` · `remaining` |
| EXCHANGE_RATE | `Decimal(18,6)` | `exchangeRate` · `usdRate` · `*Rate` |
| PERCENTAGE | `Decimal(9,4)` | `*Pct` · `*percent` |

**النتيجة المولدة** (`prisma/schema.postgresql.prisma`): **114 حقل Decimal مصنفاً** — 73 MONEY(18,4) · 36 QUANTITY/RATE(18,6) · 5 PERCENTAGE(9,4) — `prisma validate` ✅ صالحة. الملف مولّد آلياً (`scripts/rp2-gen-pg-schema.mjs`) من `schema.prisma` — أي تعديل مستقبلي على السكيما يعاد توليده.

## 2. تدقيق النماذج المالية (§3/§5)

- **صفر Float مالي**: مُثبت آلياً سابقاً (phase3-verify T10a: كل الحقول المالية DECIMAL، GPS فقط Float) — أُعيد التثقيف في هذا التدقيق: نفس النتيجة.
- **صفر أموال كنص**: كل المبالغ Decimal في السكيما وDecimal في التطبيق (سياسة R1-R10).
- **فصل الأموال عن الكميات**: مقنن أعلاه — الدقة 18,6 للكميات/الصرف و18,4 للمال — لا مشاركة precision بلا سبب.
- **الحساب التطبيقي**: R1-R10 تمنع `+ - * /` على المال خارج Decimal — مغطاة بـ143 فحص انحدار في RP1 + 518 سابقة.

## 3. إجراء الترحيل (§7) — خطوات على سيرفر الإنتاج

```bash
# 0) نسخة احتياطية كاملة قبل أي شيء (مفروضة — القاعدة 5)
cp db/custom.db backups/pre-pg-$(date +%Y%m%d-%H%M).db

# 1) رفع PostgreSQL 16 (أو docker-compose.production.yml — RP4)
# 2) إنشاء القاعدة
createdb kayan   # أو: CREATE DATABASE kayan;

# 3) دفع سكيما الإنتاج (114 حقل بدقة مقننة)
DATABASE_URL="postgresql://kayan:***@localhost:5432/kayan" \
  bunx prisma db push --schema prisma/schema.postgresql.prisma

# 4) نقل البيانات + تحقق آلي (عدّادات كل جدول + بصمات مالية)
PG_URL="postgresql://kayan:***@localhost:5432/kayan" \
  bun scripts/rp2-migrate-sqlite-to-pg.mjs
# → يجب أن ينتهي بـ: RP2_MOVE_VERIFIED

# 5) توليد عميل الإنتاج وتشغيل
DATABASE_URL="postgresql://…" bunx prisma generate
DATABASE_URL="postgresql://…" bun run build && DATABASE_URL="postgresql://…" npm run start

# 6) مطابقة مالية (مستنسخة من phase3-reconcile): إجماليات الفواتير/الأرصدة/الصندوق
#    قبل vs بعد — أي فرق = فشل وتراجع
```

**خطة التراجع (Rollback)**: `.env` يعود إلى `file:../db/custom.db` (SQLite لم يُمس) + إعادة تشغيل — التراجع < دقيقة، لذا الكات أوفر آمن.

**نقطة اللاعودة**: بعد بدء الكتابة على PG يجب إيقاف الكتابة على SQLite نهائياً (القاعدة الوحيدة تصبح PG) — يُنفذ بتغيير `.env` فقط.

## 4. ناقل البيانات (`scripts/rp2-migrate-sqlite-to-pg.mjs`)

- قراءة SQLite readonly (`node:sqlite`) → كتابة `pg` بدفعات 200 داخل معاملات.
- ترتيب طوبولوجي بالأجنبية + `TRUNCATE … RESTART IDENTITY CASCADE` (إعادة تشغيل نظيفة).
- تحويل الأنواع: bool 0/1→true/false · datetime نص/مللي ثانية→Date · numeric نص دقيق كما هو.
- ضبط التسلسلات `setval` لكل serial بعد الإدراج.
- **تحقق غير قابل للتجاوز**: عدّادات كل جدول SQLite↔PG + بصمات مالية (عدد الفواتير · Σ grand_total · Σ أرصدة المخزون · Σ طبقات OPEN) — `RP2_MOVE_VERIFIED` فقط عند التطابق التام.
- ⚠️ **حالة الصحة**: السكربت مكتمل لكنه لم يُشغَّل على PG حقيقي (لا PG في هذه البيئة) — تشغيله وتسجيل نتيجته بند إلزامي في تقرير القبول النهائي (RP7).

## 5. Definition of Done — الحالة

| البند | الحالة |
|---|---|
| PostgreSQL schema = PASS | ✅ `prisma validate` صالحة (114 حقل بدقة مقننة) |
| No financial Float = PASS | ✅ مُثبت آلياً (T10a + إعادة فحص) |
| Decimal precision = PASS | ✅ 73/36/5 موزعة وفق السياسة |
| Migration = PASS | ⏳ **بانتظار سيرفر PG** — الأداة جاهزة، التنفيذ موثق خطوة بخطوة أعلاه |
| Rollback plan = PASS | ✅ موثق (< دقيقة، SQLite لا يُمس) |
| Financial reconciliation = PASS | ⏳ ضمن خطوة 4/6 أعلاه عند التنفيذ |
