# MULTI-BRANCH AUDIT — تدقيق النطاقات (شركة/فرع/مستودع) قبل التعديل

> المرحلة 0 من MASTER PROMPT — Multi-Company / Multi-Branch Access Control.
> تاريخ التدقيق: 2026-09-15 · قاعدة الفحص: db/custom.db + src/lib/auth.ts + prisma/schema.prisma

## 1) What Exists — الموجود فعليًا

### قاعدة البيانات (49 موديلًا)
| الجدول | الحالة |
|---|---|
| `companies` | موجودة (شركة واحدة مزروعة) — **بدون حقل `code`** |
| `branches` | موجودة (BGW بغداد + BSR البصرة) مع `@@unique([companyId, code, deletedAt])` |
| `warehouses` | موجودة (WH-MAIN + REP-AHMED كلاهما في فرع بغداد) |
| `users` | `company_id` إجباري + `branch_id` اختياري (فرع واحد فقط) — **بدون scope_type أو last_login_ip** |
| `roles / permissions / role_permissions / user_roles` | RBAC كامل 230 كودًا · `user_roles.branch_id` (NULL = كل الفروع) غير مستعمل في الفحص |
| `user_warehouse_access` | موجودة (can_read/can_operate) ومفعّلة في السلسلة الأمنية |
| `refresh_tokens / user_devices / audit_logs` | موجودة · `audit_logs` يسجل LOGIN/LOCKOUT/CREATE... |

### سلسلة الأمان الحالية (src/lib/auth.ts)
1. `authenticate()` — JWT HS256 (15د) → مستخدم + أدوار + صلاحيات + مستودعات من القاعدة.
2. `requirePermission(module.action)` — 230 كود صلاحية.
3. **Company scope**: يُشتق من `sub` التوكن فقط (`companyId = user.companyId`) — لا يُقبل من الطلب ✓
4. **Warehouse scope**: `user_warehouse_access` → `SCOPE_002` عند النفاذ لمستودع خارجي ✓

### ما يفرضه الخادم اليوم فعليًا
- نطاق الشركة على كل الاستعلامات (`companyId` من التوكن).
- نطاق المستودع عند البيع/التحويل/الجرد/المشتريات.
- قفل الحساب، حد المعدل، تدقيق لاتحققي، مزامنة idempotent.

## 2) What Is Missing — الناقص (يجب إضافته)

| # | الفجوة | الأثر |
|---|---|---|
| 1 | **لا يوجد `scope_type`** (GLOBAL/COMPANY/BRANCH/WAREHOUSE/SALES_REP) على المستخدم | لا يمكن تمييز المدير المركزي من مستخدم فرع |
| 2 | **لا يوجد `user_branch_access`** (متعدد الفروع) — المستخدم مرتبط بـ `branch_id` واحد | لا دعم للمدير الإقليمي (بغداد+البصرة) |
| 3 | **لا يوجد `user_company_access`** (متعدد الشركات) | GLOBAL لا يستطيع رؤية أكثر من شركة |
| 4 | **الفرع النشط غير موجود في الجلسة** — لا مطالبة `brn` في JWT | مبدّل الفرع مستحيل؛ نطاق الفرع غير مفروض |
| 5 | **فلاتر الفرع غير مطبقة على الاستعلامات** — فواتير/عملاء/تقارير تعرض كل فروع الشركة | مستخدم بغداد يرى البصرة (تسريب أفقي) |
| 6 | **لا حماية IDOR بنطاق الفرع** — `GET /sales/invoices/[id]` تفحص الشركة فقط | قراءة فاتورة فرع آخر بالتخمين |
| 7 | **لا مبدّل فرع/شركة** في الواجهة ولا endpoints للتبديل | المرحلتان 15/16 غير مغطاة |
| 8 | **لا أحداث تدقيق للنطاق**: BRANCH_SELECTED/BRANCH_SWITCHED/ACCESS_DENIED | المرحلة 17 غير مغطاة |
| 9 | **`Company.code` غير موجود** (قيود المرحلة 39) | كود شركة فريد مطلوب |
| 10 | **لا `last_login_ip` / جهاز عند الدخول** (UserDevice موجود غير مربوط بالدخول) | المرحلة 3 جزئية |
| 11 | `Customer` **بدون `branch_id`** ولا `customer_type` | عزل عملاء الفروع + الزبون المتردد غير ممكنين |
| 12 | فاتورة البيع **بدون لقطة نوع العميل** | العرض والتقارير لا يميزون المتردد |
| 13 | الفاتورة النقدية **لا تسجل حركة صندوق** (الدفع النقدي لا يدخل Cashbox) | المرحلة 31 مخالفة |

## 3) What Must Change — التغييرات المطلوبة

### مخطط قاعدة البيانات (إضافي بحت — لا كسر رجعية)
```
Company        + code (unique, nullable في DB — إجباري على مستوى التطبيق)
User           + scope_type (GLOBAL|COMPANY|BRANCH|WAREHOUSE|SALES_REP, default BRANCH)
               + sales_rep_id (ربط نطاق مندوب)
               + last_login_ip / last_login_user_agent
UserBranchAccess (جدول جديد: userId+branchId+can_read+can_operate, unique(userId,branchId))
UserCompanyAccess (جدول جديد: userId+companyId+is_primary, unique(userId,companyId))
Customer       + branch_id (nullable + backfill) + customer_type (REGISTERED|WALK_IN|CASH_CUSTOMER|GUEST)
               + converted_from_walk_in + converted_at
SalesInvoice   + customer_type (لقطة) + walkin_name/phone/address (معلومات اختيارية §23)
RefreshToken   + active_branch_id (حفظ سياق الجلسة عبر التحديث)
```

### محرك النطاق (جديد `lib/scope.ts`)
- Session يكتسب: `scopeType, companyIds, branchIds, warehouseIds, activeBranchId`.
- قاعدة الفعالية: `activeBranchId ? [activeBranchId] : branchIds` — الكتابة دائمًا ضمن المجموعة الفعالة.
- أخطاء جديدة: `SCOPE_003` (خرق نطاق فرع — 403 للكتابة) · 404 `VAL_003` للقراءة الخارجية (منع التخمين).
- JWT يكتسب `brn` (الفرع النشط) و`scope`; refresh يحافظ عليهما.

### نقاط النهاية
- `POST /auth/login` يقبل `branch_id`/`company_id` اختياريين؛ متعدد الفروع بلا اختيار → `requires_branch_selection` + قائمة الفروع (بدون توكنات).
- `POST /auth/switch-branch` · `POST /auth/switch-company` (تبديل سياق مع تدقيق).
- `/auth/me` يعيد النطاق الكامل + التسميات القابلة للضبط لأنواع العملاء.

## 4) Migration Risks — مخاطر الترحيل

| الخطر | التخفيف |
|---|---|
| مستخدمون حاليون بلا scope_type | default `BRANCH` + إنشاء UserBranchAccess لفرعهم الحالي أثناء البذر (admin → GLOBAL) |
| عملاء حاليون بلا branch_id | Backfill إلى أول فرع للشركة (BGW) في سكربت البذر — idempotent |
| فواتير حالية بلا customer_type | default `REGISTERED` (متوافق §41 — لا أحد يتحول لمتردد) |
| توكنات قديمة بلا `brn` | authenticate يرجع للافتراضي (فرع واحد تلقائيًا، وإلا كل الفروع المسموحة) |
| SQLite vs PostgreSQL | أعمدة TEXT/Int فقط — نفس الأسماء، لا تغييرات نوعية خطرة |
| حركة الصندوق الجديدة للفواتير النقدية | تُسجل refType=SALES_INVOICE — لا تعيد احتساب أرصدة قديمة (تطبق على الجديد فقط) |

## 5) Backward Compatibility — الرجعية

- كل العملاء الحاليون يبقون `REGISTERED` ولن يُلمس رصيدهم.
- كل المستخدمين الحاليين يحتفظون بأدوارهم وصلاحياتهم ومستودعاتهم.
- واجهات API القديمة تعمل بنفس الأشكال — الإضافات كلها optional fields.
- JWT القديم صالح حتى انتهاء مدته (15 دقيقة) ثم يُصدر الجديد بالمطالب الإضافية.
- أطقم الاختبارات السابقة (24+34+33+48+40+50) يجب أن تبقى خضراء — انحدار إجباري بعد التنفيذ.

## 6) قرار التصميم الأساسي (نطاق = علاقات، وليس حقلاً واحدًا)

```
scopeType   الفروع الفعالة                    المستودعات الفعالة
GLOBAL      كل فروع الشركات الممنوحة          كل مستودعاتها
COMPANY     كل فروع شركته                     كل مستودعات شركته
BRANCH      user_branch_access ∪ {branch_id}  مستودعات تلك الفروع
WAREHOUSE   فروع المستودعات الممنوحة          user_warehouse_access
SALES_REP   كالـ BRANCH + فلاتر مندوب حسب الصلاحية (حالتها القائمة)
```
الصلاحية (Role) منفصلة عن النطاق (Scope) — المرحلة 10: مدير فرع بصلاحيات كاملة على فرعه فقط.
