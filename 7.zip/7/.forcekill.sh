#!/bin/bash
# find who owns :3000 and kill hard
PIDS=$(ss -tlnp | grep ':3000' | grep -oP 'pid=\K[0-9]+' | sort -u)
echo "owner pids: $PIDS"
for p in $PIDS; do
  kill -9 $p 2>/dev/null && echo "killed -9 $p"
done
sleep 3
ss -tlnp | grep ':3000' && echo 'STILL_BUSY' || echo 'PORT_FREE'