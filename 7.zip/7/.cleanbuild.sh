#!/bin/bash
cd /home/ahmedr/maydanerp
for p in $(pgrep -f 'next-server') $(pgrep -f 'next start'); do
  CMDLINE=$(tr '\0' ' ' < /proc/$p/cmdline 2>/dev/null)
  if echo "$CMDLINE" | grep -q ':3000\|next-server'; then kill $p 2>/dev/null; fi
done
sleep 2
rm -rf .next
echo '=== clean build ==='
npm run build >/tmp/cleanbuild.txt 2>&1
echo "BUILD_EXIT=$?"
tail -3 /tmp/cleanbuild.txt
echo '=== check built chunks ==='
grep -rl 'argon2id' .next/server/chunks/ssr/ 2>/dev/null | head -3
echo '=== start server ==='
nohup setsid npx next start -p 3000 >/home/ahmedr/maydanerp/app.log 2>&1 < /dev/null &
sleep 8
ss -tlnp 2>/dev/null | grep :3000
curl -s -o /dev/null -w 'HEALTH HTTP %{http_code}\n' http://localhost:3000/api/v1/health