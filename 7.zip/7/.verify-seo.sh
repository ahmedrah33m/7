#!/bin/bash
base="http://127.0.0.1:3000"
echo "=== robots.txt ==="
curl -s -H "Host: kayaniq.com" "$base/robots.txt"
echo ""
echo "=== sitemap.xml ==="
curl -s -H "Host: kayaniq.com" "$base/sitemap.xml"
echo ""
echo "=== opengraph-image (checks) ==="
curl -s -o /tmp/og.png -w "HTTP=%{http_code} TYPE=%{content_type} SIZE=%{size_download}\n" -H "Host: kayaniq.com" "$base/opengraph-image"
echo "=== home head meta (title/desc/og) ==="
curl -s -H "Host: kayaniq.com" "$base/" | grep -oE '<meta name="description"[^>]*>|<title>[^<]*</title>|property="og:[^"]*"[^>]*>|application/ld\+json' | head -12
echo "=== og:image tag ==="
curl -s -H "Host: kayaniq.com" "$base/" | grep -oE '<meta property="og:image"[^>]*>' | head -2