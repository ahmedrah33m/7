#!/bin/bash
cd /home/ahmedr/maydanerp
npx tsc --noEmit -p tsconfig.json >/tmp/tsc.txt 2>&1
echo "TSC_LINES=$(wc -l </tmp/tsc.txt)"
npx eslint src/components/login-form.tsx >/tmp/eslint.txt 2>&1
echo "LINT done"
npm run build >/tmp/build.txt 2>&1
echo "BUILD_EXIT=$?"
tail -6 /tmp/build.txt