#!/bin/bash
cd /home/ahmedr/maydanerp
echo "dynamic-year: $(grep -c 'new Date().getFullYear()' src/components/login-form.tsx)"
echo "pill-frame: $(grep -c 'rounded-full bg-white/5' src/components/login-form.tsx)"
npx eslint src/components/login-form.tsx >/tmp/eslint.txt 2>&1
echo "LINT_EXIT=$?"
npm run build >/tmp/build.txt 2>&1
echo "BUILD_EXIT=$?"
tail -2 /tmp/build.txt
echo '=== restart ==='
for p in $(pgrep -f 'next-server') $(pgrep -f 'next start'); do
  CMDLINE=$(tr '\0' ' ' < /proc/$p/cmdline 2>/dev/null)
  if echo "$CMDLINE" | grep -q ':3000'; then kill $p 2>/dev/null; fi
done
sleep 3
nohup setsid npx next start -p 3000 >/home/ahmedr/maydanerp/app.log 2>&1 < /dev/null &
sleep 8
ss -tlnp 2>/dev/null | grep :3000
curl -s -o /dev/null -w 'HEALTH HTTP %{http_code}\n' http://localhost:3000/api/v1/health
echo '=== built chunk check ==='
grep -rl 'جميع الحقوق محفوظة' .next/static/chunks/ 2>/dev/null | head -2