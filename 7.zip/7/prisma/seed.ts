// =====================================================================
// Phase 0 seeder — CLI wrapper.
//   The actual seeding logic lives in src/lib/seed.ts (shared with the
//   server's self-healing boot hook). Run: bun prisma/seed.ts
// =====================================================================

import { seedDatabase } from "../src/lib/seed";
import { db } from "../src/lib/db";

seedDatabase((m) => console.log(m))
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
