# نظام المبيعات والتوزيع — كود المرحلة 0 (Foundation)

> بناء فعلي للمرحلة 0 وفق `MASTER_PROMPT.md` §6 — Next.js 16 App Router + TypeScript + Prisma.
> **نتيجة اختبارات القبول: 24/24 ✅** (`bun scripts/phase0-verify.ts`)

## ما المنجز في هذه المرحلة

| المكون | التفاصيل |
|---|---|
| مخطط Prisma من ERD | 14 جدولًا: companies, branches, warehouses, users, roles, permissions, role_permissions, user_roles, user_warehouse_access, user_devices, refresh_tokens, audit_logs, settings, document_sequences — أسماء مطابقة 1:1 للـ ERD عبر `@@map` |
| المصادقة | JWT وصول 15 دقيقة (jose HS256) + رمز تحديث دوراني 7 أيام (sha256 مخزّن) + كشف إعادة الاستخدام وإبطال السلسلة كاملة |
| تجزئة كلمات المرور | argon2id (hash-wasm — بارامترات OWASP: 19MiB/3 تكرارات) |
| قفل الحساب | 5 محاولات فاشلة → قفل 15 دقيقة (AUTH_004) + عدّاد + تدقيق |
| RBAC | 157 صلاحية `module.action` · 11 دورًا نظاميًا · سلسلة فحوص على الخادم: توثيق → صلاحية → نطاق شركة → نطاق مستودع |
| مظروف الأخطاء | `{ success, code, message, errors }` + مصفوفة أكواد موحدة (AUTH/PERM/SCOPE/VAL/STOCK/CREDIT/RATE/SRV) |
| سجل التدقيق | جدول لاتحققي لكل عملية حساسة مع old/new values و IP و user-agent |
| ترقيم المستندات | خدمة `nextDocumentNumber()` — صيغة INV-2026-000001 (تُستهلك من المرحلة 3) |
| حدود المعدل | 120 طلب/د لكل مستخدم · 600/د للمزامنة (قابلة للاستبدال بـ Redis في الإنتاج) |
| Seeders | كتالوج الصلاحيات + 11 دورًا + شركة/فرع/مستودعان + 5 مستخدمين + إعدادات + متسلسلات |
| CI | `.github/workflows/ci.yml` — lint → db push → seed → boot → 24 اختبار قبول |

## نقاط النهاية (المرحلة 0)

```
GET  /api/v1/health              عام — فحص جاهزية (محمي بحد معدل)
POST /api/v1/auth/login          عام — إصدار access+refresh، قفل بعد 5 محاولات
POST /api/v1/auth/refresh        عام — دوران الرمز + كشف إعادة الاستخدام
POST /api/v1/auth/logout         عام — إبطال السلسلة أو كل الجلسات
GET  /api/v1/auth/me             توثيق — الملف + الصلاحيات + المستودعات
GET  /api/v1/admin/users         system.users.view
GET  /api/v1/admin/roles         system.roles.view
GET  /api/v1/admin/permissions   system.roles.view
GET  /api/v1/admin/audit-logs    audit.audit_logs.view
```

## حسابات الدخول (بيئة تجريبية)

| المستخدم | كلمة المرور | الدور |
|---|---|---|
| `admin` | `Admin@123` | المالك — كل الصلاحيات |
| `auditor` | `Auditor@123` | مراجع — عرض + تدقيق |
| `cashier` | `Cashier@123` | كاشير — صلاحيات دنيا (لتجربة الـ 403) |
| `rep.ahmed` | `Rep@12345` | مندوب — مخزنه فقط |
| `lockdemo` | `Lock@12345` | لاختبار قفل الحساب |

## التشغيل

```bash
bun install
cp .env.example .env         # عدّل الأسرار
bun run db:push              # تطبيق المخطط
bun prisma/seed.ts           # البيانات الأساسية
bun run dev                  # http://localhost:3000
bun scripts/phase0-verify.ts # اختبارات القبول (24 فحصًا)
```

## ملاحظة الإنتاج

- بيئة التجربة SQLite؛ الإنتاج PostgreSQL 16 عبر حزمة النشر `sales-distribution-system/` (docker-compose) — نفس أسماء الجداول والأعمدة، يكفي تغيير provider و `DATABASE_URL`.
- الأعمدة من نوع JSONB/INET في PostgreSQL تُستبدل TEXT في SQLite بنفس السلوك الوظيفي.
- الفهارس الجزئية (مثل UNIQUE(email) WHERE email IS NOT NULL) تُطبق عبر init.sql في حزمة النشر.
