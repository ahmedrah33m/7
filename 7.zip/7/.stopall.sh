#!/bin/bash
# Stop all next start -p 3000 processes
for p in $(pgrep -f 'next-server') $(pgrep -f 'next start'); do
  CMDLINE=$(tr '\0' ' ' < /proc/$p/cmdline 2>/dev/null)
  if echo "$CMDLINE" | grep -q ':3000\|next-server'; then
    kill $p 2>/dev/null
    echo "killed $p"
  fi
done
sleep 3
ss -tlnp 2>/dev/null | grep :3000 && echo 'PORT_STILL_BUSY' || echo 'PORT_FREE'