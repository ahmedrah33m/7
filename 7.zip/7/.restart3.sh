#!/bin/bash
PID=$(ss -tlnp | grep ':3000 ' | grep -oP 'pid=\K[0-9]+' | head -1)
echo "OLD_PID=${PID:-none}"
if [ -n "$PID" ]; then
  kill -9 "$PID" 2>/dev/null
  sleep 1
fi
cd /home/ahmedr/maydanerp
nohup setsid npx next start -p 3000 >app.log 2>&1 </dev/null &
echo "STARTED"