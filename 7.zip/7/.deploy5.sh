#!/bin/bash
cd /home/ahmedr/maydanerp
echo "border-xl: $(grep -c 'border-2 border-amber-400/50' src/components/login-form.tsx)"
npx eslint src/components/login-form.tsx >/tmp/eslint.txt 2>&1
echo "LINT_EXIT=$?"
npm run build >/tmp/build.txt 2>&1
echo "BUILD_EXIT=$?"
tail -2 /tmp/build.txt
echo '=== restart ==='
PIDS=$(ss -tlnp | grep ':3000' | grep -oP 'pid=\K[0-9]+' | sort -u)
for p in $PIDS; do kill -9 $p 2>/dev/null && echo "killed $p"; done
sleep 3
nohup setsid npx next start -p 3000 >/home/ahmedr/maydanerp/app.log 2>&1 < /dev/null &
sleep 8
ss -tlnp | grep ':3000'
curl -s -o /dev/null -w 'HEALTH HTTP %{http_code}\n' http://localhost:3000/api/v1/health