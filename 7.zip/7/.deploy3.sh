#!/bin/bash
cd /home/ahmedr/maydanerp
echo "rights-line in src: $(grep -c 'جميع الحقوق محفوظة' src/components/login-form.tsx)"
echo "midaniq in src: $(grep -c 'midaniq' src/components/login-form.tsx)"
npx eslint src/components/login-form.tsx >/tmp/eslint.txt 2>&1
echo "LINT_EXIT=$?"
npm run build >/tmp/build.txt 2>&1
echo "BUILD_EXIT=$?"
tail -3 /tmp/build.txt
echo '=== built check ==='
grep -rl 'جميع الحقوق محفوظة' .next/server/chunks/ssr/ 2>/dev/null | head -3