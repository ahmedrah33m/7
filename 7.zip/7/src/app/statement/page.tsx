"use client";

import * as React from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { api } from "@/lib/client-api";
import { formatIQD } from "@/lib/utils";
import { Search, FileText, TrendingUp, TrendingDown, Wallet, Send, Mail } from "lucide-react";

interface StatementRow {
  date: string; kind: string; ref: string; description: string;
  debit: number; credit: number; running: number;
}
interface StatementData {
  customer?: { id: number; code: string; name: string; phone: string | null; balance: number; creditLimit: number; creditDays: number };
  supplier?: { id: number; code: string; name: string; phone: string | null; balance: number };
  rows: StatementRow[];
  totals: { debit: number; credit: number };
  closing_balance: number;
  opening_balance?: number;
}

const KIND_CONFIG: Record<string, { color: string; label: string; icon: "up" | "down" | "neutral" }> = {
  INVOICE: { color: "bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-300", label: "فاتورة", icon: "up" },
  RETURN: { color: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300", label: "مرتجع", icon: "down" },
  COLLECTION: { color: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300", label: "تحصيل", icon: "down" },
  PAYMENT: { color: "bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300", label: "دفعة", icon: "down" },
};

/**
 * Phase 41 — Interactive visual statement.
 * Modern timeline-style customer/supplier statement with clickable rows,
 * colored badges per transaction type, running balance visualization.
 */
export default function StatementPage() {
  const [actorType, setActorType] = React.useState<"customer" | "supplier">("customer");
  const [actorId, setActorId] = React.useState<number | null>(null);
  const [search, setSearch] = React.useState("");
  const [actors, setActors] = React.useState<Array<{ id: number; name: string; code: string; balance: number }>>([]);
  const [data, setData] = React.useState<StatementData | null>(null);
  const [loading, setLoading] = React.useState(false);

  // Debounced actor search
  React.useEffect(() => {
    if (!search.trim()) return;
    const t = setTimeout(async () => {
      const endpoint = actorType === "customer" ? "/api/v1/customers" : "/api/v1/suppliers";
      const { body } = await api<{ rows?: Array<{ id: number; name: string; code: string; balance: number }> } | Array<{ id: number; name: string; code: string; balance: number }> >(`${endpoint}?search=${encodeURIComponent(search)}&per_page=10`);
      if (body.success && body.data) {
        const list = Array.isArray(body.data) ? body.data : (body.data as { rows: Array<{ id: number; name: string; code: string; balance: number }> }).rows;
        setActors(list ?? []);
      }
    }, 300);
    return () => clearTimeout(t);
  }, [search, actorType]);

  // Load statement when actorId changes
  React.useEffect(() => {
    if (!actorId) { setData(null); return; }
    setLoading(true);
    api<StatementData>(`/api/v1/finance/statements/${actorType}/${actorId}`)
      .then(({ body }) => { if (body.success && body.data) setData(body.data); })
      .finally(() => setLoading(false));
  }, [actorId, actorType]);

  async function emailStatement() {
    if (!actorId || actorType !== "customer") return;
    const { body } = await api(`/api/v1/finance/statements/customer/${actorId}/email`, {
      method: "POST", body: JSON.stringify({}),
    });
    if (body.success) {
      const d = body.data as { sent: boolean; public_url: string; target_email?: string; message: string };
      toast.success(d.message);
      if (d.public_url) window.open(d.public_url, "_blank");
    } else toast.error(body.message ?? "فشل الإرسال");
  }

  const actor = data?.customer ?? data?.supplier;
  const maxRunning = data?.rows.length ? Math.max(...data.rows.map((r) => Math.abs(r.running))) : 1;

  return (
    <div className="min-h-screen bg-muted/30 p-4">
      <div className="max-w-5xl mx-auto space-y-4">
        <header>
          <h1 className="text-2xl font-bold flex items-center gap-2"><FileText className="w-6 h-6 text-primary" /> كشف حساب تفاعلي</h1>
          <p className="text-sm text-muted-foreground">عرض بصري حديث لحركة العميل/المورد برصيد متجدد ملوّن</p>
        </header>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">اختر الطرف</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex gap-2">
              <Button
                size="sm"
                variant={actorType === "customer" ? "default" : "outline"}
                onClick={() => { setActorType("customer"); setActorId(null); setData(null); }}
              >عميل</Button>
              <Button
                size="sm"
                variant={actorType === "supplier" ? "default" : "outline"}
                onClick={() => { setActorType("supplier"); setActorId(null); setData(null); }}
              >مورد</Button>
            </div>
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={`بحث عن ${actorType === "customer" ? "عميل" : "مورد"} بالاسم أو الكود...`}
                className="h-9 w-full rounded-md border bg-background pr-10 px-3 text-sm"
              />
            </div>
            {actors.length > 0 && (
              <div className="grid gap-2 sm:grid-cols-2">
                {actors.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => setActorId(a.id)}
                    className={"text-right p-2 rounded border hover:bg-accent transition-colors " + (actorId === a.id ? "border-primary bg-accent" : "")}
                  >
                    <div className="text-sm font-medium">{a.name}</div>
                    <div className="text-xs text-muted-foreground flex justify-between">
                      <span dir="ltr">{a.code}</span>
                      <span dir="ltr">{formatIQD(a.balance)}</span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {loading && <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div>}

        {data && actor && (
          <>
            {/* Header card */}
            <Card>
              <CardContent className="pt-4 grid sm:grid-cols-3 gap-3">
                <div>
                  <div className="text-xs text-muted-foreground">{actorType === "customer" ? "العميل" : "المورد"}</div>
                  <div className="text-lg font-bold">{actor.name}</div>
                  <div className="text-xs text-muted-foreground font-mono" dir="ltr">{actor.code}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">الرصيد الحالي</div>
                  <div className="text-lg font-bold text-amber-600" dir="ltr">{formatIQD(actor.balance)}</div>
                </div>
                <div className="flex flex-wrap gap-2 items-start">
                  {actorType === "customer" && (
                    <>
                      <a href={`/api/v1/finance/statements/customer/${actorId}/pdf`} target="_blank">
                        <Button size="sm" variant="outline"><FileText className="w-3.5 h-3.5 ml-1" /> PDF</Button>
                      </a>
                      <Button size="sm" variant="outline" onClick={emailStatement}>
                        <Mail className="w-3.5 h-3.5 ml-1" /> بريد
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Timeline */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">الحركات ({data.rows.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {data.rows.length === 0 ? (
                  <div className="py-8 text-center text-muted-foreground">لا حركات</div>
                ) : (
                  <div className="space-y-2">
                    {/* Opening balance */}
                    {data.opening_balance != null && data.opening_balance !== 0 && (
                      <div className="flex items-center gap-3 p-2 rounded border bg-muted/30">
                        <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                          <Wallet className="w-4 h-4" />
                        </div>
                        <div className="flex-1">
                          <div className="text-sm font-medium">رصيد افتتاحي</div>
                          <div className="text-xs text-muted-foreground">{new Date(data.rows[0]?.date).toLocaleDateString("ar-IQ")}</div>
                        </div>
                        <div className="text-sm font-bold" dir="ltr">{formatIQD(data.opening_balance)}</div>
                      </div>
                    )}

                    {data.rows.map((r, i) => {
                      const cfg = KIND_CONFIG[r.kind] ?? { color: "bg-muted text-muted-foreground", label: r.kind, icon: "neutral" as const };
                      const barWidth = maxRunning > 0 ? Math.abs(r.running) / maxRunning * 100 : 0;
                      return (
                        <div key={i} className="flex items-center gap-3 p-2 rounded border hover:shadow-sm transition-shadow">
                          <div className={"w-10 h-10 rounded-full flex items-center justify-center " + cfg.color}>
                            {cfg.icon === "up" ? <TrendingUp className="w-4 h-4" /> : cfg.icon === "down" ? <TrendingDown className="w-4 h-4" /> : <Wallet className="w-4 h-4" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <Badge variant="secondary" className={"text-[10px] " + cfg.color}>{cfg.label}</Badge>
                              <span dir="ltr" className="text-xs font-mono text-muted-foreground">{r.ref}</span>
                            </div>
                            <div className="text-sm truncate">{r.description || "—"}</div>
                            <div className="text-xs text-muted-foreground">{new Date(r.date).toLocaleString("ar-IQ")}</div>
                          </div>
                          <div className="text-left">
                            <div className="flex gap-2 text-xs">
                              {r.debit > 0 && <span className="text-red-600" dir="ltr">مدين {formatIQD(r.debit)}</span>}
                              {r.credit > 0 && <span className="text-emerald-600" dir="ltr">دائن {formatIQD(r.credit)}</span>}
                            </div>
                            <div className="mt-1 flex items-center gap-2">
                              <div className="w-24 h-1.5 bg-muted rounded-full overflow-hidden">
                                <div className={"h-full rounded-full " + (r.running < 0 ? "bg-emerald-500" : "bg-amber-500")} style={{ width: `${barWidth}%` }} />
                              </div>
                              <div className="text-sm font-bold" dir="ltr">{formatIQD(r.running)}</div>
                            </div>
                          </div>
                        </div>
                      );
                    })}

                    {/* Closing balance */}
                    <div className="flex items-center gap-3 p-3 rounded border-2 border-primary bg-primary/5">
                      <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground">
                        <Wallet className="w-4 h-4" />
                      </div>
                      <div className="flex-1">
                        <div className="text-sm font-medium">الرصيد الختامي</div>
                        <div className="text-xs text-muted-foreground">إجمالي مدين: {formatIQD(data.totals.debit)} · إجمالي دائن: {formatIQD(data.totals.credit)}</div>
                      </div>
                      <div className="text-lg font-bold text-primary" dir="ltr">{formatIQD(data.closing_balance)}</div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}
