"use client";

import * as React from "react";
import { formatDateTime } from "@/lib/utils";
import { BadgeCheck, ShieldX, Loader2, Printer, Phone, MapPin, Building2, BadgeCheck as VerifiedIcon } from "lucide-react";

// =====================================================================
// الصفحة العامة للمستند المشترك (§37 + مشاركة العملاء):
//   kind=INVOICE    → فاتورة كاملة (بنود + إجماليات + مدفوع/متبقي + تسليم)
//   kind=QUOTATION  → عرض سعر (بنود + إجماليات + صلاحية)
// الرمز هو التصريح — لا جلسة ولا بيانات حساسة (لا تكاليف ولا أرصدة تاريخية).
// =====================================================================

interface ShareLine {
  id: number; product: string; unit: string; qty: number;
  package_qty: number; loose_qty: number; package_type: string | null;
  unit_label: string; package_unit_label: string | null;
  unit_price: number; discount_pct: number; discount_amount: number; line_total: number;
}
interface ShareDoc {
  valid: boolean;
  message?: string;
  kind?: "INVOICE" | "QUOTATION";
  invoice_number?: string; quotation_number?: string;
  invoice_date?: string; due_date?: string | null;
  quote_date?: string; valid_until?: string | null;
  status_ar?: string; sale_type_ar?: string;
  company?: { name: string; phone: string | null; address: string | null; has_logo: boolean };
  branch?: string | null;
  customer?: { name: string; shop_name: string | null };
  currency?: { code: string; exchange_rate: number | null };
  totals?: {
    subtotal: number; discount_total: number; tax_total: number; grand_total: number;
    paid_amount?: number; due_amount?: number;
  };
  delivery?: { receiver_name: string | null; delivered_at: string | null; signed_at: string | null };
  notes?: string | null;
  lines?: ShareLine[];
}

const n = (v: number) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(v);

function money(doc: ShareDoc, v: number): string {
  if (doc.currency?.code === "USD" && doc.currency.exchange_rate) return `$${n(v / doc.currency.exchange_rate)}`;
  return `${n(v)} د.ع`;
}

export default function VerifyPage({ params }: { params: Promise<{ token: string }> }) {
  const [token, setToken] = React.useState<string | null>(null);
  const [doc, setDoc] = React.useState<ShareDoc | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [logoOk, setLogoOk] = React.useState(true);

  React.useEffect(() => {
    params.then((p) => setToken(p.token));
  }, [params]);

  React.useEffect(() => {
    if (!token) return;
    setLogoOk(true);
    fetch(`/api/v1/verify/${token}`)
      .then((r) => r.json())
      .then((body) => setDoc(body?.data ?? { valid: false, message: "استجابة غير صالحة" }))
      .catch(() => setDoc({ valid: false, message: "تعذر الاتصال بخادم التحقق" }))
      .finally(() => setLoading(false));
  }, [token]);

  const isInvoice = doc?.kind === "INVOICE";
  const isQuotation = doc?.kind === "QUOTATION";
  const docNumber = doc?.invoice_number ?? doc?.quotation_number ?? "";
  const docDate = doc?.invoice_date ?? doc?.quote_date;

  const validUntilPassed = doc?.valid_until ? new Date(doc.valid_until).getTime() < Date.now() : false;

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-100 via-slate-50 to-slate-200 dark:from-slate-950 dark:via-slate-900 dark:to-slate-800 p-3 sm:p-6 print:bg-white print:p-0">
      <style>{`
        @media print {
          .no-print { display: none !important; }
          .print-sheet { box-shadow: none !important; border: none !important; max-width: 100% !important; margin: 0 !important; }
          body { background: white !important; }
        }
      `}</style>

      {loading ? (
        <div className="min-h-[60vh] flex items-center justify-center">
          <div className="text-center space-y-3">
            <Loader2 className="w-12 h-12 mx-auto text-primary animate-spin" />
            <p className="text-sm text-muted-foreground">جارٍ تحميل المستند...</p>
          </div>
        </div>
      ) : doc?.valid && (isInvoice || isQuotation) ? (
        <div className="mx-auto max-w-3xl space-y-4 print:max-w-none">
          {/* شريط التحقق */}
          <div className="no-print flex items-center justify-center gap-2 rounded-xl bg-emerald-600/10 border border-emerald-600/30 px-4 py-2 text-emerald-700 dark:text-emerald-400">
            <VerifiedIcon className="w-4 h-4" />
            <span className="text-xs font-semibold">
              {isInvoice ? "مستند موثّق — مسجّل في نظام ميدان لمبيعات والتوزيع" : "عرض سعر رسمي — صادر إلكترونياً عبر نظام ميدان"}
            </span>
          </div>

          <div className="print-sheet rounded-2xl bg-white dark:bg-slate-950 shadow-xl border overflow-hidden">
            {/* رأس المستند — الشركة */}
            <div className="flex items-start justify-between gap-4 border-b p-5 sm:p-6 bg-gradient-to-l from-primary/5 to-transparent">
              <div className="flex items-center gap-4 min-w-0">
                {doc.company?.has_logo && logoOk ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={`/api/v1/verify/${token}/logo`}
                    alt="شعار الشركة"
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl object-contain bg-white ring-1 ring-border shrink-0"
                    onError={() => setLogoOk(false)}
                  />
                ) : (
                  <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gradient-to-br from-primary to-amber-500 flex items-center justify-center shrink-0">
                    <Building2 className="w-7 h-7 text-white" />
                  </div>
                )}
                <div className="min-w-0">
                  <h1 className="text-lg sm:text-xl font-bold truncate">{doc.company?.name}</h1>
                  {doc.company?.phone && (
                    <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                      <Phone className="w-3 h-3" /><span dir="auto">{doc.company.phone}</span>
                    </div>
                  )}
                  {doc.company?.address && (
                    <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3" /><span className="truncate">{doc.company.address}</span>
                    </div>
                  )}
                </div>
              </div>
              <div className="text-left shrink-0">
                <div className={`inline-flex rounded-full px-3 py-1 text-xs font-bold ${isInvoice ? "bg-primary/10 text-primary" : "bg-amber-500/15 text-amber-700 dark:text-amber-400"}`}>
                  {isInvoice ? "فاتورة مبيعات" : "عرض سعر"}
                </div>
                <div dir="ltr" className="font-mono text-sm font-bold mt-1.5">{docNumber}</div>
                {doc.status_ar && <Badge_ label={doc.status_ar} tone={doc.status_ar === "معتمدة" || doc.status_ar === "مقبول" ? "ok" : doc.status_ar === "ملغاة" || doc.status_ar === "ملغى" || doc.status_ar === "مرفوضة" || doc.status_ar === "مرفوض" ? "bad" : "muted"} />}
              </div>
            </div>

            {/* معلومات المستند */}
            <div className="grid gap-3 p-5 sm:p-6 sm:grid-cols-2 text-sm">
              <Info label={isInvoice ? "تاريخ الفاتورة" : "تاريخ العرض"} value={docDate ? formatDateTime(docDate) : "—"} />
              {isInvoice && (
                <Info label="نوع البيع" value={doc.sale_type_ar ?? "—"} />
              )}
              {isQuotation && (
                <Info
                  label="صالح حتى"
                  value={doc.valid_until ? formatDateTime(doc.valid_until) : "غير محدد"}
                  tone={validUntilPassed ? "bad" : "ok"}
                />
              )}
              <Info
                label="العميل"
                value={`${doc.customer?.name ?? "—"}${doc.customer?.shop_name ? ` — ${doc.customer.shop_name}` : ""}`}
              />
              {doc.branch && <Info label="الفرع" value={doc.branch} />}
            </div>

            {/* البنود */}
            <div className="px-5 sm:px-6 pb-2">
              <div className="rounded-xl border overflow-x-auto">
                <table className="w-full text-sm min-w-[560px]">
                  <thead className="bg-muted/60 text-xs text-muted-foreground">
                    <tr>
                      <th className="p-2.5 font-medium text-right">#</th>
                      <th className="p-2.5 font-medium text-right">المنتج</th>
                      <th className="p-2.5 font-medium text-center">الكمية</th>
                      <th className="p-2.5 font-medium text-center">السعر</th>
                      <th className="p-2.5 font-medium text-center">الخصم</th>
                      <th className="p-2.5 font-medium text-left">الإجمالي</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(doc.lines ?? []).map((l, i) => (
                      <tr key={l.id} className="border-t">
                        <td className="p-2.5 text-xs text-muted-foreground">{i + 1}</td>
                        <td className="p-2.5 font-medium">
                          {l.product}
                          {isInvoice && l.package_qty > 0 && (
                            <div className="text-[11px] text-muted-foreground mt-0.5">
                              <span dir="ltr">{n(l.package_qty)} {l.package_unit_label ?? l.package_type ?? "عبوة"} + {n(l.loose_qty)} {l.unit_label}</span>
                            </div>
                          )}
                        </td>
                        <td className="p-2.5 text-center" dir="ltr">{n(l.qty)}</td>
                        <td className="p-2.5 text-center" dir="ltr">{money(doc, l.unit_price)}</td>
                        <td className="p-2.5 text-center text-xs" dir="ltr">
                          {l.discount_pct > 0 ? `${n(l.discount_pct)}%` : l.discount_amount > 0 ? money(doc, l.discount_amount) : "—"}
                        </td>
                        <td className="p-2.5 text-left font-semibold" dir="ltr">{money(doc, l.line_total)}</td>
                      </tr>
                    ))}
                    {!doc.lines?.length && (
                      <tr><td colSpan={6} className="p-4 text-center text-xs text-muted-foreground">لا توجد بنود</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* الإجماليات */}
            <div className="p-5 sm:p-6 grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5 text-sm">
                <Row label="المجموع" value={money(doc, doc.totals?.subtotal ?? 0)} />
                {(doc.totals?.discount_total ?? 0) > 0 && <Row label="الخصم" value={`− ${money(doc, doc.totals!.discount_total)}`} tone="ok" />}
                {(doc.totals?.tax_total ?? 0) > 0 && <Row label="الضريبة" value={money(doc, doc.totals!.tax_total)} />}
              </div>
              <div className="rounded-xl border bg-muted/30 p-4 space-y-2">
                <Row label="الإجمالي النهائي" value={money(doc, doc.totals?.grand_total ?? 0)} bold />
                {isInvoice && (
                  <>
                    <Row label="المدفوع" value={money(doc, doc.totals?.paid_amount ?? 0)} />
                    {(doc.totals?.due_amount ?? 0) > 0 ? (
                      <Row label="المتبقي" value={money(doc, doc.totals!.due_amount!)} tone="bad" bold />
                    ) : (
                      <div className="text-xs text-emerald-600 font-semibold pt-1">✓ مسددة بالكامل</div>
                    )}
                  </>
                )}
              </div>
            </div>

            {/* التسليم (فواتير فقط) */}
            {isInvoice && (doc.delivery?.receiver_name || doc.delivery?.signed_at) && (
              <div className="mx-5 sm:mx-6 mb-5 rounded-xl border bg-emerald-500/5 p-3 text-xs space-y-1">
                <div className="font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5">
                  <BadgeCheck className="w-3.5 h-3.5" /> إثبات التسليم
                </div>
                {doc.delivery?.receiver_name && <div>المستلم: <span className="font-semibold">{doc.delivery.receiver_name}</span></div>}
                {doc.delivery?.signed_at && <div>وقت التوقيع: {formatDateTime(doc.delivery.signed_at)}</div>}
              </div>
            )}

            {/* ملاحظات */}
            {doc.notes && (
              <div className="mx-5 sm:mx-6 mb-5 rounded-xl border bg-muted/30 p-3 text-xs">
                <span className="font-semibold">ملاحظات: </span>{doc.notes}
              </div>
            )}

            {/* تذييل */}
            <div className="border-t px-5 sm:px-6 py-4 flex items-center justify-between flex-wrap gap-2">
              <p className="text-[10px] text-muted-foreground">
                {isInvoice
                  ? "هذه الفاتورة مسجلة وموثقة إلكترونياً — الرمز في الرابط يثبت صحتها"
                  : "الأسعار سارية حتى تاريخ الصلاحية الموضح أعلاه"}
              </p>
              <button
                type="button"
                onClick={() => window.print()}
                className="no-print inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold hover:bg-muted transition-colors"
              >
                <Printer className="w-3.5 h-3.5" /> طباعة / حفظ PDF
              </button>
            </div>
          </div>

          <p className="no-print text-center text-[10px] text-muted-foreground pb-4">
            مدعوم من نظام ميدان لمبيعات والتوزيع
          </p>
        </div>
      ) : (
        <div className="min-h-[60vh] flex items-center justify-center">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-950 shadow-xl border p-6 text-center space-y-4">
            <ShieldX className="w-14 h-14 mx-auto text-red-600" />
            <h1 className="text-xl font-bold text-red-700">تنبيه — مستند غير معروف</h1>
            <p className="text-sm text-muted-foreground">{doc?.message ?? "لا يوجد مستند بهذا الرمز"}</p>
            <p className="text-[10px] text-muted-foreground border-t pt-3">
              نظام التحقق من المستندات — الرمز آمن ولا يكشف بيانات حساسة
            </p>
          </div>
        </div>
      )}
    </main>
  );
}

function Info({ label, value, tone }: { label: string; value: string; tone?: "ok" | "bad" }) {
  return (
    <div className="flex justify-between gap-2 rounded-lg border bg-muted/20 px-3 py-2">
      <span className="text-muted-foreground text-xs shrink-0">{label}:</span>
      <span className={`font-semibold text-xs text-left ${tone === "bad" ? "text-red-600" : tone === "ok" ? "text-emerald-600" : ""}`}>{value}</span>
    </div>
  );
}

function Row({ label, value, bold, tone }: { label: string; value: string; bold?: boolean; tone?: "ok" | "bad" }) {
  return (
    <div className="flex justify-between items-center text-sm">
      <span className="text-muted-foreground text-xs">{label}</span>
      <span dir="ltr" className={`${bold ? "font-bold text-base" : "font-semibold"} ${tone === "bad" ? "text-red-600" : tone === "ok" ? "text-emerald-600" : ""}`}>{value}</span>
    </div>
  );
}

function Badge_({ label, tone }: { label: string; tone: "ok" | "bad" | "muted" }) {
  const cls = tone === "ok" ? "bg-emerald-100 text-emerald-800" : tone === "bad" ? "bg-red-100 text-red-700" : "bg-muted text-muted-foreground";
  return <div className={`inline-block rounded-full px-2 py-0.5 text-[10px] font-bold mt-1 ${cls}`}>{label}</div>;
}
