import { ImageResponse } from "next/og";
import { readFile } from "node:fs/promises";
import { join } from "node:path";

export const alt = "نظام ميدان للمبيعات والتوزيع — بيع · مخزون · مشتريات · مالية · ميداني · بوابة B2B";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

// الخط العربي (Cairo) مضمّن في المشروع — لا اعتماد على شبكة أثناء البناء.
const fontBuffer = await readFile(join(process.cwd(), "public/fonts/cairo-800.ttf"));

export default async function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        dir="rtl"
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          textAlign: "center",
          padding: "80px",
          background: "linear-gradient(135deg, #0f172a 0%, #1e293b 45%, #ea580c 135%)",
          color: "white",
          fontFamily: "Cairo",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "24px",
            marginBottom: "32px",
          }}
        >
          <div
            style={{
              width: 96,
              height: 96,
              borderRadius: 24,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 48,
              fontWeight: 900,
              color: "#0f172a",
              background: "linear-gradient(135deg, #fbbf24, #f97316)",
            }}
          >
            م
          </div>
          <div style={{ fontSize: 56, fontWeight: 900, letterSpacing: 2 }}>نظام ميدان</div>
        </div>
        <div style={{ fontSize: 30, fontWeight: 700, opacity: 0.95, marginBottom: 20 }}>
          بيع · مخزون · مشتريات · مالية · ميداني · بوابة B2B
        </div>
        <div style={{ fontSize: 24, fontWeight: 600, opacity: 0.75 }}>
          منصة عراقية متكاملة لإدارة المبيعات والتوزيع
        </div>
      </div>
    ),
    { ...size, fonts: [{ name: "Cairo", data: fontBuffer, style: "normal" }] }
  );
}