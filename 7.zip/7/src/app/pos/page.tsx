"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/client-api";
import { formatIQD } from "@/lib/utils";
import { Search, ShoppingCart, Trash2, Plus, Minus, Receipt, Loader2, Package } from "lucide-react";

interface Product {
  id: number; name: string; code: string; salePrice: number; costPrice: number;
  stockQty?: number; packSalePrice?: number | null;
}
interface CartLine {
  productId: number; name: string; code: string;
  qty: number; unitPrice: number; lineTotal: number;
}
interface Cashbox { id: number; name: string; code: string; balance: number; currency: string }

/**
 * POS — simplified point-of-sale interface for field reps and quick cash sales.
 * Phase 40 — Innovative: lightweight, touch-friendly, separate from ERP dashboard.
 *
 * Flow:
 *   1. Search product by name/code (debounced)
 *   2. Add to cart with qty
 *   3. Pick cashbox (default = first active)
 *   4. Submit → POST /api/v1/sales/invoices (CASH, walk-in customer)
 *   5. Show receipt number + print link
 */
export default function POSPage() {
  const router = useRouter();
  const [search, setSearch] = React.useState("");
  const [products, setProducts] = React.useState<Product[] | null>(null);
  const [cart, setCart] = React.useState<CartLine[]>([]);
  const [cashboxes, setCashboxes] = React.useState<Cashbox[]>([]);
  const [cashboxId, setCashboxId] = React.useState<number | null>(null);
  const [submitting, setSubmitting] = React.useState(false);
  const [lastReceipt, setLastReceipt] = React.useState<{ number: string; id: number } | null>(null);

  // Load cashboxes on mount
  React.useEffect(() => {
    api<Cashbox[]>("/api/v1/finance/cashboxes").then(({ body }) => {
      if (body.success && body.data && body.data.length) {
        setCashboxes(body.data.filter((c) => c.balance !== undefined || true));
        setCashboxId(body.data[0].id);
      }
    });
  }, []);

  // Debounced product search
  React.useEffect(() => {
    if (!search.trim()) { setProducts(null); return; }
    const t = setTimeout(async () => {
      const { body } = await api<Product[]>(`/api/v1/products?search=${encodeURIComponent(search)}&per_page=20`);
      if (body.success && body.data) setProducts(body.data);
    }, 300);
    return () => clearTimeout(t);
  }, [search]);

  const cartTotal = cart.reduce((s, l) => s + l.lineTotal, 0);

  function addToCart(p: Product) {
    setCart((prev) => {
      const existing = prev.find((l) => l.productId === p.id);
      if (existing) {
        return prev.map((l) => l.productId === p.id
          ? { ...l, qty: l.qty + 1, lineTotal: (l.qty + 1) * l.unitPrice }
          : l);
      }
      const unitPrice = Number(p.salePrice) || 0;
      return [...prev, { productId: p.id, name: p.name, code: p.code, qty: 1, unitPrice, lineTotal: unitPrice }];
    });
  }

  function updateQty(productId: number, delta: number) {
    setCart((prev) => prev
      .map((l) => l.productId === productId
        ? { ...l, qty: Math.max(0, l.qty + delta), lineTotal: Math.max(0, l.qty + delta) * l.unitPrice }
        : l)
      .filter((l) => l.qty > 0));
  }

  function removeFromCart(productId: number) {
    setCart((prev) => prev.filter((l) => l.productId !== productId));
  }

  async function checkout() {
    if (!cart.length || !cashboxId) return;
    setSubmitting(true);
    try {
      const { body } = await api("/api/v1/sales/invoices", {
        method: "POST",
        body: JSON.stringify({
          customer_id: 1, // walk-in customer (default CASH-001)
          warehouse_id: 1,
          sale_type: "CASH",
          cashbox_id: cashboxId,
          lines: cart.map((l) => ({
            product_id: l.productId,
            qty: l.qty,
            unit_price: l.unitPrice,
          })),
        }),
      });
      if (body.success) {
        const d = body.data as { id: number; number: string };
        setLastReceipt({ number: d.number, id: d.id });
        setCart([]);
        toast.success(`تم إنشاء الفاتورة ✓ ${d.number}`);
      } else toast.error(body.message ?? "فشل الإنشاء");
    } finally { setSubmitting(false); }
  }

  return (
    <div className="min-h-screen bg-muted/30 p-4">
      <div className="max-w-7xl mx-auto">
        <header className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <ShoppingCart className="w-6 h-6 text-primary" /> نقطة البيع
            </h1>
            <p className="text-sm text-muted-foreground">واجهة مبسّطة للبيع السريع — للمندوبين الميدانيين والكاشير</p>
          </div>
          <Button variant="ghost" onClick={() => router.push("/")}>← رجوع للوحة</Button>
        </header>

        <div className="grid gap-4 lg:grid-cols-3">
          {/* Left: product search + list */}
          <div className="lg:col-span-2 space-y-3">
            <Card>
              <CardHeader className="pb-3">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    autoFocus
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="بحث منتج بالاسم أو الكود..."
                    className="pr-10"
                  />
                </div>
              </CardHeader>
              <CardContent>
                {!products ? (
                  <div className="py-8 text-center text-muted-foreground text-sm">
                    ابدأ البحث عن منتج لإضافته للسلة
                  </div>
                ) : products.length === 0 ? (
                  <div className="py-8 text-center text-muted-foreground text-sm">لا نتائج</div>
                ) : (
                  <div className="grid gap-2 sm:grid-cols-2 md:grid-cols-3">
                    {products.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => addToCart(p)}
                        className="text-right p-3 rounded-lg border hover:bg-accent hover:border-primary transition-colors"
                      >
                        <div className="font-medium text-sm truncate">{p.name}</div>
                        <div className="text-xs text-muted-foreground font-mono" dir="ltr">{p.code}</div>
                        <div className="mt-1 text-primary font-bold" dir="ltr">{formatIQD(Number(p.salePrice))}</div>
                      </button>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right: cart + checkout */}
          <div className="space-y-3">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center justify-between">
                  <span className="flex items-center gap-2"><Receipt className="w-4 h-4" /> السلة</span>
                  {cart.length > 0 && (
                    <Button size="sm" variant="ghost" onClick={() => setCart([])}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {cart.length === 0 ? (
                  <div className="py-8 text-center text-muted-foreground text-sm">
                    <Package className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    السلة فارغة
                  </div>
                ) : (
                  <div className="space-y-2">
                    {cart.map((l) => (
                      <div key={l.productId} className="flex items-center gap-2 p-2 rounded border">
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium truncate">{l.name}</div>
                          <div className="text-xs text-muted-foreground" dir="ltr">{formatIQD(l.unitPrice)} × {l.qty}</div>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updateQty(l.productId, -1)}>
                            <Minus className="w-3 h-3" />
                          </Button>
                          <span className="w-6 text-center text-sm">{l.qty}</span>
                          <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updateQty(l.productId, 1)}>
                            <Plus className="w-3 h-3" />
                          </Button>
                        </div>
                        <div className="text-sm font-bold w-20 text-left" dir="ltr">{formatIQD(l.lineTotal)}</div>
                      </div>
                    ))}
                    <div className="border-t pt-2 mt-2 flex justify-between font-bold">
                      <span>الإجمالي:</span>
                      <span dir="ltr">{formatIQD(cartTotal)}</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-4 space-y-2">
                <label className="text-xs space-y-1 block">الصندوق
                  <select
                    value={cashboxId ?? ""}
                    onChange={(e) => setCashboxId(Number(e.target.value))}
                    className="h-9 w-full rounded-md border bg-background px-3 text-sm"
                  >
                    {cashboxes.map((c) => (
                      <option key={c.id} value={c.id}>{c.name} ({formatIQD(c.balance)})</option>
                    ))}
                  </select>
                </label>
                <Button className="w-full" size="lg" disabled={!cart.length || !cashboxId || submitting} onClick={checkout}>
                  {submitting ? <Loader2 className="w-4 h-4 ml-2 animate-spin" /> : <Receipt className="w-4 h-4 ml-2" />}
                  {submitting ? "جارٍ الحفظ..." : `إتمام البيع — ${formatIQD(cartTotal)}`}
                </Button>
                {lastReceipt && (
                  <div className="mt-2 p-2 rounded bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300 text-sm">
                    <div className="font-medium">✓ {lastReceipt.number}</div>
                    <div className="flex gap-2 mt-1">
                      <a href={`/api/v1/sales/invoices/${lastReceipt.id}/pdf`} target="_blank" className="text-xs underline">طباعة PDF</a>
                      <a href={`/api/v1/sales/invoices/${lastReceipt.id}/qr`} target="_blank" className="text-xs underline">QR</a>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
