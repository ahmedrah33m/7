import { NextRequest, NextResponse } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { snapshot, snapshotPrometheus } from "@/lib/metrics";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/monitoring/metrics (system.monitoring.view) — §71.
 * JSON snapshot: process vitals (uptime/RSS/heap), HTTP counters per
 * normalized route (requests/errors/avg latency), database vitals
 * (tables, size, key row counts). Add ?format=text for Prometheus
 * exposition format.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.monitoring.view");
  const snap = await snapshot();
  const format = new URL(req.url).searchParams.get("format");
  if (format === "text") {
    return new NextResponse(snapshotPrometheus(snap), {
      status: 200,
      headers: { "Content-Type": "text/plain; version=0.0.4; charset=utf-8" },
    });
  }
  return ok({ ...snap, requested_by: session.username });
});
