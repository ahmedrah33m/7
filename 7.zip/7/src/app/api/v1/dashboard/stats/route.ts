import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { Decimal, dec, moneyR, num } from "@/lib/decimal";
import { branchWhere } from "@/lib/scope";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/dashboard/stats — live KPIs (permission: system.company.view,
 * which every role holds) — sales today/month, receivables, low stock,
 * recent invoices, top products.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.company.view");

  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const [salesToday, salesMonth, invoicesToday, receivables, productsCount, customersCount] =
    await Promise.all([
      db.salesInvoice.aggregate({
        where: { companyId: session.companyId, deletedAt: null, ...branchWhere(session), invoiceDate: { gte: startOfDay } },
        _sum: { grandTotal: true },
      }),
      db.salesInvoice.aggregate({
        where: { companyId: session.companyId, deletedAt: null, ...branchWhere(session), invoiceDate: { gte: startOfMonth } },
        _sum: { grandTotal: true },
      }),
      db.salesInvoice.count({
        where: { companyId: session.companyId, deletedAt: null, ...branchWhere(session), invoiceDate: { gte: startOfDay } },
      }),
      db.customer.aggregate({
        where: { companyId: session.companyId, deletedAt: null, ...branchWhere(session) },
        _sum: { balance: true },
      }),
      db.product.count({ where: { companyId: session.companyId, deletedAt: null, isActive: true } }),
      db.customer.count({ where: { companyId: session.companyId, deletedAt: null, isActive: true, ...branchWhere(session) } }),
    ]);

  // Low stock: products with min_stock > 0 and balance <= min_stock (scoped warehouses).
  const balances = await db.stockBalance.findMany({
    where: { companyId: session.companyId, warehouseId: { in: session.warehouseIds } },
    include: { product: { select: { code: true, name: true, unit: true, minStock: true } } },
  });
  const perProduct = new Map<number, { product: (typeof balances)[number]["product"]; qty: Decimal }>();
  for (const b of balances) {
    if (dec(b.product.minStock).lte(0)) continue;
    const cur = perProduct.get(b.productId) ?? { product: b.product, qty: new Decimal(0) };
    cur.qty = cur.qty.plus(b.qty);
    perProduct.set(b.productId, cur);
  }
  const lowStock = Array.from(perProduct.values())
    .filter((r) => r.qty.lte(r.product.minStock))
    .sort((a, b) =>
      num(a.qty.div(Decimal.max(1, a.product.minStock))) -
      num(b.qty.div(Decimal.max(1, b.product.minStock))))
    .slice(0, 6)
    .map((r) => ({ code: r.product.code, name: r.product.name, unit: r.product.unit, qty: num(r.qty), min_stock: num(r.product.minStock) }));

  const recentInvoices = await db.salesInvoice.findMany({
    where: { companyId: session.companyId, deletedAt: null },
    include: { customer: { select: { name: true } } },
    orderBy: { id: "desc" },
    take: 6,
  });

  // Top products by revenue this month (simple in-memory aggregation).
  const monthLines = await db.salesInvoiceLine.findMany({
    where: {
      invoice: { companyId: session.companyId, deletedAt: null, invoiceDate: { gte: startOfMonth } },
    },
    include: { product: { select: { code: true, name: true } } },
  });
  const revenue = new Map<number, { product: { code: string; name: string }; total: Decimal; qty: Decimal }>();
  for (const l of monthLines) {
    const cur = revenue.get(l.productId) ?? { product: l.product, total: new Decimal(0), qty: new Decimal(0) };
    cur.total = cur.total.plus(l.lineTotal);
    cur.qty = cur.qty.plus(l.qty);
    revenue.set(l.productId, cur);
  }
  const topProducts = Array.from(revenue.values())
    .sort((a, b) => num(b.total.minus(a.total)))
    .slice(0, 5)
    .map((r) => ({ code: r.product.code, name: r.product.name, qty: num(r.qty), revenue: num(moneyR(r.total)) }));

  return ok({
    sales_today: { total: num(moneyR(dec(salesToday._sum.grandTotal))), count: invoicesToday },
    sales_month: { total: num(moneyR(dec(salesMonth._sum.grandTotal))) },
    receivables: num(moneyR(dec(receivables._sum.balance))),
    products_count: productsCount,
    customers_count: customersCount,
    low_stock: lowStock,
    top_products: topProducts,
    recent_invoices: recentInvoices.map((inv) => ({
      id: inv.id,
      number: inv.number,
      type: inv.type,
      grand_total: inv.grandTotal,
      customer: inv.customer.name,
      invoice_date: inv.invoiceDate,
    })),
  });
});
