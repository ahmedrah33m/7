// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { Decimal, dec, moneyR, num } from "@/lib/decimal";
import { z } from "zod";
export const dynamic = "force-dynamic";

const replenishSchema = z.object({
  petty_cashbox_id: z.number().int().positive(),
  source_cashbox_id: z.number().int().positive(),
  amount: z.number().positive(),
  description: z.string().max(500).optional(),
});

/** POST /api/v1/finance/petty-cash — replenish petty cash from main cashbox */
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cash_transfers.create");
  const body = await parseBody(req, replenishSchema);
  
  // Verify both cashboxes exist and the petty one is type=CUSTOM (petty cash)
  const pettyBox = await db.cashbox.findFirst({
    where: { id: body.petty_cashbox_id, companyId: session.companyId, deletedAt: null, status: "ACTIVE" },
  });
  if (!pettyBox) throw new ApiError("CASHBOX_001", "Petty cash cashbox not found");
  
  const sourceBox = await db.cashbox.findFirst({
    where: { id: body.source_cashbox_id, companyId: session.companyId, deletedAt: null, status: "ACTIVE" },
  });
  if (!sourceBox) throw new ApiError("CASHBOX_001", "Source cashbox not found");
  
  if (dec(sourceBox.balance).lessThan(dec(body.amount))) {
    throw new ApiError("CASHBOX_003", `Source cashbox insufficient: ${num(sourceBox.balance)}`);
  }
  
  // Transfer: OUT from source, IN to petty
  const amount = moneyR(dec(body.amount));
  const sourceAfter = moneyR(dec(sourceBox.balance).minus(amount));
  const pettyAfter = moneyR(dec(pettyBox.balance).plus(amount));
  
  await db.$transaction(async (tx) => {
    // OUT from source
    await tx.cashTransaction.create({
      data: {
        companyId: session.companyId, cashboxId: sourceBox.id, direction: "OUT",
        category: "OTHER", transactionType: "CASH_TRANSFER_OUT",
        balanceBefore: sourceBox.balance, balanceAfter: sourceAfter,
        amount, note: `تغذية صندوق المصاريف الصغيرة ${pettyBox.name}${body.description ? " — " + body.description : ""}`,
        createdBy: session.userId,
      },
    });
    await tx.cashbox.update({ where: { id: sourceBox.id }, data: { balance: sourceAfter } });
    
    // IN to petty
    await tx.cashTransaction.create({
      data: {
        companyId: session.companyId, cashboxId: pettyBox.id, direction: "IN",
        category: "OTHER", transactionType: "CASH_TRANSFER_IN",
        balanceBefore: pettyBox.balance, balanceAfter: pettyAfter,
        amount, note: `تغذية من ${sourceBox.name}${body.description ? " — " + body.description : ""}`,
        createdBy: session.userId,
      },
    });
    await tx.cashbox.update({ where: { id: pettyBox.id }, data: { balance: pettyAfter } });
  });
  
  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: undefined, userAgent: undefined },
    { action: "CREATE", module: "finance", entityType: "petty_cash_replenish", newValues: { from: sourceBox.name, to: pettyBox.name, amount: num(amount) } }
  );
  
  return ok({
    petty_cashbox: { id: pettyBox.id, name: pettyBox.name, balance_after: num(pettyAfter) },
    source_cashbox: { id: sourceBox.id, name: sourceBox.name, balance_after: num(sourceAfter) },
    amount: num(amount), status: "POSTED",
  }, undefined, 201);
});
