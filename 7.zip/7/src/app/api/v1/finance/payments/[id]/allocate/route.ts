// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { allocatePayment } from "@/lib/cashbox-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/finance/payments/[id]/allocate
 *   Body: { allocations: [{ invoice_id, invoice_type: SALES|PURCHASE, amount }] }
 *
 * Allocates an UNALLOCATED (or partially-allocated) payment to one or
 * more outstanding invoices. Idempotent at the allocation-line level:
 * duplicate (paymentId, invoiceId) re-uses the existing row.
 *
 * Phase 11 (الدفعات غير المخصصة) + Phase 67 (allocate endpoint).
 * Permission: finance.payments.allocate — Phase 37 new action.
 */
const allocItemSchema = z.object({
  invoice_id: z.number().int().positive(),
  invoice_type: z.enum(["SALES", "PURCHASE"]),
  amount: z.number().positive(),
});

const allocateSchema = z.object({
  allocations: z.array(allocItemSchema).min(1).max(50),
});

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const session = await guard(req, "finance.payments.allocate");
  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) throw new ApiError("VAL_001", "معرّف غير صالح");

  const body = await parseBody(req, allocateSchema);

  const result = await allocatePayment(
    {
      userId: session.userId,
      companyId: session.companyId,
      branchId: session.activeBranchId,
      ip: req.headers.get("x-forwarded-for"),
      userAgent: req.headers.get("user-agent"),
    },
    id,
    body.allocations.map((a) => ({
      invoiceId: a.invoice_id,
      invoiceType: a.invoice_type,
      amount: a.amount,
    }))
  );

  return ok(result);
});
