// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { num, sumOf, dec } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/finance/payments/[id]
 *   Single payment detail (finance.payments.view).
 *   Includes allocations, linked voucher/receipt, party, cashbox.
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const session = await guard(req, "finance.payments.view");
  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) throw new ApiError("VAL_001", "معرّف غير صالح");

  const payment = await db.payment.findFirst({
    where: { id, companyId: session.companyId, deletedAt: null },
    include: {
      customer: { select: { id: true, name: true, code: true, phone: true } },
      supplier: { select: { id: true, name: true, code: true, phone: true } },
      cashbox: { select: { id: true, name: true, code: true, currency: true } },
      allocations: {
        orderBy: { id: "asc" },
      },
      receipt: { select: { id: true, number: true, receiptDate: true } },
      voucher: { select: { id: true, number: true, paymentDate: true } },
      creator: { select: { id: true, fullName: true } },
    },
  });
  if (!payment) throw new ApiError("PAYMENT_003", "الدفعة غير موجودة");

  const allocatedTotal = sumOf(payment.allocations, (a) => dec(a.allocatedAmount));

  return ok({
    id: payment.id,
    uuid: payment.uuid,
    number: payment.number,
    payment_type: payment.paymentType,
    party_type: payment.partyType,
    customer: payment.customer,
    supplier: payment.supplier,
    cashbox: payment.cashbox,
    total_amount: num(payment.totalAmount),
    currency: payment.currency,
    exchange_rate: payment.exchangeRate ? num(payment.exchangeRate) : null,
    payment_method: payment.paymentMethod,
    payment_date: payment.paymentDate.toISOString(),
    status: payment.status,
    reference_number: payment.referenceNumber,
    bank_name: payment.bankName,
    bank_account: payment.bankAccount,
    card_last4: payment.cardLast4,
    cash_amount: payment.cashAmount ? num(payment.cashAmount) : null,
    card_amount: payment.cardAmount ? num(payment.cardAmount) : null,
    bank_amount: payment.bankAmount ? num(payment.bankAmount) : null,
    on_account_amount: payment.onAccountAmount ? num(payment.onAccountAmount) : null,
    allocated_total: num(allocatedTotal),
    unallocated_amount: num(dec(payment.totalAmount).minus(allocatedTotal)),
    allocations: payment.allocations.map((a) => ({
      id: a.id,
      invoice_type: a.invoiceType,
      sales_invoice_id: a.salesInvoiceId,
      purchase_invoice_id: a.purchaseInvoiceId,
      allocated_amount: num(a.allocatedAmount),
      invoice_number: a.invoiceNumber,
      invoice_total: a.invoiceTotal ? num(a.invoiceTotal) : null,
      previously_paid: a.previouslyPaid ? num(a.previouslyPaid) : null,
      remaining_after: a.remainingAfter ? num(a.remainingAfter) : null,
    })),
    receipt: payment.receipt,
    voucher: payment.voucher,
    description: payment.description,
    notes: payment.notes,
    cancel_reason: payment.cancelReason,
    cancelled_at: payment.cancelledAt?.toISOString() ?? null,
    created_by: payment.creator,
    created_at: payment.createdAt.toISOString(),
  });
});
