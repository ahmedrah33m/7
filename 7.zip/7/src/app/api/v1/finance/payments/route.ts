// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { branchWhere } from "@/lib/scope";
import { num } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/finance/payments
 *   ?party_type=CUSTOMER|SUPPLIER|OTHER
 *   ?customer_id=  ?supplier_id=  ?cashbox_id=
 *   ?status=POSTED|CANCELLED
 *   ?payment_method=CASH|CARD|TRANSFER|CHEQUE|ON_ACCOUNT|MIXED
 *   ?from=&to=  (payment_date range)
 *   ?search=     (matches number, referenceNumber, recipient_name)
 *   ?per_page=20  ?page=1
 *
 * Phase 67 — Payment registry (الدفعات).
 * Permission: finance.payments.view.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.payments.view");
  const url = new URL(req.url);

  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1"));
  const perPage = Math.min(100, Number(url.searchParams.get("per_page") ?? "20"));
  const partyType = url.searchParams.get("party_type");
  const customerId = url.searchParams.get("customer_id");
  const supplierId = url.searchParams.get("supplier_id");
  const cashboxId = url.searchParams.get("cashbox_id");
  const status = url.searchParams.get("status");
  const method = url.searchParams.get("payment_method");
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");
  const search = url.searchParams.get("search")?.trim();

  const where: Record<string, unknown> = {
    companyId: session.companyId,
    deletedAt: null,
    ...branchWhere(session),
  };
  if (partyType) where.partyType = partyType;
  if (customerId) where.customerId = Number(customerId);
  if (supplierId) where.supplierId = Number(supplierId);
  if (cashboxId) where.cashboxId = Number(cashboxId);
  if (status) where.status = status;
  if (method) where.paymentMethod = method;
  if (from || to) {
    where.paymentDate = {
      ...(from ? { gte: new Date(from) } : {}),
      ...(to ? { lte: new Date(to) } : {}),
    };
  }
  if (search) {
    where.OR = [
      { number: { contains: search } },
      { referenceNumber: { contains: search } },
      { description: { contains: search } },
    ];
  }

  const [rows, total] = await Promise.all([
    db.payment.findMany({
      where,
      orderBy: { paymentDate: "desc" },
      take: perPage,
      skip: (page - 1) * perPage,
      include: {
        customer: { select: { id: true, name: true, code: true } },
        supplier: { select: { id: true, name: true, code: true } },
        cashbox: { select: { id: true, name: true, code: true } },
        allocations: { select: { id: true, allocatedAmount: true, invoiceNumber: true, invoiceType: true } },
        receipt: { select: { id: true, number: true } },
        voucher: { select: { id: true, number: true } },
      },
    }),
    db.payment.count({ where }),
  ]);

  return ok({
    page,
    per_page: perPage,
    total,
    pages: Math.ceil(total / perPage) || 1,
    rows: rows.map((p) => ({
      id: p.id,
      uuid: p.uuid,
      number: p.number,
      payment_type: p.paymentType,
      party_type: p.partyType,
      customer: p.customer,
      supplier: p.supplier,
      cashbox: p.cashbox,
      total_amount: num(p.totalAmount),
      currency: p.currency,
      exchange_rate: p.exchangeRate ? num(p.exchangeRate) : null,
      payment_method: p.paymentMethod,
      payment_date: p.paymentDate.toISOString(),
      status: p.status,
      reference_number: p.referenceNumber,
      cash_amount: p.cashAmount ? num(p.cashAmount) : null,
      card_amount: p.cardAmount ? num(p.cardAmount) : null,
      bank_amount: p.bankAmount ? num(p.bankAmount) : null,
      on_account_amount: p.onAccountAmount ? num(p.onAccountAmount) : null,
      allocations: p.allocations,
      receipt: p.receipt,
      voucher: p.voucher,
      description: p.description,
      notes: p.notes,
      created_at: p.createdAt.toISOString(),
    })),
  });
});
