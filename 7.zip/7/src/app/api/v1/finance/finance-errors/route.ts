// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/finance/finance-errors
 *   ?code=&resolved=0&from=&to=&limit=100
 *
 * Phase 37 — Centralized finance error log (المرحلة 37)
 * Permission: finance.finance_errors.view
 */
const FINANCE_ERROR_PREFIXES = ["CASHBOX_", "RECEIPT_", "PAYMENT_", "CASH_", "CLOSING_", "PV_", "FINANCE_", "SCOPE_", "VAL_"];

export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.finance_errors.view");
  const url = new URL(req.url);
  const code = url.searchParams.get("code");
  const resolved = url.searchParams.get("resolved");
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");
  const limit = Math.min(500, Number(url.searchParams.get("limit") ?? "100"));

  const where: Record<string, unknown> = {
    companyId: session.companyId,
  };
  if (code) where.errorCode = code;
  if (resolved === "1") where.resolvedAt = { not: null };
  if (resolved === "0") where.resolvedAt = null;
  if (from || to) {
    where.createdAt = {
      ...(from ? { gte: new Date(from) } : {}),
      ...(to ? { lte: new Date(to) } : {}),
    };
  }

  const rows = await db.financeErrorLog.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: limit,
    include: {
      user: { select: { id: true, fullName: true, username: true } },
      resolver: { select: { id: true, fullName: true } },
    },
  });

  return ok(rows.map((r) => ({
    id: r.id,
    error_code: r.errorCode,
    error_message: r.errorMessage,
    endpoint: r.endpoint,
    method: r.method,
    request_body: r.requestBody,
    cashbox_id: r.cashboxId,
    receipt_id: r.receiptId,
    voucher_id: r.voucherId,
    payment_id: r.paymentId,
    ip_address: r.ipAddress,
    user_agent: r.userAgent,
    request_id: r.requestId,
    resolved_at: r.resolvedAt,
    resolution_note: r.resolutionNote,
    user: r.user,
    resolver: r.resolver,
    created_at: r.createdAt.toISOString(),
  })));
});
