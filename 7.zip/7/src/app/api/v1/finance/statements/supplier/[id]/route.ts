// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { supplierStatement } from "@/lib/cashbox-service";
export const dynamic = "force-dynamic";
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.statements.view");
  const { id } = await ctx.params;
  const url = new URL(req.url);
  const dateFrom = url.searchParams.get("date_from");
  const dateTo = url.searchParams.get("date_to");
  const stmt = await supplierStatement(session.companyId, Number(id), { dateFrom: dateFrom ? new Date(dateFrom) : undefined, dateTo: dateTo ? new Date(dateTo) : undefined });
  return ok(stmt);
});
