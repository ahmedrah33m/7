// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";

export const dynamic = "force-dynamic";

const emailSchema = z.object({
  email: z.string().email().optional(),
  customer_id: z.number().int().positive(),
  from_date: z.string().datetime().optional(),
  to_date: z.string().datetime().optional(),
});

/**
 * POST /api/v1/finance/statements/customer/[id]/email
 *   Body: { email?, from_date?, to_date? }
 *
 * Phase 26-28 — Email statement via SMTP
 *
 * Currently logs the email intent + generates the public verify URL.
 * Real SMTP integration requires SMTP_HOST/USER/PASS env vars (placeholder).
 *
 * Permission: finance.statements.view
 */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const session = await guard(req, "finance.statements.view");
  const customerId = Number((await ctx.params).id);
  if (!Number.isFinite(customerId)) throw new ApiError("VAL_001", "معرّف غير صالح");

  const body = await parseBody(req, emailSchema);

  // Load customer
  const customer = await db.customer.findFirst({
    where: { id: customerId, companyId: session.companyId, deletedAt: null },
    select: { id: true, name: true, code: true, phone: true, email: true, balance: true },
  });
  if (!customer) throw new ApiError("VAL_003", "العميل غير موجود");

  const targetEmail = body.email ?? customer.email;
  if (!targetEmail) {
    return ok({ error: "لا يوجد بريد إلكتروني لهذا العميل", needs_email: true }, undefined, 400);
  }

  // Load company
  const company = await db.company.findFirst({
    where: { id: session.companyId },
    select: { name: true, phone: true, email: true },
  });

  // Generate a public statement URL (reuses verify/[token] pattern)
  // We use a synthetic token: base64(customerId + date)
  const statementToken = Buffer.from(`STMT-${customerId}-${Date.now()}`).toString("base64url");
  const publicUrl = `${req.nextUrl.origin}/verify/${statementToken}`;

  // Compose email body (Arabic, RTL)
  const emailBody = `
مرحباً ${customer.name}،

نرفق لكم كشف الحساب حتى تاريخ ${new Date().toLocaleString("ar-IQ")}.

يمكنكم الاطلاع على كشف الحساب الكامل عبر الرابط العام التالي:
${publicUrl}

ملخص سريع:
• رقم العميل: ${customer.code}
• الرصيد الحالي: ${new Intl.NumberFormat("ar-IQ").format(Number(customer.balance))} د.ع

في حال وجود أي استفسار، يرجى التواصل معنا${company?.phone ? ` على ${company.phone}` : ""}.

مع تحيات،
${company?.name ?? "نظام ميدان ERP"}
  `.trim();

  // Log the email intent (SMTP not actually sent in this sandbox environment)
  await db.auditLog.create({
    data: {
      companyId: session.companyId,
      userId: session.userId,
      action: "EXPORT",
      module: "finance",
      entityType: "customer_statement_email",
      entityId: customerId,
      newValues: {
        email: targetEmail,
        public_url: publicUrl,
        from_date: body.from_date,
        to_date: body.to_date,
      },
      ipAddress: req.headers.get("x-forwarded-for"),
      userAgent: req.headers.get("user-agent"),
    },
  });

  // In production: actually send via SMTP if env vars are set
  const smtpHost = process.env.SMTP_HOST;
  const smtpUser = process.env.SMTP_USER;
  const smtpPass = process.env.SMTP_PASS;
  let sent = false;
  let smtpError: string | null = null;

  if (smtpHost && smtpUser && smtpPass) {
    try {
      // Dynamic import nodemailer (would need to be installed in production)
      // const nodemailer = require("nodemailer");
      // const transporter = nodemailer.createTransport({ host: smtpHost, port: 587, auth: { user: smtpUser, pass: smtpPass } });
      // await transporter.sendMail({ from: company?.email ?? smtpUser, to: targetEmail, subject: "كشف حساب — " + (company?.name ?? ""), text: emailBody, html: emailBody.replace(/\n/g, "<br>") });
      // sent = true;
      smtpError = "SMTP configured but nodemailer not installed (sandbox mode)";
    } catch (e: any) {
      smtpError = e?.message ?? String(e);
    }
  } else {
    smtpError = "SMTP env vars not configured (SMTP_HOST/SMTP_USER/SMTP_PASS)";
  }

  return ok({
    customer_id: customerId,
    customer_name: customer.name,
    target_email: targetEmail,
    public_url: publicUrl,
    sent: sent,
    smtp_error: smtpError,
    message: sent
      ? "تم إرسال البريد الإلكتروني ✓"
      : "تم توليد الرابط العام وكتابة سجل التدقيق. SMTP غير مُعدّ — الرابط جاهز للمشاركة اليدوية.",
    email_body: emailBody,
  });
});
