// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { z } from "zod";
export const dynamic = "force-dynamic";
const budgetSchema = z.object({ account_id: z.number().int().positive(), period: z.string().regex(/^\d{4}-\d{2}$/), budgeted_amount: z.number().positive(), notes: z.string().max(500).optional() });
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.statements.view");
  const url = new URL(req.url);
  const period = url.searchParams.get("period") ?? new Date().toISOString().slice(0, 7);
  const rows = await db.budget.findMany({ where: { companyId: session.companyId, period }, include: { account: { select: { id: true, code: true, name: true, type: true } } }, orderBy: { account: { code: "asc" } } });
  return ok(rows.map((b) => ({ id: b.id, account: b.account, period: b.period, budgeted: b.budgetedAmount, actual: b.actualAmount, variance: b.variance })));
});
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.settings.edit");
  const body = await parseBody(req, budgetSchema);
  const account = await db.account.findFirst({ where: { id: body.account_id, companyId: session.companyId, deletedAt: null } });
  if (!account) throw new ApiError("VAL_003", "الحساب غير موجود");
  const [year, month] = body.period.split("-").map(Number);
  const existing = await db.budget.findFirst({ where: { companyId: session.companyId, accountId: body.account_id, period: body.period } });
  let budget;
  if (existing) { budget = await db.budget.update({ where: { id: existing.id }, data: { budgetedAmount: body.budgeted_amount } }); }
  else { budget = await db.budget.create({ data: { companyId: session.companyId, accountId: body.account_id, period: body.period, year, month, budgetedAmount: body.budgeted_amount } }); }
  await writeAudit({ userId: session.userId, companyId: session.companyId, ipAddress: undefined, userAgent: undefined }, { action: "CREATE", module: "accounting", entityType: "budget", entityId: budget.id, newValues: { account: account.code, period: body.period, amount: body.budgeted_amount } });
  return ok({ id: budget.id, account: account.code, period: body.period, budgeted: body.budgeted_amount }, undefined, 201);
});
