// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import type { CashActor } from "@/lib/cashbox-service";
import { z } from "zod";
export const dynamic = "force-dynamic";
const depositSchema = z.object({ from_cashbox_id: z.number().int().positive(), to_bank_account_id: z.number().int().positive(), amount: z.number().positive(), currency: z.string().length(3).optional(), exchange_rate: z.number().positive().optional().nullable(), bank_deposit_ref: z.string().max(80).optional(), description: z.string().max(500).optional(), idempotency_key: z.string().max(120).optional(), deposit_date: z.string().datetime().optional() });
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cash_transfers.create");
  const body = await parseBody(req, depositSchema);
  const result = await createBankDeposit({ userId: session.userId, companyId: session.companyId } as any, { fromCashboxId: body.from_cashbox_id, bankAccountId: body.to_bank_account_id, amount: body.amount, currency: body.currency, exchangeRate: body.exchange_rate, bankDepositRef: body.bank_deposit_ref, description: body.description, idempotencyKey: body.idempotency_key, depositDate: body.deposit_date ? new Date(body.deposit_date) : undefined });
  return ok(result, undefined, 201);
});
