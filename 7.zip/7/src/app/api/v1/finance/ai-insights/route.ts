// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { num, dec, sumOf } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/finance/ai-insights
 *   Generates rule-based insights (no external LLM call) by analyzing:
 *   - Cashbox balance trends (last 7 days)
 *   - Customer AR aging concentration
 *   - Payment method distribution
 *   - Reconciliation differences
 *
 * Phase 42 — AI Insights (rule-based heuristic; ready for LLM enhancement).
 *
 * Permission: finance.cashboxes.view (read-only insights)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cashboxes.view");
  const companyId = session.companyId;

  const insights: Array<{ id: string; severity: "info" | "warning" | "critical"; title: string; body: string; metric?: string; recommendation?: string }> = [];

  // 1. Cashbox balance analysis
  const cashboxes = await db.cashbox.findMany({
    where: { companyId, deletedAt: null, isActive: true },
    select: { id: true, name: true, balance: true, currency: true, type: true },
  });
  const totalCash = sumOf(cashboxes, (c) => dec(c.balance));
  const lowBoxes = cashboxes.filter((c) => Number(c.balance) < 100000);
  if (lowBoxes.length > 0) {
    insights.push({
      id: "low_balance",
      severity: "warning",
      title: `رصيد منخفض في ${lowBoxes.length} صندوق`,
      body: `الصناديق التالية برصيد أقل من 100,000 د.ع: ${lowBoxes.map((c) => c.name).join("، ")}`,
      metric: `${lowBoxes.length}/${cashboxes.length}`,
      recommendation: "ننصح بشحن الصناديق قبل نفاد النقد وتعطل عمليات البيع",
    });
  }

  // 2. AR aging concentration
  const customers = await db.customer.findMany({
    where: { companyId, deletedAt: null },
    select: { id: true, name: true, balance: true },
  });
  const debtors = customers.filter((c) => Number(c.balance) > 0);
  if (debtors.length > 0) {
    const totalAR = sumOf(debtors, (c) => dec(c.balance));
    const sortedDebtors = debtors.sort((a, b) => Number(b.balance) - Number(a.balance));
    const top3Share = sortedDebtors.slice(0, 3).reduce((s, c) => s + Number(c.balance), 0) / Number(totalAR) * 100;
    if (top3Share > 60) {
      insights.push({
        id: "ar_concentration",
        severity: "warning",
        title: "تركّز الذمم المديونة في 3 عملاء",
        body: `${top3Share.toFixed(0)}% من إجمالي الذمم (${num(totalCash)} د.ع) لدى 3 عملاء فقط: ${sortedDebtors.slice(0, 3).map((c) => c.name).join("، ")}`,
        metric: `${top3Share.toFixed(0)}%`,
        recommendation: "ننصح بمتابعة هؤلاء العملاء بشكل خاص وتوزيع المخاطر بتشجيع العملاء الآخرين",
      });
    }
  }

  // 3. Payment method distribution
  const payments = await db.payment.findMany({
    where: { companyId, deletedAt: null, status: "POSTED" },
    select: { paymentMethod: true, totalAmount: true, createdAt: true },
    take: 500,
    orderBy: { createdAt: "desc" },
  });
  if (payments.length > 0) {
    const last7Days = new Date(); last7Days.setDate(last7Days.getDate() - 7);
    const recent = payments.filter((p) => p.createdAt >= last7Days);
    const cashPayments = recent.filter((p) => p.paymentMethod === "CASH");
    const cashShare = recent.length > 0 ? cashPayments.length / recent.length * 100 : 0;
    insights.push({
      id: "payment_methods",
      severity: "info",
      title: `توزيع طرق الدفع (آخر 7 أيام)`,
      body: `${cashShare.toFixed(0)}% من ${recent.length} دفعة كانت نقدية، ${(100 - cashShare).toFixed(0)}% بطرق أخرى (بطاقة/تحويل/مختلط)`,
      metric: `${cashShare.toFixed(0)}% نقد`,
      recommendation: cashShare > 80 ? "نسبة النقد عالية جدًا — قد يفيد تشجيع الدفع الإلكتروني لتقليل مخاطر النقد" : undefined,
    });
  }

  // 4. Reconciliation differences
  const closings = await db.cashboxClosing.findMany({
    where: { companyId, deletedAt: null, status: { in: ["CLOSED", "DRAFT"] } },
    select: { difference: true, closingDate: true, cashboxId: true },
    orderBy: { closingDate: "desc" },
    take: 30,
  });
  if (closings.length > 0) {
    const withDiff = closings.filter((c) => Math.abs(Number(c.difference)) > 1000);
    if (withDiff.length >= 3) {
      const totalDiff = sumOf(withDiff, (c) => dec(c.difference));
      insights.push({
        id: "reconciliation_diff",
        severity: "critical",
        title: `${withDiff.length} فروقات جرد كبيرة في آخر 30 إغلاق`,
        body: `مجموع الفروقات: ${num(totalDiff)} د.ع — أكبر فرق: ${Math.max(...withDiff.map((c) => Math.abs(Number(c.difference))))} د.ع`,
        metric: num(totalDiff),
        recommendation: "ننصح بمراجعة إجراءات الجرد وتدريب الكاشير على العد الدقيق + تركيب كاميرات مراقبة فوق الصناديق",
      });
    }
  }

  // 5. Rep settlement backlog
  const repCashboxes = cashboxes.filter((c) => c.type === "REP");
  if (repCashboxes.length > 0) {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const recentSettlements = await db.repSettlement.count({
      where: { companyId, settlementDate: { gte: today } },
    });
    if (recentSettlements < repCashboxes.length) {
      insights.push({
        id: "rep_settlement_backlog",
        severity: "warning",
        title: "تأخر في تسليمات المندوبين اليوم",
        body: `${repCashboxes.length} صندوق مندوب نشط، لكن ${recentSettlements} فقط تسليم اليوم. ${repCashboxes.length - recentSettlements} مندوب لم يُسلّم بعد.`,
        metric: `${recentSettlements}/${repCashboxes.length}`,
        recommendation: "تذكير المندوبين بتسليم المحصّل قبل نهاية اليوم لتجنب تراكم النقد لديهم",
      });
    }
  }

  return ok({
    generated_at: new Date().toISOString(),
    insight_count: insights.length,
    critical_count: insights.filter((i) => i.severity === "critical").length,
    warning_count: insights.filter((i) => i.severity === "warning").length,
    insights,
  });
});
