// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";

export const dynamic = "force-dynamic";

const generateSchema = z.object({
  invoice_id: z.number().int().positive(),
  format: z.enum(["ZATCA", "IRAQI_EINVOICE", "EU_EINVOICE"]).default("IRAQI_EINVOICE"),
});

/**
 * POST /api/v1/finance/e-invoice
 *   Body: { invoice_id, format }
 *
 * Phase 42 — E-invoicing stub (ZATCA phase 2 / Iraqi e-invoice / EU).
 *
 * Returns a structured JSON-LD e-invoice document ready for submission
 * to a tax authority API. Currently a STUB that generates the canonical
 * payload — real integration requires:
 *   - ZATCA: XAdES signing + UUID + QR (Saudi Arabia)
 *   - Iraqi: ASCII QR + sequential numbering (forthcoming)
 *   - EU: EN 16931 XML format
 *
 * Permission: finance.receipts.create (e-invoicing is part of receipt lifecycle)
 */
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.receipts.create");
  const body = await parseBody(req, generateSchema);

  // Load invoice + company
  const invoice = await db.salesInvoice.findFirst({
    where: { id: body.invoice_id, companyId: session.companyId, deletedAt: null },
    include: {
      customer: { select: { name: true, code: true, phone: true, address: true } },
      lines: { include: { product: { select: { name: true, code: true, barcode: true } } } },
      company: { select: { name: true, taxNumber: true, phone: true, address: true } },
    },
  });
  if (!invoice) throw new ApiError("VAL_003", "الفاتورة غير موجودة");

  const uuid = crypto.randomUUID();

  // Build e-invoice payload (EN 16931 / ZATCA-compatible structure)
  const eInvoice = {
    format: body.format,
    uuid,
    issue_date: invoice.invoiceDate.toISOString(),
    invoice_number: invoice.number,
    currency: invoice.currencyCode ?? "IQD",
    exchange_rate: invoice.exchangeRate ? Number(invoice.exchangeRate) : 1,
    supplier: {
      name: invoice.company.name,
      tax_number: invoice.company.taxNumber,
      phone: invoice.company.phone,
      address: invoice.company.address,
    },
    customer: {
      name: invoice.customer?.name ?? "Walk-in",
      code: invoice.customer?.code,
      tax_number: null, // Customer has no taxNumber field — could be added later
      phone: invoice.customer?.phone,
      address: invoice.customer?.address,
    },
    line_items: invoice.lines.map((l) => ({
      product: l.product?.name,
      code: l.product?.code,
      barcode: l.product?.barcode,
      quantity: Number(l.qty),
      unit_price: Number(l.unitPrice),
      line_total: Number(l.lineTotal ?? l.qty.mul(l.unitPrice)),
    })),
    totals: {
      subtotal: Number(invoice.subtotal),
      grand_total: Number(invoice.grandTotal),
      paid_amount: Number(invoice.paidAmount),
      due_amount: Number(invoice.grandTotal) - Number(invoice.paidAmount),
    },
    payment: {
      method: invoice.saleType,
      status: invoice.status,
    },
    // Signing placeholder — real implementation would sign with XAdES / UUID QR
    signature: {
      algorithm: "stub-sha256",
      value: "PENDING_IMPLEMENTATION",
      note: "Real ZATCA/EU signing requires certificate + private key — stub for now",
    },
    qr_payload: body.format === "ZATCA" ? `zatca:${uuid}:${invoice.number}` : `einv:${uuid}:${invoice.number}`,
  };

  // Audit
  await db.auditLog.create({
    data: {
      companyId: session.companyId,
      userId: session.userId,
      action: "EXPORT",
      module: "finance",
      entityType: "e_invoice",
      entityId: invoice.id,
      newValues: JSON.stringify({ format: body.format, uuid }),
      ipAddress: req.headers.get("x-forwarded-for"),
      userAgent: req.headers.get("user-agent"),
    },
  });

  return ok({
    generated: true,
    format: body.format,
    uuid,
    invoice_number: invoice.number,
    e_invoice: eInvoice,
    note: "هذا نموذج أولي — التوقيع الفعلي (ZATCA XAdES / EU EN 16931) يتطلب شهادة ومفتاح خاص. هيكل البيانات جاهز للتكامل.",
  }, undefined, 201);
});
