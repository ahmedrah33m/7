// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { num, dec, sumOf, moneyR } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/finance/budget-vs-actual
 *   ?period=YYYY-MM   (defaults to current month)
 *   ?category_id=N
 *
 * Phase 23-25 — Budget vs Actual report
 * Computes for each ExpenseCategory:
 *   - monthly_budget (from ExpenseCategory.monthlyBudget)
 *   - actual (sum of PaymentVouchers in the period with that expenseCategoryId)
 *   - variance = actual - budget
 *   - usage_pct = actual / budget * 100
 *   - alert = true when usage_pct >= 80
 *
 * Permission: finance.budgets.view (reuses existing)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "accounting.budgets.view");
  const url = new URL(req.url);
  const period = url.searchParams.get("period") ?? new Date().toISOString().slice(0, 7); // YYYY-MM
  const categoryId = url.searchParams.get("category_id");

  // Parse period
  const [yearStr, monthStr] = period.split("-");
  const year = Number(yearStr);
  const month = Number(monthStr);
  if (!year || !month || month < 1 || month > 12) {
    return ok({ error: "صياغة الفترة غير صحيحة (YYYY-MM)" }, undefined, 400);
  }
  const dateFrom = new Date(year, month - 1, 1);
  const dateTo = new Date(year, month, 0, 23, 59, 59, 999);

  // Get expense categories with budgets
  const categories = await db.expenseCategory.findMany({
    where: {
      companyId: session.companyId,
      deletedAt: null,
      type: "EXPENSE",
      ...(categoryId ? { id: Number(categoryId) } : {}),
    },
    orderBy: { code: "asc" },
  });

  // Get actual expenses per category in the period
  const vouchers = await db.paymentVoucher.findMany({
    where: {
      companyId: session.companyId,
      deletedAt: null,
      status: "POSTED",
      paymentDate: { gte: dateFrom, lte: dateTo },
      expenseCategoryId: { not: null },
    },
    select: { expenseCategoryId: true, amount: true },
  });

  const actualByCategory: Record<number, number> = {};
  for (const v of vouchers) {
    if (v.expenseCategoryId == null) continue;
    actualByCategory[v.expenseCategoryId] = (actualByCategory[v.expenseCategoryId] ?? 0) + Number(v.amount);
  }

  const rows = categories.map((c) => {
    const budget = Number(c.monthlyBudget ?? 0);
    const actual = actualByCategory[c.id] ?? 0;
    const variance = actual - budget;
    const usagePct = budget > 0 ? (actual / budget) * 100 : (actual > 0 ? 100 : 0);
    const alert = usagePct >= 80;
    return {
      category_id: c.id,
      category_code: c.code,
      category_name: c.name,
      monthly_budget: budget,
      actual: actual,
      variance: variance,
      usage_pct: Math.round(usagePct * 100) / 100,
      alert: alert,
      alert_level: usagePct >= 100 ? "OVER" : usagePct >= 80 ? "WARNING" : "OK",
    };
  });

  const totals = {
    budget: rows.reduce((s, r) => s + r.monthly_budget, 0),
    actual: rows.reduce((s, r) => s + r.actual, 0),
    variance: 0,
    alerts: rows.filter((r) => r.alert).length,
  };
  totals.variance = totals.actual - totals.budget;

  return ok({
    period,
    date_from: dateFrom.toISOString(),
    date_to: dateTo.toISOString(),
    totals,
    rows,
  });
});
