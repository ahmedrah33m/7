// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
export const dynamic = "force-dynamic";
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.statements.view");
  const url = new URL(req.url);
  const type = url.searchParams.get("type");
  const rows = await db.account.findMany({ where: { companyId: session.companyId, deletedAt: null, ...(type ? { type } : {}) }, orderBy: { code: "asc" } });
  return ok(rows.map((a) => ({ id: a.id, code: a.code, name: a.name, name_en: a.nameEn, type: a.type, subtype: a.subtype, is_cash_account: a.isCashAccount, is_receivable: a.isReceivable, is_payable: a.isPayable, is_open: a.isOpen, opening_balance: a.openingBalance, current_balance: a.currentBalance, parent_id: a.parentId })));
});
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.settings.edit");
  const { getOrCreateStandardAccounts } = await import("@/lib/accounting-service");
  const result = await getOrCreateStandardAccounts(session.companyId);
  return ok(result);
});
