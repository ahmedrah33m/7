// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { nextDocumentNumber } from "@/lib/document-number";
import { writeAudit } from "@/lib/audit";
import { Decimal, dec, moneyR, num, sumOf } from "@/lib/decimal";
import { z } from "zod";
export const dynamic = "force-dynamic";
const clockInSchema = z.object({ cashbox_id: z.number().int().positive(), opening_balance: z.number().nonnegative().optional() });
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cashboxes.view");
  const url = new URL(req.url);
  const status = url.searchParams.get("status");
  const cashboxId = url.searchParams.get("cashbox_id");
  const rows = await db.cashierShift.findMany({ where: { companyId: session.companyId, ...(status ? { status } : {}), ...(cashboxId ? { cashboxId: Number(cashboxId) } : {}) }, include: { cashbox: { select: { id: true, name: true, code: true, currency: true } }, user: { select: { id: true, username: true, fullName: true } } }, orderBy: { clockInAt: "desc" }, take: 100 });
  return ok(rows.map((s) => ({ id: s.id, number: s.number, clock_in_at: s.clockInAt, clock_out_at: s.clockOutAt, opening_balance: s.openingBalance, closing_balance: s.closingBalance, total_receipts: s.totalReceipts, total_payments: s.totalPayments, transactions_count: s.transactionsCount, status: s.status, notes: s.notes, cashbox: s.cashbox, user: s.user })));
});
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.receipts.create");
  const body = await parseBody(req, clockInSchema);
  const box = await db.cashbox.findFirst({ where: { id: body.cashbox_id, companyId: session.companyId, deletedAt: null, status: "ACTIVE" } });
  if (!box) throw new ApiError("CASHBOX_001", "الصندوق غير موجود أو مغلق");
  const existing = await db.cashierShift.findFirst({ where: { userId: session.userId, cashboxId: box.id, status: "OPEN" } });
  if (existing) throw new ApiError("VAL_004", "لديك وردية مفتوحة بالفعل على هذا الصندوق");
  const openingBalance = body.opening_balance !== undefined ? moneyR(dec(body.opening_balance)) : dec(box.balance);
  const number = await nextDocumentNumber(db, session.companyId, "CLOSING");
  const shiftNumber = number.replace("CLOS", "SHIFT");
  const shift = await db.cashierShift.create({ data: { companyId: session.companyId ?? box.branchId, cashboxId: box.id, userId: session.userId, number: shiftNumber, clockInAt: new Date(), openingBalance, status: "OPEN" } });
  await writeAudit({ userId: session.userId, companyId: session.companyId, ipAddress: undefined, userAgent: undefined }, { action: "CREATE", module: "finance", entityType: "cashier_shift", entityId: shift.id, newValues: { number: shift.number, cashbox: box.name, opening: num(openingBalance) } });
  return ok({ id: shift.id, number: shift.number, cashbox: { id: box.id, name: box.name, currency: box.currency }, opening_balance: num(openingBalance), clock_in_at: shift.clockInAt, status: "OPEN" }, undefined, 201);
});
