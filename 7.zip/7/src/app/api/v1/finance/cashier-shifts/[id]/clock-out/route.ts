// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { Decimal, dec, moneyR, num, sumOf } from "@/lib/decimal";
import { z } from "zod";
export const dynamic = "force-dynamic";
const clockOutSchema = z.object({ closing_balance: z.number().optional(), notes: z.string().max(500).optional() });
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.receipts.create");
  const { id } = await ctx.params;
  const body = await parseBody(req, clockOutSchema);
  const shift = await db.cashierShift.findFirst({ where: { id: Number(id), companyId: session.companyId, status: "OPEN" } });
  if (!shift) throw new ApiError("VAL_003", "الوردية غير موجودة أو مغلقة مسبقًا");
  if (shift.userId !== session.userId && !session.permissions.has("finance.cash_closings.edit")) throw new ApiError("PERM_001", "لا يمكنك إغلاق وردية لمستخدم آخر");
  const txs = await db.cashTransaction.findMany({ where: { cashboxId: shift.cashboxId, createdAt: { gte: shift.clockInAt }, isReversed: false, createdBy: shift.userId } });
  const totalReceipts = sumOf(txs.filter((t) => t.direction === "IN"), (t) => dec(t.amount));
  const totalPayments = sumOf(txs.filter((t) => t.direction === "OUT"), (t) => dec(t.amount));
  const box = await db.cashbox.findFirst({ where: { id: shift.cashboxId } });
  const closingBalance = body.closing_balance !== undefined ? moneyR(dec(body.closing_balance)) : (box ? dec(box.balance) : dec(shift.openingBalance));
  await db.cashierShift.update({ where: { id: shift.id }, data: { status: "CLOSED", clockOutAt: new Date(), closingBalance, totalReceipts, totalPayments, transactionsCount: txs.length, notes: body.notes } });
  await writeAudit({ userId: session.userId, companyId: session.companyId, ipAddress: undefined, userAgent: undefined }, { action: "CLOSE", module: "finance", entityType: "cashier_shift", entityId: shift.id, newValues: { status: "CLOSED", total_receipts: num(totalReceipts), total_payments: num(totalPayments), transactions: txs.length } });
  return ok({ id: shift.id, status: "CLOSED", clock_in_at: shift.clockInAt, clock_out_at: new Date(), opening_balance: num(shift.openingBalance), closing_balance: num(closingBalance), total_receipts: num(totalReceipts), total_payments: num(totalPayments), transactions_count: txs.length });
});
