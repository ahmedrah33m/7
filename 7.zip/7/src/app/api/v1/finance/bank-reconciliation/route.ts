// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { Decimal, dec, moneyR, num } from "@/lib/decimal";
import { z } from "zod";
export const dynamic = "force-dynamic";

/** GET /api/v1/finance/bank-reconciliation?bank_account_id=X — list reconciliation matches */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.statements.view");
  const url = new URL(req.url);
  const bankId = url.searchParams.get("bank_account_id");
  const dateFrom = url.searchParams.get("date_from") ? new Date(url.searchParams.get("date_from")!) : new Date(Date.now() - 30 * 86400000);
  const dateTo = url.searchParams.get("date_to") ? new Date(url.searchParams.get("date_to")!) : new Date();

  // Get system transactions for this bank
  const systemTxs = await db.cashTransaction.findMany({
    where: {
      companyId: session.companyId, createdAt: { gte: dateFrom, lte: dateTo },
      isReversed: false,
      transactionType: { in: ["BANK_DEPOSIT", "BANK_WITHDRAWAL", "CASH_TRANSFER_IN", "CASH_TRANSFER_OUT"] },
      ...(bankId ? { cashbox: { type: "BANK" } } : {}),
    },
    include: { cashbox: { select: { id: true, name: true, code: true, currency: true } } },
    orderBy: { createdAt: "asc" },
    take: 500,
  });

  const totalIn = systemTxs.filter((t) => t.direction === "IN").reduce((s, t) => s + Number(t.amount), 0);
  const totalOut = systemTxs.filter((t) => t.direction === "OUT").reduce((s, t) => s + Number(t.amount), 0);

  return ok({
    system_transactions: systemTxs.map((t) => ({
      id: t.id, date: t.createdAt, direction: t.direction, type: t.transactionType,
      amount: num(dec(t.amount)), number: t.transactionNumber, note: t.note,
      cashbox: t.cashbox, matched: false, // would be true if matched to bank statement
    })),
    summary: {
      date_from: dateFrom.toISOString(), date_to: dateTo.toISOString(),
      total_in: totalIn, total_out: totalOut, net: totalIn - totalOut,
      transactions_count: systemTxs.length,
    },
  });
});

/** POST /api/v1/finance/bank-reconciliation — upload bank statement entries and match */
const reconcileSchema = z.object({
  bank_account_id: z.number().int().positive(),
  statement_entries: z.array(z.object({
    date: z.string().datetime(),
    description: z.string().max(200),
    amount: z.number(), // positive = credit (in), negative = debit (out)
    reference: z.string().max(80).optional(),
  })).min(1).max(500),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.statements.view");
  const body = await parseBody(req, reconcileSchema);

  // Get system transactions for this bank
  const systemTxs = await db.cashTransaction.findMany({
    where: {
      companyId: session.companyId, isReversed: false,
      transactionType: { in: ["BANK_DEPOSIT", "BANK_WITHDRAWAL", "CASH_TRANSFER_IN", "CASH_TRANSFER_OUT"] },
    },
    orderBy: { createdAt: "asc" },
    take: 500,
  });

  // Match by amount ± tolerance
  const TOLERANCE = 100; // 100 IQD tolerance
  const matched: any[] = [];
  const unmatched: any[] = [];

  for (const entry of body.statement_entries) {
    const entryAmount = Math.abs(entry.amount);
    const entryDirection = entry.amount > 0 ? "IN" : "OUT";
    const match = systemTxs.find((tx) =>
      tx.direction === entryDirection &&
      Math.abs(Number(tx.amount) - entryAmount) <= TOLERANCE &&
      !matched.some((m) => m.system_tx_id === tx.id)
    );

    if (match) {
      matched.push({
        statement_entry: entry,
        system_tx: { id: match.id, number: match.transactionNumber, amount: num(dec(match.amount)), date: match.createdAt },
        match_type: "AMOUNT",
        variance: Number(match.amount) - entryAmount,
      });
    } else {
      unmatched.push({ statement_entry: entry, reason: "No matching system transaction found" });
    }
  }

  // System transactions not in bank statement
  const unmatchedSystem = systemTxs.filter((tx) => !matched.some((m) => m.system_tx_id === tx.id)).map((tx) => ({
    system_tx: { id: tx.id, number: tx.transactionNumber, amount: num(dec(tx.amount)), date: tx.createdAt, direction: tx.direction },
    reason: "Not found in bank statement",
  }));

  return ok({
    matched,
    unmatched_bank: unmatched,
    unmatched_system: unmatchedSystem,
    summary: {
      total_statement_entries: body.statement_entries.length,
      matched_count: matched.length,
      unmatched_bank_count: unmatched.length,
      unmatched_system_count: unmatchedSystem.length,
      match_rate_pct: body.statement_entries.length > 0 ? Number(((matched.length / body.statement_entries.length) * 100).toFixed(2)) : 0,
    },
  });
});
