// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { postJournalEntry, type JournalLineInput } from "@/lib/accounting-service";
import { z } from "zod";
export const dynamic = "force-dynamic";
const journalEntrySchema = z.object({ description: z.string().max(500).optional(), notes: z.string().max(500).optional(), cost_center_id: z.number().int().positive().optional(), entry_date: z.string().datetime().optional(), lines: z.array(z.object({ account_code: z.string().min(1).max(20), debit: z.number().nonnegative().default(0), credit: z.number().nonnegative().default(0), customer_id: z.number().int().positive().optional(), supplier_id: z.number().int().positive().optional(), cashbox_id: z.number().int().positive().optional(), cost_center_id: z.number().int().positive().optional(), description: z.string().max(200).optional() })).min(2) });
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.statements.view");
  const url = new URL(req.url);
  const status = url.searchParams.get("status");
  const source = url.searchParams.get("source");
  const rows = await db.journalEntry.findMany({ where: { companyId: session.companyId, deletedAt: null, ...(status ? { status } : {}), ...(source ? { source } : {}) }, include: { lines: { include: { account: { select: { code: true, name: true, type: true } } } }, period: { select: { id: true, name: true } }, costCenter: { select: { id: true, name: true, code: true } }, createdBy: { select: { id: true, fullName: true } } }, orderBy: { entryDate: "desc" }, take: 100 });
  return ok(rows.map((e) => ({ id: e.id, number: e.number, entry_date: e.entryDate, description: e.description, source: e.source, source_type: e.sourceType, source_id: e.sourceId, status: e.status, is_reversed: e.isReversed, total_debit: e.totalDebit, total_credit: e.totalCredit, period: e.period, cost_center: e.costCenter, created_by: e.createdBy?.fullName, notes: e.notes, created_at: e.createdAt, lines: e.lines.map((l) => ({ id: l.id, account: l.account, account_code: l.accountCode, account_name: l.accountName, debit: l.debit, credit: l.credit, description: l.description })) })));
});
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.statements.view");
  const body = await parseBody(req, journalEntrySchema);
  const lines: JournalLineInput[] = body.lines.map((l) => ({ accountCode: l.account_code, debit: l.debit, credit: l.credit, customerId: l.customer_id, supplierId: l.supplier_id, cashboxId: l.cashbox_id, costCenterId: l.cost_center_id, description: l.description }));
  const result = await postJournalEntry({ userId: session.userId, companyId: session.companyId }, { description: body.description, lines, notes: body.notes, costCenterId: body.cost_center_id, entryDate: body.entry_date ? new Date(body.entry_date) : undefined });
  return ok(result, undefined, 201);
});
