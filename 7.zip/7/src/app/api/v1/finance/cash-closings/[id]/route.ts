// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
export const dynamic = "force-dynamic";
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.cash_closings.view");
  const { id } = await ctx.params;
  const { db } = await import("@/lib/db");
  const c = await db.cashboxClosing.findFirst({ where: { id: Number(id), companyId: session.companyId }, include: { cashbox: true, denominations: true } });
  if (!c) return ok({ valid: false, message: "الإغلاق غير موجود" }, undefined, 404);
  return ok(c);
});
