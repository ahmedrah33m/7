// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { reopenCashbox, type CashActor } from "@/lib/cashbox-service";
import { z } from "zod";
export const dynamic = "force-dynamic";
const reopenSchema = z.object({ reason: z.string().min(3).max(500) });
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.cash_closings.edit");
  const { id } = await ctx.params;
  const { reason } = await parseBody(req, reopenSchema);
  const result = await reopenCashbox({ userId: session.userId, companyId: session.companyId } as any, Number(id), reason);
  return ok(result);
});
