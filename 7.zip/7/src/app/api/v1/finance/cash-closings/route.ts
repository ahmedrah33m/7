// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { closeCashbox, type CloseCashboxInput, type CashActor } from "@/lib/cashbox-service";
import { z } from "zod";

export const dynamic = "force-dynamic";

const closingSchema = z.object({
  cashbox_id: z.number().int().positive(),
  branch_id: z.number().int().positive().optional(),
  closing_date: z.string().datetime().optional(),
  actual_cash: z.number().nonnegative().optional(),
  denominations: z.array(z.object({
    denomination: z.number().positive(),
    count: z.number().int().nonnegative(),
  })).optional(),
  difference_reason: z.string().max(500).optional(),
  notes: z.string().max(500).optional(),
});

export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cash_closings.view");
  const url = new URL(req.url);
  const cashboxId = url.searchParams.get("cashbox_id");
  const rows = await db.cashboxClosing.findMany({
    where: {
      companyId: session.companyId,
      ...(cashboxId ? { cashboxId: Number(cashboxId) } : {}),
    },
    include: {
      cashbox: { select: { id: true, name: true, code: true, currency: true } },
      denominations: true,
    },
    orderBy: { closingDate: "desc" },
    take: 100,
  });
  return ok(rows.map((c) => ({
    id: c.id,
    closing_date: c.closingDate,
    cashbox: c.cashbox,
    opening_balance: c.openingBalance,
    total_receipts: c.totalReceipts,
    total_payments: c.totalPayments,
    transfers_in: c.transfersIn,
    transfers_out: c.transfersOut,
    book_balance: c.bookBalance,
    actual_cash: c.actualCash,
    difference: c.difference,
    difference_reason: c.differenceReason,
    status: c.status,
    denomination_total: c.denominationTotal,
    denominations: c.denominations,
    closed_at: c.closedAt,
    reopened_at: c.reopenedAt,
    reopen_reason: c.reopenReason,
    notes: c.notes,
    created_at: c.createdAt,
  })));
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cash_closings.create");
  const body = await parseBody(req, closingSchema);

  // Phase 38 — Branch isolation: resolve branch from session, not body.
  const branchId = body.branch_id ?? session.activeBranchId ?? session.branchIds[0] ?? 0;
  if (!branchId) throw new ApiError("SCOPE_003", "لا يوجد فرع نشط في الجلسة");

  const input: CloseCashboxInput = {
    cashboxId: body.cashbox_id,
    branchId,
    closingDate: body.closing_date ? new Date(body.closing_date) : undefined,
    actualCash: body.actual_cash,
    denominations: body.denominations,
    differenceReason: body.difference_reason,
    notes: body.notes,
  };
  const result = await closeCashbox(
    {
      userId: session.userId,
      companyId: session.companyId,
      branchId,
      ip: req.headers.get("x-forwarded-for"),
      userAgent: req.headers.get("user-agent"),
    },
    input
  );
  return ok(result, undefined, 201);
});
