// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { cashboxWhere } from "@/lib/scope";
import { reconcileCashbox } from "@/lib/cashbox-service";

export const dynamic = "force-dynamic";

/**
 * GET    /api/v1/finance/cash-reconciliation
 *   ?cashbox_id=&from=&to=&status=DRAFT|CLOSED|REOPENED
 *        → list reconciliation records (DRAFT closings, by default).
 *
 * POST   /api/v1/finance/cash-reconciliation
 *   Body: { cashbox_id, actualCash?, denominations?, closingDate?, notes? }
 *        → compute book-vs-actual WITHOUT closing (Phase 67 standalone).
 *
 * Permission: finance.cashboxes.reconcile — Phase 37.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cashboxes.reconcile");
  const url = new URL(req.url);
  const cashboxId = url.searchParams.get("cashbox_id");
  const status = url.searchParams.get("status") ?? "DRAFT";
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");

  // Limit to cashboxes in session scope
  const cashboxes = await db.cashbox.findMany({
    where: { companyId: session.companyId, deletedAt: null, ...cashboxWhere(session) },
    select: { id: true },
  });
  const cashboxIds = cashboxes.map((c) => c.id);

  const rows = await db.cashboxClosing.findMany({
    where: {
      companyId: session.companyId,
      deletedAt: null,
      status,
      ...(cashboxId ? { cashboxId: Number(cashboxId) } : { cashboxId: { in: cashboxIds } }),
      ...(from || to ? { closingDate: { ...(from ? { gte: new Date(from) } : {}), ...(to ? { lte: new Date(to) } : {}) } } : {}),
    },
    orderBy: { closingDate: "desc" },
    take: 100,
    include: {
      cashbox: { select: { id: true, name: true, code: true, currency: true } },
      denominations: true,
    },
  });

  return ok({
    rows: rows.map((r) => ({
      id: r.id,
      number: r.number,
      cashbox_id: r.cashboxId,
      cashbox: r.cashbox,
      closing_date: r.closingDate.toISOString(),
      opening_balance: r.openingBalance,
      total_receipts: r.totalReceipts,
      total_payments: r.totalPayments,
      transfers_in: r.transfersIn,
      transfers_out: r.transfersOut,
      book_balance: r.bookBalance,
      actual_cash: r.actualCash,
      difference: r.difference,
      difference_reason: r.differenceReason,
      denomination_total: r.denominationTotal,
      status: r.status,
      denominations: r.denominations,
    })),
  });
});

const denomSchema = z.object({
  denomination: z.number().positive(),
  count: z.number().int().nonnegative(),
});

const postSchema = z.object({
  cashbox_id: z.number().int().positive(),
  actualCash: z.number().nonnegative().optional(),
  denominations: z.array(denomSchema).optional(),
  closingDate: z.string().datetime().optional(),
  notes: z.string().max(1000).optional(),
}).refine(
  (d) => d.actualCash != null || (Array.isArray(d.denominations) && d.denominations.length > 0),
  { message: "يلزم تحديد actualCash أو تفصيل الفئات" }
);

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cashboxes.reconcile");
  const body = await parseBody(req, postSchema);

  const result = await reconcileCashbox(
    {
      userId: session.userId,
      companyId: session.companyId,
      branchId: session.activeBranchId,
      ip: req.headers.get("x-forwarded-for"),
      userAgent: req.headers.get("user-agent"),
    },
    {
      cashboxId: body.cashbox_id,
      actualCash: body.actualCash,
      denominations: body.denominations,
      closingDate: body.closingDate ? new Date(body.closingDate) : null,
      notes: body.notes,
    }
  );

  return ok(result, undefined, 201);
});
