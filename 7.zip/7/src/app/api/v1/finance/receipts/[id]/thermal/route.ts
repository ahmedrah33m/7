// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { htmlToPdf, buildReceiptThermalHtml, amountInWords } from "@/lib/pdf";
import QRCode from "qrcode";
export const dynamic = "force-dynamic";

/** GET /api/v1/finance/receipts/[id]/thermal — 80mm thermal receipt */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.receipts.print");
  const { id } = await ctx.params;
  const r = await db.receiptVoucher.findFirst({
    where: { id: Number(id), companyId: session.companyId, deletedAt: null },
    include: { customer: { select: { code: true, phone: true } }, cashbox: { select: { name: true } },
      company: { select: { name: true, phone: true, address: true, taxNumber: true } } },
  });
  if (!r) return ok({ error: "Not found" }, undefined, 404);
  const verifyUrl = `${req.nextUrl.origin}/verify/${r.verifyToken}`;
  const qrSvg = await QRCode.toString(verifyUrl, { type: "svg", width: 160, margin: 0 });
  let invoiceSnap: any = null;
  try { invoiceSnap = r.invoiceSnapshot ? JSON.parse(r.invoiceSnapshot)[0] : null; } catch {}
  const customer = r.customerId ? await db.customer.findFirst({ where: { id: r.customerId }, select: { balance: true } }) : null;
  const html = buildReceiptThermalHtml({
    companyName: r.company.name, companyPhone: r.company.phone, companyAddress: r.company.address,
    companyTaxNumber: r.company.taxNumber, number: r.number, receiptDate: new Date(r.receiptDate).toLocaleString("ar-IQ"),
    cashboxName: r.cashbox.name, recipientName: r.recipientName, customerCode: r.customer?.code ?? null,
    customerPhone: r.customer?.phone ?? null, amount: Number(r.amount), amountInWords: amountInWords(Number(r.amount), r.currency),
    currency: r.currency, paymentMethod: r.paymentMethod, referenceNumber: r.referenceNumber, description: r.description,
    notes: r.notes, receivedBy: r.receivedBy, invoiceNumber: invoiceSnap?.invoiceNumber ?? null,
    grandTotal: invoiceSnap?.grandTotal ?? null, previouslyPaid: invoiceSnap?.previouslyPaid ?? null,
    currentPayment: invoiceSnap?.current ?? null, remaining: invoiceSnap?.remaining ?? null,
    previousBalance: customer ? Number(customer.balance) + Number(r.amount) : null,
    newBalance: customer ? Number(customer.balance) : null, qrSvg, qrVerifyUrl: verifyUrl,
  } as any);
  try {
    const pdf = await htmlToPdf(html);
    return new Response(pdf, { headers: { "Content-Type": "application/pdf", "Content-Disposition": `inline; filename="thermal-${r.number}.pdf"` } });
  } catch { return ok({ error: "PDF engine unavailable", html }, undefined, 503); }
});
