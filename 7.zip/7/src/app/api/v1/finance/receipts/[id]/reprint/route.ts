// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

/** POST /api/v1/finance/receipts/[id]/reprint — track reprint (doesn't create new receipt) */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.receipts.print");
  const { id } = await ctx.params;
  const r = await db.receiptVoucher.findFirst({ where: { id: Number(id), companyId: session.companyId, deletedAt: null } });
  if (!r) return ok({ error: "Not found" }, undefined, 404);
  await db.receiptVoucher.update({ where: { id: r.id }, data: { printCount: { increment: 1 } } });
  await writeAudit({ userId: session.userId, companyId: session.companyId, ipAddress: undefined, userAgent: undefined },
    { action: "PRINT", module: "finance", entityType: "receipt_voucher", entityId: r.id, newValues: { number: r.number, reprint_count: r.printCount + 1 } });
  return ok({ id: r.id, number: r.number, print_count: r.printCount + 1, message: "Reprint tracked — no new receipt created" });
});
