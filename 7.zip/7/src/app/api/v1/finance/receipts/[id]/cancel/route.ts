// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { cancelReceiptVoucher, type CashActor } from "@/lib/cashbox-service";
import { z } from "zod";
export const dynamic = "force-dynamic";
const cancelSchema = z.object({ reason: z.string().min(3).max(500) });
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.receipts.cancel");
  const { id } = await ctx.params;
  const { reason } = await parseBody(req, cancelSchema);
  const result = await cancelReceiptVoucher({ userId: session.userId, companyId: session.companyId } as any, Number(id), reason);
  return ok(result);
});
