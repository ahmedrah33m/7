// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { branchWhere } from "@/lib/scope";
import { createReceiptVoucher, type CashActor } from "@/lib/cashbox-service";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/finance/receipts — list receipt vouchers (finance.receipts.view)
 *   Query params (all optional):
 *     search       — match against number OR recipientName OR customer.name OR supplier.name
 *     status       — POSTED | CANCELLED
 *     customer_id  — filter by customer
 *     supplier_id  — filter by supplier
 *     cashbox_id   — filter by cashbox
 *     date_from    — ISO date (inclusive)
 *     date_to      — ISO date (inclusive)
 *     amount_min   — minimum amount
 *     amount_max   — maximum amount
 *     per_page     — page size (default 50, max 200)
 *
 * POST /api/v1/finance/receipts — create a receipt voucher (finance.receipts.create)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.receipts.view");
  const url = new URL(req.url);
  const perPage = Math.min(200, Math.max(1, Number(url.searchParams.get("per_page") ?? 50)));
  const search = url.searchParams.get("search")?.trim() || "";
  const status = url.searchParams.get("status");
  const customerId = url.searchParams.get("customer_id");
  const supplierId = url.searchParams.get("supplier_id");
  const cashboxId = url.searchParams.get("cashbox_id");
  const dateFrom = url.searchParams.get("date_from");
  const dateTo = url.searchParams.get("date_to");
  const amountMin = url.searchParams.get("amount_min");
  const amountMax = url.searchParams.get("amount_max");

  const where: any = {
    companyId: session.companyId,
    deletedAt: null,
    ...branchWhere(session),
  };
  if (status) where.status = status;
  if (customerId) where.customerId = Number(customerId);
  if (supplierId) where.supplierId = Number(supplierId);
  if (cashboxId) where.cashboxId = Number(cashboxId);
  if (dateFrom || dateTo) {
    where.receiptDate = {};
    if (dateFrom) where.receiptDate.gte = new Date(dateFrom);
    if (dateTo) {
      const end = new Date(dateTo);
      end.setHours(23, 59, 59, 999);
      where.receiptDate.lte = end;
    }
  }
  if (amountMin || amountMax) {
    where.amount = {};
    if (amountMin) where.amount.gte = Number(amountMin);
    if (amountMax) where.amount.lte = Number(amountMax);
  }
  if (search) {
    where.OR = [
      { number: { contains: search } },
      { recipientName: { contains: search } },
      { referenceNumber: { contains: search } },
      { customer: { name: { contains: search } } },
      { supplier: { name: { contains: search } } },
      { receivedBy: { contains: search } },
    ];
  }

  const rows = await db.receiptVoucher.findMany({
    where,
    orderBy: { receiptDate: "desc" },
    take: perPage,
    include: {
      customer: { select: { id: true, name: true, code: true } },
      supplier: { select: { id: true, name: true, code: true } },
      cashbox: { select: { id: true, name: true } },
    },
  });

  return ok(rows.map((r) => ({
    id: r.id,
    number: r.number,
    receiptDate: r.receiptDate,
    recipientName: r.recipientName,
    amount: r.amount,
    paymentMethod: r.paymentMethod,
    status: r.status,
    referenceNumber: r.referenceNumber,
    customer: r.customer ? { id: r.customer.id, name: r.customer.name, code: r.customer.code } : null,
    supplier: r.supplier ? { id: r.supplier.id, name: r.supplier.name, code: r.supplier.code } : null,
    cashbox: r.cashbox ? { id: r.cashbox.id, name: r.cashbox.name } : null,
  })));
});

const createSchema = z.object({
  customer_id: z.number().int().positive().optional().nullable(),
  supplier_id: z.number().int().positive().optional().nullable(),
  cashbox_id: z.number().int().positive(),
  branch_id: z.number().int().positive().optional(),
  amount: z.number().positive(),
  currency: z.string().optional(),
  exchange_rate: z.number().optional().nullable(),
  payment_method: z.string().optional(),
  reference_number: z.string().optional().nullable(),
  bank_name: z.string().optional().nullable(),
  bank_account: z.string().optional().nullable(),
  card_last4: z.string().max(4).optional().nullable(),
  received_by: z.string().optional().nullable(),
  description: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
  idempotency_key: z.string().optional().nullable(),
  invoice_id: z.number().int().positive().optional().nullable(),
  allocations: z.array(z.object({
    invoice_id: z.number().int().positive(),
    invoice_type: z.enum(["SALES", "PURCHASE"]),
    amount: z.number().positive(),
  })).optional(),
  // ---- Phase 15 — Mixed payment split amounts -------------------------
  cash_amount: z.number().nonnegative().optional().nullable(),
  card_amount: z.number().nonnegative().optional().nullable(),
  bank_amount: z.number().nonnegative().optional().nullable(),
  on_account_amount: z.number().nonnegative().optional().nullable(),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.receipts.create");
  const body = await parseBody(req, createSchema);

  // Resolve branchId: prefer body, fall back to active session, then home.
  // Phase 38 — Branch isolation: the resolved branch must be in the session set.
  const effBranchIds = session.activeBranchId
    ? [session.activeBranchId]
    : session.branchIds;
  let branchId = body.branch_id ?? session.activeBranchId ?? session.branchIds[0] ?? 0;
  if (!branchId) throw new ApiError("SCOPE_003", "لا يوجد فرع نشط في الجلسة");
  if (!effBranchIds.includes(branchId)) {
    throw new ApiError("SCOPE_003", "الفرع المطلوب خارج نطاق الجلسة");
  }

  const actor: CashActor = {
    userId: session.userId,
    companyId: session.companyId,
    branchId,
    ip: req.headers.get("x-forwarded-for") ?? undefined,
    userAgent: req.headers.get("user-agent") ?? undefined,
  };

  const result = await createReceiptVoucher(actor, {
    customerId: body.customer_id ?? null,
    supplierId: body.supplier_id ?? null,
    cashboxId: body.cashbox_id,
    branchId,
    amount: body.amount,
    currency: body.currency,
    exchangeRate: body.exchange_rate ?? null,
    paymentMethod: body.payment_method,
    referenceNumber: body.reference_number ?? null,
    bankName: body.bank_name ?? null,
    bankAccount: body.bank_account ?? null,
    cardLast4: body.card_last4 ?? null,
    receivedBy: body.received_by ?? null,
    description: body.description,
    notes: body.notes,
    idempotencyKey: body.idempotency_key ?? null,
    invoiceId: body.invoice_id ?? null,
    allocations: body.allocations?.map((a) => ({ invoiceId: a.invoice_id, invoiceType: a.invoice_type, amount: a.amount })),
    // Phase 15 — Mixed payment split (validated inside createReceiptVoucher)
    cashAmount: body.cash_amount ?? null,
    cardAmount: body.card_amount ?? null,
    bankAmount: body.bank_amount ?? null,
    onAccountAmount: body.on_account_amount ?? null,
  });

  return ok(result, undefined, 201);
});
