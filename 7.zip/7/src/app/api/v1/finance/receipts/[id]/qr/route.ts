// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import QRCode from "qrcode";

export const dynamic = "force-dynamic";

/** GET /api/v1/finance/receipts/[id]/qr — get QR SVG for receipt */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.receipts.view");
  const { id } = await ctx.params;
  const r = await db.receiptVoucher.findFirst({ where: { id: Number(id), companyId: session.companyId, deletedAt: null } });
  if (!r) return ok({ error: "Not found" }, undefined, 404);
  const verifyUrl = `${req.nextUrl.origin}/verify/${r.verifyToken}`;
  const svg = await QRCode.toString(verifyUrl, { type: "svg", width: 200, margin: 2 });
  return ok({ number: r.number, verify_url: verifyUrl, svg });
});
