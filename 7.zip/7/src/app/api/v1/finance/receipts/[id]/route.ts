// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
export const dynamic = "force-dynamic";
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.receipts.view");
  const { id } = await ctx.params;
  const r = await db.receiptVoucher.findFirst({ where: { id: Number(id), companyId: session.companyId, deletedAt: null }, include: { customer: true, supplier: true, cashbox: true, payment: { include: { allocations: true } }, cashTransactions: true } });
  if (!r) return ok({ valid: false, message: "وصل القبض غير موجود" }, undefined, 404);
  return ok({ id: r.id, number: r.number, receipt_date: r.receiptDate, cashbox: r.cashbox, recipient_name: r.recipientName, customer: r.customer, supplier: r.supplier, amount: r.amount, currency: r.currency, exchange_rate: r.exchangeRate, amount_in_cashbox: r.amountInCashbox, payment_method: r.paymentMethod, reference_number: r.referenceNumber, bank_name: r.bankName, bank_account: r.bankAccount, invoice_snapshot: r.invoiceSnapshot, grand_total_snapshot: r.grandTotalSnapshot, previously_paid_snapshot: r.previouslyPaidSnapshot, current_payment_snapshot: r.currentPaymentSnapshot, remaining_snapshot: r.remainingSnapshot, status: r.status, cancel_reason: r.cancelReason, cancelled_at: r.cancelledAt, verify_token: r.verifyToken, qr_data: r.qrData, print_count: r.printCount, description: r.description, notes: r.notes, received_by: r.receivedBy, allocations: r.payment?.allocations ?? [], cash_transactions: r.cashTransactions.map((t) => ({ id: t.id, direction: t.direction, amount: t.amount, balance_before: t.balanceBefore, balance_after: t.balanceAfter, transaction_type: t.transactionType, transaction_number: t.transactionNumber, is_reversed: t.isReversed, note: t.note, created_at: t.createdAt })), created_at: r.createdAt });
});
