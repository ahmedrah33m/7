// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { htmlToPdf, buildReceiptVoucherHtml, amountInWords } from "@/lib/pdf";
import QRCode from "qrcode";

export const dynamic = "force-dynamic";

/** GET /api/v1/finance/receipts/[id]/pdf — download receipt PDF with QR */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.receipts.print");
  const { id } = await ctx.params;

  const r = await db.receiptVoucher.findFirst({
    where: { id: Number(id), companyId: session.companyId, deletedAt: null },
    include: {
      customer: { select: { name: true, code: true, phone: true } },
      supplier: { select: { name: true, code: true, phone: true } },
      cashbox: { select: { name: true, code: true, currency: true } },
      company: { select: { name: true, phone: true, address: true, taxNumber: true } },
      branch: { select: { name: true } },
    },
  });
  if (!r) return ok({ error: "Receipt not found" }, undefined, 404);

  // Generate QR
  const verifyUrl = `${req.nextUrl.origin}/verify/${r.verifyToken}`;
  const qrSvg = await QRCode.toString(verifyUrl, { type: "svg", width: 160, margin: 1 });

  // Parse invoice snapshot
  let invoiceSnap: any = null;
  try { invoiceSnap = r.invoiceSnapshot ? JSON.parse(r.invoiceSnapshot)[0] : null; } catch {}

  // Get customer balance snapshot
  const customer = r.customerId ? await db.customer.findFirst({ where: { id: r.customerId }, select: { balance: true } }) : null;

  const html = buildReceiptVoucherHtml({
    companyName: r.company.name,
    companyPhone: r.company.phone,
    companyAddress: r.company.address,
    companyTaxNumber: r.company.taxNumber,
    branchName: r.branch?.name,
    number: r.number,
    receiptDate: new Date(r.receiptDate).toLocaleString("ar-IQ"),
    cashboxName: r.cashbox.name,
    recipientName: r.recipientName,
    customerCode: r.customer?.code ?? null,
    customerPhone: r.customer?.phone ?? null,
    amount: Number(r.amount),
    amountInWords: amountInWords(Number(r.amount), r.currency),
    currency: r.currency,
    paymentMethod: r.paymentMethod,
    referenceNumber: r.referenceNumber,
    bankName: r.bankName,
    bankAccount: r.bankAccount,
    description: r.description,
    notes: r.notes,
    receivedBy: r.receivedBy,
    invoiceNumber: invoiceSnap?.invoiceNumber ?? null,
    grandTotal: invoiceSnap?.grandTotal ?? null,
    previouslyPaid: invoiceSnap?.previouslyPaid ?? null,
    currentPayment: invoiceSnap?.current ?? null,
    remaining: invoiceSnap?.remaining ?? null,
    previousBalance: customer ? Number(customer.balance) + Number(r.amount) : null,
    newBalance: customer ? Number(customer.balance) : null,
    qrSvg,
    qrVerifyUrl: verifyUrl,
  });

  // Increment print count
  await db.receiptVoucher.update({
    where: { id: r.id },
    data: { printCount: { increment: 1 } },
  });

  try {
    const pdfBuffer = await htmlToPdf(html);
    return new Response(pdfBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="${r.number}.pdf"`,
        "Cache-Control": "private, max-age=0",
      },
    });
  } catch {
    return ok({ error: "PDF engine unavailable — use browser print", html }, undefined, 503);
  }
});
