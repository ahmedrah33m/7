// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler } from "@/lib/api";

export const dynamic = "force-dynamic";

// ESC/POS command bytes
const ESC = 0x1b;
const GS = 0x1d;
const LF = 0x0a;
const INIT = Buffer.from([ESC, 0x40]); // Initialize printer
const ALIGN_CENTER = Buffer.from([ESC, 0x61, 0x01]);
const ALIGN_RIGHT = Buffer.from([ESC, 0x61, 0x02]);
const ALIGN_LEFT = Buffer.from([ESC, 0x61, 0x00]);
const BOLD_ON = Buffer.from([ESC, 0x45, 0x01]);
const BOLD_OFF = Buffer.from([ESC, 0x45, 0x00]);
const DOUBLE_ON = Buffer.from([GS, 0x21, 0x11]);
const DOUBLE_OFF = Buffer.from([GS, 0x21, 0x00]);
const CUT_PAPER = Buffer.from([GS, 0x56, 0x42, 0x00]);
const FEED_LINES = (n: number) => Buffer.from([ESC, 0x64, n]);

/**
 * GET /api/v1/finance/receipts/[id]/escpos
 *
 * Returns raw ESC/POS bytes for direct thermal printer support
 * (Xprinter, Epson TM series, etc.) — 80mm paper.
 *
 * Phase 12-14 — ESC/POS thermal printing (replaces PDF-only thermal).
 *
 * The browser can fetch this and send it via WebUSB / network socket
 * to the printer. No PDF rendering needed.
 *
 * Permission: finance.receipts.print
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.receipts.print");
  const { id } = await ctx.params;

  const r = await db.receiptVoucher.findFirst({
    where: { id: Number(id), companyId: session.companyId, deletedAt: null },
    include: {
      customer: { select: { code: true, phone: true, name: true } },
      cashbox: { select: { name: true } },
      company: { select: { name: true, phone: true, address: true, taxNumber: true } },
    },
  });
  if (!r) return ok({ error: "Not found" }, undefined, 404);

  // Parse invoice snapshot for receipt context
  let invoiceSnap: any = null;
  try {
    const snaps = r.invoiceSnapshot ? JSON.parse(r.invoiceSnapshot) : [];
    invoiceSnap = snaps[0] ?? null;
  } catch {}

  const customer = r.customerId
    ? await db.customer.findFirst({ where: { id: r.customerId }, select: { balance: true } })
    : null;

  // Build ESC/POS buffer
  const parts: Buffer[] = [];
  parts.push(INIT);
  parts.push(ALIGN_CENTER);
  parts.push(BOLD_ON);
  parts.push(DOUBLE_ON);
  parts.push(Buffer.from(r.company.name + "\n", "utf8"));
  parts.push(DOUBLE_OFF);
  parts.push(BOLD_OFF);
  if (r.company.phone) parts.push(Buffer.from(`هاتف: ${r.company.phone}\n`, "utf8"));
  if (r.company.address) parts.push(Buffer.from(r.company.address + "\n", "utf8"));
  parts.push(Buffer.from("ــــــــــــــــــــــــــــــــ\n", "utf8"));

  // Header: receipt number + date
  parts.push(BOLD_ON);
  parts.push(Buffer.from("وصل قبض\n", "utf8"));
  parts.push(BOLD_OFF);
  parts.push(Buffer.from(`رقم: ${r.number}\n`, "utf8"));
  parts.push(Buffer.from(`التاريخ: ${new Date(r.receiptDate).toLocaleString("ar-IQ")}\n`, "utf8"));
  parts.push(Buffer.from("ــــــــــــــــــــــــــــــــ\n", "utf8"));

  // Party info
  parts.push(ALIGN_RIGHT);
  parts.push(Buffer.from(`استلمنا من: ${r.recipientName}\n`, "utf8"));
  if (r.customer?.code) parts.push(Buffer.from(`رقم العميل: ${r.customer.code}\n`, "utf8"));
  if (r.customer?.phone) parts.push(Buffer.from(`هاتف: ${r.customer.phone}\n`, "utf8"));
  parts.push(Buffer.from(`الصندوق: ${r.cashbox.name}\n`, "utf8"));
  parts.push(Buffer.from("ــــــــــــــــــــــــــــــــ\n", "utf8"));

  // Amount
  parts.push(ALIGN_CENTER);
  parts.push(BOLD_ON);
  parts.push(DOUBLE_ON);
  const amountStr = new Intl.NumberFormat("ar-IQ").format(Number(r.amount));
  parts.push(Buffer.from(`${amountStr} ${r.currency}\n`, "utf8"));
  parts.push(DOUBLE_OFF);
  parts.push(BOLD_OFF);
  parts.push(Buffer.from(`طريقة الدفع: ${r.paymentMethod}\n`, "utf8"));
  if (r.referenceNumber) parts.push(Buffer.from(`المرجع: ${r.referenceNumber}\n`, "utf8"));

  // Invoice context (if linked)
  if (invoiceSnap) {
    parts.push(Buffer.from("ــــــــــــــــــــــــــــــــ\n", "utf8"));
    parts.push(ALIGN_RIGHT);
    if (invoiceSnap.invoiceNumber) parts.push(Buffer.from(`فاتورة: ${invoiceSnap.invoiceNumber}\n`, "utf8"));
    if (invoiceSnap.invoiceTotal) parts.push(Buffer.from(`الإجمالي: ${new Intl.NumberFormat("ar-IQ").format(invoiceSnap.invoiceTotal)} ${r.currency}\n`, "utf8"));
    if (invoiceSnap.previouslyPaid) parts.push(Buffer.from(`سابق: ${new Intl.NumberFormat("ar-IQ").format(invoiceSnap.previouslyPaid)} ${r.currency}\n`, "utf8"));
    if (invoiceSnap.currentPayment) parts.push(Buffer.from(`الدفعة: ${new Intl.NumberFormat("ar-IQ").format(invoiceSnap.currentPayment)} ${r.currency}\n`, "utf8"));
    if (invoiceSnap.remainingAfter) parts.push(Buffer.from(`المتبقي: ${new Intl.NumberFormat("ar-IQ").format(invoiceSnap.remainingAfter)} ${r.currency}\n`, "utf8"));
  }

  // Balance
  if (customer) {
    parts.push(Buffer.from("ــــــــــــــــــــــــــــــــ\n", "utf8"));
    const prevBalance = Number(customer.balance) + Number(r.amount);
    parts.push(Buffer.from(`الرصيد السابق: ${new Intl.NumberFormat("ar-IQ").format(prevBalance)} ${r.currency}\n`, "utf8"));
    parts.push(Buffer.from(`الرصيد الحالي: ${new Intl.NumberFormat("ar-IQ").format(Number(customer.balance))} ${r.currency}\n`, "utf8"));
  }

  // Footer
  parts.push(Buffer.from("\n", "utf8"));
  parts.push(ALIGN_CENTER);
  parts.push(Buffer.from("شكراً لتعاملكم معنا\n", "utf8"));
  parts.push(Buffer.from(`${req.nextUrl.origin}/verify/${r.verifyToken}\n`, "utf8"));
  parts.push(FEED_LINES(3));
  parts.push(CUT_PAPER);

  const buf = Buffer.concat(parts);

  // Increment print count
  await db.receiptVoucher.update({
    where: { id: r.id },
    data: { printCount: { increment: 1 } },
  });

  return new Response(buf, {
    headers: {
      "Content-Type": "application/octet-stream",
      "Content-Disposition": `attachment; filename="receipt-${r.number}.bin"`,
      "X-Receipt-Number": r.number,
      "X-Receipt-Amount": String(r.amount),
      "X-Receipt-Currency": r.currency,
    },
  });
});
