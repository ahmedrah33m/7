// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { htmlToPdf, buildBatchReceiptsHtml, amountInWords } from "@/lib/pdf";
import QRCode from "qrcode";
export const dynamic = "force-dynamic";

/** GET /api/v1/finance/receipts/batch-pdf?date_from=&date_to= — batch PDF of all receipts */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.receipts.print");
  const url = new URL(req.url);
  const dateFrom = url.searchParams.get("date_from") ? new Date(url.searchParams.get("date_from")!) : new Date(Date.now() - 86400000);
  const dateTo = url.searchParams.get("date_to") ? new Date(url.searchParams.get("date_to")!) : new Date();
  const receipts = await db.receiptVoucher.findMany({
    where: { companyId: session.companyId, deletedAt: null, status: "POSTED", receiptDate: { gte: dateFrom, lte: dateTo } },
    include: { customer: { select: { code: true, phone: true } }, cashbox: { select: { name: true } },
      company: { select: { name: true, phone: true, address: true, taxNumber: true } } },
    orderBy: { receiptDate: "asc" }, take: 100,
  });
  if (receipts.length === 0) return ok({ error: "No receipts found in date range" }, undefined, 404);
  const pdfDataList: any[] = [];
  for (const r of receipts) {
    const verifyUrl = `${req.nextUrl.origin}/verify/${r.verifyToken}`;
    const qrSvg = await QRCode.toString(verifyUrl, { type: "svg", width: 160, margin: 1 });
    let invoiceSnap: any = null;
    try { invoiceSnap = r.invoiceSnapshot ? JSON.parse(r.invoiceSnapshot)[0] : null; } catch {}
    pdfDataList.push({
      companyName: r.company.name, companyPhone: r.company.phone, companyAddress: r.company.address,
      companyTaxNumber: r.company.taxNumber, number: r.number, receiptDate: new Date(r.receiptDate).toLocaleString("ar-IQ"),
      cashboxName: r.cashbox.name, recipientName: r.recipientName, customerCode: r.customer?.code ?? null,
      customerPhone: r.customer?.phone ?? null, amount: Number(r.amount), amountInWords: amountInWords(Number(r.amount), r.currency),
      currency: r.currency, paymentMethod: r.paymentMethod, referenceNumber: r.referenceNumber, description: r.description,
      invoiceNumber: invoiceSnap?.invoiceNumber ?? null, grandTotal: invoiceSnap?.grandTotal ?? null,
      previouslyPaid: invoiceSnap?.previouslyPaid ?? null, currentPayment: invoiceSnap?.current ?? null,
      remaining: invoiceSnap?.remaining ?? null, qrSvg, qrVerifyUrl: verifyUrl,
    });
  }
  const html = buildBatchReceiptsHtml(pdfDataList);
  try {
    const pdf = await htmlToPdf(html);
    return new Response(pdf, { headers: { "Content-Type": "application/pdf", "Content-Disposition": `inline; filename="batch-receipts-${dateFrom.toISOString().slice(0,10)}.pdf"` } });
  } catch { return ok({ error: "PDF engine unavailable", html }, undefined, 503); }
});
