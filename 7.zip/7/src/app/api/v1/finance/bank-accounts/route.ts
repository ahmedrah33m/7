// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { z } from "zod";
export const dynamic = "force-dynamic";
const bankSchema = z.object({ code: z.string().min(2).max(40).regex(/^[A-Za-z0-9_-]+$/), name: z.string().min(2).max(120), bank_name: z.string().min(2).max(120), iban: z.string().max(60).optional(), account_number: z.string().min(2).max(40), currency: z.string().length(3).default("IQD"), branch_id: z.number().int().positive().optional(), description: z.string().max(500).optional() });
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cashboxes.view");
  const rows = await db.bankAccount.findMany({ where: { companyId: session.companyId, deletedAt: null }, orderBy: { id: "asc" } });
  return ok(rows.map((b) => ({ id: b.id, code: b.code, name: b.name, bank_name: b.bankName, iban: b.iban, account_number: b.accountNumber, currency: b.currency, balance: b.balance, status: b.status })));
});
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cashboxes.create");
  const body = await parseBody(req, bankSchema);
  const existing = await db.bankAccount.findFirst({ where: { companyId: session.companyId, code: body.code, deletedAt: null } });
  if (existing) return ok({ id: existing.id }, undefined, 200);
  const bank = await db.bankAccount.create({ data: { companyId: session.companyId,  code: body.code, name: body.name, bankName: body.bank_name, iban: body.iban, accountNumber: body.account_number, currency: body.currency, createdBy: session.userId } });
  await writeAudit({ userId: session.userId, companyId: session.companyId, ipAddress: undefined, userAgent: undefined }, { action: "CREATE", module: "finance", entityType: "bank_account", entityId: bank.id, newValues: { code: bank.code, name: bank.name, bank_name: bank.bankName } });
  return ok({ id: bank.id, code: bank.code, name: bank.name, balance: bank.balance }, undefined, 201);
});
