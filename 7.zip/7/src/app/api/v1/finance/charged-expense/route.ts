// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import type { CashActor } from "@/lib/cashbox-service";
import { z } from "zod";
export const dynamic = "force-dynamic";
const chargedSchema = z.object({ customer_id: z.number().int().positive(), amount: z.number().positive(), currency: z.string().length(3).optional(), reason: z.enum(["EXPENSE", "OPERATING_EXPENSE", "ADVANCE", "OTHER"]).default("EXPENSE"), expense_category_id: z.number().int().positive().optional(), expense_category: z.string().max(80).optional(), description: z.string().max(500).optional(), notes: z.string().max(500).optional(), idempotency_key: z.string().max(120).optional(), voucher_date: z.string().datetime().optional() });
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.payment_vouchers.create");
  const body = await parseBody(req, chargedSchema);
  const result = await createChargedExpense({ userId: session.userId, companyId: session.companyId } as any, { customerId: body.customer_id, amount: body.amount, currency: body.currency, reason: body.reason, expenseCategoryId: body.expense_category_id, expenseCategory: body.expense_category, description: body.description, notes: body.notes, idempotencyKey: body.idempotency_key, voucherDate: body.voucher_date ? new Date(body.voucher_date) : undefined });
  return ok(result, undefined, 201);
});
