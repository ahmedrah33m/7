// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { markOverdueNotificationSent } from "@/lib/overdue-notification-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/finance/overdue-notifications/[id]/mark-sent
 *   Marks the notification as SENT (after user clicks the WhatsApp link).
 *   Idempotent: re-marking a SENT notification is a no-op.
 */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const session = await guard(req, "finance.overdue_notifications.create");
  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) throw new ApiError("VAL_001", "معرّف غير صالح");

  const result = await markOverdueNotificationSent(
    {
      userId: session.userId,
      companyId: session.companyId,
      ip: req.headers.get("x-forwarded-for"),
      userAgent: req.headers.get("user-agent"),
    },
    id
  );

  return ok(result);
});
