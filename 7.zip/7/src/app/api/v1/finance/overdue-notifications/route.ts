// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { scanAndGenerateOverdueNotifications, listPendingOverdueNotifications } from "@/lib/overdue-notification-service";
import { num } from "@/lib/decimal";

export const dynamic = "force-dynamic";

const scanSchema = z.object({
  buckets: z.array(z.enum(["D1_30", "D31_60", "D61_90", "D90_PLUS"])).optional(),
  dry_run: z.boolean().optional(),
});

/**
 * GET /api/v1/finance/overdue-notifications
 *   ?bucket=&customer_id=&status=PENDING&limit=100
 *
 * POST /api/v1/finance/overdue-notifications
 *   Body: { buckets?, dry_run? }
 *   Scans all outstanding invoices + creates notifications for unnotified (invoice, bucket) pairs
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.overdue_notifications.view");
  const url = new URL(req.url);
  const bucket = url.searchParams.get("bucket");
  const customerId = url.searchParams.get("customer_id");
  const status = url.searchParams.get("status") ?? "PENDING";
  const limit = url.searchParams.get("limit") ? Number(url.searchParams.get("limit")) : 100;

  const rows = await listPendingOverdueNotifications(session.companyId, {
    bucket: bucket ?? undefined,
    customerId: customerId ? Number(customerId) : undefined,
    status,
    limit,
  });

  return ok(rows.map((n) => ({
    id: n.id,
    customer: n.customer,
    invoice: n.invoice,
    bucket: n.bucket,
    age_days: n.ageDays,
    amount_due: num(n.amountDue),
    channel: n.channel,
    status: n.status,
    sent_at: n.sentAt,
    whatsapp_url: n.whatsappUrl,
    message_body: n.messageBody,
    error: n.error,
    created_at: n.createdAt,
  })));
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.overdue_notifications.create");
  const body = await parseBody(req, scanSchema);

  const result = await scanAndGenerateOverdueNotifications(
    {
      userId: session.userId,
      companyId: session.companyId,
      ip: req.headers.get("x-forwarded-for"),
      userAgent: req.headers.get("user-agent"),
    },
    {
      buckets: body.buckets,
      dryRun: body.dry_run ?? false,
    }
  );

  return ok(result, undefined, 201);
});
