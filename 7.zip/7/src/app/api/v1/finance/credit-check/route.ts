// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { Decimal, dec, num } from "@/lib/decimal";
export const dynamic = "force-dynamic";

/** GET /api/v1/finance/credit-check?customer_id=X — check credit limit including pending expenses */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.receipts.view");
  const url = new URL(req.url);
  const customerId = url.searchParams.get("customer_id");
  if (!customerId) return ok({ error: "customer_id required" }, undefined, 400);
  
  const customer = await db.customer.findFirst({
    where: { id: Number(customerId), companyId: session.companyId, deletedAt: null },
  });
  if (!customer) return ok({ error: "Customer not found" }, undefined, 404);
  
  const creditLimit = dec(customer.creditLimit ?? 0);
  const currentBalance = dec(customer.balance);
  // Sum pending charged expenses (not yet receipted)
  const pendingCharges = await db.paymentVoucher.aggregate({
    where: {
      companyId: session.companyId, deletedAt: null, status: "POSTED",
      chargeToCustomerId: customer.id, reason: { in: ["EXPENSE", "OPERATING_EXPENSE"] },
    },
    _sum: { amount: true },
  });
  const chargedTotal = dec(pendingCharges._sum.amount ?? 0);
  const availableCredit = moneyR(creditLimit.minus(currentBalance).minus(chargedTotal));
  const pctUsed = creditLimit.isPositive() ? Number(currentBalance.plus(chargedTotal).times(100).div(creditLimit).toDecimalPlaces(2)) : 0;
  
  return ok({
    customer: { id: customer.id, name: customer.name, code: customer.code },
    credit_limit: num(creditLimit),
    current_balance: num(currentBalance),
    pending_charged_expenses: num(chargedTotal),
    total_used: num(currentBalance.plus(chargedTotal)),
    available_credit: num(availableCredit),
    pct_used: pctUsed,
    status: pctUsed >= 100 ? "EXCEEDED" : pctUsed >= 80 ? "WARNING" : "OK",
    can_charge_more: availableCredit.isPositive(),
  });
});
