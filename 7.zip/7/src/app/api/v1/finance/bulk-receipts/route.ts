// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { quickReceiptFromCustomer } from "@/lib/advanced-finance-service";
import { z } from "zod";
export const dynamic = "force-dynamic";

const bulkSchema = z.object({
  cashbox_id: z.number().int().positive(),
  payments: z.array(z.object({
    customer_id: z.number().int().positive(),
    amount: z.number().positive(),
    note: z.string().max(500).optional(),
  })).min(1).max(50),
});

/** POST /api/v1/finance/bulk-receipts — process multiple customer payments at once (FIFO each) */
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.receipts.create");
  const body = await parseBody(req, bulkSchema);
  const results = [];
  let totalProcessed = 0;
  let successCount = 0;
  let failCount = 0;
  
  for (const p of body.payments) {
    try {
      const result = await quickReceiptFromCustomer(
        { userId: session.userId, companyId: session.companyId },
        { customerId: p.customer_id, cashboxId: body.cashbox_id, amount: p.amount, note: p.note, idempotencyKey: `bulk-${Date.now()}-${p.customer_id}` },
      );
      results.push({ customer_id: p.customer_id, success: true, receipt_number: result.number, amount: p.amount });
      totalProcessed += p.amount;
      successCount++;
    } catch (e: any) {
      results.push({ customer_id: p.customer_id, success: false, error: e.message ?? "Unknown error", amount: p.amount });
      failCount++;
    }
  }
  
  return ok({
    results,
    summary: { total: body.payments.length, success: successCount, failed: failCount, total_amount: totalProcessed },
  }, undefined, 201);
});
