// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { Decimal, dec, moneyR, num } from "@/lib/decimal";
import { z } from "zod";
export const dynamic = "force-dynamic";
const recurringSchema = z.object({ name: z.string().min(2).max(120), amount: z.number().positive(), currency: z.string().length(3).default("IQD"), frequency: z.enum(["MONTHLY", "WEEKLY", "YEARLY", "QUARTERLY"]).default("MONTHLY"), day_of_month: z.number().int().min(1).max(31).optional(), day_of_week: z.number().int().min(0).max(6).optional(), start_date: z.string().datetime(), end_date: z.string().datetime().optional(), beneficiary_name: z.string().max(120).optional(), notes: z.string().max(500).optional(), cashbox_id: z.number().int().positive().optional(), idempotency_key: z.string().max(120).optional() });
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.expenses.view");
  const rows = await db.recurringExpense.findMany({ where: { companyId: session.companyId, deletedAt: null }, include: { cashbox: { select: { id: true, name: true, code: true, currency: true } } }, orderBy: { nextRunAt: "asc" } });
  return ok(rows.map((r) => ({ id: r.id, name: r.name, amount: r.amount, currency: r.currency, frequency: r.frequency, day_of_month: r.dayOfMonth, day_of_week: r.dayOfWeek, start_date: r.startDate, end_date: r.endDate, next_run_at: r.nextRunAt, last_run_at: r.lastRunAt, status: r.status, beneficiary_name: r.beneficiaryName, notes: r.notes, cashbox: r.cashbox })));
});
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.expenses.create");
  const body = await parseBody(req, recurringSchema);
  const startDate = new Date(body.start_date);
  const now = new Date();
  const nextRunAt = new Date(startDate);
  if (nextRunAt < now) { if (body.frequency === "MONTHLY") { nextRunAt.setMonth(now.getMonth() + 1); nextRunAt.setDate(body.day_of_month ?? 1); } else if (body.frequency === "WEEKLY") { nextRunAt.setDate(now.getDate() + 7); } else if (body.frequency === "QUARTERLY") { nextRunAt.setMonth(now.getMonth() + 3 - (now.getMonth() % 3)); nextRunAt.setDate(body.day_of_month ?? 1); } else if (body.frequency === "YEARLY") { nextRunAt.setFullYear(now.getFullYear() + 1); } }
  const recurring = await db.recurringExpense.create({ data: { companyId: session.companyId ?? null, cashboxId: body.cashbox_id ?? null, name: body.name, amount: moneyR(dec(body.amount)), currency: body.currency, frequency: body.frequency, dayOfMonth: body.day_of_month ?? null, dayOfWeek: body.day_of_week ?? null, startDate, endDate: body.end_date ? new Date(body.end_date) : null, nextRunAt, status: "ACTIVE", beneficiaryName: body.beneficiary_name ?? null, notes: body.notes, createdById: session.userId } });
  await writeAudit({ userId: session.userId, companyId: session.companyId, ipAddress: undefined, userAgent: undefined }, { action: "CREATE", module: "finance", entityType: "recurring_expense", entityId: recurring.id, newValues: { name: recurring.name, amount: num(recurring.amount), frequency: recurring.frequency, next_run: nextRunAt.toISOString() } });
  return ok({ id: recurring.id, name: recurring.name, amount: num(recurring.amount), currency: recurring.currency, frequency: recurring.frequency, next_run_at: nextRunAt.toISOString(), status: recurring.status }, undefined, 201);
});
