// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { htmlToPdf, buildAgingStatementHtml } from "@/lib/pdf";
import QRCode from "qrcode";
import { Decimal } from "@prisma/client/runtime/library";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/finance/aging/[id]/pdf?type=customers|suppliers
 * Generates a per-actor aging statement PDF showing:
 *  - Customer/supplier info
 *  - Total balance
 *  - 5 buckets breakdown
 *  - Detailed invoice list with age days and bucket assignment
 *  - QR verification code
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.aging.view");
  const { id } = await ctx.params;
  const url = new URL(req.url);
  const type = url.searchParams.get("type") === "suppliers" ? "suppliers" : "customers";
  const actorId = Number(id);

  // Load company
  const company = await db.company.findFirst({
    where: { id: session.companyId },
    select: { name: true, phone: true, address: true },
  });
  if (!company) return ok({ error: "Company not found" }, undefined, 404);

  if (type === "customers") {
    // ---- Customer aging detail ----
    const cust = await db.customer.findFirst({
      where: { id: actorId, companyId: session.companyId, deletedAt: null },
      select: { id: true, code: true, name: true, phone: true, address: true, balance: true },
    });
    if (!cust) return ok({ error: "Customer not found" }, undefined, 404);

    const today = new Date();
    const invoices = await db.salesInvoice.findMany({
      where: { customerId: cust.id, companyId: session.companyId, deletedAt: null },
      select: { id: true, number: true, grandTotal: true, paidAmount: true, invoiceDate: true },
    });

    const buckets = { current: 0, d1_30: 0, d31_60: 0, d61_90: 0, d90_plus: 0 };
    const invoiceRows: any[] = [];

    for (const inv of invoices) {
      const due = new Decimal(inv.grandTotal).minus(inv.paidAmount);
      if (!due.isPositive()) continue;
      const dueNum = Number(due);
      const ageDays = Math.floor((today.getTime() - inv.invoiceDate.getTime()) / (24 * 3600 * 1000));
      let bucketKey: keyof typeof buckets;
      let bucketLabel: string;
      if (ageDays <= 0) { bucketKey = "current"; bucketLabel = "حالي"; }
      else if (ageDays <= 30) { bucketKey = "d1_30"; bucketLabel = "1-30"; }
      else if (ageDays <= 60) { bucketKey = "d31_60"; bucketLabel = "31-60"; }
      else if (ageDays <= 90) { bucketKey = "d61_90"; bucketLabel = "61-90"; }
      else { bucketKey = "d90_plus"; bucketLabel = "+90"; }
      buckets[bucketKey] += dueNum;
      invoiceRows.push({
        number: inv.number,
        date: inv.invoiceDate.toLocaleDateString("ar-IQ"),
        grandTotal: Number(inv.grandTotal),
        paidAmount: Number(inv.paidAmount),
        dueAmount: dueNum,
        ageDays,
        bucket: bucketLabel,
      });
    }

    // Sort invoices by age desc (oldest first)
    invoiceRows.sort((a, b) => b.ageDays - a.ageDays);

    const verifyToken = `AGING-C-${cust.id}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const verifyUrl = `${req.nextUrl.origin}/verify/${verifyToken}`;
    const qrSvg = await QRCode.toString(verifyUrl, { type: "svg", width: 160, margin: 1 });

    const html = buildAgingStatementHtml({
      companyName: company.name,
      companyPhone: company.phone,
      companyAddress: company.address,
      actorType: "customer",
      actorCode: cust.code,
      actorName: cust.name,
      actorPhone: cust.phone,
      actorAddress: cust.address,
      asOfDate: today.toLocaleDateString("ar-IQ"),
      totalBalance: Number(cust.balance),
      buckets,
      invoices: invoiceRows,
      qrSvg,
      qrVerifyUrl: verifyUrl,
    });

    try {
      const pdfBuffer = await htmlToPdf(html);
      return new Response(pdfBuffer, {
        headers: {
          "Content-Type": "application/pdf",
          "Content-Disposition": `inline; filename="aging-customer-${cust.code}.pdf"`,
          "Cache-Control": "private, max-age=0",
        },
      });
    } catch {
      return ok({ error: "PDF engine unavailable — use browser print", html }, undefined, 503);
    }
  } else {
    // ---- Supplier aging detail ----
    const sup = await db.supplier.findFirst({
      where: { id: actorId, companyId: session.companyId, deletedAt: null },
      select: { id: true, code: true, name: true, phone: true, address: true, balance: true },
    });
    if (!sup) return ok({ error: "Supplier not found" }, undefined, 404);

    const today = new Date();
    const invoices = await db.purchaseInvoice.findMany({
      where: { supplierId: sup.id, companyId: session.companyId, deletedAt: null },
      select: { id: true, number: true, grandTotal: true, paidAmount: true, invoiceDate: true },
    });

    const buckets = { current: 0, d1_30: 0, d31_60: 0, d61_90: 0, d90_plus: 0 };
    const invoiceRows: any[] = [];

    for (const inv of invoices) {
      const due = new Decimal(inv.grandTotal).minus(inv.paidAmount);
      if (!due.isPositive()) continue;
      const dueNum = Number(due);
      const ageDays = Math.floor((today.getTime() - inv.invoiceDate.getTime()) / (24 * 3600 * 1000));
      let bucketKey: keyof typeof buckets;
      let bucketLabel: string;
      if (ageDays <= 0) { bucketKey = "current"; bucketLabel = "حالي"; }
      else if (ageDays <= 30) { bucketKey = "d1_30"; bucketLabel = "1-30"; }
      else if (ageDays <= 60) { bucketKey = "d31_60"; bucketLabel = "31-60"; }
      else if (ageDays <= 90) { bucketKey = "d61_90"; bucketLabel = "61-90"; }
      else { bucketKey = "d90_plus"; bucketLabel = "+90"; }
      buckets[bucketKey] += dueNum;
      invoiceRows.push({
        number: inv.number,
        date: inv.invoiceDate.toLocaleDateString("ar-IQ"),
        grandTotal: Number(inv.grandTotal),
        paidAmount: Number(inv.paidAmount),
        dueAmount: dueNum,
        ageDays,
        bucket: bucketLabel,
      });
    }

    invoiceRows.sort((a, b) => b.ageDays - a.ageDays);

    const verifyToken = `AGING-S-${sup.id}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const verifyUrl = `${req.nextUrl.origin}/verify/${verifyToken}`;
    const qrSvg = await QRCode.toString(verifyUrl, { type: "svg", width: 160, margin: 1 });

    const html = buildAgingStatementHtml({
      companyName: company.name,
      companyPhone: company.phone,
      companyAddress: company.address,
      actorType: "supplier",
      actorCode: sup.code,
      actorName: sup.name,
      actorPhone: sup.phone,
      actorAddress: sup.address,
      asOfDate: today.toLocaleDateString("ar-IQ"),
      totalBalance: Number(sup.balance),
      buckets,
      invoices: invoiceRows,
      qrSvg,
      qrVerifyUrl: verifyUrl,
    });

    try {
      const pdfBuffer = await htmlToPdf(html);
      return new Response(pdfBuffer, {
        headers: {
          "Content-Type": "application/pdf",
          "Content-Disposition": `inline; filename="aging-supplier-${sup.code}.pdf"`,
          "Cache-Control": "private, max-age=0",
        },
      });
    } catch {
      return ok({ error: "PDF engine unavailable — use browser print", html }, undefined, 503);
    }
  }
});
