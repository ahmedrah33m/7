// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { customerAging, supplierAging } from "@/lib/cashbox-service";
export const dynamic = "force-dynamic";
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.aging.view");
  const url = new URL(req.url);
  const type = url.searchParams.get("type") ?? "customers";
  if (type === "suppliers") return ok(await supplierAging(session.companyId));
  return ok(await customerAging(session.companyId));
});
