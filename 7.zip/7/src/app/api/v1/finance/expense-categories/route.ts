// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { z } from "zod";
export const dynamic = "force-dynamic";
const catSchema = z.object({ code: z.string().min(2).max(40).regex(/^[A-Za-z0-9_-]+$/), name: z.string().min(2).max(120), name_en: z.string().max(120).optional(), description: z.string().max(500).optional(), monthly_budget: z.number().nonnegative().optional(), type: z.enum(["EXPENSE", "INCOME"]).default("EXPENSE") });
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.expenses.view");
  const rows = await db.expenseCategory.findMany({ where: { companyId: session.companyId, deletedAt: null }, orderBy: { type: "asc" } });
  return ok(rows.map((c) => ({ id: c.id, code: c.code, name: c.name, name_en: c.nameEn, type: c.type, description: c.description, monthly_budget: c.monthlyBudget, is_active: c.isActive })));
});
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.expenses.create");
  const body = await parseBody(req, catSchema);
  const existing = await db.expenseCategory.findFirst({ where: { companyId: session.companyId, code: body.code, deletedAt: null } });
  if (existing) return ok({ id: existing.id, code: existing.code, name: existing.name }, undefined, 200);
  const cat = await db.expenseCategory.create({ data: { companyId: session.companyId, code: body.code, name: body.name, nameEn: body.name_en, description: body.description, monthlyBudget: body.monthly_budget, type: body.type, createdBy: session.userId } });
  await writeAudit({ userId: session.userId, companyId: session.companyId, ipAddress: undefined, userAgent: undefined }, { action: "CREATE", module: "finance", entityType: "expense_category", entityId: cat.id, newValues: { code: cat.code, name: cat.name } });
  return ok({ id: cat.id, code: cat.code, name: cat.name, type: cat.type }, undefined, 201);
});
