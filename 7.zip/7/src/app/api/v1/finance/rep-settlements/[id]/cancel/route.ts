// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { cancelRepSettlement } from "@/lib/rep-settlement-service";

export const dynamic = "force-dynamic";

const cancelSchema = z.object({
  reason: z.string().min(3).max(500),
});

/**
 * POST /api/v1/finance/rep-settlements/[id]/cancel
 *   Body: { reason }
 *   Reverses the cash transfer + restores both cashbox balances.
 */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const session = await guard(req, "finance.rep_settlements.cancel");
  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) throw new ApiError("VAL_001", "معرّف غير صالح");

  const body = await parseBody(req, cancelSchema);

  const result = await cancelRepSettlement(
    {
      userId: session.userId,
      companyId: session.companyId,
      branchId: session.activeBranchId,
      ip: req.headers.get("x-forwarded-for"),
      userAgent: req.headers.get("user-agent"),
    },
    id,
    body.reason
  );

  return ok(result);
});
