// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { branchWhere } from "@/lib/scope";
import { createRepSettlement, getRepOutstandingBalance } from "@/lib/rep-settlement-service";
import { num, dec } from "@/lib/decimal";

export const dynamic = "force-dynamic";

const createSchema = z.object({
  rep_user_id: z.number().int().positive(),
  from_cashbox_id: z.number().int().positive(),
  to_cashbox_id: z.number().int().positive(),
  branch_id: z.number().int().positive().optional(),
  collected_amount: z.number().positive().optional().nullable(),
  delivered_amount: z.number().positive().optional().nullable(),
  difference_reason: z.string().max(500).optional(),
  received_by: z.string().max(120).optional(),
  received_by_id: z.number().int().positive().optional(),
  signature_data: z.string().optional(),
  description: z.string().max(500).optional(),
  notes: z.string().max(500).optional(),
  idempotency_key: z.string().max(120).optional(),
  settlement_date: z.string().datetime().optional(),
});

/**
 * GET /api/v1/finance/rep-settlements
 *   ?rep_user_id=&from_cashbox_id=&from=&to=&status=
 *   ?outstanding=1 + rep_user_id + from_cashbox_id → compute outstanding balance
 *
 * Phase 4-7 — سجل تسليمات المندوبين (REP-STL-2026-)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.rep_settlements.view");
  const url = new URL(req.url);
  const repUserId = url.searchParams.get("rep_user_id");
  const fromCashboxId = url.searchParams.get("from_cashbox_id");
  const status = url.searchParams.get("status");
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");
  const outstandingFlag = url.searchParams.get("outstanding") === "1";

  // Optional: compute outstanding balance for a rep
  if (outstandingFlag && repUserId && fromCashboxId) {
    const result = await getRepOutstandingBalance(
      session.companyId,
      Number(repUserId),
      Number(fromCashboxId)
    );
    return ok(result);
  }

  const where: Record<string, unknown> = {
    companyId: session.companyId,
    deletedAt: null,
    ...branchWhere(session),
  };
  if (repUserId) where.repUserId = Number(repUserId);
  if (fromCashboxId) where.fromCashboxId = Number(fromCashboxId);
  if (status) where.status = status;
  if (from || to) {
    where.settlementDate = {
      ...(from ? { gte: new Date(from) } : {}),
      ...(to ? { lte: new Date(to) } : {}),
    };
  }

  const rows = await db.repSettlement.findMany({
    where,
    orderBy: { settlementDate: "desc" },
    take: 100,
    include: {
      repUser: { select: { id: true, fullName: true, username: true } },
      fromCashbox: { select: { id: true, name: true, code: true, balance: true } },
      toCashbox: { select: { id: true, name: true, code: true, balance: true } },
      receivedByUser: { select: { id: true, fullName: true } },
    },
  });

  return ok(rows.map((r) => ({
    id: r.id,
    number: r.number,
    settlement_date: r.settlementDate,
    rep_user: r.repUser,
    from_cashbox: r.fromCashbox,
    to_cashbox: r.toCashbox,
    cash_transfer_id: r.cashTransferId,
    collected_amount: num(r.collectedAmount),
    delivered_amount: num(r.deliveredAmount),
    difference: num(r.difference),
    difference_reason: r.differenceReason,
    received_by: r.receivedBy,
    received_by_user: r.receivedByUser,
    signature_data: r.signatureData ? "[موجود]" : null,
    status: r.status,
    description: r.description,
    notes: r.notes,
    created_at: r.createdAt,
  })));
});

/**
 * POST /api/v1/finance/rep-settlements
 *   Body: CreateRepSettlementInput — creates atomic settlement + linked transfer
 *   Permission: finance.rep_settlements.create
 */
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.rep_settlements.create");
  const body = await parseBody(req, createSchema);

  const branchId = body.branch_id ?? session.activeBranchId ?? session.branchIds[0] ?? 0;
  if (!branchId) throw new ApiError("SCOPE_003", "لا يوجد فرع نشط في الجلسة");

  const result = await createRepSettlement(
    {
      userId: session.userId,
      companyId: session.companyId,
      branchId,
      ip: req.headers.get("x-forwarded-for"),
      userAgent: req.headers.get("user-agent"),
    },
    {
      repUserId: body.rep_user_id,
      fromCashboxId: body.from_cashbox_id,
      toCashboxId: body.to_cashbox_id,
      branchId,
      collectedAmount: body.collected_amount,
      deliveredAmount: body.delivered_amount,
      differenceReason: body.difference_reason,
      receivedBy: body.received_by,
      receivedById: body.received_by_id,
      signatureData: body.signature_data,
      description: body.description,
      notes: body.notes,
      idempotencyKey: body.idempotency_key,
      settlementDate: body.settlement_date ? new Date(body.settlement_date) : null,
    }
  );

  return ok(result, undefined, 201);
});
