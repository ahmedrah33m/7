// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { branchWhere } from "@/lib/scope";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/finance/audit-logs
 *   ?entity_type=&action=&user_id=&from=&to=&per_page=50
 *
 * Phase 15-17 — Financial audit log UI (filters for cashbox/receipt/voucher/transfer)
 *
 * Permission: audit.audit_logs.view (reuses existing core permission)
 */
const FINANCE_ENTITY_TYPES = [
  "cashbox",
  "cash_transaction",
  "receipt_voucher",
  "payment_voucher",
  "cash_transfer",
  "cashbox_closing",
  "cashbox_closing_reopen",
  "payment_allocation",
  "rep_settlement",
  "rep_settlement_reopen",
  "overdue_notification_scan",
  "overdue_notification",
  "cashbox_reconcile",
];

export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "audit.audit_logs.view");
  const url = new URL(req.url);
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1"));
  const perPage = Math.min(200, Number(url.searchParams.get("per_page") ?? "50"));
  const entityType = url.searchParams.get("entity_type");
  const action = url.searchParams.get("action");
  const userId = url.searchParams.get("user_id");
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");
  const cashboxScope = url.searchParams.get("cashbox_scope") === "1";
  const financeOnly = url.searchParams.get("finance_only") !== "0"; // default = finance only

  const where: Record<string, unknown> = {
    companyId: session.companyId,
    ...(financeOnly
      ? { entityType: entityType ? entityType : { in: FINANCE_ENTITY_TYPES } }
      : {}),
  };
  if (action) where.action = action;
  if (userId) where.userId = Number(userId);
  if (from || to) {
    where.createdAt = {
      ...(from ? { gte: new Date(from) } : {}),
      ...(to ? { lte: new Date(to) } : {}),
    };
  }

  const [rows, total] = await Promise.all([
    db.auditLog.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: perPage,
      skip: (page - 1) * perPage,
      include: {
        user: { select: { id: true, fullName: true, username: true } },
      },
    }),
    db.auditLog.count({ where }),
  ]);

  return ok({
    page,
    per_page: perPage,
    total,
    pages: Math.ceil(total / perPage) || 1,
    entity_types: FINANCE_ENTITY_TYPES,
    rows: rows.map((r) => ({
      id: r.id,
      action: r.action,
      module: r.module,
      entity_type: r.entityType,
      entity_id: r.entityId,
      old_values: r.oldValues,
      new_values: r.newValues,
      ip_address: r.ipAddress,
      user_agent: r.userAgent,
      user: r.user,
      created_at: r.createdAt.toISOString(),
    })),
  });
});
