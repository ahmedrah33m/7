// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { getOutstandingInvoices } from "@/lib/advanced-finance-service";
export const dynamic = "force-dynamic";
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.receipts.view");
  const { id } = await ctx.params;
  const invoices = await getOutstandingInvoices(session.companyId, Number(id));
  return ok(invoices);
});
