// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { db } from "@/lib/db";
import { branchWhere } from "@/lib/scope";
import {
  collectFromCustomer,
  paySupplier,
  recordExpense,
  openCashbox,
} from "@/lib/finance-service";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/finance/transactions — cash ledger (finance.payments.view)
 *      ?category= · ?cashbox_id= · ?per_page=
 * POST /api/v1/finance/transactions — unified cash operations
 *      kind=collection  → collect from customer (finance.payments.create)
 *      kind=supplier    → pay supplier          (finance.payments.create)
 *      kind=expense     → record expense        (finance.expenses.create)
 *      kind=opening     → cashbox opening       (finance.payments.create)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.payments.view");
  const url = new URL(req.url);
  const category = url.searchParams.get("category") ?? undefined;
  const cashboxId = url.searchParams.get("cashbox_id");
  const perPage = Math.min(200, Math.max(1, Number(url.searchParams.get("per_page") ?? 30)));

  // Branch context: only transactions of cashboxes inside the effective set
  const branchBoxes = await db.cashbox.findMany({
    where: { companyId: session.companyId, deletedAt: null, ...branchWhere(session) },
    select: { id: true },
  });
  const boxIds = branchBoxes.map((b) => b.id);
  const rows = await db.cashTransaction.findMany({
    where: {
      companyId: session.companyId,
      cashboxId: { in: boxIds },
      ...(category ? { category } : {}),
      ...(cashboxId ? { cashboxId: Number(cashboxId) } : {}),
    },
    include: {
      cashbox: { select: { code: true, name: true } },
      customer: { select: { code: true, name: true } },
      supplier: { select: { code: true, name: true } },
    },
    orderBy: { id: "desc" },
    take: perPage,
  });

  return ok(
    rows.map((t) => ({
      id: t.id,
      direction: t.direction,
      category: t.category,
      amount: t.amount,
      balance_after: t.balanceAfter,
      cashbox: t.cashbox,
      customer: t.customer ? { id: t.customer.code, name: t.customer.name } : null,
      supplier: t.supplier ? { id: t.supplier.code, name: t.supplier.name } : null,
      ref_type: t.refType,
      ref_id: t.refId,
      note: t.note,
      created_at: t.createdAt,
    }))
  );
});

const createSchema = z.discriminatedUnion("kind", [
  z.object({
    kind: z.literal("collection"),
    customer_id: z.number().int().positive("اختر العميل"),
    cashbox_id: z.number().int().positive("اختر الصندوق"),
    amount: z.number().positive("المبلغ يجب أن يكون أكبر من صفر"),
    invoice_id: z.number().int().positive().optional().nullable(),
    note: z.string().trim().max(300).optional().nullable(),
  }),
  z.object({
    kind: z.literal("supplier"),
    supplier_id: z.number().int().positive("اختر المورد"),
    cashbox_id: z.number().int().positive("اختر الصندوق"),
    amount: z.number().positive("المبلغ يجب أن يكون أكبر من صفر"),
    note: z.string().trim().max(300).optional().nullable(),
  }),
  z.object({
    kind: z.literal("expense"),
    cashbox_id: z.number().int().positive("اختر الصندوق"),
    amount: z.number().positive("المبلغ يجب أن يكون أكبر من صفر"),
    title: z.string().trim().min(2, "بيان المصروف مطلوب").max(200),
    note: z.string().trim().max(300).optional().nullable(),
  }),
  z.object({
    kind: z.literal("opening"),
    cashbox_id: z.number().int().positive("اختر الصندوق"),
    amount: z.number().positive("المبلغ يجب أن يكون أكبر من صفر"),
    note: z.string().trim().max(300).optional().nullable(),
  }),
]);

export const POST = handler(async (req: NextRequest) => {
  const body = await parseBody(req, createSchema);

  if (body.kind === "expense") {
    const session = await guard(req, "finance.expenses.create");
    const result = await recordExpense(
      { userId: session.userId, companyId: session.companyId, ip: req.headers.get("x-forwarded-for") ?? undefined, userAgent: req.headers.get("user-agent") ?? undefined },
      { cashboxId: body.cashbox_id, amount: body.amount, title: body.title, note: body.note ?? null }
    );
    return ok(result, undefined, 201);
  }

  const session = await guard(req, "finance.payments.create");
  const actor = {
    userId: session.userId,
    companyId: session.companyId,
    ip: req.headers.get("x-forwarded-for") ?? undefined,
    userAgent: req.headers.get("user-agent") ?? undefined,
  };

  if (body.kind === "collection") {
    const result = await collectFromCustomer(actor, {
      customerId: body.customer_id,
      cashboxId: body.cashbox_id,
      amount: body.amount,
      invoiceId: body.invoice_id ?? null,
      note: body.note ?? null,
    });
    return ok(result, undefined, 201);
  }

  if (body.kind === "supplier") {
    const result = await paySupplier(actor, {
      supplierId: body.supplier_id,
      cashboxId: body.cashbox_id,
      amount: body.amount,
      note: body.note ?? null,
    });
    return ok(result, undefined, 201);
  }

  const result = await openCashbox(actor, {
    cashboxId: body.cashbox_id,
    amount: body.amount,
    note: body.note ?? null,
  });
  return ok(result, undefined, 201);
});
