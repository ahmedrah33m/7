// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import type { CashActor } from "@/lib/cashbox-service";
import { z } from "zod";
export const dynamic = "force-dynamic";
const quickSchema = z.object({ customer_id: z.number().int().positive(), cashbox_id: z.number().int().positive(), amount: z.number().positive(), currency: z.string().length(3).optional(), payment_method: z.enum(["CASH", "CARD", "BANK_TRANSFER", "ELECTRONIC"]).default("CASH"), note: z.string().max(500).optional(), idempotency_key: z.string().max(120).optional() });
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.receipts.create");
  const body = await parseBody(req, quickSchema);
  const result = await quickReceiptFromCustomer({ userId: session.userId, companyId: session.companyId } as any, { customerId: body.customer_id, cashboxId: body.cashbox_id, amount: body.amount, currency: body.currency, paymentMethod: body.payment_method, note: body.note, idempotencyKey: body.idempotency_key });
  return ok(result, undefined, 201);
});
