// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { z } from "zod";
export const dynamic = "force-dynamic";

/** GET /api/v1/finance/expense-approvals — pending expense approvals */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.expenses.view");
  // PaymentVouchers with reason=EXPENSE and status=PENDING_APPROVAL (or large amounts)
  const THRESHOLD = 1000000; // 1M IQD threshold for approval
  const rows = await db.paymentVoucher.findMany({
    where: {
      companyId: session.companyId, deletedAt: null, status: "POSTED",
      reason: { in: ["EXPENSE", "OPERATING_EXPENSE"] },
      amount: { gte: THRESHOLD },
      approvedById: null,
    },
    include: {
      supplier: { select: { id: true, name: true, code: true } },
      cashbox: { select: { id: true, name: true, code: true, currency: true } },
      expenseCategoryLink: { select: { id: true, code: true, name: true } },
      createdBy: { select: { id: true, fullName: true } },
    },
    orderBy: { voucherDate: "desc" },
    take: 50,
  });
  return ok(rows.map((v) => ({
    id: v.id, number: v.number, voucher_date: v.voucherDate,
    beneficiary: v.beneficiaryName, amount: v.amount, currency: v.currency,
    reason: v.reason, expense_category: v.expenseCategoryLink,
    cashbox: v.cashbox, supplier: v.supplier, created_by: v.createdBy?.fullName,
    description: v.description, threshold: THRESHOLD,
  })));
});

/** POST /api/v1/finance/expense-approvals — approve/reject an expense */
const approveSchema = z.object({
  voucher_id: z.number().int().positive(),
  action: z.enum(["approve", "reject"]),
  reason: z.string().max(500).optional(),
});
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.expenses.approve");
  const body = await parseBody(req, approveSchema);
  const voucher = await db.paymentVoucher.findFirst({
    where: { id: body.voucher_id, companyId: session.companyId, deletedAt: null, approvedById: null },
  });
  if (!voucher) return ok({ error: "Voucher not found or already approved" }, undefined, 404);
  
  if (body.action === "approve") {
    await db.paymentVoucher.update({
      where: { id: voucher.id },
      data: { approvedById: session.userId, notes: body.reason ? `${voucher.notes ?? ""}\nموافقة: ${body.reason}` : voucher.notes },
    });
    await writeAudit(
      { userId: session.userId, companyId: session.companyId, ipAddress: undefined, userAgent: undefined },
      { action: "APPROVE", module: "finance", entityType: "payment_voucher", entityId: voucher.id, newValues: { number: voucher.number, action: "approved" } }
    );
    return ok({ id: voucher.id, number: voucher.number, status: "APPROVED" });
  } else {
    await db.paymentVoucher.update({
      where: { id: voucher.id },
      data: { status: "CANCELLED", cancelReason: `مرفوض: ${body.reason ?? "غير محدد"}`, cancelledById: session.userId, cancelledAt: new Date() },
    });
    return ok({ id: voucher.id, number: voucher.number, status: "REJECTED" });
  }
});
