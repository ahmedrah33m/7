// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { cashboxWhere } from "@/lib/scope";
import { num, dec } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/finance/cashboxes/[id]/live
 *   Returns the current balance of a single cashbox + latest transaction.
 *   Designed for polling every 5-30 seconds (lightweight query).
 *
 * Phase 34-35 — Live cashbox balance for multi-user consistency.
 * Permission: finance.cashboxes.view
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const session = await guard(req, "finance.cashboxes.view");
  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) throw new ApiError("VAL_001", "معرّف غير صالح");

  // Single cashbox fetch — minimal columns for speed
  const box = await db.cashbox.findFirst({
    where: { id, companyId: session.companyId, deletedAt: null, ...cashboxWhere(session) },
    select: {
      id: true, code: true, name: true, balance: true,
      currency: true, status: true, isActive: true, updatedAt: true,
    },
  });
  if (!box) throw new ApiError("CASHBOX_001");

  // Get the latest transaction (1 row only)
  const latestTx = await db.cashTransaction.findFirst({
    where: { cashboxId: id, isReversed: false },
    orderBy: { createdAt: "desc" },
    select: {
      direction: true,
      amount: true,
      balanceAfter: true,
      transactionType: true,
      transactionNumber: true,
      createdAt: true,
      note: true,
    },
  });

  return ok({
    id: box.id,
    code: box.code,
    name: box.name,
    balance: num(box.balance),
    currency: box.currency,
    status: box.status,
    is_active: box.isActive,
    updated_at: box.updatedAt.toISOString(),
    server_time: new Date().toISOString(),
    latest_transaction: latestTx ? {
      direction: latestTx.direction,
      amount: num(latestTx.amount),
      balance_after: num(latestTx.balanceAfter),
      type: latestTx.transactionType,
      number: latestTx.transactionNumber,
      time: latestTx.createdAt.toISOString(),
      note: latestTx.note,
    } : null,
  });
});
