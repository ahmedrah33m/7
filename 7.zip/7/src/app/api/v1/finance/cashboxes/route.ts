// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { branchWhere, cashboxWhere } from "@/lib/scope";
import { nextDocumentNumber } from "@/lib/document-number";
import { dec, moneyR, num, sumOf } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/finance/cashboxes — list cashboxes (finance.cashboxes.view)
 *      ?with_kpis=1 → also returns receipts_today / payments_today /
 *                     total_cash / open_cashboxes / top_cashboxes / pending_checks
 * POST /api/v1/finance/cashboxes — create a cashbox (finance.cashboxes.create)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cashboxes.view");
  const url = new URL(req.url);
  const withKpis = url.searchParams.get("with_kpis") === "1";

  const rows = await db.cashbox.findMany({
    where: { companyId: session.companyId, deletedAt: null, ...cashboxWhere(session) },
    orderBy: { id: "asc" },
    include: { branch: { select: { name: true } } },
  });

  if (!withKpis) {
    return ok(
      rows.map((b) => ({
        id: b.id,
        code: b.code,
        name: b.name,
        balance: b.balance,
        is_active: b.isActive,
        type: b.type,
        status: b.status,
        currency: b.currency,
        branch: b.branch,
      }))
    );
  }

  // KPI aggregation
  const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
  const cashboxIds = rows.map((b) => b.id);
  const [receipts, payments, checks] = await Promise.all([
    db.receiptVoucher.findMany({
      where: { companyId: session.companyId, deletedAt: null, receiptDate: { gte: todayStart }, status: "POSTED", cashboxId: { in: cashboxIds } },
      select: { amount: true },
    }),
    db.paymentVoucher.findMany({
      where: { companyId: session.companyId, deletedAt: null, paymentDate: { gte: todayStart }, status: "POSTED", cashboxId: { in: cashboxIds } },
      select: { amount: true },
    }),
    db.check.findMany({
      where: { companyId: session.companyId, deletedAt: null, status: "PENDING" },
      select: { id: true, checkNumber: true, amount: true, dueDate: true, checkType: true },
      orderBy: { dueDate: "asc" },
      take: 20,
    }),
  ]);

  return ok({
    rows: rows.map((b) => ({
      id: b.id, code: b.code, name: b.name, balance: b.balance,
      is_active: b.isActive, type: b.type, status: b.status, currency: b.currency,
      branch: b.branch,
    })),
    receipts_today: num(moneyR(sumOf(receipts, (r) => r.amount))),
    payments_today: num(moneyR(sumOf(payments, (r) => r.amount))),
    total_cash: num(moneyR(sumOf(rows, (b) => dec(b.balance)))),
    open_cashboxes: rows.filter((r) => r.status === "ACTIVE").length,
    top_cashboxes: [...rows]
      .sort((a, b) => num(dec(b.balance).minus(dec(a.balance))))
      .slice(0, 5)
      .map((b) => ({ id: b.id, code: b.code, name: b.name, balance: num(b.balance), branch: b.branch })),
    pending_checks: checks.map((c) => ({
      id: c.id, checkNumber: c.checkNumber, amount: num(c.amount),
      dueDate: c.dueDate.toISOString(), checkType: c.checkType,
    })),
  });
});

const createSchema = z.object({
  code: z.string().min(1),
  name: z.string().min(1),
  branch_id: z.number().int().positive(),
  type: z.enum(["MAIN", "BRANCH", "REP", "CUSTOM", "BANK"]).default("BRANCH"),
  currency: z.enum(["IQD", "USD"]).default("IQD"),
  opening_balance: z.number().default(0),
  description: z.string().optional(),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cashboxes.create");
  const body = await parseBody(req, createSchema);

  const cashbox = await db.cashbox.create({
    data: {
      companyId: session.companyId,
      branchId: body.branch_id,
      code: body.code,
      name: body.name,
      type: body.type,
      currency: body.currency,
      openingBalance: moneyR(body.opening_balance),
      balance: moneyR(body.opening_balance),
      description: body.description,
      createdBy: session.userId,
    },
  });

  // Opening balance flows into the cash ledger as an OPENING transaction
  if (body.opening_balance > 0) {
    const number = await nextDocumentNumber(db, session.companyId, "PAYMENT");
    await db.cashTransaction.create({
      data: {
        companyId: session.companyId,
        cashboxId: cashbox.id,
        direction: "IN",
        category: "OPENING",
        amount: moneyR(body.opening_balance),
        balanceAfter: moneyR(body.opening_balance),
        balanceBefore: moneyR(0),
        transactionType: "OPENING",
        transactionNumber: number,
        note: "رصيد افتتاحي للصندوق",
        createdBy: session.userId,
      },
    });
  }

  return ok({
    id: cashbox.id, code: cashbox.code, name: cashbox.name,
    type: cashbox.type, currency: cashbox.currency,
    opening_balance: num(cashbox.openingBalance),
  }, undefined, 201);
});
