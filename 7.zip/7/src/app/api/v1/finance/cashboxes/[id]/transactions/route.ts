// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { cashboxWhere } from "@/lib/scope";
import { listCashboxTransactions } from "@/lib/cashbox-service";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/finance/cashboxes/[id]/transactions
 *   ?limit=100      (max 500)
 *   ?offset=0
 *   ?from=ISO       (createdAt >=)
 *   ?to=ISO         (createdAt <=)
 *
 * Phase 67 — cashbox-scoped ledger (حركة الصندوق).
 * Permission: finance.cashboxes.view (read-only ledger inspection).
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const session = await guard(req, "finance.cashboxes.view");
  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) throw new ApiError("VAL_001", "معرّف غير صالح");

  // Verify the cashbox exists and is in scope (Phase 38 isolation).
  const box = await db.cashbox.findFirst({
    where: { id, companyId: session.companyId, deletedAt: null, ...cashboxWhere(session) },
    select: { id: true, name: true, code: true, currency: true, balance: true, status: true },
  });
  if (!box) throw new ApiError("CASHBOX_001");

  const url = new URL(req.url);
  const limit = url.searchParams.get("limit") ? Number(url.searchParams.get("limit")) : 100;
  const offset = url.searchParams.get("offset") ? Number(url.searchParams.get("offset")) : 0;
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");

  const result = await listCashboxTransactions(
    { userId: session.userId, companyId: session.companyId, branchId: session.activeBranchId },
    id,
    {
      limit,
      offset,
      fromDate: from ? new Date(from) : null,
      toDate: to ? new Date(to) : null,
    }
  );

  return ok({
    cashbox: {
      id: box.id,
      code: box.code,
      name: box.name,
      currency: box.currency,
      current_balance: box.balance,
      status: box.status,
    },
    ...result,
  });
});
