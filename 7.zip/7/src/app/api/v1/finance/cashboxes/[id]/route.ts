// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { cashboxWhere } from "@/lib/scope";
import { editCashbox } from "@/lib/cashbox-service";

export const dynamic = "force-dynamic";

/**
 * GET    /api/v1/finance/cashboxes/[id]              — fetch single cashbox (finance.cashboxes.view)
 * PATCH  /api/v1/finance/cashboxes/[id]              — edit cashbox metadata (finance.cashboxes.edit)
 *        Body: { name?, code?, type?, currency?, description?, ownerUserId?,
 *                warehouseId?, status?, isActive? } — balance is NEVER editable.
 *        Phase 67 / Phase 71 #2 (تعديل صندوق).
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const session = await guard(req, "finance.cashboxes.view");
  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) throw new ApiError("VAL_001", "معرّف غير صالح");

  const box = await db.cashbox.findFirst({
    where: { id, companyId: session.companyId, deletedAt: null, ...cashboxWhere(session) },
    include: {
      branch: { select: { id: true, name: true } },
      owner: { select: { id: true, fullName: true } },
      warehouse: { select: { id: true, name: true } },
    },
  });
  if (!box) throw new ApiError("CASHBOX_001");

  return ok({
    id: box.id,
    uuid: box.uuid,
    code: box.code,
    name: box.name,
    type: box.type,
    currency: box.currency,
    status: box.status,
    is_active: box.isActive,
    opening_balance: box.openingBalance,
    balance: box.balance,
    description: box.description,
    branch: box.branch,
    owner: box.owner,
    warehouse: box.warehouse,
    created_at: box.createdAt.toISOString(),
    updated_at: box.updatedAt.toISOString(),
  });
});

const patchSchema = z.object({
  name: z.string().min(1).max(200).optional(),
  code: z.string().min(1).max(50).optional(),
  type: z.enum(["MAIN", "BRANCH", "REP", "CUSTOM", "BANK"]).optional(),
  currency: z.enum(["IQD", "USD"]).optional(),
  description: z.string().nullable().optional(),
  ownerUserId: z.number().int().positive().nullable().optional(),
  warehouseId: z.number().int().positive().nullable().optional(),
  status: z.enum(["ACTIVE", "SUSPENDED"]).optional(),
  isActive: z.boolean().optional(),
});

export const PATCH = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const session = await guard(req, "finance.cashboxes.edit");
  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) throw new ApiError("VAL_001", "معرّف غير صالح");

  const body = await parseBody(req, patchSchema);
  const updated = await editCashbox(
    { userId: session.userId, companyId: session.companyId, branchId: session.activeBranchId, ip: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    id,
    {
      name: body.name,
      code: body.code,
      type: body.type,
      currency: body.currency,
      description: body.description,
      ownerUserId: body.ownerUserId,
      warehouseId: body.warehouseId,
      status: body.status,
      isActive: body.isActive,
    }
  );

  return ok(updated);
});
