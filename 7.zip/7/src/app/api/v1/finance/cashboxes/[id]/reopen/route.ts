// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { cashboxWhere } from "@/lib/scope";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/finance/cashboxes/[id]/reopen
 *   Body: { reason: string }
 *
 * Reopens a CLOSED cashbox (status CLOSED → ACTIVE). The closed
 * CashboxClosing record remains in DRAFT/CLOSED state (audit immutable),
 * but the cashbox itself is available again for new transactions.
 * Phase 67 / Phase 71 #3 (فتح صندوق).
 *
 * Permission: finance.cashboxes.reopen — Phase 37 new action.
 */
const reopenSchema = z.object({
  reason: z.string().min(3).max(500),
});

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const session = await guard(req, "finance.cashboxes.reopen");
  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) throw new ApiError("VAL_001", "معرّف غير صالح");

  const body = await parseBody(req, reopenSchema);

  const result = await db.$transaction(async (tx) => {
    const box = await tx.cashbox.findFirst({
      where: { id, companyId: session.companyId, deletedAt: null, ...cashboxWhere(session) },
    });
    if (!box) throw new ApiError("CASHBOX_001");
    if (box.status !== "CLOSED") {
      throw new ApiError("VAL_001", "الصندوق ليس مغلقًا — لا حاجة لإعادة الفتح");
    }

    // Mark the latest CLOSED closing as REOPENED (audit chain preserved)
    const lastClosing = await tx.cashboxClosing.findFirst({
      where: { cashboxId: box.id, status: "CLOSED" },
      orderBy: { closingDate: "desc" },
    });

    if (lastClosing) {
      await tx.cashboxClosing.update({
        where: { id: lastClosing.id },
        data: {
          status: "REOPENED",
          reopenedAt: new Date(),
          reopenedById: session.userId,
          reopenReason: body.reason,
        },
      });
    }

    // Reopen the cashbox itself
    const updated = await tx.cashbox.update({
      where: { id: box.id },
      data: { status: "ACTIVE" },
    });

    await tx.auditLog.create({
      data: {
        companyId: session.companyId,
        userId: session.userId,
        action: "REOPEN",
        module: "finance",
        entityType: "cashbox",
        entityId: box.id,
        oldValues: { status: "CLOSED" },
        newValues: { status: "ACTIVE", reason: body.reason, closingId: lastClosing?.id },
        ipAddress: req.headers.get("x-forwarded-for"),
        userAgent: req.headers.get("user-agent"),
      },
    });

    return { id: updated.id, status: updated.status, reopened_closing_id: lastClosing?.id ?? null };
  });

  return ok(result);
});
