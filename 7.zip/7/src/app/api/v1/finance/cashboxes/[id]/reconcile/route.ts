// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { reconcileCashbox } from "@/lib/cashbox-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/finance/cashboxes/[id]/reconcile
 *   Body: {
 *     actualCash?: number,            // counted total (if no denominations)
 *     denominations?: [{ denomination, count }], // 25000×50, 10000×60, ...
 *     closingDate?: ISO,
 *     notes?: string
 *   }
 *
 * Computes book vs actual without closing the cashbox. Persists as a
 * DRAFT CashboxClosing record. Operator can later promote to CLOSED
 * via /cash-closings or by closing the cashbox.
 *
 * Phase 67 — cashbox-scoped reconciliation (جرد الصندوق).
 * Permission: finance.cashboxes.reconcile — Phase 37 new action.
 */
const denomSchema = z.object({
  denomination: z.number().positive(),
  count: z.number().int().nonnegative(),
});

const reconcileSchema = z.object({
  actualCash: z.number().nonnegative().optional(),
  denominations: z.array(denomSchema).optional(),
  closingDate: z.string().datetime().optional(),
  notes: z.string().max(1000).optional(),
}).refine(
  (d) => d.actualCash != null || (Array.isArray(d.denominations) && d.denominations.length > 0),
  { message: "يلزم تحديد actualCash أو تفصيل الفئات" }
);

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const session = await guard(req, "finance.cashboxes.reconcile");
  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) throw new ApiError("VAL_001", "معرّف غير صالح");

  const body = await parseBody(req, reconcileSchema);

  const result = await reconcileCashbox(
    {
      userId: session.userId,
      companyId: session.companyId,
      branchId: session.activeBranchId,
      ip: req.headers.get("x-forwarded-for"),
      userAgent: req.headers.get("user-agent"),
    },
    {
      cashboxId: id,
      actualCash: body.actualCash,
      denominations: body.denominations,
      closingDate: body.closingDate ? new Date(body.closingDate) : null,
      notes: body.notes,
    }
  );

  return ok(result, undefined, 201);
});
