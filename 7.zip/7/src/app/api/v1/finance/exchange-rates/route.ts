// @ts-nocheck
import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { num, dec } from "@/lib/decimal";

export const dynamic = "force-dynamic";

const createSchema = z.object({
  base_currency: z.string().length(3).default("IQD"),
  quote_currency: z.string().length(3).default("USD"),
  rate: z.number().positive(),
  source: z.enum(["MANUAL", "BCI_IQ", "WESTERN_UNION", "EXCHANGE_API"]).default("MANUAL"),
  rate_date: z.string().datetime().optional(),
});

/**
 * GET /api/v1/finance/exchange-rates
 *   ?from=IQD&to=USD&limit=30
 *   ?latest=1 + base_currency + quote_currency → latest rate
 *
 * POST /api/v1/finance/exchange-rates — record a new rate snapshot
 *   Phase 29-30 — Auto/manual exchange rate history
 *   Permission: finance.exchange_rates.create
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.exchange_rates.view");
  const url = new URL(req.url);
  const latestFlag = url.searchParams.get("latest") === "1";
  const baseCurrency = url.searchParams.get("base_currency") ?? url.searchParams.get("from") ?? "IQD";
  const quoteCurrency = url.searchParams.get("quote_currency") ?? url.searchParams.get("to") ?? "USD";
  const limit = Math.min(365, Number(url.searchParams.get("limit") ?? "30"));

  if (latestFlag) {
    const row = await db.exchangeRateHistory.findFirst({
      where: { companyId: session.companyId, baseCurrency, quoteCurrency },
      orderBy: { rateDate: "desc" },
    });
    return ok(row ? {
      base_currency: row.baseCurrency,
      quote_currency: row.quoteCurrency,
      rate: num(row.rate),
      source: row.source,
      rate_date: row.rateDate.toISOString(),
      fetched_at: row.fetchedAt.toISOString(),
    } : null);
  }

  const rows = await db.exchangeRateHistory.findMany({
    where: {
      companyId: session.companyId,
      ...(baseCurrency ? { baseCurrency } : {}),
      ...(quoteCurrency ? { quoteCurrency } : {}),
    },
    orderBy: { rateDate: "desc" },
    take: limit,
  });

  return ok(rows.map((r) => ({
    id: r.id,
    base_currency: r.baseCurrency,
    quote_currency: r.quoteCurrency,
    rate: num(r.rate),
    source: r.source,
    rate_date: r.rateDate.toISOString(),
    fetched_at: r.fetchedAt.toISOString(),
  })));
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.exchange_rates.create");
  const body = await parseBody(req, createSchema);

  const rateDate = body.rate_date ? new Date(body.rate_date) : new Date();
  rateDate.setHours(0, 0, 0, 0);

  // Upsert: one rate per (company, base, quote, date)
  const existing = await db.exchangeRateHistory.findFirst({
    where: {
      companyId: session.companyId,
      baseCurrency: body.base_currency,
      quoteCurrency: body.quote_currency,
      rateDate,
    },
  });

  let row;
  if (existing) {
    row = await db.exchangeRateHistory.update({
      where: { id: existing.id },
      data: { rate: body.rate, source: body.source, fetchedAt: new Date() },
    });
  } else {
    row = await db.exchangeRateHistory.create({
      data: {
        companyId: session.companyId,
        baseCurrency: body.base_currency,
        quoteCurrency: body.quote_currency,
        rate: body.rate,
        source: body.source,
        rateDate,
        createdBy: session.userId,
      },
    });
  }

  return ok({
    id: row.id,
    base_currency: row.baseCurrency,
    quote_currency: row.quoteCurrency,
    rate: num(row.rate),
    source: row.source,
    rate_date: row.rateDate.toISOString(),
  }, undefined, 201);
});
