// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import type { CashActor } from "@/lib/cashbox-service";
import { z } from "zod";
export const dynamic = "force-dynamic";
const withdrawalSchema = z.object({ from_bank_account_id: z.number().int().positive(), to_cashbox_id: z.number().int().positive(), amount: z.number().positive(), currency: z.string().length(3).optional(), exchange_rate: z.number().positive().optional().nullable(), bank_withdrawal_ref: z.string().max(80).optional(), description: z.string().max(500).optional(), idempotency_key: z.string().max(120).optional(), withdrawal_date: z.string().datetime().optional() });
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cash_transfers.create");
  const body = await parseBody(req, withdrawalSchema);
  const result = await createBankWithdrawal({ userId: session.userId, companyId: session.companyId } as any, { bankAccountId: body.from_bank_account_id, toCashboxId: body.to_cashbox_id, amount: body.amount, currency: body.currency, exchangeRate: body.exchange_rate, bankWithdrawalRef: body.bank_withdrawal_ref, description: body.description, idempotencyKey: body.idempotency_key, withdrawalDate: body.withdrawal_date ? new Date(body.withdrawal_date) : undefined });
  return ok(result, undefined, 201);
});
