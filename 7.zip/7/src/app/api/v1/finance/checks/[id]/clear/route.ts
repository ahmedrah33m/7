// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import type { CashActor } from "@/lib/cashbox-service";
import { z } from "zod";
export const dynamic = "force-dynamic";
const clearSchema = z.object({ cashbox_id: z.number().int().positive(), cleared_at: z.string().datetime().optional(), notes: z.string().max(500).optional() });
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.receipts.create");
  const { id } = await ctx.params;
  const body = await parseBody(req, clearSchema);
  const result = await clearCheck({ userId: session.userId, companyId: session.companyId } as any, Number(id), { cashboxId: body.cashbox_id, clearedAt: body.cleared_at ? new Date(body.cleared_at) : undefined, notes: body.notes });
  return ok(result);
});
