// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
export const dynamic = "force-dynamic";
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cash_transfers.view");
  const url = new URL(req.url);
  const status = url.searchParams.get("status");
  const type = url.searchParams.get("type");
  const rows = await db.check.findMany({ where: { companyId: session.companyId, deletedAt: null, ...(status ? { status } : {}), ...(type ? { checkType: type } : {}) }, include: { customer: { select: { id: true, name: true, code: true } }, supplier: { select: { id: true, name: true, code: true } }, issuingBank: { select: { id: true, name: true, code: true } }, receivingBank: { select: { id: true, name: true, code: true } } }, orderBy: { dueDate: "asc" }, take: 200 });
  return ok(rows.map((c) => ({ id: c.id, check_number: c.checkNumber, check_type: c.checkType, direction: c.direction, amount: c.amount, currency: c.currency, issue_date: c.issueDate, due_date: c.dueDate, cleared_at: c.clearedAt, status: c.status, notes: c.notes, customer: c.customer, supplier: c.supplier, issuing_bank: c.issuingBank, receiving_bank: c.receivingBank, beneficiary_name: c.beneficiaryName })));
});
