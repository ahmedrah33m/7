// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { htmlToPdf, buildDailyReceiptsReportHtml } from "@/lib/pdf";
import { cashboxWhere } from "@/lib/scope";
import { num, sumOf, dec } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/finance/reports/daily-receipts
 *   ?date=YYYY-MM-DD   (defaults to today)
 *   ?cashbox_id=N      (filter by cashbox, else all in scope)
 *   ?from=&to=         (alternative date range)
 *
 * Phase 18-20 — Daily Receipts PDF Report (المرحلة 42 من MASTER PROMPT)
 * Permission: finance.receipts.view
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.receipts.view");
  const url = new URL(req.url);

  // Resolve date range
  let dateFrom: Date;
  let dateTo: Date;
  const dateParam = url.searchParams.get("date");
  const fromParam = url.searchParams.get("from");
  const toParam = url.searchParams.get("to");

  if (fromParam && toParam) {
    dateFrom = new Date(fromParam);
    dateTo = new Date(toParam);
    dateTo.setHours(23, 59, 59, 999);
  } else {
    // Single-day mode (defaults to today)
    const target = dateParam ? new Date(dateParam) : new Date();
    dateFrom = new Date(target);
    dateFrom.setHours(0, 0, 0, 0);
    dateTo = new Date(target);
    dateTo.setHours(23, 59, 59, 999);
  }

  // Resolve cashboxes in scope
  const cashboxIdParam = url.searchParams.get("cashbox_id");
  const cashboxes = await db.cashbox.findMany({
    where: { companyId: session.companyId, deletedAt: null, ...cashboxWhere(session) },
    select: { id: true, name: true, code: true, currency: true },
  });
  const cashboxIds = cashboxIdParam ? [Number(cashboxIdParam)] : cashboxes.map((c) => c.id);

  if (!cashboxIds.length) {
    return ok({ error: "لا صناديق في النطاق" }, undefined, 400);
  }

  // Fetch receipts in range
  const receipts = await db.receiptVoucher.findMany({
    where: {
      companyId: session.companyId,
      deletedAt: null,
      cashboxId: { in: cashboxIds },
      receiptDate: { gte: dateFrom, lte: dateTo },
    },
    orderBy: { receiptDate: "asc" },
    include: {
      customer: { select: { name: true } },
      cashbox: { select: { id: true, name: true, code: true, currency: true } },
    },
  });

  // Build summary by cashbox
  const byCashbox: Record<number, { name: string; code: string; currency: string; count: number; total: number; byMethod: Record<string, { count: number; total: number }> }> = {};
  for (const r of receipts) {
    if (!byCashbox[r.cashboxId]) {
      byCashbox[r.cashboxId] = {
        name: r.cashbox.name,
        code: r.cashbox.code,
        currency: r.cashbox.currency,
        count: 0,
        total: 0,
        byMethod: {},
      };
    }
    if (r.status === "POSTED") {
      byCashbox[r.cashboxId].count++;
      byCashbox[r.cashboxId].total += Number(r.amount);
      const method = r.paymentMethod ?? "CASH";
      if (!byCashbox[r.cashboxId].byMethod[method]) {
        byCashbox[r.cashboxId].byMethod[method] = { count: 0, total: 0 };
      }
      byCashbox[r.cashboxId].byMethod[method].count++;
      byCashbox[r.cashboxId].byMethod[method].total += Number(r.amount);
    }
  }

  // For single-cashbox mode, generate a single PDF; for multi-cashbox, generate
  // the first cashbox's PDF (or all combined).
  const company = await db.company.findFirst({
    where: { id: session.companyId },
    select: { name: true, phone: true, address: true },
  });

  // Aggregate all receipts across cashboxes into a single report
  const allReceiptsFlat = receipts.map((r) => ({
    number: r.number,
    receiptDate: new Date(r.receiptDate).toLocaleString("ar-IQ"),
    recipientName: r.recipientName,
    customerName: r.customer?.name ?? null,
    amount: Number(r.amount),
    paymentMethod: r.paymentMethod ?? "CASH",
    referenceNumber: r.referenceNumber,
    status: r.status,
  }));

  const totalsByMethod: Record<string, { count: number; total: number }> = {};
  for (const cb of Object.values(byCashbox)) {
    for (const [method, info] of Object.entries(cb.byMethod)) {
      if (!totalsByMethod[method]) totalsByMethod[method] = { count: 0, total: 0 };
      totalsByMethod[method].count += info.count;
      totalsByMethod[method].total += info.total;
    }
  }
  const totalCount = Object.values(totalsByMethod).reduce((s, m) => s + m.count, 0);
  const totalAmount = Object.values(totalsByMethod).reduce((s, m) => s + m.total, 0);

  // Use the first cashbox's metadata (for currency display)
  const firstCashbox = cashboxes[0] ?? { name: "—", code: "—", currency: "IQD" };

  const html = buildDailyReceiptsReportHtml({
    companyName: company?.name ?? "نظام ميدان ERP",
    companyPhone: company?.phone ?? null,
    companyAddress: company?.address ?? null,
    cashboxId: 0,
    cashboxName: cashboxIdParam ? (cashboxes.find((c) => c.id === Number(cashboxIdParam))?.name ?? "—") : "كل الصناديق",
    cashboxCode: cashboxIdParam ? (cashboxes.find((c) => c.id === Number(cashboxIdParam))?.code ?? "—") : "ALL",
    cashboxCurrency: firstCashbox.currency ?? "IQD",
    dateFrom: dateFrom.toLocaleString("ar-IQ"),
    dateTo: dateTo.toLocaleString("ar-IQ"),
    generatedAt: new Date().toLocaleString("ar-IQ"),
    receipts: allReceiptsFlat,
    totals: {
      count: totalCount,
      totalAmount,
      byMethod: totalsByMethod,
    },
  });

  try {
    const pdf = await htmlToPdf(html);
    return new Response(pdf, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="daily-receipts-${dateFrom.toISOString().slice(0, 10)}.pdf"`,
      },
    });
  } catch {
    return ok({ error: "PDF engine unavailable", html }, undefined, 503);
  }
});
