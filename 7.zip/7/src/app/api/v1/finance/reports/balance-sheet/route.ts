// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { getBalanceSheet } from "@/lib/accounting-service";
export const dynamic = "force-dynamic";
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.statements.view");
  const result = await getBalanceSheet(session.companyId);
  return ok(result);
});
