// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { getIncomeStatement } from "@/lib/accounting-service";
export const dynamic = "force-dynamic";
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.statements.view");
  const result = await getIncomeStatement(session.companyId);
  return ok(result);
});
