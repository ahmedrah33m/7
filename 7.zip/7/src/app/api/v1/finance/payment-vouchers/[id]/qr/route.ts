// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import QRCode from "qrcode";

export const dynamic = "force-dynamic";

/** GET /api/v1/finance/payment-vouchers/[id]/qr — get QR SVG */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.payment_vouchers.view");
  const { id } = await ctx.params;
  const v = await db.paymentVoucher.findFirst({ where: { id: Number(id), companyId: session.companyId, deletedAt: null } });
  if (!v) return ok({ error: "Not found" }, undefined, 404);
  const verifyUrl = `${req.nextUrl.origin}/verify/${v.verifyToken}`;
  const svg = await QRCode.toString(verifyUrl, { type: "svg", width: 200, margin: 2 });
  return ok({ number: v.number, verify_url: verifyUrl, svg });
});
