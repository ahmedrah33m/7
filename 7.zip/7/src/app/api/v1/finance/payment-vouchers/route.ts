// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { branchWhere } from "@/lib/scope";
import { createPaymentVoucher, type CreatePaymentVoucherInput, type ReceiptAllocationInput } from "@/lib/cashbox-service";
import { z } from "zod";

export const dynamic = "force-dynamic";

const voucherSchema = z.object({
  cashbox_id: z.number().int().positive().optional(),
  supplier_id: z.number().int().positive().optional(),
  customer_id: z.number().int().positive().optional(),
  charge_to_customer_id: z.number().int().positive().optional(),
  beneficiary_name: z.string().max(120).optional(),
  amount: z.number().positive(),
  currency: z.string().length(3).optional(),
  exchange_rate: z.number().positive().optional().nullable(),
  // Phase 15 — MIXED added so split amounts become valid
  payment_method: z.enum(["CASH", "CARD", "BANK_TRANSFER", "ELECTRONIC", "MIXED"]),
  reason: z.enum([
    "PAYMENT_TO_SUPPLIER", "EXPENSE", "ADVANCE", "DIRECT_PURCHASE",
    "REFUND", "OPERATING_EXPENSE", "BANK_TRANSFER", "OTHER",
  ]),
  expense_category: z.string().max(80).optional(),
  expense_category_id: z.number().int().positive().optional(),
  purchase_invoice_id: z.number().int().positive().optional(),
  allocations: z.array(z.object({
    invoice_type: z.enum(["SALES", "PURCHASE"]),
    invoice_id: z.number().int().positive(),
    amount: z.number().positive(),
  })).optional(),
  reference_number: z.string().max(80).optional(),
  bank_name: z.string().max(80).optional(),
  bank_account: z.string().max(80).optional(),
  card_last4: z.string().max(4).optional(),
  // ---- Phase 15 — Mixed payment split amounts -------------------------
  cash_amount: z.number().nonnegative().optional(),
  card_amount: z.number().nonnegative().optional(),
  bank_amount: z.number().nonnegative().optional(),
  on_account_amount: z.number().nonnegative().optional(),
  description: z.string().max(500).optional(),
  notes: z.string().max(500).optional(),
  paid_to: z.string().max(80).optional(),
  idempotency_key: z.string().max(120).optional(),
  payment_date: z.string().datetime().optional(),
});

/**
 * GET /api/v1/finance/payment-vouchers — searchable list
 *   Query params (all optional):
 *     search       — match against number OR beneficiaryName OR supplier.name OR customer.name
 *     status       — POSTED | CANCELLED
 *     supplier_id  — filter by supplier
 *     customer_id  — filter by customer
 *     cashbox_id   — filter by cashbox
 *     date_from    — ISO date (inclusive)
 *     date_to      — ISO date (inclusive)
 *     amount_min   — minimum amount
 *     amount_max   — maximum amount
 *     reason       — filter by voucher reason
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.payment_vouchers.view");
  const url = new URL(req.url);
  const perPage = Math.min(200, Math.max(1, Number(url.searchParams.get("per_page") ?? 50)));
  const search = url.searchParams.get("search")?.trim() || "";
  const status = url.searchParams.get("status");
  const supplierId = url.searchParams.get("supplier_id");
  const customerId = url.searchParams.get("customer_id");
  const cashboxId = url.searchParams.get("cashbox_id");
  const dateFrom = url.searchParams.get("date_from");
  const dateTo = url.searchParams.get("date_to");
  const amountMin = url.searchParams.get("amount_min");
  const amountMax = url.searchParams.get("amount_max");
  const reason = url.searchParams.get("reason");

  const where: any = {
    companyId: session.companyId,
    deletedAt: null,
    ...branchWhere(session),
  };
  if (status) where.status = status;
  if (supplierId) where.supplierId = Number(supplierId);
  if (customerId) where.customerId = Number(customerId);
  if (cashboxId) where.cashboxId = Number(cashboxId);
  if (reason) where.reason = reason;
  if (dateFrom || dateTo) {
    where.paymentDate = {};
    if (dateFrom) where.paymentDate.gte = new Date(dateFrom);
    if (dateTo) {
      const end = new Date(dateTo);
      end.setHours(23, 59, 59, 999);
      where.paymentDate.lte = end;
    }
  }
  if (amountMin || amountMax) {
    where.amount = {};
    if (amountMin) where.amount.gte = Number(amountMin);
    if (amountMax) where.amount.lte = Number(amountMax);
  }
  if (search) {
    where.OR = [
      { number: { contains: search } },
      { beneficiaryName: { contains: search } },
      { referenceNumber: { contains: search } },
      { paidTo: { contains: search } },
      { supplier: { name: { contains: search } } },
      { customer: { name: { contains: search } } },
    ];
  }

  const rows = await db.paymentVoucher.findMany({
    where,
    include: {
      supplier: { select: { id: true, name: true, code: true } },
      customer: { select: { id: true, name: true, code: true } },
      cashbox: { select: { id: true, name: true, code: true, currency: true } },
      purchaseInvoice: { select: { id: true, number: true } },
    },
    orderBy: { paymentDate: "desc" },
    take: perPage,
  });
  return ok(rows.map((v) => ({
    id: v.id, number: v.number, payment_date: v.paymentDate,
    beneficiary_name: v.beneficiaryName,
    supplier: v.supplier, customer: v.customer, cashbox: v.cashbox,
    purchase_invoice: v.purchaseInvoice,
    amount: v.amount, currency: v.currency, payment_method: v.paymentMethod,
    reason: v.reason, expense_category: v.expenseCategory, status: v.status,
    reference_number: v.referenceNumber,
    verify_token: v.verifyToken,
    grand_total_snapshot: v.grandTotalSnapshot,
    previously_paid_snapshot: v.previouslyPaidSnapshot,
    current_payment_snapshot: v.currentPaymentSnapshot,
    remaining_snapshot: v.remainingSnapshot,
    created_at: v.createdAt,
  })));
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.payment_vouchers.create");
  const body = await parseBody(req, voucherSchema);

  // Resolve branchId from active session — Phase 38 isolation.
  const branchId = session.activeBranchId ?? (session.branchIds[0] ?? 0);
  if (!branchId) throw new ApiError("SCOPE_003", "لا يوجد فرع نشط في الجلسة");

  const input: CreatePaymentVoucherInput = {
    cashboxId: body.cashbox_id,
    supplierId: body.supplier_id,
    customerId: body.customer_id,
    chargeToCustomerId: body.charge_to_customer_id,
    beneficiaryName: body.beneficiary_name,
    branchId,
    amount: body.amount,
    currency: body.currency,
    exchangeRate: body.exchange_rate,
    paymentMethod: body.payment_method,
    reason: body.reason,
    expenseCategory: body.expense_category,
    expenseCategoryId: body.expense_category_id,
    purchaseInvoiceId: body.purchase_invoice_id,
    allocations: body.allocations?.map((a): ReceiptAllocationInput => ({
      invoiceType: a.invoice_type,
      invoiceId: a.invoice_id,
      amount: a.amount,
    })),
    referenceNumber: body.reference_number,
    bankName: body.bank_name,
    bankAccount: body.bank_account,
    cardLast4: body.card_last4,
    // Phase 15 — Mixed payment split (only honored when payment_method=MIXED)
    cashAmount: body.cash_amount,
    cardAmount: body.card_amount,
    bankAmount: body.bank_amount,
    onAccountAmount: body.on_account_amount,
    description: body.description,
    notes: body.notes,
    paidTo: body.paid_to,
    idempotencyKey: body.idempotency_key,
  };
  // Note: payment_date is captured inside the service as `new Date()` — kept
  // consistent with the cash_transaction timestamps for audit chain alignment.
  // (Body field `payment_date` is ignored intentionally — historical
  // backdating is reserved for a future Supervisor-approval flow.)

  const result = await createPaymentVoucher(
    {
      userId: session.userId,
      companyId: session.companyId,
      branchId,
      ip: req.headers.get("x-forwarded-for"),
      userAgent: req.headers.get("user-agent"),
    },
    input
  );
  return ok(result, undefined, 201);
});
