// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { htmlToPdf, buildPaymentVoucherThermalHtml, amountInWords } from "@/lib/pdf";
import QRCode from "qrcode";
export const dynamic = "force-dynamic";

/** GET /api/v1/finance/payment-vouchers/[id]/thermal — 80mm thermal payment voucher */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.payment_vouchers.print");
  const { id } = await ctx.params;
  const v = await db.paymentVoucher.findFirst({
    where: { id: Number(id), companyId: session.companyId, deletedAt: null },
    include: { supplier: { select: { code: true } }, cashbox: { select: { name: true } },
      company: { select: { name: true, phone: true, address: true, taxNumber: true } } },
  });
  if (!v) return ok({ error: "Not found" }, undefined, 404);
  const verifyUrl = `${req.nextUrl.origin}/verify/${v.verifyToken}`;
  const qrSvg = await QRCode.toString(verifyUrl, { type: "svg", width: 160, margin: 0 });
  const html = buildPaymentVoucherThermalHtml({
    companyName: v.company.name, companyPhone: v.company.phone, companyAddress: v.company.address,
    companyTaxNumber: v.company.taxNumber, number: v.number, voucherDate: new Date(v.voucherDate).toLocaleString("ar-IQ"),
    cashboxName: v.cashbox?.name ?? "على الحساب", beneficiaryName: v.beneficiaryName,
    supplierCode: v.supplier?.code ?? null, amount: Number(v.amount), amountInWords: amountInWords(Number(v.amount), v.currency),
    currency: v.currency, paymentMethod: v.paymentMethod, referenceNumber: v.referenceNumber,
    reason: v.reason, expenseCategory: v.expenseCategory, description: v.description, paidTo: v.paidTo,
    qrSvg, qrVerifyUrl: verifyUrl,
  } as any);
  try {
    const pdf = await htmlToPdf(html);
    return new Response(pdf, { headers: { "Content-Type": "application/pdf", "Content-Disposition": `inline; filename="thermal-${v.number}.pdf"` } });
  } catch { return ok({ error: "PDF engine unavailable", html }, undefined, 503); }
});
