// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.payment_vouchers.view");
  const { id } = await ctx.params;
  const v = await db.paymentVoucher.findFirst({ where: { id: Number(id), companyId: session.companyId, deletedAt: null }, include: { supplier: true, customer: true, cashbox: true, purchaseInvoice: { select: { id: true, number: true, grandTotal: true, paidAmount: true } }, payment: { include: { allocations: true } }, cashTransactions: true } });
  if (!v) return ok({ valid: false, message: "وصل الصرف غير موجود" }, undefined, 404);
  return ok({ id: v.id, number: v.number, voucher_date: v.voucherDate, cashbox: v.cashbox, beneficiary_name: v.beneficiaryName, supplier: v.supplier, customer: v.customer, purchase_invoice: v.purchaseInvoice, amount: v.amount, currency: v.currency, exchange_rate: v.exchangeRate, amount_in_cashbox: v.amountInCashbox, payment_method: v.paymentMethod, reference_number: v.referenceNumber, bank_name: v.bankName, bank_account: v.bankAccount, reason: v.reason, expense_category: v.expenseCategory, purchase_snapshot: v.purchaseSnapshot, grand_total_snapshot: v.grandTotalSnapshot, previously_paid_snapshot: v.previouslyPaidSnapshot, current_payment_snapshot: v.currentPaymentSnapshot, remaining_snapshot: v.remainingSnapshot, status: v.status, cancel_reason: v.cancelReason, cancelled_at: v.cancelledAt, verify_token: v.verifyToken, qr_data: v.qrData, print_count: v.printCount, description: v.description, notes: v.notes, paid_to: v.paidTo, allocations: v.payment?.allocations ?? [], cash_transactions: v.cashTransactions.map((t) => ({ id: t.id, direction: t.direction, amount: t.amount, balance_before: t.balanceBefore, balance_after: t.balanceAfter, transaction_type: t.transactionType, transaction_number: t.transactionNumber, is_reversed: t.isReversed, note: t.note, created_at: t.createdAt })), created_at: v.createdAt });
});
