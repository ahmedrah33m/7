// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { htmlToPdf, buildPaymentVoucherHtml, amountInWords } from "@/lib/pdf";
import QRCode from "qrcode";

export const dynamic = "force-dynamic";

/** GET /api/v1/finance/payment-vouchers/[id]/pdf — download payment voucher PDF with QR */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.payment_vouchers.print");
  const { id } = await ctx.params;

  const v = await db.paymentVoucher.findFirst({
    where: { id: Number(id), companyId: session.companyId, deletedAt: null },
    include: {
      supplier: { select: { name: true, code: true } },
      customer: { select: { name: true, code: true } },
      cashbox: { select: { name: true, code: true, currency: true } },
      company: { select: { name: true, phone: true, address: true, taxNumber: true } },
      branch: { select: { name: true } },
    },
  });
  if (!v) return ok({ error: "Payment voucher not found" }, undefined, 404);

  const verifyUrl = `${req.nextUrl.origin}/verify/${v.verifyToken}`;
  const qrSvg = await QRCode.toString(verifyUrl, { type: "svg", width: 160, margin: 1 });

  const html = buildPaymentVoucherHtml({
    companyName: v.company.name,
    companyPhone: v.company.phone,
    companyAddress: v.company.address,
    companyTaxNumber: v.company.taxNumber,
    branchName: v.branch?.name,
    number: v.number,
    voucherDate: new Date(v.voucherDate).toLocaleString("ar-IQ"),
    cashboxName: v.cashbox?.name ?? "على الحساب",
    beneficiaryName: v.beneficiaryName,
    supplierCode: v.supplier?.code ?? null,
    amount: Number(v.amount),
    amountInWords: amountInWords(Number(v.amount), v.currency),
    currency: v.currency,
    paymentMethod: v.paymentMethod,
    referenceNumber: v.referenceNumber,
    bankName: v.bankName,
    bankAccount: v.bankAccount,
    reason: v.reason,
    expenseCategory: v.expenseCategory,
    description: v.description,
    notes: v.notes,
    paidTo: v.paidTo,
    qrSvg,
    qrVerifyUrl: verifyUrl,
  });

  await db.paymentVoucher.update({ where: { id: v.id }, data: { printCount: { increment: 1 } } });

  try {
    const pdfBuffer = await htmlToPdf(html);
    return new Response(pdfBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="${v.number}.pdf"`,
        "Cache-Control": "private, max-age=0",
      },
    });
  } catch {
    return ok({ error: "PDF engine unavailable", html }, undefined, 503);
  }
});
