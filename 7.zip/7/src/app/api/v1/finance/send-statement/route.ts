// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { z } from "zod";
export const dynamic = "force-dynamic";

const sendSchema = z.object({
  customer_id: z.number().int().positive().optional(),
  supplier_id: z.number().int().positive().optional(),
  email: z.string().email(),
  date_from: z.string().datetime().optional(),
  date_to: z.string().datetime().optional(),
});

/** POST /api/v1/finance/send-statement — send customer/supplier statement via email */
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.statements.view");
  const body = await parseBody(req, sendSchema);

  // In production, this would use Nodemailer/SES/Resend to send the email
  // For now, we generate the statement URL and return it
  // The email would contain: subject + HTML body with statement link + PDF attachment

  const partyType = body.customer_id ? "customer" : "supplier";
  const partyId = body.customer_id ?? body.supplier_id;
  const statementUrl = `/api/v1/finance/statements/${partyType}/${partyId}`;

  // Email template (stub — would be sent via SMTP in production)
  const emailContent = {
    to: body.email,
    subject: `كشف حساب — ${partyType === "customer" ? "العميل" : "المورد"}`,
    body: `
      <html dir="rtl" lang="ar">
      <body style="font-family: Arial, sans-serif; padding: 20px;">
        <h2>كشف حساب</h2>
        <p>يرجى الاطلاع على كشف حسابكم المرفق.</p>
        <p>للاطلاع على التفاصيل الكاملة، يرجى زيارة:</p>
        <a href="${statementUrl}">${statementUrl}</a>
        <p>مع تحيات،<br/>إدارة الحسابات</p>
      </body>
      </html>
    `,
    statement_url: statementUrl,
    sent_at: new Date().toISOString(),
  };

  // In production:
  // const transporter = nodemailer.createTransport({ host: process.env.SMTP_HOST, port: 587, ... });
  // await transporter.sendMail({ from: ..., to: body.email, subject: ..., html: emailContent.body });

  return ok({
    status: "QUEUED",
    message: `تم إعداد إرسال كشف الحساب إلى ${body.email}`,
    email: body.email,
    statement_url: statementUrl,
    note: "في الإنتاج، يُرسل عبر SMTP. أضف SMTP_HOST/SMTP_PORT/SMTP_USER/SMTP_PASS في .env",
  });
});
