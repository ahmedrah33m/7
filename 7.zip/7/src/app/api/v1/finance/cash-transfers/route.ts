// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { createCashTransfer, type CreateCashTransferInput, type CashActor } from "@/lib/cashbox-service";
import { z } from "zod";

export const dynamic = "force-dynamic";

const transferSchema = z.object({
  from_cashbox_id: z.number().int().positive(),
  to_cashbox_id: z.number().int().positive(),
  amount: z.number().positive(),
  currency: z.string().length(3).optional(),
  exchange_rate: z.number().positive().optional().nullable(),
  is_bank_deposit: z.boolean().optional(),
  is_bank_withdrawal: z.boolean().optional(),
  bank_deposit_ref: z.string().max(80).optional(),
  bank_withdrawal_ref: z.string().max(80).optional(),
  description: z.string().max(500).optional(),
  notes: z.string().max(500).optional(),
  idempotency_key: z.string().max(120).optional(),
});

export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cash_transfers.view");
  const url = new URL(req.url);
  const status = url.searchParams.get("status");
  const rows = await db.cashTransfer.findMany({
    where: {
      companyId: session.companyId,
      deletedAt: null,
      ...(status ? { status } : {}),
    },
    include: {
      fromCashbox: { select: { id: true, name: true, code: true, currency: true } },
      toCashbox: { select: { id: true, name: true, code: true, currency: true } },
    },
    orderBy: { transferDate: "desc" },
    take: 200,
  });
  return ok(rows.map((t) => ({
    id: t.id,
    number: t.number,
    transfer_date: t.transferDate,
    from: t.fromCashbox,
    to: t.toCashbox,
    amount: t.amount,
    currency: t.currency,
    exchange_rate: t.exchangeRate,
    source_amount: t.sourceAmount,
    target_amount: t.targetAmount,
    is_bank_deposit: t.isBankDeposit,
    is_bank_withdrawal: t.isBankWithdrawal,
    status: t.status,
    cancel_reason: t.cancelReason,
    description: t.description,
    created_at: t.createdAt,
  })));
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.cash_transfers.create");
  const body = await parseBody(req, transferSchema);

  // Phase 38 — Branch isolation: branchId resolved from session, not body.
  const branchId = session.activeBranchId ?? session.branchIds[0] ?? 0;
  if (!branchId) throw new ApiError("SCOPE_003", "لا يوجد فرع نشط في الجلسة");

  const input: CreateCashTransferInput = {
    fromCashboxId: body.from_cashbox_id,
    toCashboxId: body.to_cashbox_id,
    branchId,
    amount: body.amount,
    currency: body.currency,
    exchangeRate: body.exchange_rate,
    isBankDeposit: body.is_bank_deposit,
    isBankWithdrawal: body.is_bank_withdrawal,
    bankDepositRef: body.bank_deposit_ref,
    bankWithdrawalRef: body.bank_withdrawal_ref,
    description: body.description,
    notes: body.notes,
    idempotencyKey: body.idempotency_key,
  };
  const result = await createCashTransfer(
    {
      userId: session.userId,
      companyId: session.companyId,
      branchId,
      ip: req.headers.get("x-forwarded-for"),
      userAgent: req.headers.get("user-agent"),
    },
    input
  );
  return ok(result, undefined, 201);
});
