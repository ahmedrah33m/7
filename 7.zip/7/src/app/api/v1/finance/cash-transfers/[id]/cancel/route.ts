// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { cancelCashTransfer, type CashActor } from "@/lib/cashbox-service";
import { z } from "zod";
export const dynamic = "force-dynamic";
const cancelSchema = z.object({ reason: z.string().min(3).max(500) });
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "finance.cash_transfers.cancel");
  const { id } = await ctx.params;
  const { reason } = await parseBody(req, cancelSchema);
  const result = await cancelCashTransfer({ userId: session.userId, companyId: session.companyId } as any, Number(id), reason);
  return ok(result);
});
