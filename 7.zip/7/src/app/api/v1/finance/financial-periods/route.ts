// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { z } from "zod";
export const dynamic = "force-dynamic";
const periodSchema = z.object({ name: z.string().min(2).max(60), period_type: z.enum(["MONTH", "QUARTER", "YEAR"]).default("MONTH"), start_date: z.string().datetime(), end_date: z.string().datetime() });
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "finance.statements.view");
  const rows = await db.financialPeriod.findMany({ where: { companyId: session.companyId }, orderBy: { startDate: "desc" } });
  return ok(rows.map((p) => ({ id: p.id, name: p.name, period_type: p.periodType, start_date: p.startDate, end_date: p.endDate, status: p.status, closed_at: p.closedAt, close_note: p.closeNote })));
});
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.settings.edit");
  const body = await parseBody(req, periodSchema);
  const existing = await db.financialPeriod.findFirst({ where: { companyId: session.companyId, name: body.name } });
  if (existing) return ok({ id: existing.id, name: existing.name, status: existing.status });
  const period = await db.financialPeriod.create({ data: { companyId: session.companyId, name: body.name, periodType: body.period_type, startDate: new Date(body.start_date), endDate: new Date(body.end_date), status: "OPEN" } });
  return ok({ id: period.id, name: period.name, status: "OPEN" }, undefined, 201);
});
