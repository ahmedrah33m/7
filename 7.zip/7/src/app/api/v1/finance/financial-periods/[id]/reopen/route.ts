// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { reopenFinancialPeriod } from "@/lib/accounting-service";
import { z } from "zod";
export const dynamic = "force-dynamic";
const reopenSchema = z.object({ reason: z.string().min(3).max(500) });
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "system.settings.edit");
  const { id } = await ctx.params;
  const { reason } = await parseBody(req, reopenSchema);
  const result = await reopenFinancialPeriod({ userId: session.userId, companyId: session.companyId }, Number(id), reason);
  return ok(result);
});
