// @ts-nocheck
import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { closeFinancialPeriod } from "@/lib/accounting-service";
import { z } from "zod";
export const dynamic = "force-dynamic";
const closeSchema = z.object({ close_note: z.string().max(500).optional() });
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "system.settings.edit");
  const { id } = await ctx.params;
  const body = await parseBody(req, closeSchema);
  const result = await closeFinancialPeriod({ userId: session.userId, companyId: session.companyId }, Number(id), body.close_note);
  return ok(result);
});
