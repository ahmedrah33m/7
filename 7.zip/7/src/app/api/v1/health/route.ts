import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit } from "@/lib/rate-limit";
import { ERROR_CODES } from "@/lib/errors";

export const dynamic = "force-dynamic";

/** GET /api/v1/health — public readiness probe (rate-limited 600/min per IP). */
export async function GET(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
  const rl = rateLimit(`rl:${ip}`, 600);
  if (!rl.allowed) {
    return NextResponse.json(
      { success: false, code: "RATE_001", message: ERROR_CODES.RATE_001.ar },
      { status: 429, headers: { "Retry-After": String(rl.retryAfterSec) } }
    );
  }
  try {
    await db.$queryRaw`SELECT 1`;
    // Seed probe: detects an up-but-empty database (AUTH_003 for everyone).
    const userCount = await db.user.count({ where: { deletedAt: null } });
    return NextResponse.json({
      success: true,
      data: {
        status: "ok",
        service: "sds-api",
        version: "0.1.0-phase0",
        database: "up",
        seeded: userCount > 0,
        time: new Date().toISOString(),
      },
    });
  } catch {
    return NextResponse.json(
      { success: false, code: "SRV_002", message: "قاعدة البيانات غير متاحة" },
      { status: 503 }
    );
  }
}
