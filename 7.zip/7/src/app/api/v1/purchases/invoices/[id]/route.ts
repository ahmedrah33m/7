import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, ApiError } from "@/lib/api";
import { db } from "@/lib/db";
import { deletePurchaseInvoice } from "@/lib/purchasing-service";
import { dec, moneyR, num } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/purchases/invoices/[id] — fetch single invoice with full lines
 *   (purchasing.purchase_invoices.view)
 *   v15: returns invoice header + all lines with product info + sale prices.
 *
 * DELETE /api/v1/purchases/invoices/[id] — حذف فاتورة شراء (عكس كامل)
 *   (purchasing.purchase_invoices.delete)
 *   · مخزون OUT لكل بند — يُرفض إذا بيعت البضاعة (لا سالب مخزون)
 *   · خصم ذمة المورد + إرجاع المبلغ المسدد للصندوق (قيد قلب)
 *   · soft delete + audit
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "purchasing.purchase_invoices.view");
  const { id } = await ctx.params;
  const invoiceId = Number(id);
  if (!Number.isInteger(invoiceId)) throw new ApiError("VAL_003", "معرّف فاتورة غير صالح");

  const inv = await db.purchaseInvoice.findFirst({
    where: { id: invoiceId, companyId: session.companyId, deletedAt: null },
    include: {
      supplier: { select: { id: true, code: true, name: true, phone: true } },
      warehouse: { select: { id: true, code: true, name: true } },
      branch: { select: { id: true, name: true } },
      creator: { select: { id: true, fullName: true } },
      lines: {
        include: {
          product: {
            select: {
              id: true, code: true, name: true, unit: true,
              packUnit: true, packQty: true,
              costPrice: true, salePrice: true, packSalePrice: true,
            },
          },
        },
        orderBy: { id: "asc" },
      },
    },
  });
  if (!inv) throw new ApiError("VAL_003", "فاتورة الشراء غير موجودة");

  const grandTotal = dec(inv.grandTotal);
  const paidAmount = dec(inv.paidAmount);
  const dueAmount = moneyR(grandTotal.minus(paidAmount));

  return ok({
    id: inv.id,
    number: inv.number,
    status: inv.status,
    invoice_date: inv.invoiceDate.toISOString(),
    supplier: inv.supplier,
    warehouse: inv.warehouse,
    branch: inv.branch,
    creator: inv.creator,
    currency_code: inv.currencyCode ?? "IQD",
    exchange_rate: inv.exchangeRate ? num(inv.exchangeRate) : null,
    notes: inv.notes,
    // Totals (in IQD — base currency)
    subtotal: num(inv.subtotal),
    grand_total: num(inv.grandTotal),
    paid_amount: num(inv.paidAmount),
    due_amount: num(dueAmount),
    // Lines with full detail
    lines: inv.lines.map((l) => {
      const productPackQty = Number(l.product.packQty ?? 1);
      const productPackUnit = l.product.packUnit ?? null;
      const cartons = productPackQty > 1 ? Math.floor(Number(l.qty) / productPackQty) : 0;
      const pieces = productPackQty > 1
        ? Math.round((Number(l.qty) - cartons * productPackQty) * 1e6) / 1e6
        : Number(l.qty);
      return {
        id: l.id,
        product_id: l.productId,
        product: l.product,
        qty: num(l.qty),
        unit_cost: num(l.unitCost),
        line_total: num(l.lineTotal),
        // Derived fields for display
        cartons,
        pieces,
        pack_qty: productPackQty,
        pack_unit: productPackUnit,
        wholesale_sale_price: l.product.packSalePrice ? num(l.product.packSalePrice) : null,
        retail_sale_price: l.product.salePrice ? num(l.product.salePrice) : null,
      };
    }),
  });
});

export const DELETE = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "purchasing.purchase_invoices.delete");
  const { id } = await ctx.params;
  const invoiceId = Number(id);
  if (!Number.isInteger(invoiceId)) throw new ApiError("VAL_003", "معرّف فاتورة غير صالح");

  const result = await deletePurchaseInvoice(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    invoiceId
  );

  return ok(result);
});
