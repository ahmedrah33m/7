import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { db } from "@/lib/db";
import { createPurchaseInvoice } from "@/lib/purchasing-service";
import { dec, moneyR, num } from "@/lib/decimal";
import { branchWhere } from "@/lib/scope";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/purchases/invoices — list (purchasing.purchase_invoices.view)
 *   Query params:
 *     q         — search by invoice number OR supplier name
 *     per_page  — page size (default 50, max 100)
 *     status    — filter by status (POSTED, VOID)
 *
 * POST /api/v1/purchases/invoices — post supplier invoice
 *   (purchasing.purchase_invoices.create) — atomic: numbering + stock IN
 *   + WAVG cost update + supplier balance + optional cash payment.
 *   v15: supports currency_code (IQD|USD) + exchange_rate + sale prices per line.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "purchasing.purchase_invoices.view");
  const url = new URL(req.url);
  const q = url.searchParams.get("q")?.trim() ?? url.searchParams.get("search")?.trim() ?? "";
  const perPage = Math.min(100, Math.max(1, Number(url.searchParams.get("per_page") ?? 50)));
  const status = url.searchParams.get("status");

  const where = {
    companyId: session.companyId,
    ...branchWhere(session),
    deletedAt: null,
    ...(status ? { status } : {}),
    ...(q ? { OR: [{ number: { contains: q } }, { supplier: { name: { contains: q } } }] } : {}),
  };

  const [rows, total] = await Promise.all([
    db.purchaseInvoice.findMany({
      where,
      include: {
        supplier: { select: { id: true, code: true, name: true } },
        warehouse: { select: { code: true, name: true } },
        creator: { select: { fullName: true } },
        _count: { select: { lines: true } },
      },
      orderBy: { id: "desc" },
      take: perPage,
    }),
    db.purchaseInvoice.count({ where }),
  ]);

  return ok(
    rows.map((inv) => ({
      id: inv.id,
      number: inv.number,
      type: dec(inv.paidAmount).gte(dec(inv.grandTotal)) ? "CASH" : "CREDIT",
      status: inv.status,
      invoice_date: inv.invoiceDate,
      supplier: inv.supplier,
      warehouse: inv.warehouse,
      supplier_id: inv.supplier.id,
      lines_count: inv._count.lines,
      grand_total: num(inv.grandTotal),
      paid_amount: num(inv.paidAmount),
      // صافي مستحقات المورد = grandTotal − paidAmount (Decimal — بلا float)
      due_amount: num(moneyR(dec(inv.grandTotal).minus(inv.paidAmount))),
      currency_code: inv.currencyCode ?? "IQD",
      exchange_rate: inv.exchangeRate ? num(inv.exchangeRate) : null,
      notes: inv.notes,
      created_by: inv.creator.fullName,
    })),
    { total }
  );
});

const createSchema = z.object({
  supplier_id: z.number().int().positive("اختر المورد"),
  warehouse_id: z.number().int().positive("اختر المستودع"),
  type: z.enum(["CASH", "CREDIT"]),
  notes: z.string().trim().max(500).optional().nullable(),
  paid_amount: z.number().min(0).optional().nullable(),
  // v15 — Currency support
  currency_code: z.enum(["IQD", "USD"]).optional(),
  exchange_rate: z.number().positive().optional().nullable(),
  lines: z
    .array(
      z.object({
        product_id: z.number().int().positive(),
        qty: z.number().positive("كمية البند يجب أن تكون أكبر من صفر"),
        unit_cost: z.number().min(0).optional(),
        // v15 — Sale prices (optional, updates the product if provided)
        wholesale_sale_price: z.number().min(0).optional().nullable(), // سعر البيع جمله (للكرتونة)
        retail_sale_price: z.number().min(0).optional().nullable(),    // سعر البيع مفرد (للحبة)
      })
    )
    .min(1, "أضف بندًا واحدًا على الأقل"),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "purchasing.purchase_invoices.create");
  const body = await parseBody(req, createSchema);

  const result = await createPurchaseInvoice(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    {
      supplierId: body.supplier_id,
      warehouseId: body.warehouse_id,
      type: body.type,
      notes: body.notes ?? null,
      paidAmount: body.paid_amount ?? null,
      currencyCode: body.currency_code ?? "IQD",
      exchangeRate: body.exchange_rate ?? null,
      lines: body.lines.map((l) => ({
        productId: l.product_id,
        qty: l.qty,
        unitCost: l.unit_cost,
        wholesaleSalePrice: l.wholesale_sale_price ?? null,
        retailSalePrice: l.retail_sale_price ?? null,
      })),
    }
  );

  return ok(result, undefined, 201);
});
