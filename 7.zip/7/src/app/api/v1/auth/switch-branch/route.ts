import { z } from "zod";
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { signAccessToken, ACCESS_TOKEN_TTL_SEC } from "@/lib/jwt";
import { writeAudit } from "@/lib/audit";
import { ApiError, clientContext, handler, ok, parseBody } from "@/lib/api";
import { buildScopePayload } from "@/lib/session-payload";
import { resolveScope } from "@/lib/scope";

export const dynamic = "force-dynamic";

const switchSchema = z.object({
  branch_id: z.number().int().positive(),
});

/**
 * POST /api/v1/auth/switch-branch — Branch Switcher (Phase 15).
 * Validates the target branch against the granted set, re-issues the
 * access token with the new `brn` context and audits BRANCH_SWITCHED.
 * The refresh token stays valid.
 */
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req);
  const { ip, userAgent } = clientContext(req);
  const body = await parseBody(req, switchSchema);

  if (!session.branchIds.includes(body.branch_id)) {
    await writeAudit(
      { userId: session.userId, companyId: session.companyId, ipAddress: ip, userAgent },
      { action: "ACCESS_DENIED", module: "auth", entityType: "branch", entityId: body.branch_id,
        newValues: { reason: "Branch Scope Violation", stage: "switch", username: session.username } }
    );
    throw new ApiError("SCOPE_005", "لا تملك نفاذًا لهذا الفرع");
  }

  const branch = await db.branch.findFirst({
    where: { id: body.branch_id, deletedAt: null },
    select: { id: true, companyId: true, name: true },
  });
  if (!branch) throw new ApiError("VAL_003", "الفرع غير موجود");

  // Branch must belong to the active company context
  if (branch.companyId !== session.companyId) {
    await writeAudit(
      { userId: session.userId, companyId: session.companyId, ipAddress: ip, userAgent },
      { action: "ACCESS_DENIED", module: "auth", entityType: "branch", entityId: body.branch_id,
        newValues: { reason: "Company Scope Violation", stage: "switch", username: session.username } }
    );
    throw new ApiError("SCOPE_004", "الفرع يتبع شركة أخرى — بدّل الشركة أولًا");
  }

  const { token, expiresIn } = await signAccessToken({
    id: session.userId,
    companyId: session.companyId,
    username: session.username,
    activeBranchId: branch.id,
    scopeType: session.scopeType,
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: ip, userAgent },
    { action: "BRANCH_SWITCHED", module: "auth", entityType: "branch", entityId: branch.id,
      newValues: { from: session.activeBranchId, to: branch.id, branch_name: branch.name } }
  );

  // Re-resolve scope with the new active branch (warehouses follow branches)
  const scope = await resolveScope({
    id: session.userId,
    companyId: session.companyId,
    branchId: branch.id,
    scopeType: session.scopeType,
  });
  const scopePayload = await buildScopePayload({
    ...session,
    activeBranchId: branch.id,
    warehouseIds: scope.warehouseIds,
  });

  return ok({
    access_token: token,
    expires_in: ACCESS_TOKEN_TTL_SEC,
    active_branch_id: branch.id,
    scope: scopePayload,
  });
});
