import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, clientContext } from "@/lib/api";
import { signAccessToken } from "@/lib/jwt";
import { writeAudit } from "@/lib/audit";
import { resolveScope } from "@/lib/scope";
import { buildScopePayload } from "@/lib/session-payload";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/auth/refresh-scope — re-resolve the session scope from the
 * access tables and re-issue the access token. Used right after a new
 * company is provisioned (or grants change) so the company/branch
 * switchers reflect the new scope WITHOUT logging out and back in.
 */
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req);
  const { ip, userAgent } = clientContext(req);

  const scope = await resolveScope({
    id: session.userId,
    companyId: session.companyId,
    branchId: session.activeBranchId,
    scopeType: session.scopeType,
  });

  const { token, expiresIn } = await signAccessToken({
    id: session.userId,
    companyId: session.companyId,
    username: session.username,
    activeBranchId: session.activeBranchId,
    scopeType: session.scopeType,
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: ip, userAgent },
    { action: "SCOPE_REFRESHED", module: "auth", entityType: "user", entityId: session.userId,
      newValues: { companies: scope.companyIds.length, branches: scope.branchIds.length } }
  );

  const scopePayload = await buildScopePayload({
    ...session,
    companyIds: scope.companyIds,
    branchIds: scope.branchIds,
    warehouseIds: scope.warehouseIds,
  });

  return ok({
    access_token: token,
    expires_in: expiresIn,
    active_company_id: session.companyId,
    scope: scopePayload,
  });
});
