import { z } from "zod";
import { NextRequest } from "next/server";
import { checkRefreshToken, revokeAllForUser, revokeChain } from "@/lib/refresh";
import { writeAudit } from "@/lib/audit";
import { clientContext, handler, ok, parseBody } from "@/lib/api";

export const dynamic = "force-dynamic";

const logoutSchema = z.object({
  refresh_token: z.string().min(20).max(200).optional(),
  all: z.boolean().optional(),
});

/** POST /api/v1/auth/logout — revoke current chain or all sessions. */
export const POST = handler(async (req: NextRequest) => {
  const { ip, userAgent } = clientContext(req);
  const body = await parseBody(req, logoutSchema);

  if (body.all) {
    // logout-all requires identifying the user via a valid presented token.
    if (body.refresh_token) {
      const check = await checkRefreshToken(body.refresh_token);
      if (check.ok) {
        await revokeAllForUser(check.row.userId);
        await writeAudit(
          { userId: check.row.userId, ipAddress: ip, userAgent },
          { action: "LOGOUT_ALL", module: "auth", entityType: "user", entityId: check.row.userId }
        );
      }
    }
    return ok({ logged_out: "all" });
  }

  if (body.refresh_token) {
    const check = await checkRefreshToken(body.refresh_token);
    if (check.ok) {
      await revokeChain(check.row.uuid, check.row.userId);
      await writeAudit(
        { userId: check.row.userId, ipAddress: ip, userAgent },
        { action: "LOGOUT", module: "auth", entityType: "user", entityId: check.row.userId }
      );
    }
  }
  return ok({ logged_out: true });
});
