import { z } from "zod";
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { signAccessToken, ACCESS_TOKEN_TTL_SEC } from "@/lib/jwt";
import { checkRefreshToken, issueRefreshToken, markRotated } from "@/lib/refresh";
import { writeAudit } from "@/lib/audit";
import { ApiError, clientContext, handler, ok, parseBody } from "@/lib/api";
import { assertCompanyActive } from "@/lib/subscription";
import { normalizeScopeType } from "@/lib/scope";

export const dynamic = "force-dynamic";

const refreshSchema = z.object({
  refresh_token: z.string().min(20).max(200),
});

/** POST /api/v1/auth/refresh — rotate refresh token, mint new access token. */
export const POST = handler(async (req: NextRequest) => {
  const { ip, userAgent } = clientContext(req);
  const body = await parseBody(req, refreshSchema);

  const check = await checkRefreshToken(body.refresh_token);
  if (!check.ok) {
    // Attribute the event to the owner when the token row reveals them
    // (REUSED/EXPIRED) so it lands inside the company audit scope.
    if (check.reason !== "INVALID") {
      const owner = await db.user.findUnique({
        where: { id: check.userId },
        select: { companyId: true },
      });
      await writeAudit(
        { userId: check.userId, companyId: owner?.companyId ?? null, ipAddress: ip, userAgent },
        {
          action: "REFRESH_REJECTED",
          module: "auth",
          entityType: "refresh_token",
          entityId: undefined,
          newValues: { reason: check.reason, chain_uuid: check.uuid },
        }
      );
    } else {
      await writeAudit({ ipAddress: ip, userAgent }, {
        action: "REFRESH_REJECTED",
        module: "auth",
        entityType: "refresh_token",
        newValues: { reason: "INVALID" },
      });
    }
    // REUSED → the whole chain is revoked; user must re-login (AUTH_007 context)
    if (check.reason === "REUSED") {
      throw new ApiError("AUTH_006", "رمز تحديث مستهلك — أُلغيت السلسلة كلها لأسباب أمنية. سجّل الدخول من جديد");
    }
    if (check.reason === "EXPIRED") throw new ApiError("AUTH_007");
    throw new ApiError("AUTH_006");
  }

  const user = await db.user.findFirst({
    where: { id: check.row.userId, deletedAt: null, isActive: true },
  });
  if (!user) throw new ApiError("AUTH_005");

  // Subscription enforcement — الجلسات الطويلة تموت عند انتهاء/تعليق الشركة
  // حتى بدون إعادة دخول (المالكون GLOBAL bypass للإدارة والتجديد).
  if (normalizeScopeType(user.scopeType) !== "GLOBAL") {
    await assertCompanyActive(user.companyId);
  }

  // Rotate: new child token chained to the old one, old one revoked.
  // The session's active branch context rides along (Phase 14 — session scope).
  const fresh = await issueRefreshToken(user.id, check.row.uuid, ip, userAgent, check.row.activeBranchId);
  await markRotated(check.row.uuid, fresh.uuid);

  const { token, expiresIn } = await signAccessToken({
    id: user.id,
    companyId: user.companyId,
    username: user.username,
    activeBranchId: check.row.activeBranchId,
    scopeType: user.scopeType,
  });

  await writeAudit(
    { userId: user.id, companyId: user.companyId, ipAddress: ip, userAgent },
    { action: "REFRESH", module: "auth", entityType: "refresh_token", entityId: check.row.id, newValues: { rotated_to: fresh.uuid } }
  );

  return ok({
    access_token: token,
    refresh_token: fresh.token,
    expires_in: ACCESS_TOKEN_TTL_SEC,
  });
});
