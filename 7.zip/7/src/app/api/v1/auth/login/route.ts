import { z } from "zod";
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { verifyPassword } from "@/lib/password";
import { signAccessToken, ACCESS_TOKEN_TTL_SEC } from "@/lib/jwt";
import { issueRefreshToken } from "@/lib/refresh";
import { writeAudit } from "@/lib/audit";
import { ApiError, clientContext, handler, ok, parseBody } from "@/lib/api";
import { ERROR_CODES } from "@/lib/errors";
import { ensureSeeded } from "@/lib/seed";
import { normalizeScopeType, resolveScope } from "@/lib/scope";
import { buildScopePayload } from "@/lib/session-payload";
import { assertCompanyActive } from "@/lib/subscription";

export const dynamic = "force-dynamic";

const loginSchema = z.object({
  username: z.string().trim().min(3, "اسم الدخول قصير جدًا").max(80),
  password: z.string().min(8, "كلمة المرور قصيرة جدًا").max(128),
  // Multi-Branch login (Phase 14): pick the session branch/company up-front.
  branch_id: z.number().int().positive().optional(),
  company_id: z.number().int().positive().optional(),
});

// Lockout policy (settings-configurable; defaults per ERD)
const MAX_FAILED = 5;
const LOCKOUT_MIN = 15;

/** POST /api/v1/auth/login — issues access (15m) + rotating refresh (7d). */
export const POST = handler(async (req: NextRequest) => {
  const { ip, userAgent } = clientContext(req);
  const body = await parseBody(req, loginSchema);

  // Self-heal guard: if the DB was reset externally (empty users table),
  // re-seed before the lookup instead of rejecting valid credentials.
  await ensureSeeded();

  // ---- Multi-Tenant login (Phase 1 — Company Isolation Repair) -----------
  // نفس username قد يوجد كحساب منفصل في أكثر من شركة. findFirst(username)
  // ممنوع لأنه يلتقط أول صف عشوائياً (اختيار شركة خاطئ = اختراق عزل).
  // القرار: كلمة المرور (+ selected_company الاختياري) تحدد الحساب:
  //   • مرشّح واحد → سلوك سابق تلقائي (auto select)
  //   • عدة مرشحين → التحقق ضدهم جميعاً: تطابق واحد يكمل، وتطابق أكثر
  //     من شركة يُرجع requires_company_selection قبل إصدار أي توكن.
  const candidates = await db.user.findMany({
    where: { username: body.username, deletedAt: null },
    include: {
      roles: { include: { role: { include: { permissions: { include: { permission: true } } } } } },
    },
  });

  // Uniform rejection — never disclose which factor failed.
  if (candidates.length === 0) {
    await writeAudit({ ipAddress: ip, userAgent }, {
      action: "LOGIN_FAILED", module: "auth", entityType: "user",
      newValues: { username: body.username, reason: "UNKNOWN_USER" },
    });
    throw new ApiError("AUTH_003");
  }

  // عند تمرير selected_company نفضّل الحساب المقيم فيها فعلاً؛ إن لم يوجد
  // صف فيها نبقي كل المرشحين (حالة منح الوصول UserCompanyAccess — تُتحقق لاحقاً).
  const pool =
    body.company_id != null && candidates.some((u) => u.companyId === body.company_id)
      ? candidates.filter((u) => u.companyId === body.company_id)
      : candidates;

  const now = new Date();
  const active = pool.filter((u) => !u.lockedUntil || u.lockedUntil <= now);
  if (active.length === 0) {
    const maxMs = Math.max(...pool.map((u) => (u.lockedUntil?.getTime() ?? now.getTime()) - now.getTime()));
    const minutes = Math.max(1, Math.ceil(maxMs / 60000));
    throw new ApiError("AUTH_004", `${ERROR_CODES.AUTH_004.ar} — حاول بعد ${minutes} دقيقة`);
  }

  // Verify the password against every unlocked candidate — the set of
  // matching rows decides whether a company selection is required.
  // v14 — خروج مبكر بعد تطابقين: القرار يحتاج فقط «واحد» مقابل «أكثر من
  // واحد» — التحقق من مئات المرشحين (username مكرر عبر شركات كثيرة) كان
  // يشغّل argon2id مئات المرات بلا فائدة (ذاكرة ووقت هائلان على قواعد
  // الاختبار الضخمة — وثار زائد محتمل في الإنتاج متعدد الشركات).
  const verified: typeof candidates = [];
  for (const u of active) {
    if (await verifyPassword(body.password, u.passwordHash)) {
      verified.push(u);
      if (verified.length >= 2) break;
    }
  }

  if (verified.length === 0) {
    // Lockout counters bump on ALL candidates — multi-tenant username
    // spraying cannot evade the lockout policy by rotating company_id.
    for (const u of active) {
      const failedCount = u.failedLoginCount + 1;
      const lockNow = failedCount >= MAX_FAILED;
      await db.user.update({
        where: { id: u.id },
        data: {
          failedLoginCount: lockNow ? 0 : failedCount,
          lockedUntil: lockNow ? new Date(Date.now() + LOCKOUT_MIN * 60_000) : null,
        },
      });
    }

    await writeAudit(
      { userId: active[0].id, companyId: active[0].companyId, ipAddress: ip, userAgent },
      {
        action: active.some((u) => u.failedLoginCount + 1 >= MAX_FAILED) ? "LOCKOUT" : "LOGIN_FAILED",
        module: "auth",
        entityType: "user",
        entityId: active[0].id,
        newValues: { username: body.username, candidates: active.length, locked: active.some((u) => u.failedLoginCount + 1 >= MAX_FAILED) },
      }
    );

    throw new ApiError("AUTH_003", `${ERROR_CODES.AUTH_003.ar} — المحاولات المتبقية: ${MAX_FAILED - (active[0].failedLoginCount + 1)}`);
  }

  // اختيار الحساب: المطلوب company_id؟ اربطه بصفّ الشركة نفسها إن وجد.
  let user = verified[0];
  if (body.company_id != null) {
    const exact = verified.filter((v) => v.companyId === body.company_id);
    if (exact.length > 0) {
      user = exact[0];
    } else if (active.length > 1) {
      // عدة حسابات بنفس اسم المستخدم ولا واحد منها في الشركة المطلوبة —
      // إعادة اختيار الشركة قبل أي توكن.
      return companySelectionPayload(active, ip, userAgent);
    }
    // تطابق واحد فقط → مسار المنح (company_id ضمن scope.companyIds يُتحقق أدناه)
  } else if (active.length > 1) {
    // Phase 1 §1 strict: نفس username موجود في أكثر من شركة — اختيار الشركة
    // إلزامي قبل إصدار Access Token النهائي، حتى لو تطابقت كلمة المرور مع
    // حساب واحد (لا نكشف أي شركة تطابقت — القائمة تعرض كل شركات الاسم).
    return companySelectionPayload(active, ip, userAgent);
  }

  if (!user.isActive) throw new ApiError("AUTH_005");

  // ---- resolve scope (Phase 1) ------------------------------------------
  const scope = await resolveScope({
    id: user.id,
    companyId: user.companyId,
    branchId: user.branchId,
    scopeType: user.scopeType,
  });

  // ---- Company selection (Phase 16, GLOBAL multi-company) ----------------
  let activeCompanyId = user.companyId;
  if (body.company_id != null) {
    if (!scope.companyIds.includes(body.company_id)) {
      await writeAudit(
        { userId: user.id, companyId: user.companyId, ipAddress: ip, userAgent },
        { action: "ACCESS_DENIED", module: "auth", entityType: "company", entityId: body.company_id,
          newValues: { reason: "Company Scope Violation", stage: "login" } }
      );
      throw new ApiError("AUTH_008", "الشركة المطلوبة خارج نطاق المستخدم");
    }
    activeCompanyId = body.company_id;
  }

  // ---- Subscription enforcement (لوحة المالك — مدة كل شركة) --------------
  // مستخدمو شركة منتهية/معلّقة ممنوعون من الدخول — مالكو المنصة (GLOBAL)
  // bypass حتى يستطيعوا إدارة الشركات المنتهية وتجديدها.
  const isPlatformGlobal = normalizeScopeType(user.scopeType) === "GLOBAL";
  if (!isPlatformGlobal) {
    await assertCompanyActive(activeCompanyId);
  }

  // ---- Branch selection (Phase 14) ---------------------------------------
  let activeBranchId: number | null = null;
  const branchesOfCompany = await db.branch.findMany({
    where: { id: { in: scope.branchIds }, companyId: activeCompanyId, deletedAt: null },
    select: { id: true },
  });
  const selectableBranches = branchesOfCompany.map((b) => b.id);

  if (body.branch_id != null) {
    if (!selectableBranches.includes(body.branch_id)) {
      await writeAudit(
        { userId: user.id, companyId: activeCompanyId, ipAddress: ip, userAgent },
        { action: "ACCESS_DENIED", module: "auth", entityType: "branch", entityId: body.branch_id,
          newValues: { reason: "Branch Scope Violation", stage: "login", username: user.username } }
      );
      throw new ApiError("AUTH_008", "الفرع المطلوب خارج نطاق المستخدم");
    }
    activeBranchId = body.branch_id;
    await writeAudit(
      { userId: user.id, companyId: activeCompanyId, ipAddress: ip, userAgent },
      { action: "BRANCH_SELECTED", module: "auth", entityType: "branch", entityId: activeBranchId,
        newValues: { username: user.username, scope_type: normalizeScopeType(user.scopeType) } }
    );
  } else if (selectableBranches.length === 1) {
    // Single-branch user → auto-select (Phase 14 rule).
    activeBranchId = selectableBranches[0];
  } else if (selectableBranches.length > 1) {
    const st = normalizeScopeType(user.scopeType);
    if (st === "GLOBAL" || st === "COMPANY") {
      // Phase 36: GLOBAL/COMPANY managers see ALL allowed branches by
      // default (no narrowing) — the header switcher narrows on demand.
      activeBranchId = null;
    } else {
      // Multi-branch user without selection → hand back the picker, NO tokens.
      const payload = await scopeSelectionPayload(user, scope, activeCompanyId, ip, userAgent);
      return ok({
        requires_branch_selection: true,
        scope_type: payload.scope_type,
        companies: payload.companies,
        branches: payload.branches,
        active_company_id: activeCompanyId,
        user: { id: user.id, username: user.username, full_name: user.fullName, scope_type: payload.scope_type },
      });
    }
  }

  // ---- proceed with full session -----------------------------------------
  const session = await completeLogin(user, activeCompanyId, activeBranchId, ip, userAgent, body.password);
  return ok(session);
});

/** Build the company-selection payload (Phase 1 §1 — no tokens issued). */
async function companySelectionPayload(
  rows: { id: number; companyId: number; username: string; fullName: string }[],
  ip: string,
  _ua: string
) {
  const companies = await db.company.findMany({
    where: { id: { in: rows.map((v) => v.companyId) }, deletedAt: null },
    select: { id: true, code: true, name: true },
    orderBy: { id: "asc" },
  });
  await writeAudit(
    { userId: rows[0].id, companyId: rows[0].companyId, ipAddress: ip, userAgent: _ua },
    {
      action: "COMPANY_SELECTION_REQUIRED", module: "auth", entityType: "user",
      entityId: rows[0].id,
      newValues: { username: rows[0].username, companies: companies.map((c) => c.id) },
    }
  );
  return ok({
    requires_company_selection: true,
    companies: companies.map((c) => ({ id: c.id, code: c.code, name: c.name })),
    user: { username: rows[0].username, full_name: rows[0].fullName },
  });
}

/** Build the branch-selection payload (no tokens issued yet). */
async function scopeSelectionPayload(
  user: { id: number; companyId: number; branchId: number | null; scopeType: string; username: string; fullName: string },
  scope: Awaited<ReturnType<typeof resolveScope>>,
  activeCompanyId: number,
  _ip: string,
  _ua: string
) {
  const [branches, companies] = await Promise.all([
    db.branch.findMany({
      where: { id: { in: scope.branchIds }, companyId: activeCompanyId, isActive: true, deletedAt: null },
      select: { id: true, code: true, name: true, companyId: true },
      orderBy: { id: "asc" },
    }),
    db.company.findMany({
      where: { id: { in: scope.companyIds }, deletedAt: null },
      select: { id: true, code: true, name: true },
      orderBy: { id: "asc" },
    }),
  ]);
  void user;
  return {
    scope_type: normalizeScopeType(scope.scopeType),
    companies: companies.map((c) => ({ id: c.id, code: c.code, name: c.name })),
    branches: branches.map((b) => ({ id: b.id, code: b.code, name: b.name, company_id: b.companyId })),
  };
}

/** Issue tokens + stamps + audit for a fully-scoped login. */
async function completeLogin(
  user: { id: number; companyId: number; username: string; fullName: string; language: string; theme: string; uuid: string; scopeType: string },
  activeCompanyId: number,
  activeBranchId: number | null,
  ip: string,
  userAgent: string,
  _password: string
) {
  // Success — reset counters, stamp last login (Phase 3: IP + agent).
  await db.user.update({
    where: { id: user.id },
    data: {
      failedLoginCount: 0,
      lockedUntil: null,
      lastLoginAt: new Date(),
      lastLoginIp: ip,
      lastLoginAgent: userAgent.slice(0, 200),
    },
  });

  // Phase 1 §2 — Role Isolation: أدوار الشركة النشطة حصراً — استثناء مالك
  // المنصة (GLOBAL) لأن أدواره منصية وليست لكل شركة على حدة.
  const isPlatformGlobal = normalizeScopeType(user.scopeType) === "GLOBAL";
  const roles = await db.userRole.findMany({
    where: {
      userId: user.id,
      ...(isPlatformGlobal
        ? { role: { deletedAt: null } }
        : { companyId: activeCompanyId, role: { companyId: activeCompanyId, deletedAt: null } }),
    },
    include: { role: { include: { permissions: { include: { permission: true } } } } },
  });
  const permissions = new Set<string>();
  const roleList: { id: number; code: string; name: string }[] = [];
  for (const ur of roles) {
    roleList.push({ id: ur.role.id, code: ur.role.code, name: ur.role.name });
    for (const rp of ur.role.permissions) permissions.add(rp.permission.code);
  }

  const { token, expiresIn } = await signAccessToken({
    id: user.id,
    companyId: activeCompanyId,
    username: user.username,
    activeBranchId,
    scopeType: user.scopeType,
  });
  const refresh = await issueRefreshToken(user.id, null, ip, userAgent, activeBranchId);

  await writeAudit(
    { userId: user.id, companyId: activeCompanyId, ipAddress: ip, userAgent },
    { action: "LOGIN", module: "auth", entityType: "user", entityId: user.id,
      newValues: { username: user.username, active_branch_id: activeBranchId } }
  );

  // Scope payload (branches limited to the active company for the picker UX)
  const scope = await resolveScope({
    id: user.id,
    companyId: activeCompanyId,
    branchId: activeBranchId,
    scopeType: user.scopeType,
  });
  const scopePayload = await buildScopePayload({
    userId: user.id,
    companyId: activeCompanyId,
    username: user.username,
    fullName: user.fullName,
    permissions,
    roles: roleList.map((r) => ({ ...r, branchId: null })),
    warehouseIds: scope.warehouseIds,
    scopeType: scope.scopeType,
    companyIds: scope.companyIds,
    branchIds: scope.branchIds,
    activeBranchId,
  });

  return {
    access_token: token,
    refresh_token: refresh.token,
    expires_in: ACCESS_TOKEN_TTL_SEC,
    user: {
      id: user.id,
      uuid: user.uuid,
      username: user.username,
      full_name: user.fullName,
      company_id: activeCompanyId,
      branch_id: activeBranchId,
      scope_type: scopePayload.scope_type,
      language: user.language,
      theme: user.theme,
    },
    permissions: Array.from(permissions),
    roles: roleList,
    scope: scopePayload,
  };
}
