import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { buildScopePayload } from "@/lib/session-payload";
import { adminLevelOf } from "@/lib/scope";

export const dynamic = "force-dynamic";

/** GET /api/v1/auth/me — current session profile + permissions + full scope. */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req);

  const company = await db.company.findFirst({
    where: { id: session.companyId, deletedAt: null },
    select: { id: true, code: true, name: true, nameEn: true, phone: true, email: true, address: true, taxNumber: true, currencyCode: true, logoUrl: true },
  });

  const scope = await buildScopePayload(session);

  return ok({
    user: {
      id: session.userId,
      username: session.username,
      full_name: session.fullName,
      company_id: session.companyId,
      branch_id: session.activeBranchId,
      scope_type: session.scopeType,
      admin_level: adminLevelOf(session.scopeType),
    },
    roles: session.roles,
    permissions: Array.from(session.permissions).sort(),
    warehouses: scope.warehouses,
    company,
    // ---- Multi-Company / Multi-Branch scope (Phases 1, 14-16) ------------
    scope,
  });
});
