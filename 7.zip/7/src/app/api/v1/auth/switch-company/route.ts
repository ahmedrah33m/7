import { z } from "zod";
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { signAccessToken, ACCESS_TOKEN_TTL_SEC } from "@/lib/jwt";
import { writeAudit } from "@/lib/audit";
import { ApiError, clientContext, handler, ok, parseBody } from "@/lib/api";
import { buildScopePayload } from "@/lib/session-payload";
import { resolveScope } from "@/lib/scope";
import { assertCompanyActive } from "@/lib/subscription";
import { normalizeScopeType } from "@/lib/scope";

export const dynamic = "force-dynamic";

const switchSchema = z.object({
  company_id: z.number().int().positive(),
});

/**
 * POST /api/v1/auth/switch-company — Company Switcher (Phase 16).
 * Validates the target company against user_company_access, rebuilds the
 * whole scope (branches reset → the client must pick a branch of the new
 * company) and audits COMPANY_SWITCHED.
 */
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req);
  const { ip, userAgent } = clientContext(req);
  const body = await parseBody(req, switchSchema);

  if (!session.companyIds.includes(body.company_id)) {
    await writeAudit(
      { userId: session.userId, companyId: session.companyId, ipAddress: ip, userAgent },
      { action: "ACCESS_DENIED", module: "auth", entityType: "company", entityId: body.company_id,
        newValues: { reason: "Company Scope Violation", stage: "switch", username: session.username } }
    );
    throw new ApiError("SCOPE_004", "لا تملك نفاذًا لهذه الشركة");
  }

  const company = await db.company.findFirst({
    where: { id: body.company_id, deletedAt: null },
    select: { id: true, name: true },
  });
  if (!company) throw new ApiError("VAL_003", "الشركة غير موجودة");

  // Subscription enforcement — لا تبديل إلى شركة منتهية/معلّقة
  // (مالكو المنصة GLOBAL bypass للإدارة والتجديد).
  if (normalizeScopeType(session.scopeType) !== "GLOBAL") {
    await assertCompanyActive(company.id);
  }

  // Rebuild scope with the new home company (Phase 16: rebuild after switch).
  // resolveScope widens GLOBAL/COMPANY scopes across ALL granted companies —
  // narrow the branch/warehouse sets to the NEW active company (strict
  // per-company isolation) before returning the scope payload.
  const scope = await resolveScope({
    id: session.userId,
    companyId: company.id,
    branchId: null,
    scopeType: session.scopeType,
  });
  const [coBranches, coWarehouses] = await Promise.all([
    db.branch.findMany({ where: { companyId: company.id, deletedAt: null }, select: { id: true } }),
    db.warehouse.findMany({ where: { companyId: company.id, deletedAt: null }, select: { id: true } }),
  ]);
  const branchSet = new Set(coBranches.map((b) => b.id));
  const warehouseSet = new Set(coWarehouses.map((w) => w.id));
  const activeBranchIds = scope.branchIds.filter((id) => branchSet.has(id));
  const activeWarehouseIds = scope.warehouseIds.filter((id) => warehouseSet.has(id));

  const { token, expiresIn } = await signAccessToken({
    id: session.userId,
    companyId: company.id,
    username: session.username,
    activeBranchId: null, // company changed → branch context must be re-selected
    scopeType: session.scopeType,
  });

  await writeAudit(
    { userId: session.userId, companyId: company.id, ipAddress: ip, userAgent },
    { action: "COMPANY_SWITCHED", module: "auth", entityType: "company", entityId: company.id,
      newValues: { from: session.companyId, to: company.id, company_name: company.name } }
  );

  const scopePayload = await buildScopePayload({
    ...session,
    companyId: company.id,
    activeBranchId: null,
    companyIds: scope.companyIds,
    branchIds: activeBranchIds,
    warehouseIds: activeWarehouseIds,
  });

  return ok({
    access_token: token,
    expires_in: ACCESS_TOKEN_TTL_SEC,
    active_company_id: company.id,
    scope: scopePayload,
  });
});
