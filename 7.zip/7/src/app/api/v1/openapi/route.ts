import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/openapi — machine-readable OpenAPI 3.0 contract of the
 * implemented surface (Phase 9 hardening deliverable). Static contract:
 * the envelope {success, data, meta} and the error-code matrix match
 * docs/02_API spec. Public for tooling; no sensitive data included.
 */
const envelope = (dataSchema: object) => ({
  type: "object",
  properties: {
    success: { type: "boolean" },
    data: dataSchema,
    meta: { type: "object", nullable: true },
    code: { type: "string", nullable: true },
    message: { type: "string", nullable: true },
    errors: { type: "array", items: { type: "object" }, nullable: true },
  },
});

const err = () => ({ description: "Uniform error envelope (code matrix per API spec §2.5)" });

function op(summary: string, permission?: string, body?: object, params: string[] = []) {
  const responses: Record<string, unknown> = {
    200: { description: "ok", content: { "application/json": { schema: envelope({}) } } },
    401: err(), 403: err(), 409: err(), 422: err(), 429: err(),
  };
  const o: Record<string, unknown> = {
    summary,
    tags: ["sds"],
    security: permission ? [{ bearerAuth: [] }] : [],
    responses,
  };
  if (permission) (o as { description?: string }).description = `Required permission: ${permission}`;
  if (body) o.requestBody = { required: true, content: { "application/json": { schema: body } } };
  if (params.length) o.parameters = params.map((p) => ({ name: p, in: "query", schema: { type: "string" } }));
  return o;
}

const linesSchema = {
  type: "object",
  properties: {
    lines: {
      type: "array",
      items: {
        type: "object",
        properties: { product_id: { type: "integer" }, qty: { type: "number" }, unit_price: { type: "number" }, discount_pct: { type: "number" } },
      },
    },
  },
};

export function GET() {
  const spec = {
    openapi: "3.0.3",
    info: {
      title: "SDS — Sales & Distribution System API",
      version: "0.1.0",
      description:
        "نظام ميدان لمبيعات والتوزيع — المراحل 0–8: الأساس، البيانات الرئيسية، المخزون، البيع، الميدان، المشتريات، المالية، التقارير، بوابة B2B والمزامنة. الاستجابات الموحدة {success, data} وأكواد الأخطاء الموحدة.",
    },
    servers: [{ url: "/api/v1" }],
    components: {
      securitySchemes: { bearerAuth: { type: "http", scheme: "bearer", bearerFormat: "JWT" } },
    },
    paths: {
      "/health": { get: op("فحص صحة الخدمة + مؤشر الزرع") },
      "/auth/login": { post: op("دخول المستخدم", undefined, { type: "object", properties: { username: { type: "string" }, password: { type: "string" } } }) },
      "/auth/refresh": { post: op("تدوير رمز التحديث (دوراني + كشف إعادة استخدام)") },
      "/auth/logout": { post: op("خروج وإبطال السلسلة") },
      "/auth/me": { get: op("ملف الجلسة والصلاحيات والمستودعات") },
      "/admin/users": { get: op("قائمة المستخدمين", "system.users.view") },
      "/admin/roles": { get: op("الأدوار والصلاحيات", "system.roles.view") },
      "/admin/audit-logs": { get: op("سجل التدقيق", "audit.audit_logs.view") },
      "/products": { get: op("كتالوج المنتجات", "products.products.view"), post: op("إنشاء منتج", "products.products.create") },
      "/categories": { get: op("تصنيفات المنتجات", "products.products.view") },
      "/customers": { get: op("العملاء", "parties.customers.view"), post: op("إنشاء عميل", "parties.customers.create") },
      "/suppliers": { get: op("الموردون", "parties.suppliers.view"), post: op("إنشاء مورد", "parties.suppliers.create") },
      "/inventory/balances": { get: op("أرصدة المخزون", "inventory.stock.view") },
      "/inventory/movements": { get: op("حركات المخزون", "inventory.movements.view"), post: op("حركة يدوية (إدخال/تسوية)", "inventory.movements.create") },
      "/inventory/transfers": { get: op("التحويلات", "inventory.transfers.view"), post: op("تحويل بين مستودعين", "inventory.transfers.create") },
      "/inventory/transfers/{id}/receive": { post: op("استلام تحويل (مرة واحدة)", "inventory.transfers.create") },
      "/inventory/transfers/{id}/cancel": { post: op("إلغاء تحويل", "inventory.transfers.cancel") },
      "/sales/invoices": { get: op("فواتير البيع", "sales.invoices.view"), post: op("ترحيل فاتورة (ذرّي: مخزون+ذمة+ائتمان)", "sales.invoices.create", linesSchema) },
      "/sales/invoices/{id}": { get: op("تفاصيل فاتورة", "sales.invoices.view") },
      "/sales/returns": { get: op("مرتجعات البيع", "sales.returns.view"), post: op("مرتجع على فاتورة", "sales.returns.create", linesSchema) },
      "/purchases/invoices": { get: op("فواتير الشراء", "purchasing.purchase_invoices.view"), post: op("ترحيل شراء (إدخال مخزون + WAVG)", "purchasing.purchase_invoices.create", linesSchema) },
      "/finance/cashboxes": { get: op("صناديق النقدية", "finance.cashboxes.view") },
      "/finance/transactions": { get: op("دفتر النقدية", "finance.payments.view"), post: op("تحصيل/سداد/مصروف/افتتاحي", "finance.payments.create") },
      "/reports/{type}": { get: op("تقارير: sales-daily|top-products|aging|valuation|profit", "reports.reports.view", undefined, ["from", "to", "warehouse_id"]) },
      "/field/targets": { get: op("أهداف المندوبين + التحقيق الحي", "field.targets.view"), post: op("تعيين هدف شهري", "field.targets.create") },
      "/field/visits": { get: op("زيارات المندوبين (عزل المندوب)", "field.visits.view"), post: op("تخطيط زيارة", "field.visits.create") },
      "/field/visits/{id}/checkin": { post: op("تسجيل حضور مع GPS", "field.visits.edit") },
      "/field/visits/{id}/complete": { post: op("إتمام زيارة بنتيجة", "field.visits.edit") },
      "/field/visits/{id}/cancel": { post: op("إلغاء زيارة", "field.visits.cancel") },
      "/field/routes": { get: op("مسارات التوزيع", "field.routes.view"), post: op("إنشاء مسار بعملائه", "field.routes.create") },
      "/field/commissions": { get: op("العمولات (عزل المندوب)", "field.commissions.view") },
      "/field/commissions/{id}/approve": { post: op("اعتماد عمولة", "field.commissions.approve") },
      "/field/commissions/{id}/pay": { post: op("صرف عمولة معتمدة", "field.commissions.approve") },
      "/field/summary": { get: op("لوحة الميدان: أداء + عمولات", "field.visits.view") },
      "/sync/push": { post: op("دفن عمليات العمل دون اتصال (idempotent بـ op_uuid — SYNC_001)", "sales.invoices.create") },
      "/sync/pull": { get: op("تنزيل دلتا بالكيرسور (منتجات/عملاء/أرصدة)", "products.products.view", undefined, ["cursor", "entities", "limit"]) },
      "/b2b/auth": { post: op("دخول بوابة العميل (code + pin) — JWT عميل 12 ساعة") },
      "/b2b/catalog": { get: op("كتالوج بأسعار العميل نفسه", undefined) },
      "/b2b/orders": { post: op("تقديم طلب من البوابة", undefined, linesSchema) },
      "/b2b/statement": { get: op("كشف حساب العميل") },
      "/b2b/admin/orders": { get: op("طابور طلبات البوابة", "b2b.orders.view") },
      "/b2b/admin/orders/{id}/confirm": { post: op("اعتماد الطلب → فاتورة حقيقية", "b2b.orders.approve") },
      "/b2b/admin/orders/{id}/reject": { post: op("رفض طلب", "b2b.orders.reject") },
      // ---- Development pack 2 ------------------------------------------------
      "/search": { get: op("بحث شامل موحّد (منتجات/عملاء/فواتير/أوامر/موردون/B2B — حسب صلاحيات الجلسة)", undefined, undefined, ["q"]) },
      // v14 — أُزيل توثيق /customers/{id}/loyalty: نظام نقاط الولاء أُلغي بالكامل
      "/sales/invoices/{id}/qr": { get: op("QR الفوترة الإلكترونية (TLV/Base64 — نمط ZATCA Phase-1) + SVG للطباعة", "sales.invoices.view") },
      "/admin/backup": { get: op("نسخة احتياطية شاملة JSON لكل بيانات الشركة (بلا أسرار)", "system.settings.edit") },
      "/alerts": { get: op("مركز التنبيهات الذكي — يشمل تنبؤ نفاد المخزون بسرعة البيع 30 يومًا") },
    },
  };
  return NextResponse.json(spec, { headers: { "Cache-Control": "public, max-age=300" } });
}
