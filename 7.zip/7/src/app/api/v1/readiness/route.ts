import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { promises as fs } from "fs";
import { UPLOAD_DIR } from "@/lib/storage";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/readiness — RP4 §5: هل الخدمة قادرة على خدمة الطلبات؟
 * يفحص: قاعدة البيانات (استعلام فعلي) + قابلية الكتابة على تخزين الملفات.
 * Redis/تبعيات خارجية: تُضاف عند تفعيلها (لا Redis في النشر الحالي — موثق).
 */
export async function GET() {
  const checks: Record<string, string> = {};
  let ready = true;
  try {
    await db.$queryRaw`SELECT 1`;
    checks.database = "up";
  } catch {
    checks.database = "down";
    ready = false;
  }
  try {
    const probe = `${UPLOAD_DIR}/.readiness-${Date.now()}`;
    await fs.writeFile(probe, "ok");
    await fs.unlink(probe);
    checks.storage = "up";
  } catch {
    checks.storage = "down";
    ready = false;
  }
  return NextResponse.json(
    { success: ready, data: { status: ready ? "ready" : "not-ready", checks, time: new Date().toISOString() } },
    { status: ready ? 200 : 503 }
  );
}
