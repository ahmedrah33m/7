import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { db } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { SETTING_GROUPS, SETTING_KEY_INDEX } from "@/lib/settings-catalog";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/settings (system.settings.view) — §62: 14 منطقة إعداد
 * تعيد كل مجموعة بمفاتيحها: القيمة الفعلية من القاعدة أو الافتراضية.
 *
 * PUT /api/v1/settings (system.settings.edit) — تحديث دفعة مفاتيح
 * { updates: [{ key, value }] } — قيمة سكالار (string|number|boolean)،
 * upsert داخل معاملة واحدة + audit.
 */

const putSchema = z.object({
  updates: z
    .array(
      z.object({
        key: z.string().min(1).max(120),
        value: z.union([z.string().max(500), z.number(), z.boolean()]),
      })
    )
    .min(1)
    .max(100),
});

function groupValues(rows: { key: string; value: string }[]) {
  const dbMap = new Map(rows.map((r) => [r.key, r.value]));
  return SETTING_GROUPS.map((g) => ({
    group: g.nameAr,
    prefix: g.key,
    settings: g.keys.map((k) => {
      const raw = dbMap.get(k.key);
      let value: unknown = k.value;
      if (raw != null) {
        try {
          value = JSON.parse(raw);
        } catch {
          value = raw;
        }
      }
      return { key: k.key, value, default: k.value, desc: k.descAr, custom: raw != null };
    }),
  }));
}

export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.settings.view");
  const rows = await db.setting.findMany({ where: { companyId: session.companyId } });
  return ok({ groups: groupValues(rows) });
});

export const PUT = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.settings.edit");
  const body = await parseBody(req, putSchema);

  // كل مفتاح يجب أن يقع ضمن البادئات المعروفة (مناطق §62 الأربعة عشر)
  for (const u of body.updates) {
    if (!SETTING_KEY_INDEX.has(u.key)) {
      throw new ApiError("VAL_001", `مفتاح إعداد غير معروف: ${u.key}`, [
        { field: "key", message: "استخدم أحد مفاتيح المناطق الـ14 من GET /settings" },
      ]);
    }
  }

  await db.$transaction(async (tx) => {
    for (const u of body.updates) {
      const value = JSON.stringify(u.value);
      await tx.setting.upsert({
        where: { companyId_key: { companyId: session.companyId, key: u.key } },
        create: { companyId: session.companyId, key: u.key, value, updatedBy: session.userId },
        update: { value, updatedBy: session.userId },
      });
    }
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for") ?? undefined, userAgent: req.headers.get("user-agent") ?? undefined },
    { action: "UPDATE", module: "system", entityType: "settings", entityId: 0, newValues: { keys: body.updates.map((u) => u.key) } }
  );

  const rows = await db.setting.findMany({ where: { companyId: session.companyId } });
  return ok({ updated: body.updates.length, groups: groupValues(rows) });
});
