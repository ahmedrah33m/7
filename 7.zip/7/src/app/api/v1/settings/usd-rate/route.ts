import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { getCompanyUsdRate, setCompanyUsdRate } from "@/lib/currency";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/settings/usd-rate — سعر صرف الشركة المعتمد (د.ع لكل $1).
 * يعيد rate=null حين لم يُضبط بعد — الواجهة تطلب من المستخدم تحديده
 * بدل تخمين رقم قديم (منع فئة أخطاء «26/1300 = $0.02»).
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "products.products.view");
  const rate = await getCompanyUsdRate(session.companyId);
  return ok({ rate });
});

const putSchema = z.object({ rate: z.number().positive().max(1_000_000) });

/** PUT /api/v1/settings/usd-rate — حفظ سعر الصرف المعتمد للشركة. */
export const PUT = handler(async (req: NextRequest) => {
  const session = await guard(req, "products.products.edit");
  const body = await parseBody(req, putSchema);
  const rate = await setCompanyUsdRate(session.companyId, body.rate, session.userId);
  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    { action: "UPDATE", module: "settings", entityType: "usd_rate", entityId: 0, newValues: { rate } }
  );
  return ok({ rate });
});
