import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { normalizeCostMethod } from "@/lib/cost-engine";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/settings/costing-method — طريقة التكلفة المعتمدة للشركة
 * (Phase 4: FIFO | WEIGHTED_AVERAGE | STANDARD_COST | LAST_COST —
 * القيمة القديمة WAVG تُعرض كمرادفها WEIGHTED_AVERAGE).
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "products.products.view");
  const company = await db.company.findUnique({
    where: { id: session.companyId },
    select: { costingMethod: true },
  });
  return ok({ costing_method: normalizeCostMethod(company?.costingMethod ?? "WAVG") });
});

const putSchema = z.object({
  costing_method: z.enum(["FIFO", "WEIGHTED_AVERAGE", "STANDARD_COST", "LAST_COST", "WAVG"]),
});

/** PUT /api/v1/settings/costing-method — تغيير طريقة التكلفة للشركة.
 *  الفواتير القديمة محمية بلقطة COGS (§6) — التغيير يطبق على الترحيلات الجديدة فقط. */
export const PUT = handler(async (req: NextRequest) => {
  const session = await guard(req, "products.products.edit");
  const body = await parseBody(req, putSchema);
  const method = normalizeCostMethod(body.costing_method);

  const company = await db.company.findUnique({
    where: { id: session.companyId },
    select: { costingMethod: true },
  });
  if (!company) throw new ApiError("VAL_003", "الشركة غير موجودة");

  const updated = await db.company.update({
    where: { id: session.companyId },
    data: { costingMethod: method },
    select: { costingMethod: true },
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    {
      action: "UPDATE",
      module: "settings",
      entityType: "costing_method",
      entityId: 0,
      oldValues: { method: company.costingMethod },
      newValues: { method: updated.costingMethod },
    }
  );

  return ok({ costing_method: normalizeCostMethod(updated.costingMethod) });
});
