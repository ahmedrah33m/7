import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { repPerformance, setTarget, resolveRepId } from "@/lib/field-service";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/field/targets — targets + live achievement (field.targets.view)
 * POST /api/v1/field/targets — set/update monthly target (field.targets.create)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "field.targets.view");
  const url = new URL(req.url);
  const period = url.searchParams.get("period") ?? currentPeriod();

  // Rep isolation: a rep sees only himself (resolveRepId pins self for reps).
  const repId = await resolveRepId(session, null).catch(() => undefined);
  const rows = await repPerformance(session.companyId, period, repId);
  return ok(rows, { period });
});

const setSchema = z.object({
  rep_id: z.number().int().positive("حدد المندوب"),
  period: z.string().regex(/^\d{4}-\d{2}$/, "الفترة بصيغة YYYY-MM"),
  target_amount: z.number().positive("قيمة الهدف أكبر من صفر"),
  notes: z.string().trim().max(300).optional().nullable(),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "field.targets.create");
  const body = await parseBody(req, setSchema);
  const row = await setTarget(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    {
      repId: body.rep_id,
      period: body.period,
      targetAmount: body.target_amount,
      notes: body.notes ?? null,
    }
  );
  return ok({ id: row.id, rep_id: row.repId, period: row.period, target_amount: row.targetAmount }, undefined, 201);
});

function currentPeriod(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}
