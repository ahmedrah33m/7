import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { z } from "zod";
import { decideCommission } from "@/lib/field-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/field/commissions/[id]/pay — (field.commissions.approve).
 * APPROVED → PAID. Paying a PENDING commission → VAL_004.
 */
const schema = z.object({}).optional();

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "field.commissions.approve");
  const { id } = await ctx.params;
  const commissionId = Number(id);
  if (!Number.isInteger(commissionId)) throw new ApiError("VAL_003", "معرّف عمولة غير صالح");
  await parseBody(req, schema).catch(() => ({}));

  const updated = await decideCommission(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    commissionId,
    "pay"
  );
  return ok({ id: updated.id, status: updated.status, paid_at: updated.paidAt });
});
