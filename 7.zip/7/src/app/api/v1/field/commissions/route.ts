import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { listCommissions, resolveRepId, isSalesRep } from "@/lib/field-service";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/field/commissions — (field.commissions.view).
 * Rep → own commissions only; managers/accountants → all (filterable).
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "field.commissions.view");
  const url = new URL(req.url);
  const status = url.searchParams.get("status") ?? undefined;
  const period = url.searchParams.get("period") ?? undefined;
  const repParam = url.searchParams.get("rep_id") ? Number(url.searchParams.get("rep_id")) : undefined;

  const rep = await isSalesRep(session.userId);
  const repId = rep ? session.userId : repParam;

  const rows = await listCommissions(session.companyId, { repId, status, period });
  return ok(
    rows.map((c) => ({
      id: c.id,
      rule: c.rule.name,
      rule_type: c.ruleType,
      rep: { id: c.rep.id, name: c.rep.fullName, username: c.rep.username },
      invoice: { id: c.invoice.id, number: c.invoice.number, grand_total: c.invoice.grandTotal, date: c.invoice.invoiceDate },
      period: c.period,
      base_amount: c.baseAmount,
      total_qty: c.totalQty,
      amount: c.amount,
      status: c.status,
      approved_at: c.approvedAt,
      paid_at: c.paidAt,
      created_at: c.createdAt,
    }))
  );
});

// silence unused-import lint when rep isolation is resolved via isSalesRep only
void resolveRepId;
