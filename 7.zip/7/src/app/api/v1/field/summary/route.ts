import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { dec, moneyR, num, sumOf } from "@/lib/decimal";
import { repPerformance, resolveRepId, listCommissions } from "@/lib/field-service";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/field/summary — field dashboard (field.visits.view OR
 * field.targets.view): rep performance for the period + commission totals.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req); // permission gate per-row below
  if (!session.permissions.has("field.targets.view") && !session.permissions.has("field.visits.view") && !session.permissions.has("field.commissions.view")) {
    void session;
    return ok({ reps: [], commissions: [], period: currentPeriod() });
  }

  const url = new URL(req.url);
  const period = url.searchParams.get("period") ?? currentPeriod();

  // Rep isolation — rep performance endpoint returns only self for reps.
  const repId = await resolveRepId(session, null).catch(() => undefined);
  const [reps, commissions] = await Promise.all([
    repPerformance(session.companyId, period, repId).catch(() => []),
    listCommissions(session.companyId, { repId: repId ?? undefined, period }).catch(() => []),
  ]);

  const totals = {
    sales: num(sumOf(reps, (r) => r.sales)),
    visits: reps.reduce((s, r) => s + r.visitsThisMonth, 0),
    commissions_pending: num(moneyR(sumOf(commissions.filter((c) => c.status === "PENDING"), (c) => c.amount))),
    commissions_approved: num(moneyR(sumOf(commissions.filter((c) => c.status === "APPROVED"), (c) => c.amount))),
    commissions_paid: num(moneyR(sumOf(commissions.filter((c) => c.status === "PAID"), (c) => c.amount))),
  };

  return ok({ period, totals, reps, commissions: commissions.slice(0, 25) });
});

function currentPeriod(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}
