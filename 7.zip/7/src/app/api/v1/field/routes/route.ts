import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { createRoute, listRoutes } from "@/lib/field-service";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/field/routes — routes + ordered customers (field.routes.view)
 * POST /api/v1/field/routes — create route (field.routes.create)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "field.routes.view");
  const rows = await listRoutes(session.companyId);
  return ok(
    rows.map((r) => ({
      id: r.id,
      code: r.code,
      name: r.name,
      day_of_week: r.dayOfWeek,
      rep: r.rep,
      customers: r.customers.map((rc) => ({ seq: rc.seq, id: rc.customer.id, code: rc.customer.code, name: rc.customer.name, balance: rc.customer.balance })),
      visits_count: r._count.visits,
      is_active: r.isActive,
    }))
  );
});

const createSchema = z.object({
  name: z.string().trim().min(2, "اسم المسار مطلوب").max(120),
  rep_id: z.number().int().positive().optional().nullable(),
  day_of_week: z.number().int().min(0).max(6).optional().nullable(),
  customer_ids: z.array(z.number().int().positive()).max(50).optional(),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "field.routes.create");
  const body = await parseBody(req, createSchema);
  const route = await createRoute(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    {
      name: body.name,
      repId: body.rep_id ?? null,
      dayOfWeek: body.day_of_week ?? null,
      customerIds: body.customer_ids ?? [],
    }
  );
  return ok({ id: route.id, code: route.code, name: route.name }, undefined, 201);
});
