import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { z } from "zod";
import { cancelVisit } from "@/lib/field-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/field/visits/[id]/cancel — (field.visits.cancel).
 * COMPLETED/CANCELLED visits cannot be cancelled → VAL_004.
 */
const cancelSchema = z.object({ reason: z.string().trim().max(300).optional().nullable() });

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "field.visits.cancel");
  const { id } = await ctx.params;
  const visitId = Number(id);
  if (!Number.isInteger(visitId)) throw new ApiError("VAL_003", "معرّف زيارة غير صالح");
  const body = await parseBody(req, cancelSchema).catch(() => ({ reason: null }));

  const updated = await cancelVisit(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    visitId,
    body.reason ?? null
  );
  return ok({ id: updated.id, status: updated.status });
});
