import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { completeVisit, VISIT_OUTCOMES } from "@/lib/field-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/field/visits/[id]/complete — (field.visits.edit).
 * CHECKED_IN → COMPLETED with outcome. Without check-in → VAL_004.
 */
const completeSchema = z.object({
  outcome: z.enum(["ORDERED", "NO_ORDER", "COLLECTION", "POSTPONED"], { message: "نتيجة الزيارة غير صالحة" }),
  order_value: z.number().min(0).optional(),
  notes: z.string().trim().max(300).optional().nullable(),
});
void VISIT_OUTCOMES;

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "field.visits.edit");
  const { id } = await ctx.params;
  const visitId = Number(id);
  if (!Number.isInteger(visitId)) throw new ApiError("VAL_003", "معرّف زيارة غير صالح");
  const body = await parseBody(req, completeSchema);

  const updated = await completeVisit(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    visitId,
    { outcome: body.outcome, orderValue: body.order_value ?? 0, notes: body.notes ?? null }
  );
  return ok({ id: updated.id, status: updated.status, outcome: updated.outcome, order_value: updated.orderValue });
});
