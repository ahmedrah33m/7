import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { checkinVisit } from "@/lib/field-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/field/visits/[id]/checkin — GPS check-in (field.visits.edit).
 * PLANNED → CHECKED_IN. Second check-in → VAL_004.
 */
const checkinSchema = z.object({
  lat: z.number().min(-90).max(90, "خط العرض بين -90 و 90"),
  lng: z.number().min(-180).max(180, "خط الطول بين -180 و 180"),
});

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "field.visits.edit");
  const { id } = await ctx.params;
  const visitId = Number(id);
  if (!Number.isInteger(visitId)) throw new ApiError("VAL_003", "معرّف زيارة غير صالح");
  const body = await parseBody(req, checkinSchema);

  const updated = await checkinVisit(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    visitId,
    { lat: body.lat, lng: body.lng }
  );
  return ok({ id: updated.id, status: updated.status, checkin_at: updated.checkinAt, gps: { lat: updated.checkinLat, lng: updated.checkinLng } });
});
