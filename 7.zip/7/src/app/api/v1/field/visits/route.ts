import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { listVisits, planVisit } from "@/lib/field-service";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/field/visits — list (field.visits.view; rep → own only)
 * POST /api/v1/field/visits — plan a visit (field.visits.create)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "field.visits.view");
  const url = new URL(req.url);
  const status = url.searchParams.get("status") ?? undefined;
  const repId = url.searchParams.get("rep_id") ? Number(url.searchParams.get("rep_id")) : undefined;

  const rows = await listVisits(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
    },
    { status, repId }
  );

  return ok(
    rows.map((v) => ({
      id: v.id,
      status: v.status,
      planned_date: v.plannedDate,
      customer: v.customer,
      rep: v.rep,
      route: v.route,
      checkin_at: v.checkinAt,
      gps: v.checkinLat != null ? { lat: v.checkinLat, lng: v.checkinLng } : null,
      checkout_at: v.checkoutAt,
      outcome: v.outcome,
      order_value: v.orderValue,
      notes: v.notes,
    }))
  );
});

const planSchema = z.object({
  customer_id: z.number().int().positive("اختر العميل"),
  planned_date: z.string().min(8, "حدد تاريخ الزيارة"),
  rep_id: z.number().int().positive().optional().nullable(),
  route_id: z.number().int().positive().optional().nullable(),
  notes: z.string().trim().max(300).optional().nullable(),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "field.visits.create");
  const body = await parseBody(req, planSchema);
  const visit = await planVisit(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    {
      customerId: body.customer_id,
      plannedDate: body.planned_date,
      repId: body.rep_id ?? null,
      routeId: body.route_id ?? null,
      notes: body.notes ?? null,
    }
  );
  return ok(
    { id: visit.id, status: visit.status, planned_date: visit.plannedDate, customer: visit.customer, rep: visit.rep },
    undefined,
    201
  );
});
