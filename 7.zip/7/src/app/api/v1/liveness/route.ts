import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/** GET /api/v1/liveness — RP4 §5: هل العملية حية؟ بلا فحوص تابعة (لإعادة التشغيل التلقائي). */
export async function GET() {
  return NextResponse.json({ success: true, data: { status: "alive", time: new Date().toISOString() } });
}
