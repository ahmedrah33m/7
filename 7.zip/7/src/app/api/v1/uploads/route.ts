import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, ApiError, clientContext } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { saveUpload, MAX_UPLOAD_BYTES } from "@/lib/storage";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/uploads (system.files.create) — multipart file upload.
 * Fields: file (required). Returns { name, url, mime, size } where url
 * is served publicly (unguessable UUID name) via /api/v1/files/<name>.
 * Typical use: product images → PATCH /products/[id] { image_url }.
 */
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.files.create");
  const ct = req.headers.get("content-type") ?? "";
  if (!ct.includes("multipart/form-data")) {
    throw new ApiError("VAL_001", "الطلب يجب أن يكون multipart/form-data مع حقل file");
  }
  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) {
    throw new ApiError("VAL_001", "أرفق الملف في الحقل file", [
      { field: "file", message: "الملف مطلوب" },
    ]);
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    throw new ApiError("VAL_001", "حجم الملف يتجاوز 5 ميجابايت");
  }
  const buf = Buffer.from(await file.arrayBuffer());
  let stored;
  try {
    stored = await saveUpload(buf, file.type || "application/octet-stream");
  } catch (e) {
    throw new ApiError("VAL_001", (e as Error).message);
  }

  // RP5 §9/§10 — سجل ملكية الملف: كل رفع جديد يُقيّد بشركته (لا ملفات مجهولة جديدة)
  await db.fileObject.create({
    data: { companyId: session.companyId, name: stored.name, mime: stored.mime, size: stored.size, createdBy: session.userId },
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: clientContext(req).ip, userAgent: clientContext(req).userAgent },
    { action: "UPLOAD", module: "system", entityType: "file", entityId: null, newValues: { name: stored.name, mime: stored.mime, size: stored.size } }
  );

  return ok({ name: stored.name, url: stored.url, mime: stored.mime, size: stored.size });
});
