import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { ensureWalkInCustomer } from "@/lib/walkin";
import { customerTypeLabels } from "@/lib/session-payload";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/customers/default-walkin — the shared walk-in record for POS
 * (Phase 20/46): fast "زبون نقدي" selection without opening Customers.
 * Also returns the configurable customer-type labels (Phase 19).
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "parties.customers.view");
  const walkin = await ensureWalkInCustomer(session.companyId);
  const labels = await customerTypeLabels(session.companyId);
  return ok({ ...walkin, customer_type: "WALK_IN", labels });
});
