import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/customers/import (parties.customers.import)
 * Bulk CSV import — one row per line:
 *   name, phone, address, credit_limit, credit_days
 * Header line optional. Duplicate = same name AND (same phone or no phone).
 */
const bodySchema = z.object({
  csv: z.string().min(1, "الصق محتوى CSV").max(300_000),
});

type ParsedRow = {
  name: string; phone: string | null; address: string | null;
  creditLimit: number; creditDays: number;
};

function parseCsv(csv: string): { rows: ParsedRow[]; errors: { line: number; message: string }[] } {
  const errors: { line: number; message: string }[] = [];
  const rows: ParsedRow[] = [];
  const lines = csv.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);

  lines.forEach((raw, idx) => {
    const lineNo = idx + 1;
    if (idx === 0 && /^name\s*,/i.test(raw)) return; // header
    const cells = raw.split(",").map((c) => c.trim());
    const name = cells[0];
    if (!name || name.length < 2) {
      errors.push({ line: lineNo, message: "الاسم مفقود أو قصير جدًا" });
      return;
    }
    const creditLimit = Number(cells[3] ?? 0);
    const creditDays = Number(cells[4] ?? 0);
    rows.push({
      name,
      phone: cells[1] || null,
      address: cells[2] || null,
      creditLimit: isFinite(creditLimit) && creditLimit >= 0 ? creditLimit : 0,
      creditDays: isFinite(creditDays) && creditDays >= 0 ? Math.min(365, Math.round(creditDays)) : 0,
    });
  });

  return { rows, errors };
}

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "parties.customers.import");
  const body = await parseBody(req, bodySchema);

  const { rows, errors } = parseCsv(body.csv);
  let created = 0;
  let skipped = 0;
  const skippedNames: string[] = [];

  const existing = await db.customer.findMany({
    where: { companyId: session.companyId, deletedAt: null },
    select: { id: true, name: true, phone: true },
  });
  const keyOf = (name: string, phone: string | null) => `${name}|${(phone ?? "").trim()}`;
  const existingSet = new Set(existing.map((c) => keyOf(c.name, c.phone)));

  const maxAgg = await db.customer.aggregate({ where: { companyId: session.companyId }, _max: { id: true } });
  let nextCode = (maxAgg._max.id ?? 0) + 1;

  for (const r of rows) {
    const key = keyOf(r.name, r.phone);
    if (existingSet.has(key)) {
      skipped += 1;
      skippedNames.push(r.name);
      continue;
    }
    const code = `C-${String(nextCode).padStart(5, "0")}`;
    nextCode += 1;
    await db.customer.create({
      data: {
        companyId: session.companyId,
        code,
        name: r.name,
        phone: r.phone,
        address: r.address,
        creditLimit: r.creditLimit,
        creditDays: r.creditDays,
        createdBy: session.userId,
      },
    });
    existingSet.add(key);
    created += 1;
  }

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    { action: "IMPORT", module: "parties", entityType: "customer", entityId: 0, newValues: { created, skipped, errors: errors.length } }
  );

  return ok({ created, skipped, skipped_names: skippedNames.slice(0, 10), errors });
});
