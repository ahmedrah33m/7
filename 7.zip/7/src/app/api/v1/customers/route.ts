import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { effectiveBranchIds, resolveCreateBranch } from "@/lib/scope";
import { assertManualCustomerTypeAllowed, ensureWalkInCustomer, isWalkInType } from "@/lib/walkin";

export const dynamic = "force-dynamic";

const CUSTOMER_TYPES = ["REGISTERED", "WALK_IN", "CASH_CUSTOMER", "GUEST"] as const;

/**
 * GET  /api/v1/customers — list (permission: parties.customers.view)
 *      ?q=search · ?type=REGISTERED|WALK_IN|... · ?page= · ?per_page=
 *      Branch-scoped for branch/warehouse/rep sessions (Phase 5).
 * POST /api/v1/customers — create (permission: parties.customers.create)
 *      Manual creation is always REGISTERED — walk-in types are
 *      system-managed (Phase 33/52).
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "parties.customers.view");
  const url = new URL(req.url);
  const q = url.searchParams.get("q")?.trim() ?? "";
  const type = url.searchParams.get("type")?.trim().toUpperCase() ?? "";
  const page = Math.max(1, Number(url.searchParams.get("page") ?? 1));
  const perPage = Math.min(100, Math.max(1, Number(url.searchParams.get("per_page") ?? 50)));

  const eff = effectiveBranchIds(session);
  const where = {
    companyId: session.companyId,
    deletedAt: null,
    // Branch scope (Phase 5): own-branch customers + company-wide records
    // (the shared walk-in "زبون نقدي" has no branch on purpose)
    ...(session.scopeType === "GLOBAL" || session.scopeType === "COMPANY"
      ? {}
      : { OR: [{ branchId: { in: eff } }, { branchId: null }] }),
    // التسلسل الهرمي §6: موظف بنطاق SELF يرى عملاءه الذين أضافهم هو فقط
    ...(session.scopeType === "SELF" ? { createdBy: session.userId } : {}),
    ...(q ? { OR: [{ name: { contains: q } }, { code: { contains: q } }, { phone: { contains: q } }] } : {}),
    ...(CUSTOMER_TYPES as readonly string[]).includes(type) ? { customerType: type } : {},
  };

  const [rows, total, walkin] = await Promise.all([
    db.customer.findMany({
      where,
      orderBy: { id: "asc" },
      skip: (page - 1) * perPage,
      take: perPage,
    }),
    db.customer.count({ where }),
    ensureWalkInCustomer(session.companyId),
  ]);

  return ok(
    rows.map((c) => ({
      id: c.id,
      code: c.code,
      name: c.name,
      phone: c.phone,
      whatsapp: c.whatsapp,
      address: c.address,
      customer_type: c.customerType,
      is_walkin: isWalkInType(c.customerType),
      converted_from_walk_in: c.convertedFromWalkIn,
      branch_id: c.branchId,
      credit_limit: c.creditLimit,
      credit_days: c.creditDays,
      balance: c.balance,
      status: c.status,
      is_active: c.isActive,
    })),
    { total, page, per_page: perPage, default_walkin: walkin }
  );
});

const createSchema = z.object({
  name: z.string().trim().min(2, "اسم العميل قصير جدًا").max(200),
  code: z.string().trim().max(40).optional(),
  phone: z.string().trim().max(30).optional(),
  address: z.string().trim().max(300).optional(),
  shop_name: z.string().trim().max(200).optional(),
  whatsapp: z.string().trim().max(40).optional(),
  area: z.string().trim().max(120).optional(),
  credit_limit: z.number().min(0).default(0),
  credit_days: z.number().int().min(0).max(365).default(0),
  branch_id: z.number().int().positive().optional().nullable(),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "parties.customers.create");
  const body = await parseBody(req, createSchema);

  // Phase 33/52: walk-in-like types are system-managed, never manual.
  assertManualCustomerTypeAllowed("REGISTERED");

  // Branch assignment: explicit (within context) → active branch → single branch
  const branchId = resolveCreateBranch(session, body.branch_id ?? null);

  // Auto code: C-00001 style.
  let code = body.code?.trim();
  if (!code) {
    const max = await db.customer.aggregate({
      where: { companyId: session.companyId },
      _max: { id: true },
    });
    code = `C-${String((max._max.id ?? 0) + 1).padStart(5, "0")}`;
  } else {
    const dup = await db.customer.findFirst({
      where: { companyId: session.companyId, code, deletedAt: null },
    });
    if (dup) throw new ApiError("VAL_002", "كود العميل مستخدم مسبقًا");
  }

  const customer = await db.customer.create({
    data: {
      companyId: session.companyId,
      branchId,
      code,
      name: body.name,
      phone: body.phone || null,
      address: body.address || null,
      shopName: body.shop_name || null,
      whatsapp: body.whatsapp || null,
      area: body.area || null,
      customerType: "REGISTERED",
      creditLimit: body.credit_limit,
      creditDays: body.credit_days,
      createdBy: session.userId,
    },
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    { action: "CREATE", module: "parties", entityType: "customer", entityId: customer.id, newValues: { code: customer.code, name: customer.name, credit_limit: customer.creditLimit, branch_id: branchId } }
  );

  return ok(
    {
      id: customer.id,
      code: customer.code,
      name: customer.name,
      customer_type: customer.customerType,
      credit_limit: customer.creditLimit,
      balance: customer.balance,
    },
    undefined,
    201
  );
});
