import { z } from "zod";
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { ensureWalkInCustomer, isWalkInType } from "@/lib/walkin";

export const dynamic = "force-dynamic";

const convertSchema = z.object({
  name: z.string().trim().min(2, "الاسم إلزامي لتحويل الزبون المتردد").max(200),
  phone: z.string().trim().max(30).optional().nullable(),
  whatsapp: z.string().trim().max(40).optional().nullable(),
  address: z.string().trim().max(300).optional().nullable(),
  shop_name: z.string().trim().max(200).optional().nullable(),
  area: z.string().trim().max(120).optional().nullable(),
  credit_limit: z.number().min(0).default(0),
  credit_days: z.number().int().min(0).max(365).default(0),
});

/**
 * POST /api/v1/customers/[id]/convert — Convert Walk-In → Registered
 * (Phase 22): the SAME record becomes REGISTERED so its invoice history,
 * returns and audit stay intact (§52 — never delete history), flagged
 * with converted_from_walk_in + converted_at. If the converted record is
 * the shared default walk-in, a fresh shared record is created so POS
 * keeps a "زبون نقدي" available.
 */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "parties.customers.edit");
  const { id } = await ctx.params;
  const customerId = Number(id);
  if (!Number.isInteger(customerId)) throw new ApiError("VAL_003", "معرّف عميل غير صالح");

  const body = await parseBody(req, convertSchema);

  const customer = await db.customer.findFirst({
    where: { id: customerId, companyId: session.companyId, deletedAt: null },
  });
  if (!customer) throw new ApiError("VAL_003", "العميل غير موجود");
  if (!isWalkInType(customer.customerType)) {
    throw new ApiError("WALK_003", "التحويل متاح فقط للزبون المتردد/النقدي/غير المعروف");
  }
  if (customer.customerType === "REGISTERED") throw new ApiError("WALK_003");

  const wasSharedDefault = customer.code.startsWith("CASH-");

  const updated = await db.$transaction(async (tx) => {
    const row = await tx.customer.update({
      where: { id: customer.id },
      data: {
        name: body.name,
        phone: body.phone || customer.phone,
        whatsapp: body.whatsapp || customer.whatsapp,
        address: body.address || customer.address,
        shopName: body.shop_name || customer.shopName,
        area: body.area || customer.area,
        creditLimit: body.credit_limit,
        creditDays: body.credit_days,
        customerType: "REGISTERED",
        status: "ACTIVE",
        convertedFromWalkIn: true, // المرجع التاريخي §22
        convertedAt: new Date(),
        updatedBy: session.userId,
      },
    });

    // The shared default was just registered — mint a fresh walk-in for POS.
    if (wasSharedDefault) {
      const stillHasWalkin = await tx.customer.findFirst({
        where: { companyId: session.companyId, customerType: "WALK_IN", deletedAt: null },
      });
      if (!stillHasWalkin) await ensureWalkInCustomer(session.companyId);
    }

    return row;
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    {
      action: "WALKIN_CONVERTED",
      module: "parties",
      entityType: "customer",
      entityId: updated.id,
      oldValues: { customer_type: customer.customerType, code: customer.code },
      newValues: { customer_type: "REGISTERED", name: updated.name, credit_limit: updated.creditLimit, was_shared_default: wasSharedDefault },
    }
  );

  return ok({
    id: updated.id,
    code: updated.code,
    name: updated.name,
    customer_type: updated.customerType,
    converted_from_walk_in: updated.convertedFromWalkIn,
    converted_at: updated.convertedAt,
    credit_limit: updated.creditLimit,
  });
});
