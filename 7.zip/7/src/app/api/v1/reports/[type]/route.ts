import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, ApiError } from "@/lib/api";
import { db } from "@/lib/db";
import { Decimal, dec, moneyR, qtyR, sumOf, num } from "@/lib/decimal";
import { handleExtraReport } from "@/lib/reports-extra";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/reports/[type] (reports.reports.view)
 *   sales-daily   → آخر 14 يوم: عدد الفواتير + الإجمالي (نقدي/آجل)
 *   top-products  → أفضل 10 منتجات حسب الإيراد
 *   aging         → أعمار الذمم (0-30 / 31-60 / 61-90 / +90)
 *   valuation     → تقييم المخزون بالتكلفة لكل مستودع
 *   profit        → الربحية الإجمالية لآخر 5000 بند بيع (إيراد − تكلفة)
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "reports.reports.view");
  const { type } = await ctx.params;
  const companyId = session.companyId;
  const url = new URL(req.url);

  if (type === "sales-daily") {
    const since = new Date();
    since.setDate(since.getDate() - 13);
    since.setHours(0, 0, 0, 0);

    const rows = await db.salesInvoice.findMany({
      where: { companyId, deletedAt: null, invoiceDate: { gte: since } },
      select: { invoiceDate: true, grandTotal: true, type: true },
      orderBy: { invoiceDate: "asc" },
    });

    const days = new Map<string, { date: string; count: number; total: Decimal; cash: Decimal; credit: Decimal }>();
    for (let i = 0; i < 14; i++) {
      const d = new Date(since);
      d.setDate(d.getDate() + i);
      const key = d.toISOString().slice(0, 10);
      days.set(key, { date: key, count: 0, total: new Decimal(0), cash: new Decimal(0), credit: new Decimal(0) });
    }
    for (const r of rows) {
      const key = r.invoiceDate.toISOString().slice(0, 10);
      const bucket = days.get(key);
      if (!bucket) continue;
      bucket.count += 1;
      bucket.total = bucket.total.plus(r.grandTotal);
      if (r.type === "CASH") bucket.cash = bucket.cash.plus(r.grandTotal);
      else bucket.credit = bucket.credit.plus(r.grandTotal);
    }

    return ok([...days.values()].map((d) => ({
      date: d.date, count: d.count,
      total: num(moneyR(d.total)), cash: num(moneyR(d.cash)), credit: num(moneyR(d.credit)),
    })));
  }

  if (type === "top-products") {
    const lines = await db.salesInvoiceLine.findMany({
      where: { invoice: { companyId, deletedAt: null } },
      select: { productId: true, qty: true, lineTotal: true, product: { select: { name: true, unit: true } } },
    });

    const agg = new Map<number, { product_id: number; name: string; unit: string; qty: Decimal; revenue: Decimal }>();
    for (const l of lines) {
      const cur = agg.get(l.productId) ?? {
        product_id: l.productId,
        name: l.product.name,
        unit: l.product.unit,
        qty: new Decimal(0),
        revenue: new Decimal(0),
      };
      cur.qty = cur.qty.plus(l.qty);
      cur.revenue = cur.revenue.plus(l.lineTotal);
      agg.set(l.productId, cur);
    }

    return ok(
      [...agg.values()]
        .sort((a, b) => num(b.revenue.minus(a.revenue)))
        .slice(0, 10)
        .map((r) => ({ ...r, qty: num(qtyR(r.qty)), revenue: num(moneyR(r.revenue)) }))
    );
  }

  if (type === "aging") {
    const invoices = await db.salesInvoice.findMany({
      where: { companyId, deletedAt: null },
      select: { invoiceDate: true, grandTotal: true, paidAmount: true, customer: { select: { code: true, name: true } } },
    });

    const buckets = {
      current: { label: "0-30 يوم", total: new Decimal(0), count: 0 },
      d31_60: { label: "31-60 يوم", total: new Decimal(0), count: 0 },
      d61_90: { label: "61-90 يوم", total: new Decimal(0), count: 0 },
      d90: { label: "أكثر من 90 يوم", total: new Decimal(0), count: 0 },
    };
    const now = Date.now();
    const perCustomer = new Map<string, { name: string; total: Decimal }>();

    for (const inv of invoices) {
      const due = moneyR(dec(inv.grandTotal).minus(inv.paidAmount));
      if (!due.isPositive()) continue;
      const ageDays = Math.floor((now - inv.invoiceDate.getTime()) / 86_400_000);
      const b =
        ageDays <= 30 ? buckets.current
        : ageDays <= 60 ? buckets.d31_60
        : ageDays <= 90 ? buckets.d61_90
        : buckets.d90;
      b.total = b.total.plus(due);
      b.count += 1;
      const key = inv.customer.code;
      const pc = perCustomer.get(key) ?? { name: inv.customer.name, total: new Decimal(0) };
      pc.total = pc.total.plus(due);
      perCustomer.set(key, pc);
    }

    const topCustomers = [...perCustomer.entries()]
      .map(([code, v]) => ({ code, name: v.name, total: num(moneyR(v.total)) }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 10);

    return ok({
      buckets: Object.values(buckets).map((b) => ({ label: b.label, total: num(moneyR(b.total)), count: b.count })),
      top_customers: topCustomers,
    });
  }

  if (type === "valuation") {
    const rows = await db.stockBalance.findMany({
      where: { companyId, qty: { not: 0 } },
      include: {
        warehouse: { select: { code: true, name: true } },
        product: { select: { id: true, name: true, unit: true, costPrice: true, salePrice: true, minStock: true } },
      },
    });

    const byWh = new Map<string, { warehouse: string; code: string; items: number; qty: Decimal; cost_value: Decimal; sale_value: Decimal; low: number }>();
    for (const r of rows) {
      const key = r.warehouse.code;
      const cur = byWh.get(key) ?? { warehouse: r.warehouse.name, code: key, items: 0, qty: new Decimal(0), cost_value: new Decimal(0), sale_value: new Decimal(0), low: 0 };
      cur.items += 1;
      cur.qty = cur.qty.plus(r.qty);
      cur.cost_value = cur.cost_value.plus(dec(r.qty).mul(r.product.costPrice));
      cur.sale_value = cur.sale_value.plus(dec(r.qty).mul(r.product.salePrice));
      if (dec(r.qty).lte(r.product.minStock)) cur.low += 1;
      byWh.set(key, cur);
    }

    // §66.1 summary — company-wide KPIs for the inventory overview cards
    const totalQty = sumOf(rows, (r) => r.qty);
    const costValue = sumOf(rows, (r) => dec(r.qty).mul(r.product.costPrice));
    const saleValue = sumOf(rows, (r) => dec(r.qty).mul(r.product.salePrice));
    const lowCount = rows.filter((r) => dec(r.qty).lte(r.product.minStock)).length;

    // out-of-stock: active products with no positive balance anywhere
    const inStockIds = new Set(rows.map((r) => r.product.id));
    const totalProducts = await db.product.count({ where: { companyId, deletedAt: null, isActive: true } });
    const outCount = Math.max(0, totalProducts - inStockIds.size);

    // dead stock: products whose last movement is older than 90 days (or none)
    const since = new Date(Date.now() - 90 * 24 * 3600 * 1000);
    const recentMov = await db.stockMovement.groupBy({
      by: ["productId"],
      where: { companyId, createdAt: { gte: since } },
    });
    const recentIds = new Set(recentMov.map((m) => m.productId));
    const deadCount = rows.filter((r) => !recentIds.has(r.product.id)).length;

    // COGS from sold lines (same basis as profit report)
    const cogsLines = await db.salesInvoiceLine.findMany({
      where: { invoice: { companyId, deletedAt: null } },
      select: { qty: true, unitCost: true },
      take: 20000,
    });
    const cogs = sumOf(cogsLines, (l) => dec(l.unitCost).mul(l.qty));

    return ok({
      rows: [...byWh.values()].map((w) => ({
        warehouse: w.warehouse, code: w.code, items: w.items,
        qty: num(qtyR(w.qty)), cost_value: num(moneyR(w.cost_value)), sale_value: num(moneyR(w.sale_value)), low: w.low,
      })),
      summary: {
        total_qty: num(qtyR(totalQty)),
        cost_value: num(moneyR(costValue)),
        sale_value: num(moneyR(saleValue)),
        expected_profit: num(moneyR(saleValue.minus(costValue))),
        cogs: num(moneyR(cogs)),
        low_count: lowCount,
        out_count: outCount,
        dead_count: deadCount,
      },
    });
  }

  if (type === "profit") {
    const lines = await db.salesInvoiceLine.findMany({
      where: { invoice: { companyId, deletedAt: null } },
      select: { qty: true, lineTotal: true, unitCost: true, product: { select: { name: true } } },
      take: 5000,
      orderBy: { id: "desc" },
    });

    let revenue = new Decimal(0);
    let cost = new Decimal(0);
    const perProduct = new Map<string, { name: string; revenue: Decimal; cost: Decimal; qty: Decimal }>();
    for (const l of lines) {
      const c = moneyR(dec(l.unitCost).mul(l.qty));
      revenue = revenue.plus(l.lineTotal);
      cost = cost.plus(c);
      const key = l.product.name;
      const cur = perProduct.get(key) ?? { name: key, revenue: new Decimal(0), cost: new Decimal(0), qty: new Decimal(0) };
      cur.revenue = cur.revenue.plus(l.lineTotal);
      cur.cost = cur.cost.plus(c);
      cur.qty = cur.qty.plus(l.qty);
      perProduct.set(key, cur);
    }

    const products = [...perProduct.values()]
      .map((p) => ({
        name: p.name,
        revenue: num(moneyR(p.revenue)),
        cost: num(moneyR(p.cost)),
        qty: num(qtyR(p.qty)),
        profit: num(moneyR(p.revenue.minus(p.cost))),
        margin_pct: p.revenue.isPositive()
          ? num(p.revenue.minus(p.cost).div(p.revenue).mul(1000).toDecimalPlaces(0, Decimal.ROUND_HALF_UP).div(10))
          : 0,
      }))
      .sort((a, b) => b.profit - a.profit);

    return ok({
      revenue: num(moneyR(revenue)),
      cost: num(moneyR(cost)),
      gross_profit: num(moneyR(revenue.minus(cost))),
      margin_pct: revenue.isPositive()
        ? num(revenue.minus(cost).div(revenue).mul(1000).toDecimalPlaces(0, Decimal.ROUND_HALF_UP).div(10))
        : 0,
      products: products.slice(0, 10),
    });
  }

  if (type === "customer-statement") {
    const customerId = Number(url.searchParams.get("customer_id") ?? 0);
    if (!Number.isInteger(customerId) || customerId <= 0) {
      throw new ApiError("VAL_001", "حدد العميل عبر ?customer_id=");
    }
    const days = Math.min(3650, Math.max(1, Number(url.searchParams.get("days") ?? 365)));
    const since = new Date();
    since.setDate(since.getDate() - days);
    since.setHours(0, 0, 0, 0);

    const customer = await db.customer.findFirst({
      where: { id: customerId, companyId, deletedAt: null },
      select: { id: true, code: true, name: true, phone: true, whatsapp: true, balance: true, creditLimit: true, creditDays: true },
    });
    if (!customer) throw new ApiError("VAL_003", "العميل غير موجود");

    const [invoices, returns, collections, loyaltyRows] = await Promise.all([
      db.salesInvoice.findMany({
        where: { companyId, customerId, deletedAt: null, invoiceDate: { gte: since } },
        select: { id: true, number: true, invoiceDate: true, grandTotal: true, paidAmount: true, type: true },
        orderBy: { invoiceDate: "asc" },
      }),
      db.salesReturn.findMany({
        where: { companyId, customerId, deletedAt: null, returnDate: { gte: since } },
        select: { id: true, number: true, returnDate: true, totalAmount: true, refundCash: true, creditNote: true },
        orderBy: { returnDate: "asc" },
      }),
      db.cashTransaction.findMany({
        // exclude cashbox mirror rows (SALES_INVOICE_CASH) AND invoice-attached
        // payments (SALES_INVOICE) — both are already represented by the
        // invoice's own PAYMENT row (paidAmount); counting them here would
        // double-credit the customer (running ≠ closing).
        // NOTE: OR keeps refType NULL rows (manual collections w/o invoice)
        // because Prisma `not:` drops NULLs in SQL.
        where: {
          companyId, customerId, category: "COLLECTION", createdAt: { gte: since },
          OR: [{ refType: null }, { refType: { notIn: ["SALES_INVOICE", "SALES_INVOICE_CASH"] } }],
        },
        select: { id: true, createdAt: true, amount: true, note: true },
        orderBy: { createdAt: "asc" },
      }),
      db.loyaltyTransaction.findMany({
        where: { companyId, customerId, type: "REDEEM", createdAt: { gte: since } },
        select: { id: true, createdAt: true, points: true, note: true },
        orderBy: { createdAt: "asc" },
      }),
    ]);

    // الرصيد المرحَّل — أثر كل حركات ما قبل بداية الفترة على الذمة.
    // بدونها لا يتطابق running مع closing_balance لأي عميل له سجل سابق للفترة.
    const [preInvoices, preReturns, preCollections, preLoyalty] = await Promise.all([
      db.salesInvoice.aggregate({
        where: { companyId, customerId, deletedAt: null, invoiceDate: { lt: since } },
        _sum: { grandTotal: true, paidAmount: true },
      }),
      db.salesReturn.aggregate({
        where: { companyId, customerId, deletedAt: null, returnDate: { lt: since } },
        _sum: { creditNote: true },
      }),
      db.cashTransaction.aggregate({
        where: {
          companyId, customerId, category: "COLLECTION", createdAt: { lt: since },
          OR: [{ refType: null }, { refType: { notIn: ["SALES_INVOICE", "SALES_INVOICE_CASH"] } }],
        },
        _sum: { amount: true },
      }),
      db.loyaltyTransaction.aggregate({
        where: { companyId, customerId, type: "REDEEM", createdAt: { lt: since } },
        _sum: { points: true },
      }),
    ]);
    const openingBalance = moneyR(
      dec(preInvoices._sum.grandTotal)
      .minus(dec(preInvoices._sum.paidAmount))
      .plus(dec(preReturns._sum.creditNote))
      .minus(dec(preCollections._sum.amount))
      .minus(dec(preLoyalty._sum.points).abs())
    );

    type Row = {
      date: string; kind: "INVOICE" | "RETURN" | "COLLECTION" | "PAYMENT" | "LOYALTY";
      ref: string; description: string;
      debit: Decimal; credit: Decimal; running: Decimal;
    };
    const rows: Row[] = [];
    let running = openingBalance; // يبدأ من الرصيد المرحَّل لا من الصفر

    const merged = [
      ...invoices.map((i) => ({ t: i.invoiceDate.getTime(), kind: "INVOICE" as const, row: i })),
      ...returns.map((r) => ({ t: r.returnDate.getTime(), kind: "RETURN" as const, row: r })),
      ...collections.map((c) => ({ t: c.createdAt.getTime(), kind: "COLLECTION" as const, row: c })),
      ...loyaltyRows.map((l) => ({ t: l.createdAt.getTime(), kind: "LOYALTY" as const, row: l })),
    ].sort((a, b) => a.t - b.t || a.kind.localeCompare(b.kind));

    for (const m of merged) {
      if (m.kind === "INVOICE") {
        const inv = m.row;
        running = running.plus(inv.grandTotal);
        rows.push({
          date: inv.invoiceDate.toISOString().slice(0, 10), kind: "INVOICE",
          ref: inv.number, description: inv.type === "CASH" ? "فاتورة نقدية" : "فاتورة آجلة",
          debit: moneyR(dec(inv.grandTotal)), credit: new Decimal(0), running,
        });
        if (dec(inv.paidAmount).isPositive()) {
          running = running.minus(inv.paidAmount);
          rows.push({
            date: inv.invoiceDate.toISOString().slice(0, 10), kind: "PAYMENT",
            ref: inv.number, description: "سداد مع الفاتورة",
            debit: new Decimal(0), credit: moneyR(dec(inv.paidAmount)), running,
          });
        }
      } else if (m.kind === "RETURN") {
        const ret = m.row;
        if (dec(ret.creditNote).isPositive()) {
          running = running.minus(ret.creditNote);
          rows.push({
            date: ret.returnDate.toISOString().slice(0, 10), kind: "RETURN",
            ref: ret.number, description: dec(ret.refundCash).isPositive() ? "مرتجع — إشعار دائن + رد نقدي" : "مرتجع — إشعار دائن",
            debit: new Decimal(0), credit: moneyR(dec(ret.creditNote)), running,
          });
        }
      } else if (m.kind === "LOYALTY") {
        const l = m.row;
        const value = Math.abs(l.points); // 1 نقطة = 1 د.ع
        running = running.minus(value);
        rows.push({
          date: l.createdAt.toISOString().slice(0, 10), kind: "LOYALTY",
          ref: `#${l.id}`, description: l.note ?? `استبدال ${Math.abs(l.points)} نقطة ولاء`,
          debit: new Decimal(0), credit: dec(value), running,
        });
      } else {
        const c = m.row;
        running = running.minus(c.amount);
        rows.push({
          date: c.createdAt.toISOString().slice(0, 10), kind: "COLLECTION",
          ref: `#${c.id}`, description: c.note ?? "تحصيل نقدي",
          debit: new Decimal(0), credit: moneyR(dec(c.amount)), running,
        });
      }
    }

    const totals = {
      debit: num(moneyR(sumOf(rows, (r) => r.debit))),
      credit: num(moneyR(sumOf(rows, (r) => r.credit))),
    };

    return ok({
      customer,
      rows: rows.map((r) => ({ ...r, debit: num(r.debit), credit: num(r.credit), running: num(moneyR(r.running)) })),
      totals,
      opening_balance: num(openingBalance),
      closing_balance: customer.balance,
      statement_running_total: num(moneyR(running)),
    });
  }

  if (type === "rep-performance") {
    // آخر 30 يومًا — أداء المندوبين: فواتير، مبيعات، زيارات، تحصيلات، عمولات
    const since = new Date();
    since.setDate(since.getDate() - 29);
    since.setHours(0, 0, 0, 0);

    const reps = await db.user.findMany({
      where: {
        companyId, deletedAt: null, isActive: true,
        roles: { some: { role: { code: "SALES_REP", deletedAt: null } } },
      },
      select: { id: true, fullName: true, username: true },
    });

    const [invoices, visits, collections, commissions] = await Promise.all([
      db.salesInvoice.groupBy({
        by: ["createdById"],
        where: { companyId, deletedAt: null, invoiceDate: { gte: since } },
        _count: { _all: true },
        _sum: { grandTotal: true },
      }),
      db.visit.groupBy({
        by: ["repId"],
        where: { companyId, deletedAt: null, plannedDate: { gte: since }, status: "COMPLETED" },
        _count: { _all: true },
      }),
      db.cashTransaction.groupBy({
        by: ["createdBy"],
        where: { companyId, category: "COLLECTION", createdAt: { gte: since } },
        _sum: { amount: true },
      }),
      db.commission.groupBy({
        by: ["repId"],
        where: { companyId, createdAt: { gte: since } },
        _sum: { amount: true },
      }),
    ]);

    const invMap = new Map(invoices.map((r) => [r.createdById, r]));
    const visMap = new Map(visits.map((r) => [r.repId, r]));
    const colMap = new Map(collections.map((r) => [r.createdBy ?? 0, r]));
    const comMap = new Map(commissions.map((r) => [r.repId, r]));

    const rows = reps.map((rep) => {
      const inv = invMap.get(rep.id);
      const vis = visMap.get(rep.id);
      const col = colMap.get(rep.id);
      const com = comMap.get(rep.id);
      const sales = num(moneyR(dec(inv?._sum.grandTotal)));
      return {
        rep_id: rep.id,
        name: rep.fullName,
        username: rep.username,
        invoices_count: inv?._count._all ?? 0,
        sales_total: sales,
        completed_visits: vis?._count._all ?? 0,
        collected_total: num(moneyR(dec(col?._sum.amount))),
        commissions_total: num(moneyR(dec(com?._sum?.amount))),
      };
    });

    return ok({ since: since.toISOString().slice(0, 10), days: 30, rows });
  }

  const extra = await handleExtraReport(type, session, url);
  if (extra) return ok(extra);

  throw new ApiError("VAL_003", "نوع تقرير غير معروف — راجع قائمة التقارير في الواجهة (31 نوعًا مدعومًا)");
});
