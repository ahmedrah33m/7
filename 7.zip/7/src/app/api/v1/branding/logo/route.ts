import { NextRequest, NextResponse } from "next/server";
import { handler, enforceRateLimit } from "@/lib/api";
import { db } from "@/lib/db";
import { storage } from "@/lib/storage";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/branding/logo — صورة شعار النظام العامة (بلا مصادقة).
 *
 * يخدم بايتات شعار النظام من جدول system_brand (صف واحد) — مستقل عن شعارات
 * الشركات — لا ملفات عشوائية ولا مسارات من المستخدم: الاسم يأتي من القاعدة
 * وكان UUID + امتداد بيضاء عند التخزين (طبقة storage تتحقق مرة أخرى).
 * Cache عام قصير + X-Content-Type-Options.
 */
export const GET = handler(async (req: NextRequest) => {
  enforceRateLimit(`branding-logo:${req.headers.get("x-forwarded-for") ?? "local"}`, 300);

  const brand = await db.systemBrand.findUnique({
    where: { id: 1 },
    select: { logoUrl: true },
  });

  const name = brand?.logoUrl?.split("/").pop() ?? "";
  const row = name ? await storage.read(name) : null;
  if (!row) {
    return NextResponse.json({ success: false, code: "VAL_003", message: "لا يوجد شعار" }, { status: 404 });
  }

  return new NextResponse(new Uint8Array(row.data), {
    status: 200,
    headers: {
      "Content-Type": row.mime,
      "Content-Length": String(row.data.length),
      "Cache-Control": "public, max-age=300, stale-while-revalidate=3600",
      "X-Content-Type-Options": "nosniff",
    },
  });
});
