import { NextRequest } from "next/server";
import { handler, ok, enforceRateLimit } from "@/lib/api";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/branding — نقطة هوية عامة (بلا مصادقة) لشاشة تسجيل الدخول.
 *
 * تعيد **شعار النظام** من جدول system_brand (صف واحد) — مستقل تمامًا عن
 * شعارات الشركات (Company.logoUrl تظهر في القائمة الجانبية والفواتير فقط).
 *   { logo_url: string | null, logo_version: string | null }
 *   logo_url يشير إلى نقطة الصورة العامة /api/v1/branding/logo?v=<mtime>
 *   — معرف الإصدار يكسر الكاش تلقائيًا عند تغيير الشعار.
 *
 * الأمان: بلا أسرار ولا بيانات مستخدمين — مسار صورة فقط، مع حد معدل.
 */
export const GET = handler(async (req: NextRequest) => {
  enforceRateLimit(`branding:${req.headers.get("x-forwarded-for") ?? "local"}`, 300);

  const brand = await db.systemBrand.findUnique({
    where: { id: 1 },
    select: { logoUrl: true, updatedAt: true },
  });

  if (!brand?.logoUrl) {
    return ok({ logo_url: null, logo_version: null });
  }

  // logoUrl بصيغة /api/v1/files/<uuid>.<ext> — الصورة تُقدَّم عبر النقطة العامة
  return ok({
    logo_url: `/api/v1/branding/logo`,
    logo_version: Math.floor(new Date(brand.updatedAt).getTime() / 1000).toString(),
  });
});
