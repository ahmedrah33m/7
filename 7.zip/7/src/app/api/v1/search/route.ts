import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { branchWhere, effectiveBranchIds } from "@/lib/scope";
import { handler, ok } from "@/lib/api";
import { db } from "@/lib/db";
import { dec, num, sumOf } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/search?q= — بحث شامل موحّد (Development pack 2).
 * يجيب مرة واحدة من كل ما يملك الجلسة صلاحية رؤيته:
 *   المنتجات (اسم/كود/باركود) · العملاء (اسم/هاتف/كود) · الفواتير (رقم)
 *   الموردون · أوامر البيع · طلبات B2B — كل مجموعة مشروطة بصلاحيتها.
 * نتيجة كل عنصر: { type, id, label, sublabel, tab } لتفتح التبويب الصحيح.
 */
const LIMIT_PER_GROUP = 5;

export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req);
  const q = (new URL(req.url).searchParams.get("q") ?? "").trim();
  if (q.length < 2) {
    return ok({ query: q, groups: [], total: 0, hint: "اكتب حرفين على الأقل" });
  }
  const companyId = session.companyId;
  const can = (p: string) => session.permissions.has(p);
  type Hit = { type: string; id: number; label: string; sublabel: string; tab: string };
  const groups: { type: string; title: string; hits: Hit[] }[] = [];
  let total = 0;

  const push = (type: string, title: string, hits: Hit[]) => {
    if (hits.length) {
      groups.push({ type, title, hits });
      total += hits.length;
    }
  };

  // 1) المنتجات — بالاسم أو الكود أو الباركود
  if (can("products.products.view")) {
    const rows = await db.product.findMany({
      where: {
        companyId, deletedAt: null,
        OR: [{ name: { contains: q } }, { code: { contains: q } }, { barcode: { contains: q } }],
      },
      select: { id: true, code: true, name: true, unit: true, salePrice: true, stockBalances: { select: { qty: true } } },
      take: LIMIT_PER_GROUP,
      orderBy: { id: "asc" },
    });
    push("product", "المنتجات", rows.map((p) => ({
      type: "product", id: p.id, label: p.name,
      sublabel: `${p.code} · ${new Intl.NumberFormat("ar-IQ").format(num(p.salePrice))} د.ع · متاح ${num(sumOf(p.stockBalances, (b) => b.qty))} ${p.unit}`,
      tab: "products",
    })));
  }

  // 2) العملاء — بالاسم أو الهاتف أو الكود
  if (can("parties.customers.view")) {
    const rows = await db.customer.findMany({
      where: {
        companyId, deletedAt: null,
        ...branchWhere(session),
        OR: [{ name: { contains: q } }, { phone: { contains: q } }, { code: { contains: q } }],
      },
      select: { id: true, code: true, name: true, phone: true, balance: true },
      take: LIMIT_PER_GROUP,
      orderBy: { id: "asc" },
    });
    push("customer", "العملاء", rows.map((c) => ({
      type: "customer", id: c.id, label: c.name,
      sublabel: `${c.code}${c.phone ? ` · ${c.phone}` : ""} · ذمة ${new Intl.NumberFormat("ar-IQ").format(num(c.balance))} د.ع`,
      tab: "customers",
    })));
  }

  // 3) الفواتير — بالرقم
  if (can("sales.invoices.view")) {
    const rows = await db.salesInvoice.findMany({
      where: { companyId, deletedAt: null, ...branchWhere(session), number: { contains: q } },
      select: { id: true, number: true, invoiceDate: true, grandTotal: true, paidAmount: true, customer: { select: { name: true } } },
      take: LIMIT_PER_GROUP,
      orderBy: { id: "desc" },
    });
    push("invoice", "الفواتير", rows.map((i) => ({
      type: "invoice", id: i.id, label: i.number,
      sublabel: `${i.customer.name} · ${new Intl.NumberFormat("ar-IQ").format(num(i.grandTotal))} د.ع${dec(i.grandTotal).minus(i.paidAmount).isPositive() ? " (غير مسددة كاملة)" : " (مسددة)"}`,
      tab: "invoices",
    })));
  }

  // 4) أوامر البيع
  if (can("sales.orders.view")) {
    const rows = await db.salesOrder.findMany({
      where: { companyId, deletedAt: null, ...branchWhere(session), number: { contains: q } },
      select: { id: true, number: true, status: true, grandTotal: true, customer: { select: { name: true } } },
      take: LIMIT_PER_GROUP,
      orderBy: { id: "desc" },
    });
    push("order", "أوامر البيع", rows.map((o) => ({
      type: "order", id: o.id, label: o.number,
      sublabel: `${o.customer.name} · ${o.status} · ${new Intl.NumberFormat("ar-IQ").format(num(o.grandTotal))} د.ع`,
      tab: "orders",
    })));
  }

  // 5) الموردون
  if (can("parties.suppliers.view")) {
    const rows = await db.supplier.findMany({
      where: {
        companyId, deletedAt: null,
        OR: [{ name: { contains: q } }, { phone: { contains: q } }, { code: { contains: q } }],
      },
      select: { id: true, code: true, name: true, phone: true, balance: true },
      take: LIMIT_PER_GROUP,
      orderBy: { id: "asc" },
    });
    push("supplier", "الموردون", rows.map((s) => ({
      type: "supplier", id: s.id, label: s.name,
      sublabel: `${s.code}${s.phone ? ` · ${s.phone}` : ""} · مستحقات ${new Intl.NumberFormat("ar-IQ").format(num(s.balance))} د.ع`,
      tab: "purchases",
    })));
  }

  // 6) طلبات بوابة B2B
  if (can("b2b.orders.view")) {
    const rows = await db.b2BOrder.findMany({
      where: { companyId, deletedAt: null, number: { contains: q } },
      select: { id: true, number: true, status: true, grandTotal: true, customer: { select: { name: true } } },
      take: LIMIT_PER_GROUP,
      orderBy: { id: "desc" },
    });
    push("b2b", "طلبات بوابة العملاء", rows.map((o) => ({
      type: "b2b", id: o.id, label: o.number,
      sublabel: `${o.customer.name} · ${o.status} · ${new Intl.NumberFormat("ar-IQ").format(num(o.grandTotal))} د.ع`,
      tab: "b2b",
    })));
  }

  return ok({ query: q, groups, total });
});
