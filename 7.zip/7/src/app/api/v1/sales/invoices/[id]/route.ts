import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, ApiError } from "@/lib/api";
import { Decimal, dec, moneyR, num } from "@/lib/decimal";
import { packInfoOf, fmtPackText, packSplit } from "@/lib/packaging";
import { effectiveBranchIds } from "@/lib/scope";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/sales/invoices/[id] — smart invoice full document
 * (sales.invoices.view): header + customer card + balance snapshot
 * (فصل الرصيد §4) + lines with packaging split & stock before/after
 * (§26) + packaging ledger events (§13) + mini statement (§22) +
 * linked delivery notes.
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.invoices.view");
  const { id } = await ctx.params;
  const invoiceId = Number(id);
  if (!Number.isInteger(invoiceId)) throw new ApiError("VAL_003", "معرّف فاتورة غير صالح");

  const inv = await db.salesInvoice.findFirst({
    where: { id: invoiceId, companyId: session.companyId, deletedAt: null },
    include: {
      customer: {
        select: {
          id: true, code: true, name: true, shopName: true, phone: true, whatsapp: true,
          address: true, area: true, status: true, balance: true, creditLimit: true,
        },
      },
      warehouse: { select: { id: true, code: true, name: true } },
      creator: { select: { id: true, fullName: true } },
      rep: { select: { id: true, fullName: true } },
      branch: { select: { name: true } },
      lines: {
        include: { product: { select: { code: true, name: true, unit: true, packUnit: true, packQty: true, packSalePrice: true } } },
        orderBy: { id: "asc" },
      },
      sourceOrders: { select: { number: true } },
      deliveryNotes: {
        select: { number: true, status: true, driver: true, driverPhone: true, deliveredAt: true, shipDate: true },
      },
      convertedQuotations: { select: { number: true } },
    },
  });
  if (!inv) throw new ApiError("VAL_003", "الفاتورة غير موجودة");

  // ---- IDOR guard (Phase 13): an invoice of another branch must never
  // leak — answer 404 exactly like a missing record (no enumeration).
  if (!effectiveBranchIds(session).includes(inv.branchId)) {
    await writeAudit(
      { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
      { action: "ACCESS_DENIED", module: "sales", entityType: "sales_invoice", entityId: inv.id,
        newValues: { reason: "Branch Scope Violation", attempted_branch: inv.branchId, active_branch: session.activeBranchId } }
    );
    throw new ApiError("VAL_003", "الفاتورة غير موجودة");
  }

  // packaging ledger for this invoice (سجل التعبئة §13)
  const pkgLedger = await db.packagingLedger.findMany({
    where: { companyId: session.companyId, refType: "SALES_INVOICE", refId: inv.id },
    orderBy: { id: "asc" },
    select: {
      packageCode: true, packageType: true, direction: true,
      openingQty: true, issuedQty: true, remainingQty: true, note: true, createdAt: true,
    },
  });
  const pkgLedgerOut = pkgLedger.map((e) => ({
    ...e,
    openingQty: num(e.openingQty),
    issuedQty: num(e.issuedQty),
    remainingQty: num(e.remainingQty),
  }));

  // mini statement (§22) — optional per company setting
  const [lastInvoiceBefore, lastPayment, settings] = await Promise.all([
    db.salesInvoice.findFirst({
      where: {
        customerId: inv.customerId, companyId: session.companyId,
        deletedAt: null, status: { not: "REJECTED" }, id: { lt: inv.id },
      },
      orderBy: { id: "desc" },
      select: { number: true, invoiceDate: true, grandTotal: true },
    }),
    db.cashTransaction.findFirst({
      where: { customerId: inv.customerId, companyId: session.companyId, direction: "IN" },
      orderBy: { id: "desc" },
      select: { amount: true, createdAt: true },
    }),
    db.setting.findMany({
      where: { companyId: session.companyId, key: { in: ["invoice.footer_text", "invoice.show_mini_statement"] } },
    }),
  ]);
  const sMap = new Map(settings.map((s) => [s.key, s.value]));
  let footerText = "البضاعة المباعة لا تستبدل إلا حسب سياسة الشركة.\nشكراً لتعاملكم معنا.";
  let showMiniStatement = true;
  try { if (sMap.has("invoice.footer_text")) footerText = JSON.parse(sMap.get("invoice.footer_text")!); } catch { /* keep default */ }
  try { if (sMap.has("invoice.show_mini_statement")) showMiniStatement = JSON.parse(sMap.get("invoice.show_mini_statement")!); } catch { /* keep default */ }

  // ---- سجل المدفوعات المفصلة على الفاتورة (تطوير الفاتورة — جولة 2) ------
  // كل حركة صندوق مرتبطة بهذه الفاتورة: الدفعة الأصلية (SALES_INVOICE_CASH)
  // + التحصيلات اللاحقة (SALES_INVOICE) + استرداد الإلغاء (SALES_INVOICE_VOID)
  const paymentRows = await db.cashTransaction.findMany({
    where: {
      companyId: session.companyId,
      refType: { in: ["SALES_INVOICE", "SALES_INVOICE_CASH", "SALES_INVOICE_VOID"] },
      refId: inv.id,
    },
    orderBy: { id: "desc" },
    select: {
      id: true, direction: true, category: true, amount: true,
      note: true, createdAt: true, createdBy: true, cashbox: { select: { name: true } },
    },
  });
  const paymentUserIds = [...new Set(paymentRows.map((p) => p.createdBy).filter((x): x is number => x != null))];
  const paymentUsers = paymentUserIds.length
    ? await db.user.findMany({ where: { id: { in: paymentUserIds } }, select: { id: true, fullName: true } })
    : [];
  const paymentUserName = new Map(paymentUsers.map((u) => [u.id, u.fullName]));
  const payments = paymentRows.map((p) => ({
    id: p.id,
    direction: p.direction, // IN تحصيل | OUT استرداد/إلغاء
    category: p.category,
    amount: num(p.amount),
    note: p.note,
    cashbox: p.cashbox.name,
    created_at: p.createdAt,
    by: p.createdBy ? paymentUserName.get(p.createdBy) ?? `#${p.createdBy}` : "—",
  }));

  // R10 — حدود الاستجابة: كل الحقول المالية/الكمية تخرج numbers كما كانت
  const nOrNull = (v: unknown): number | null => (v == null ? null : num(v));
  const lines = inv.lines.map((l) => {
    const info = packInfoOf(l.product);
    const split = info.hasPack
      ? packSplit(l.qty, info.packQty)
      : { packages: 0, loose: num(l.qty) };
    // prefer the stored split when it exists (line-level packaging §11)
    const hasStoredSplit = dec(l.packageQty).gt(0);
    const pkgQty = hasStoredSplit ? num(l.packageQty) : split.packages;
    const loose = hasStoredSplit ? num(l.looseQty) : split.loose;
    return {
      id: l.id,
      product: { ...l.product, packQty: num(l.product.packQty) },
      qty: num(l.qty),
      ordered_qty: num(l.orderedQty),
      package_qty: pkgQty,
      loose_qty: loose,
      package_type: l.packageType,
      package_type_label: l.packageType === "BOX" ? "صندوق" : l.packageType === "PACK" ? "باكيت" : "كرتونة",
      package_conversion: num(l.packageConversion),
      package_price: nOrNull(l.packagePrice),
      unit_price: num(l.unitPrice),
      discount_pct: num(l.discountPct),
      discount_amount: num(l.discountAmount),
      tax_amount: num(l.taxAmount),
      line_total: num(l.lineTotal),
      stock_before: num(l.stockBefore),
      stock_after: num(l.stockAfter),
      package_note: l.packageNote,
      qty_text: fmtPackText(num(l.qty), info),
    };
  });

  return ok({
    id: inv.id,
    number: inv.number,
    type: inv.type,
    sale_type: inv.saleType,
    status: inv.status,
    stock_applied: inv.stockApplied,
    credit_exceeded: inv.creditExceeded,
    invoice_date: inv.invoiceDate,
    due_date: inv.dueDate,
    payment_method: inv.paymentMethod,
    // ---- Dual currency snapshot (عرض الدولار = المخزن ÷ السعر) ----------
    currency_code: inv.currencyCode,
    exchange_rate: nOrNull(inv.exchangeRate),
    customer: {
      ...inv.customer,
      balance: num(inv.customer.balance),
      creditLimit: num(inv.customer.creditLimit),
    },
    warehouse: inv.warehouse,
    branch: inv.branch?.name ?? null,
    customer_type: inv.customerType,
    walkin_info: inv.customerType !== "REGISTERED"
      ? { name: inv.walkinName, phone: inv.walkinPhone, address: inv.walkinAddress }
      : null,
    created_by: inv.creator.fullName,
    rep: inv.rep ? { id: inv.rep.id, name: inv.rep.fullName } : null,
    // ---- balance snapshot (§4 — فصل الرصيد عن الفاتورة) -----------------
    previous_balance: num(inv.previousBalance),
    grand_total: num(inv.grandTotal),
    total_due: num(moneyR(dec(inv.previousBalance).plus(inv.grandTotal))),
    paid_amount: num(inv.paidAmount),
    // المتبقي لا يُعرض سالبًا — الفرق الزائد = إشعارات دائنة من مرتجعات لاحقة
    due_amount: num(moneyR(Decimal.max(new Decimal(0), dec(inv.grandTotal).minus(inv.paidAmount)))),
    credit_note_adjustment: num(moneyR(Decimal.max(new Decimal(0), dec(inv.paidAmount).minus(inv.grandTotal)))),
    new_balance: num(inv.newBalance),
    credit_limit: nOrNull(inv.creditLimitSnap),
    available_credit: num(moneyR(Decimal.max(new Decimal(0), dec(inv.creditLimitSnap).minus(inv.newBalance)))),
    // ---- packaging -------------------------------------------------------
    packaging_details: inv.packagingDetails,
    packaging_ledger: pkgLedgerOut,
    // ---- extras ----------------------------------------------------------
    receiver_name: inv.receiverName,
    receiver_phone: inv.receiverPhone,
    delivered_at: inv.deliveredAt,
    signed_at: inv.signedAt,
    rep_notes: inv.repNotes,
    customer_notes: inv.customerNotes,
    admin_notes: inv.adminNotes,
    notes: inv.notes,
    verify_token: inv.verifyToken,
    subtotal: num(inv.subtotal),
    discount_total: num(inv.discountTotal),
    tax_total: num(inv.taxTotal),
    source_orders: inv.sourceOrders.map((o) => o.number),
    source_quotations: inv.convertedQuotations.map((q) => q.number),
    delivery_notes: inv.deliveryNotes,
    mini_statement: showMiniStatement
      ? {
          last_invoice: lastInvoiceBefore
            ? { number: lastInvoiceBefore.number, date: lastInvoiceBefore.invoiceDate, total: num(lastInvoiceBefore.grandTotal) }
            : null,
          last_payment: lastPayment ? { amount: num(lastPayment.amount), date: lastPayment.createdAt } : null,
          balance_before_invoice: num(inv.previousBalance),
        }
      : null,
    footer_text: footerText,
    // سجل المدفوعات المفصلة (تطوير الفاتورة — جولة 2)
    payments,
    lines,
  });
});
