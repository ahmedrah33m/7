import { NextRequest, NextResponse } from "next/server";
import QRCode from "qrcode";
import { guard } from "@/lib/auth";
import { handler, ApiError } from "@/lib/api";
import { db } from "@/lib/db";
import { buildInvoiceHtml, htmlToPdf } from "@/lib/pdf";
import { round2 } from "@/lib/utils-server";

export const dynamic = "force-dynamic";

// Decimal → number عند حدود العرض (قوالب PDF تتوقع number).
const N = (x: unknown): number => (x == null ? 0 : Number(x));

// =====================================================================
// GET /api/v1/sales/invoices/[id]/pdf (sales.invoices.print) — §57.
// Server-side PDF of the invoice via headless Chromium: RTL Arabic,
// embedded Naskh font, ZATCA-style TLV QR. Falls back to SRV_002 when
// no engine is available (browser printing remains the alternative).
// =====================================================================

function tlv(tag: number, value: string): Buffer {
  const val = Buffer.from(value, "utf8");
  return Buffer.concat([Buffer.from([tag, val.length]), val]);
}

export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.invoices.print");
  const { id } = await ctx.params;
  const invoiceId = Number(id);
  if (!Number.isInteger(invoiceId)) throw new ApiError("VAL_003", "معرّف فاتورة غير صالح");

  const inv = await db.salesInvoice.findFirst({
    where: { id: invoiceId, companyId: session.companyId, deletedAt: null },
    include: {
      company: true,
      branch: { select: { name: true } },
      warehouse: { select: { name: true } },
      customer: { select: { code: true, name: true, phone: true } },
      rep: { select: { fullName: true } },
      lines: { include: { product: { select: { name: true } } } },
    },
  });
  if (!inv) throw new ApiError("VAL_003", "الفاتورة غير موجودة");

  const seller = inv.company.nameEn || inv.company.name;
  const tlvBase64 = Buffer.concat([
    tlv(1, seller),
    tlv(2, inv.company.taxNumber || "NA"),
    tlv(3, inv.invoiceDate.toISOString()),
    tlv(4, inv.grandTotal.toFixed(2)),
    tlv(5, inv.taxTotal.toFixed(2)),
  ]).toString("base64");
  const qrSvg = await QRCode.toString(tlvBase64, { type: "svg", errorCorrectionLevel: "M", margin: 1, width: 160 });

  const html = buildInvoiceHtml({
    companyName: inv.company.name,
    companyPhone: inv.company.phone,
    companyAddress: inv.company.address,
    companyTaxNumber: inv.company.taxNumber,
    branchName: inv.branch.name,
    warehouseName: inv.warehouse.name,
    number: inv.number,
    invoiceDate: inv.invoiceDate.toISOString().slice(0, 10),
    dueDate: inv.dueDate ? inv.dueDate.toISOString().slice(0, 10) : null,
    type: inv.type,
    customerName: inv.customer.name,
    customerCode: inv.customer.code,
    customerPhone: inv.customer.phone,
    salesRep: inv.rep?.fullName ?? null,
    subtotal: N(inv.subtotal),
    discountTotal: N(inv.discountTotal),
    taxTotal: N(inv.taxTotal),
    grandTotal: N(inv.grandTotal),
    paidAmount: round2(N(inv.paidAmount)),
    lines: inv.lines.map((l) => ({
      product: l.product.name,
      unit: l.packageType ?? null,
      qtyUnits: N(l.packageQty) > 0 ? N(l.packageQty) : null,
      qty: N(l.qty),
      unitPrice: N(l.unitPrice),
      discountPct: N(l.discountPct),
      lineTotal: N(l.lineTotal),
    })),
    qrSvg,
  });

  try {
    const pdf = await htmlToPdf(html);
    return new NextResponse(new Uint8Array(pdf), {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="${inv.number}.pdf"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (e) {
    const msg = (e as Error).message;
    if (msg.includes("playwright-not-available")) {
      throw new ApiError("SRV_002", "محرك PDF غير متاح على هذا الخادم — استخدم زر الطباعة من المتصفح (A4/حراري)");
    }
    throw new ApiError("SRV_001", `فشل توليد PDF: ${msg.slice(0, 140)}`);
  }
});
