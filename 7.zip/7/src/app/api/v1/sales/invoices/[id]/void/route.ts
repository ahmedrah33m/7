import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { ApiError } from "@/lib/api";
import { voidInvoice } from "@/lib/sales-service";

export const dynamic = "force-dynamic";

const voidSchema = z.object({
  reason: z.string().trim().max(300).optional().nullable(),
});

/**
 * POST /api/v1/sales/invoices/[id]/void — إلغاء فاتورة (sales.invoices.cancel)
 *  · PENDING_APPROVAL → إلغاء بسيط دون آثار
 *  · POSTED → عكس المخزون + إرجاع العبوات + خصم المتبقي من ذمة العميل
 * المبالغ المحصّلة سابقاً تبقى موثقة في الصندوق (الاسترداد يدوي).
 */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.invoices.cancel");
  const { id } = await ctx.params;
  const invoiceId = Number(id);
  if (!Number.isInteger(invoiceId)) throw new ApiError("VAL_003", "الفاتورة غير موجودة"); // 404 — لا نجاح فارغ أبداً

  const body = await parseBody(req, voidSchema).catch(() => ({ reason: null }));

  const result = await voidInvoice(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    invoiceId,
    body.reason ?? null
  );

  return ok(result);
});
