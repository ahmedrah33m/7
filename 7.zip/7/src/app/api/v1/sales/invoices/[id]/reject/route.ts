import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { ApiError } from "@/lib/api";
import { rejectInvoice } from "@/lib/sales-service";

export const dynamic = "force-dynamic";

const schema = z.object({ reason: z.string().trim().max(300).optional().nullable() });

/**
 * POST /api/v1/sales/invoices/[id]/reject — (sales.invoices.reject)
 * Rejects a PENDING_APPROVAL invoice: no stock/balance effects, the
 * number stays reserved as REJECTED for audit (spec §6 — منع الفاتورة).
 */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.invoices.reject");
  const body = await parseBody(req, schema).catch(() => ({ reason: null }));
  const { id } = await ctx.params;
  const invoiceId = Number(id);
  if (!Number.isInteger(invoiceId)) throw new ApiError("VAL_003", "الفاتورة غير موجودة"); // 404 — لا نجاح فارغ أبداً

  const result = await rejectInvoice(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    invoiceId,
    body.reason ?? null
  );
  return ok(result);
});
