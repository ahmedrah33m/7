import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { createSalesInvoice } from "@/lib/sales-service";
import { dec, moneyR, num } from "@/lib/decimal";
import { branchWhere } from "@/lib/scope";
import { invoiceOwnRowsWhere } from "@/lib/scope-service";

export const dynamic = "force-dynamic";

const SALE_TYPES = ["CASH", "CREDIT", "PARTIAL", "SWAP", "RETURN"] as const;
const PAY_METHODS = ["CASH", "CARD", "TRANSFER", "CHEQUE"] as const;

/**
 * GET  /api/v1/sales/invoices — list (permission: sales.invoices.view)
 *      ?q=number|customer · ?type=CASH|CREDIT · ?status= · ?page= · ?per_page=
 *      ?date_from=ISO · ?date_to=ISO (نطاق تاريخ الفاتورة)
 *      meta.summary = { count, total, paid, due } لكل النتائج المطابقة
 * POST /api/v1/sales/invoices — post a new smart invoice
 *      (permission: sales.invoices.create) — atomic: numbering + stock +
 *      packages + customer balance + audit, all-or-nothing. Credit-exceed
 *      under APPROVAL policy → PENDING_APPROVAL (no effects until approve).
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "sales.invoices.view");
  const url = new URL(req.url);
  const q = url.searchParams.get("q")?.trim() ?? "";
  const type = url.searchParams.get("type");
  const status = url.searchParams.get("status");
  const dateFrom = url.searchParams.get("date_from");
  const dateTo = url.searchParams.get("date_to");
  const page = Math.max(1, Number(url.searchParams.get("page") ?? 1));
  const perPage = Math.min(100, Math.max(1, Number(url.searchParams.get("per_page") ?? 50)));

  const where = {
    companyId: session.companyId,
    deletedAt: null,
    // Branch scope (Phase 12): active branch if selected, else granted set
    ...branchWhere(session),
    // التسلسل الهرمي §6/§7: موظف (SELF/SALES_REP) يرى فواتيره فقط
    ...invoiceOwnRowsWhere(session),
    ...(q ? { OR: [{ number: { contains: q } }, { customer: { name: { contains: q } } }] } : {}),
    ...(type === "CASH" || type === "CREDIT" ? { type } : {}),
    ...(status ? { status } : {}),
    ...(dateFrom || dateTo
      ? {
          invoiceDate: {
            ...(dateFrom ? { gte: new Date(`${dateFrom}T00:00:00`) } : {}),
            ...(dateTo ? { lte: new Date(`${dateTo}T23:59:59.999`) } : {}),
          },
        }
      : {}),
  };

  const [rows, total, agg] = await Promise.all([
    db.salesInvoice.findMany({
      where,
      include: {
        customer: { select: { id: true, code: true, name: true } },
        warehouse: { select: { code: true, name: true } },
        creator: { select: { fullName: true } },
        rep: { select: { fullName: true } },
        _count: { select: { lines: true } },
      },
      orderBy: { id: "desc" },
      skip: (page - 1) * perPage,
      take: perPage,
    }),
    db.salesInvoice.count({ where }),
    db.salesInvoice.aggregate({
      where,
      _count: { _all: true },
      _sum: { grandTotal: true, paidAmount: true },
    }),
  ]);

  // aggregate يعيد Decimal|null → dec() ثم تقريب مالي، وnum() فقط عند الحدود (R10)
  const sumGrand = moneyR(dec(agg._sum.grandTotal));
  const sumPaid = moneyR(dec(agg._sum.paidAmount));
  const summary = {
    count: agg._count._all,
    total: num(sumGrand),
    paid: num(sumPaid),
    due: num(moneyR(sumGrand.minus(sumPaid))),
  };

  return ok(
    rows.map((inv) => ({
      id: inv.id,
      number: inv.number,
      type: inv.type,
      sale_type: inv.saleType,
      status: inv.status,
      credit_exceeded: inv.creditExceeded,
      currency_code: inv.currencyCode,
      invoice_date: inv.invoiceDate,
      due_date: inv.dueDate,
      customer: inv.customer,
      warehouse: inv.warehouse,
      customer_type: inv.customerType,
      rep: inv.rep?.fullName ?? inv.creator.fullName,
      lines_count: inv._count.lines,
      subtotal: num(inv.subtotal),
      discount_total: num(inv.discountTotal),
      tax_total: num(inv.taxTotal),
      grand_total: num(inv.grandTotal),
      paid_amount: num(inv.paidAmount),
      due_amount: num(moneyR(dec(inv.grandTotal).minus(inv.paidAmount))),
      previous_balance: num(inv.previousBalance),
      new_balance: num(inv.newBalance),
      created_by: inv.creator.fullName,
    })),
    { total, page, per_page: perPage, summary }
  );
});

const createSchema = z.object({
  customer_id: z.number().int().positive("اختر العميل"),
  warehouse_id: z.number().int().positive("اختر المستودع"),
  type: z.enum(["CASH", "CREDIT"]),
  sale_type: z.enum(SALE_TYPES).optional(),
  payment_method: z.enum(PAY_METHODS).optional(),
  due_date: z.string().datetime({ offset: true }).optional().nullable().or(z.string().min(8)),
  rep_id: z.number().int().positive().optional().nullable(),
  packaging_details: z.boolean().optional(),
  receiver_name: z.string().trim().max(120).optional().nullable(),
  receiver_phone: z.string().trim().max(40).optional().nullable(),
  rep_notes: z.string().trim().max(500).optional().nullable(),
  customer_notes: z.string().trim().max(500).optional().nullable(),
  admin_notes: z.string().trim().max(500).optional().nullable(),
  notes: z.string().trim().max(500).optional().nullable(),
  paid_amount: z.number().min(0).optional().nullable(), // CREDIT partial
  // ---- Walk-In optional info (Phase 23) --------------------------------
  walkin_name: z.string().trim().max(200).optional().nullable(),
  walkin_phone: z.string().trim().max(40).optional().nullable(),
  walkin_address: z.string().trim().max(300).optional().nullable(),
  // ---- Dual currency (IQD base + USD invoices) --------------------------
  currency_code: z.enum(["IQD", "USD"]).optional(), // العقد snake_case الموحد مع بقية الحقول
  currency: z.enum(["IQD", "USD"]).optional(), // توافق خلفي مع الواجهة — نفس المعنى
  exchange_rate: z.number().positive().max(1_000_000).optional().nullable(), // د.ع لكل $1 — إلزامي مع USD
  // ---- إدخال قائمة قديمة بنفس رقمها المطبوع -------------------------------
  custom_number: z.string().trim().min(1, "الرقم المخصص فارغ").max(40).optional().nullable(),
  // ---- السماح بالصرف رغم نقص المخزون (تجاوز STOCK_001 — يُدوّن في التدقيق) ----
  allow_negative_stock: z.boolean().optional(),
  lines: z
    .array(
      z.object({
        product_id: z.number().int().positive(),
        qty: z.number().positive("كمية البند يجب أن تكون أكبر من صفر").optional(),
        package_qty: z.number().min(0).optional(),
        loose_qty: z.number().min(0).optional(),
        unit: z.enum(["PIECE", "PACKAGE"]).optional(),
        unit_price: z.number().min(0).optional().nullable(),
        price_unit: z.enum(["PIECE", "PACKAGE"]).optional(),
        package_price: z.number().min(0).optional().nullable(), // سعر الكرتونة الصريح (§19)
        piece_price: z.number().min(0).optional().nullable(), // سعر الحبة الصريح
        discount_pct: z.number().min(0).max(100).optional(),
        discount_amount: z.number().min(0).optional(),
      })
    )
    .min(1, "أضف بندًا واحدًا على الأقل"),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "sales.invoices.create");
  const body = await parseBody(req, createSchema);

  const result = await createSalesInvoice(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    {
      customerId: body.customer_id,
      warehouseId: body.warehouse_id,
      type: body.type,
      saleType: body.sale_type,
      paymentMethod: body.payment_method,
      dueDate: body.due_date ?? null,
      repId: body.rep_id ?? null,
      packagingDetails: body.packaging_details,
      receiverName: body.receiver_name ?? null,
      receiverPhone: body.receiver_phone ?? null,
      repNotes: body.rep_notes ?? null,
      customerNotes: body.customer_notes ?? null,
      adminNotes: body.admin_notes ?? null,
      notes: body.notes ?? null,
      paidAmount: body.paid_amount ?? null,
      walkin_name: body.walkin_name ?? null,
      walkin_phone: body.walkin_phone ?? null,
      walkin_address: body.walkin_address ?? null,
      currencyCode: body.currency_code ?? body.currency ?? "IQD", // الاثنان متكافئان — currency_code مقدَّم على العقد
      exchangeRate: body.exchange_rate ?? null,
      customNumber: body.custom_number ?? null,
      allowNegativeStock: body.allow_negative_stock ?? false,
      lines: body.lines.map((l) => ({
        productId: l.product_id,
        qty: l.qty,
        package_qty: l.package_qty,
        loose_qty: l.loose_qty,
        unit: l.unit,
        unit_price: l.unit_price,
        price_unit: l.price_unit,
        package_price: l.package_price,
        piece_price: l.piece_price,
        discount_pct: l.discount_pct,
        discount_amount: l.discount_amount,
      })),
    }
  );

  return ok(result, undefined, 201);
});
