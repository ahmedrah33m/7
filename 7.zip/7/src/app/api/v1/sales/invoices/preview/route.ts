import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { db } from "@/lib/db";
import { Decimal, dec, moneyR, num } from "@/lib/decimal";
import { getInvoiceSettings, getCreditPolicy } from "@/lib/sales-service";
import { packInfoOf, summarizePackages, packSplit, fmtPackText } from "@/lib/packaging";

export const dynamic = "force-dynamic";

const schema = z.object({
  customer_id: z.number().int().positive(),
  warehouse_id: z.number().int().positive(),
  product_ids: z.array(z.number().int().positive()).max(50).optional(),
});

/**
 * POST /api/v1/sales/invoices/preview — smart-invoice pre-flight
 * (permission: sales.invoices.view). Returns the customer card (§2),
 * the APPROVED previous balance (§3 — إلزامي), the mini statement (§22),
 * credit headroom (§6) and the warehouse package state per product (§10/§27).
 */
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "sales.invoices.view");
  const body = await parseBody(req, schema);
  const companyId = session.companyId;

  const customer = await db.customer.findFirst({
    where: { id: body.customer_id, companyId, deletedAt: null },
  });
  if (!customer) return ok({ customer: null });

  // ---- mini statement (§22): last invoice + last payment --------------
  const [lastInvoice, lastPayment, settings, creditPolicy] = await Promise.all([
    db.salesInvoice.findFirst({
      where: { customerId: customer.id, companyId, deletedAt: null, status: { not: "REJECTED" } },
      orderBy: { id: "desc" },
      select: { number: true, invoiceDate: true, grandTotal: true },
    }),
    db.cashTransaction.findFirst({
      where: { customerId: customer.id, companyId, direction: "IN" },
      orderBy: { id: "desc" },
      select: { amount: true, createdAt: true, note: true },
    }),
    getInvoiceSettings(companyId),
    getCreditPolicy(companyId),
  ]);

  const warehouse = await db.warehouse.findFirst({
    where: { id: body.warehouse_id, companyId, deletedAt: null },
    select: { id: true, name: true, code: true },
  });

  // ---- package state per requested product (rep stock view §27) -------
  let packages: Record<string, unknown> = {};
  if (body.product_ids?.length && warehouse) {
    const products = await db.product.findMany({
      where: { id: { in: body.product_ids }, companyId, deletedAt: null },
    });
    const [rows, balances] = await Promise.all([
      db.package.findMany({
        where: {
          companyId, warehouseId: warehouse.id,
          productId: { in: body.product_ids },
          status: { not: "EMPTY" },
        },
        orderBy: { id: "asc" },
      }),
      // أرصدة المستودع — لعرض العبوات للمخزون القديم غير المُزامن مع سجل العبوات
      // (البيع الفعلي يبني العبوات تلقائياً عبر ensurePackageCoverage §31)
      db.stockBalance.findMany({
        where: { warehouseId: warehouse.id, productId: { in: body.product_ids } },
        select: { productId: true, qty: true },
      }),
    ]);
    const balMap = new Map(balances.map((b) => [b.productId, b.qty]));
    const out: Record<string, unknown> = {};
    for (const p of products) {
      const info = packInfoOf(p);
      const mine = rows.filter((r) => r.productId === p.id);
      if (!info.hasPack) {
        // total_pieces = رصيد المستودع الفعلي — ليعرض الواجهة «المتاح» لكل منتج حتى غير المعبأ
        out[String(p.id)] = { has_pack: false, text: p.unit, total_pieces: num(balMap.get(p.id) ?? 0) };
        continue;
      }
      const summarized = summarizePackages(mine, info);
      const balanceQty = balMap.get(p.id) ?? 0;
      if (dec(summarized.total_pieces).lt(dec(balanceQty))) {
        // مخزون قديم بلا صفوف عبوات — اشتق العرض من الرصيد (قراءة فقط، بلا كتابة):
        // يطابق ما سيبنيه الخادم تلقائياً عند الترحيل، ويزيل تحذير STOCK_001 الزائف.
        const { packages: closed, loose } = packSplit(balanceQty, info.packQty);
        out[String(p.id)] = {
          has_pack: true,
          closed_packages: closed,
          open_packages: loose > 0 ? 1 : 0,
          open_qty: loose,
          total_pieces: num(balanceQty),
          text: fmtPackText(num(balanceQty), info),
          open_detail: [],
          pack_unit: info.packUnit,
          pack_qty: info.packQty,
          packages_synced: false,
        };
      } else {
        out[String(p.id)] = { has_pack: true, ...summarized, pack_unit: info.packUnit, pack_qty: info.packQty };
      }
    }
    packages = out;
  }

  const creditLimit = customer.creditLimit; // Prisma Decimal
  const previousBalance = num(moneyR(dec(customer.balance))); // R10 — number للحدود

  return ok({
    customer: {
      id: customer.id,
      code: customer.code,
      name: customer.name,
      shop_name: customer.shopName,
      phone: customer.phone,
      whatsapp: customer.whatsapp,
      address: customer.address,
      area: customer.area,
      status: customer.status,
      credit_limit: num(creditLimit),
      credit_days: customer.creditDays,
      discount_pct: num(customer.discountPct),
      // الرصيد السابق المعتمد — من دفتر الحساب (§47)
      previous_balance: previousBalance,
      has_previous_balance: previousBalance !== 0,
      available_credit: dec(creditLimit).isPositive()
        ? num(moneyR(Decimal.max(new Decimal(0), dec(creditLimit).minus(previousBalance))))
        : null,
      no_debt: previousBalance <= 0,
    },
    warehouse,
    mini_statement: settings.showMiniStatement
      ? {
          last_invoice: lastInvoice
            ? { number: lastInvoice.number, date: lastInvoice.invoiceDate, total: num(lastInvoice.grandTotal) }
            : null,
          last_payment: lastPayment
            ? { amount: num(lastPayment.amount), date: lastPayment.createdAt, note: lastPayment.note }
            : null,
        }
      : null,
    settings: {
      footer_text: settings.footerText,
      packaging_details_default: settings.packagingDetailsDefault,
      open_package_policy: settings.openPackagePolicy,
      credit_exceed_policy: creditPolicy,
    },
    packages,
  });
});
