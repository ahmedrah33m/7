import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { effectiveBranchIds } from "@/lib/scope";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

// ---------------------------------------------------------------------
// POST /api/v1/sales/invoices/[id]/confirm-receipt — تأكيد الاستلام
// (تطوير الفاتورة — جولة 2): تسجيل المستلم + توقيع العميل على الفاتورة.
// القواعد:
//   · الفاتورة معتمدة (POSTED) فقط — المعلقة/المرفوضة/الملغاة لا تُوقَّع
//   · ضمن نطاق الفرع (IDOR يُجاب 404 مثل سجل غير موجود)
//   · التوقيع غير قابل للتكرار (signed_at يُضبط مرة واحدة)
// ---------------------------------------------------------------------
const bodySchema = z.object({
  receiver_name: z.string().trim().min(2, "اسم المستلم إلزامي").max(120),
  receiver_phone: z.string().trim().max(30).optional().nullable(),
});

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.invoices.edit");
  const { id } = await ctx.params;
  const invoiceId = Number(id);
  if (!Number.isInteger(invoiceId)) throw new ApiError("VAL_003", "معرّف فاتورة غير صالح");
  const body = await parseBody(req, bodySchema);

  const inv = await db.salesInvoice.findFirst({
    where: { id: invoiceId, companyId: session.companyId, deletedAt: null },
    select: { id: true, number: true, status: true, branchId: true, signedAt: true, deliveredAt: true, receiverName: true },
  });
  // IDOR guard: 404 بلا تسريب — نفس سلوك GET التفاصيل
  if (!inv || !effectiveBranchIds(session).includes(inv.branchId)) {
    throw new ApiError("VAL_003", "الفاتورة غير موجودة");
  }

  if (inv.status !== "POSTED") {
    throw new ApiError("VAL_004", "لا يمكن تأكيد الاستلام إلا لفاتورة معتمدة (POSTED)");
  }
  if (inv.signedAt) {
    throw new ApiError("VAL_004", `الفاتورة موقّعة مسبقًا بواسطة ${inv.receiverName ?? "—"} — التوقيع غير قابل للتكرار`);
  }

  const now = new Date();
  const updated = await db.salesInvoice.update({
    where: { id: inv.id },
    data: {
      receiverName: body.receiver_name,
      receiverPhone: body.receiver_phone || null,
      signedAt: now,
      deliveredAt: inv.deliveredAt ?? now,
    },
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    {
      action: "INVOICE_RECEIPT_CONFIRMED",
      module: "sales",
      entityType: "sales_invoice",
      entityId: inv.id,
      newValues: {
        number: inv.number,
        receiver: body.receiver_name,
        signed_at: updated.signedAt,
      },
    }
  );

  return ok({
    id: updated.id,
    number: updated.number,
    receiver_name: updated.receiverName,
    receiver_phone: updated.receiverPhone,
    signed_at: updated.signedAt,
    delivered_at: updated.deliveredAt,
  });
});
