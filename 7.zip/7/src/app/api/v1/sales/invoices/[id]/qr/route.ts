import { NextRequest } from "next/server";
import QRCode from "qrcode";
import { guard } from "@/lib/auth";
import { handler, ok, ApiError } from "@/lib/api";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// =====================================================================
// E-invoice QR (Development pack 2) — صيغة TLV/Base64 القياسية المستخدمة
// في الفوترة الإلكترونية (نمط ZATCA Phase-1 الموسع):
//   Tag1 اسم البائع (UTF-8) · Tag2 الرقم الضريبي/التسجيلي
//   Tag3 الطابع الزمني ISO · Tag4 الإجمالي مع الضريبة
//   Tag5 ضريبة القيمة المضافة
// QR يُولّد SVG (نقاءً رقميًا — قابل للطباعة بلا فقد) + سلسلة TLV الخام
// لأي قارئ/جهة ضريبية. الحقول تُبنى من الفاتورة والشركة — لا تخزين إضافي.
// =====================================================================

function tlv(tag: number, value: string): Buffer {
  const val = Buffer.from(value, "utf8");
  return Buffer.concat([Buffer.from([tag, val.length]), val]);
}

/** GET /api/v1/sales/invoices/[id]/qr — (sales.invoices.view). */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.invoices.view");
  const { id } = await ctx.params;
  const invoiceId = Number(id);
  if (!Number.isInteger(invoiceId)) throw new ApiError("VAL_003", "معرّف فاتورة غير صالح");

  const inv = await db.salesInvoice.findFirst({
    where: { id: invoiceId, companyId: session.companyId, deletedAt: null },
    select: {
      id: true, number: true, invoiceDate: true, grandTotal: true, taxTotal: true,
      company: { select: { name: true, nameEn: true, taxNumber: true } },
    },
  });
  if (!inv) throw new ApiError("VAL_003", "الفاتورة غير موجودة");

  const seller = inv.company.nameEn || inv.company.name;
  const taxNumber = inv.company.taxNumber || "NA";
  const total = inv.grandTotal.toFixed(2);
  const tax = inv.taxTotal.toFixed(2);

  const tlvBuf = Buffer.concat([
    tlv(1, seller),
    tlv(2, taxNumber),
    tlv(3, inv.invoiceDate.toISOString()),
    tlv(4, total),
    tlv(5, tax),
  ]);
  const tlvBase64 = tlvBuf.toString("base64");

  const svg = await QRCode.toString(tlvBase64, {
    type: "svg",
    errorCorrectionLevel: "M",
    margin: 1,
    width: 160,
  });

  return ok({
    invoice: { id: inv.id, number: inv.number },
    seller,
    tax_number: taxNumber,
    issued_at: inv.invoiceDate.toISOString(),
    total: inv.grandTotal,
    vat: inv.taxTotal,
    tlv_base64: tlvBase64,
    svg,
  });
});
