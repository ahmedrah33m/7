import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { ApiError } from "@/lib/api";
import { approveInvoice } from "@/lib/sales-service";
import { z } from "zod";

export const dynamic = "force-dynamic";

const schema = z.object({ reason: z.string().trim().max(300).optional().nullable() });

/**
 * POST /api/v1/sales/invoices/[id]/approve — (sales.invoices.approve)
 * Applies the deferred effects of a PENDING_APPROVAL invoice in ONE
 * transaction: stock OUT + package consumption + ledger + customer
 * balance + POSTED status. (spec §6 — طلب موافقة)
 */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.invoices.approve");
  await parseBody(req, schema).catch(() => ({ reason: null }));
  const { id } = await ctx.params;
  const invoiceId = Number(id);
  if (!Number.isInteger(invoiceId)) throw new ApiError("VAL_003", "الفاتورة غير موجودة"); // 404 — لا نجاح فارغ أبداً

  const result = await approveInvoice(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    invoiceId
  );
  return ok(result);
});
