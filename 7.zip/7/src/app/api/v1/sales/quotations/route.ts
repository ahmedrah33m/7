import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { db } from "@/lib/db";
import { createQuotation } from "@/lib/quotation-service";
import { branchWhere } from "@/lib/scope";
import { ownRowsWhere } from "@/lib/scope-service";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/sales/quotations — list (sales.quotations.view)
 * POST /api/v1/sales/quotations — create DRAFT quotation (sales.quotations.create)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "sales.quotations.view");
  const url = new URL(req.url);
  const status = url.searchParams.get("status") ?? undefined;
  const perPage = Math.min(100, Math.max(1, Number(url.searchParams.get("per_page") ?? 50)));

  const where = {
    companyId: session.companyId,
    ...branchWhere(session),
    // التسلسل الهرمي §6/§7: موظف (SELF/SALES_REP) يرى بياناته فقط
    ...ownRowsWhere(session),
    deletedAt: null,
    ...(status ? { status } : {}),
  };

  const [rows, total] = await Promise.all([
    db.quotation.findMany({
      where,
      include: {
        customer: { select: { code: true, name: true } },
        creator: { select: { fullName: true } },
        lines: { select: { qty: true } },
        convertedInvoice: { select: { number: true } },
      },
      orderBy: { id: "desc" },
      take: perPage,
    }),
    db.quotation.count({ where }),
  ]);

  return ok(
    rows.map((q) => ({
      id: q.id,
      number: q.number,
      status: q.status,
      customer: q.customer,
      quote_date: q.quoteDate,
      valid_until: q.validUntil,
      items: q.lines.length,
      grand_total: q.grandTotal,
      converted_invoice: q.convertedInvoice?.number ?? null,
      notes: q.notes,
      created_by: q.creator.fullName,
      created_at: q.createdAt,
    })),
    { total }
  );
});

const createSchema = z.object({
  customer_id: z.number().int().positive("اختر العميل"),
  valid_until: z.string().datetime().optional().nullable(),
  notes: z.string().trim().max(300).optional().nullable(),
  lines: z
    .array(
      z.object({
        product_id: z.number().int().positive(),
        qty: z.number().positive("الكمية يجب أن تكون أكبر من صفر"),
        unit_price: z.number().min(0).optional(),
        discount_pct: z.number().min(0).max(100).optional(),
      })
    )
    .min(1, "أضف بندًا واحدًا على الأقل"),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "sales.quotations.create");
  const body = await parseBody(req, createSchema);

  const q = await createQuotation(
    { userId: session.userId, companyId: session.companyId, warehouseIds: session.warehouseIds },
    {
      customerId: body.customer_id,
      validUntil: body.valid_until ? new Date(body.valid_until) : null,
      notes: body.notes ?? null,
      lines: body.lines.map((l) => ({
        productId: l.product_id,
        qty: l.qty,
        unitPrice: l.unit_price,
        discountPct: l.discount_pct,
      })),
    }
  );

  return ok(q, undefined, 201);
});
