import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { db } from "@/lib/db";
import { effectiveBranchIds } from "@/lib/scope";
import { setQuotationStatus, convertQuotation } from "@/lib/quotation-service";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/sales/quotations/[id] — detail with lines
 * PATCH /api/v1/sales/quotations/[id] — { status } (DRAFT→SENT→ACCEPTED…)
 * POST /api/v1/sales/quotations/[id] — { pay_mode, paid_amount } → CONVERT
 *      (one-shot; creates a real posted invoice + stock OUT — v14: بلا ولاء)
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.quotations.view");
  const { id } = await ctx.params;
  const q = await db.quotation.findFirst({
    where: {
      id: Number(id),
      companyId: session.companyId,
      deletedAt: null,
      branchId: { in: effectiveBranchIds(session) },
    },
    include: {
      customer: { select: { id: true, code: true, name: true, phone: true, whatsapp: true, balance: true } },
      creator: { select: { fullName: true } },
      convertedInvoice: { select: { id: true, number: true } },
      lines: { include: { product: { select: { code: true, name: true, unit: true } } } },
    },
  });
  if (!q) throw new ApiError("VAL_003", "عرض السعر غير موجود");

  return ok({
    id: q.id,
    uuid: q.uuid, // رمز المعاينة العامة — /verify/<uuid> (مشاركة العملاء)
    number: q.number,
    status: q.status,
    customer: q.customer,
    quote_date: q.quoteDate,
    valid_until: q.validUntil,
    subtotal: q.subtotal,
    discount_total: q.discountTotal,
    tax_total: q.taxTotal,
    grand_total: q.grandTotal,
    notes: q.notes,
    created_by: q.creator.fullName,
    converted_invoice: q.convertedInvoice,
    lines: q.lines.map((l) => ({
      product_id: l.productId,
      code: l.product.code,
      product: l.product.name,
      unit: l.product.unit,
      qty: l.qty,
      unit_price: l.unitPrice,
      discount_pct: l.discountPct,
      line_total: l.lineTotal,
    })),
  });
});

const patchSchema = z.object({
  status: z.enum(["SENT", "ACCEPTED", "REJECTED", "CANCELLED"]),
});

export const PATCH = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.quotations.edit");
  const { id } = await ctx.params;
  const body = await parseBody(req, patchSchema);
  const q = await setQuotationStatus(
    { userId: session.userId, companyId: session.companyId, warehouseIds: session.warehouseIds },
    Number(id),
    body.status
  );
  return ok({ id: q.id, status: q.status });
});

const convertSchema = z.object({
  pay_mode: z.enum(["CASH", "CREDIT"]),
  paid_amount: z.number().min(0).optional(),
});

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.quotations.post");
  const { id } = await ctx.params;
  const body = await parseBody(req, convertSchema);
  const result = await convertQuotation(
    { userId: session.userId, companyId: session.companyId, warehouseIds: session.warehouseIds },
    Number(id),
    body.pay_mode,
    body.paid_amount ?? 0
  );
  return ok(result);
});
