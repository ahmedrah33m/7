import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, ApiError } from "@/lib/api";
import { db } from "@/lib/db";
import { effectiveBranchIds } from "@/lib/scope";
import { writeAudit } from "@/lib/audit";
import { orderWhereForActor } from "@/lib/sales-order-service";

export const dynamic = "force-dynamic";

/** GET /api/v1/sales/orders/[id] — order detail with lines (sales.orders.view). */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.orders.view");
  const { id } = await ctx.params;
  const orderId = Number(id);
  if (!Number.isInteger(orderId)) throw new ApiError("VAL_003", "معرّف غير صالح");

  const order = await db.salesOrder.findFirst({
    where: {
      ...(await orderWhereForActor({
        userId: session.userId,
        companyId: session.companyId,
        warehouseIds: session.warehouseIds,
      })),
      id: orderId,
    },
    include: {
      customer: { select: { id: true, code: true, name: true, phone: true, balance: true } },
      warehouse: { select: { id: true, code: true, name: true } },
      creator: { select: { id: true, fullName: true, username: true } },
      invoice: { select: { id: true, number: true, grandTotal: true } },
      lines: {
        include: { product: { select: { id: true, code: true, name: true, unit: true } } },
        orderBy: { id: "asc" },
      },
    },
  });
  if (!order) throw new ApiError("VAL_003", "أمر البيع غير موجود أو خارج نطاقك");

  // IDOR guard (Phase 13) — the order's warehouse must sit inside the
  // session's effective branch context; otherwise answer 404 (no leak).
  const orderWh = await db.warehouse.findUnique({
    where: { id: order.warehouseId },
    select: { branchId: true },
  });
  if (!orderWh || !effectiveBranchIds(session).includes(orderWh.branchId)) {
    throw new ApiError("VAL_003", "أمر البيع غير موجود أو خارج نطاقك");
  }

  return ok({
    id: order.id,
    number: order.number,
    status: order.status,
    order_date: order.orderDate,
    expected_date: order.expectedDate,
    notes: order.notes,
    subtotal: order.subtotal,
    discount_total: order.discountTotal,
    tax_total: order.taxTotal,
    grand_total: order.grandTotal,
    customer: order.customer,
    warehouse: order.warehouse,
    created_by: order.creator,
    invoice: order.invoice,
    lines: order.lines.map((l) => ({
      id: l.id,
      product: l.product,
      qty: l.qty,
      unit_price: l.unitPrice,
      discount_pct: l.discountPct,
      line_total: l.lineTotal,
    })),
  });
});
