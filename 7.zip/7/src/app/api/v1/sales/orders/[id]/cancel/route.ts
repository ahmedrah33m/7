import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, ApiError } from "@/lib/api";
import { cancelSalesOrder } from "@/lib/sales-order-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/sales/orders/[id]/cancel (sales.orders.cancel)
 *   DRAFT | CONFIRMED → CANCELLED. Invoiced orders are NOT cancellable —
 *   reverse via a sales return instead.
 */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.orders.cancel");
  const { id } = await ctx.params;
  const orderId = Number(id);
  if (!Number.isInteger(orderId)) throw new ApiError("VAL_003", "معرّف غير صالح");

  const result = await cancelSalesOrder(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    orderId
  );
  return ok(result);
});
