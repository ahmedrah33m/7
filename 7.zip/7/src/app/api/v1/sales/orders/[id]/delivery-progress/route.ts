import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, ApiError } from "@/lib/api";
import { orderDeliveryProgress } from "@/lib/delivery-service";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/sales/orders/[id]/delivery-progress
 * تقدم التسليم الجزئي على أمر البيع — لكل بند:
 * ordered / delivered / pending (مخطط بإشعارات معلقة) / remaining
 * + حالة التسليم الإجمالية PENDING|PARTIAL|DELIVERED + قائمة الإشعارات.
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.orders.view");
  const { id } = await ctx.params;
  const orderId = Number(id);
  if (!Number.isInteger(orderId)) throw new ApiError("VAL_003", "معرّف غير صالح");

  const progress = await orderDeliveryProgress(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
    },
    orderId
  );

  return ok(progress);
});
