import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { convertOrderToInvoice } from "@/lib/sales-order-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/sales/orders/[id]/convert (sales.invoices.create)
 *   CONFIRMED order → posted sales invoice via the atomic engine
 *   (stock OUT + credit guard + INV numbering in one transaction).
 *   Body: { type: "CASH" | "CREDIT", paid_amount? }
 *   Double convert → VAL_004 with the original invoice number.
 */
const convertSchema = z.object({
  type: z.enum(["CASH", "CREDIT"]),
  paid_amount: z.number().min(0).optional().nullable(),
});

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.invoices.create");
  const { id } = await ctx.params;
  const orderId = Number(id);
  if (!Number.isInteger(orderId)) throw new ApiError("VAL_003", "معرّف غير صالح");

  const body = await parseBody(req, convertSchema);

  const result = await convertOrderToInvoice(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    orderId,
    { type: body.type, paidAmount: body.paid_amount ?? null }
  );
  return ok(result);
});
