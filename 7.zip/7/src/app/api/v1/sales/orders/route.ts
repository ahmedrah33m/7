import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { createSalesOrder, shapeOrderRow, orderWhereForActor } from "@/lib/sales-order-service";
import { num } from "@/lib/decimal";
import { branchWhere } from "@/lib/scope";
import { ownRowsWhere } from "@/lib/scope-service";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/sales/orders — list (sales.orders.view)
 *      ?status=DRAFT|CONFIRMED|INVOICED|CANCELLED · ?q=number/customer · ?per_page=
 * POST /api/v1/sales/orders — create DRAFT order (sales.orders.create)
 *      Orders never touch stock/balance — conversion does.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "sales.orders.view");
  const url = new URL(req.url);
  const status = url.searchParams.get("status")?.trim().toUpperCase() ?? "";
  const q = url.searchParams.get("q")?.trim() ?? "";
  const perPage = Math.min(100, Math.max(1, Number(url.searchParams.get("per_page") ?? 50)));

  const base = await orderWhereForActor({
    userId: session.userId,
    companyId: session.companyId,
    warehouseIds: session.warehouseIds,
  });

  const where = {
    ...base,
    ...branchWhere(session),
    // التسلسل الهرمي §6/§7: موظف (SELF/SALES_REP) يرى بياناته فقط
    ...ownRowsWhere(session),
    ...(status && ["DRAFT", "CONFIRMED", "INVOICING", "INVOICED", "CANCELLED"].includes(status) ? { status } : {}),
    ...(q ? { OR: [{ number: { contains: q } }, { customer: { name: { contains: q } } }] } : {}),
  };

  const [rows, total] = await Promise.all([
    db.salesOrder.findMany({
      where,
      include: {
        customer: { select: { id: true, code: true, name: true } },
        warehouse: { select: { id: true, code: true, name: true } },
        creator: { select: { id: true, fullName: true, username: true } },
        invoice: { select: { id: true, number: true } },
        _count: { select: { lines: true } },
      },
      orderBy: { id: "desc" },
      take: perPage,
    }),
    db.salesOrder.count({ where }),
  ]);

  // R10 — shapeOrderRow يقبل numbers: حوّل الحقول المالية عند الحدود فقط
  return ok(
    rows.map((o) => shapeOrderRow({ ...o, grandTotal: num(o.grandTotal), subtotal: num(o.subtotal), discountTotal: num(o.discountTotal) })),
    { total, per_page: perPage }
  );
});

const lineSchema = z.object({
  product_id: z.number().int().positive(),
  qty: z.number().positive(),
  unit_price: z.number().min(0).optional(),
  discount_pct: z.number().min(0).max(100).optional(),
});

const createSchema = z.object({
  customer_id: z.number().int().positive(),
  warehouse_id: z.number().int().positive(),
  notes: z.string().trim().max(500).optional().nullable(),
  expected_date: z.string().trim().max(30).optional().nullable(),
  lines: z.array(lineSchema).min(1, "أضف بندًا واحدًا على الأقل"),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "sales.orders.create");
  const body = await parseBody(req, createSchema);

  const result = await createSalesOrder(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    {
      customerId: body.customer_id,
      warehouseId: body.warehouse_id,
      notes: body.notes ?? null,
      expectedDate: body.expected_date ?? null,
      lines: body.lines.map((l) => ({
        productId: l.product_id,
        qty: l.qty,
        unitPrice: l.unit_price,
        discountPct: l.discount_pct,
      })),
    }
  );

  return ok(result, undefined, 201);
});
