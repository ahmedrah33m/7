import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { db } from "@/lib/db";
import { effectiveBranchIds } from "@/lib/scope";
import { deliverDeliveryNote, cancelDeliveryNote, type DeliverLineInput } from "@/lib/delivery-service";
import { dec, num } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET   /api/v1/sales/delivery-notes/[id] — detail with lines (§2 الكميات الأربعة)
 * PATCH /api/v1/sales/delivery-notes/[id] — { action: "deliver" | "cancel",
 *          received_by?, lines?: [{ line_id, qty }] — التسليم الجزئي الفعلي }
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.delivery_notes.view");
  const { id } = await ctx.params;
  const dn = await db.deliveryNote.findFirst({
    where: {
      id: Number(id),
      companyId: session.companyId,
      deletedAt: null,
      branchId: { in: effectiveBranchIds(session) },
    },
    include: {
      customer: { select: { id: true, code: true, name: true, phone: true } },
      warehouse: { select: { id: true, code: true, name: true } },
      invoice: { select: { id: true, number: true } },
      salesOrder: { select: { id: true, number: true, status: true } },
      creator: { select: { id: true, fullName: true } },
      deliverer: { select: { id: true, fullName: true } },
      canceller: { select: { id: true, fullName: true } },
      lines: {
        include: { product: { select: { id: true, code: true, name: true, unit: true, packUnit: true } } },
        orderBy: { id: "asc" },
      },
    },
  });
  if (!dn) throw new ApiError("VAL_003", "إشعار التسليم غير موجود");

  return ok({
    id: dn.id,
    number: dn.number,
    status: dn.status,
    customer: dn.customer,
    invoice: dn.invoice,
    sales_order: dn.salesOrder,
    warehouse: dn.warehouse,
    ship_date: dn.shipDate,
    delivered_at: dn.deliveredAt,
    cancelled_at: dn.cancelledAt,
    driver: dn.driver,
    driver_phone: dn.driverPhone,
    address: dn.address,
    received_by: dn.receivedBy,
    notes: dn.notes,
    created_by: dn.creator.fullName,
    delivered_by: dn.deliverer?.fullName ?? null,
    cancelled_by: dn.canceller?.fullName ?? null,
    lines: dn.lines.map((l) => ({
      id: l.id,
      product: l.product,
      sales_order_line_id: l.salesOrderLineId,
      invoice_line_id: l.invoiceLineId,
      ordered_qty: num(l.orderedQty),
      previously_delivered_qty: num(l.previouslyDeliveredQty),
      current_delivered_qty: num(l.currentDeliveredQty),
      remaining_qty: num(l.remainingQty),
      package_qty: num(l.packageQty),
      loose_qty: num(l.looseQty),
      package_type: l.packageType,
      package_conversion: num(l.packageConversion),
      note: l.note,
      // «متاح للتسليم الآن» من منظور هذا الإشعار عند إنشائه (لقطات ثابتة)
      deliverable_qty: num(dec(l.orderedQty).minus(dec(l.previouslyDeliveredQty))),
    })),
  });
});

const deliverLineSchema = z.object({
  line_id: z.number().int().positive(),
  qty: z.number().min(0),
});

const patchSchema = z
  .object({
    action: z.enum(["deliver", "cancel"]),
    received_by: z.string().trim().max(120).optional().nullable(),
    lines: z.array(deliverLineSchema).max(100).optional().nullable(),
  });

export const PATCH = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.delivery_notes.edit");
  const { id } = await ctx.params;
  const body = await parseBody(req, patchSchema);

  const c = { userId: session.userId, companyId: session.companyId, warehouseIds: session.warehouseIds };
  if (body.action === "deliver") {
    const dn = await deliverDeliveryNote(c, Number(id), {
      receivedBy: body.received_by ?? null,
      lines: (body.lines ?? null) as DeliverLineInput[] | null,
    });
    return ok({
      id: dn.id,
      status: dn.status,
      delivered_at: dn.deliveredAt,
      lines: dn.lines.map((l) => ({
        id: l.id,
        current_delivered_qty: num(l.currentDeliveredQty),
        remaining_qty: num(l.remainingQty),
      })),
    });
  }
  const dn = await cancelDeliveryNote(c, Number(id));
  return ok({ id: dn.id, status: dn.status, cancelled_at: dn.cancelledAt });
});
