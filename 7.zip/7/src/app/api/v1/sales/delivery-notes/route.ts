import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { db } from "@/lib/db";
import { createDeliveryNote, type DeliveryLineInput } from "@/lib/delivery-service";
import { branchWhere } from "@/lib/scope";
import { ownRowsWhere } from "@/lib/scope-service";
import { num } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/sales/delivery-notes — list (sales.delivery_notes.view)
 *      ?status=PENDING|PARTIAL|DELIVERED|CANCELLED&order_id=&per_page=
 * POST /api/v1/sales/delivery-notes — create PENDING note (sales.delivery_notes.create)
 *      المصدر: order_id (أساسي — بنود = كل المتبقي أو explicit) | invoice_id | مستقل ببنود يدوية
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "sales.delivery_notes.view");
  const url = new URL(req.url);
  const status = url.searchParams.get("status") ?? undefined;
  const orderId = Number(url.searchParams.get("order_id") ?? 0) || undefined;
  const perPage = Math.min(100, Math.max(1, Number(url.searchParams.get("per_page") ?? 50)));

  const where = {
    companyId: session.companyId,
    ...branchWhere(session),
    // التسلسل الهرمي §6/§7: موظف (SELF/SALES_REP) يرى بياناته فقط
    ...ownRowsWhere(session),
    deletedAt: null,
    ...(status ? { status } : {}),
    ...(orderId ? { salesOrderId: orderId } : {}),
  };

  const [rows, total] = await Promise.all([
    db.deliveryNote.findMany({
      where,
      include: {
        customer: { select: { code: true, name: true, phone: true } },
        warehouse: { select: { code: true, name: true } },
        invoice: { select: { id: true, number: true } },
        salesOrder: { select: { id: true, number: true } },
        creator: { select: { fullName: true } },
        _count: { select: { lines: true } },
      },
      orderBy: { id: "desc" },
      take: perPage,
    }),
    db.deliveryNote.count({ where }),
  ]);

  return ok(
    rows.map((d) => ({
      id: d.id,
      number: d.number,
      status: d.status,
      customer: d.customer,
      invoice: d.invoice?.number ?? null,
      sales_order: d.salesOrder?.number ?? null,
      sales_order_id: d.salesOrderId,
      lines_count: d._count.lines,
      warehouse: d.warehouse,
      ship_date: d.shipDate,
      delivered_at: d.deliveredAt,
      driver: d.driver,
      driver_phone: d.driverPhone,
      address: d.address,
      received_by: d.receivedBy,
      notes: d.notes,
      created_by: d.creator.fullName,
    })),
    { total }
  );
});

const lineSchema = z.object({
  product_id: z.number().int().positive().optional(),
  sales_order_line_id: z.number().int().positive().optional(),
  invoice_line_id: z.number().int().positive().optional(),
  qty: z.number().positive("كمية التسليم يجب أن تكون أكبر من صفر"),
  note: z.string().trim().max(300).optional().nullable(),
});

const createSchema = z
  .object({
    customer_id: z.number().int().positive().optional().nullable(),
    order_id: z.number().int().positive().optional().nullable(),
    invoice_id: z.number().int().positive().optional().nullable(),
    warehouse_id: z.number().int().positive().optional().nullable(),
    driver: z.string().trim().max(120).optional().nullable(),
    driver_phone: z.string().trim().max(30).optional().nullable(),
    address: z.string().trim().max(300).optional().nullable(),
    notes: z.string().trim().max(300).optional().nullable(),
    lines: z.array(lineSchema).max(100).optional().nullable(),
  })
  .refine((v) => v.customer_id || v.order_id || v.invoice_id, {
    message: "حدد المصدر — أمر بيع أو فاتورة أو عميل (مستقل)",
  });

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "sales.delivery_notes.create");
  const body = await parseBody(req, createSchema);

  const dn = await createDeliveryNote(
    { userId: session.userId, companyId: session.companyId, warehouseIds: session.warehouseIds },
    {
      customerId: body.customer_id ?? null,
      orderId: body.order_id ?? null,
      invoiceId: body.invoice_id ?? null,
      warehouseId: body.warehouse_id ?? null,
      driver: body.driver ?? null,
      driverPhone: body.driver_phone ?? null,
      address: body.address ?? null,
      notes: body.notes ?? null,
      lines: (body.lines ?? null) as DeliveryLineInput[] | null,
    }
  );

  return ok(
    {
      id: dn.id,
      number: dn.number,
      status: dn.status,
      lines_count: dn.lines.length,
      lines: dn.lines.map((l) => ({
        id: l.id,
        product_id: l.productId,
        sales_order_line_id: l.salesOrderLineId,
        invoice_line_id: l.invoiceLineId,
        ordered_qty: num(l.orderedQty),
        previously_delivered_qty: num(l.previouslyDeliveredQty),
        current_delivered_qty: num(l.currentDeliveredQty),
        remaining_qty: num(l.remainingQty),
        package_qty: num(l.packageQty),
        loose_qty: num(l.looseQty),
        package_type: l.packageType,
        package_conversion: num(l.packageConversion),
      })),
    },
    undefined,
    201
  );
});
