import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { convertDeliveryNoteToInvoice } from "@/lib/delivery-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/sales/delivery-notes/[id]/convert
 * إشعار تسليم مسلَّم (على أمر بيع) → فاتورة بالكميات المسلَّمة فعلاً
 * عبر المحرك المعتمد createSalesInvoice — خصم المخزون مرة واحدة + COGS.
 * body: { type: "CASH" | "CREDIT", paid_amount?, notes? }
 */
const convertSchema = z.object({
  type: z.enum(["CASH", "CREDIT"]),
  paid_amount: z.number().min(0).optional().nullable(),
  notes: z.string().trim().max(500).optional().nullable(),
});

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "sales.delivery_notes.edit");
  const { id } = await ctx.params;
  const body = await parseBody(req, convertSchema);

  const result = await convertDeliveryNoteToInvoice(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    Number(id),
    { type: body.type, paidAmount: body.paid_amount ?? null, notes: body.notes ?? null }
  );

  return ok(result, undefined, 201);
});
