import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { db } from "@/lib/db";
import { createSalesReturn } from "@/lib/returns-service";
import { branchWhere } from "@/lib/scope";
import { ownRowsWhere } from "@/lib/scope-service";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/sales/returns — list (sales.returns.view)
 * POST /api/v1/sales/returns — post return against an invoice
 *      (sales.returns.create) — atomic: numbering + stock IN + receivable
 *      relief (credit note) + optional cash refund via the cash ledger.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "sales.returns.view");
  const url = new URL(req.url);
  const q = url.searchParams.get("q")?.trim() ?? "";
  const perPage = Math.min(100, Math.max(1, Number(url.searchParams.get("per_page") ?? 50)));

  const where = {
    companyId: session.companyId,
    ...branchWhere(session),
    // التسلسل الهرمي §6/§7: موظف (SELF/SALES_REP) يرى بياناته فقط
    ...ownRowsWhere(session),
    deletedAt: null,
    ...(q ? { OR: [{ number: { contains: q } }, { invoice: { number: { contains: q } } }, { customer: { name: { contains: q } } }] } : {}),
  };

  const [rows, total] = await Promise.all([
    db.salesReturn.findMany({
      where,
      include: {
        customer: { select: { id: true, code: true, name: true, whatsapp: true } },
        invoice: { select: { id: true, number: true } },
        warehouse: { select: { code: true, name: true } },
        creator: { select: { fullName: true } },
        _count: { select: { lines: true } },
      },
      orderBy: { id: "desc" },
      take: perPage,
    }),
    db.salesReturn.count({ where }),
  ]);

  return ok(
    rows.map((r) => ({
      id: r.id,
      number: r.number,
      return_date: r.returnDate,
      customer: r.customer,
      invoice: r.invoice,
      warehouse: r.warehouse,
      lines_count: r._count.lines,
      total_amount: r.totalAmount,
      credit_note: r.creditNote,
      refund_cash: r.refundCash,
      status: r.status,
      created_by: r.creator.fullName,
    })),
    { total }
  );
});

const createSchema = z.object({
  invoice_id: z.number().int().positive("اختر الفاتورة"),
  cashbox_id: z.number().int().positive().optional().nullable(),
  refund_cash: z.number().min(0).optional().default(0),
  notes: z.string().trim().max(500).optional().nullable(),
  lines: z
    .array(
      z.object({
        invoice_line_id: z.number().int().positive(),
        qty: z.number().positive("كمية المرتجع يجب أن تكون أكبر من صفر"),
        // §30: حالة العبوة المرتجعة — مغلقة كاملة / حبات من عبوة مفتوحة / تالفة
        package_condition: z.enum(["SEALED", "OPENED", "DAMAGED"]).optional(),
      })
    )
    .min(1, "أضف بندًا واحدًا على الأقل"),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "sales.returns.create");
  const body = await parseBody(req, createSchema);

  const result = await createSalesReturn(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    {
      invoiceId: body.invoice_id,
      cashboxId: body.cashbox_id ?? null,
      refundCash: body.refund_cash ?? 0,
      notes: body.notes ?? null,
      lines: body.lines.map((l) => ({ invoiceLineId: l.invoice_line_id, qty: l.qty, package_condition: l.package_condition })),
    }
  );

  return ok(result, undefined, 201);
});
