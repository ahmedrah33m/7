import { NextRequest } from "next/server";
import { handler, ok, ApiError, enforceRateLimit, clientContext } from "@/lib/api";
import { verifyByToken } from "@/lib/sales-service";
import { verifyQuotationByToken } from "@/lib/quotation-service";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/verify/[token] — PUBLIC document verification (spec §37 + مشاركة العملاء).
 * الرمز هو التصريح الوحيد: QR الفاتورة يحمل verifyToken، ورابط عرض السعر يحمل uuid.
 * يستجيب بنوع المستند: kind=INVOICE (فاتورة كاملة) أو kind=QUOTATION (عرض سعر).
 * Rate-limited per IP to prevent token enumeration.
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const { ip } = clientContext(req);
  enforceRateLimit(`verify:${ip}`, 60);

  const { token } = await ctx.params;
  if (!token || token.length < 8 || !/^[a-f0-9-]+$/i.test(token)) {
    throw new ApiError("VAL_003", "رمز تحقق غير صالح");
  }

  const result = (await verifyByToken(token)) ?? (await verifyQuotationByToken(token));
  if (!result) {
    return ok({ valid: false, message: "لا يوجد مستند بهذا الرمز — قد يكون الرابط غير صحيح أو مزيف" });
  }
  return ok(result);
});
