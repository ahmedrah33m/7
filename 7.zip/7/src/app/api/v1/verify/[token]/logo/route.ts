import { NextRequest, NextResponse } from "next/server";
import { handler, clientContext, enforceRateLimit } from "@/lib/api";
import { db } from "@/lib/db";
import { storage } from "@/lib/storage";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/verify/[token]/logo — PUBLIC company logo for the shared
 * invoice/quotation page. الرمز هو التصريح: الصفحة العامة للأصل نفسه قد
 * تعرض شعار صاحب المستند فقط. /api/v1/files محمية بمصادقة ولا تصلح هنا،
 * لذا تُقرأ بايتات الشعار مباشرة من طبقة التخزين باسم ملفها المستخرج من
 * Company.logoUrl (/api/v1/files/<name>) — 404 عند غياب الشعار (بلا كشف).
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const { ip } = clientContext(req);
  enforceRateLimit(`verify-logo:${ip}`, 60);

  const { token } = await ctx.params;
  if (!token || token.length < 8 || !/^[a-f0-9-]+$/i.test(token)) {
    return new NextResponse("Not found", { status: 404 });
  }

  const [inv, qtn] = await Promise.all([
    db.salesInvoice.findFirst({
      where: { verifyToken: token, deletedAt: null },
      select: { company: { select: { logoUrl: true } } },
    }),
    db.quotation.findFirst({
      where: { uuid: token, deletedAt: null },
      select: { company: { select: { logoUrl: true } } },
    }),
  ]);
  const logoUrl = inv?.company.logoUrl ?? qtn?.company.logoUrl ?? null;
  if (!logoUrl) return new NextResponse("Not found", { status: 404 });

  // الشعار دائماً بالشكل /api/v1/files/<name> — آخر مقطع هو اسم الملف
  const name = logoUrl.split("/").filter(Boolean).pop();
  if (!name || name.includes("..") || name.includes("/")) {
    return new NextResponse("Not found", { status: 404 });
  }

  const row = await storage.read(name);
  if (!row || !row.mime.startsWith("image/")) {
    return new NextResponse("Not found", { status: 404 });
  }

  return new NextResponse(new Uint8Array(row.data), {
    status: 200,
    headers: {
      "Content-Type": row.mime,
      "Content-Length": String(row.data.length),
      // عام لأن الصفحة نفسها عامة — TTL قصير كي ينعكس تغيير الشعار سريعاً
      "Cache-Control": "public, max-age=300",
      "X-Content-Type-Options": "nosniff",
    },
  });
});
