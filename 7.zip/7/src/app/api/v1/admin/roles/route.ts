import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

/** GET /api/v1/admin/roles — roles with their permission codes (system.roles.view). */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.roles.view");

  const roles = await db.role.findMany({
    where: { companyId: session.companyId, deletedAt: null },
    select: {
      id: true,
      code: true,
      name: true,
      description: true,
      isSystem: true,
      permissions: { select: { permission: { select: { code: true, module: true } } } },
      users: { select: { userId: true } },
    },
    orderBy: { id: "asc" },
  });

  return ok(
    roles.map((r) => ({
      id: r.id,
      code: r.code,
      name: r.name,
      description: r.description,
      is_system: r.isSystem,
      users_count: new Set(r.users.map((u) => u.userId)).size,
      permissions: r.permissions.map((p) => p.permission.code),
      modules: Array.from(new Set(r.permissions.map((p) => p.permission.module))),
    })),
    { total: roles.length }
  );
});

// ---------------------------------------------------------------------
// PATCH — تعديل الدور: الاسم/الوصف + استبدال صلاحياته الذرية كاملة
// حواجز الحماية:
//   · الدور ملك حصري للشركة النشطة (عزل Tenant صارم)
//   · صلاحيات دور المالك (OWNER) محمية — خط الدفاع الأخير ضد القفل الذاتي
//   · لا يمكن تعديل صلاحيات دورٍ تملكه أنت بنفسك — استخدم مالكًا آخر
//   · أي دور يبقى بصلاحية واحدة على الأقل (لا أدوار فارغة)
// ---------------------------------------------------------------------
const patchSchema = z.object({
  role_id: z.number().int().positive(),
  name: z.string().trim().min(2).max(120).optional(),
  description: z.string().trim().max(500).optional().nullable(),
  permissions: z.array(z.string().trim().min(3).max(120)).min(1, "يجب إبقاء صلاحية واحدة على الأقل").optional(),
});

export const PATCH = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.roles.edit");
  const body = await parseBody(req, patchSchema);

  // العزل الصارم: الدور يجب أن يتبع الشركة النشطة — لا تعديل عابرًا للشركات
  const role = await db.role.findFirst({
    where: { id: body.role_id, companyId: session.companyId, deletedAt: null },
    select: { id: true, code: true, name: true, isSystem: true, users: { select: { userId: true } } },
  });
  if (!role) throw new ApiError("VAL_003", "الدور غير موجود في الشركة النشطة — الأدوار ملك حصري لشركتها");

  let permissionsChanged = false;

  if (body.permissions) {
    if (role.code === "OWNER") {
      throw new ApiError("PERM_002", "صلاحيات دور المالك (OWNER) محمية ولا يمكن تعديلها — خط الدفاع الأخير ضد قفل النظام");
    }
    if (role.users.some((u) => u.userId === session.userId)) {
      throw new ApiError("PERM_001", "لا يمكنك تعديل صلاحيات دورٍ تملكه بنفسك — اطلب من مالك آخر تنفيذ ذلك");
    }
    const codes = [...new Set(body.permissions)];
    const perms = await db.permission.findMany({ where: { code: { in: codes } }, select: { id: true, code: true } });
    if (perms.length !== codes.length) {
      throw new ApiError("VAL_003", "إحدى الصلاحيات المحددة غير موجودة في كتالوج النظام");
    }
    await db.$transaction(async (tx) => {
      await tx.rolePermission.deleteMany({ where: { roleId: role.id, companyId: session.companyId } });
      for (const p of perms) {
        await tx.rolePermission.create({ data: { companyId: session.companyId, roleId: role.id, permissionId: p.id } });
      }
    });
    permissionsChanged = true;
  }

  const updated = await db.role.update({
    where: { id: role.id },
    data: {
      ...(body.name ? { name: body.name } : {}),
      ...(body.description !== undefined ? { description: body.description } : {}),
      updatedBy: session.userId,
    },
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    {
      action: permissionsChanged ? "ROLE_PERMISSIONS_CHANGED" : "ROLE_UPDATED",
      module: "system",
      entityType: "role",
      entityId: role.id,
      oldValues: { name: role.name },
      newValues: { code: role.code, name: updated.name, permissions_replaced: permissionsChanged, permissions_count: body.permissions?.length ?? undefined },
    }
  );

  const fresh = await db.role.findFirst({
    where: { id: role.id },
    select: { permissions: { select: { permission: { select: { code: true } } } } },
  });

  return ok({
    id: updated.id,
    code: updated.code,
    name: updated.name,
    description: updated.description,
    permissions: fresh?.permissions.map((p) => p.permission.code) ?? [],
  });
});
