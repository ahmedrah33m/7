import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

/**
 * PATCH  /api/v1/admin/branches/[id] — edit (system.branches.edit)
 * DELETE /api/v1/admin/branches/[id] — soft delete (system.branches.delete)
 *          blocked when active warehouses/users still attached.
 */
const patchSchema = z.object({
  name: z.string().trim().min(2).max(120).optional(),
  phone: z.string().trim().max(30).optional().nullable(),
  address: z.string().trim().max(300).optional().nullable(),
  city: z.string().trim().max(80).optional().nullable(),
  is_active: z.boolean().optional(),
});

export const PATCH = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "system.branches.edit");
  const { id } = await ctx.params;

  const branch = await db.branch.findFirst({
    where: { id: Number(id), companyId: session.companyId, deletedAt: null },
  });
  if (!branch) throw new ApiError("VAL_003", "الفرع غير موجود");

  const body = await parseBody(req, patchSchema);
  const updated = await db.branch.update({
    where: { id: branch.id },
    data: {
      ...(body.name !== undefined ? { name: body.name } : {}),
      ...(body.phone !== undefined ? { phone: body.phone } : {}),
      ...(body.address !== undefined ? { address: body.address } : {}),
      ...(body.city !== undefined ? { city: body.city } : {}),
      ...(body.is_active !== undefined ? { isActive: body.is_active } : {}),
      updatedBy: session.userId,
    },
  });

  return ok({ id: updated.id, name: updated.name, is_active: updated.isActive });
});

export const DELETE = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "system.branches.delete");
  const { id } = await ctx.params;

  const branch = await db.branch.findFirst({
    where: { id: Number(id), companyId: session.companyId, deletedAt: null },
    include: {
      warehouses: { where: { deletedAt: null }, select: { id: true } },
      users: { where: { deletedAt: null }, select: { id: true } },
    },
  });
  if (!branch) throw new ApiError("VAL_003", "الفرع غير موجود");

  if (branch.warehouses.length > 0) {
    throw new ApiError("BRN_001", `لا يمكن حذف الفرع — يحتوي ${branch.warehouses.length} مستودعًا نشطًا`);
  }
  if (branch.users.length > 0) {
    throw new ApiError("BRN_001", `لا يمكن حذف الفرع — مرتبط بـ ${branch.users.length} مستخدمًا`);
  }

  await db.branch.update({ where: { id: branch.id }, data: { deletedAt: new Date(), isActive: false, updatedBy: session.userId } });
  return ok({ id: branch.id, deleted: true });
});
