import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { db } from "@/lib/db";
import { moneyR, num, sumOf } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/admin/branches — list (system.branches.view)
 * POST /api/v1/admin/branches — create (system.branches.create)
 * Soft-unique per company+code; warehouses count included for overview.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.branches.view");

  const rows = await db.branch.findMany({
    where: { companyId: session.companyId, deletedAt: null },
    include: {
      warehouses: { where: { deletedAt: null }, select: { id: true, name: true } },
      users: { where: { deletedAt: null }, select: { id: true } },
      salesInvoices: { select: { grandTotal: true, paidAmount: true } },
    },
    orderBy: { id: "asc" },
  });

  return ok(
    rows.map((b) => ({
      id: b.id,
      code: b.code,
      name: b.name,
      phone: b.phone,
      address: b.address,
      city: b.city,
      is_active: b.isActive,
      warehouses: b.warehouses,
      users_count: b.users.length,
      invoices_count: b.salesInvoices.length,
      revenue: num(moneyR(sumOf(b.salesInvoices, (i) => i.grandTotal))),
      created_at: b.createdAt,
    }))
  );
});

const createSchema = z.object({
  code: z
    .string()
    .trim()
    .min(1, "كود الفرع مطلوب")
    .max(20)
    .regex(/^[A-Za-z0-9_-]+$/, "كود الفرع: حروف لاتينية وأرقام و - و _ فقط"),
  name: z.string().trim().min(2, "اسم الفرع مطلوب").max(120),
  phone: z.string().trim().max(30).optional().nullable(),
  address: z.string().trim().max(300).optional().nullable(),
  city: z.string().trim().max(80).optional().nullable(),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.branches.create");
  const body = await parseBody(req, createSchema);

  const dup = await db.branch.findFirst({
    where: { companyId: session.companyId, code: body.code, deletedAt: null },
    select: { id: true },
  });
  if (dup) throw new ApiError("VAL_002", `كود الفرع «${body.code}» مستخدم مسبقًا`);

  const branch = await db.branch.create({
    data: {
      companyId: session.companyId,
      code: body.code,
      name: body.name,
      phone: body.phone ?? null,
      address: body.address ?? null,
      city: body.city ?? null,
      createdBy: session.userId,
    },
  });

  return ok(branch, undefined, 201);
});
