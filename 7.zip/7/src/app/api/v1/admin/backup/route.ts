import { NextRequest, NextResponse } from "next/server";
import { guard } from "@/lib/auth";
import { handler } from "@/lib/api";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/admin/backup — نسخة احتياطية شاملة JSON (Development pack 2).
 * الصلاحية: system.settings.edit (المالك/مدير النظام/مدير الفرع).
 * كل الجداول داخل نطاق الشركة الواحدة، مع حذف حقول الأسرار ( hashes )
 * — الملف تنزيل مباشر باسم backup-{company}-{date}.json.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.settings.edit");
  const companyId = session.companyId;

  const scope = (extra: object = {}) => ({ companyId, ...extra });

  const [
    company, branches, warehouses, users, roles, rolePermissions, userRoles,
    settings, sequences, categories, products, customers, suppliers,
    stockBalances, stockMovements, salesInvoices, salesInvoiceLines,
    salesOrders, salesOrderLines, purchaseInvoices, purchaseInvoiceLines,
    salesReturns, salesReturnLines, stockTransfers, stockTransferLines,
    cashboxes, cashTransactions, commissionRules, commissions, repTargets,
    visits, routes, routeCustomers, b2bOrders, b2bOrderLines, loyaltyTransactions,
    auditLogs,
  ] = await Promise.all([
    db.company.findMany({ where: { id: companyId } }),
    db.branch.findMany({ where: scope() }),
    db.warehouse.findMany({ where: scope() }),
    db.user.findMany({ where: scope() }),
    db.role.findMany({ where: scope() }),
    db.rolePermission.findMany({ where: { role: { companyId } } }),
    db.userRole.findMany({ where: { user: { companyId } } }),
    db.setting.findMany({ where: scope() }),
    db.documentSequence.findMany({ where: scope() }),
    db.category.findMany({ where: scope() }),
    db.product.findMany({ where: scope() }),
    db.customer.findMany({ where: scope() }),
    db.supplier.findMany({ where: scope() }),
    db.stockBalance.findMany({ where: scope() }),
    db.stockMovement.findMany({ where: scope(), orderBy: { id: "asc" }, take: 20_000 }),
    db.salesInvoice.findMany({ where: scope(), orderBy: { id: "asc" }, take: 20_000 }),
    db.salesInvoiceLine.findMany({ where: { invoice: { companyId } }, take: 100_000 }),
    db.salesOrder.findMany({ where: scope(), orderBy: { id: "asc" }, take: 20_000 }),
    db.salesOrderLine.findMany({ where: { order: { companyId } }, take: 100_000 }),
    db.purchaseInvoice.findMany({ where: scope(), orderBy: { id: "asc" }, take: 20_000 }),
    db.purchaseInvoiceLine.findMany({ where: { invoice: { companyId } }, take: 100_000 }),
    db.salesReturn.findMany({ where: scope(), orderBy: { id: "asc" }, take: 20_000 }),
    db.salesReturnLine.findMany({ where: { returnDoc: { companyId } }, take: 100_000 }),
    db.stockTransfer.findMany({ where: scope(), orderBy: { id: "asc" }, take: 20_000 }),
    db.stockTransferLine.findMany({ where: { transfer: { companyId } }, take: 100_000 }),
    db.cashbox.findMany({ where: scope() }),
    db.cashTransaction.findMany({ where: scope(), orderBy: { id: "asc" }, take: 50_000 }),
    db.commissionRule.findMany({ where: scope() }),
    db.commission.findMany({ where: scope(), take: 50_000 }),
    db.repTarget.findMany({ where: scope() }),
    db.visit.findMany({ where: scope(), orderBy: { id: "asc" }, take: 50_000 }),
    db.route.findMany({ where: scope() }),
    db.routeCustomer.findMany({ where: { route: { companyId } } }),
    db.b2BOrder.findMany({ where: scope(), orderBy: { id: "asc" }, take: 20_000 }),
    db.b2BOrderLine.findMany({ where: { order: { companyId } }, take: 100_000 }),
    db.loyaltyTransaction.findMany({ where: scope(), orderBy: { id: "asc" }, take: 100_000 }),
    db.auditLog.findMany({ where: scope(), orderBy: { id: "asc" }, take: 50_000 }),
  ]);

  // أسرار لا تُصدَّر أبدًا
  const safeUsers = users.map((u) => ({
    ...u,
    passwordHash: "«محجوب»",
  }));

  const payload = {
    meta: {
      kind: "sds-full-backup",
      schema_version: 2,
      generated_at: new Date().toISOString(),
      generated_by: session.userId,
      company: company[0]?.name ?? `company#${companyId}`,
      counts: {
        users: safeUsers.length, products: products.length, customers: customers.length,
        suppliers: suppliers.length, sales_invoices: salesInvoices.length,
        sales_orders: salesOrders.length, purchase_invoices: purchaseInvoices.length,
        returns: salesReturns.length, transfers: stockTransfers.length,
        cash_transactions: cashTransactions.length, visits: visits.length,
        b2b_orders: b2bOrders.length, loyalty_transactions: loyaltyTransactions.length,
        audit_logs: auditLogs.length,
      },
    },
    data: {
      company, branches, warehouses, users: safeUsers, roles, role_permissions: rolePermissions,
      user_roles: userRoles, settings, document_sequences: sequences,
      categories, products, customers, suppliers,
      stock_balances: stockBalances, stock_movements: stockMovements,
      sales_invoices: salesInvoices, sales_invoice_lines: salesInvoiceLines,
      sales_orders: salesOrders, sales_order_lines: salesOrderLines,
      purchase_invoices: purchaseInvoices, purchase_invoice_lines: purchaseInvoiceLines,
      sales_returns: salesReturns, sales_return_lines: salesReturnLines,
      stock_transfers: stockTransfers, stock_transfer_lines: stockTransferLines,
      cashboxes, cash_transactions: cashTransactions,
      commission_rules: commissionRules, commissions, rep_targets: repTargets,
      visits, routes, route_customers: routeCustomers,
      b2b_orders: b2bOrders, b2b_order_lines: b2bOrderLines,
      loyalty_transactions: loyaltyTransactions, audit_logs: auditLogs,
    },
  };

  const companySlug = String(company[0]?.name ?? "company").replace(/[^\p{L}\p{N}]+/gu, "-").slice(0, 30);
  const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-");
  // SQLite قد يُرجع بعض المعرّفات BigInt — نحوّلها بأمان إلى أرقام
  const body = JSON.stringify(
    payload,
    (_k, v) => (typeof v === "bigint" ? Number(v) : v),
    1
  );

  return new NextResponse(body, {
    status: 200,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="backup-${encodeURIComponent(companySlug)}-${stamp}.json"`,
      "Cache-Control": "no-store",
    },
  });
});

// guard-only wrapper fallback (kept for handler typing consistency)
export const runtime = "nodejs";
