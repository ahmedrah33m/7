import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError, clientContext } from "@/lib/api";
import { db } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { subscriptionInfo, revokeCompanySessions } from "@/lib/subscription";

export const dynamic = "force-dynamic";

/**
 * PATCH /api/v1/admin/companies/[id] — تعديل بيانات الشركة + إدارة الاشتراك
 * (system.company.edit):
 *   · identity: الاسم/الهاتف/الضريبي... (الاسم = هوية كل فواتير الشركة)
 *   · subscription: subscription_ends_at (ISO أو null = مفتوح) + is_suspended
 *     + subscription_note — التعليق أو ضبط تاريخ ماضٍ يُنهي كل جلسات الشركة
 *   · kill_sessions: true → إنهاء فوري لكل جلسات مستخدمي الشركة
 *
 * DELETE /api/v1/admin/companies/[id] — حذف شركة (system.company.delete):
 *   · حذف ناعم (deleted_at) — البيانات تبقى قابلة للفحص/الاستعادة من القاعدة
 *   · تختفي فورًا من: القوائم، مبدّل الشركة، شاشة اختيار الشركة عند الدخول،
 *     نطاق الجلسات (resolveScope يرشح الشركات المحذوفة)
 *   · إنهاء فوري لكل جلسات مستخدمي الشركة (refresh tokens + access)
 *   · لا يُحذف نظامياً إلا بقرار صريح — سجل تدقيق كامل باللقطتين
 */
const patchSchema = z.object({
  name: z.string().trim().min(2, "اسم الشركة مطلوب").max(160).optional(),
  name_en: z.string().trim().max(160).optional().nullable(),
  legal_name: z.string().trim().max(200).optional().nullable(),
  tax_number: z.string().trim().max(40).optional().nullable(),
  phone: z.string().trim().max(30).optional().nullable(),
  email: z.string().trim().max(120).email("البريد غير صالح").or(z.literal("")).optional().nullable(),
  address: z.string().trim().max(300).optional().nullable(),
  currency_code: z.string().trim().max(5).optional(),
  // ---- إدارة الاشتراك (لوحة المالك) -------------------------------------
  subscription_ends_at: z.string().datetime({ offset: true }).nullable().optional()
    .or(z.string().min(8).max(40).nullable()) // يقبل "2026-12-31" المحلي أيضًا
    .optional(),
  is_suspended: z.boolean().optional(),
  subscription_note: z.string().trim().max(300).nullable().optional(),
  kill_sessions: z.boolean().optional(),
});

export const PATCH = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "system.company.edit");
  const { ip, userAgent } = clientContext(req);
  const { id } = await ctx.params;
  const companyId = Number(id);

  if (!session.companyIds.includes(companyId)) {
    throw new ApiError("SCOPE_004", "لا تملك نفاذًا لهذه الشركة");
  }
  const company = await db.company.findFirst({
    where: { id: companyId, deletedAt: null },
  });
  if (!company) throw new ApiError("VAL_003", "الشركة غير موجودة");

  const body = await parseBody(req, patchSchema);

  // ---- تفسير تاريخ الانتهاء: ISO كامل أو "YYYY-MM-DD" (نهاية اليوم) ----
  let newEndsAt: Date | null | undefined;
  if (body.subscription_ends_at !== undefined) {
    if (body.subscription_ends_at === null || String(body.subscription_ends_at).trim() === "") {
      newEndsAt = null; // مفتوح بلا حد
    } else {
      const raw = String(body.subscription_ends_at).trim();
      const d = new Date(raw.length === 10 ? `${raw}T23:59:59.000Z` : raw);
      if (Number.isNaN(d.getTime())) {
        throw new ApiError("VAL_001", "تاريخ انتهاء الاشتراك غير صالح", [
          { field: "subscription_ends_at", message: "استخدم YYYY-MM-DD أو ISO كاملًا" },
        ]);
      }
      newEndsAt = d;
    }
  }

  // هل ستصبح الشركة منتهية/معلّقة بعد هذا التعديل؟ (لإنهاء الجلسات تلقائيًا)
  const willBeBlocked =
    body.is_suspended === true ||
    (newEndsAt !== undefined && newEndsAt !== null && newEndsAt.getTime() <= Date.now());

  if (body.name !== undefined && body.name !== company.name) {
    const dupName = await db.company.findFirst({
      where: { name: body.name, deletedAt: null, id: { not: company.id } },
      select: { id: true },
    });
    if (dupName) throw new ApiError("VAL_002", `اسم الشركة «${body.name}» مستخدم مسبقًا`);
  }

  const updated = await db.company.update({
    where: { id: company.id },
    data: {
      ...(body.name !== undefined ? { name: body.name } : {}),
      ...(body.name_en !== undefined ? { nameEn: body.name_en || null } : {}),
      ...(body.legal_name !== undefined ? { legalName: body.legal_name || null } : {}),
      ...(body.tax_number !== undefined ? { taxNumber: body.tax_number || null } : {}),
      ...(body.phone !== undefined ? { phone: body.phone || null } : {}),
      ...(body.email !== undefined ? { email: body.email || null } : {}),
      ...(body.address !== undefined ? { address: body.address || null } : {}),
      ...(body.currency_code !== undefined ? { currencyCode: body.currency_code } : {}),
      ...(newEndsAt !== undefined ? { subscriptionEndsAt: newEndsAt } : {}),
      ...(body.is_suspended !== undefined ? { isSuspended: body.is_suspended } : {}),
      ...(body.subscription_note !== undefined ? { subscriptionNote: body.subscription_note || null } : {}),
      updatedBy: session.userId,
    },
  });

  // ---- إنهاء الجلسات: تعليق/انتهاء تلقائيًا، أو عند الطلب الصريح --------
  let sessionsRevoked = 0;
  if (willBeBlocked || body.kill_sessions === true) {
    sessionsRevoked = await revokeCompanySessions(company.id);
  }

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: ip, userAgent },
    {
      action: "COMPANY_UPDATED",
      module: "system",
      entityType: "company",
      entityId: company.id,
      oldValues: {
        name: company.name, phone: company.phone, address: company.address, tax_number: company.taxNumber,
        subscription_ends_at: company.subscriptionEndsAt, is_suspended: company.isSuspended,
      },
      newValues: {
        name: updated.name, phone: updated.phone, address: updated.address, tax_number: updated.taxNumber,
        subscription_ends_at: updated.subscriptionEndsAt, is_suspended: updated.isSuspended,
        subscription_note: updated.subscriptionNote, sessions_revoked: sessionsRevoked || undefined,
      },
    }
  );

  return ok({
    id: updated.id,
    code: updated.code,
    name: updated.name,
    name_en: updated.nameEn,
    legal_name: updated.legalName,
    tax_number: updated.taxNumber,
    phone: updated.phone,
    email: updated.email,
    address: updated.address,
    currency_code: updated.currencyCode,
    subscription: subscriptionInfo(updated.subscriptionEndsAt, updated.isSuspended, updated.subscriptionNote),
    sessions_revoked: sessionsRevoked || undefined,
  });
});

/**
 * DELETE /api/v1/admin/companies/[id] (system.company.delete) — حذف شركة.
 * حذف ناعم: deleted_at = الآن + إنهاء كل جلسات الشركة + تدقيق كامل.
 * الشركات المحذوفة تختفي من القوائم والمبدّلات وشاشة الدخول والنطاق فورًا.
 */
export const DELETE = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "system.company.delete");
  const { ip, userAgent } = clientContext(req);
  const { id } = await ctx.params;
  const companyId = Number(id);

  if (!Number.isInteger(companyId) || companyId <= 0) {
    throw new ApiError("VAL_001", "معرّف الشركة غير صالح");
  }

  const company = await db.company.findFirst({
    where: { id: companyId, deletedAt: null },
    select: {
      id: true, code: true, name: true,
      _count: { select: { branches: true, users: true, salesInvoices: true, customers: true, products: true } },
    },
  });
  if (!company) throw new ApiError("VAL_003", "الشركة غير موجودة أو محذوفة مسبقًا");

  // حذف ناعم — مرجعية كل السجلات التابعة تبقى سليمة (فواتير/حركات/تدقيق)
  const deleted = await db.company.update({
    where: { id: company.id },
    data: { deletedAt: new Date(), updatedBy: session.userId },
  });

  // إنهاء كل جلسات مستخدمي الشركة — لا جلسة تستمر على شركة محذوفة
  const sessionsRevoked = await revokeCompanySessions(company.id);

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: ip, userAgent },
    {
      action: "COMPANY_DELETED",
      module: "system",
      entityType: "company",
      entityId: company.id,
      oldValues: {
        code: company.code, name: company.name,
        branches: company._count.branches, users: company._count.users,
        invoices: company._count.salesInvoices, customers: company._count.customers,
        products: company._count.products,
      },
      newValues: { soft_deleted: true, sessions_revoked: sessionsRevoked },
    }
  );

  return ok({
    id: deleted.id,
    code: deleted.code,
    name: deleted.name,
    deleted_at: deleted.deletedAt,
    sessions_revoked: sessionsRevoked,
  });
});
