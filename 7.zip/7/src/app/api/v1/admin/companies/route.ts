import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError, clientContext } from "@/lib/api";
import { db } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { provisionCompany } from "@/lib/company-provisioning";
import { subscriptionInfo, revokeCompanySessions } from "@/lib/subscription";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/admin/companies — list companies in the session's scope
 *      (system.company.view). Reads LIVE user_company_access for GLOBAL
 *      users so a freshly provisioned company appears without re-login.
 * POST /api/v1/admin/companies — create + full provisioning
 *      (system.company.edit): branch, MAIN warehouse, 11 system roles,
 *      doc sequences, baseline settings, walk-in customer, creator grant.
 */

async function scopedCompanyIds(session: { userId: number; companyId: number; scopeType: string }): Promise<number[]> {
  if (session.scopeType === "GLOBAL") {
    const granted = await db.userCompanyAccess.findMany({
      where: { userId: session.userId, company: { deletedAt: null } },
      select: { companyId: true },
    });
    return granted.length ? granted.map((g) => g.companyId) : [session.companyId];
  }
  return [session.companyId];
}

export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.company.view");
  const ids = await scopedCompanyIds(session);

  const rows = await db.company.findMany({
    where: { id: { in: ids }, deletedAt: null },
    select: {
      id: true, code: true, name: true, nameEn: true, legalName: true,
      taxNumber: true, phone: true, email: true, address: true,
      currencyCode: true, createdAt: true,
      subscriptionEndsAt: true, isSuspended: true, subscriptionNote: true,
      _count: { select: { branches: true, users: true, salesInvoices: true, customers: true, products: true } },
    },
    orderBy: { id: "asc" },
  });

  return ok(
    rows.map((c) => ({
      id: c.id,
      code: c.code,
      name: c.name,
      name_en: c.nameEn,
      legal_name: c.legalName,
      tax_number: c.taxNumber,
      phone: c.phone,
      email: c.email,
      address: c.address,
      currency_code: c.currencyCode,
      branches_count: c._count.branches,
      users_count: c._count.users,
      invoices_count: c._count.salesInvoices,
      customers_count: c._count.customers,
      products_count: c._count.products,
      subscription: subscriptionInfo(c.subscriptionEndsAt, c.isSuspended, c.subscriptionNote),
      is_active_company: c.id === session.companyId,
      created_at: c.createdAt,
    }))
  );
});

const createSchema = z.object({
  code: z
    .string()
    .trim()
    .min(1, "كود الشركة مطلوب")
    .max(20)
    .regex(/^[A-Za-z0-9_-]+$/, "كود الشركة: حروف لاتينية وأرقام و - و _ فقط"),
  name: z.string().trim().min(2, "اسم الشركة مطلوب").max(160),
  name_en: z.string().trim().max(160).optional().nullable(),
  legal_name: z.string().trim().max(200).optional().nullable(),
  tax_number: z.string().trim().max(40).optional().nullable(),
  phone: z.string().trim().max(30).optional().nullable(),
  email: z.string().trim().max(120).email("البريد غير صالح").or(z.literal("")).optional().nullable(),
  address: z.string().trim().max(300).optional().nullable(),
  currency_code: z.string().trim().max(5).optional(),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.company.edit");
  const { ip, userAgent } = clientContext(req);
  const body = await parseBody(req, createSchema);

  const dup = await db.company.findFirst({
    where: { code: body.code, deletedAt: null },
    select: { id: true },
  });
  if (dup) throw new ApiError("VAL_002", `كود الشركة «${body.code}» مستخدم مسبقًا`);

  const dupName = await db.company.findFirst({
    where: { name: body.name, deletedAt: null },
    select: { id: true },
  });
  if (dupName) throw new ApiError("VAL_002", `اسم الشركة «${body.name}» مستخدم مسبقًا`);

  const result = await provisionCompany({
    code: body.code,
    name: body.name,
    nameEn: body.name_en || null,
    legalName: body.legal_name || null,
    taxNumber: body.tax_number || null,
    phone: body.phone || null,
    email: body.email || null,
    address: body.address || null,
    currencyCode: body.currency_code || undefined,
    createdBy: session.userId,
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: ip, userAgent },
    {
      action: "COMPANY_CREATED",
      module: "system",
      entityType: "company",
      entityId: result.companyId,
      newValues: { code: result.code, name: result.name, roles_created: result.rolesCreated },
    }
  );

  return ok(result, undefined, 201);
});
