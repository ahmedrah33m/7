// @ts-nocheck
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/admin/backup-logs
 *   ?type=FULL&status=OK&limit=50
 *
 * Phase 38 — Backup history log
 * Permission: system.backup_logs.view
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.backup_logs.view");
  const url = new URL(req.url);
  const type = url.searchParams.get("type");
  const status = url.searchParams.get("status");
  const limit = Math.min(500, Number(url.searchParams.get("limit") ?? "50"));

  const where: Record<string, unknown> = {
    companyId: session.companyId,
  };
  if (type) where.backupType = type;
  if (status) where.status = status;

  const rows = await db.backupLog.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: limit,
    include: {
      creator: { select: { id: true, fullName: true } },
    },
  });

  return ok(rows.map((r) => ({
    id: r.id,
    backup_type: r.backupType,
    status: r.status,
    file_path: r.filePath,
    file_size: r.fileSize,
    file_md5: r.fileMd5,
    table_count: r.tableCount,
    row_count: r.rowCount,
    duration_ms: r.durationMs,
    error: r.error,
    triggered_by: r.triggeredBy,
    created_at: r.createdAt.toISOString(),
    completed_at: r.completedAt?.toISOString() ?? null,
    creator: r.creator,
  })));
});
