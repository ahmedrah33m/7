import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, ApiError, clientContext } from "@/lib/api";
import { db } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { saveUpload, MAX_UPLOAD_BYTES } from "@/lib/storage";

export const dynamic = "force-dynamic";

/**
 * شعار النظام (هوية المنصة العامة) — مستقل تمامًا عن شعارات الشركات.
 *
 * POST /api/v1/admin/system-logo (system.settings.edit) — multipart:
 *   · حقل file إلزامي — صورة فقط (png/jpg/webp/gif) — حتى 5MB
 *   · يُخزّن عبر طبقة التخزين (UUID + قائمة بيضاء للـ MIME + فحص بايتات)
 *   · يُثبّت على SystemBrand.logoUrl (صف واحد) — يظهر في:
 *       شاشة تسجيل الدخول (نقطة /branding العامة) + شريط النظام العلوي (الهيدر)
 * DELETE /api/v1/admin/system-logo — إزالة شعار النظام (رجوع للأيقونة الافتراضية)
 *
 * ملاحظة فصل الهويات:
 *   شعار النظام  → SystemBrand (هذه النقطة) — دخول + هيدر
 *   شعار الشركة  → Company.logoUrl عبر /admin/company-logo — قائمة جانبية + فواتير
 */

async function upsertBrand(logoUrl: string | null) {
  const existing = await db.systemBrand.findUnique({ where: { id: 1 } });
  if (existing) {
    return db.systemBrand.update({ where: { id: 1 }, data: { logoUrl } });
  }
  return db.systemBrand.create({ data: { id: 1, logoUrl } });
}

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.settings.edit");
  const ct = req.headers.get("content-type") ?? "";
  if (!ct.includes("multipart/form-data")) {
    throw new ApiError("VAL_001", "الطلب يجب أن يكون multipart/form-data مع حقل file");
  }
  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) {
    throw new ApiError("VAL_001", "أرفق الشعار في الحقل file", [
      { field: "file", message: "ملف الشعار مطلوب" },
    ]);
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    throw new ApiError("VAL_001", "حجم الشعار يتجاوز 5 ميجابايت");
  }
  if (file.type && !file.type.startsWith("image/")) {
    throw new ApiError("VAL_001", "الشعار يجب أن يكون صورة (png/jpg/webp/gif)");
  }

  const buf = Buffer.from(await file.arrayBuffer());
  let stored;
  try {
    stored = await saveUpload(buf, file.type || "application/octet-stream");
  } catch (e) {
    throw new ApiError("VAL_001", (e as Error).message);
  }
  if (!stored.mime.startsWith("image/")) {
    // طبقة ثانية: ما يعلنه المتصفح قد يختلف عن البايتات الفعلية
    throw new ApiError("VAL_001", "الشعار يجب أن يكون صورة (png/jpg/webp/gif)");
  }

  const logoUrl = `/api/v1/files/${stored.name}`;
  const brand = await upsertBrand(logoUrl);

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: clientContext(req).ip, userAgent: clientContext(req).userAgent },
    { action: "SYSTEM_LOGO_SET", module: "system", entityType: "system_brand", entityId: brand.id, newValues: { logo_url: logoUrl, name: stored.name, size: stored.size } }
  );

  return ok({
    logo_url: logoUrl,
    file: { name: stored.name, mime: stored.mime, size: stored.size },
  });
});

export const DELETE = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.settings.edit");
  const brand = await db.systemBrand.findUnique({ where: { id: 1 } });
  if (!brand?.logoUrl) throw new ApiError("VAL_003", "لا يوجد شعار نظام مُثبّت");

  await upsertBrand(null);

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: clientContext(req).ip, userAgent: clientContext(req).userAgent },
    { action: "SYSTEM_LOGO_REMOVED", module: "system", entityType: "system_brand", entityId: brand.id, oldValues: { logo_url: brand.logoUrl } }
  );

  return ok({ logo_url: null });
});
