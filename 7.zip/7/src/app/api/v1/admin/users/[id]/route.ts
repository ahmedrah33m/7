import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, ApiError } from "@/lib/api";
import { db } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { normalizeScopeType } from "@/lib/scope";
import { assertManageUser } from "@/lib/scope-service";

export const dynamic = "force-dynamic";

/**
 * DELETE /api/v1/admin/users/[id] — حذف مستخدم (soft delete)
 *   (permission: system.users.delete)
 *
 * الحمايات:
 *   · بوابات التسلسل الهرمي: لا حذف لرؤساء أو نظراء (§9/§17) —
 *     COMPANY لا يحذف مستخدم منصة، وBRANCH لا يحذف COMPANY ولا نظيره
 *   · لا تحذف نفسك (منع قفل النفس)
 *   · لا تحذف آخر مستخدم نشط بدور OWNER في الشركة (حماية من فقدان الملكية)
 *   · المستخدم النشط يُنهى كل جلساته فورًا
 *   · تنظيف المنح (أدوار/فروع/مستودعات/شركات) + حذف ناعم + audit
 */
export const DELETE = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "system.users.delete");
  const ip = req.headers.get("x-forwarded-for");
  const userAgent = req.headers.get("user-agent");
  const { id } = await ctx.params;
  const userId = Number(id);
  if (!Number.isInteger(userId)) throw new ApiError("VAL_003", "معرّف مستخدم غير صالح");

  if (userId === session.userId) {
    throw new ApiError("PERM_001", "لا يمكنك حذف حسابك الشخصي — اطلب من مالك آخر تنفيذ ذلك");
  }

  // نطاق الرؤية — المالك (GLOBAL) يدير مستخدمي كل شركات نطاقه
  // (يظهر لهم في القائمة — يجب أن يكون الحذف متسقًا مع ذلك)
  let visibleCompanyIds: number[];
  if (normalizeScopeType(session.scopeType) === "GLOBAL") {
    const granted = await db.userCompanyAccess.findMany({
      where: { userId: session.userId, company: { deletedAt: null } },
      select: { companyId: true },
    });
    visibleCompanyIds = granted.length ? granted.map((g) => g.companyId) : [session.companyId];
  } else {
    visibleCompanyIds = [session.companyId];
  }

  const target = await db.user.findFirst({
    where: { id: userId, companyId: { in: visibleCompanyIds }, deletedAt: null },
    include: { roles: { select: { role: { select: { code: true } } } } },
  });
  if (!target) throw new ApiError("VAL_003", "المستخدم غير موجود");

  // بوابات التسلسل الهرمي — لا حذف لرؤساء أو نظراء (وثيقة §9/§17)
  await assertManageUser(session, target, "delete_user");

  // حماية آخر مالك: لا يُحذف آخر مستخدم نشط بدور OWNER في شركة المستخدم الهدف
  const isOwner = target.roles.some((r) => r.role.code === "OWNER");
  if (isOwner) {
    const activeOwners = await db.userRole.count({
      where: {
        role: { code: "OWNER", deletedAt: null },
        user: { companyId: target.companyId, deletedAt: null, isActive: true },
      },
    });
    if (activeOwners <= 1) {
      throw new ApiError("PERM_002", "لا يمكن حذف آخر مالك نشط في الشركة — أنشئ مالكًا آخر أولًا");
    }
  }

  await db.$transaction(async (tx) => {
    await tx.user.update({
      where: { id: target.id },
      data: { deletedAt: new Date(), isActive: false, updatedBy: session.userId },
    });
    // تنظيف المنح — الأدوار/المنح لحساب محذوف لا معنى لها
    await tx.userRole.deleteMany({ where: { userId: target.id } });
    await tx.userBranchAccess.deleteMany({ where: { userId: target.id } });
    await tx.userWarehouseAccess.deleteMany({ where: { userId: target.id } });
    await tx.userCompanyAccess.deleteMany({ where: { userId: target.id } });
  });

  // كل جلسات المستخدم تموت فورًا
  await db.refreshToken.updateMany({
    where: { userId: target.id, revokedAt: null },
    data: { revokedAt: new Date() },
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: ip, userAgent },
    {
      action: "USER_DELETED",
      module: "system",
      entityType: "user",
      entityId: target.id,
      oldValues: { username: target.username, full_name: target.fullName, scope_type: target.scopeType, is_active: target.isActive },
      newValues: { deleted: true, sessions_revoked: true, company_id: target.companyId },
    }
  );

  return ok({ id: target.id, username: target.username, deleted: true });
});
