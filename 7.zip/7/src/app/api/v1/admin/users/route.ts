import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { hashPassword } from "@/lib/password";
import { normalizeScopeType } from "@/lib/scope";
import { assertGrantScope, assertManageUser, usersListWhere, validateRoleScopeCombo } from "@/lib/scope-service";

export const dynamic = "force-dynamic";

// ---------------------------------------------------------------------
// STRICT per-company isolation helpers (company A ≠ company B):
// every branch / warehouse / sales-rep granted to a user MUST belong to
// the ACTIVE company — session-set membership alone is not enough.
// ---------------------------------------------------------------------
async function assertBranchesInCompany(companyId: number, branchIds: number[]): Promise<void> {
  if (!branchIds.length) return;
  const count = await db.branch.count({
    where: { id: { in: branchIds }, companyId, deletedAt: null },
  });
  if (count !== new Set(branchIds).size) {
    throw new ApiError("SCOPE_003", "لا يمكن منح فرعًا يتبع شركة أخرى — الفروع ملك حصري لشركتها");
  }
}

async function assertWarehousesInCompany(companyId: number, warehouseIds: number[]): Promise<void> {
  if (!warehouseIds.length) return;
  const count = await db.warehouse.count({
    where: { id: { in: warehouseIds }, companyId, deletedAt: null },
  });
  if (count !== new Set(warehouseIds).size) {
    throw new ApiError("SCOPE_002", "لا يمكن منح مستودعًا يتبع شركة أخرى — المستودعات ملك حصري لشركتها");
  }
}

async function assertSalesRepInCompany(companyId: number, salesRepId: number): Promise<void> {
  const rep = await db.user.findFirst({
    where: { id: salesRepId, companyId, deletedAt: null },
    select: { id: true },
  });
  if (!rep) {
    throw new ApiError("SCOPE_005", "المندوب المرتبط يجب أن ينتمي إلى الشركة النشطة");
  }
}

/**
 * GET /api/v1/admin/users — list users with full scope info
 * (system.users.view) — **وفق التسلسل الهرمي (وثيقة Hierarchical Visibility)**:
 *   · GLOBAL (مالك المنصة) → مستخدمو كل شركات نطاقه
 *   · COMPANY → مستخدمو شركته فقط — **دون مستخدمي المنصة (GLOBAL غير مرئيين §17)**
 *   · BRANCH/WAREHOUSE → مستخدمو فروعه الممنوحة فقط (بسياق نشط أو بدونه)
 *   · SELF/SALES_REP → نفسه حصراً (الموظف لا يرى مستخدمين آخرين §6)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.users.view");

  // نطاق الرؤية: GLOBAL → كل شركات النطاق (قراءة حية من user_company_access
  // حتى تظهر شركات أُنشئت حديثًا دون إعادة دخول)؛ غير ذلك الشركة النشطة.
  let visibleCompanyIds: number[];
  if (normalizeScopeType(session.scopeType) === "GLOBAL") {
    const granted = await db.userCompanyAccess.findMany({
      where: { userId: session.userId, company: { deletedAt: null } },
      select: { companyId: true },
    });
    visibleCompanyIds = granted.length ? granted.map((g) => g.companyId) : [session.companyId];
  } else {
    visibleCompanyIds = [session.companyId];
  }

  // فلتر اختياري ?company_id — ضمن شركات الرؤية فقط (لا تسريب خارج النطاق)
  const url = new URL(req.url);
  const companyFilter = Number(url.searchParams.get("company_id")) || null;
  if (companyFilter != null && !visibleCompanyIds.includes(companyFilter)) {
    throw new ApiError("SCOPE_004", "لا يمكنك عرض مستخدمي شركة خارج نطاقك");
  }

  const users = await db.user.findMany({
    where: usersListWhere(session, visibleCompanyIds, companyFilter),
    select: {
      id: true, uuid: true, username: true, fullName: true, email: true, phone: true,
      isActive: true, lastLoginAt: true, lastLoginIp: true, branchId: true,
      scopeType: true, salesRepId: true,
      roles: { select: { role: { select: { code: true, name: true } } } },
      branch: { select: { name: true } },
      company: { select: { id: true, name: true, code: true } },
      branchAccess: { select: { branchId: true, canRead: true, canOperate: true } },
      warehouseAccess: { select: { warehouseId: true, canRead: true, canOperate: true } },
      companyAccess: { select: { companyId: true, isPrimary: true } },
    },
    orderBy: [{ companyId: "asc" }, { id: "asc" }],
  });

  return ok(
    users.map((u) => ({
      id: u.id,
      uuid: u.uuid,
      username: u.username,
      full_name: u.fullName,
      email: u.email,
      phone: u.phone,
      is_active: u.isActive,
      last_login_at: u.lastLoginAt,
      last_login_ip: u.lastLoginIp,
      branch_id: u.branchId,
      branch: u.branch?.name ?? null,
      company_id: u.company.id,
      company_name: u.company.name,
      company_code: u.company.code,
      scope_type: u.scopeType,
      sales_rep_id: u.salesRepId,
      branches: u.branchAccess.map((b) => b.branchId),
      warehouses: u.warehouseAccess.map((w) => w.warehouseId),
      companies: u.companyAccess.map((c) => c.companyId),
      roles: u.roles.map((r) => ({ code: r.role.code, name: r.role.name })),
    })),
    { total: users.length, visible_company_ids: visibleCompanyIds, filtered_by_company: companyFilter }
  );
});

// ---------------------------------------------------------------------
// POST — create user with scope (Phase 2: full creation form)
// ---------------------------------------------------------------------
const createSchema = z.object({
  username: z.string().trim().min(3).max(80),
  password: z.string().min(8, "كلمة المرور قصيرة جدًا").max(128),
  full_name: z.string().trim().min(2).max(200),
  email: z.string().trim().email().optional().nullable(),
  phone: z.string().trim().max(30).optional().nullable(),
  role_code: z.string().trim().min(2),
  // ربط المستخدم بشركة معينة (صريح) — افتراضيًا الشركة النشطة
  company_id: z.number().int().positive().optional().nullable(),
  branch_id: z.number().int().positive().optional().nullable(),
  scope_type: z.enum(["GLOBAL", "COMPANY", "BRANCH", "WAREHOUSE", "SALES_REP", "SELF"]).default("BRANCH"),
  sales_rep_id: z.number().int().positive().optional().nullable(),
  branch_ids: z.array(z.number().int().positive()).default([]),
  warehouse_ids: z.array(z.number().int().positive()).default([]),
  company_ids: z.array(z.number().int().positive()).default([]),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.users.create");
  const body = await parseBody(req, createSchema);

  // ---- ربط الشركة الصريح (Company binding) ----------------------------
  // افتراضيًا الشركة النشطة؛ يمكن ربط المستخدم بأي شركة ضمن نطاق الجلسة
  // (session.companyIds) فقط — الشركات خارج النطاق مرفوضة دائمًا.
  const targetCompanyId = body.company_id ?? session.companyId;
  if (body.company_id != null && !session.companyIds.includes(body.company_id)) {
    throw new ApiError("SCOPE_004", "لا يمكنك ربط مستخدم بشركة خارج نطاقك");
  }
  const crossCompany = targetCompanyId !== session.companyId;

  // Scope self-guard: a BRANCH-scope admin can only create users inside
  // their own branch context (Phase 5 — no create outside scope).
  // عند الربط بشركة أخرى يكفي أن الفرع ملك للشركة الهدف (فحص الملكية أدناه)
  // لأن فروع تلك الشركة ليست ضمن نطاق الجلسة النشط أصلًا.
  const branchIds = [...new Set([...(body.branch_ids ?? []), ...(body.branch_id ? [body.branch_id] : [])])];
  if (!crossCompany) {
    for (const bid of branchIds) {
      if (!session.branchIds.includes(bid)) throw new ApiError("SCOPE_003", "لا يمكنك إنشاء مستخدم لفرع خارج نطاقك");
    }
    for (const wid of body.warehouse_ids) {
      if (!session.warehouseIds.includes(wid)) throw new ApiError("SCOPE_002", "لا يمكنك منح مستودعًا خارج نطاقك");
    }
  }
  for (const cid of body.company_ids) {
    if (!session.companyIds.includes(cid)) throw new ApiError("SCOPE_004", "لا يمكنك منح شركة خارج نطاقك");
  }

  // STRICT company isolation: the granted branches/warehouses/rep must
  // belong to the TARGET company — never another company's structure.
  await assertBranchesInCompany(targetCompanyId, branchIds);
  await assertWarehousesInCompany(targetCompanyId, body.warehouse_ids);
  if (body.sales_rep_id != null) await assertSalesRepInCompany(targetCompanyId, body.sales_rep_id);

  const dup = await db.user.findFirst({ where: { companyId: targetCompanyId, username: body.username, deletedAt: null } });
  if (dup) throw new ApiError("VAL_002", "اسم المستخدم موجود مسبقًا في هذه الشركة");

  // الدور ملك حصري للشركة الهدف — لا يمكن استخدام دور شركة أخرى
  const role = await db.role.findFirst({
    where: { companyId: targetCompanyId, code: body.role_code, deletedAt: null },
  });
  if (!role) throw new ApiError("VAL_003", crossCompany ? "الدور المحدد غير موجود في الشركة الهدف — الأدوار ملك حصري لشركتها" : "الدور المحدد غير موجود");

  // ---------------------------------------------------------------------
  // بوابات التسلسل الهرمي (وثيقة Hierarchical Visibility §14/§17):
  //   · منح النطاق يتطلب رتبة أعلى — لا تصعيد نحو GLOBAL من مستويات دنيا
  //   · الدور ↔ النطاق: لا BRANCH_MANAGER بنطاق COMPANY ولا عكسها
  // ---------------------------------------------------------------------
  await assertGrantScope(session, body.scope_type, { target_company: targetCompanyId, role: body.role_code });
  const combo = validateRoleScopeCombo(role.code, body.scope_type);
  if (!combo.ok) {
    await writeAudit(
      { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
      { action: "SCOPE_ESCALATION_BLOCKED", module: "system", entityType: "scope", entityId: session.userId, newValues: { attempted: body.scope_type, role: role.code, reason: combo.reason } }
    );
    throw new ApiError("VAL_003", combo.reason ?? "تركيبة الدور والنطاق غير منطقية");
  }

  const passwordHash = await hashPassword(body.password);
  const user = await db.$transaction(async (tx) => {
    const u = await tx.user.create({
      data: {
        companyId: targetCompanyId,
        branchId: body.branch_id ?? branchIds[0] ?? null,
        username: body.username,
        email: body.email || null,
        phone: body.phone || null,
        fullName: body.full_name,
        passwordHash,
        scopeType: body.scope_type,
        salesRepId: body.sales_rep_id ?? null,
        createdBy: session.userId,
      },
    });
    await tx.userRole.create({ data: { companyId: targetCompanyId, userId: u.id, roleId: role.id } });
    for (const bid of branchIds) {
      await tx.userBranchAccess.create({ data: { companyId: targetCompanyId, userId: u.id, branchId: bid } });
    }
    for (const wid of body.warehouse_ids) {
      await tx.userWarehouseAccess.create({ data: { companyId: targetCompanyId, userId: u.id, warehouseId: wid, canRead: true, canOperate: true } });
    }
    for (const cid of body.company_ids) {
      if (cid === targetCompanyId) continue; // صف الشركة الأساسي يُضاف أدناه
      await tx.userCompanyAccess.create({ data: { userId: u.id, companyId: cid, isPrimary: false } });
    }
    // الشركة المرتبطة لها صف انتماء أساسي دائمًا (مبدّل الشركة + العزل)
    await tx.userCompanyAccess.create({ data: { userId: u.id, companyId: targetCompanyId, isPrimary: true } });
    return u;
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    { action: "USER_CREATED", module: "system", entityType: "user", entityId: user.id,
      newValues: { username: user.username, company_id: targetCompanyId, scope_type: user.scopeType, roles: [body.role_code], branches: branchIds, warehouses: body.warehouse_ids } }
  );

  return ok({ id: user.id, username: user.username, company_id: user.companyId, scope_type: user.scopeType }, undefined, 201);
});

// ---------------------------------------------------------------------
// PATCH — update scope / status / password (Phase 44: user access editor)
// ---------------------------------------------------------------------
const patchSchema = z.object({
  user_id: z.number().int().positive(),
  is_active: z.boolean().optional(),
  // نقل المستخدم إلى شركة أخرى (ربطه بشركة معينة) — ضمن نطاق الجلسة فقط
  company_id: z.number().int().positive().optional().nullable(),
  scope_type: z.enum(["GLOBAL", "COMPANY", "BRANCH", "WAREHOUSE", "SALES_REP", "SELF"]).optional(),
  branch_id: z.number().int().positive().optional().nullable(),
  branch_ids: z.array(z.number().int().positive()).optional(),
  warehouse_ids: z.array(z.number().int().positive()).optional(),
  company_ids: z.array(z.number().int().positive()).optional(),
  sales_rep_id: z.number().int().positive().optional().nullable(),
  password: z.string().min(8).max(128).optional(),
  // تعديل الأدوار — يستبدل أدوار المستخدم كاملة (دور واحد أو أكثر)
  role_codes: z.array(z.string().trim().min(2).max(80)).min(1, "يجب إبقاء دور واحد على الأقل").optional(),
});

export const PATCH = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.users.edit");
  const body = await parseBody(req, patchSchema);

  // نطاق الرؤية — المالك (GLOBAL) يدير مستخدمي كل شركات نطاقه (متسق مع GET/DELETE)
  let visibleCompanyIds: number[];
  if (normalizeScopeType(session.scopeType) === "GLOBAL") {
    const granted = await db.userCompanyAccess.findMany({
      where: { userId: session.userId, company: { deletedAt: null } },
      select: { companyId: true },
    });
    visibleCompanyIds = granted.length ? granted.map((g) => g.companyId) : [session.companyId];
  } else {
    visibleCompanyIds = [session.companyId];
  }

  const target = await db.user.findFirst({
    where: { id: body.user_id, companyId: { in: visibleCompanyIds }, deletedAt: null },
    include: {
      branchAccess: true, warehouseAccess: true, companyAccess: true,
      roles: { select: { roleId: true, role: { select: { code: true } } } },
    },
  });
  if (!target) throw new ApiError("VAL_003", "المستخدم غير موجود");

  // ---------------------------------------------------------------------
  // بوابات التسلسل الهرمي (§9/§17): لا إدارة لرؤساء أو نظراء —
  // COMPANY لا يعدل مستخدم منصة، وBRANCH لا يعدل COMPANY ولا نظيره.
  // ---------------------------------------------------------------------
  await assertManageUser(session, target, "update_user");

  // ---------------------------------------------------------------------
  // نقل/ربط المستخدم بشركة معينة (Company binding transfer):
  //   · لا يمكن نقل نفسك (منع قفل النفس خارج النظام)
  //   · الشركة الهدف يجب أن تكون ضمن نطاق الجلسة (session.companyIds)
  //   · النقل يُلغي كل منح الشركة القديمة (فروع/مستودعات ملك حصري لها)
  //     ويعيد ربط الأدوار بالشركة الجديدة (نفس الأكواد أو role_codes صريحة)
  //   · ويُنهي كل جلسات المستخدم فورًا (سياق العزل تغيّر كليًا)
  // ---------------------------------------------------------------------
  const transferTo = body.company_id ?? null;
  if (transferTo != null) {
    if (body.user_id === session.userId) {
      throw new ApiError("PERM_001", "لا يمكنك نقل نفسك إلى شركة أخرى — اطلب من مالك آخر تنفيذ ذلك");
    }
    const inSessionScope = session.companyIds.includes(transferTo);
    const isTargetHome = target.companyId === transferTo;
    if (!inSessionScope && !(isTargetHome && normalizeScopeType(session.scopeType) === "GLOBAL")) {
      throw new ApiError("SCOPE_004", "لا يمكنك ربط المستخدم بشركة خارج نطاقك");
    }
  }
  const transferring = transferTo != null && transferTo !== target.companyId;
  const finalCompanyId = transferring ? (transferTo as number) : target.companyId;

  if (transferring) {
    // اسم المستخدم فريد داخل كل شركة — يجب ألا يتعارض في الشركة الهدف
    const dup = await db.user.findFirst({
      where: { companyId: finalCompanyId, username: target.username, deletedAt: null },
      select: { id: true },
    });
    if (dup) throw new ApiError("VAL_002", `اسم المستخدم "${target.username}" مستخدم مسبقًا في الشركة الهدف`);
  }

  // STRICT company isolation — every structural grant must belong to the
  // TARGET company (finalCompanyId). عند النقل يكفي فحص الملكية للشركة
  // الهدف لأن فروعها ليست ضمن نطاق الجلسة النشط أصلًا — والسلطة على تلك
  // الشركة تأتي من session.companyIds المفحوص أعلاه.
  if (body.branch_id != null) {
    await assertBranchesInCompany(finalCompanyId, [body.branch_id]);
    if (!transferring && !session.branchIds.includes(body.branch_id)) {
      throw new ApiError("SCOPE_003", "لا يمكنك تعيين فرع رئيسي خارج نطاقك");
    }
  }
  if (body.branch_ids) {
    if (!transferring) {
      for (const bid of body.branch_ids) {
        // المالك (GLOBAL) يمنح فروعًا من شركة المستخدم الهدف حتى لو خارجة عن
        // نطاق جلسته النشطة — assertBranchesInCompany أدناه يضمن الملكية
        if (!session.branchIds.includes(bid) && normalizeScopeType(session.scopeType) !== "GLOBAL") {
          throw new ApiError("SCOPE_003", "لا يمكنك منح فرعًا خارج نطاقك");
        }
      }
    }
    await assertBranchesInCompany(finalCompanyId, body.branch_ids);
  }
  if (body.warehouse_ids) {
    if (!transferring) {
      for (const wid of body.warehouse_ids) {
        if (!session.warehouseIds.includes(wid) && normalizeScopeType(session.scopeType) !== "GLOBAL") {
          throw new ApiError("SCOPE_002", "لا يمكنك منح مستودعًا خارج نطاقك");
        }
      }
    }
    await assertWarehousesInCompany(finalCompanyId, body.warehouse_ids);
  }
  if (body.sales_rep_id != null) await assertSalesRepInCompany(finalCompanyId, body.sales_rep_id);

  // ---- role editing guard ---------------------------------------------
  // الأدوار ملك حصري للشركة الهدف (النشطة أو شركة النقل) + لا يمكن تعديل
  // أدوارك الشخصية (منع قفل النفس — استخدم مالكًا آخر لتعديل أدوارك)
  let replacementRoleIds: number[] = [];
  let replacementRoleCodes: string[] = [];
  if (body.role_codes) {
    if (body.user_id === session.userId) {
      throw new ApiError("PERM_001", "لا يمكنك تعديل أدوارك الشخصية — اطلب من مالك آخر تنفيذ ذلك");
    }
    const codes = [...new Set(body.role_codes)];
    const roles = await db.role.findMany({
      where: { companyId: finalCompanyId, deletedAt: null, code: { in: codes } },
      select: { id: true, code: true },
    });
    if (roles.length !== codes.length) {
      throw new ApiError("VAL_003", "أحد الأدوار المحددة غير موجود في الشركة الهدف — الأدوار ملك حصري لشركتها");
    }
    replacementRoleIds = roles.map((r) => r.id);
    replacementRoleCodes = roles.map((r) => r.code);
  }

  // ---------------------------------------------------------------------
  // فحوص التسلسل الهرمي للنطاق/الأدوار المطلوب تغييرها (§14/§17):
  //   · نطاق جديد → رتبة المانح أعلى منه + توافق مع الأدوار النهائية
  //   · أدوار جديدة → توافق مع النطاق النهائي (الجديد أو الحالي)
  // ---------------------------------------------------------------------
  if (body.scope_type || replacementRoleCodes.length) {
    const finalScope = body.scope_type ?? target.scopeType;
    if (body.scope_type && normalizeScopeType(body.scope_type) !== normalizeScopeType(target.scopeType)) {
      await assertGrantScope(session, body.scope_type, { target_user: target.id, from: target.scopeType });
    }
    const finalRoleCodes = replacementRoleCodes.length
      ? replacementRoleCodes
      : target.roles.map((r) => r.role.code);
    for (const rc of finalRoleCodes) {
      const combo = validateRoleScopeCombo(rc, finalScope);
      if (!combo.ok) {
        await writeAudit(
          { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
          { action: "SCOPE_ESCALATION_BLOCKED", module: "system", entityType: "scope", entityId: target.id, newValues: { attempted: finalScope, role: rc, reason: combo.reason } }
        );
        throw new ApiError("VAL_003", combo.reason ?? "تركيبة الدور والنطاق غير منطقية");
      }
    }
  }

  const scopeChanges: Record<string, unknown> = {};

  const updated = await db.$transaction(async (tx) => {
    // ---- نقل الشركة: تنظيف منح الشركة القديمة + إعادة ربط الأدوار --------
    // الفروع/المستودعات ملك حصري لشركتها — لا يجوز أن تتبع مستخدمًا انتقل
    // إلى شركة أخرى (إلا إن كانت ضمن الشركة الهدف صراحةً).
    if (transferring) {
      await tx.userBranchAccess.deleteMany({ where: { userId: target.id, companyId: target.companyId } });
      await tx.userWarehouseAccess.deleteMany({ where: { userId: target.id, companyId: target.companyId } });
      // الأدوار ملك حصري أيضًا — أعِد ربط نفس الأكواد في الشركة الهدف
      const currentCodes = [...new Set(target.roles.map((r) => r.role.code))];
      const newRoles = await tx.role.findMany({
        where: { companyId: finalCompanyId, deletedAt: null, code: { in: currentCodes } },
        select: { id: true },
      });
      if (!newRoles.length) {
        throw new ApiError("VAL_003", "لا توجد أدوار مطابقة في الشركة الهدف — مرّر role_codes موجودة في تلك الشركة");
      }
      await tx.userRole.deleteMany({ where: { userId: target.id } });
      for (const r of newRoles) {
        await tx.userRole.create({ data: { companyId: finalCompanyId, userId: target.id, roleId: r.id } });
      }
      scopeChanges.company_transfer = { from: target.companyId, to: finalCompanyId };
      scopeChanges.roles_remapped = currentCodes;
    }

    // ---- branch access set (Phase 8) ----------------------------------
    if (body.branch_ids) {
      if (transferring) {
        // منح جديد كليًا داخل الشركة الهدف (منح الشركة القديمة أُلغيت أعلاه)
        for (const bid of body.branch_ids) {
          await tx.userBranchAccess.create({ data: { companyId: finalCompanyId, userId: target.id, branchId: bid } });
        }
        scopeChanges.branches_added = body.branch_ids;
      } else {
      const current = new Set(target.branchAccess.map((b) => b.branchId));
      const next = new Set(body.branch_ids);
      const added = [...next].filter((b) => !current.has(b));
      const removed = [...current].filter((b) => !next.has(b));
      for (const bid of added) {
        // المنح ملك لشركة المستخدم الهدف — لا لشركة الجلسة النشطة
        // (المالك يعدل مستخدمي شركة أخرى من قائمته الموحدة)
        await tx.userBranchAccess.create({ data: { companyId: finalCompanyId, userId: target.id, branchId: bid } });
      }
      for (const bid of removed) {
        await tx.userBranchAccess.deleteMany({ where: { userId: target.id, branchId: bid } });
      }
      if (added.length || removed.length) {
        scopeChanges.branches_added = added;
        scopeChanges.branches_removed = removed;
      }
      }
    }

    // ---- warehouse access set (Phase 9) --------------------------------
    if (body.warehouse_ids) {
      if (transferring) {
        for (const wid of body.warehouse_ids) {
          await tx.userWarehouseAccess.create({ data: { companyId: finalCompanyId, userId: target.id, warehouseId: wid, canRead: true, canOperate: true } });
        }
        scopeChanges.warehouses_added = body.warehouse_ids;
      } else {
      const current = new Set(target.warehouseAccess.map((w) => w.warehouseId));
      const next = new Set(body.warehouse_ids);
      const added = [...next].filter((w) => !current.has(w));
      const removed = [...current].filter((w) => !next.has(w));
      for (const wid of added) {
        await tx.userWarehouseAccess.create({ data: { companyId: finalCompanyId, userId: target.id, warehouseId: wid, canRead: true, canOperate: true } });
      }
      for (const wid of removed) {
        await tx.userWarehouseAccess.deleteMany({ where: { userId: target.id, warehouseId: wid } });
      }
      if (added.length || removed.length) {
        scopeChanges.warehouses_added = added;
        scopeChanges.warehouses_removed = removed;
      }
      }
    }

    // ---- company access (GLOBAL switcher, Phase 16) ---------------------
    if (body.company_ids) {
      for (const cid of body.company_ids) {
        const inScope = session.companyIds.includes(cid);
        const isTargetHome = cid === target.companyId;
        if (!inScope && !(isTargetHome && normalizeScopeType(session.scopeType) === "GLOBAL")) {
          throw new ApiError("SCOPE_004", "لا يمكنك منح شركة خارج نطاقك");
        }
      }
      // صفوف شركات خارج نطاق الجلسة تُحفظ كما هي — لا يجوز حذفها بصمت
      // (المدير لا يراها لكن المستخدم قد يعتمد عليها للتبديل)
      const preserved = target.companyAccess
        .map((c) => c.companyId)
        .filter((cid) => !session.companyIds.includes(cid));
      await tx.userCompanyAccess.deleteMany({ where: { userId: target.id } });
      // الشركة المرتبطة (الأساسية) دائمًا ضمن قائمة التبديل — حتى لا يفقد
      // المستخدم القدرة على العودة لشركته الأم من مبدّل الشركة
      const switcherSet = new Set([...body.company_ids, ...preserved, finalCompanyId]);
      for (const cid of switcherSet) {
        await tx.userCompanyAccess.create({ data: { userId: target.id, companyId: cid, isPrimary: cid === finalCompanyId } });
      }
      scopeChanges.companies = [...switcherSet];
    }

    // ---- roles replacement (تعديل الأدوار) --------------------------------
    if (replacementRoleIds.length) {
      const currentIds = new Set(target.roles.map((r) => r.roleId));
      const changed = replacementRoleIds.some((id) => !currentIds.has(id)) || currentIds.size !== replacementRoleIds.length;
      if (changed) {
        await tx.userRole.deleteMany({ where: { userId: target.id } });
        for (const roleId of replacementRoleIds) {
          await tx.userRole.create({ data: { companyId: finalCompanyId, userId: target.id, roleId } });
        }
        scopeChanges.roles_before = [...currentIds];
        scopeChanges.roles_after = replacementRoleIds;
      }
    }

    // ---- core fields -----------------------------------------------------
    if (body.password) {
      const passwordHash = await hashPassword(body.password);
      await tx.user.update({ where: { id: target.id }, data: { passwordHash } });
      scopeChanges.password_changed = true;
    }

    return tx.user.update({
      where: { id: target.id },
      data: {
        ...(body.is_active !== undefined ? { isActive: body.is_active } : {}),
        ...(body.scope_type ? { scopeType: body.scope_type } : {}),
        ...(transferring ? { companyId: finalCompanyId } : {}),
        // الفرع الرئيسي من شركة قديمة لا يصح بعد النقل — يُصفَّر ما لم يُمرَّر فرع جديد
        ...(transferring
          ? { branchId: body.branch_id !== undefined ? body.branch_id : (body.branch_ids?.[0] ?? null) }
          : body.branch_id !== undefined ? { branchId: body.branch_id } : {}),
        // المندوب المرتبط من الشركة القديمة يُصفَّر عند النقل
        ...(transferring && body.sales_rep_id === undefined ? { salesRepId: null } : {}),
        ...(body.sales_rep_id !== undefined ? { salesRepId: body.sales_rep_id } : {}),
        updatedBy: session.userId,
      },
    });
  });

  // Disable / transfer → kill all sessions (Phase 3: دعم إنهاء الجلسات)
  // النقل يغيّر سياق العزل كليًا — كل الجلسات القديمة يجب أن تموت فورًا
  if (body.is_active === false || transferring) {
    await db.refreshToken.updateMany({
      where: { userId: target.id, revokedAt: null },
      data: { revokedAt: new Date() },
    });
  }

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    { action: transferring ? "USER_COMPANY_CHANGED" : body.is_active === false ? "USER_DISABLED" : scopeChanges.roles_after ? "USER_ROLES_CHANGED" : "USER_SCOPE_CHANGED", module: "system", entityType: "user", entityId: target.id,
      oldValues: { company_id: target.companyId, scope_type: target.scopeType, is_active: target.isActive },
      newValues: { ...scopeChanges, company_id: updated.companyId, scope_type: updated.scopeType, is_active: updated.isActive } }
  );

  return ok({ id: updated.id, username: updated.username, company_id: updated.companyId, scope_type: updated.scopeType, is_active: updated.isActive });
});
