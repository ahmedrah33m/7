import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, ApiError, clientContext } from "@/lib/api";
import { db } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { saveUpload, MAX_UPLOAD_BYTES } from "@/lib/storage";

export const dynamic = "force-dynamic";

/**
 * شعار الشركة/النظام — Multi-tenant branding (Multi-Company).
 *
 * POST /api/v1/admin/company-logo (system.company.edit) — multipart:
 *   · حقل file إلزامي — صورة فقط (png/jpg/webp/gif) — حتى 5MB
 *   · يُخزّن عبر طبقة التخزين (UUID + قائمة بيضاء للـ MIME + فحص بايتات)
 *   · يُثبّت على Company.logoUrl للشركة النشطة — يظهر في:
 *       شاشة الدخول (نقطة /branding العامة) · هيدر النظام · القائمة الجانبية
 *       · رأس الفاتورة المطبوعة
 * DELETE /api/v1/admin/company-logo — إزالة الشعار (رجوع للشعار الافتراضي)
 */

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.company.edit");
  const ct = req.headers.get("content-type") ?? "";
  if (!ct.includes("multipart/form-data")) {
    throw new ApiError("VAL_001", "الطلب يجب أن يكون multipart/form-data مع حقل file");
  }
  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) {
    throw new ApiError("VAL_001", "أرفق الشعار في الحقل file", [
      { field: "file", message: "ملف الشعار مطلوب" },
    ]);
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    throw new ApiError("VAL_001", "حجم الشعار يتجاوز 5 ميجابايت");
  }
  if (file.type && !file.type.startsWith("image/")) {
    throw new ApiError("VAL_001", "الشعار يجب أن يكون صورة (png/jpg/webp/gif)");
  }

  const buf = Buffer.from(await file.arrayBuffer());
  let stored;
  try {
    stored = await saveUpload(buf, file.type || "application/octet-stream");
  } catch (e) {
    throw new ApiError("VAL_001", (e as Error).message);
  }
  if (!stored.mime.startsWith("image/")) {
    // طبقة ثانية: ما يعلنه المتصفح قد يختلف عن البايتات الفعلية
    throw new ApiError("VAL_001", "الشعار يجب أن يكون صورة (png/jpg/webp/gif)");
  }

  const company = await db.company.findFirst({
    where: { id: session.companyId, deletedAt: null },
    select: { id: true, name: true, logoUrl: true },
  });
  if (!company) throw new ApiError("VAL_003", "الشركة غير موجودة");

  const logoUrl = `/api/v1/files/${stored.name}`;
  const updated = await db.company.update({
    where: { id: company.id },
    data: { logoUrl, updatedBy: session.userId },
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: clientContext(req).ip, userAgent: clientContext(req).userAgent },
    { action: "COMPANY_LOGO_SET", module: "system", entityType: "company", entityId: company.id, newValues: { logo_url: logoUrl, name: stored.name, size: stored.size } }
  );

  return ok({
    company_id: updated.id,
    name: updated.name,
    logo_url: logoUrl,
    file: { name: stored.name, mime: stored.mime, size: stored.size },
  });
});

export const DELETE = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.company.edit");
  const company = await db.company.findFirst({
    where: { id: session.companyId, deletedAt: null },
    select: { id: true, name: true, logoUrl: true },
  });
  if (!company) throw new ApiError("VAL_003", "الشركة غير موجودة");
  if (!company.logoUrl) throw new ApiError("VAL_003", "لا يوجد شعار مُثبّت لهذه الشركة");

  const updated = await db.company.update({
    where: { id: company.id },
    data: { logoUrl: null, updatedBy: session.userId },
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: clientContext(req).ip, userAgent: clientContext(req).userAgent },
    { action: "COMPANY_LOGO_REMOVED", module: "system", entityType: "company", entityId: company.id, oldValues: { logo_url: company.logoUrl } }
  );

  return ok({ company_id: updated.id, name: updated.name, logo_url: null });
});
