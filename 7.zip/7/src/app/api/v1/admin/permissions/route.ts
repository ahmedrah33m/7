import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";

export const dynamic = "force-dynamic";

/** GET /api/v1/admin/permissions — the atomic permission catalog (system.roles.view). */
export const GET = handler(async (req: NextRequest) => {
  await guard(req, "system.roles.view");

  const permissions = await db.permission.findMany({
    select: { id: true, code: true, module: true, entity: true, action: true, descriptionAr: true },
    orderBy: { code: "asc" },
  });

  return ok(
    permissions.map((p) => ({
      id: p.id,
      code: p.code,
      module: p.module,
      entity: p.entity,
      action: p.action,
      description_ar: p.descriptionAr,
    })),
    { total: permissions.length }
  );
});
