import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/admin/audit-logs — immutable audit trail (audit.audit_logs.view).
 * Query: ?action=&module=&page=&per_page=  (max 100/page)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "audit.audit_logs.view");

  const url = new URL(req.url);
  const action = url.searchParams.get("action") ?? undefined;
  const moduleName = url.searchParams.get("module") ?? undefined;
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1") || 1);
  const perPage = Math.min(100, Math.max(10, Number(url.searchParams.get("per_page") ?? "20") || 20));

  const where = {
    companyId: session.companyId,
    ...(action ? { action } : {}),
    ...(moduleName ? { module: moduleName } : {}),
  };

  const [rows, total] = await Promise.all([
    db.auditLog.findMany({
      where,
      include: { user: { select: { username: true, fullName: true } } },
      orderBy: { id: "desc" },
      skip: (page - 1) * perPage,
      take: perPage,
    }),
    db.auditLog.count({ where }),
  ]);

  return ok(
    rows.map((r) => ({
      id: r.id,
      action: r.action,
      module: r.module,
      entity_type: r.entityType,
      entity_id: r.entityId,
      user: r.user ? { username: r.user.username, full_name: r.user.fullName } : null,
      ip_address: r.ipAddress,
      new_values: r.newValues ? JSON.parse(r.newValues) : null,
      created_at: r.createdAt,
    })),
    { page, per_page: perPage, total }
  );
});
