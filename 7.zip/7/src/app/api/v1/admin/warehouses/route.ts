import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError, clientContext } from "@/lib/api";
import { db } from "@/lib/db";
import { writeAudit } from "@/lib/audit";
import { assertBranchInScope } from "@/lib/scope";

export const dynamic = "force-dynamic";

/**
 * Multi-Tenant org structure (MASTER PROMPT §10/§12/§14):
 * GET   /api/v1/admin/warehouses — warehouses of the ACTIVE company only
 * POST  /api/v1/admin/warehouses — create under a branch of the ACTIVE
 *       company (chain validated: branch.company_id == session.company_id).
 *       Types: MAIN | BRANCH | REP | TRANSIT | DAMAGED | RETURN
 * PATCH /api/v1/admin/warehouses — rename / toggle active / change manager
 *
 * Warehouse uniqueness follows the same per-tenant rule as branches:
 * UNIQUE(company_id, code) — identical names across companies are legal.
 */

const WAREHOUSE_TYPES = ["MAIN", "BRANCH", "REP", "TRANSIT", "DAMAGED", "RETURN"] as const;

export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.branches.view");

  const rows = await db.warehouse.findMany({
    where: { companyId: session.companyId, deletedAt: null },
    include: {
      branch: { select: { id: true, name: true, code: true } },
      _count: { select: { stockBalances: true } },
    },
    orderBy: { id: "asc" },
  });

  return ok(
    rows.map((w) => ({
      id: w.id,
      code: w.code,
      name: w.name,
      type: w.type,
      is_mobile: w.isMobile,
      is_active: w.isActive,
      branch_id: w.branchId,
      branch: w.branch?.name ?? null,
      company_id: w.companyId,
      skus: w._count.stockBalances,
      created_at: w.createdAt,
    })),
    { total: rows.length }
  );
});

const createSchema = z.object({
  code: z
    .string()
    .trim()
    .min(1, "كود المستودع مطلوب")
    .max(20)
    .regex(/^[A-Za-z0-9_-]+$/, "الكود: حروف لاتينية وأرقام و - و _ فقط"),
  name: z.string().trim().min(2, "اسم المستودع مطلوب").max(120),
  branch_id: z.number().int().positive("اختر الفرع التابع له المستودع"),
  type: z.enum(WAREHOUSE_TYPES).default("BRANCH"),
  is_mobile: z.boolean().optional().default(false),
  manager_id: z.number().int().positive().optional().nullable(),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.branches.create");
  const { ip, userAgent } = clientContext(req);
  const body = await parseBody(req, createSchema);

  // §19 chain validation — the warehouse hangs off a branch of the ACTIVE
  // company, inside the actor's branch scope. No cross-tenant anchoring.
  const branch = await db.branch.findFirst({
    where: { id: body.branch_id, companyId: session.companyId, deletedAt: null },
    select: { id: true, name: true },
  });
  if (!branch) throw new ApiError("SCOPE_006", "الفرع المحدد لا يتبع الشركة النشطة");
  assertBranchInScope(session, body.branch_id);

  const dup = await db.warehouse.findFirst({
    where: { companyId: session.companyId, code: body.code, deletedAt: null },
    select: { id: true },
  });
  if (dup) throw new ApiError("VAL_002", `كود المستودع «${body.code}» مستخدم مسبقًا في هذه الشركة`);

  // MAIN warehouses are unique per company (provisioning owns the first)
  if (body.type === "MAIN") {
    const main = await db.warehouse.findFirst({
      where: { companyId: session.companyId, type: "MAIN", deletedAt: null },
      select: { id: true },
    });
    if (main) throw new ApiError("VAL_002", "يوجد مستودع رئيسي واحد لكل شركة");
  }
  // REP warehouses belong to exactly one sales rep of this company
  if (body.manager_id != null) {
    const mgr = await db.user.findFirst({
      where: { id: body.manager_id, companyId: session.companyId, deletedAt: null },
      select: { id: true },
    });
    if (!mgr) throw new ApiError("SCOPE_006", "المسؤول المحدد لا يتبع الشركة النشطة");
  }

  const warehouse = await db.warehouse.create({
    data: {
      companyId: session.companyId,
      branchId: body.branch_id,
      code: body.code,
      name: body.name,
      type: body.type,
      isMobile: body.is_mobile,
      managerId: body.manager_id ?? null,
      createdBy: session.userId,
    },
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: ip, userAgent },
    {
      action: "WAREHOUSE_CREATED",
      module: "system",
      entityType: "warehouse",
      entityId: warehouse.id,
      newValues: { code: warehouse.code, name: warehouse.name, type: warehouse.type, branch_id: warehouse.branchId },
    }
  );

  return ok(warehouse, undefined, 201);
});

const patchSchema = z.object({
  warehouse_id: z.number().int().positive(),
  name: z.string().trim().min(2).max(120).optional(),
  is_active: z.boolean().optional(),
  manager_id: z.number().int().positive().optional().nullable(),
});

export const PATCH = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.branches.create");
  const { ip, userAgent } = clientContext(req);
  const body = await parseBody(req, patchSchema);

  const target = await db.warehouse.findFirst({
    where: { id: body.warehouse_id, companyId: session.companyId, deletedAt: null },
  });
  if (!target) throw new ApiError("VAL_003", "المستودع غير موجود");

  if (body.manager_id != null) {
    const mgr = await db.user.findFirst({
      where: { id: body.manager_id, companyId: session.companyId, deletedAt: null },
      select: { id: true },
    });
    if (!mgr) throw new ApiError("SCOPE_006", "المسؤول المحدد لا يتبع الشركة النشطة");
  }

  const updated = await db.warehouse.update({
    where: { id: target.id },
    data: {
      ...(body.name ? { name: body.name } : {}),
      ...(body.is_active !== undefined ? { isActive: body.is_active } : {}),
      ...(body.manager_id !== undefined ? { managerId: body.manager_id } : {}),
      updatedBy: session.userId,
    },
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: ip, userAgent },
    {
      action: "WAREHOUSE_UPDATED",
      module: "system",
      entityType: "warehouse",
      entityId: target.id,
      oldValues: { name: target.name, is_active: target.isActive, manager_id: target.managerId },
      newValues: { name: updated.name, is_active: updated.isActive, manager_id: updated.managerId },
    }
  );

  return ok({ id: updated.id, name: updated.name, is_active: updated.isActive });
});

/**
 * DELETE /api/v1/admin/warehouses?id=N — حذف مستودع (soft delete)
 *   (permission: system.warehouses.delete)
 *
 * الحمايات:
 *   · المستودع الرئيسي (MAIN) لا يُحذف — عطّله بدلاً من ذلك
 *   · يُمنع الحذف إذا كان يحمل مخزونًا غير صفري (أصناف يجب تصفيرها أولًا)
 *   · الحذف الناعم يُبقي حركات المخزون والفواتير التاريخية سليمة
 */
export const DELETE = handler(async (req: NextRequest) => {
  const session = await guard(req, "system.warehouses.delete");
  const { ip, userAgent } = clientContext(req);
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!Number.isInteger(id) || id <= 0) throw new ApiError("VAL_003", "معرّف مستودع غير صالح");

  const target = await db.warehouse.findFirst({
    where: { id, companyId: session.companyId, deletedAt: null },
  });
  if (!target) throw new ApiError("VAL_003", "المستودع غير موجود");

  if (target.type === "MAIN") {
    throw new ApiError("WH_001", "المستودع الرئيسي لا يُحذف — عطّله بدلاً من ذلك");
  }

  // مخزون غير صفري = كنز لا يُحذف — يجب تسويته (جرد/تحويل) أولًا
  const nonZero = await db.stockBalance.count({
    where: { warehouseId: target.id, qty: { not: 0 } },
  });
  if (nonZero > 0) {
    throw new ApiError("WH_001", `لا يمكن حذف «${target.name}» — يحمل ${nonZero} صنفًا بمخزون غير صفري`, [
      { field: "stock", message: "صفّر مخزون المستودع أولًا (جرد/تحويل/تسوية)" },
    ]);
  }

  await db.$transaction(async (tx) => {
    await tx.warehouse.update({
      where: { id: target.id },
      data: { deletedAt: new Date(), isActive: false, updatedBy: session.userId },
    });
    // منح وصول المستخدمين لمستودع محذوف لا معنى لها
    await tx.userWarehouseAccess.deleteMany({ where: { warehouseId: target.id } });
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: ip, userAgent },
    {
      action: "WAREHOUSE_DELETED",
      module: "system",
      entityType: "warehouse",
      entityId: target.id,
      oldValues: { code: target.code, name: target.name, type: target.type, branch_id: target.branchId },
      newValues: { deleted: true },
    }
  );

  return ok({ id: target.id, code: target.code, deleted: true });
});
