import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { db } from "@/lib/db";
import { dec, moneyR, qtyR, sumOf, num } from "@/lib/decimal";
import { periodOf } from "@/lib/field-service";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/alerts — smart operations center (any authenticated user).
 * Content is filtered by what the session may SEE (permission-aware):
 *   LOW_STOCK      — products at/below min level   (inventory.stock.view)
 *   CREDIT_OVER    — customers over credit limit   (parties.customers.view)
 *   OVERDUE        — receivables past credit days  (parties.customers.view)
 *   PENDING_B2B    — portal orders awaiting action (b2b.orders.view)
 *   COMM_PENDING   — commissions awaiting approval (field.commissions.approve)
 *   VISITS_TODAY   — my planned visits today       (field.visits.view)
 * Each alert: { type, severity, title, message, count, tab } — the UI
 * maps `tab` to the dashboard tab to open on click.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req);
  const companyId = session.companyId;
  const can = (p: string) => session.permissions.has(p);
  const alerts: {
    type: string; severity: "HIGH" | "MEDIUM" | "LOW";
    title: string; message: string; count: number; tab: string;
  }[] = [];

  // 1) Low stock (needs stock visibility)
  if (can("inventory.stock.view") || can("products.products.view")) {
    const rows = await db.product.findMany({
      where: { companyId, deletedAt: null, isActive: true, minStock: { gt: 0 } },
      select: { id: true, name: true, unit: true, minStock: true, stockBalances: { select: { qty: true } } },
    });
    const low = rows
      .map((p) => ({ p, total: qtyR(sumOf(p.stockBalances, (b) => b.qty)) }))
      .filter((x) => x.total.lte(x.p.minStock))
      .sort((a, b) => num(a.total.minus(b.total)));
    if (low.length) {
      const names = low.slice(0, 3).map((x) => `${x.p.name} (${num(x.total)} ${x.p.unit})`).join(" · ");
      alerts.push({
        type: "LOW_STOCK", severity: low.some((x) => !x.total.isPositive()) ? "HIGH" : "MEDIUM",
        title: "أصناف وصلت حد إعادة الطلب",
        message: `${low.length} صنفًا عند الحد الأدنى أو تحته — ${names}${low.length > 3 ? " …" : ""}`,
        count: low.length, tab: "inventory",
      });
    }

    // 1-b) STOCKOUT forecast — سرعة البيع آخر 30 يومًا تحدد "ينفد خلال N يوم"
    const since30 = new Date(Date.now() - 30 * 86_400_000);
    const sold = await db.salesInvoiceLine.groupBy({
      by: ["productId"],
      where: { invoice: { companyId, deletedAt: null, invoiceDate: { gte: since30 } } },
      _sum: { qty: true },
    });
    if (sold.length) {
      const velocity = new Map(sold.map((s) => [s.productId, s._sum.qty ?? 0]));
      const actives = await db.product.findMany({
        where: { companyId, deletedAt: null, isActive: true, id: { in: [...velocity.keys()] } },
        select: { id: true, name: true, unit: true, stockBalances: { select: { qty: true } } },
      });
      const risky = actives
        .map((p) => {
          const stock = qtyR(sumOf(p.stockBalances, (b) => b.qty));
          const perDay = dec(velocity.get(p.id) ?? 0).div(30);
          return { p, stock, daysCover: perDay.isPositive() ? num(stock.div(perDay)) : Infinity };
        })
        .filter((x) => Number.isFinite(x.daysCover) && x.daysCover <= 7)
        .sort((a, b) => a.daysCover - b.daysCover);
      if (risky.length) {
        const names = risky.slice(0, 3).map((x) => `${x.p.name} (~${Math.max(1, Math.floor(x.daysCover))} يوم)`).join(" · ");
        alerts.push({
          type: "STOCKOUT_RISK", severity: risky.some((x) => x.daysCover <= 3) ? "HIGH" : "MEDIUM",
          title: "تنبؤ نفاد مخزون خلال أسبوع",
          message: `بحسب سرعة البيع (30 يومًا): ${names}${risky.length > 3 ? " …" : ""} — أوصِ قبل النفاد`,
          count: risky.length, tab: "inventory",
        });
      }
    }
  }

  // 2) Customers over credit limit
  if (can("parties.customers.view")) {
    const over = await db.customer.count({
      where: { companyId, deletedAt: null, isActive: true, creditLimit: { gt: 0 }, balance: { gt: 0 } },
    });
    const rows = await db.customer.findMany({
      where: { companyId, deletedAt: null, isActive: true, creditLimit: { gt: 0 }, balance: { gt: 0 } },
      select: { name: true, balance: true, creditLimit: true },
    });
    const exceeding = rows.filter((c) => dec(c.balance).gt(c.creditLimit));
    if (exceeding.length) {
      alerts.push({
        type: "CREDIT_OVER", severity: "HIGH",
        title: "عملاء تجاوزوا حد الائتمان",
        message: `${exceeding.length} عميلًا تجاوز حدّه — ${exceeding.slice(0, 3).map((c) => c.name).join(" · ")}${exceeding.length > 3 ? " …" : ""} — البيع الآجل محجوب حتى السداد`,
        count: exceeding.length, tab: "customers",
      });
    }
    if (over > exceeding.length) {
      alerts.push({
        type: "CREDIT_NEAR", severity: "LOW",
        title: "اقتراب من حد الائتمان",
        message: `${over - exceeding.length} عميلًا لديه ذمة قريبة من الحد (لم يتجاوزه بعد)`,
        count: over - exceeding.length, tab: "customers",
      });
    }

    // 3) Overdue receivables (invoice due & older than 30 days baseline)
    const invoices = await db.salesInvoice.findMany({
      where: { companyId, deletedAt: null },
      select: { invoiceDate: true, grandTotal: true, paidAmount: true, customer: { select: { name: true } } },
    });
    const now = Date.now();
    const overdue = invoices.filter((i) => {
      const due = dec(i.grandTotal).minus(i.paidAmount);
      if (!due.isPositive()) return false;
      return now - i.invoiceDate.getTime() > 30 * 86_400_000;
    });
    if (overdue.length) {
      const totalDue = moneyR(sumOf(overdue, (i) => dec(i.grandTotal).minus(i.paidAmount)));
      alerts.push({
        type: "OVERDUE", severity: "HIGH",
        title: "ذمم متأخرة عن 30 يومًا",
        message: `${overdue.length} فاتورة غير محصلة مضى عليها أكثر من 30 يومًا — إجمالي ${new Intl.NumberFormat("ar-IQ").format(num(totalDue))} د.ع`,
        count: overdue.length, tab: "reports",
      });
    }
  }

  // 4) B2B orders awaiting decision
  if (can("b2b.orders.view")) {
    const pending = await db.b2BOrder.count({ where: { companyId, status: "SUBMITTED", deletedAt: null } });
    if (pending) {
      alerts.push({
        type: "PENDING_B2B", severity: "MEDIUM",
        title: "طلبات بوابة العملاء بانتظار القرار",
        message: `${pending} طلب B2B أُرسل من العملاء ويحتاج موافقة أو رفضًا`,
        count: pending, tab: "b2b",
      });
    }
  }

  // 5) Commissions awaiting approval
  if (can("field.commissions.approve")) {
    const pending = await db.commission.count({ where: { companyId, status: "PENDING" } });
    if (pending) {
      alerts.push({
        type: "COMM_PENDING", severity: "LOW",
        title: "عمولات بانتظار الاعتماد",
        message: `${pending} عمولة مولّدة تلقائيًا من فواتير المندوبين تحتاج اعتمادًا`,
        count: pending, tab: "field",
      });
    }
  }

  // 6) My visits today (reps mostly)
  if (can("field.visits.view")) {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const end = new Date(start);
    end.setDate(end.getDate() + 1);
    const planned = await db.visit.count({
      where: { companyId, repId: session.userId, deletedAt: null, status: "PLANNED", plannedDate: { gte: start, lt: end } },
    });
    if (planned) {
      alerts.push({
        type: "VISITS_TODAY", severity: "LOW",
        title: "زيارات مجدولة اليوم",
        message: `لديك ${planned} زيارة مخططة اليوم — سجّل الحضور (GPS) وابدأ`,
        count: planned, tab: "field",
      });
    }
  }

  // 7) v14 — DELIVERY_SHORTAGE: نقص التسليم — حصراً لحساب أمين الصندوق.
  //    «في حاله النقص يتم تبليغه فقط»: يظهر هذا التنبيه للجلسات التي تحمل
  //    دور CASH_KEEPER (أمين الصندوق) دون باقي الأدوار — حتى المالك لا يراه.
  //    النقص = إشعار تسليم بحالة PARTIAL لديه بنود «المتبقي > 0» (سُلّم أقل
  //    من المخطط في بنود الإشعار نفسه — انظر حالة PARTIAL في delivery-service).
  if (session.roles.some((r) => r.code === "CASH_KEEPER")) {
    const shortageNotes = await db.deliveryNote.findMany({
      where: {
        companyId, deletedAt: null, status: "PARTIAL",
        lines: { some: { remainingQty: { gt: 0 } } },
      },
      select: {
        id: true, number: true,
        customer: { select: { name: true } },
        lines: {
          where: { remainingQty: { gt: 0 } },
          select: { remainingQty: true, product: { select: { name: true, unit: true } } },
          take: 3,
        },
      },
      orderBy: { updatedAt: "desc" },
      take: 50,
    });
    if (shortageNotes.length) {
      const examples = shortageNotes.slice(0, 2).map((n) => {
        const items = n.lines.slice(0, 2)
          .map((l) => `${l.product.name} (${num(qtyR(l.remainingQty))} ${l.product.unit})`)
          .join(" + ");
        return `${n.number} — ${n.customer.name}: ${items}`;
      }).join(" · ");
      alerts.push({
        type: "DELIVERY_SHORTAGE", severity: "HIGH",
        title: "نقص في تسليم بضاعة — إشعارات تنتظر الإكمال",
        message: `${shortageNotes.length} إشعار تسليم سُلّم أقل من المخطط — ${examples}${shortageNotes.length > 2 ? " …" : ""} — راجع الإشعارات وأكمل المتتبقي`,
        count: shortageNotes.length, tab: "delivery",
      });
    }
  }

  const severityRank = { HIGH: 0, MEDIUM: 1, LOW: 2 } as const;
  alerts.sort((a, b) => severityRank[a.severity] - severityRank[b.severity]);

  const period = periodOf(new Date());
  return ok({ alerts, period, generated_at: new Date().toISOString() });
});
