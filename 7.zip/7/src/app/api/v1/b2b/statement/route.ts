import { NextRequest } from "next/server";
import { handler, ok, ApiError } from "@/lib/api";
import { verifyB2BToken } from "@/lib/jwt";
import { b2bStatement } from "@/lib/b2b-service";

export const dynamic = "force-dynamic";

/** GET /api/v1/b2b/statement — own invoices, orders and balance (B2B token). */
export const GET = handler(async (req: NextRequest) => {
  const header = req.headers.get("authorization") ?? "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  const claims = await verifyB2BToken(token);
  if (!claims) throw new ApiError("AUTH_001", "رمز البوابة مفقود أو غير صالح");

  const statement = await b2bStatement(claims.cid);
  return ok(statement);
});
