import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { z } from "zod";
import { rejectB2BOrder } from "@/lib/b2b-service";

export const dynamic = "force-dynamic";

/** POST /api/v1/b2b/admin/orders/[id]/reject — (b2b.orders.reject). SUBMITTED → REJECTED. */
const rejectSchema = z.object({ reason: z.string().trim().max(300).optional().nullable() });

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "b2b.orders.reject");
  const { id } = await ctx.params;
  const orderId = Number(id);
  if (!Number.isInteger(orderId)) throw new ApiError("VAL_003", "معرّف طلب غير صالح");
  const body = await parseBody(req, rejectSchema).catch(() => ({ reason: null }));

  const result = await rejectB2BOrder(
    {
      userId: session.userId,
      companyId: session.companyId,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    orderId,
    body.reason ?? null
  );
  return ok(result);
});
