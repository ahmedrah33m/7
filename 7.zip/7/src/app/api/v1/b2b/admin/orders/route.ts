import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { listB2BOrders } from "@/lib/b2b-service";

export const dynamic = "force-dynamic";

/** GET /api/v1/b2b/admin/orders — back-office B2B order queue (b2b.orders.view). */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "b2b.orders.view");
  const url = new URL(req.url);
  const status = url.searchParams.get("status") ?? undefined;

  const rows = await listB2BOrders(session.companyId, status);
  return ok(
    rows.map((o) => ({
      id: o.id,
      number: o.number,
      status: o.status,
      customer: o.customer,
      grand_total: o.grandTotal,
      subtotal: o.subtotal,
      notes: o.notes,
      lines: o.lines.map((l) => ({ product: l.product, qty: l.qty, unit_price: l.unitPrice, line_total: l.lineTotal })),
      confirmed_invoice: o.confirmedInvoice?.number ?? null,
      created_at: o.createdAt,
    }))
  );
});
