import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { confirmB2BOrder } from "@/lib/b2b-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/b2b/admin/orders/[id]/confirm — (b2b.orders.approve).
 * SUBMITTED → CONFIRMED by creating a REAL invoice through the posting
 * engine (atomic stock OUT + credit guard). Double confirm → VAL_004.
 */
const confirmSchema = z.object({
  warehouse_id: z.number().int().positive("اختر المستودع"),
  type: z.enum(["CASH", "CREDIT"], { message: "نوع الفاتورة نقدي أو آجل" }),
  notes: z.string().trim().max(300).optional().nullable(),
});

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "b2b.orders.approve");
  const { id } = await ctx.params;
  const orderId = Number(id);
  if (!Number.isInteger(orderId)) throw new ApiError("VAL_003", "معرّف طلب غير صالح");
  const body = await parseBody(req, confirmSchema);

  const result = await confirmB2BOrder(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    orderId,
    { warehouseId: body.warehouse_id, type: body.type, notes: body.notes ?? null }
  );
  return ok({
    order_id: result.order_id,
    order_number: result.order_number,
    status: result.status,
    invoice: result.invoice,
  });
});
