import { NextRequest } from "next/server";
import { handler, ok, ApiError } from "@/lib/api";
import { verifyB2BToken } from "@/lib/jwt";
import { b2bCatalog } from "@/lib/b2b-service";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/b2b/catalog — the customer's OWN prices only (B2B token).
 * Exit criterion: B2B sees own prices, never other customers' pricing.
 */
export const GET = handler(async (req: NextRequest) => {
  const header = req.headers.get("authorization") ?? "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  const claims = await verifyB2BToken(token);
  if (!claims) throw new ApiError("AUTH_001", "رمز البوابة مفقود أو غير صالح");

  const catalog = await b2bCatalog(claims.cid);
  return ok(catalog);
});
