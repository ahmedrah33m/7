import { NextRequest } from "next/server";
import { z } from "zod";
import { enforceRateLimit } from "@/lib/api";
import { handler, ok, parseBody } from "@/lib/api";
import { db } from "@/lib/db";
import { b2bLogin } from "@/lib/b2b-service";
import { signB2BToken } from "@/lib/jwt";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/b2b/auth — customer portal login {code, pin}.
 * Uniform AUTH_003 on any failure (no code/PIN probing).
 */
const loginSchema = z.object({
  code: z.string().trim().min(1, "رمز العميل مطلوب").max(40),
  pin: z.string().trim().min(4, "رقم البوابة مطلوب").max(8),
});

export const POST = handler(async (req: NextRequest) => {
  enforceRateLimit(`b2b:${req.headers.get("x-forwarded-for") ?? "local"}`, 30);
  await ensureSeeded();
  const body = await parseBody(req, loginSchema);

  // Single-tenant demo resolves the (sole) seed company; production takes
  // companyId from the subdomain/host mapping.
  const company = await db.company.findFirst({ where: { deletedAt: null }, select: { id: true } });
  if (!company) throw Object.assign(new Error("no-company"), { code: "SRV_001" });

  const customer = await b2bLogin(company.id, body.code, body.pin);
  const { token, expiresIn } = await signB2BToken({ id: customer.id, companyId: customer.companyId, code: customer.code });

  return ok({
    token,
    expires_in: expiresIn,
    customer: {
      id: customer.id,
      code: customer.code,
      name: customer.name,
      discount_pct: customer.discountPct,
      balance: customer.balance,
      credit_limit: customer.creditLimit,
    },
  });
});
