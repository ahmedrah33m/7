import { NextRequest } from "next/server";
import { z } from "zod";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { verifyB2BToken } from "@/lib/jwt";
import { b2bCreateOrder } from "@/lib/b2b-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/b2b/orders — submit a portal order (B2B token).
 * Prices are snapshotted from the customer's OWN pricing server-side —
 * the client cannot inject a price.
 */
const orderSchema = z.object({
  notes: z.string().trim().max(300).optional().nullable(),
  lines: z
    .array(
      z.object({
        product_id: z.number().int().positive(),
        qty: z.number().positive("الكمية أكبر من صفر"),
      })
    )
    .min(1, "أضف بندًا واحدًا على الأقل")
    .max(40),
});

export const POST = handler(async (req: NextRequest) => {
  const header = req.headers.get("authorization") ?? "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  const claims = await verifyB2BToken(token);
  if (!claims) throw new ApiError("AUTH_001", "رمز البوابة مفقود أو غير صالح");

  const body = await parseBody(req, orderSchema);
  const result = await b2bCreateOrder(claims.cid, {
    lines: body.lines.map((l) => ({ product_id: l.product_id, qty: l.qty })),
    notes: body.notes ?? null,
  });
  return ok(result, undefined, 201);
});
