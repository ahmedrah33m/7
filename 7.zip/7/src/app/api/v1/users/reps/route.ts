import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/users/reps — active sales reps (id/name/username).
 * Accessible to anyone who can create/view sales documents — used by
 * the invoice form «البيع باسم مندوب» selector (§20).
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req);
  const reps = await db.user.findMany({
    where: {
      companyId: session.companyId,
      deletedAt: null,
      isActive: true,
      roles: { some: { role: { code: "SALES_REP", deletedAt: null } } },
    },
    select: { id: true, fullName: true, username: true },
    orderBy: { fullName: "asc" },
  });
  return ok(reps.map((r) => ({ id: r.id, name: r.fullName, username: r.username })));
});
