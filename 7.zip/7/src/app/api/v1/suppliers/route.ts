import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { dec, moneyR } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/suppliers — list (parties.suppliers.view)
 * POST /api/v1/suppliers — create (parties.suppliers.create)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "parties.suppliers.view");
  const url = new URL(req.url);
  const q = url.searchParams.get("q")?.trim() ?? "";

  const rows = await db.supplier.findMany({
    where: {
      companyId: session.companyId,
      deletedAt: null,
      ...(q ? { OR: [{ name: { contains: q } }, { code: { contains: q } }, { phone: { contains: q } }] } : {}),
    },
    orderBy: { id: "asc" },
    take: 200,
  });

  return ok(
    rows.map((s) => ({
      id: s.id,
      code: s.code,
      name: s.name,
      phone: s.phone,
      address: s.address,
      balance: s.balance,
      is_active: s.isActive,
    }))
  );
});

const createSchema = z.object({
  name: z.string().trim().min(2, "اسم المورد مطلوب").max(120),
  phone: z.string().trim().max(30).optional().nullable(),
  address: z.string().trim().max(250).optional().nullable(),
  opening_balance: z.number().min(0).optional().default(0),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "parties.suppliers.create");
  const body = await parseBody(req, createSchema);

  const count = await db.supplier.count({ where: { companyId: session.companyId } });
  const code = `S-${String(count + 1).padStart(5, "0")}`;

  const dup = await db.supplier.findFirst({
    where: { companyId: session.companyId, name: body.name, deletedAt: null },
  });
  if (dup) throw new ApiError("VAL_002", "اسم المورد موجود مسبقًا");

  const created = await db.supplier.create({
    data: {
      companyId: session.companyId,
      code,
      name: body.name,
      phone: body.phone ?? null,
      address: body.address ?? null,
      balance: moneyR(dec(body.opening_balance ?? 0)),
      createdBy: session.userId,
    },
  });

  return ok(
    {
      id: created.id,
      code: created.code,
      name: created.name,
      balance: created.balance,
      is_active: created.isActive,
    },
    undefined,
    201
  );
});
