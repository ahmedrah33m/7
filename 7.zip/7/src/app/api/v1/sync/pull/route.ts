import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { pullDelta } from "@/lib/sync-service";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/sync/pull?cursor=<ISO>&entities=products,customers,stock_balances
 * Cursor-delta download for offline clients. Any authenticated user with
 * product/customer visibility may pull (same data the UI reads).
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "products.products.view");
  const url = new URL(req.url);
  const cursor = url.searchParams.get("cursor");
  const entities = url.searchParams.get("entities")?.split(",").map((s) => s.trim()).filter(Boolean);
  const limit = url.searchParams.get("limit") ? Number(url.searchParams.get("limit")) : undefined;

  const result = await pullDelta(session.companyId, session.warehouseIds, { cursor, entities, limit });
  return ok(result);
});
