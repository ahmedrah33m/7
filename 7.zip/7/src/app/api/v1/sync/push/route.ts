import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { pushOperations } from "@/lib/sync-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/sync/push — offline queue drain (sales.invoices.create or
 * finance.payments.create per op entity). Idempotent by op_uuid:
 * replaying a push returns the ORIGINAL result flagged SYNC_001.
 */
const pushSchema = z.object({
  device_id: z.string().trim().max(120).optional().nullable(),
  operations: z
    .array(
      z.object({
        op_uuid: z.string().trim().min(8, "op_uuid مطلوب (UUID من العميل)").max(64),
        entity: z.enum(["sales_invoice", "collection"]),
        action: z.literal("create"),
        payload: z.record(z.string(), z.unknown()),
        client_ref: z.string().max(120).optional().nullable(),
      })
    )
    .min(1, "أرسل عملية واحدة على الأقل")
    .max(50, "الحد الأقصى 50 عملية بالدفعة"),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req); // per-op permission enforced here per entity
  const body = await parseBody(req, pushSchema);

  // Each queued op must still pass the RBAC gate of its entity — a queued
  // offline op never bypasses permissions.
  const needed = new Set(body.operations.map((o) => o.entity));
  if (needed.has("sales_invoice") && !session.permissions.has("sales.invoices.create")) {
    return ok({ results: body.operations.map((o) => ({ op_uuid: o.op_uuid, status: "REJECTED", code: "PERM_001", error: { code: "PERM_001", message: "العملية تتطلب الصلاحية: sales.invoices.create" } })), summary: { total: body.operations.length, applied: 0, duplicates: 0, rejected: body.operations.length } });
  }
  if (needed.has("collection") && !session.permissions.has("finance.payments.create")) {
    return ok({ results: body.operations.map((o) => o.entity === "collection" ? ({ op_uuid: o.op_uuid, status: "REJECTED", code: "PERM_001", error: { code: "PERM_001", message: "العملية تتطلب الصلاحية: finance.payments.create" } }) : null).filter(Boolean), summary: { total: body.operations.length, applied: 0, duplicates: 0, rejected: body.operations.length } });
  }

  const actor = {
    userId: session.userId,
    companyId: session.companyId,
    warehouseIds: session.warehouseIds,
    ip: req.headers.get("x-forwarded-for") ?? undefined,
    userAgent: req.headers.get("user-agent") ?? undefined,
  };

  const result = await pushOperations(actor, { device_id: body.device_id ?? null, operations: body.operations });
  return ok(result);
});
