import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { validatePackaging } from "@/lib/product-validation";
import { syncProductPrices, getEffectivePrices } from "@/lib/product-pricing";
import { asCurrency, getCompanyUsdRate, type Currency } from "@/lib/currency";
import { num, nOrNull, sumOf } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/products — list (permission: products.products.view)
 *      ?q=search · ?category_id= · ?page=1 · ?per_page=50
 *      includes total on-hand qty across company warehouses.
 * POST /api/v1/products — create (permission: products.products.create)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "products.products.view");
  const url = new URL(req.url);
  const q = url.searchParams.get("q")?.trim() ?? "";
  const categoryId = url.searchParams.get("category_id");
  const page = Math.max(1, Number(url.searchParams.get("page") ?? 1));
  const perPage = Math.min(100, Math.max(1, Number(url.searchParams.get("per_page") ?? 50)));

  const where = {
    companyId: session.companyId,
    deletedAt: null,
    ...(q ? { OR: [{ name: { contains: q } }, { code: { contains: q } }, { barcode: { contains: q } }] } : {}),
    ...(categoryId ? { categoryId: Number(categoryId) } : {}),
  };

  const [rows, total] = await Promise.all([
    db.product.findMany({
      where,
      include: {
        category: { select: { id: true, name: true } },
        stockBalances: { select: { qty: true } },
      },
      orderBy: { id: "asc" },
      skip: (page - 1) * perPage,
      take: perPage,
    }),
    db.product.count({ where }),
  ]);

  // ---- Phase 2 §5: الأسعار المهيكلة السارية (عملة كل سعر كما خُزّنت) ----
  const priceMap = await getEffectivePrices(session.companyId, rows.map((p) => p.id));
  const companyRate = await getCompanyUsdRate(session.companyId);

  const priceOf = (pid: number, type: string, unit: string) =>
    priceMap.get(pid)?.find((r) => r.priceType === type && r.unit === unit) ?? null;

  return ok(
    rows.map((p) => {
      const salePiece = priceOf(p.id, "SALE", "PIECE");
      const salePack = priceOf(p.id, "SALE", "PACKAGE");
      const cost = priceOf(p.id, "COST", "PIECE");
      return {
        id: p.id,
        code: p.code,
        name: p.name,
        name_en: p.nameEn,
        barcode: p.barcode,
        unit: p.unit, // الوحدة الأساسية (حبة) — §1
        // packaging config (§7): 1 كرتونة = 12 حبة + سعر الكرتونة المستقل
        pack_unit: p.packUnit,
        pack_qty: nOrNull(p.packQty),
        pack_sale_price: nOrNull(p.packSalePrice), // إسقاط IQD للتوافق
        category: p.category,
        cost_price: num(p.costPrice),
        sale_price: num(p.salePrice),
        // ---- Phase 2: العملة المصدر لكل سعر + القيمة كما خُزّنت (§6) ----
        sale_currency: salePiece?.currency ?? "IQD",
        sale_amount: salePiece ? num(salePiece.amount) : num(p.salePrice),
        pack_sale_currency: salePack?.currency ?? "IQD",
        pack_sale_amount: salePack ? num(salePack.amount) : nOrNull(p.packSalePrice),
        cost_currency: cost?.currency ?? "IQD",
        cost_amount: cost ? num(cost.amount) : num(p.costPrice),
        prices: {
          sale_piece: salePiece ? { amount: num(salePiece.amount), currency: salePiece.currency } : null,
          sale_package: salePack ? { amount: num(salePack.amount), currency: salePack.currency } : null,
          cost_piece: cost ? { amount: num(cost.amount), currency: cost.currency } : null,
        },
        company_usd_rate: companyRate,
        tax_rate_pct: num(p.taxRatePct),
        min_stock: num(p.minStock),
        is_active: p.isActive,
        stock_total: num(sumOf(p.stockBalances, (b) => b.qty)),
      };
    }),
    { total, page, per_page: perPage }
  );
});

const createSchema = z.object({
  name: z.string().trim().min(2, "اسم المنتج قصير جدًا").max(200),
  code: z.string().trim().max(40).optional(),
  name_en: z.string().trim().max(200).optional(),
  barcode: z.string().trim().max(60).optional(),
  category_id: z.number().int().positive().optional().nullable(),
  unit: z.string().trim().min(1).max(30).default("قطعة"),
  // packaging (§7): pack_unit مثل "كرتونة" · pack_qty مثل 12 · pack_sale_price سعر الكرتونة
  pack_unit: z.string().trim().max(30).optional().nullable(),
  pack_qty: z.number().max(100000).optional().nullable(),
  pack_sale_price: z.number().min(0).optional().nullable(),
  cost_price: z.number().min(0).default(0),
  sale_price: z.number().min(0).default(0),
  // ---- Phase 2 §6: عملة كل سعر كما دخل (IQD افتراضياً) ------------------
  cost_currency: z.enum(["IQD", "USD"]).optional(),
  sale_currency: z.enum(["IQD", "USD"]).optional(),
  pack_sale_currency: z.enum(["IQD", "USD"]).optional(),
  // سعر الصرف المطلوب مع أي سعر USD — لتحديث الإسقاط بالدينار فقط
  exchange_rate: z.number().positive().max(1000000).optional().nullable(),
  tax_rate_pct: z.number().min(0).max(100).default(0),
  min_stock: z.number().min(0).default(0),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "products.products.create");
  const body = await parseBody(req, createSchema);

  if (body.category_id != null) {
    const cat = await db.category.findFirst({
      where: { id: body.category_id, companyId: session.companyId, deletedAt: null },
    });
    if (!cat) throw new ApiError("VAL_003", "التصنيف غير موجود");
  }

  if (body.barcode) {
    const dup = await db.product.findFirst({
      where: { companyId: session.companyId, barcode: body.barcode, deletedAt: null },
    });
    if (dup) throw new ApiError("VAL_002", "الباركود مسجل لمنتج آخر");
  }

  // Auto code: P-00001 style, conflict-safe retry.
  let code = body.code?.trim();
  if (!code) {
    const max = await db.product.aggregate({
      where: { companyId: session.companyId },
      _max: { id: true },
    });
    code = `P-${String((max._max.id ?? 0) + 1).padStart(5, "0")}`;
  } else {
    const dup = await db.product.findFirst({
      where: { companyId: session.companyId, code, deletedAt: null },
    });
    if (dup) throw new ApiError("VAL_002", "كود المنتج مستخدم مسبقًا");
  }

  // ---- Phase 2 §3: التحقق المركزي من التعبئة (وليس في الواجهة فقط) ------
  // يرفض: packQty<=1 · packUnit==unit · سعر عبوة بلا وحدة · وحدة بلا كمية
  const pack = validatePackaging({
    unit: body.unit,
    packUnit: body.pack_unit,
    packQty: body.pack_qty,
    packSalePrice: body.pack_sale_price,
  });

  const product = await db.$transaction(async (tx) => {
    const created = await tx.product.create({
      data: {
        companyId: session.companyId,
        categoryId: body.category_id ?? null,
        code,
        name: body.name,
        nameEn: body.name_en || null,
        barcode: body.barcode || null,
        unit: pack.unit,
        packUnit: pack.packUnit,
        packQty: pack.packQty,
        // الإسقاط المبدئي — syncProductPrices يضبطه بدقة داخل المعاملة
        packSalePrice: pack.hasPack ? (body.pack_sale_price ?? null) : null,
        costPrice: body.cost_price,
        salePrice: body.sale_price,
        taxRatePct: body.tax_rate_pct,
        minStock: body.min_stock,
        createdBy: session.userId,
      },
    });

    // ---- Phase 2 §6: الأسعار تُخزَّن بعملتها كما دخلت + الإسقاط بالدينار
    await syncProductPrices(tx, {
      companyId: session.companyId,
      productId: created.id,
      packQty: pack.packQty,
      userId: session.userId,
      input: {
        cost_price: body.cost_price,
        sale_price: body.sale_price,
        pack_sale_price: pack.hasPack ? (body.pack_sale_price ?? null) : null,
        cost_currency: asCurrency(body.cost_currency),
        sale_currency: asCurrency(body.sale_currency),
        pack_sale_currency: asCurrency(body.pack_sale_currency),
        exchange_rate: body.exchange_rate ?? null,
      },
    });

    return created;
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    { action: "CREATE", module: "products", entityType: "product", entityId: product.id, newValues: { code: product.code, name: product.name, sale_price: num(product.salePrice), pack_unit: product.packUnit, pack_qty: nOrNull(product.packQty) } }
  );

  return ok(
    {
      id: product.id,
      code: product.code,
      name: product.name,
      unit: product.unit,
      pack_unit: product.packUnit,
      pack_qty: nOrNull(product.packQty),
      pack_sale_price: nOrNull(product.packSalePrice),
      cost_price: num(product.costPrice),
      sale_price: num(product.salePrice),
      min_stock: num(product.minStock),
    },
    undefined,
    201
  );
});
