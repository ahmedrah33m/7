import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { totalOnHand } from "@/lib/inventory";
import { validatePackaging } from "@/lib/product-validation";
import { syncProductPrices } from "@/lib/product-pricing";
import { asCurrency, type Currency } from "@/lib/currency";
import { Decimal, dec, moneyR, num } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/** R10 — تحويل مالي/كمي إلى number للحدود مع حفظ null (حقول قابلة للإفراغ). */
const nOrNull = (v: unknown): number | null => (v == null ? null : num(v));

const patchSchema = z.object({
  name: z.string().trim().min(2).max(200).optional(),
  barcode: z.string().trim().max(60).optional().nullable(),
  unit: z.string().trim().min(1).max(30).optional(),
  category_id: z.number().int().positive().optional().nullable(), // نقل المنتج بين التصنيفات (تعديل المنتجات)
  // packaging (§7) — pack_unit بدون pack_qty مرفوض (PRD_005)
  pack_unit: z.string().trim().max(30).optional().nullable(),
  pack_qty: z.number().max(100000).optional().nullable(),
  pack_sale_price: z.number().min(0).optional().nullable(),
  cost_price: z.number().min(0).optional(),
  sale_price: z.number().min(0).optional(),
  // ---- Phase 2 §6: عملة كل سعر كما دخل ----------------------------------
  cost_currency: z.enum(["IQD", "USD"]).optional(),
  sale_currency: z.enum(["IQD", "USD"]).optional(),
  pack_sale_currency: z.enum(["IQD", "USD"]).optional(),
  exchange_rate: z.number().positive().max(1000000).optional().nullable(),
  tax_rate_pct: z.number().min(0).max(100).optional(),
  min_stock: z.number().min(0).optional(),
  is_active: z.boolean().optional(),
  // ---- Phase 4 §5: التكلفة المعيارية (منفصلة عن آخر تكلفة شراء) --------
  standard_cost: z.number().min(0).optional().nullable(),
});

/** العملة الفعالة الحالية لسعر منتج من الطبقة المهيكلة (IQD افتراضياً). */
async function currentPriceCurrency(productId: number, priceType: string, unit: string): Promise<Currency> {
  const row = await db.productPrice.findFirst({
    where: { productId, priceType, unit, isActive: true },
    orderBy: { effectiveFrom: "desc" },
    select: { currency: true },
  });
  return asCurrency(row?.currency);
}

/**
 * PATCH /api/v1/products/[id] — update product incl. packaging config
 * (permission: products.products.edit).
 * Phase 2: التحقق المركزي للتعبئة + الأسعار تُخزَّن بعملتها (§3/§6).
 */
export const PATCH = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "products.products.edit");
  const { id } = await ctx.params;
  const productId = Number(id);
  if (!Number.isInteger(productId)) throw new ApiError("VAL_003", "معرّف منتج غير صالح");

  const product = await db.product.findFirst({
    where: { id: productId, companyId: session.companyId, deletedAt: null },
  });
  if (!product) throw new ApiError("VAL_003", "المنتج غير موجود");

  const body = await parseBody(req, patchSchema);

  // التصنيف ملك حصري لشركته — تصنيف شركة أخرى مرفوض (عزل صارم)
  if (body.category_id !== undefined && body.category_id !== null) {
    const cat = await db.category.findFirst({
      where: { id: body.category_id, companyId: session.companyId, deletedAt: null },
      select: { id: true },
    });
    if (!cat) throw new ApiError("VAL_003", "التصنيف غير موجود");
  }

  // ---- الحالة النهائية المدموجة (body فوق القائم) للتحقق المركزي §3 ------
  const finalUnit = body.unit !== undefined ? body.unit : product.unit;
  const packUnitProvided = body.pack_unit !== undefined;
  const packQtyProvided = body.pack_qty !== undefined;
  const packPriceProvided = body.pack_sale_price !== undefined;
  // إزالة التعبئة صراحةً (pack_unit فارغ) تُسقط أيضاً الكمية والسعر المخزنين —
  // كانتا صفات للعبوة المحذوفة (توافق مع نمط الواجهة: pack_unit:"" يزيل التعبئة)
  const clearingPack = packUnitProvided && !String(body.pack_unit ?? "").trim();

  const pack = validatePackaging({
    unit: finalUnit,
    packUnit: packUnitProvided ? body.pack_unit : product.packUnit,
    packQty: clearingPack ? null : (packQtyProvided ? body.pack_qty : (product.packQty != null ? num(product.packQty) : null)), // ⚠️ لا تُسيهل null إلى 0 — يُطلق PRD_002 زوراً على منتجات بلا تعبئة
    packSalePrice: clearingPack ? null : (packPriceProvided ? body.pack_sale_price : nOrNull(product.packSalePrice)),
  });

  // ---- الحالة النهائية للأسعار: القيم الجديدة أو المخزنة + العملات فعالة
  const [costCur, saleCur, packCur] = await Promise.all([
    currentPriceCurrency(product.id, "COST", "PIECE"),
    currentPriceCurrency(product.id, "SALE", "PIECE"),
    currentPriceCurrency(product.id, "SALE", "PACKAGE"),
  ]);
  const finalCost = body.cost_price !== undefined ? body.cost_price : product.costPrice; // number | Decimal
  const finalSale = body.sale_price !== undefined ? body.sale_price : product.salePrice; // number | Decimal
  // سعر العبوة: صريح > القائم (مع نفس كمية التعبئة) > اشتقاق من سعر الحبة × الكمية
  let finalPackPrice: Decimal | null = null;
  if (pack.hasPack) {
    finalPackPrice =
      packPriceProvided && body.pack_sale_price != null
        ? dec(body.pack_sale_price)
        : product.packSalePrice != null && dec(product.packQty).equals(dec(pack.packQty))
          ? dec(product.packSalePrice)
          : moneyR(dec(finalSale).mul(pack.packQty ?? 1));
  }

  const updated = await db.$transaction(async (tx) => {
    const row = await tx.product.update({
      where: { id: product.id },
      data: {
        ...(body.name !== undefined ? { name: body.name } : {}),
        ...(body.barcode !== undefined ? { barcode: body.barcode } : {}),
        ...(body.unit !== undefined ? { unit: pack.unit } : {}),
        ...(body.category_id !== undefined ? { categoryId: body.category_id } : {}),
        packUnit: pack.packUnit,
        packQty: pack.packQty,
        packSalePrice: pack.hasPack ? finalPackPrice : null,
        costPrice: finalCost,
        salePrice: finalSale,
        ...(body.tax_rate_pct !== undefined ? { taxRatePct: body.tax_rate_pct } : {}),
        ...(body.min_stock !== undefined ? { minStock: body.min_stock } : {}),
        ...(body.is_active !== undefined ? { isActive: body.is_active } : {}),
        // Phase 4 §5 — التكلفة المعيارية: null = إلغاء صريح، غياب = بلا تغيير
        ...(body.standard_cost !== undefined ? { standardCost: body.standard_cost } : {}),
        updatedBy: session.userId,
      },
    });

    // ---- §6: مزامنة الطبقة المهيكلة (عملة كما دخلت) + الإسقاط بالدينار
    await syncProductPrices(tx, {
      companyId: session.companyId,
      productId: product.id,
      packQty: pack.packQty,
      userId: session.userId,
      input: {
        cost_price: num(finalCost),
        sale_price: num(finalSale),
        pack_sale_price: pack.hasPack ? nOrNull(finalPackPrice) : null,
        cost_currency: asCurrency(body.cost_currency ?? costCur),
        sale_currency: asCurrency(body.sale_currency ?? saleCur),
        pack_sale_currency: asCurrency(body.pack_sale_currency ?? packCur),
        exchange_rate: body.exchange_rate ?? null,
      },
    });

    return row;
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    {
      action: "UPDATE",
      module: "products",
      entityType: "product",
      entityId: product.id,
      oldValues: { name: product.name, sale_price: num(product.salePrice), category_id: product.categoryId, pack_unit: product.packUnit, pack_qty: nOrNull(product.packQty), pack_sale_price: nOrNull(product.packSalePrice) },
      newValues: { name: updated.name, sale_price: num(updated.salePrice), category_id: updated.categoryId, pack_unit: updated.packUnit, pack_qty: nOrNull(updated.packQty), pack_sale_price: nOrNull(updated.packSalePrice) },
    }
  );

  return ok({
    id: updated.id, code: updated.code, name: updated.name, unit: updated.unit,
    category_id: updated.categoryId,
    pack_unit: updated.packUnit, pack_qty: nOrNull(updated.packQty), pack_sale_price: nOrNull(updated.packSalePrice),
    sale_price: num(updated.salePrice), is_active: updated.isActive,
    standard_cost: nOrNull(updated.standardCost), last_cost: nOrNull(updated.lastCost),
  });
});

/**
 * DELETE /api/v1/products/[id] — حذف المنتج (soft delete)
 *   (permission: products.products.delete).
 *   · يُمنع حذف منتج لديه مخزون في أي مستودع — يجب تصفيره أولًا
 *     (المرتجعات/الفواتير التاريخية تبقى سليمة لأن الحذف ناعم).
 */
export const DELETE = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "products.products.delete");
  const { id } = await ctx.params;
  const productId = Number(id);
  if (!Number.isInteger(productId)) throw new ApiError("VAL_003", "معرّف منتج غير صالح");

  const product = await db.product.findFirst({
    where: { id: productId, companyId: session.companyId, deletedAt: null },
  });
  if (!product) throw new ApiError("VAL_003", "المنتج غير موجود");

  const onHand = await totalOnHand(session.companyId, product.id);
  if (onHand.isPositive()) {
    throw new ApiError("PRD_001", `لا يمكن حذف «${product.name}» — لديه مخزون (${num(onHand)} ${product.unit})`, [
      { field: "stock", message: "صفّر مخزون المنتج من كل المستودعات أولًا (تسوية جرد أو تحويل)" },
    ]);
  }

  const deleted = await db.product.update({
    where: { id: product.id },
    data: { deletedAt: new Date(), isActive: false, updatedBy: session.userId },
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    {
      action: "DELETE",
      module: "products",
      entityType: "product",
      entityId: product.id,
      oldValues: { code: product.code, name: product.name, sale_price: num(product.salePrice), is_active: product.isActive },
      newValues: { deleted: true },
    }
  );

  return ok({ id: deleted.id, code: deleted.code, deleted: true });
});
