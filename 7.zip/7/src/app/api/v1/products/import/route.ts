import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { writeAudit } from "@/lib/audit";
import { validatePackaging } from "@/lib/product-validation";
import { syncProductPrices } from "@/lib/product-pricing";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/products/import (products.products.import)
 * Bulk CSV import — one row per line:
 *   name, sale_price, cost_price, unit, barcode, min_stock,
 *   pack_unit, pack_qty, pack_sale_price
 * Header line is optional and ignored. Duplicates (existing barcode or
 * name+code collision) are SKIPPED, never fatal — the response reports
 * created/skipped per row so the operator can fix and re-submit.
 * Phase 2 §3: كل صف يمر بالتحقق المركزي للتعبئة — الصف غير الصالح يُرفض
 * ويُبلّغ عنه ولا يوقف باقي الاستيراد.
 */
const bodySchema = z.object({
  csv: z.string().min(1, "الصق محتوى CSV").max(300_000),
  update_prices: z.boolean().optional().default(false),
});

type ParsedRow = {
  name: string; salePrice: number; costPrice: number;
  unit: string; barcode: string | null; minStock: number;
  packUnit: string | null; packQty: number | null; packSalePrice: number | null;
};

function parseCsv(csv: string): { rows: ParsedRow[]; errors: { line: number; message: string }[] } {
  const errors: { line: number; message: string }[] = [];
  const rows: ParsedRow[] = [];
  const lines = csv.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);

  lines.forEach((raw, idx) => {
    const lineNo = idx + 1;
    // سطر الرأس (إنجليزي أو عربي: name/اسم/الاسم/المنتج) يُتجاهل
    if (idx === 0 && /^(name|اسم|الاسم|المنتج)\s*,/i.test(raw)) return;
    const cells = raw.split(",").map((c) => c.trim());
    const name = cells[0];
    if (!name || name.length < 2) {
      errors.push({ line: lineNo, message: "الاسم مفقود أو قصير جدًا" });
      return;
    }
    const salePrice = Number(cells[1] ?? 0);
    if (!isFinite(salePrice) || salePrice < 0) {
      errors.push({ line: lineNo, message: `سعر بيع غير صالح: «${cells[1] ?? ""}»` });
      return;
    }
    const costPrice = Number(cells[2] ?? 0);
    if (!isFinite(costPrice) || costPrice < 0) {
      errors.push({ line: lineNo, message: `سعر تكلفة غير صالح: «${cells[2] ?? ""}»` });
      return;
    }
    const unit = cells[3] || "قطعة";
    const barcode = cells[4] || null;
    const minStock = Number(cells[5] ?? 0);
    // ---- Phase 2 §3: أعمدة التعبئة الاختيارية (pack_unit, pack_qty, pack_sale_price)
    const packUnit = (cells[6] || "").toLowerCase() === "null" ? null : cells[6] || null;
    const packQtyRaw = Number(cells[7] ?? NaN);
    const packQty = Number.isFinite(packQtyRaw) && packQtyRaw > 0 ? packQtyRaw : null;
    const packPriceRaw = Number(cells[8] ?? NaN);
    const packSalePrice = Number.isFinite(packPriceRaw) && packPriceRaw >= 0 ? packPriceRaw : null;
    rows.push({
      name,
      salePrice,
      costPrice,
      unit,
      barcode: barcode && barcode.toLowerCase() !== "null" ? barcode : null,
      minStock: isFinite(minStock) && minStock >= 0 ? minStock : 0,
      packUnit,
      packQty,
      packSalePrice,
    });
  });

  return { rows, errors };
}

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "products.products.import");
  const body = await parseBody(req, bodySchema);

  const { rows, errors } = parseCsv(body.csv);
  let created = 0;
  let skipped = 0;
  const skippedNames: string[] = [];

  // Existing lookups for duplicate detection
  const existing = await db.product.findMany({
    where: { companyId: session.companyId, deletedAt: null },
    select: { id: true, name: true, barcode: true },
  });
  const nameSet = new Set(existing.map((p) => p.name));
  const barcodeSet = new Set(existing.filter((p) => p.barcode).map((p) => p.barcode as string));

  const maxAgg = await db.product.aggregate({ where: { companyId: session.companyId }, _max: { id: true } });
  let nextCode = (maxAgg._max.id ?? 0) + 1;

  for (const r of rows) {
    if ((r.barcode && barcodeSet.has(r.barcode)) || nameSet.has(r.name)) {
      skipped += 1;
      skippedNames.push(r.name);
      continue;
    }
    // ---- Phase 2 §3: التحقق المركزي للتعبئة لكل صف — غير الصالح يُبلّغ ويُتخطى
    let pack: ReturnType<typeof validatePackaging>;
    try {
      pack = validatePackaging({
        unit: r.unit,
        packUnit: r.packUnit,
        packQty: r.packQty,
        packSalePrice: r.packSalePrice,
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : "صف غير صالح";
      errors.push({ line: rows.indexOf(r) + 1, message: `${r.name}: ${msg}` });
      continue;
    }
    const code = `P-${String(nextCode).padStart(5, "0")}`;
    nextCode += 1;
    await db.$transaction(async (tx) => {
      const created = await tx.product.create({
        data: {
          companyId: session.companyId,
          code,
          name: r.name,
          unit: pack.unit,
          barcode: r.barcode,
          costPrice: r.costPrice,
          salePrice: r.salePrice,
          minStock: r.minStock,
          packUnit: pack.packUnit,
          packQty: pack.packQty,
          packSalePrice: pack.hasPack ? (pack.packSalePrice ?? null) : null,
          createdBy: session.userId,
        },
      });
      await syncProductPrices(tx, {
        companyId: session.companyId,
        productId: created.id,
        packQty: pack.packQty,
        userId: session.userId,
        input: {
          cost_price: r.costPrice,
          sale_price: r.salePrice,
          pack_sale_price: pack.hasPack ? (pack.packSalePrice ?? null) : null,
        },
      });
    });
    if (r.barcode) barcodeSet.add(r.barcode);
    nameSet.add(r.name);
    created += 1;
  }

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    { action: "IMPORT", module: "products", entityType: "product", entityId: 0, newValues: { created, skipped, errors: errors.length } }
  );

  return ok({ created, skipped, skipped_names: skippedNames.slice(0, 10), errors });
});
