import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

const SUPPORT_PRIORITIES = ["LOW", "NORMAL", "HIGH"] as const;

const createSchema = z.object({
  subject: z.string().trim().min(3, "الموضوع قصير جدًا (3 أحرف على الأقل)").max(160, "الموضوع طويل جدًا"),
  body: z.string().trim().min(10, "اشرح المشكلة بمزيد من التفاصيل (10 أحرف على الأقل)").max(2000, "الرسالة طويلة جدًا"),
  priority: z.enum(SUPPORT_PRIORITIES).default("NORMAL"),
});

/**
 * POST /api/v1/support — أرسل رسالة دعم فني لمالك المنصة (أي مستخدم مُصادق).
 * تُحفَظ الرسالة على مستوى الشركة النشطة للمرسل — يراها مالك المنصة نقطيًا
 * في GET والموظفون في شركته (نطاق COMPANY) والمستخدم لنفسه فقط.
 */
export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req);
  const body = await parseBody(req, createSchema);

  const msg = await db.supportMessage.create({
    data: {
      companyId: session.companyId,
      userId: session.userId,
      subject: body.subject,
      body: body.body,
      priority: body.priority,
    },
    select: { id: true, subject: true, priority: true, status: true, createdAt: true },
  });

  return ok({ message: msg }, undefined, 201);
});

/**
 * GET /api/v1/support — سرد رسائل الدعم حسب نطاق الجلسة:
 *   GLOBAL (مالك المنصة)  → كل الرسائل من كل الشركات (وعدد المفتوحة)
 *   COMPANY (مدير شركة)   → رسائل شركته فقط
 *   BRANCH/WAREHOUSE/...  → رسائله هو فقط
 * معامل اختياري: ?scope=open يعرض المفتوحة فقط، ?mine=1 لرسائل المستخدم فقط.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req);
  const url = new URL(req.url);
  const scope = url.searchParams.get("scope") ?? "all";
  const mineOnly = url.searchParams.get("mine") === "1";

  const isOwner = session.scopeType === "GLOBAL";
  const isCompanyManager = session.scopeType === "COMPANY";

  // قاعدة النطاق: المديرون يرون ما تُنشره شركتهم؛ الموظفون يرون رسائلهم فقط.
  let whereUserId: number | undefined;
  let whereCompanyId: number | undefined;
  if (mineOnly || (!isOwner && !isCompanyManager)) whereUserId = session.userId;
  else if (isCompanyManager) whereCompanyId = session.companyId;

  const [messages, viewerOpenCount] = await Promise.all([
    db.supportMessage.findMany({
      where: {
        status: scope === "open" ? "OPEN" : undefined,
        userId: whereUserId,
        companyId: whereCompanyId,
      },
      select: {
        id: true,
        subject: true,
        body: true,
        priority: true,
        status: true,
        createdAt: true,
        resolvedAt: true,
        user: { select: { id: true, fullName: true, username: true } },
        company: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 100,
    }),
    db.supportMessage.count({
      where: {
        status: "OPEN",
        userId: mineOnly || (!isOwner && !isCompanyManager) ? session.userId : undefined,
        companyId: isCompanyManager && !mineOnly ? session.companyId : undefined,
      },
    }),
  ]);

  return ok({
    messages,
    open_count: viewerOpenCount,
    viewer: { scope_type: session.scopeType, is_owner: isOwner },
  });
});

/**
 * PATCH /api/v1/support?id=<id> — حصر دعم مفتوحة كمحلولة.
 * مالك المنصة (GLOBAL) يغلق أي رسالة، أو مدير الشركة لرسائل شركته.
 */
export const PATCH = handler(async (req: NextRequest) => {
  const session = await guard(req);
  const url = new URL(req.url);
  const id = Number(url.searchParams.get("id"));
  if (!Number.isInteger(id) || id <= 0) throw new ApiError("VAL_001", "معرف رسالة غير صالح");

  const msg = await db.supportMessage.findFirst({
    where: { id },
    select: { id: true, companyId: true, status: true },
  });
  if (!msg) throw new ApiError("VAL_003", "رسالة الدعم غير موجودة");

  if (msg.status === "RESOLVED") return ok({ message: { id: msg.id, status: "RESOLVED" }, already: true });

  const isOwner = session.scopeType === "GLOBAL";
  const isCompanyManager = session.scopeType === "COMPANY";
  if (!isOwner && !(isCompanyManager && msg.companyId === session.companyId)) {
    throw new ApiError("PERM_001", "حل رسائل الدعم متاح لمالك المنصة أو مدير الشركة");
  }

  await db.supportMessage.update({
    where: { id: msg.id },
    data: { status: "RESOLVED", resolvedAt: new Date(), resolvedBy: session.userId },
  });

  return ok({ message: { id: msg.id, status: "RESOLVED" } });
});