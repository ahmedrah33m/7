import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/categories — list (permission: products.products.view)
 * POST /api/v1/categories — create (permission: products.products.create)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "products.products.view");

  const rows = await db.category.findMany({
    where: { companyId: session.companyId, deletedAt: null },
    include: { _count: { select: { products: { where: { deletedAt: null } } } } },
    orderBy: { id: "asc" },
  });

  return ok(rows.map((c) => ({ id: c.id, name: c.name, products_count: c._count.products })));
});

const createSchema = z.object({
  name: z.string().trim().min(2, "اسم التصنيف قصير جدًا").max(120),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "products.products.create");
  const body = await parseBody(req, createSchema);

  const dup = await db.category.findFirst({
    where: { companyId: session.companyId, name: body.name, deletedAt: null },
  });
  if (dup) throw new ApiError("VAL_002", "التصنيف موجود مسبقًا");

  const cat = await db.category.create({
    data: { companyId: session.companyId, name: body.name, createdBy: session.userId },
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    { action: "CREATE", module: "products", entityType: "category", entityId: cat.id, newValues: { name: cat.name } }
  );

  return ok({ id: cat.id, name: cat.name }, undefined, 201);
});
