import { NextRequest, NextResponse } from "next/server";
import { storage } from "@/lib/storage";
import { guard } from "@/lib/auth";
import { db } from "@/lib/db";
import { handler } from "@/lib/api";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/files/[name] — RP5 §10: توريد ملفات بمصادقة إلزامية وعزل شركة.
 *  · 401 بلا جلسة صالحة (المصادقة أول حاجز — UUID ليس حدّاً أمنياً).
 *  · سجل FileObject في القاعدة شرط: 404 موحد إن غاب.
 *  · ملكية الشركة: rec.companyId ≠ session.companyId → 404 (بلا كشف وجود).
 *  · companyId=null (ملفات Legacy سبقت طبقة الملكية — صور منتجات) → لأي مستخدم مصادق.
 *  · Cache-Control private — الملفات لا تُخزَّن مؤقتاً في وكلاء مشتركة.
 *  · اسم الملف UUID + امتداد بيضاء (لا traversal) — كما هو في الطبقة السفلية.
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req); // مصادقة + حد معدل — بلا صلاحية مخصصة (أي مستخدم نشط)
  const { name } = await ctx.params;

  const rec = await db.fileObject.findUnique({ where: { name } });
  if (!rec) {
    return NextResponse.json({ success: false, code: "VAL_003", message: "الملف غير موجود" }, { status: 404 });
  }
  if (rec.companyId != null && rec.companyId !== session.companyId) {
    // عزل المستأجرين — 404 موحد (لا 403 لكشف الوجود عبر الشركات)
    return NextResponse.json({ success: false, code: "VAL_003", message: "الملف غير موجود" }, { status: 404 });
  }

  const row = await storage.read(name);
  if (!row) {
    return NextResponse.json({ success: false, code: "VAL_003", message: "الملف غير موجود" }, { status: 404 });
  }
  return new NextResponse(new Uint8Array(row.data), {
    status: 200,
    headers: {
      "Content-Type": row.mime,
      "Content-Length": String(row.data.length),
      "Cache-Control": "private, max-age=31536000, immutable",
      "X-Content-Type-Options": "nosniff",
    },
  });
});
