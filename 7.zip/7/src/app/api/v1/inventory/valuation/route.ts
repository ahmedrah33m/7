import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { round2 } from "@/lib/utils-server";
import { branchFilter } from "@/lib/branch-scope";
import { Prisma } from "@prisma/client";

export const dynamic = "force-dynamic";

// Decimal → number عند حدود العرض (تقرير تجميعي — المخرجات round2).
const N = (x: unknown): number => (x == null ? 0 : Number(x));

/**
 * GET /api/v1/inventory/valuation — §66 Inventory Costing & Overview.
 * (permission: inventory.valuation.view)
 *
 * Every number below is computed LIVE from the database (ledger + balances)
 * — no mock data, no constants:
 *   · totals      — total qty, cost value (qty × applicable cost), potential
 *                   sales value, expected gross profit, distinct items.
 *   · health      — low stock / out of stock / dead stock (count + value).
 *   · cogs        — posting-time COGS from invoice line cost snapshots
 *                   (§66.10): net sales − net COGS = gross profit.
 *   · by_location — per warehouse: qty / cost value / sales value / %.
 *   · by_type     — MAIN | BRANCH | REP | TRANSIT | DAMAGED rollup (§66.28).
 *   · rep_inventory — rep vehicle stock valuation (§66.17/66.27).
 *   · adjustments — stocktake variances booked as ADJUSTMENT movements
 *                   (§66.14–66.16): surplus in / shortage out / net value.
 *   · top_value / most_moving / dead_items — item-level widgets.
 *   · product_id  — "أين توجد المادة؟" per-location breakdown (§66.4).
 *
 * Applicable cost (§66.7/66.8): WEIGHTED AVERAGE derived from the immutable
 * ledger (Σ IN qty×unitCost ÷ Σ IN qty), falling back to the product's
 * master cost_price when the item has no costed inbound movement yet.
 * All reads respect the session's warehouse + branch scope.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "inventory.valuation.view");
  const url = new URL(req.url);
  const companyId = session.companyId;

  // ---- settings (§66.7 cost method · §66.23 dead-stock definition) ----
  // القيم مخزّنة JSON-stringify (اتفاق مسار الإعدادات) — تُفكّ بأمان
  const parseVal = (raw: unknown): unknown => {
    if (typeof raw !== "string") return raw;
    try { return JSON.parse(raw); } catch { return raw; }
  };
  const settingRows = await db.setting.findMany({
    where: { companyId, key: { in: ["inventory.cost_method", "inventory.dead_stock_days"] } },
    select: { key: true, value: true },
  });
  const settingMap = new Map(settingRows.map((s) => [s.key, parseVal(s.value)]));
  const costMethodRaw = settingMap.get("inventory.cost_method");
  const costMethod = typeof costMethodRaw === "string" ? costMethodRaw : "WEIGHTED_AVERAGE";
  const deadDaysCfg = Number(settingMap.get("inventory.dead_stock_days"));
  const deadDays = [30, 60, 90, 180].includes(Number(url.searchParams.get("dead_days")))
    ? Number(url.searchParams.get("dead_days"))
    : [30, 60, 90, 180].includes(deadDaysCfg) ? deadDaysCfg : 90;

  // ---- scoped warehouses — §66 valuation follows the BRANCH SCOPE (chain
  // step 4), not operational warehouse grants: a dashboard is a reporting
  // view. branchScope.all (OWNER/admin) → كل مستودعات الشركة؛ مقيّد بفرع
  // (BRANCH_MANAGER@BSR) → مستودعات فرعه فقط. المندوب/الكاشير لا يملكان
  // inventory.valuation.view أصلًا فيصلان هنا 403.
  const scope = {
    all: session.scopeType === "GLOBAL" || session.scopeType === "COMPANY",
    ids: session.branchIds,
  };
  const warehouses = await db.warehouse.findMany({
    where: {
      companyId,
      deletedAt: null,
      ...(scope.all ? {} : { branchId: { in: scope.ids } }),
    },
    include: { branch: { select: { id: true, code: true, name: true } } },
    orderBy: { id: "asc" },
  });
  const whIds = warehouses.map((w) => w.id);
  const whMap = new Map(warehouses.map((w) => [w.id, w]));

  const empty = {
    totals: { total_qty: 0, cost_value: 0, sales_value: 0, potential_profit: 0, items_count: 0 },
    health: { low_stock: 0, out_of_stock: 0, dead_stock: { count: 0, value: 0 } },
    cogs: { period: "month", revenue: 0, returns_value: 0, net_sales: 0, cogs: 0, returned_cogs: 0, gross_profit: 0, margin_pct: 0 },
    by_location: [] as unknown[], by_type: [] as unknown[], rep_inventory: { items: [] as unknown[], total_value: 0 },
    adjustments: { count: 0, surplus_qty: 0, surplus_value: 0, shortage_qty: 0, shortage_value: 0, net_value: 0, recent: [] as unknown[] },
    top_value_items: [] as unknown[], most_moving_items: [] as unknown[], dead_items: [] as unknown[],
    meta: { cost_method: costMethod, dead_days: deadDays, generated_at: new Date().toISOString(), warehouses_scoped: whIds.length },
  };
  if (whIds.length === 0) return ok(empty, { scoped_out: true });

  // ---- balances + products ----
  const balances = await db.stockBalance.findMany({
    where: { companyId, warehouseId: { in: whIds }, product: { deletedAt: null } },
    include: {
      product: { select: { id: true, code: true, name: true, unit: true, salePrice: true, costPrice: true, minStock: true } },
    },
  });

  // ---- applicable cost from the ledger (weighted average + last cost) ----
  const avgRows = await db.$queryRaw<{ product_id: number; q: number | bigint; v: number | bigint }[]>(
    Prisma.sql`SELECT product_id, SUM(qty) AS q, SUM(qty * unit_cost) AS v
               FROM stock_movements
               WHERE company_id = ${companyId} AND direction = 'IN' AND unit_cost IS NOT NULL
               GROUP BY product_id`,
  );
  const lastRows = await db.$queryRaw<{ product_id: number; unit_cost: number }[]>(
    Prisma.sql`SELECT product_id, unit_cost
               FROM stock_movements
               WHERE id IN (
                 SELECT MAX(id) FROM stock_movements
                 WHERE company_id = ${companyId} AND direction = 'IN' AND unit_cost IS NOT NULL
                 GROUP BY product_id
               )`,
  );
  const avgCost = new Map<number, number>();
  const lastCost = new Map<number, number>();
  for (const r of avgRows) {
    const q = Number(r.q), v = Number(r.v);
    if (q > 0) avgCost.set(Number(r.product_id), v / q);
  }
  for (const r of lastRows) lastCost.set(Number(r.product_id), Number(r.unit_cost));
  const applicableCost = (productId: number, masterCost: number): number => {
    const m = costMethod === "STANDARD" ? masterCost : avgCost.get(productId);
    return m != null && m > 0 ? m : masterCost;
  };

  // ---- where-is-item mode (§66.4) ----
  const pid = Number(url.searchParams.get("product_id") ?? 0);
  if (pid > 0) {
    const product = await db.product.findFirst({
      where: { id: pid, companyId, deletedAt: null },
      select: { id: true, code: true, name: true, unit: true, salePrice: true, costPrice: true },
    });
    if (!product) return ok({ ...empty, product: null }, { product_not_found: true });
    const unitCost = applicableCost(pid, N(product.costPrice));
    const rows = balances
      .filter((b) => b.productId === pid)
      .map((b) => ({
        warehouse_id: b.warehouseId,
        warehouse: whMap.get(b.warehouseId)?.name ?? `#${b.warehouseId}`,
        warehouse_type: whMap.get(b.warehouseId)?.type ?? "MAIN",
        qty: round2(N(b.qty)),
        cost_value: round2(N(b.qty) * unitCost),
      }));
    const totalQty = round2(rows.reduce((s, r) => s + r.qty, 0));
    return ok({
      ...empty,
      product: {
        ...product,
        avg_cost: costMethod === "STANDARD" ? null : round2(avgCost.get(pid) ?? 0) || null,
        last_cost: round2(lastCost.get(pid) ?? 0) || null,
        applicable_cost: round2(unitCost),
        locations: rows,
        totals: {
          qty: totalQty,
          cost_value: round2(totalQty * unitCost),
          sales_value: round2(totalQty * N(product.salePrice)),
          potential_profit: round2(totalQty * (N(product.salePrice) - unitCost)),
        },
      },
    });
  }

  // ---- per-warehouse / per-product aggregation ----
  const perWh = new Map<number, { qty: number; cost: number; sales: number }>();
  const perProduct = new Map<number, { product: (typeof balances)[number]["product"]; qty: number; cost: number; sales: number }>();
  let totalQty = 0, totalCost = 0, totalSales = 0;
  for (const b of balances) {
    const cost = applicableCost(b.productId, N(b.product.costPrice));
    const qty = N(b.qty);
    const cv = qty * cost;
    const sv = qty * N(b.product.salePrice);
    totalQty += qty; totalCost += cv; totalSales += sv;
    const w = perWh.get(b.warehouseId) ?? { qty: 0, cost: 0, sales: 0 };
    w.qty += qty; w.cost += cv; w.sales += sv;
    perWh.set(b.warehouseId, w);
    const p = perProduct.get(b.productId) ?? { product: b.product, qty: 0, cost: 0, sales: 0 };
    p.qty += qty; p.cost += cv; p.sales += sv;
    perProduct.set(b.productId, p);
  }

  // ---- health: low / out of stock (tracked products, scoped view) ----
  const trackedActive = await db.product.findMany({
    where: { companyId, deletedAt: null, isActive: true, minStock: { gt: 0 } },
    select: { id: true },
  });
  const trackedIds = new Set(trackedActive.map((p) => p.id));
  let lowStock = 0, outOfStock = 0;
  for (const [, agg] of perProduct) {
    if (N(agg.product.minStock) <= 0) continue;
    if (agg.qty <= 0) outOfStock++;
    else if (agg.qty <= N(agg.product.minStock)) lowStock++;
  }
  for (const id of trackedIds) if (!perProduct.has(id)) outOfStock++;

  // ---- dead stock (§66.23): stocked but no OUT movement in the window ----
  const cutoff = new Date(Date.now() - deadDays * 24 * 60 * 60 * 1000);
  const movedOut = await db.stockMovement.findMany({
    where: { companyId, warehouseId: { in: whIds }, direction: "OUT", createdAt: { gte: cutoff } },
    select: { productId: true },
    distinct: ["productId"],
  });
  const movedOutIds = new Set(movedOut.map((m) => m.productId));
  const deadItems: { id: number; code: string; name: string; unit: string; qty: number; value: number; last_out: string | null; days_since: number | null }[] = [];
  let deadCount = 0, deadValue = 0;
  const lastOutRows = await db.stockMovement.groupBy({
    by: ["productId"],
    where: { companyId, warehouseId: { in: whIds }, direction: "OUT" },
    _max: { createdAt: true },
  });
  const lastOutMap = new Map(lastOutRows.map((r) => [r.productId, r._max.createdAt]));
  for (const [pid2, agg] of perProduct) {
    if (agg.qty <= 0 || movedOutIds.has(pid2)) continue;
    deadCount++;
    deadValue += agg.cost;
    if (deadItems.length < 8) {
      const lo = lastOutMap.get(pid2) ?? null;
      deadItems.push({
        id: pid2, code: agg.product.code, name: agg.product.name, unit: agg.product.unit,
        qty: round2(agg.qty), value: round2(agg.cost),
        last_out: lo ? lo.toISOString() : null,
        days_since: lo ? Math.floor((Date.now() - lo.getTime()) / 86400000) : null,
      });
    }
  }
  deadItems.sort((a, b) => b.value - a.value);

  // ---- COGS (§66.10): posting-time snapshots from invoice lines ----
  const startOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  const bF = branchFilter(session);
  const invLines = await db.salesInvoiceLine.findMany({
    where: { invoice: { companyId, deletedAt: null, status: "POSTED", invoiceDate: { gte: startOfMonth }, ...bF } },
    select: { qty: true, lineTotal: true, unitCost: true },
  });
  const retLines = await db.salesReturnLine.findMany({
    where: { returnDoc: { companyId, deletedAt: null, returnDate: { gte: startOfMonth }, ...bF } },
    select: { qty: true, lineTotal: true, invoiceLine: { select: { unitCost: true } } },
  });
  let revenue = 0, cogs = 0;
  for (const l of invLines) { revenue += N(l.lineTotal); cogs += N(l.qty) * N(l.unitCost); }
  let returnsValue = 0, returnedCogs = 0;
  for (const l of retLines) {
    returnsValue += N(l.lineTotal);
    returnedCogs += N(l.qty) * N(l.invoiceLine?.unitCost);
  }
  const netSales = round2(revenue - returnsValue);
  const netCogs = round2(cogs - returnedCogs);
  const grossProfit = round2(netSales - netCogs);

  // ---- adjustments = booked stocktake variances (§66.14–66.16) ----
  const adjMoves = await db.stockMovement.findMany({
    where: { companyId, warehouseId: { in: whIds }, refType: "ADJUSTMENT" },
    include: { product: { select: { code: true, name: true, unit: true, costPrice: true } }, warehouse: { select: { name: true } } },
    orderBy: { id: "desc" },
    take: 300,
  });
  let adjCount = 0, surplusQty = 0, surplusValue = 0, shortageQty = 0, shortageValue = 0;
  const recentAdj: unknown[] = [];
  for (const m of adjMoves) {
    adjCount++;
    const cost = m.unitCost != null ? N(m.unitCost) : applicableCost(m.productId, N(m.product.costPrice));
    const val = Math.abs(N(m.qty) * cost);
    if (m.direction === "IN") { surplusQty += N(m.qty); surplusValue += val; }
    else { shortageQty += N(m.qty); shortageValue += val; }
    if (recentAdj.length < 5) {
      recentAdj.push({
        id: m.id, direction: m.direction, qty: round2(N(m.qty)), value: round2(val),
        product: m.product.name, unit: m.product.unit, warehouse: m.warehouse.name,
        note: m.note, at: m.createdAt.toISOString(),
      });
    }
  }

  // ---- most moving (OUT qty in the last 30 days) ----
  const movingCutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const moved = await db.stockMovement.groupBy({
    by: ["productId"],
    where: { companyId, warehouseId: { in: whIds }, direction: "OUT", createdAt: { gte: movingCutoff } },
    _sum: { qty: true },
    orderBy: { _sum: { qty: "desc" } },
    take: 8,
  });
  const movingIds = moved.map((m) => m.productId);
  const movingProducts = movingIds.length
    ? await db.product.findMany({ where: { id: { in: movingIds } }, select: { id: true, code: true, name: true, unit: true } })
    : [];
  const mpMap = new Map(movingProducts.map((p) => [p.id, p]));
  const mostMoving = moved
    .filter((m) => mpMap.has(m.productId))
    .map((m) => ({ ...mpMap.get(m.productId)!, out_qty: round2(N(m._sum.qty)) }));

  // ---- widgets ----
  const byLocation = warehouses
    .map((w) => {
      const agg = perWh.get(w.id) ?? { qty: 0, cost: 0, sales: 0 };
      return {
        warehouse_id: w.id, code: w.code, name: w.name, type: w.type,
        branch: w.branch.name,
        qty: round2(agg.qty), cost_value: round2(agg.cost), sales_value: round2(agg.sales),
        pct: totalCost > 0 ? Math.round((agg.cost / totalCost) * 1000) / 10 : 0,
      };
    })
    .filter((r) => r.qty !== 0 || r.cost_value !== 0)
    .sort((a, b) => b.cost_value - a.cost_value);

  const TYPE_LABELS: Record<string, string> = {
    MAIN: "المستودعات الرئيسية", BRANCH: "فروع", REP: "مخازن المندوبين",
    TRANSIT: "قيد النقل", DAMAGED: "تالف",
  };
  const typeAgg = new Map<string, { qty: number; cost: number }>();
  for (const w of warehouses) {
    const agg = perWh.get(w.id) ?? { qty: 0, cost: 0 };
    const t = typeAgg.get(w.type) ?? { qty: 0, cost: 0 };
    t.qty += agg.qty; t.cost += agg.cost;
    typeAgg.set(w.type, t);
  }
  const byType = [...typeAgg.entries()]
    .map(([type, agg]) => ({
      type, label: TYPE_LABELS[type] ?? type,
      qty: round2(agg.qty), cost_value: round2(agg.cost),
      pct: totalCost > 0 ? Math.round((agg.cost / totalCost) * 1000) / 10 : 0,
    }))
    .filter((r) => r.cost_value !== 0 || r.qty !== 0)
    .sort((a, b) => b.cost_value - a.cost_value);

  const repItems = byLocation
    .filter((r) => r.type === "REP")
    .map((r) => ({ warehouse_id: r.warehouse_id, name: r.name, branch: r.branch, qty: r.qty, cost_value: r.cost_value, sales_value: r.sales_value }));

  const topValue = [...perProduct.values()]
    .filter((a) => a.qty > 0)
    .sort((a, b) => b.cost - a.cost)
    .slice(0, 8)
    .map((a) => ({
      id: a.product.id, code: a.product.code, name: a.product.name, unit: a.product.unit,
      qty: round2(N(a.qty)), avg_cost: round2(applicableCost(a.product.id, N(a.product.costPrice))),
      cost_value: round2(a.cost), sales_value: round2(a.sales),
      pct: totalCost > 0 ? Math.round((a.cost / totalCost) * 1000) / 10 : 0,
    }));

  return ok({
    totals: {
      total_qty: round2(totalQty),
      cost_value: round2(totalCost),
      sales_value: round2(totalSales),
      potential_profit: round2(totalSales - totalCost),
      items_count: [...perProduct.values()].filter((a) => a.qty > 0).length,
    },
    health: {
      low_stock: lowStock,
      out_of_stock: outOfStock,
      dead_stock: { count: deadCount, value: round2(deadValue) },
    },
    cogs: {
      period: "month",
      revenue: round2(revenue),
      returns_value: round2(returnsValue),
      net_sales: netSales,
      cogs: netCogs,
      returned_cogs: round2(returnedCogs),
      gross_profit: grossProfit,
      margin_pct: netSales > 0 ? Math.round((grossProfit / netSales) * 1000) / 10 : 0,
    },
    by_location: byLocation,
    by_type: byType,
    rep_inventory: {
      items: repItems,
      total_value: round2(repItems.reduce((s, r) => s + r.cost_value, 0)),
    },
    adjustments: {
      count: adjCount,
      surplus_qty: round2(surplusQty), surplus_value: round2(surplusValue),
      shortage_qty: round2(shortageQty), shortage_value: round2(shortageValue),
      net_value: round2(surplusValue - shortageValue),
      recent: recentAdj,
    },
    top_value_items: topValue,
    most_moving_items: mostMoving,
    dead_items: deadItems,
    meta: {
      cost_method: costMethod,
      dead_days: deadDays,
      generated_at: new Date().toISOString(),
      warehouses_scoped: whIds.length,
    },
  });
});
