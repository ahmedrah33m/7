import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { db } from "@/lib/db";
import { createTransfer } from "@/lib/transfers-service";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/inventory/transfers — list (inventory.transfers.view)
 * POST /api/v1/inventory/transfers — create + auto-dispatch
 *      (inventory.transfers.create) — atomic numbering + stock OUT.
 *      Receiving is a separate endpoint (double-receive blocked).
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "inventory.transfers.view");
  const url = new URL(req.url);
  const status = url.searchParams.get("status") ?? undefined;
  const perPage = Math.min(100, Math.max(1, Number(url.searchParams.get("per_page") ?? 50)));

  const where = {
    companyId: session.companyId,
    deletedAt: null,
    ...(status ? { status } : {}),
  };

  const [rows, total] = await Promise.all([
    db.stockTransfer.findMany({
      where,
      include: {
        fromWarehouse: { select: { code: true, name: true } },
        toWarehouse: { select: { code: true, name: true } },
        creator: { select: { fullName: true } },
        lines: { include: { product: { select: { code: true, name: true, unit: true } } } },
      },
      orderBy: { id: "desc" },
      take: perPage,
    }),
    db.stockTransfer.count({ where }),
  ]);

  return ok(
    rows.map((t) => ({
      id: t.id,
      number: t.number,
      status: t.status,
      from: t.fromWarehouse,
      to: t.toWarehouse,
      notes: t.notes,
      lines: t.lines.map((l) => ({
        product: l.product,
        qty: l.qty,
      })),
      dispatched_at: t.dispatchedAt,
      received_at: t.receivedAt,
      created_by: t.creator.fullName,
      created_at: t.createdAt,
    })),
    { total }
  );
});

const createSchema = z.object({
  from_warehouse_id: z.number().int().positive("اختر مستودع المصدر"),
  to_warehouse_id: z.number().int().positive("اختر مستودع الوجهة"),
  notes: z.string().trim().max(300).optional().nullable(),
  auto_dispatch: z.boolean().optional().default(true),
  lines: z
    .array(
      z.object({
        product_id: z.number().int().positive(),
        qty: z.number().positive("كمية البند يجب أن تكون أكبر من صفر"),
      })
    )
    .min(1, "أضف بندًا واحدًا على الأقل"),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "inventory.transfers.create");
  const body = await parseBody(req, createSchema);

  const result = await createTransfer(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    {
      fromWarehouseId: body.from_warehouse_id,
      toWarehouseId: body.to_warehouse_id,
      notes: body.notes ?? null,
      autoDispatch: body.auto_dispatch,
      lines: body.lines.map((l) => ({ productId: l.product_id, qty: l.qty })),
    }
  );

  return ok(result, undefined, 201);
});
