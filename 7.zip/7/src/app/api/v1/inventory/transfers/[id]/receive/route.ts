import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { receiveTransfer } from "@/lib/transfers-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/inventory/transfers/[id]/receive
 *   (inventory.transfers.create) — stock IN to destination, exactly once.
 *   Second receive → VAL_004 "التحويل مستلم مسبقًا".
 */
const receiveSchema = z.object({
  lines: z
    .array(
      z.object({
        product_id: z.number().int().positive(),
        qty: z.number().positive(),
      })
    )
    .optional()
    .nullable(), // null = receive everything in full
});

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "inventory.transfers.create");
  const { id } = await ctx.params;
  const transferId = Number(id);
  if (!Number.isInteger(transferId)) throw new ApiError("VAL_003", "معرّف تحويل غير صالح");

  const body = await parseBody(req, receiveSchema).catch(() => ({ lines: null }));

  const result = await receiveTransfer(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    transferId,
    { lines: body.lines?.map((l) => ({ productId: l.product_id, qty: l.qty })) ?? null }
  );

  return ok(result);
});
