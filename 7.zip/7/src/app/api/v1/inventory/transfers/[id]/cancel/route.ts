import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, ApiError } from "@/lib/api";
import { cancelTransfer } from "@/lib/transfers-service";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/inventory/transfers/[id]/cancel
 *   (inventory.transfers.create) — only DRAFT cancellable (nothing moved).
 */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "inventory.transfers.create");
  const { id } = await ctx.params;
  const transferId = Number(id);
  if (!Number.isInteger(transferId)) throw new ApiError("VAL_003", "معرّف تحويل غير صالح");

  const result = await cancelTransfer(
    {
      userId: session.userId,
      companyId: session.companyId,
      warehouseIds: session.warehouseIds,
      ip: req.headers.get("x-forwarded-for") ?? undefined,
      userAgent: req.headers.get("user-agent") ?? undefined,
    },
    transferId
  );

  return ok(result);
});
