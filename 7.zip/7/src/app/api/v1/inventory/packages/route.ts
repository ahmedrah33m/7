import { NextRequest } from "next/server";
import { guard } from "@/lib/auth";
import { handler, ok, ApiError } from "@/lib/api";
import { db } from "@/lib/db";
import { packInfoOf, summarizePackages, ensurePackageCoverage, txOf } from "@/lib/packaging";
import { num } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/inventory/packages?warehouse_id=&product_id=
 * (permission: inventory.stock.view) — Open Package Tracking (§10):
 * closed packages + open packages + pieces inside the open one +
 * total pieces, plus the per-package state (codes/remaining) and the
 * recent packaging ledger entries. Never shows fractional cartons (§45).
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "inventory.stock.view");
  const url = new URL(req.url);
  const warehouseId = Number(url.searchParams.get("warehouse_id"));
  const productId = Number(url.searchParams.get("product_id"));
  if (!Number.isInteger(warehouseId) || warehouseId <= 0) {
    throw new ApiError("VAL_001", "حدد المستودع", [{ field: "warehouse_id", message: "مطلوب" }]);
  }
  if (!Number.isInteger(productId) || productId <= 0) {
    throw new ApiError("VAL_001", "حدد المنتج", [{ field: "product_id", message: "مطلوب" }]);
  }
  if (!session.warehouseIds.includes(warehouseId)) throw new ApiError("SCOPE_002");

  const companyId = session.companyId;
  const product = await db.product.findFirst({
    where: { id: productId, companyId, deletedAt: null },
  });
  if (!product) throw new ApiError("VAL_003", "المنتج غير موجود");

  const info = packInfoOf(product);
  if (!info.hasPack) {
    const balance = await db.stockBalance.findUnique({
      where: { warehouseId_productId: { warehouseId, productId } },
    });
    return ok({
      has_pack: false,
      unit: product.unit,
      total_pieces: num(balance?.qty),
      text: `${num(balance?.qty)} ${product.unit}`,
    });
  }

  // lazily sync legacy stock into packages so the view is always truthful
  await db.$transaction((tx) =>
    ensurePackageCoverage(txOf(tx), { companyId, warehouseId, productId, info, userId: session.userId })
  );

  const rows = await db.package.findMany({
    where: { companyId, warehouseId, productId, status: { not: "EMPTY" } },
    orderBy: [{ status: "asc" }, { id: "asc" }],
  });
  const balance = await db.stockBalance.findUnique({
    where: { warehouseId_productId: { warehouseId, productId } },
  });
  const summary = summarizePackages(rows, info);

  const recentLedger = await db.packagingLedger.findMany({
    where: { companyId, warehouseId, productId },
    orderBy: { id: "desc" },
    take: 15,
    select: {
      packageCode: true, direction: true, openingQty: true, issuedQty: true,
      remainingQty: true, refNumber: true, note: true, createdAt: true,
    },
  });

  return ok({
    has_pack: true,
    pack_unit: info.packUnit,
    pack_qty: info.packQty,
    ...summary,
    stock_balance: num(balance?.qty),
    packages: rows.map((r) => ({
      id: r.id, code: r.code, status: r.status,
      original_qty: num(r.originalQty), remaining_qty: num(r.remainingQty),
      opened_at: r.openedAt,
    })),
    recent_ledger: recentLedger.map((e) => ({
      ...e,
      openingQty: num(e.openingQty),
      issuedQty: num(e.issuedQty),
      remainingQty: num(e.remainingQty),
    })),
  });
});
