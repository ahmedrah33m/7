import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok } from "@/lib/api";
import { dec, num } from "@/lib/decimal";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/inventory/balances?warehouse_id= — stock levels
 * (permission: inventory.stock.view) — warehouse scope enforced from
 * session (chain step 4): a rep only ever sees his own warehouse.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "inventory.stock.view");
  const url = new URL(req.url);
  const q = url.searchParams.get("q")?.trim() ?? "";

  // Scope: requested warehouse must be within session scope (default: all scoped).
  const requested = url.searchParams.get("warehouse_id");
  const warehouseId = requested ? Number(requested) : null;
  if (warehouseId && !session.warehouseIds.includes(warehouseId)) {
    return ok([], { total: 0, warehouse_id: warehouseId, scoped_out: true });
  }

  const rows = await db.stockBalance.findMany({
    where: {
      companyId: session.companyId,
      ...(warehouseId ? { warehouseId } : { warehouseId: { in: session.warehouseIds } }),
      product: {
        deletedAt: null,
        ...(q ? { OR: [{ name: { contains: q } }, { code: { contains: q } }] } : {}),
      },
    },
    include: {
      // v16 — include pack info for carton display
      product: { select: { id: true, code: true, name: true, unit: true, minStock: true, salePrice: true, packUnit: true, packQty: true } },
      warehouse: { select: { id: true, code: true, name: true } },
    },
    orderBy: [{ warehouseId: "asc" }, { productId: "asc" }],
  });

  return ok(
    rows.map((b) => ({
      product_id: b.product.id,
      product_code: b.product.code,
      product_name: b.product.name,
      unit: b.product.unit,
      // v16 — pack info for carton display
      pack_unit: b.product.packUnit,
      pack_qty: b.product.packQty ? num(b.product.packQty) : null,
      min_stock: num(b.product.minStock),
      sale_price: num(b.product.salePrice),
      warehouse: b.warehouse,
      qty: num(b.qty),
      low: dec(b.product.minStock).gt(0) && dec(b.qty).lte(dec(b.product.minStock)),
    })),
    { total: rows.length }
  );
});
