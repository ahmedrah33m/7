import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { applyStockMovement } from "@/lib/inventory";
import { receiveCostLayer, consumeCost, getCompanyCostMethod } from "@/lib/cost-engine";
import { Decimal, dec, moneyR, num } from "@/lib/decimal";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/inventory/movements?warehouse_id=&product_id=&per_page=
 *      — immutable ledger view (permission: inventory.movements.view)
 * POST /api/v1/inventory/movements — stock intake / adjustment
 *      (permission: inventory.movements.create, warehouse scope enforced)
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "inventory.movements.view");
  const url = new URL(req.url);
  const perPage = Math.min(200, Math.max(1, Number(url.searchParams.get("per_page") ?? 50)));
  const warehouseId = url.searchParams.get("warehouse_id");
  const productId = url.searchParams.get("product_id");

  const wId = warehouseId ? Number(warehouseId) : null;
  if (wId && !session.warehouseIds.includes(wId)) return ok([], { total: 0 });

  const rows = await db.stockMovement.findMany({
    where: {
      companyId: session.companyId,
      ...(wId ? { warehouseId: wId } : { warehouseId: { in: session.warehouseIds } }),
      ...(productId ? { productId: Number(productId) } : {}),
    },
    include: {
      product: { select: { code: true, name: true, unit: true } },
      warehouse: { select: { code: true, name: true } },
    },
    orderBy: { id: "desc" },
    take: perPage,
  });

  return ok(
    rows.map((m) => ({
      id: m.id,
      direction: m.direction,
      qty: num(m.qty),
      ref_type: m.refType,
      ref_id: m.refId,
      balance_after: num(m.balanceAfter),
      note: m.note,
      product: m.product,
      warehouse: m.warehouse,
      created_at: m.createdAt,
      created_by: m.createdBy,
    })),
    { total: rows.length }
  );
});

const createSchema = z.object({
  warehouse_id: z.number().int().positive(),
  product_id: z.number().int().positive(),
  direction: z.enum(["IN", "OUT"]).default("IN"),
  qty: z.number().positive("الكمية يجب أن تكون أكبر من صفر"),
  unit_cost: z.number().min(0).optional().nullable(),
  note: z.string().trim().max(300).optional().nullable(),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "inventory.movements.create");
  const body = await parseBody(req, createSchema);

  if (!session.warehouseIds.includes(body.warehouse_id)) throw new ApiError("SCOPE_002");

  const wh = await db.warehouse.findFirst({
    where: { id: body.warehouse_id, companyId: session.companyId, deletedAt: null, isActive: true },
  });
  if (!wh) throw new ApiError("VAL_003", "المستودع غير موجود");

  const product = await db.product.findFirst({
    where: { id: body.product_id, companyId: session.companyId, deletedAt: null },
  });
  if (!product) throw new ApiError("VAL_003", "المنتج غير موجود");

  const result = await db.$transaction(async (tx) => {
    // ---- Phase 4 §1/§2/§3: كل حركة يدوية تعبر محرك التكلفة -------------
    // IN  → طبقة تكلفة جديدة (OPENING_BALANCE — إدخال افتتاحي/يدوي)
    // OUT → صرف من الطبقات بالتكلفة الفعلية حسب طريقة الشركة
    let unitCost: Decimal | number | null;
    if (body.direction === "IN") {
      unitCost = body.unit_cost != null ? moneyR(dec(body.unit_cost)) : dec(product.costPrice);
      await receiveCostLayer({
        tx,
        companyId: session.companyId,
        warehouseId: body.warehouse_id,
        productId: body.product_id,
        sourceType: "OPENING_BALANCE",
        quantity: body.qty,
        unitCost,
        createdBy: session.userId,
      });
    } else {
      const method = await getCompanyCostMethod(session.companyId);
      const cogs = await consumeCost({
        tx,
        companyId: session.companyId,
        warehouseId: body.warehouse_id,
        productId: body.product_id,
        qty: body.qty,
        method,
        fallbackCost: dec(product.costPrice),
        refType: "ADJUSTMENT",
        userId: session.userId,
      });
      unitCost = cogs.unitCost;
    }
    return applyStockMovement({
      tx,
      companyId: session.companyId,
      warehouseId: body.warehouse_id,
      productId: body.product_id,
      direction: body.direction,
      qty: body.qty,
      unitCost,
      refType: body.direction === "IN" ? "INTAKE" : "ADJUSTMENT",
      note: body.note ?? (body.direction === "IN" ? "إدخال مخزون" : "تسوية مخزون"),
      userId: session.userId,
    });
  });

  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: req.headers.get("x-forwarded-for"), userAgent: req.headers.get("user-agent") },
    {
      action: "CREATE",
      module: "inventory",
      entityType: "stock_movement",
      newValues: {
        direction: body.direction,
        qty: body.qty,
        product: product.name,
        warehouse: wh.name,
        balance_after: num(result.balanceAfter),
        note: body.note,
      },
    }
  );

  return ok(
    {
      product: { id: product.id, name: product.name },
      warehouse: { id: wh.id, name: wh.name },
      direction: body.direction,
      qty: body.qty,
      balance_after: num(result.balanceAfter),
    },
    undefined,
    201
  );
});
