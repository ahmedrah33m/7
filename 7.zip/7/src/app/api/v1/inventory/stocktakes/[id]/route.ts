import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody, ApiError } from "@/lib/api";
import { db } from "@/lib/db";
import { effectiveBranchIds } from "@/lib/scope";
import { postStocktake, cancelStocktake } from "@/lib/stocktake-service";

export const dynamic = "force-dynamic";

/**
 * GET  /api/v1/inventory/stocktakes/[id] — detail with lines
 * POST /api/v1/inventory/stocktakes/[id] — { action: "post" | "cancel" }
 *        post   → apply diffs as ADJUSTMENT movements (one-shot)
 *        cancel → DRAFT-only soft cancel
 */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "inventory.stocktakes.view");
  const { id } = await ctx.params;
  const st = await db.stocktake.findFirst({
    where: {
      id: Number(id),
      companyId: session.companyId,
      deletedAt: null,
      branchId: { in: effectiveBranchIds(session) },
    },
    include: {
      warehouse: { select: { code: true, name: true } },
      creator: { select: { fullName: true } },
      poster: { select: { fullName: true } },
      lines: { include: { product: { select: { code: true, name: true, unit: true } } }, orderBy: { id: "asc" } },
    },
  });
  if (!st) throw new ApiError("VAL_003", "أمر الجرد غير موجود");

  return ok({
    id: st.id,
    number: st.number,
    status: st.status,
    warehouse: st.warehouse,
    take_date: st.takeDate,
    posted_at: st.postedAt,
    posted_by: st.poster?.fullName ?? null,
    created_by: st.creator.fullName,
    diff_count: st.diffCount,
    diff_value: st.diffValue,
    notes: st.notes,
    lines: st.lines.map((l) => ({
      product_id: l.productId,
      code: l.product.code,
      product: l.product.name,
      unit: l.product.unit,
      system_qty: l.systemQty,
      counted_qty: l.countedQty,
      diff_qty: l.diffQty,
      unit_cost: l.unitCost,
    })),
  });
});

const actionSchema = z.object({ action: z.enum(["post", "cancel"]) });

export const POST = handler(async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
  const session = await guard(req, "inventory.stocktakes.post");
  const { id } = await ctx.params;
  const body = await parseBody(req, actionSchema);

  const c = { userId: session.userId, companyId: session.companyId, warehouseIds: session.warehouseIds };
  const result =
    body.action === "post"
      ? await postStocktake(c, Number(id))
      : await cancelStocktake(c, Number(id));
  return ok(result);
});
