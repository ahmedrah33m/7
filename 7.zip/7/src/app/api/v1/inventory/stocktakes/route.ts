import { NextRequest } from "next/server";
import { z } from "zod";
import { guard } from "@/lib/auth";
import { handler, ok, parseBody } from "@/lib/api";
import { db } from "@/lib/db";
import { createStocktake, saveCounts } from "@/lib/stocktake-service";
import { branchWhere } from "@/lib/scope";

export const dynamic = "force-dynamic";

/**
 * GET   /api/v1/inventory/stocktakes — list (inventory.stocktakes.view)
 * POST  /api/v1/inventory/stocktakes — open a count sheet for a warehouse
 *       (inventory.stocktakes.create) — snapshot of current balances.
 * PATCH /api/v1/inventory/stocktakes — save counted quantities (DRAFT only).
 */
export const GET = handler(async (req: NextRequest) => {
  const session = await guard(req, "inventory.stocktakes.view");
  const url = new URL(req.url);
  const status = url.searchParams.get("status") ?? undefined;
  const perPage = Math.min(100, Math.max(1, Number(url.searchParams.get("per_page") ?? 50)));

  const where = {
    companyId: session.companyId,
    ...branchWhere(session),
    deletedAt: null,
    ...(status ? { status } : {}),
  };

  const [rows, total] = await Promise.all([
    db.stocktake.findMany({
      where,
      include: {
        warehouse: { select: { code: true, name: true } },
        creator: { select: { fullName: true } },
      },
      orderBy: { id: "desc" },
      take: perPage,
    }),
    db.stocktake.count({ where }),
  ]);

  return ok(
    rows.map((s) => ({
      id: s.id,
      number: s.number,
      status: s.status,
      warehouse: s.warehouse,
      take_date: s.takeDate,
      lines_count: s.linesCount,
      diff_count: s.diffCount,
      diff_value: s.diffValue,
      notes: s.notes,
      created_by: s.creator.fullName,
      posted_at: s.postedAt,
      created_at: s.createdAt,
    })),
    { total }
  );
});

const createSchema = z.object({
  warehouse_id: z.number().int().positive("اختر المستودع"),
  notes: z.string().trim().max(300).optional().nullable(),
});

export const POST = handler(async (req: NextRequest) => {
  const session = await guard(req, "inventory.stocktakes.create");
  const body = await parseBody(req, createSchema);
  const result = await createStocktake(
    { userId: session.userId, companyId: session.companyId, warehouseIds: session.warehouseIds },
    { warehouseId: body.warehouse_id, notes: body.notes ?? null }
  );
  return ok(result, undefined, 201);
});

const saveSchema = z.object({
  id: z.number().int().positive(),
  counts: z
    .array(
      z.object({
        product_id: z.number().int().positive(),
        counted_qty: z.number().min(0, "الكمية المعدودة لا تكون سالبة"),
      })
    )
    .min(1, "أدخل الكميات المعدودة"),
});

export const PATCH = handler(async (req: NextRequest) => {
  const session = await guard(req, "inventory.stocktakes.edit");
  const body = await parseBody(req, saveSchema);
  const result = await saveCounts(
    { userId: session.userId, companyId: session.companyId, warehouseIds: session.warehouseIds },
    body.id,
    body.counts
  );
  return ok(result);
});
