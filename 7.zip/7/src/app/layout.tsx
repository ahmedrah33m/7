import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "sonner";

const SITE_URL = "https://kayaniq.com";
const SITE_NAME = "نظام ميدان للمبيعات والتوزيع";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: SITE_NAME,
    template: `%s | ${SITE_NAME}`,
  },
  description:
    "ميدان — نظام عراقي لإدارة المبيعات والتوزيع: فواتير البيع، المخزون والمستودعات، المشتريات، الذمم والمالية، المندوبون الميدانيون، بوابة B2B، والتقارير.",
  keywords: [
    "نظام ميدان",
    "برنامج مبيعات وتوزيع",
    "نظام فواتير العراق",
    "إدارة المخزون",
    "برنامج مستودعات",
    "نظام حسابات ومبيعات",
    "تطبيق مندوبين مبيعات",
    "نظام إدارة أعمال عربي",
    "Maydan ERP",
    "sales & distribution Iraq",
  ],
  authors: [{ name: "ميدان الاقتصاد" }],
  creator: "ميدان الاقتصاد",
  publisher: "ميدان الاقتصاد",
  applicationName: SITE_NAME,
  category: "business",
  formatDetection: { telephone: false, address: false, email: false },
  openGraph: {
    type: "website",
    locale: "ar_IQ",
    url: SITE_URL,
    siteName: SITE_NAME,
    title: SITE_NAME,
    description:
      "منصة عراقية متكاملة لإدارة البيع والمخزون والميداني — فواتير، مستودعات، ذمم، تقارير، وبوابة عملاء.",
    images: [{ url: "/opengraph-image", width: 1200, height: 630, alt: SITE_NAME }],
  },
  twitter: {
    card: "summary_large_image",
    title: SITE_NAME,
    description: "نظام ميدان — بيع · مخزون · مشتريات · مالية · ميداني · بوابة B2B",
    images: ["/opengraph-image"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large", "max-snippet": -1 },
  },
  alternates: { canonical: "/" },
  icons: {
    icon: "/icons/icon-192.png",
    apple: "/icons/icon-512.png",
  },
  manifest: "/manifest.webmanifest",
};

// بيانات منظمة (JSON-LD) — هوية المنظمة + الموقع لفهم محركات البحث
const jsonLd = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      name: "ميدان الاقتصاد",
      url: SITE_URL,
      logo: `${SITE_URL}/icons/icon-512.png`,
      address: { "@type": "PostalAddress", addressCountry: "IQ" },
    },
    {
      "@type": "WebSite",
      name: SITE_NAME,
      url: SITE_URL,
      inLanguage: "ar",
      potentialAction: {
        "@type": "SearchAction",
        target: `${SITE_URL}/?q={search_term_string}`,
        "query-input": "required name=search_term_string",
      },
    },
    {
      "@type": "SoftwareApplication",
      name: SITE_NAME,
      url: SITE_URL,
      applicationCategory: "BusinessApplication",
      operatingSystem: "Any",
      inLanguage: "ar",
      offers: { "@type": "Offer", price: "0", priceCurrency: "IQD" },
      description:
        "منصة عراقية متكاملة لإدارة المبيعات والتوزيع: بيع، مخزون، مشتريات، مالية، ميداني، وبوابة B2B.",
    },
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body className="min-h-screen antialiased">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        {children}
        <Toaster
          position="top-center"
          richColors
          dir="rtl"
          toastOptions={{ style: { fontFamily: "inherit" } }}
        />
      </body>
    </html>
  );
}