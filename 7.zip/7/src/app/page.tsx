"use client";

import * as React from "react";
import { api, loadStoredRefresh, clearTokens, setTokens, type LoginPayload } from "@/lib/client-api";
import { LoginForm } from "@/components/login-form";
import { SalesDashboard } from "@/components/sales-dashboard";
import { Loader2 } from "lucide-react";

interface MeResponse {
  user: { id: number; username: string; full_name: string; company_id: number; branch_id: number | null; scope_type?: string };
  roles: LoginPayload["roles"];
  permissions: string[];
  warehouses: { id: number; code: string; name: string; type: string }[];
  scope?: LoginPayload["scope"];
}

export default function Home() {
  const [session, setSession] = React.useState<LoginPayload | null>(null);
  const [booting, setBooting] = React.useState(true);

  // On mount: silent session restore — stored refresh token → rotate → /me.
  React.useEffect(() => {
    (async () => {
      const rt = loadStoredRefresh();
      if (rt) {
        try {
          const refreshRes = await fetch("/api/v1/auth/refresh", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ refresh_token: rt }),
          });
          const refreshBody = await refreshRes.json();
          if (refreshRes.ok && refreshBody.success) {
            setTokens(refreshBody.data.access_token, refreshBody.data.refresh_token);
            const me = await api<MeResponse>("/api/v1/auth/me");
            if (me.res.ok && me.body.success && me.body.data) {
              const d = me.body.data;
              setSession({
                access_token: refreshBody.data.access_token,
                refresh_token: refreshBody.data.refresh_token,
                expires_in: refreshBody.data.expires_in,
                user: {
                  id: d.user.id,
                  uuid: "",
                  username: d.user.username,
                  full_name: d.user.full_name,
                  company_id: d.user.company_id,
                  branch_id: d.user.branch_id ?? null,
                  scope_type: d.user.scope_type,
                  language: "ar",
                  theme: "system",
                },
                permissions: d.permissions,
                roles: d.roles,
                scope: d.scope,
              });
            }
          } else {
            clearTokens();
          }
        } catch {
          clearTokens();
        }
      }
      setBooting(false);
    })();
  }, []);

  function handleLogin(payload: LoginPayload) {
    setTokens(payload.access_token, payload.refresh_token);
    setSession(payload);
  }

  if (booting) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!session) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <SalesDashboard
      session={session}
      onSession={setSession}
      onLogout={() => { clearTokens(); setSession(null); }}
    />
  );
}
