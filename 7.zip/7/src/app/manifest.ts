import type { MetadataRoute } from "next";

// §58 — PWA manifest: the dashboard is installable on Android/iOS
// (standalone window, RTL Arabic, brand orange). Full offline-capable
// mobile app remains the documented Flutter future work.
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "نظام ميدان لمبيعات والتوزيع",
    short_name: "ميدان",
    description: "ميدان — بيع · مخزون · مشتريات · مالية · ميداني · بوابة B2B",
    lang: "ar",
    dir: "rtl",
    start_url: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#f6f7f9",
    theme_color: "#ea580c",
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
