// =====================================================================
// Next.js instrumentation hook (runs once per server process start).
//
// Boot self-heal: if the database was reset externally (schema intact,
// data wiped — e.g. sandbox lifecycle resets db/custom.db), the app
// re-seeds foundation data automatically instead of failing every
// login with AUTH_003. A 60s probe keeps healing while the server runs.
// =====================================================================

export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  // RP4 §2 — باب أمان الأسرار: في الإنتاج لا يُقبل سر JWT افتراضي أو قصير.
  // (فشل مبكر صريح بدل تشغيل بنظام مصادقة قابل للتزوير)
  if (process.env.NODE_ENV === "production") {
    const s = process.env.JWT_ACCESS_SECRET ?? "";
    if (!s || s.length < 32 || s.includes("dev-access-secret") || s.includes("change-me")) {
      throw new Error(
        "[boot] JWT_ACCESS_SECRET مطلوب في الإنتاج (32+ حرفاً عشوائياً) — اضبطه في .env قبل التشغيل"
      );
    }
  }

  try {
    const { ensureSeeded, syncOwnerPermissions, ensureCashKeeperAccounts } = await import("./lib/seed");
    await ensureSeeded({ force: true });
    // مزامنة كتالوج الصلاحيات مع أدوار المالك (مثال: system.company.delete)
    // — تشغّل كل إقلاع وتتعامل مع قواعد بيانات قائمة (لا تعتمد على إعادة التهيئة).
    await syncOwnerPermissions((m) => console.warn(`[seed] ${m}`));
    // v14 — تفعيل «حساب أمين الصندوق» ذاتياً في كل شركة (حتى القواعد القائمة):
    // دور CASH_KEEPER + مستخدم cashkeeper + صلاحيات إشعارات التسليم فقط.
    await ensureCashKeeperAccounts((m) => console.warn(`[seed] ${m}`));
    setInterval(() => {
      ensureSeeded({ force: true }).catch(() => {});
    }, 60_000);
  } catch (e) {
    console.warn("[instrumentation] boot seed check failed:", (e as Error)?.message?.slice(0, 200));
  }
}
