"use client";

import * as React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { api, getAccessToken, rawFetch, type LoginPayload } from "@/lib/client-api";
import { formatDateTime } from "@/lib/utils";
import { toast } from "sonner";
import {
  CheckCircle2, XCircle, Loader2, FlaskConical, LockKeyhole, ShieldAlert, UserX, RefreshCcw,
} from "lucide-react";

// ---------------------------------------------------------------------
// Live security verification panel — every test hits the REAL API and
// shows the real response. This is the interactive twin of
// scripts/phase0-verify.ts (the CI version).
// ---------------------------------------------------------------------

type TestState = "idle" | "running" | "pass" | "fail";
interface TestResult {
  status: number | string;
  code?: string;
  message?: string;
  detail?: string;
}

interface TestDef {
  id: string;
  title: string;
  description: string;
  expect: string;
  run: () => Promise<{ ok: boolean; result: TestResult }>;
}

async function post(path: string, body: unknown, headers?: Record<string, string>) {
  const { status, body: b } = await rawFetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...(headers ?? {}) },
    body: JSON.stringify(body),
  });
  return { status, body: b };
}

export function SecurityTestsTab({ session }: { session: LoginPayload }) {
  const [states, setStates] = React.useState<Record<string, TestState>>({});
  const [results, setResults] = React.useState<Record<string, TestResult>>({});

  const tests: TestDef[] = React.useMemo(
    () => [
      {
        id: "no-token",
        title: "طلب محمي بدون توكن",
        description: "استدعاء /auth/me دون ترويسة Authorization — يجب أن يُرفض فورًا.",
        expect: "AUTH_001 · 401",
        run: async () => {
          const { status, body } = await rawFetch("/api/v1/auth/me");
          return { ok: status === 401 && body.code === "AUTH_001", result: { status, code: body.code, message: body.message } };
        },
      },
      {
        id: "wrong-password",
        title: "كلمة مرور خاطئة",
        description: "دخول بحساب lockdemo بكلمة مرور خاطئة — عدّاد المحاولات يرتفع.",
        expect: "AUTH_003 · 401",
        run: async () => {
          const { status, body } = await post("/api/v1/auth/login", { username: "lockdemo", password: "Wrong@9999" });
          return { ok: status === 401 && body.code === "AUTH_003", result: { status, code: body.code, message: body.message } };
        },
      },
      {
        id: "lockout",
        title: "قفل الحساب بعد 5 محاولات",
        description: "أربع محاولات خاطئة إضافية على lockdemo — المحاولة الخامسة تقفل الحساب 15 دقيقة.",
        expect: "AUTH_004 · 423 عند المحاولة الخامسة",
        run: async () => {
          let last = { status: 0, body: {} as import("@/lib/client-api").RawApiBody };
          for (let i = 0; i < 4; i++) {
            last = await post("/api/v1/auth/login", { username: "lockdemo", password: "Wrong@9999" });
          }
          const locked = last.status === 423 && last.body.code === "AUTH_004";
          return {
            ok: locked,
            result: {
              status: last.status,
              code: last.body.code,
              message: locked ? last.body.message : "لم يُقفل الحساب — تحقق من العدّاد",
              detail: "5 محاولات فاشلة إجمالًا في هذا الاختبار (1 سابق + 4 الآن)",
            },
          };
        },
      },
      {
        id: "perm-403",
        title: "منع صلاحية غير متوفرة (PERM_001)",
        description: "دخول بصلاحيات الكاشير ثم استدعاء قائمة المستخدمين — يجب رفضه لأن الكاشير لا يملك system.users.view.",
        expect: "PERM_001 · 403",
        run: async () => {
          const login = await post("/api/v1/auth/login", { username: "cashier", password: "Cashier@123" });
          if (login.status !== 200) return { ok: false, result: { status: login.status, code: login.body.code, message: "فشل دخول الكاشير" } };
          const token = (login.body.data as { access_token: string }).access_token;
          const { status, body } = await rawFetch("/api/v1/admin/users", {
            headers: { Authorization: `Bearer ${token}` },
          });
          return { ok: status === 403 && body.code === "PERM_001", result: { status, code: body.code, message: body.message, detail: "دخل الكاشير بنجاح لكن أُوقفت بطلب الإدارة" } };
        },
      },
      {
        id: "refresh-rotation",
        title: "دوران رمز التحديث وكشف إعادة الاستخدام",
        description: "تحديث الجلسة مرتين بالرمز نفسه: الأولى تنجح وتدوّر الرمز، والثانية تكشف الاستهلاك وتُبطل السلسلة كلها.",
        expect: "الأولى 200 · الثانية AUTH_006 · 401",
        run: async () => {
          // Fresh session for a dedicated token
          const login = await post("/api/v1/auth/login", { username: "auditor", password: "Auditor@123" });
          if (login.status !== 200) return { ok: false, result: { status: login.status, message: "فشل دخول auditor" } };
          const rt = (login.body.data as { refresh_token: string }).refresh_token;

          const first = await post("/api/v1/auth/refresh", { refresh_token: rt });
          const second = await post("/api/v1/auth/refresh", { refresh_token: rt }); // reuse!
          const okResult = first.status === 200 && second.status === 401 && second.body.code === "AUTH_006";
          return {
            ok: okResult,
            result: {
              status: `${first.status} ثم ${second.status}`,
              code: second.body.code,
              message: okResult
                ? "التدوير نجح، وإعادة استخدام الرمز القديم أبطلت السلسلة كاملة"
                : "سلوك غير متوقع",
            },
          };
        },
      },
      {
        id: "forged-token",
        title: "توكن مزوّر",
        description: "إرسال JWT عشوائي — يجب رفضه بتوقيع غير صالح.",
        expect: "AUTH_002 · 401",
        run: async () => {
          const { status, body } = await rawFetch("/api/v1/auth/me", {
            headers: { Authorization: "Bearer eyJhbGciOiJIUzI1NiJ9.forged.signature" },
          });
          return { ok: status === 401 && body.code === "AUTH_002", result: { status, code: body.code, message: body.message } };
        },
      },
    ],
    []
  );

  async function runTest(t: TestDef) {
    setStates((s) => ({ ...s, [t.id]: "running" }));
    try {
      const { ok: passed, result } = await t.run();
      setResults((r) => ({ ...r, [t.id]: result }));
      setStates((s) => ({ ...s, [t.id]: passed ? "pass" : "fail" }));
      passed
        ? toast.success(`نجح: ${t.title}`)
        : toast.error(`فشل: ${t.title}`);
    } catch (e) {
      setStates((s) => ({ ...s, [t.id]: "fail" }));
      setResults((r) => ({ ...r, [t.id]: { status: "ERR", message: String(e) } }));
    }
  }

  async function runAll() {
    for (const t of tests) await runTest(t);
  }

  const passedCount = Object.values(states).filter((s) => s === "pass").length;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <CardTitle className="flex items-center gap-2">
                <FlaskConical className="w-5 h-5 text-primary" />
                اختبار الأمان الحي — سلسلة الفحوص على الخادم
              </CardTitle>
              <CardDescription className="mt-1.5">
                كل اختبار يستدعي الـ API الحقيقي ويعرض الرد الفعلي — لا بيانات وهمية. معايير خروج المرحلة 0.
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={passedCount === tests.length ? "success" : "secondary"}>
                {passedCount}/{tests.length} ناجح
              </Badge>
              <Button size="sm" onClick={runAll} variant="navy">
                <ShieldAlert className="w-4 h-4" /> تشغيل الكل
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {tests.map((t) => {
            const st = states[t.id] ?? "idle";
            const res = results[t.id];
            return (
              <div key={t.id} className="rounded-lg border p-4 flex flex-col gap-2 hover:bg-muted/30 transition-colors">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 font-semibold text-sm">
                      {st === "pass" && <CheckCircle2 className="w-4 h-4 text-success shrink-0" />}
                      {st === "fail" && <XCircle className="w-4 h-4 text-destructive shrink-0" />}
                      {st === "running" && <Loader2 className="w-4 h-4 animate-spin text-primary shrink-0" />}
                      {st === "idle" && <div className="w-4 h-4 rounded-full border-2 border-muted-foreground/30 shrink-0" />}
                      {t.title}
                      <Badge variant="outline" className="font-mono text-[10px]">{t.expect}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1.5 leading-relaxed">{t.description}</p>
                    {res && (
                      <p className={"text-xs mt-1.5 font-medium " + (st === "pass" ? "text-success" : "text-destructive")}>
                        الرد الفعلي: [{res.status}] {res.code ?? ""} {res.message ?? ""}
                        {res.detail ? ` — ${res.detail}` : ""}
                      </p>
                    )}
                  </div>
                  <Button size="sm" variant="outline" onClick={() => runTest(t)} disabled={st === "running"}>
                    {st === "running" ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <><LockKeyhole className="w-3.5 h-3.5" /> تنفيذ</>}
                  </Button>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      <Card className="bg-accent/60 border-primary/20">
        <CardContent className="pt-5 text-sm leading-relaxed text-accent-foreground">
          <strong className="flex items-center gap-2 mb-1"><UserX className="w-4 h-4" /> ملاحظة حول حساب lockdemo:</strong>
          بعد اختبار القفل يبقى الحساب مقفولًا 15 دقيقة (سلوك مقصود وفق AUTH_004) — ويُسجل في سجل التدقيق. الدخول اللاحق قبل انتهاء المدة يرفض برسالة زمن التحرر.
        </CardContent>
      </Card>
    </div>
  );
}

// Small helper used by the overview tab for the health probe button
export function useHealthProbe() {
  const [state, setState] = React.useState<"idle" | "loading" | "up" | "down">("idle");
  const [info, setInfo] = React.useState<string>("");
  const probe = React.useCallback(async () => {
    setState("loading");
    try {
      const { status, body } = await rawFetch("/api/v1/health");
      const okBody = body as { data?: { database?: string; version?: string } };
      if (status === 200 && okBody.data) {
        setState("up");
        setInfo(`v${okBody.data.version} — قاعدة البيانات: ${okBody.data.database}`);
      } else setState("down");
    } catch {
      setState("down");
    }
  }, []);
  return { state, info, probe };
}

export { post as _post, api, getAccessToken, formatDateTime, RefreshCcw };
