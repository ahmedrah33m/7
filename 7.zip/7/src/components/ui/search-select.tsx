"use client";

import * as React from "react";
import { ChevronDown } from "lucide-react";

export interface SearchOption {
  value: string;
  label: string;
  hint?: string;
  disabled?: boolean;
}

/**
 * قائمة اختيار قابلة للبحث — بديل مباشر لـ <select> حين تكون الخيارات كثيرة.
 * · النقر/التركيز يفتح القائمة كاملة (سلوك منسدلة تقليدي) — ثم اكتب للتصفية
 * · Enter يختار أول نتيجة · Esc يغلق · النقر يختار
 * · القائمة المنسدلة position:fixed بإحداثيات viewport حتى لا تُقص داخل
 *   جداول overflow — (درس: absolute مع إحداثيات getBoundingClientRect
 *   يزيح القائمة ضِعف الإزاحة وتختفي خارج الشاشة)
 *
 * إصلاحات «اختفاء القائمة المنسدلة» (ملاحظة المستخدم 2026-09-19):
 * · التمرير/تغيير الحجم لا يغلق القائمة بل يعيد حساب موقعها فوق الحقل مباشرة
 *   (كانت تُغلق فورًا حتى عند تمرير محتواها الداخلي — فتبدو مختفية)
 * · إن لم تكفِ المساحة أسفل الحقل تنفتح للأعلى (سلوك select الأصلي)
 * · حد أدنى 120px لارتفاع القائمة — لا تُرسم بارتفاع صفري مهما كان موضع الحقل
 */
const MIN_H = 120;
const MAX_H = 256;

export function SearchSelect({
  value,
  onChange,
  options,
  placeholder = "— اكتب للبحث ثم اختر —",
  className = "h-9 w-full rounded-md border bg-background pl-8 pr-3 text-sm",
  emptyText = "لا نتائج مطابقة",
}: {
  value: string;
  onChange: (value: string) => void;
  options: SearchOption[];
  placeholder?: string;
  className?: string;
  emptyText?: string;
}) {
  const [open, setOpen] = React.useState(false);
  const [query, setQuery] = React.useState("");
  const [rect, setRect] = React.useState<{ top: number; bottom: number; left: number; width: number; up: boolean; maxH: number } | null>(null);
  const inputRef = React.useRef<HTMLInputElement>(null);
  const listRef = React.useRef<HTMLDivElement>(null);

  const selected = options.find((o) => o.value === value);
  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    const base = q
      ? options.filter((o) => `${o.label} ${o.hint ?? ""}`.toLowerCase().includes(q))
      : options;
    return base.slice(0, 80);
  }, [options, query]);

  // حساب موقع القائمة: أسفل الحقل إن اتسعت المساحة، وإلا فوقه مثبتة بحافتها
  // السفلية على الحقل مباشرة (لا فجوة مهما قلّ عدد العناصر) — وفي RTL تُحاذي
  // حافة القائمة اليمنى حافة الحقل (بداية القراءة العربية)
  const computeRect = React.useCallback((): { top: number; bottom: number; left: number; width: number; up: boolean; maxH: number } | null => {
    const r = inputRef.current?.getBoundingClientRect();
    if (!r) return null;
    const width = Math.max(r.width, 280);
    // RTL: حافة القائمة اليمنى = حافة الحقل اليمنى — مع إبقائها داخل الشاشة
    const left = Math.max(8, Math.min(r.right - width, window.innerWidth - width - 8));
    const below = window.innerHeight - r.bottom - 8;
    const above = r.top - 8;
    if (below >= MIN_H || below >= above) {
      return { top: r.bottom + 4, bottom: 0, left, width, up: false, maxH: Math.max(MIN_H, Math.min(MAX_H, below)) };
    }
    return { top: 0, bottom: window.innerHeight - r.top + 4, left, width, up: true, maxH: Math.max(MIN_H, Math.min(MAX_H, above)) };
  }, []);

  function openList() {
    setRect(computeRect());
    setOpen(true);
    setQuery("");
  }

  // التمرير/تغيير الحجم والقائمة مفتوحة → إعادة تموضعها فوق الحقل بدل إغلاقها
  // (تُغلق فقط إن خرج الحقل نفسه كليًا عن الشاشة) — وتُتجاهل حركات التمرير
  // الصادرة من داخل القائمة نفسها (كانت تُغلقها فورًا = «القائمة اختفت»)
  React.useEffect(() => {
    if (!open) return;
    const reposition = (e?: Event) => {
      if (e && listRef.current && e.target instanceof Node && listRef.current.contains(e.target)) return;
      const r = inputRef.current?.getBoundingClientRect();
      if (!r || r.bottom < -40 || r.top > window.innerHeight + 40) {
        setOpen(false);
        return;
      }
      setRect(computeRect());
    };
    window.addEventListener("scroll", reposition, true);
    window.addEventListener("resize", reposition);
    return () => {
      window.removeEventListener("scroll", reposition, true);
      window.removeEventListener("resize", reposition);
    };
  }, [open, computeRect]);

  function pick(v: string) {
    onChange(v);
    setOpen(false);
  }

  return (
    <div className="relative">
      <input
        ref={inputRef}
        className={className}
        value={open ? query : (selected?.label ?? "")}
        placeholder={placeholder}
        onChange={(e) => {
          setQuery(e.target.value);
          if (!open) openList();
        }}
        onFocus={openList}
        onClick={() => { if (!open) openList(); }}
        onBlur={() => window.setTimeout(() => setOpen(false), 180)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            const first = filtered.find((o) => !o.disabled);
            if (first) pick(first.value);
          } else if (e.key === "Escape") {
            setOpen(false);
          }
        }}
        autoComplete="off"
      />
      {/* سهم القائمة المنسدلة — النقر يفتح/يغلق القائمة كاملة (سلوك select) */}
      <button
        type="button"
        tabIndex={-1}
        aria-label="فتح القائمة المنسدلة"
        className="absolute left-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-muted-foreground hover:text-foreground"
        onMouseDown={(e) => e.preventDefault()}
        onClick={() => (open ? setOpen(false) : openList())}
      >
        <ChevronDown className={`w-4 h-4 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && rect && (
        <div
          ref={listRef}
          className="fixed z-[70] overflow-y-auto rounded-md border bg-popover py-1 shadow-lg"
          style={rect.up
            ? { bottom: rect.bottom, left: rect.left, width: rect.width, maxHeight: rect.maxH }
            : { top: rect.top, left: rect.left, width: rect.width, maxHeight: rect.maxH }}
          onMouseDown={(e) => e.preventDefault()}
        >
          {filtered.length === 0 && (
            <div className="px-3 py-2 text-sm text-muted-foreground">{emptyText}</div>
          )}
          {filtered.map((o) => (
            <button
              key={o.value}
              type="button"
              disabled={o.disabled}
              className={`flex w-full items-center justify-between gap-2 px-3 py-1.5 text-right text-sm hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40 ${o.value === value ? "bg-muted/70 font-medium" : ""}`}
              onMouseDown={(e) => {
                e.preventDefault();
                if (!o.disabled) pick(o.value);
              }}
            >
              <span className="min-w-0 truncate">{o.label}</span>
              {o.hint && <span className="shrink-0 text-[10px] text-muted-foreground" dir="auto">{o.hint}</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
