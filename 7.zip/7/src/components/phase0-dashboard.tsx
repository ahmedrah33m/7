"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { api, clearTokens, type LoginPayload } from "@/lib/client-api";
import { formatDateTime } from "@/lib/utils";
import { SecurityTestsTab, useHealthProbe } from "@/components/security-tests-tab";
import { BranchesSection } from "@/components/admin/branches-section";
import { UsersScopeSection } from "@/components/admin/users-scope-section";
import { CompaniesSection } from "@/components/admin/companies-section";
import { RoleEditor, type RoleEditorData } from "@/components/admin/role-editor";
import {
  Activity, BadgeCheck, Database, FileClock, LayoutDashboard, LogOut, Pencil, RefreshCcw,
  ShieldCheck, Users, KeyRound, CheckCircle2, CircleDashed, ServerCog, Building2, Landmark,
} from "lucide-react";

interface AuditRow {
  id: number;
  action: string;
  module: string;
  entity_type: string;
  entity_id: number | null;
  user: { username: string; full_name: string } | null;
  ip_address: string | null;
  created_at: string;
  new_values: unknown;
}

interface RoleRow {
  id: number;
  code: string;
  name: string;
  description: string | null;
  is_system: boolean;
  users_count: number;
  permissions: string[];
  modules: string[];
}

interface UserRow {
  id: number;
  username: string;
  full_name: string;
  email: string | null;
  is_active: boolean;
  last_login_at: string | null;
  branch: string | null;
  roles: { code: string; name: string }[];
}

const PHASE0_SCOPE = [
  "مخطط Prisma من ERD — نطاق Core/Security + جداول النظام (audit, settings, sequences, refresh)",
  "مصادقة JWT: وصول 15 دقيقة + رمز تحديث دوراني 7 أيام مع كشف إعادة الاستخدام",
  "RBAC على الخادم: 157 صلاحية module.action + 11 دورًا نظاميًا + نطاق مستودعات",
  "قفل الحساب بعد 5 محاولات (AUTH_004) + عدّاد محاولات + سجل تدقيق للأحداث الأمنية",
  "مظروف أخطاء موحد + مصفوفة أكواد (AUTH/PERM/SCOPE/VAL/STOCK/CREDIT/RATE/SRV)",
  "خدمة سجل تدقيق لاتحققي + خدمة ترقيم مستندات (INV-2026-000001) جاهزة للمرحلة 3",
  "Seeders كاملة + سكربت تحقق آلي (verify:phase0) + إعداد CI",
];

export function Phase0Dashboard({ session, onLogout, onSession, embed = false }: { session: LoginPayload; onLogout: () => void; onSession?: (s: LoginPayload) => void; embed?: boolean }) {
  const [users, setUsers] = React.useState<UserRow[] | null>(null);
  const [roles, setRoles] = React.useState<RoleRow[] | null>(null);
  const [audit, setAudit] = React.useState<AuditRow[] | null>(null);
  const [auditLoading, setAuditLoading] = React.useState(false);
  const [editingRole, setEditingRole] = React.useState<RoleEditorData | null>(null);
  const health = useHealthProbe();

  const loadUsers = React.useCallback(async () => {
    const { body } = await api<UserRow[]>("/api/v1/admin/users");
    if (body.success && body.data) setUsers(body.data);
    else toast.error(body.message ?? "تعذر تحميل المستخدمين");
  }, []);

  const loadRoles = React.useCallback(async () => {
    const { body } = await api<RoleRow[]>("/api/v1/admin/roles");
    if (body.success && body.data) setRoles(body.data);
    else toast.error(body.message ?? "تعذر تحميل الأدوار");
  }, []);

  const loadAudit = React.useCallback(async () => {
    setAuditLoading(true);
    try {
      const { body } = await api<AuditRow[]>("/api/v1/admin/audit-logs?per_page=25");
      if (body.success && body.data) setAudit(body.data);
      else toast.error(body.message ?? "تعذر تحميل السجل");
    } finally {
      setAuditLoading(false);
    }
  }, []);

  React.useEffect(() => {
    // Initial data fetch — async loaders, setState happens after await.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadUsers();
    loadRoles();
    loadAudit();
    health.probe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // STRICT per-company isolation (UI layer): company switch must NEVER
  // leave the previous company's users/roles on screen — reload the
  // admin data whenever the active company changes.
  React.useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadUsers();
    loadRoles();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session.user.company_id]);

  async function logout() {
    await api("/api/v1/auth/logout", { method: "POST" }, { skipAuth: true }).catch(() => {});
    clearTokens();
    onLogout();
  }

  const permsByModule = React.useMemo(() => {
    const map = new Map<string, string[]>();
    for (const p of session.permissions) {
      const mod = p.split(".")[0];
      map.set(mod, [...(map.get(mod) ?? []), p]);
    }
    return Array.from(map.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [session.permissions]);

  return (
    <div className={embed ? "" : "min-h-screen bg-background"}>
      {/* Top bar */}
      {!embed && (
      <header className="sticky top-0 z-40 bg-navy text-navy-foreground shadow">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <div className="font-bold leading-tight truncate">نظام ميدان لمبيعات والتوزيع</div>
              <div className="text-[11px] text-slate-300">المرحلة 0 — الأساس · Phase 0 Foundation</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:block text-left">
              <div className="text-sm font-semibold leading-tight">{session.user.full_name}</div>
              <div className="text-[11px] text-slate-300" dir="ltr">@{session.user.username}</div>
            </div>
            <Button size="sm" variant="ghost" className="text-slate-200 hover:bg-white/10 hover:text-white" onClick={logout}>
              <LogOut className="w-4 h-4" /> خروج
            </Button>
          </div>
        </div>
      </header>
      )}

      <main className={embed ? "py-0" : "max-w-7xl mx-auto px-4 py-6"}>
        <Tabs defaultValue="overview" dir="rtl">
          <TabsList className="w-full justify-start overflow-x-auto scroll-thin h-auto py-1">
            <TabsTrigger value="overview"><LayoutDashboard className="w-4 h-4" /> نظرة عامة</TabsTrigger>
            <TabsTrigger value="users"><Users className="w-4 h-4" /> المستخدمون</TabsTrigger>
            <TabsTrigger value="companies"><Landmark className="w-4 h-4" /> الشركات</TabsTrigger>
            <TabsTrigger value="roles"><KeyRound className="w-4 h-4" /> الأدوار والصلاحيات</TabsTrigger>
            <TabsTrigger value="branches"><Building2 className="w-4 h-4" /> الفروع</TabsTrigger>
            <TabsTrigger value="audit"><FileClock className="w-4 h-4" /> سجل التدقيق</TabsTrigger>
            <TabsTrigger value="security"><ShieldCheck className="w-4 h-4" /> اختبار الأمان</TabsTrigger>
          </TabsList>

          {/* ---------------- Overview ---------------- */}
          <TabsContent value="overview">
            <div className="grid gap-4 lg:grid-cols-3">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><BadgeCheck className="w-5 h-5 text-primary" /> نطاق المرحلة 0 المنجز</CardTitle>
                  <CardDescription>معايير الخروج: الدخول/التحديث/القفل يعملون · حاجز الصلاحيات يمنع غير المخوّل · الترحيلات نظيفة</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2.5">
                  {PHASE0_SCOPE.map((item) => (
                    <div key={item} className="flex items-start gap-2.5 text-sm">
                      <CheckCircle2 className="w-4 h-4 text-success mt-0.5 shrink-0" />
                      <span className="leading-relaxed">{item}</span>
                    </div>
                  ))}
                  <div className="pt-2 flex items-center gap-2 text-xs text-muted-foreground">
                    <CircleDashed className="w-4 h-4" />
                    المرحلة القادمة: 1 — البيانات الرئيسية (منتجات، تصنيفات، وحدات، عملاء، موردون، قوائم أسعار)
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2"><Activity className="w-4 h-4 text-primary" /> فحص الجاهزية</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button variant="outline" size="sm" className="w-full" onClick={health.probe}>
                      <RefreshCcw className="w-4 h-4" /> فحص /api/v1/health
                    </Button>
                    <div className="text-sm">
                      {health.state === "up" && (
                        <div className="flex items-center gap-2 text-success font-medium">
                          <Database className="w-4 h-4" /> الخدمة تعمل — {health.info}
                        </div>
                      )}
                      {health.state === "down" && (
                        <div className="text-destructive font-medium">الخدمة غير متاحة!</div>
                      )}
                      {health.state === "loading" && <div className="text-muted-foreground">جارٍ الفحص...</div>}
                      {health.state === "idle" && <div className="text-muted-foreground">لم يُفحص بعد</div>}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2"><ServerCog className="w-4 h-4 text-primary" /> جلستك</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-1.5 text-sm">
                    <div className="flex justify-between"><span className="text-muted-foreground">الأدوار:</span>
                      <span className="font-medium">{session.roles.map((r) => r.name).join("، ")}</span>
                    </div>
                    <div className="flex justify-between"><span className="text-muted-foreground">الصلاحيات:</span>
                      <Badge variant="accent">{session.permissions.length} صلاحية</Badge>
                    </div>
                    <div className="flex justify-between"><span className="text-muted-foreground">انتهاء الوصول:</span>
                      <span className="font-mono text-xs">15 دقيقة (دوران آلي)</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* ---------------- Users + Scope (Phase 2/44) ---------------- */}
          <TabsContent value="users">
            <UsersScopeSection key={session.user.company_id} session={session} />
          </TabsContent>

          {/* ---------------- Companies (Multi-Company) ---------------- */}
          <TabsContent value="companies">
            <CompaniesSection
              key={session.user.company_id}
              session={session}
              onSession={onSession}
              onLogout={onLogout}
              canEdit={session.permissions.includes("system.company.edit")}
              canDelete={session.permissions.includes("system.company.delete")}
            />
          </TabsContent>

          {/* ---------------- Roles (مع تعديل الأدوار) ---------------- */}
          <TabsContent value="roles">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle>الأدوار النظامية الـ 11 — مع تعديل الأدوار</CardTitle>
                <CardDescription>
                  من /api/v1/admin/roles — كل دور يمنح صلاحياته الذرية عبر role_permissions، وتُفحص دائمًا على الخادم.
                  زر «تعديل» يفتح محرر الاسم/الوصف/الصلاحيات (صلاحية system.roles.edit). صلاحيات المالك ودورك الشخصي محمية.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {editingRole && (
                  <RoleEditor
                    role={editingRole}
                    selfRoleIds={session.roles.map((r) => r.id)}
                    onSaved={() => { setEditingRole(null); loadRoles(); }}
                    onCancel={() => setEditingRole(null)}
                  />
                )}
                {roles === null ? (
                  <div className="py-10 text-center text-muted-foreground">جارٍ التحميل...</div>
                ) : (
                  <div className="grid gap-3 md:grid-cols-2">
                    {roles.map((r) => {
                      const locked = r.code === "OWNER" || session.roles.some((sr) => sr.id === r.id);
                      return (
                      <div key={r.id} className="rounded-lg border p-4 hover:border-primary/40 transition-colors">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <div className="font-semibold">{r.name}</div>
                          <div className="flex gap-1.5">
                            {r.is_system && <Badge variant="accent" className="text-[10px]">نظام</Badge>}
                            <Badge variant="secondary" className="text-[10px]">{r.permissions.length} صلاحية</Badge>
                            <Badge variant="outline" className="text-[10px]">{r.users_count} مستخدم</Badge>
                            {session.permissions.includes("system.roles.edit") && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-6 px-2 text-[11px]"
                                onClick={() => setEditingRole(r)}
                              >
                                <Pencil className="w-3 h-3" /> تعديل
                              </Button>
                            )}
                          </div>
                        </div>
                        <div dir="ltr" className="font-mono text-[11px] text-muted-foreground text-left mt-1">
                          {r.code}{locked ? " · صلاحياته محمية" : ""}
                        </div>
                        {r.description && <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{r.description}</p>}
                        <div className="flex flex-wrap gap-1 mt-2.5">
                          {r.modules.map((m) => (
                            <Badge key={m} variant="outline" className="text-[10px] font-mono">{m}</Badge>
                          ))}
                        </div>
                      </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ---------------- Audit ---------------- */}
          <TabsContent value="audit">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <CardTitle>سجل التدقيق — لاتحققي</CardTitle>
                    <CardDescription>
                      /api/v1/admin/audit-logs — بصلاحية <code className="font-mono text-xs bg-muted px-1.5 py-0.5 rounded">audit.audit_logs.view</code>. لا تحذيف ولا تعديل من أي واجهة.
                    </CardDescription>
                  </div>
                  <Button size="sm" variant="outline" onClick={loadAudit} disabled={auditLoading}>
                    <RefreshCcw className={"w-4 h-4" + (auditLoading ? " animate-spin" : "")} /> تحديث
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {audit === null ? (
                  <div className="py-10 text-center text-muted-foreground">جارٍ التحميل...</div>
                ) : audit.length === 0 ? (
                  <div className="py-10 text-center text-muted-foreground">السجل فارغ</div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>#</TableHead>
                        <TableHead>الفعل</TableHead>
                        <TableHead>الوحدة</TableHead>
                        <TableHead>الكيان</TableHead>
                        <TableHead>الفاعل</TableHead>
                        <TableHead>IP</TableHead>
                        <TableHead>الوقت</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {audit.map((r) => (
                        <TableRow key={r.id}>
                          <TableCell className="font-mono text-xs">{r.id}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                r.action === "LOGIN" ? "success"
                                : r.action.includes("FAILED") || r.action === "LOCKOUT" ? "destructive"
                                : "secondary"
                              }
                              className="font-mono text-[10px]"
                            >
                              {r.action}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-mono text-xs">{r.module}</TableCell>
                          <TableCell className="text-xs">
                            {r.entity_type}{r.entity_id != null ? `#${r.entity_id}` : ""}
                          </TableCell>
                          <TableCell className="text-xs">{r.user ? r.user.full_name : "زائر"}</TableCell>
                          <TableCell dir="ltr" className="font-mono text-[11px] text-left">{r.ip_address ?? "—"}</TableCell>
                          <TableCell className="text-xs text-muted-foreground">{formatDateTime(r.created_at)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ---------------- Branches ---------------- */}
          <TabsContent value="branches">
            <BranchesSection key={session.user.company_id} canEdit={session.permissions.includes("system.branches.create")} />
          </TabsContent>

          {/* ---------------- Security tests ---------------- */}
          <TabsContent value="security">
            <SecurityTestsTab session={session} />
          </TabsContent>
        </Tabs>
      </main>

      {!embed && (
      <footer className="border-t mt-8">
        <div className="max-w-7xl mx-auto px-4 py-4 text-xs text-muted-foreground flex items-center justify-between flex-wrap gap-2">
          <span>نظام ميدان لمبيعات والتوزيع — بناء المرحلة 0 وفق MASTER PROMPT §6 ووثيقتي ERD و API</span>
          <span dir="ltr" className="font-mono">Next.js 16 · Prisma · argon2id · jose JWT</span>
        </div>
      </footer>
      )}
    </div>
  );
}
