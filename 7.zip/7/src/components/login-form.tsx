"use client";

import * as React from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { api, setTokens, type LoginPayload, type ScopeBranch, type ScopeCompany } from "@/lib/client-api";
import {
  LogIn,
  Lock,
  User,
  Building2,
  MapPin,
  GitBranch,
  Store,
  Eye,
  EyeOff,
  ShieldCheck,
  MoveRight,
} from "lucide-react";

type SelectionPayload = {
  requires_branch_selection: true;
  scope_type: string;
  companies: ScopeCompany[];
  branches: ScopeBranch[];
  active_company_id: number;
  user: { id: number; username: string; full_name: string };
};

// Phase 1 §1 — نفس اسم المستخدم موجود في أكثر من شركة → اختيار الشركة
// إلزامي قبل إصدار Access Token النهائي (لا توكنز مع هذا الرد).
type CompanySelectionPayload = {
  requires_company_selection: true;
  companies: ScopeCompany[];
  user?: { username: string; full_name?: string };
};

const FEATURES = [
  { icon: Store, label: "بيع & مخزون" },
  { icon: Building2, label: "مشتريات & مالية" },
  { icon: MapPin, label: "ميداني & B2B" },
];

// خلفية مشتركة لكل شاشات الدخول (خلفية متدرجة متحركة بهوية ميدان)
function AuthBackdrop({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative min-h-screen flex items-center justify-center p-4 overflow-hidden bg-slate-950">
      {/* تدرج القاعدة */}
      <div
        className="absolute inset-0"
        aria-hidden
        style={{
          background:
            "linear-gradient(140deg, #0a0f1e 0%, #101b33 40%, #1a120b 75%, #0a0f1e 100%)",
        }}
      />
      {/* هالات متحركة (aurora blobs) */}
      <div className="absolute -top-32 -right-32 w-[28rem] h-[28rem] rounded-full bg-primary/30 blur-3xl animate-aurora" aria-hidden />
      <div className="absolute -bottom-44 -left-28 w-[32rem] h-[32rem] rounded-full bg-amber-600/25 blur-3xl animate-aurora-slow" aria-hidden />
      <div className="absolute top-1/3 left-1/3 w-80 h-80 rounded-full bg-sky-500/10 blur-3xl animate-aurora" aria-hidden />

      {/* شبكة نقطية خفيفة */}
      <div
        className="absolute inset-0 opacity-[0.06]"
        aria-hidden
        style={{
          backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)",
          backgroundSize: "26px 26px",
        }}
      />

      {/* أشكال عائمة زخرفية */}
      <div className="absolute top-24 right-[12%] w-3 h-3 rounded-full bg-amber-400/70 animate-floaty" aria-hidden />
      <div className="absolute bottom-28 left-[10%] w-2 h-2 rounded-full bg-primary/80 animate-floaty" aria-hidden />
      <div className="absolute top-1/2 right-[6%] w-1.5 h-1.5 rounded-full bg-white/30 animate-floaty" aria-hidden />

      {/* تدرج علوي لتخفيف الحواف */}
      <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-black/30 to-transparent" aria-hidden />

      <div className="relative z-10 w-full">{children}</div>
    </div>
  );
}

// هوية النظام — شعار + اسم (الشعار = شعار النظام من system_brand — مستقل عن شعارات الشركات)
function BrandMark({ compact = false, logoUrl }: { compact?: boolean; logoUrl?: string | null }) {
  return (
    <div className={`flex ${compact ? "items-center gap-3 text-right" : "flex-col items-center text-center"} `}>
      <div className="relative">
        {logoUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={logoUrl}
            alt="شعار النظام"
            className={`${compact ? "w-11 h-11" : "w-20 h-20"} rounded-2xl object-cover shadow-2xl shadow-primary/40 ring-2 ring-white/20 shrink-0`}
          />
        ) : (
          <div
            className={`${compact ? "w-11 h-11" : "w-20 h-20"} rounded-2xl bg-gradient-to-br from-primary via-orange-500 to-amber-500 flex items-center justify-center shadow-2xl shadow-primary/40 ring-1 ring-white/25 shrink-0 ${
              compact ? "" : "animate-glow-pulse"
            }`}
          >
            <Store className={`${compact ? "w-5 h-5" : "w-9 h-9"} text-white drop-shadow`} />
          </div>
        )}
      </div>
      <div className={compact ? "" : "mt-4"}>
        <h1 className={`${compact ? "text-lg" : "text-3xl"} font-extrabold text-white leading-tight tracking-tight`}>
          نظام <span className="bg-gradient-to-l from-amber-300 via-orange-400 to-amber-500 bg-clip-text text-transparent">ميدان</span> للمبيعات والتوزيع
        </h1>
        {!compact && (
          <p className="mt-2 text-sm text-slate-400">
            منصة عراقية متكاملة لإدارة البيع والمخزون والميداني
          </p>
        )}
      </div>
    </div>
  );
}

// بطاقة زجاجية مشتركة
function GlassCard({ children }: { children: React.ReactNode }) {
  return (
    <Card className="w-full max-w-md shadow-2xl animate-fade-up relative overflow-hidden rounded-2xl border-white/10 bg-white/[0.06] backdrop-blur-xl text-white">
      <div className="absolute inset-x-0 top-0 h-[3px] bg-gradient-to-r from-primary via-amber-400 to-primary" aria-hidden />
      <CardContent className="pt-7">{children}</CardContent>
    </Card>
  );
}

export function LoginForm({ onLogin }: { onLogin: (payload: LoginPayload) => void }) {
  const [username, setUsername] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [showPassword, setShowPassword] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  // شعار النظام العام (نقطة بلا مصادقة) — يظهر فوق شاشة الدخول إن وُجد
  const [brandLogo, setBrandLogo] = React.useState<string | null>(null);
  React.useEffect(() => {
    api<{ logo_url: string | null; logo_version: string | null }>("/api/v1/branding", { method: "GET" }, { skipAuth: true })
      .then(({ body }) => {
        if (body.success && body.data?.logo_url) {
          setBrandLogo(body.data.logo_version ? `${body.data.logo_url}?v=${body.data.logo_version}` : body.data.logo_url);
        }
      })
      .catch(() => {});
  }, []);

  // ---- Multi-branch selection state (Phase 14) ---------------------------
  const [selection, setSelection] = React.useState<SelectionPayload | null>(null);
  const [pickedBranch, setPickedBranch] = React.useState<number | null>(null);

  // ---- Multi-company selection state (Phase 1) ----------------------------
  const [companySel, setCompanySel] = React.useState<CompanySelectionPayload | null>(null);
  const [pickedCompany, setPickedCompany] = React.useState<number | null>(null);

  // بدء الجلسة بعد اختيار الشركة — قد يتبعه اختيار فرع (لا توكنز بعد).
  async function completeCompanySelection() {
    if (!companySel || !pickedCompany) return;
    setBusy(true);
    setError(null);
    try {
      const { res, body } = await api<LoginPayload | SelectionPayload>(
        "/api/v1/auth/login",
        {
          method: "POST",
          body: JSON.stringify({ username, password, company_id: pickedCompany }),
        },
        { skipAuth: true }
      );
      if (!res.ok || !body.success || !body.data) {
        setError(`${body.code ?? "خطأ"}: ${body.message ?? "تعذر الدخول"}`);
        return;
      }
      if ("requires_branch_selection" in body.data && body.data.requires_branch_selection) {
        setCompanySel(null);
        setSelection(body.data);
        setPickedBranch(body.data.branches[0]?.id ?? null);
        return;
      }
      if ("requires_company_selection" in body.data && body.data.requires_company_selection) {
        setCompanySel(body.data as unknown as CompanySelectionPayload);
        setError("تعذر تحديد الحساب — أعد اختيار الشركة");
        return;
      }
      const payload = body.data as LoginPayload;
      setTokens(payload.access_token, payload.refresh_token);
      toast.success(`أهلًا ${payload.user.full_name} 👋`);
      onLogin(payload);
    } catch {
      setError("تعذر الاتصال بالخادم — تحقق من التشغيل");
    } finally {
      setBusy(false);
    }
  }

  async function completeSelection() {
    if (!selection || !pickedBranch) return;
    setBusy(true);
    setError(null);
    try {
      const { res, body } = await api<LoginPayload>(
        "/api/v1/auth/login",
        {
          method: "POST",
          body: JSON.stringify({
            username,
            password,
            company_id: selection.active_company_id,
            branch_id: pickedBranch,
          }),
        },
        { skipAuth: true }
      );
      if (!res.ok || !body.success || !body.data || !("access_token" in body.data)) {
        setError(`${body.code ?? "خطأ"}: ${body.message ?? "تعذر إتمام اختيار الفرع"}`);
        return;
      }
      setTokens(body.data.access_token, body.data.refresh_token);
      toast.success(`أهلًا ${body.data.user.full_name} — ${selection.branches.find((b) => b.id === pickedBranch)?.name ?? ""}`);
      onLogin(body.data);
    } catch {
      setError("تعذر الاتصال بالخادم — تحقق من التشغيل");
    } finally {
      setBusy(false);
    }
  }

  async function submit(e?: React.FormEvent) {
    e?.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const { res, body } = await api<LoginPayload | SelectionPayload>(
        "/api/v1/auth/login",
        { method: "POST", body: JSON.stringify({ username, password }) },
        { skipAuth: true }
      );
      if (!res.ok || !body.success || !body.data) {
        setError(`${body.code ?? "خطأ"}: ${body.message ?? "تعذر الدخول"}`);
        if (body.code === "AUTH_004") toast.error(body.message);
        return;
      }
      // ---- Same username in several companies → company picker first (Phase 1) ----
      if ("requires_company_selection" in body.data && body.data.requires_company_selection) {
        const cs = body.data as unknown as CompanySelectionPayload;
        setCompanySel(cs);
        setPickedCompany(cs.companies[0]?.id ?? null);
        return;
      }
      // ---- Multi-branch user → show the branch picker (no tokens yet) ----
      if ("requires_branch_selection" in body.data && body.data.requires_branch_selection) {
        setSelection(body.data);
        setPickedBranch(body.data.branches[0]?.id ?? null);
        return;
      }
      const payload = body.data as LoginPayload;
      setTokens(payload.access_token, payload.refresh_token);
      toast.success(`أهلًا ${payload.user.full_name} 👋`);
      onLogin(payload);
    } catch {
      setError("تعذر الاتصال بالخادم — تحقق من التشغيل");
    } finally {
      setBusy(false);
    }
  }

  // ---- Company picker screen (Phase 1 §1: اختر الشركة) -------------------
  if (companySel) {
    return (
      <AuthBackdrop>
        <div className="flex flex-col items-center">
          <div className="mb-7">
            <BrandMark compact logoUrl={brandLogo} />
          </div>
          <GlassCard>
            <div className="mb-4">
              <h2 className="text-xl font-bold flex items-center gap-2 text-white">
                <Building2 className="w-5 h-5 text-amber-400" /> اختر الشركة
              </h2>
              <p className="text-sm text-slate-400 mt-1">
                اسم المستخدم «{companySel.user?.username ?? username}» مرتبط بأكثر من شركة — اختر شركة الجلسة للمتابعة
              </p>
            </div>
            <div className="space-y-3">
              <div className="grid gap-2">
                {companySel.companies.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setPickedCompany(c.id)}
                    className={`w-full text-right rounded-xl border px-4 py-3 flex items-center gap-3 transition-all ${
                      pickedCompany === c.id
                        ? "border-amber-400/70 bg-amber-400/15 text-white shadow-lg shadow-amber-500/10"
                        : "border-white/10 bg-white/5 hover:bg-white/10 text-white"
                    }`}
                  >
                    <span
                      className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        pickedCompany === c.id ? "bg-amber-400/20" : "bg-white/10"
                      }`}
                    >
                      <Building2 className={`w-4 h-4 ${pickedCompany === c.id ? "text-amber-400" : "text-slate-300"}`} />
                    </span>
                    <span className="font-semibold flex-1">{c.name}</span>
                    {c.code && <Badge variant="outline" className="border-white/15 bg-white/5 text-slate-300" dir="ltr">{c.code}</Badge>}
                  </button>
                ))}
              </div>
              {error && (
                <div className="rounded-lg bg-red-500/10 border border-red-500/30 text-red-300 text-sm px-3 py-2.5 font-medium">
                  {error}
                </div>
              )}
              <div className="flex gap-2 pt-1">
                <Button
                  className="flex-1 bg-gradient-to-l from-primary to-amber-500 hover:from-primary/90 hover:to-amber-500/90 shadow-lg shadow-primary/25"
                  size="lg"
                  disabled={busy || !pickedCompany}
                  onClick={completeCompanySelection}
                >
                  <LogIn className="w-4 h-4" /> متابعة
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-white/15 bg-white/5 text-white hover:bg-white/10"
                  onClick={() => { setCompanySel(null); setError(null); }}
                >
                  رجوع
                </Button>
              </div>
            </div>
          </GlassCard>
        </div>
      </AuthBackdrop>
    );
  }

  // ---- Branch picker screen (Phase 14: اختر الفرع) ------------------------
  if (selection) {
    return (
      <AuthBackdrop>
        <div className="flex flex-col items-center">
          <div className="mb-7">
            <BrandMark compact logoUrl={brandLogo} />
          </div>
          <GlassCard>
            <div className="mb-4">
              <h2 className="text-xl font-bold flex items-center gap-2 text-white">
                <GitBranch className="w-5 h-5 text-amber-400" /> اختر الفرع
              </h2>
              <p className="text-sm text-slate-400 mt-1">
                أهلًا {selection.user.full_name} — حسابك مرتبط بأكثر من فرع، اختر فرع الجلسة
              </p>
            </div>
            <div className="space-y-3">
              <div className="grid gap-2">
                {selection.branches.map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => setPickedBranch(b.id)}
                    className={`w-full text-right rounded-xl border px-4 py-3 flex items-center gap-3 transition-all ${
                      pickedBranch === b.id
                        ? "border-amber-400/70 bg-amber-400/15 text-white shadow-lg shadow-amber-500/10"
                        : "border-white/10 bg-white/5 hover:bg-white/10 text-white"
                    }`}
                  >
                    <span
                      className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        pickedBranch === b.id ? "bg-amber-400/20" : "bg-white/10"
                      }`}
                    >
                      <MapPin className={`w-4 h-4 ${pickedBranch === b.id ? "text-amber-400" : "text-slate-300"}`} />
                    </span>
                    <span className="font-semibold flex-1">{b.name}</span>
                    <Badge variant="outline" className="border-white/15 bg-white/5 text-slate-300" dir="ltr">{b.code}</Badge>
                  </button>
                ))}
              </div>
              {error && (
                <div className="rounded-lg bg-red-500/10 border border-red-500/30 text-red-300 text-sm px-3 py-2.5 font-medium">
                  {error}
                </div>
              )}
              <div className="flex gap-2 pt-1">
                <Button
                  className="flex-1 bg-gradient-to-l from-primary to-amber-500 hover:from-primary/90 hover:to-amber-500/90 shadow-lg shadow-primary/25"
                  size="lg"
                  disabled={busy || !pickedBranch}
                  onClick={completeSelection}
                >
                  <LogIn className="w-4 h-4" /> بدء الجلسة
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-white/15 bg-white/5 text-white hover:bg-white/10"
                  onClick={() => { setSelection(null); setError(null); }}
                >
                  رجوع
                </Button>
              </div>
            </div>
          </GlassCard>
        </div>
      </AuthBackdrop>
    );
  }

  return (
    <AuthBackdrop>
      <div className="mx-auto w-full max-w-md">
        {/* الهوية فوق البطاقة */}
        <div className="mb-8 flex justify-center">
          <BrandMark logoUrl={brandLogo} />
        </div>

        {/* بطاقة الدخول */}
        <GlassCard>
          <form onSubmit={submit} className="space-y-4">
            <div className="mb-1 flex items-center gap-2 justify-center">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span className="text-xs tracking-wide text-slate-400">دخول آمن · مصادقة من الخوادم</span>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="username" className="text-sm font-medium flex items-center gap-1.5 text-slate-200">
                <User className="w-4 h-4 text-amber-400" /> اسم المستخدم
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-500 absolute top-1/2 -translate-y-1/2 right-3.5 pointer-events-none" />
                <Input
                  id="username"
                  dir="ltr"
                  autoComplete="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="أدخل اسم المستخدم"
                  className="h-12 text-left pl-4 pr-11 rounded-xl bg-white/10 border-white/10 text-white placeholder:text-slate-500 shadow-inner focus-visible:ring-2 focus-visible:ring-amber-400/60 focus-visible:border-amber-400/50"
                  required
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <label htmlFor="password" className="text-sm font-medium flex items-center gap-1.5 text-slate-200">
                <Lock className="w-4 h-4 text-amber-400" /> كلمة المرور
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute top-1/2 -translate-y-1/2 right-3.5 pointer-events-none" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  dir="ltr"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="h-12 text-left pl-11 pr-11 rounded-xl bg-white/10 border-white/10 text-white placeholder:text-slate-500 shadow-inner focus-visible:ring-2 focus-visible:ring-amber-400/60 focus-visible:border-amber-400/50"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 p-1 rounded-md text-slate-400 hover:text-white transition-colors"
                  aria-label={showPassword ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="rounded-lg bg-red-500/10 border border-red-500/30 text-red-300 text-sm px-3 py-2.5 font-medium">
                {error}
              </div>
            )}

            <Button
              type="submit"
              className="w-full h-12 text-base bg-gradient-to-l from-primary via-orange-500 to-amber-500 hover:brightness-110 shadow-lg shadow-primary/30 transition-all"
              size="lg"
              disabled={busy}
            >
              {busy ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  جارٍ التحقق...
                </>
              ) : (
                <>
                  <LogIn className="w-5 h-5" />
                  دخول
                  <MoveRight className="w-4 h-4 opacity-60" />
                </>
              )}
            </Button>
          </form>
        </GlassCard>

        {/* ميزات النظام */}
        <div className="mt-7 flex items-center justify-center gap-3">
          {FEATURES.map((f) => (
            <div key={f.label} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm">
              <f.icon className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-xs text-slate-300">{f.label}</span>
            </div>
          ))}
        </div>

        <div className="mt-7 flex items-center justify-center">
          <p className="inline-flex items-center px-5 py-2 rounded-full bg-white/10 border-2 border-amber-400/50 backdrop-blur-sm text-xs font-medium text-slate-200 shadow-lg shadow-black/20">
            جميع الحقوق محفوظة © {new Date().getFullYear()} لميدان الاقتصاد ·
          </p>
        </div>
      </div>
    </AuthBackdrop>
  );
}