"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api, applyScopeSwitch, clearTokens, getAccessToken, type LoginPayload, type SessionScope } from "@/lib/client-api";
import { CalendarClock, Building2, CheckCircle2, Clock, ImagePlus, Loader2, PauseCircle, Pencil, PlayCircle, Plus, RefreshCw, ShieldAlert, Store, TimerOff, Trash2, X, Zap } from "lucide-react";

interface SubscriptionInfo {
  ends_at: string | null;
  days_left: number | null;
  is_suspended: boolean;
  status: "OPEN" | "ACTIVE" | "EXPIRING_SOON" | "EXPIRED" | "SUSPENDED";
  note: string | null;
}

interface CompanyRow {
  id: number;
  code: string | null;
  name: string;
  name_en: string | null;
  legal_name: string | null;
  tax_number: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  currency_code: string;
  subscription: SubscriptionInfo;
  branches_count: number;
  users_count: number;
  invoices_count: number;
  customers_count: number;
  products_count: number;
  is_active_company: boolean;
  created_at: string;
}

function subBadge(s: SubscriptionInfo) {
  switch (s.status) {
    case "OPEN": return <Badge variant="navy" className="text-[10px] gap-1"><CheckCircle2 className="w-3 h-3" /> مفتوح</Badge>;
    case "ACTIVE": return <Badge variant="success" className="text-[10px] gap-1"><Clock className="w-3 h-3" /> {s.days_left} يوم</Badge>;
    case "EXPIRING_SOON": return <Badge variant="secondary" className="text-[10px] gap-1 bg-amber-100 text-amber-800"><ShieldAlert className="w-3 h-3" /> {s.days_left} يوم</Badge>;
    case "EXPIRED": return <Badge variant="destructive" className="text-[10px] gap-1"><TimerOff className="w-3 h-3" /> منتهٍ</Badge>;
    case "SUSPENDED": return <Badge variant="destructive" className="text-[10px] gap-1"><PauseCircle className="w-3 h-3" /> معلّقة</Badge>;
  }
}

function fmtDate(iso: string | null) {
  if (!iso) return "—";
  try { return new Intl.DateTimeFormat("ar-IQ", { dateStyle: "medium" }).format(new Date(iso)); } catch { return iso; }
}

/**
 * Companies management (Multi-Company) — add a new company with FULL
 * provisioning (branch + warehouse + roles + sequences + settings +
 * walk-in customer), edit its identity data (name/phone/tax…), and
 * refresh the session scope so the new company appears in the switcher.
 *
 * The active company name shows under the system title and on invoices.
 */
export function CompaniesSection({ session, onSession, onLogout, canEdit, canDelete }: {
  session: LoginPayload;
  onSession?: (s: LoginPayload) => void;
  onLogout?: () => void;
  canEdit: boolean;
  canDelete: boolean;
}) {
  const [rows, setRows] = React.useState<CompanyRow[] | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [editing, setEditing] = React.useState<CompanyRow | null>(null);
  // لوحة المالك: إدارة مدة اشتراك شركة (تاريخ + ملاحظة) + تعليق/إنهاء جلسات
  const [subTarget, setSubTarget] = React.useState<CompanyRow | null>(null);
  // شعار الشركة النشطة (يظهر أعلى القائمة الجانبية ورأس الفواتير) — رفع/إزالة
  const [logoBusy, setLogoBusy] = React.useState(false);
  const activeLogo = session.scope?.companies.find((c) => c.id === session.user.company_id)?.logo_url ?? null;
  const activeCompanyNameLocal = session.scope?.companies.find((c) => c.id === session.user.company_id)?.name ?? "الشركة النشطة";

  // شعار النظام (هوية المنصة العامة — شاشة الدخول + الهيدر) — مستقل عن شعار الشركة
  const canSystemBrand = session.permissions.includes("system.settings.edit");
  const [sysLogoBusy, setSysLogoBusy] = React.useState(false);
  const [systemLogo, setSystemLogo] = React.useState<string | null>(null);
  const loadSystemLogo = React.useCallback(() => {
    api<{ logo_url: string | null; logo_version: string | null }>("/api/v1/branding", { method: "GET" }, { skipAuth: true })
      .then(({ body }) => {
        setSystemLogo(body.success && body.data?.logo_url
          ? (body.data.logo_version ? `${body.data.logo_url}?v=${body.data.logo_version}` : body.data.logo_url)
          : null);
      })
      .catch(() => {});
  }, []);
  React.useEffect(() => { loadSystemLogo(); }, [loadSystemLogo]);

  /** رفع شعار النظام (multipart — بدون التغليف JSON لمساعد api) */
  async function uploadSystemLogo(file: File) {
    setSysLogoBusy(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const token = getAccessToken();
      const res = await fetch("/api/v1/admin/system-logo", {
        method: "POST",
        headers: token ? { Authorization: `Bearer ${token}` } : undefined,
        body: fd,
      });
      const body = (await res.json().catch(() => ({ success: false, message: "رد غير صالح" }))) as { success: boolean; message?: string };
      if (res.ok && body.success) {
        toast.success("تم تثبيت شعار النظام — سيظهر في شاشة تسجيل الدخول وشريط النظام العلوي");
        loadSystemLogo();
        window.dispatchEvent(new CustomEvent("sales:branding-changed"));
      } else {
        toast.error(body.message ?? (res.status === 401 ? "انتهت الجلسة — أعد المحاولة بعد تجديد الدخول" : "فشل رفع شعار النظام"));
      }
    } catch {
      toast.error("تعذر الاتصال بالخادم");
    } finally {
      setSysLogoBusy(false);
    }
  }

  async function removeSystemLogo() {
    if (!window.confirm("إزالة شعار النظام (لن يتأثر شعار أي شركة) والعودة للأيقونة الافتراضية؟")) return;
    setSysLogoBusy(true);
    try {
      const { body } = await api("/api/v1/admin/system-logo", { method: "DELETE" });
      if (body.success) {
        toast.success("أُزيل شعار النظام");
        loadSystemLogo();
        window.dispatchEvent(new CustomEvent("sales:branding-changed"));
      } else toast.error(body.message ?? "فشل إزالة شعار النظام");
    } finally {
      setSysLogoBusy(false);
    }
  }

  /** رفع شعار الشركة النشطة (multipart — بدون التغليف JSON لمساعد api) */
  async function uploadLogo(file: File) {
    setLogoBusy(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const token = getAccessToken();
      const res = await fetch("/api/v1/admin/company-logo", {
        method: "POST",
        headers: token ? { Authorization: `Bearer ${token}` } : undefined,
        body: fd,
      });
      const body = (await res.json().catch(() => ({ success: false, message: "رد غير صالح" }))) as { success: boolean; message?: string };
      if (res.ok && body.success) {
        toast.success("تم تثبيت شعار الشركة — سيظهر في القائمة الجانبية ورأس الفواتير المطبوعة");
        await refreshScope(true);
      } else {
        toast.error(body.message ?? (res.status === 401 ? "انتهت الجلسة — أعد المحاولة بعد تجديد الدخول" : "فشل رفع الشعار"));
      }
    } catch {
      toast.error("تعذر الاتصال بالخادم");
    } finally {
      setLogoBusy(false);
    }
  }

  async function removeLogo() {
    if (!window.confirm("إزالة شعار الشركة النشطة والعودة للأيقونة الافتراضية؟")) return;
    setLogoBusy(true);
    try {
      const { body } = await api("/api/v1/admin/company-logo", { method: "DELETE" });
      if (body.success) {
        toast.success("أُزيل الشعار");
        await refreshScope(true);
      } else toast.error(body.message ?? "فشل إزالة الشعار");
    } finally {
      setLogoBusy(false);
    }
  }

  // ---- حذف شركة (حذف ناعم + إنهاء جلساتها) ------------------------------
  async function deleteCompany(c: CompanyRow) {
    const isCurrent = c.id === session.user.company_id;
    const msg = isCurrent
      ? `حذف شركة «${c.name}»؟

⚠️ هذه شركتك النشطة حاليًا — سيُنهى دخولك فورًا وستعود لشاشة تسجيل الدخول.`
      : `حذف شركة «${c.name}»؟

• حذف ناعم — البيانات تبقى في القاعدة ويمكن استعادتها فنيًا
• ستُنهى كل جلسات مستخدميها فورًا
• تختفي من القوائم والمبدّل وشاشة الدخول`;
    if (!window.confirm(msg)) return;
    setBusy(true);
    try {
      const { body } = await api<{ name: string; sessions_revoked: number }>(`/api/v1/admin/companies/${c.id}`, { method: "DELETE" });
      if (body.success) {
        toast.success(`حُذفت شركة «${c.name}» — أُنهيت ${body.data?.sessions_revoked ?? 0} جلسة`);
        if (isCurrent) {
          clearTokens();
          setTimeout(() => onLogout?.(), 1200);
        } else {
          await load();
          await refreshScope(true);
        }
      } else toast.error(body.message ?? "فشل حذف الشركة");
    } finally {
      setBusy(false);
    }
  }

  const load = React.useCallback(async () => {
    const r = await api<CompanyRow[]>("/api/v1/admin/companies");
    if (r.body.success && r.body.data) setRows(r.body.data);
    else toast.error(r.body.message ?? "فشل تحميل الشركات");
  }, []);

  React.useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load();
  }, [load]);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      code: String(fd.get("code") || "").trim(),
      name: String(fd.get("name") || "").trim(),
      name_en: String(fd.get("name_en") || "").trim() || undefined,
      legal_name: String(fd.get("legal_name") || "").trim() || undefined,
      tax_number: String(fd.get("tax_number") || "").trim() || undefined,
      phone: String(fd.get("phone") || "").trim() || undefined,
      email: String(fd.get("email") || "").trim() || undefined,
      address: String(fd.get("address") || "").trim() || undefined,
    };
    setBusy(true);
    try {
      if (editing) {
        const { body } = await api(`/api/v1/admin/companies/${editing.id}`, {
          method: "PATCH",
          body: JSON.stringify(payload),
        });
        if (body.success) {
          toast.success(`حُدّثت بيانات «${(body.data as { name: string }).name}» — سيظهر الاسم الجديد في الفواتير`);
          setEditing(null);
          await load();
          // refresh scope so the new name reaches the header/sidebar instantly
          await refreshScope(true);
        } else toast.error(body.message ?? "فشل التحديث");
      } else {
        const { body } = await api<{ name: string; rolesCreated: number }>("/api/v1/admin/companies", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        const created = body.data;
        if (body.success && created) {
          toast.success(`أُنشئت شركة «${created.name}» مع تجهيز كامل (${created.rolesCreated} دور نظامي)`);
          (e.target as HTMLFormElement).reset();
          await load();
          // make the new company switchable right away
          await refreshScope(true);
          toast.info("يمكنك التبديل إلى الشركة الجديدة من مبدّل الشركة أعلى الشاشة");
        } else toast.error(body.message ?? "فشل الإنشاء");
      }
    } finally {
      setBusy(false);
    }
  }

  /** POST refresh-scope → new access token + scope → update session (no re-login). */
  async function refreshScope(silent = false) {
    const { body } = await api<{ access_token: string; scope: SessionScope; active_company_id: number }>(
      "/api/v1/auth/refresh-scope",
      { method: "POST" }
    );
    if (body.success && body.data) {
      onSession?.(applyScopeSwitch(body.data, session));
      if (!silent) toast.success("حُدّث نطاق الصلاحيات");
    } else if (!silent) {
      toast.error(body.message ?? "فشل تحديث النطاق");
    }
  }

  function startEdit(c: CompanyRow) {
    setEditing(c);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  // ---- لوحة المالك: إدارة اشتراك شركة ---------------------------------
  async function patchCompany(id: number, data: Record<string, unknown>, okMsg: string) {
    setBusy(true);
    try {
      const { body } = await api<{ name: string; sessions_revoked?: number }>(`/api/v1/admin/companies/${id}`, {
        method: "PATCH",
        body: JSON.stringify(data),
      });
      if (body.success) {
        toast.success(body.data?.sessions_revoked ? `${okMsg} — أُنهيت ${body.data.sessions_revoked} جلسة` : okMsg);
        await load();
      } else toast.error(body.message ?? "فشل التحديث");
    } finally {
      setBusy(false);
    }
  }

  /** حفظ مدة الاشتراك من اللوحة: تاريخ مخصص/إفراغ + ملاحظة */
  async function saveSubscription(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!subTarget) return;
    const fd = new FormData(e.currentTarget);
    const date = String(fd.get("sub_date") || "").trim();
    const note = String(fd.get("sub_note") || "").trim();
    await patchCompany(
      subTarget.id,
      { subscription_ends_at: date || null, subscription_note: note || null, is_suspended: false },
      date ? `حُدّدت مدة اشتراك «${subTarget.name}» حتى ${fmtDate(date)} ✓` : `أُصبح اشتراك «${subTarget.name}» مفتوحًا ✓`
    );
    setSubTarget(null);
  }

  /** تمديد سريع بالأيام من تاريخ اليوم (أو من تاريخ الانتهاء الحالي إن كان أبعد) */
  async function extend(c: CompanyRow, days: number) {
    const base = c.subscription.ends_at ? new Date(c.subscription.ends_at).getTime() : Date.now();
    const from = Math.max(base, Date.now());
    const next = new Date(from + days * 86_400_000);
    await patchCompany(
      c.id,
      { subscription_ends_at: next.toISOString(), is_suspended: false },
      `مُدّد اشتراك «${c.name}» ${days} يوماً — حتى ${fmtDate(next.toISOString())} ✓`
    );
    setSubTarget(null);
  }

  return (
    <div className="space-y-4">
      {/* شعار النظام — هوية المنصة العامة (شاشة الدخول + الهيدر) — مستقل عن شعارات الشركات */}
      {canEdit && canSystemBrand && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <ImagePlus className="w-4 h-4" /> شعار النظام (هوية المنصة)
            </CardTitle>
            <CardDescription>
              صورة PNG/JPG حتى 5 ميجابايت — شعار النظام نفسه، يظهر في شاشة تسجيل الدخول وأعلى شريط النظام العلوي فقط. مستقل تمامًا عن شعارات الشركات (لكل شركة شعارها الخاص في البطاقة أدناه). للشعار المربع (1:1) أفضلية في العرض.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 flex-wrap">
              {systemLogo ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={systemLogo} alt="شعار النظام الحالي" className="w-16 h-16 rounded-xl object-cover ring-1 ring-border bg-muted" />
              ) : (
                <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary to-amber-500 flex items-center justify-center">
                  <Store className="w-7 h-7 text-white" />
                </div>
              )}
              <div className="flex gap-2 flex-wrap">
                <label className="inline-flex">
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/gif"
                    className="hidden"
                    disabled={sysLogoBusy}
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) uploadSystemLogo(f);
                      e.currentTarget.value = "";
                    }}
                  />
                  <span className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md bg-primary text-white text-xs font-semibold cursor-pointer hover:bg-primary/90 transition-colors">
                    {sysLogoBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImagePlus className="w-4 h-4" />}
                    {systemLogo ? "تغيير شعار النظام" : "رفع شعار النظام"}
                  </span>
                </label>
                {systemLogo && (
                  <Button size="sm" variant="outline" disabled={sysLogoBusy} onClick={removeSystemLogo}>
                    <X className="w-4 h-4" /> إزالة
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* شعار الشركة النشطة — يظهر أعلى القائمة الجانبية ورأس الفواتير المطبوعة لهذه الشركة */}
      {canEdit && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Building2 className="w-4 h-4" /> شعار الشركة — {activeCompanyNameLocal}
            </CardTitle>
            <CardDescription>
              صورة PNG/JPG حتى 5 ميجابايت — شعار الشركة النشطة حصراً، يظهر أعلى القائمة الجانبية وفي رأس فواتير هذه الشركة المطبوعة. يظهر في شاشة الدخول شعار النظام فقط (البطاقة أعلاه). للشعار المربع (1:1) أفضلية في العرض.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 flex-wrap">
              {activeLogo ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={activeLogo} alt="شعار الشركة الحالي" className="w-16 h-16 rounded-xl object-cover ring-1 ring-border bg-muted" />
              ) : (
                <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary to-amber-500 flex items-center justify-center">
                  <Building2 className="w-7 h-7 text-white" />
                </div>
              )}
              <div className="flex gap-2 flex-wrap">
                <label className="inline-flex">
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/gif"
                    className="hidden"
                    disabled={logoBusy}
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) uploadLogo(f);
                      e.currentTarget.value = "";
                    }}
                  />
                  <span className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md bg-primary text-white text-xs font-semibold cursor-pointer hover:bg-primary/90 transition-colors">
                    {logoBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImagePlus className="w-4 h-4" />}
                    {activeLogo ? "تغيير شعار الشركة" : "رفع شعار الشركة"}
                  </span>
                </label>
                {activeLogo && (
                  <Button size="sm" variant="outline" disabled={logoBusy} onClick={removeLogo}>
                    <X className="w-4 h-4" /> إزالة
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {canEdit && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Building2 className="w-4 h-4" />
              {editing ? `تعديل بيانات: ${editing.name}` : "شركة جديدة — تجهيز كامل"}
            </CardTitle>
            <CardDescription>
              {editing
                ? "الاسم يظهر تحت اسم النظام وفي ترويسة كل فواتير هذه الشركة"
                : "تُنشأ الشركة مع: فرع رئيسي + مستودع رئيسي + 11 دورًا نظاميًا + تسلسلات مستندات + إعدادات + زبون نقدي افتراضي"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={submit} className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
              <Input
                name="code"
                required
                disabled={!!editing}
                placeholder="الكود (CO-NEW)"
                className="h-9"
                dir="ltr"
                defaultValue={editing?.code ?? ""}
              />
              <Input name="name" required placeholder="اسم الشركة (يظهر في الفواتير)" className="h-9" defaultValue={editing?.name ?? ""} />
              <Input name="name_en" placeholder="الاسم الإنجليزي" className="h-9" dir="ltr" defaultValue={editing?.name_en ?? ""} />
              <Input name="legal_name" placeholder="الاسم القانوني" className="h-9" defaultValue={editing?.legal_name ?? ""} />
              <Input name="tax_number" placeholder="الرقم الضريبي" className="h-9" dir="ltr" defaultValue={editing?.tax_number ?? ""} />
              <Input name="phone" placeholder="هاتف" className="h-9" dir="ltr" defaultValue={editing?.phone ?? ""} />
              <Input name="email" type="email" placeholder="البريد الإلكتروني" className="h-9" dir="ltr" defaultValue={editing?.email ?? ""} />
              <Input name="address" placeholder="العنوان" className="h-9" defaultValue={editing?.address ?? ""} />
              <div className="flex gap-2 sm:col-span-2 lg:col-span-4">
                <Button type="submit" size="sm" disabled={busy}>
                  {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : editing ? <Pencil className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  {editing ? "حفظ التعديلات" : "إضافة الشركة"}
                </Button>
                {editing && (
                  <Button type="button" size="sm" variant="ghost" disabled={busy} onClick={() => setEditing(null)}>
                    <X className="w-4 h-4" /> إلغاء
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* لوحة المالك: تحديد مدة اشتراك شركة */}
      {subTarget && canEdit && (
        <Card className="border-primary/40">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <CalendarClock className="w-4 h-4 text-primary" /> مدة اشتراك: {subTarget.name}
            </CardTitle>
            <CardDescription>
              الحالة الحالية: {subTarget.subscription.status === "OPEN" ? "مفتوح بلا حد" : subTarget.subscription.status === "SUSPENDED" ? "معلّقة" : subTarget.subscription.status === "EXPIRED" ? "منتهٍ" : `ينتهي بعد ${subTarget.subscription.days_left} يوم`} · عند التعليق أو الانتهاء يُمنع دخول مستخدمي الشركة فورًا (مالكو المنصة Global يبقون قادرين على الدخول للإدارة)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-1.5 mb-3">
              <Button type="button" size="sm" variant="outline" disabled={busy} onClick={() => extend(subTarget, 30)}>+ شهر (30 يوم)</Button>
              <Button type="button" size="sm" variant="outline" disabled={busy} onClick={() => extend(subTarget, 90)}>+ 3 أشهر</Button>
              <Button type="button" size="sm" variant="outline" disabled={busy} onClick={() => extend(subTarget, 180)}>+ 6 أشهر</Button>
              <Button type="button" size="sm" variant="outline" disabled={busy} onClick={() => extend(subTarget, 365)}>+ سنة</Button>
            </div>
            <form onSubmit={saveSubscription} className="grid gap-2 sm:grid-cols-3">
              <label className="text-xs font-medium space-y-1">
                تاريخ الانتهاء (فارغ = مفتوح بلا حد)
                <Input type="date" name="sub_date" className="h-9" dir="ltr"
                  defaultValue={subTarget.subscription.ends_at ? subTarget.subscription.ends_at.slice(0, 10) : ""} />
              </label>
              <label className="text-xs font-medium space-y-1">
                ملاحظة المالك (الباقة / جهة الدفع…)
                <Input name="sub_note" className="h-9" placeholder="مثال: باقة سنوية — دفع نقدي" defaultValue={subTarget.subscription.note ?? ""} />
              </label>
              <div className="flex items-end gap-2">
                <Button type="submit" size="sm" disabled={busy}>حفظ المدة</Button>
                <Button type="button" size="sm" variant="ghost" disabled={busy} onClick={() => setSubTarget(null)}>
                  <X className="w-4 h-4" /> إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <CardTitle className="text-base">الشركات</CardTitle>
              <CardDescription>كل شركة باسمها الخاص — يظهر تحت اسم النظام وفي فواتيرها</CardDescription>
            </div>
            <div className="flex gap-1.5">
              <Button size="sm" variant="outline" onClick={() => refreshScope(false)} title="إعادة قراءة الصلاحيات والشركات من قاعدة البيانات">
                <RefreshCw className="w-4 h-4" /> تحديث النطاق
              </Button>
              <Button size="sm" variant="ghost" onClick={load}><RefreshCw className="w-4 h-4" /></Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {rows == null ? (
            <div className="py-8 text-center text-muted-foreground"><Loader2 className="w-5 h-5 animate-spin inline" /></div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الكود</TableHead>
                  <TableHead>الشركة</TableHead>
                  <TableHead>الهاتف</TableHead>
                  <TableHead className="text-left">فروع</TableHead>
                  <TableHead className="text-left">مستخدمون</TableHead>
                  <TableHead className="text-left">فواتير</TableHead>
                  <TableHead className="text-left">عملاء</TableHead>
                  <TableHead className="text-left">الاشتراك</TableHead>
                  <TableHead className="text-left">الحالة</TableHead>
                  {canEdit && <TableHead className="text-left">إجراءات</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((c) => (
                  <TableRow key={c.id}>
                    <TableCell className="font-mono text-xs" dir="ltr">{c.code ?? "—"}</TableCell>
                    <TableCell>
                      <div className="text-sm font-medium">{c.name}</div>
                      {c.name_en && <div className="text-[11px] text-muted-foreground" dir="ltr">{c.name_en}</div>}
                    </TableCell>
                    <TableCell className="text-xs" dir="ltr">{c.phone ?? "—"}</TableCell>
                    <TableCell className="text-left text-sm">{c.branches_count}</TableCell>
                    <TableCell className="text-left text-sm">{c.users_count}</TableCell>
                    <TableCell className="text-left text-sm">{c.invoices_count}</TableCell>
                    <TableCell className="text-left text-sm">{c.customers_count}</TableCell>
                    <TableCell className="text-left">
                      {subBadge(c.subscription)}
                      {c.subscription.note && <div className="text-[10px] text-muted-foreground mt-0.5" title={c.subscription.note}>{c.subscription.note}</div>}
                    </TableCell>
                    <TableCell className="text-left">
                      {c.is_active_company ? (
                        <Badge variant="success" className="text-[10px] gap-1">
                          <CheckCircle2 className="w-3 h-3" /> النشطة الآن
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-[10px]">—</Badge>
                      )}
                    </TableCell>
                    {canEdit && (
                      <TableCell className="text-left">
                        <div className="flex gap-1 justify-end">
                          <Button size="icon" variant="ghost" className="h-7 w-7" title="تحديد مدة الاشتراك / تمديد" onClick={() => setSubTarget(subTarget?.id === c.id ? null : c)}>
                            <CalendarClock className="w-4 h-4 text-sky-600" />
                          </Button>
                          <Button
                            size="icon" variant="ghost" className="h-7 w-7"
                            title={c.subscription.is_suspended ? "إلغاء التعليق وتشغيل الشركة" : "تعليق الشركة وإنهاء كل جلساتها"}
                            disabled={busy}
                            onClick={() =>
                              c.subscription.is_suspended
                                ? patchCompany(c.id, { is_suspended: false }, `أُعيد تشغيل «${c.name}» ✓`)
                                : window.confirm(`تعليق شركة «${c.name}»؟ ستُمنع كل مستخدميها من الدخول وتُنهى كل جلساتهم فورًا.`) && patchCompany(c.id, { is_suspended: true }, `عُلّقت «${c.name}» وأُنهيت جلساتها ✓`)
                            }
                          >
                            {c.subscription.is_suspended ? <PlayCircle className="w-4 h-4 text-green-600" /> : <PauseCircle className="w-4 h-4 text-amber-500" />}
                          </Button>
                          <Button
                            size="icon" variant="ghost" className="h-7 w-7"
                            title="إنهاء كل جلسات مستخدمي هذه الشركة فورًا"
                            disabled={busy}
                            onClick={() => {
                              if (window.confirm(`إنهاء كل جلسات مستخدمي «${c.name}»؟ سيسجّل الجميع الدخول من جديد.`)) {
                                patchCompany(c.id, { kill_sessions: true }, `أُنهيت كل جلسات «${c.name}» ✓`);
                              }
                            }}
                          >
                            <Zap className="w-4 h-4 text-rose-600" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-7 w-7" title="تعديل الاسم والبيانات" onClick={() => startEdit(c)}>
                            <Pencil className="w-4 h-4 text-amber-500" />
                          </Button>
                          {canDelete && (
                            <Button
                              size="icon" variant="ghost" className="h-7 w-7"
                              title="حذف الشركة (حذف ناعم + إنهاء جلساتها)"
                              disabled={busy}
                              onClick={() => deleteCompany(c)}
                            >
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
