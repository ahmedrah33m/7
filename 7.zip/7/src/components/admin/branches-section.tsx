"use client";

// =====================================================================
// Branches + Warehouses management (MASTER PROMPT §8/§10/§12/§14):
// كل شركة تمتلك فروعها ومستودعاتها (فرعية/مندوبين) الخاصة — عزل تام
// UNIQUE(company_id, code) — تطابق الأسماء بين الشركات مسموح.
// =====================================================================

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { formatIQD } from "@/lib/utils";
import { Building2, Loader2, Plus, RefreshCw, Trash2, Power, Warehouse } from "lucide-react";

interface BranchRow {
  id: number;
  code: string;
  name: string;
  phone: string | null;
  address: string | null;
  city: string | null;
  is_active: boolean;
  warehouses: { id: number; name: string }[];
  users_count: number;
  invoices_count: number;
  revenue: number;
  created_at: string;
}

interface WarehouseRow {
  id: number;
  code: string;
  name: string;
  type: string;
  is_mobile: boolean;
  is_active: boolean;
  branch_id: number;
  branch: string | null;
  skus: number;
}

const WH_TYPE_LABELS: Record<string, string> = {
  MAIN: "رئيسي", BRANCH: "فرعي", REP: "مندوب", TRANSIT: "عبور", DAMAGED: "تالف", RETURN: "مرتجعات",
};

export function BranchesSection({ canEdit }: { canEdit: boolean }) {
  const [rows, setRows] = React.useState<BranchRow[] | null>(null);
  const [warehouses, setWarehouses] = React.useState<WarehouseRow[] | null>(null);
  const [busy, setBusy] = React.useState(false);

  const load = React.useCallback(async () => {
    const r = await api<BranchRow[]>("/api/v1/admin/branches");
    if (r.body.success && r.body.data) setRows(r.body.data);
    else toast.error(r.body.message ?? "فشل تحميل الفروع");
    const w = await api<WarehouseRow[]>("/api/v1/admin/warehouses");
    if (w.body.success && w.body.data) setWarehouses(w.body.data);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  async function create(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setBusy(true);
    try {
      const { body } = await api("/api/v1/admin/branches", {
        method: "POST",
        body: JSON.stringify({
          code: String(fd.get("code") || "").trim(),
          name: String(fd.get("name") || "").trim(),
          phone: fd.get("phone") || undefined,
          city: fd.get("city") || undefined,
          address: fd.get("address") || undefined,
        }),
      });
      if (body.success) {
        toast.success(`أُنشئ الفرع ${(body.data as { name: string }).name}`);
        (e.target as HTMLFormElement).reset();
        await load();
      } else toast.error(body.message ?? "فشل الإنشاء");
    } finally {
      setBusy(false);
    }
  }

  async function toggleActive(b: BranchRow) {
    setBusy(true);
    try {
      const { body } = await api(`/api/v1/admin/branches/${b.id}`, {
        method: "PATCH",
        body: JSON.stringify({ is_active: !b.is_active }),
      });
      if (body.success) await load();
      else toast.error(body.message ?? "فشل التحديث");
    } finally {
      setBusy(false);
    }
  }

  async function remove(b: BranchRow) {
    if (!window.confirm(`حذف الفرع «${b.name}» نهائيًا (حذف ناعم)؟`)) return;
    setBusy(true);
    try {
      const { body } = await api(`/api/v1/admin/branches/${b.id}`, { method: "DELETE" });
      if (body.success) {
        toast.success("حُذف الفرع");
        await load();
      } else toast.error(body.message ?? "فشل الحذف");
    } finally {
      setBusy(false);
    }
  }

  async function createWarehouse(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setBusy(true);
    try {
      const { body } = await api("/api/v1/admin/warehouses", {
        method: "POST",
        body: JSON.stringify({
          code: String(fd.get("code") || "").trim(),
          name: String(fd.get("name") || "").trim(),
          branch_id: Number(fd.get("branch_id")),
          type: String(fd.get("type") || "BRANCH"),
          is_mobile: fd.get("is_mobile") === "on",
        }),
      });
      if (body.success) {
        toast.success(`أُنشئ المستودع ${(body.data as { name: string }).name}`);
        (e.target as HTMLFormElement).reset();
        await load();
      } else toast.error(body.message ?? "فشل إنشاء المستودع");
    } finally {
      setBusy(false);
    }
  }

  async function toggleWarehouseActive(w: WarehouseRow) {
    setBusy(true);
    try {
      const { body } = await api("/api/v1/admin/warehouses", {
        method: "PATCH",
        body: JSON.stringify({ warehouse_id: w.id, is_active: !w.is_active }),
      });
      if (body.success) await load();
      else toast.error(body.message ?? "فشل التحديث");
    } finally {
      setBusy(false);
    }
  }

  // حذف مستودع (حذف ناعم) — يرفضه الخادم إذا كان رئيسيًا أو يحمل مخزونًا
  async function removeWarehouse(w: WarehouseRow) {
    if (!window.confirm(`حذف المستودع «${w.name}» (${w.code})؟

· يُخفى نهائيًا من القوائم ولا يمكن الاستلام فيه
· حركاته وفواتيره التاريخية تبقى سليمة
· يُرفض إذا كان رئيسيًا أو يحمل مخزونًا غير صفري`)) return;
    setBusy(true);
    try {
      const { body } = await api(`/api/v1/admin/warehouses?id=${w.id}`, { method: "DELETE" });
      if (body.success) {
        toast.success(`حُذف المستودع ${w.name} ✓`);
        await load();
      } else toast.error(body.message ?? "فشل الحذف");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      {canEdit && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base"><Building2 className="w-4 h-4" /> فرع جديد</CardTitle>
            <CardDescription>الكود لاتيني فريد لكل شركة — يمكن ربط المستودعات لاحقًا</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={create} className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
              <Input name="code" required placeholder="الكود (BSR)" className="h-9" dir="ltr" />
              <Input name="name" required placeholder="اسم الفرع" className="h-9" />
              <Input name="city" placeholder="المدينة" className="h-9" />
              <Input name="phone" placeholder="هاتف" className="h-9" dir="ltr" />
              <Button type="submit" size="sm" disabled={busy}>
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} إضافة
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base">الفروع</CardTitle>
              <CardDescription>الإيراد محسوب من كل فواتير الفرع</CardDescription>
            </div>
            <Button size="sm" variant="ghost" onClick={load}><RefreshCw className="w-4 h-4" /></Button>
          </div>
        </CardHeader>
        <CardContent>
          {rows == null ? (
            <div className="py-8 text-center text-muted-foreground"><Loader2 className="w-5 h-5 animate-spin inline" /></div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الكود</TableHead>
                  <TableHead>الفرع</TableHead>
                  <TableHead>المدينة</TableHead>
                  <TableHead className="text-left">المستودعات</TableHead>
                  <TableHead className="text-left">مستخدمون</TableHead>
                  <TableHead className="text-left">فواتير</TableHead>
                  <TableHead className="text-left">الإيراد</TableHead>
                  <TableHead className="text-left">الحالة</TableHead>
                  {canEdit && <TableHead className="text-left">إجراءات</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((b) => (
                  <TableRow key={b.id}>
                    <TableCell className="font-mono text-xs" dir="ltr">{b.code}</TableCell>
                    <TableCell className="text-sm font-medium">{b.name}</TableCell>
                    <TableCell className="text-sm">{b.city ?? "—"}</TableCell>
                    <TableCell className="text-left text-sm">{b.warehouses.length}</TableCell>
                    <TableCell className="text-left text-sm">{b.users_count}</TableCell>
                    <TableCell className="text-left text-sm">{b.invoices_count}</TableCell>
                    <TableCell className="text-left text-sm font-semibold" dir="ltr">{formatIQD(b.revenue)}</TableCell>
                    <TableCell className="text-left">
                      <Badge variant={b.is_active ? "success" : "destructive"} className="text-[10px]">
                        {b.is_active ? "نشط" : "معطّل"}
                      </Badge>
                    </TableCell>
                    {canEdit && (
                      <TableCell className="text-left">
                        <div className="flex gap-1 justify-end">
                          <Button size="icon" variant="ghost" className="h-7 w-7" title={b.is_active ? "تعطيل" : "تنشيط"} onClick={() => toggleActive(b)} disabled={busy}>
                            <Power className={`w-4 h-4 ${b.is_active ? "text-amber-500" : "text-green-600"}`} />
                          </Button>
                          {b.warehouses.length === 0 && b.users_count === 0 && (
                            <Button size="icon" variant="ghost" className="h-7 w-7" title="حذف" onClick={() => remove(b)} disabled={busy}>
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
      {canEdit && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base"><Warehouse className="w-4 h-4" /> مستودع جديد</CardTitle>
            <CardDescription>
              مستودع فرعي أو مستودع مندوب (REP) يتبع فرعًا من فروع الشركة النشطة — لا يمكن ربطه بفرع شركة أخرى
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={createWarehouse} className="grid gap-2 sm:grid-cols-2 lg:grid-cols-6">
              <Input name="code" required placeholder="الكود (WH-BSR)" className="h-9" dir="ltr" />
              <Input name="name" required placeholder="اسم المستودع" className="h-9" />
              <select name="branch_id" required className="h-9 rounded-md border bg-background px-2 text-sm" defaultValue="">
                <option value="" disabled>الفرع…</option>
                {(rows ?? []).filter((b) => b.is_active).map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
              <select name="type" className="h-9 rounded-md border bg-background px-2 text-sm" defaultValue="BRANCH">
                {Object.entries(WH_TYPE_LABELS).map(([k, v]) => (
                  <option key={k} value={k}>{k} — {v}</option>
                ))}
              </select>
              <label className="flex items-center gap-1.5 text-xs text-muted-foreground h-9">
                <input type="checkbox" name="is_mobile" /> مستودع متنقل
              </label>
              <Button type="submit" size="sm" disabled={busy}>
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} إضافة
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">المستودعات</CardTitle>
          <CardDescription>كل مستودعات الشركة النشطة (رئيسي/فرعي/مندوب) — الفريدة لكل شركة</CardDescription>
        </CardHeader>
        <CardContent>
          {warehouses == null ? (
            <div className="py-8 text-center text-muted-foreground"><Loader2 className="w-5 h-5 animate-spin inline" /></div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الكود</TableHead>
                  <TableHead>المستودع</TableHead>
                  <TableHead>النوع</TableHead>
                  <TableHead>الفرع</TableHead>
                  <TableHead className="text-left">أصناف</TableHead>
                  <TableHead className="text-left">الحالة</TableHead>
                  {canEdit && <TableHead className="text-left"></TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {warehouses.map((w) => (
                  <TableRow key={w.id}>
                    <TableCell className="font-mono text-xs" dir="ltr">{w.code}</TableCell>
                    <TableCell className="text-sm font-medium">
                      {w.name}
                      {w.is_mobile && <Badge variant="secondary" className="ms-1 text-[10px]">متنقل</Badge>}
                    </TableCell>
                    <TableCell><Badge variant="outline" className="text-[10px]">{WH_TYPE_LABELS[w.type] ?? w.type}</Badge></TableCell>
                    <TableCell className="text-sm">{w.branch ?? "—"}</TableCell>
                    <TableCell className="text-left text-sm">{w.skus}</TableCell>
                    <TableCell className="text-left">
                      <Badge variant={w.is_active ? "success" : "destructive"} className="text-[10px]">
                        {w.is_active ? "نشط" : "معطّل"}
                      </Badge>
                    </TableCell>
                    {canEdit && (
                      <TableCell className="text-left">
                        <div className="flex gap-1 justify-end">
                          <Button size="icon" variant="ghost" className="h-7 w-7" title={w.is_active ? "تعطيل" : "تنشيط"} onClick={() => toggleWarehouseActive(w)} disabled={busy}>
                            <Power className={`w-4 h-4 ${w.is_active ? "text-amber-500" : "text-green-600"}`} />
                          </Button>
                          {w.type !== "MAIN" && (
                            <Button size="icon" variant="ghost" className="h-7 w-7" title="حذف المستودع" onClick={() => removeWarehouse(w)} disabled={busy}>
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
