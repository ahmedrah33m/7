"use client";

// =====================================================================
// Role editor — تعديل الأدوار (Phase: RBAC role management)
//   · تعديل اسم الدور ووصفه
//   · استبدال صلاحياته الذرية كاملة (checkboxes مجمّعة حسب الوحدة)
//   · حواجز الحماية على الخادم: OWNER محمي · لا تعديل لدورٍ تملكه · ≥1 صلاحية
// =====================================================================

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/client-api";
import { Loader2, Lock, Save } from "lucide-react";

export interface RoleEditorData {
  id: number;
  code: string;
  name: string;
  description: string | null;
  is_system: boolean;
  permissions: string[];
}

interface PermRow {
  id: number;
  code: string;
  module: string;
  entity: string;
  action: string;
  description_ar: string | null;
}

const ACTION_AR: Record<string, string> = {
  view: "عرض", create: "إنشاء", edit: "تعديل", delete: "حذف",
  approve: "اعتماد", reject: "رفض", cancel: "إلغاء",
  print: "طباعة", export: "تصدير", import: "استيراد", post: "ترحيل", reverse: "عكس",
};

export function RoleEditor({
  role,
  selfRoleIds,
  onSaved,
  onCancel,
}: {
  role: RoleEditorData;
  /** معرفات الأدوار التي يملكها المستخدم الحالي — الخادم يمنع تعديل صلاحياتها */
  selfRoleIds: number[];
  onSaved: () => void;
  onCancel: () => void;
}) {
  const [permsCatalog, setPermsCatalog] = React.useState<PermRow[] | null>(null);
  const [name, setName] = React.useState(role.name);
  const [description, setDescription] = React.useState(role.description ?? "");
  const [selected, setSelected] = React.useState<Set<string>>(new Set(role.permissions));
  const [busy, setBusy] = React.useState(false);

  const permsLocked = role.code === "OWNER" || selfRoleIds.includes(role.id);
  const lockReason =
    role.code === "OWNER"
      ? "صلاحيات دور المالك (OWNER) محمية — لا يمكن تعديلها من أي واجهة"
      : "تملك هذا الدور بنفسك — لا يمكنك تعديل صلاحياته من حسابك (اطلب من مالك آخر)";

  React.useEffect(() => {
    api<PermRow[]>("/api/v1/admin/permissions").then(({ body }) => {
      if (body.success && body.data) setPermsCatalog(body.data);
      else toast.error(body.message ?? "تعذر تحميل كتالوج الصلاحيات");
    });
  }, []);

  // مجمّعة حسب الوحدة (module) للعرض المنظم
  const byModule = React.useMemo(() => {
    const map = new Map<string, PermRow[]>();
    for (const p of permsCatalog ?? []) {
      const list = map.get(p.module) ?? [];
      list.push(p);
      map.set(p.module, list);
    }
    return [...map.entries()].sort(([a], [b]) => a.localeCompare(b));
  }, [permsCatalog]);

  function toggle(code: string) {
    if (permsLocked) return;
    setSelected((cur) => {
      const next = new Set(cur);
      if (next.has(code)) next.delete(code);
      else next.add(code);
      return next;
    });
  }

  function toggleModule(rows: PermRow[], on: boolean) {
    if (permsLocked) return;
    setSelected((cur) => {
      const next = new Set(cur);
      for (const r of rows) (on ? next.add(r.code) : next.delete(r.code));
      return next;
    });
  }

  async function save() {
    if (name.trim().length < 2) { toast.error("اسم الدور قصير جدًا"); return; }
    if (selected.size === 0) { toast.error("يجب إبقاء صلاحية واحدة على الأقل"); return; }
    setBusy(true);
    try {
      const { body } = await api("/api/v1/admin/roles", {
        method: "PATCH",
        body: JSON.stringify({
          role_id: role.id,
          name: name.trim(),
          description: description.trim() || null,
          ...(permsLocked ? {} : { permissions: [...selected] }),
        }),
      });
      if (body.success) {
        toast.success(permsLocked ? `حُدّثت بيانات الدور ${role.code} ✓` : `حُدّث الدور ${role.code} وصلاحياته (${selected.size} صلاحية) ✓`);
        onSaved();
      } else toast.error(body.message ?? "فشل تحديث الدور");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-lg border border-primary/40 bg-primary/[0.03] p-4 space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="font-semibold text-sm flex items-center gap-2">
          تعديل الدور: {role.name}
          <span className="font-mono text-xs text-muted-foreground" dir="ltr">{role.code}</span>
          {role.code === "OWNER" && <Badge variant="accent" className="text-[10px]"><Lock className="w-3 h-3" /> صلاحياته محمية</Badge>}
          {!role.code.startsWith("OWNER") && selfRoleIds.includes(role.id) && (
            <Badge variant="secondary" className="text-[10px]"><Lock className="w-3 h-3" /> دورك الشخصي</Badge>
          )}
        </div>
        <div className="text-[11px] text-muted-foreground">
          محدد حاليًا: <b dir="ltr">{selected.size}</b> صلاحية
          {!permsLocked && selected.size !== role.permissions.length && (
            <span className="text-amber-600"> (الأصل: {role.permissions.length})</span>
          )}
        </div>
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        <label className="text-xs font-medium space-y-1">اسم الدور
          <Input value={name} onChange={(e) => setName(e.target.value)} className="h-9" />
        </label>
        <label className="text-xs font-medium space-y-1">الوصف
          <Input value={description} onChange={(e) => setDescription(e.target.value)} className="h-9" placeholder="وصف مختصر لمهام الدور" />
        </label>
      </div>

      {permsLocked && (
        <div className="rounded-md border border-amber-500/40 bg-amber-500/5 px-3 py-2 text-xs text-amber-700 dark:text-amber-400 flex items-center gap-1.5">
          <Lock className="w-3.5 h-3.5 shrink-0" /> {lockReason}
        </div>
      )}

      {permsCatalog === null ? (
        <div className="py-6 text-center text-sm text-muted-foreground">جارٍ تحميل كتالوج الصلاحيات...</div>
      ) : (
        <div className="max-h-72 overflow-y-auto rounded-md border bg-background divide-y">
          {byModule.map(([module, rows]) => {
            const allOn = rows.every((r) => selected.has(r.code));
            return (
              <div key={module} className="p-2.5">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="text-xs font-bold font-mono" dir="ltr">{module}</div>
                  {!permsLocked && (
                    <button
                      type="button"
                      className="text-[10px] text-primary hover:underline"
                      onClick={() => toggleModule(rows, !allOn)}
                    >
                      {allOn ? "إلغاء الكل" : "تحديد الكل"}
                    </button>
                  )}
                </div>
                <div className="grid gap-1 sm:grid-cols-2 lg:grid-cols-3">
                  {rows.map((p) => (
                    <label key={p.id} className={`flex items-start gap-1.5 text-xs ${permsLocked ? "opacity-80" : "cursor-pointer"}`}>
                      <input
                        type="checkbox"
                        className="mt-0.5"
                        checked={selected.has(p.code)}
                        disabled={permsLocked}
                        onChange={() => toggle(p.code)}
                      />
                      <span>
                        <span className="font-medium">{ACTION_AR[p.action] ?? p.action}</span>
                        <span className="text-muted-foreground"> · {p.entity}</span>
                        {p.description_ar && <div className="text-[9px] text-muted-foreground leading-tight">{p.description_ar}</div>}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="flex gap-2">
        <Button size="sm" onClick={save} disabled={busy}>
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} حفظ الدور
        </Button>
        <Button size="sm" variant="outline" onClick={onCancel} disabled={busy}>إلغاء</Button>
      </div>
    </div>
  );
}
