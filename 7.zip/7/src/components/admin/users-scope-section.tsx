"use client";

// =====================================================================
// Users & Scope management (MASTER PROMPT Phases 2 + 44)
//   · إنشاء مستخدم بنطاق كامل (الاسم/الدخول/الدور/الفرع/المستودع/المندوب)
//   · محرر نطاق المستخدم: فروع متعددة + مستودعات متعددة (checkboxes)
//   · تعطيل مستخدم (يُنهي جلساته فورًا) + إعادة تعيين كلمة المرور
// =====================================================================

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api, type LoginPayload } from "@/lib/client-api";
import { formatDateTime } from "@/lib/utils";
import { KeyRound, Loader2, Plus, ShieldCheck, Trash2, UserCog, Users, X } from "lucide-react";

interface ScopeUserRow {
  id: number;
  username: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  is_active: boolean;
  last_login_at: string | null;
  last_login_ip: string | null;
  branch_id: number | null;
  branch: string | null;
  company_id: number;
  company_name: string;
  company_code: string;
  scope_type: string;
  sales_rep_id: number | null;
  branches: number[];
  warehouses: number[];
  companies: number[];
  roles: { code: string; name: string }[];
}

interface RoleRow {
  id: number; code: string; name: string; is_system: boolean; users_count: number;
}

const SCOPE_LABELS: Record<string, { label: string; cls: string }> = {
  GLOBAL: { label: "عالمي — كل الشركات", cls: "bg-purple-100 text-purple-800" },
  COMPANY: { label: "شركة كاملة", cls: "bg-emerald-100 text-emerald-800" },
  BRANCH: { label: "فرع/فروع محددة", cls: "bg-amber-100 text-amber-800" },
  WAREHOUSE: { label: "مستودع محدد", cls: "bg-sky-100 text-sky-800" },
  SALES_REP: { label: "مندوب", cls: "bg-rose-100 text-rose-800" },
  SELF: { label: "بياناتي فقط (موظف)", cls: "bg-slate-100 text-slate-800" },
};

// ---- التسلسل الهرمي (وثيقة Hierarchical Visibility §2) -------------------
// المستوى الإداري مشتق من نوع النطاق — نفس منطق الخادم (adminLevelOf)
const ADMIN_LEVEL_LABELS: Record<string, string> = {
  PLATFORM_OWNER: "مالك المنصة",
  COMPANY_MANAGER: "مدير شركة",
  BRANCH_MANAGER: "مدير فرع",
  EMPLOYEE: "موظف",
};
const SCOPE_TO_LEVEL: Record<string, string> = {
  GLOBAL: "PLATFORM_OWNER",
  COMPANY: "COMPANY_MANAGER",
  BRANCH: "BRANCH_MANAGER",
};
const LEVEL_CLS: Record<string, string> = {
  PLATFORM_OWNER: "bg-purple-100 text-purple-800",
  COMPANY_MANAGER: "bg-emerald-100 text-emerald-800",
  BRANCH_MANAGER: "bg-amber-100 text-amber-800",
  EMPLOYEE: "bg-slate-100 text-slate-700",
};
const levelOfScope = (s: string) => SCOPE_TO_LEVEL[s] ?? "EMPLOYEE";

// رتب النطاقات — نفس منطق الخادم: منح نطاق يتطلب رتبة أعلى (§17)
const SCOPE_RANKS: Record<string, number> = { GLOBAL: 40, COMPANY: 30, BRANCH: 20, WAREHOUSE: 10, SALES_REP: 8, SELF: 5 };
const ALL_SCOPES = ["GLOBAL", "COMPANY", "BRANCH", "WAREHOUSE", "SALES_REP", "SELF"] as const;

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";

export function UsersScopeSection({ session }: { session: LoginPayload }) {
  const [users, setUsers] = React.useState<ScopeUserRow[] | null>(null);
  const [branches, setBranches] = React.useState<{ id: number; name: string; code: string }[]>([]);
  const [warehouses, setWarehouses] = React.useState<{ id: number; name: string; code: string }[]>([]);
  // الشركات المتاحة للجلسة (ربط المستخدم بشركة معينة + مبدّل الشركات)
  const [companies, setCompanies] = React.useState<{ id: number; code: string; name: string }[]>([]);
  const [activeCompanyId, setActiveCompanyId] = React.useState<number | null>(null);
  const [createCompanyId, setCreateCompanyId] = React.useState<number | null>(null); // شركة الربط في نموذج الإنشاء
  const [editing, setEditing] = React.useState<ScopeUserRow | null>(null);
  const [editBranches, setEditBranches] = React.useState<number[]>([]);
  const [editWarehouses, setEditWarehouses] = React.useState<number[]>([]);
  const [editRoles, setEditRoles] = React.useState<string[]>([]); // تعديل الأدوار (أكواد الأدوار)
  const [editCompanyId, setEditCompanyId] = React.useState<number | null>(null); // الشركة المرتبطة (النقل)
  const [editCompanies, setEditCompanies] = React.useState<number[]>([]); // شركات التبديل الإضافية
  const [roles, setRoles] = React.useState<RoleRow[] | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [showCreate, setShowCreate] = React.useState(false);
  // تصفية جدول المستخدمين حسب الشركة (المالك GLOBAL يرى كل الشركات — المشكلة 1)
  const [filterCompanyId, setFilterCompanyId] = React.useState<number | null>(null);

  const canCreate = session.permissions.includes("system.users.create");
  const canEdit = session.permissions.includes("system.users.edit");
  const canDelete = session.permissions.includes("system.users.delete");

  // مستوى جلستك + النطاقات التي يحق لك منحها (الخادم يفرض الأمر صرامةً —
  // هذا مجرد إخفاء للخيارات غير المسموحة في الواجهة)
  const myScope = session.scope?.scope_type ?? "BRANCH";
  const myLevel = ADMIN_LEVEL_LABELS[levelOfScope(myScope)];
  const grantableScopes = ALL_SCOPES.filter((s) => (SCOPE_RANKS[myScope] ?? 0) > SCOPE_RANKS[s]);

  // ---- حذف مستخدم (حذف ناعم + إنهاء جلساته) ----------------------------
  async function deleteUser(u: ScopeUserRow) {
    if (!window.confirm(`حذف المستخدم «${u.username}» (${u.full_name})؟

· يُحذف نهائيًا من قائمة المستخدمين ولا يمكن دخوله
· تُنهى كل جلساته الحالية فورًا
· حماية آخر مالك: لا يُحذف المالك الوحيد النشط`)) return;
    setBusy(true);
    try {
      const { body } = await api(`/api/v1/admin/users/${u.id}`, { method: "DELETE" });
      if (body.success) {
        toast.success(`حُذف المستخدم ${u.username} وأُنهيت جلساته ✓`);
        if (editing?.id === u.id) setEditing(null);
        await load();
      } else toast.error(body.message ?? "فشل الحذف");
    } finally {
      setBusy(false);
    }
  }

  // المندوبون = مستخدمو الشركة الحالية بنطاق SALES_REP أو دور SALES_REP
  // (قائمة المالك تشمل كل الشركات — الربط بالمندوب في نموذج الإنشاء يقتصر
  // على الشركة الهدف، وفحص الملكية على الخادم صارم أيضًا)
  const reps = React.useMemo(
    () =>
      (users ?? []).filter(
        (u) => u.scope_type === "SALES_REP" || u.roles.some((r) => r.code === "SALES_REP")
      ),
    [users]
  );
  const createReps = React.useMemo(
    () => reps.filter((r) => r.company_id === (createCompanyId ?? activeCompanyId)),
    [reps, createCompanyId, activeCompanyId]
  );

  // صفوف الجدول بعد التصفية (الافتراضي: كل الشركات في نطاق المالك — المشكلة 1)
  const visibleUsers = React.useMemo(
    () => (users ?? []).filter((u) => filterCompanyId == null || u.company_id === filterCompanyId),
    [users, filterCompanyId]
  );

  const load = React.useCallback(async () => {
    const { body } = await api<ScopeUserRow[]>("/api/v1/admin/users");
    if (body.success && body.data) setUsers(body.data);
    else toast.error(body.message ?? "تعذر تحميل المستخدمين");
  }, []);

  React.useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load();
    api<{ user: { company_id: number }; scope: { active_company_id: number | null; companies: { id: number; code: string; name: string }[]; branches: { id: number; name: string; code: string }[]; warehouses: { id: number; name: string; code: string }[] } }>("/api/v1/auth/me")
      .then(({ body }) => {
        if (body.success && body.data?.scope) {
          setBranches(body.data.scope.branches);
          setWarehouses(body.data.scope.warehouses);
          setCompanies(body.data.scope.companies ?? []);
          const active = body.data.scope.active_company_id ?? body.data.user?.company_id ?? null;
          setActiveCompanyId(active);
          setCreateCompanyId(active);
        }
      });
    // أدوار الشركة النشطة — لمنتقي تعديل الأدوار في المحرر
    api<RoleRow[]>("/api/v1/admin/roles").then(({ body }) => {
      if (body.success && body.data) setRoles(body.data);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function patchUser(userId: number, data: Record<string, unknown>, okMsg: string) {
    setBusy(true);
    try {
      const { body } = await api("/api/v1/admin/users", {
        method: "PATCH",
        body: JSON.stringify({ user_id: userId, ...data }),
      });
      if (body.success) {
        toast.success(okMsg);
        await load();
      } else {
        toast.error(body.message ?? "فشل التحديث");
      }
    } finally {
      setBusy(false);
    }
  }

  async function createUser(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    const fd = new FormData(e.currentTarget);
    const password = String(fd.get("password") ?? "");
    const confirm = String(fd.get("password_confirm") ?? "");
    if (password !== confirm) {
      toast.error("كلمتا المرور غير متطابقتين");
      setBusy(false);
      return;
    }
    try {
      const { body } = await api("/api/v1/admin/users", {
        method: "POST",
        body: JSON.stringify({
          username: fd.get("username"),
          password,
          full_name: fd.get("full_name"),
          email: fd.get("email") || undefined,
          phone: fd.get("phone") || undefined,
          role_code: fd.get("role_code"),
          // ربط المستخدم بشركة معينة (صريح) — الشركة النشطة افتراضيًا
          company_id: createCompanyId ?? undefined,
          branch_id: fd.get("branch_id") ? Number(fd.get("branch_id")) : undefined,
          scope_type: fd.get("scope_type"),
          sales_rep_id: fd.get("sales_rep_id") ? Number(fd.get("sales_rep_id")) : undefined,
          branch_ids: createCompanyId === activeCompanyId ? fd.getAll("branch_ids").map(Number).filter(Boolean) : [],
          warehouse_ids: createCompanyId === activeCompanyId ? fd.getAll("warehouse_ids").map(Number).filter(Boolean) : [],
        }),
      });
      if (body.success && body.data) {
        const created = body.data as { username: string; company_id?: number };
        const boundName = companies.find((c) => c.id === created.company_id)?.name;
        toast.success(`أُنشئ المستخدم ${created.username} ✓${boundName && boundName !== companies.find((c) => c.id === activeCompanyId)?.name ? ` — مرتبط بشركة ${boundName}` : ""}`);
        setShowCreate(false);
        await load();
      } else {
        toast.error(body.message ?? "فشل إنشاء المستخدم");
      }
    } finally {
      setBusy(false);
    }
  }

  function openEditor(u: ScopeUserRow) {
    setEditing(u);
    setEditBranches(u.branches);
    setEditWarehouses(u.warehouses);
    setEditRoles(u.roles.map((r) => r.code)); // الأدوار الحالية جاهزة للتعديل
    setEditCompanyId(u.company_id);
    setEditCompanies(u.companies);
  }

  // هل المحرر في حالة "نقل إلى شركة أخرى"؟ (تُلغي منح الشركة القديمة)
  const editorTransferring = editing != null && editCompanyId != null && editCompanyId !== editing.company_id;

  return (
    <div className="space-y-4">
      {/* ---------- Users table with scope ---------- */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div>
              <CardTitle className="flex items-center gap-2"><Users className="w-4 h-4" /> صلاحيات ونطاق المستخدمين</CardTitle>
              <CardDescription>
                النطاق (Scope) منفصل عن الصلاحية (Role): المدير المركزي يرى عدة فروع بإسناد صريح فقط — والفرض على الخادم دائمًا
              </CardDescription>
            </div>
            {canCreate && (
              <Button size="sm" onClick={() => setShowCreate((v) => !v)}>
                <Plus className="w-4 h-4" /> مستخدم جديد
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* ---------- create form (Phase 2) ---------- */}
          {showCreate && (
            <form onSubmit={createUser} className="rounded-lg border p-4 space-y-3 bg-muted/30">
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                <label className="text-xs font-medium space-y-1">الاسم الكامل *
                  <Input name="full_name" required minLength={2} className={inputCls} placeholder="مثال: عمر المدير" />
                </label>
                <label className="text-xs font-medium space-y-1">اسم المستخدم *
                  <Input name="username" required minLength={3} dir="ltr" className={`${inputCls} text-left`} placeholder="baghdad_admin" />
                </label>
                <label className="text-xs font-medium space-y-1">البريد الإلكتروني
                  <Input name="email" type="email" dir="ltr" className={`${inputCls} text-left`} />
                </label>
                <label className="text-xs font-medium space-y-1">رقم الهاتف
                  <Input name="phone" dir="ltr" className={`${inputCls} text-left`} />
                </label>
                <label className="text-xs font-medium space-y-1">كلمة المرور *
                  <Input name="password" type="password" required minLength={8} dir="ltr" className={`${inputCls} text-left`} />
                </label>
                <label className="text-xs font-medium space-y-1">تأكيد كلمة المرور *
                  <Input name="password_confirm" type="password" required minLength={8} dir="ltr" className={`${inputCls} text-left`} />
                </label>
                <label className="text-xs font-medium space-y-1">الدور (Role) *
                  <select name="role_code" required className={inputCls} defaultValue="CASHIER">
                    {["OWNER", "SUPER_ADMIN", "BRANCH_MANAGER", "SALES_MANAGER", "WAREHOUSE_MANAGER", "SALES_REP", "CASHIER", "ACCOUNTANT", "PURCHASING_OFFICER", "AUDITOR", "VIEWER"].map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </label>
                <label className="text-xs font-medium space-y-1">نوع النطاق *
                  <select name="scope_type" required className={inputCls} defaultValue={grantableScopes[0] ?? "BRANCH"}>
                    {grantableScopes.map((s) => (
                      <option key={s} value={s}>{SCOPE_LABELS[s] ? `${s} — ${SCOPE_LABELS[s].label}` : s}</option>
                    ))}
                  </select>
                  <span className="block text-[10px] text-muted-foreground">مستواك: {myLevel} — الرؤية والسلطة تنزل للأسفل فقط (لا يمكنك منح نطاق بمستواك أو أعلى)</span>
                </label>
                {companies.length > 1 ? (
                  <label className="text-xs font-medium space-y-1">
                    <span className="flex items-center gap-1">🏢 الشركة المرتبطة (الانتماء) *</span>
                    <select
                      name="company_id"
                      className={inputCls}
                      value={createCompanyId ?? ""}
                      onChange={(e) => setCreateCompanyId(Number(e.target.value))}
                    >
                      {companies.map((c) => (
                        <option key={c.id} value={c.id}>{c.name} ({c.code})</option>
                      ))}
                    </select>
                  </label>
                ) : (
                  <div className="text-xs space-y-1">
                    <div className="font-semibold">🏢 الشركة المرتبطة</div>
                    <div className="rounded-md border bg-background px-3 py-2 text-muted-foreground">
                      {companies[0]?.name ?? "الشركة النشطة"} — ثابتة (لا توجد شركات أخرى في نطاقك)
                    </div>
                  </div>
                )}
              </div>
              {createCompanyId != null && createCompanyId !== activeCompanyId && (
                <div className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900 leading-relaxed">
                  الربط سيكون مع شركة <b>مختلفة عن شركتك النشطة</b> — أنشئ المستخدم أولًا ثم بدّل إلى تلك الشركة لمنحه الفروع والمستودعات من محرر النطاق (فروع ومستودعات كل شركة ملك حصري لها).
                </div>
              )}
              {createCompanyId == null || createCompanyId === activeCompanyId ? (
              <div className="grid gap-2 sm:grid-cols-2">
                <div className="space-y-1">
                  <div className="text-xs font-semibold">الفروع الممنوحة (متعدد)</div>
                  <div className="max-h-28 overflow-y-auto rounded-md border p-2 space-y-1 bg-background">
                    {branches.map((b) => (
                      <label key={b.id} className="flex items-center gap-2 text-sm">
                        <input type="checkbox" name="branch_ids" value={b.id} />
                        <span>{b.name}</span>
                        <span className="text-[10px] text-muted-foreground" dir="ltr">{b.code}</span>
                      </label>
                    ))}
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-xs font-semibold">المستودعات الممنوحة (متعدد)</div>
                  <div className="max-h-28 overflow-y-auto rounded-md border p-2 space-y-1 bg-background">
                    {warehouses.map((w) => (
                      <label key={w.id} className="flex items-center gap-2 text-sm">
                        <input type="checkbox" name="warehouse_ids" value={w.id} />
                        <span>{w.name}</span>
                        <span className="text-[10px] text-muted-foreground" dir="ltr">{w.code}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
              ) : null}
              <label className="text-xs font-medium space-y-1 sm:max-w-xs">
                ربط بمندوب (لنطاق SALES_REP)
                <select name="sales_rep_id" className={inputCls} defaultValue="">
                  <option value="">— بدون —</option>
                  {createReps.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.full_name} ({r.username})
                    </option>
                  ))}
                </select>
              </label>
              <Button type="submit" disabled={busy}>
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} إنشاء المستخدم
              </Button>
            </form>
          )}

          {users === null ? (
            <div className="py-10 text-center text-muted-foreground">جارٍ التحميل...</div>
          ) : (
            <div className="space-y-2">
              {/* تصفية الشركة — للمالك الذي يرى أكثر من شركة (المشكلة 1) */}
              {companies.length > 1 && (
                <div className="flex items-center gap-2 flex-wrap text-xs">
                  <span className="font-semibold shrink-0">🏢 تصفية حسب الشركة:</span>
                  <select
                    className={`${inputCls} max-w-xs`}
                    value={filterCompanyId ?? ""}
                    onChange={(e) => setFilterCompanyId(e.target.value ? Number(e.target.value) : null)}
                  >
                    <option value="">كل الشركات ({users.length} مستخدم)</option>
                    {companies.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({users.filter((u) => u.company_id === c.id).length})
                      </option>
                    ))}
                  </select>
                  {filterCompanyId != null && (
                    <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => setFilterCompanyId(null)}>
                      <X className="w-3 h-3" /> إلغاء التصفية
                    </Button>
                  )}
                </div>
              )}
            <div className="max-h-[28rem] overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>اسم الدخول</TableHead>
                    <TableHead>الاسم الكامل</TableHead>
                    <TableHead>🏢 الشركة</TableHead>
                    <TableHead>الأدوار</TableHead>
                    <TableHead>النطاق</TableHead>
                    <TableHead>الفروع/المستودعات</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>آخر دخول</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {visibleUsers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center text-muted-foreground py-8">
                        لا يوجد مستخدمون في هذه التصفية
                      </TableCell>
                    </TableRow>
                  ) : (
                  visibleUsers.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell dir="ltr" className="font-medium text-right">
                        {u.username}
                        {u.last_login_ip && <div className="text-[10px] text-muted-foreground" dir="ltr">IP {u.last_login_ip}</div>}
                      </TableCell>
                      <TableCell>{u.full_name}</TableCell>
                      <TableCell>
                        <div className="text-xs font-medium">{u.company_name}</div>
                        <div className="text-[10px] text-muted-foreground" dir="ltr">{u.company_code}</div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {u.roles.map((r) => (
                            <Badge key={r.code} variant="navy" className="text-[10px]">{r.name}</Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col items-start gap-1">
                          <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${SCOPE_LABELS[u.scope_type]?.cls ?? ""}`}>
                            {u.scope_type}
                          </span>
                          <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${LEVEL_CLS[levelOfScope(u.scope_type)] ?? ""}`}>
                            {ADMIN_LEVEL_LABELS[levelOfScope(u.scope_type)]}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {u.branches.length} فرع · {u.warehouses.length} مستودع
                        {u.sales_rep_id != null && (
                          <div className="text-[10px] text-rose-700">
                            مندوب: {reps.find((r) => r.id === u.sales_rep_id)?.full_name ?? `#${u.sales_rep_id}`}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        {u.is_active ? <Badge variant="success">نشط</Badge> : <Badge variant="destructive">معطل</Badge>}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">{formatDateTime(u.last_login_at)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {canEdit && (
                            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => openEditor(u)}>
                              <UserCog className="w-3.5 h-3.5" /> النطاق
                            </Button>
                          )}
                          {canEdit && u.is_active && u.id !== session.user.id && (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-7 px-2 text-xs text-destructive"
                              disabled={busy}
                              onClick={() => {
                                if (window.confirm(`تعطيل المستخدم ${u.username}؟ ستُنهى كل جلساته فورًا.`)) {
                                  patchUser(u.id, { is_active: false }, `عُطّل ${u.username} وأُنهيت جلساته`);
                                }
                              }}
                            >
                              تعطيل
                            </Button>
                          )}
                          {canEdit && !u.is_active && (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-7 px-2 text-xs text-emerald-700"
                              disabled={busy}
                              onClick={() => patchUser(u.id, { is_active: true }, `أُعيد تفعيل ${u.username}`)}
                            >
                              تفعيل
                            </Button>
                          )}
                          {canDelete && u.id !== session.user.id && (
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-7 w-7"
                              title="حذف المستخدم نهائيًا وإنهاء جلساته"
                              disabled={busy}
                              onClick={() => deleteUser(u)}
                            >
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                  )}
                </TableBody>
              </Table>
            </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ---------- scope editor (Phase 44) ---------- */}
      {editing && (
        <Card className="border-primary/40">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <ShieldCheck className="w-4 h-4 text-primary" /> نطاق المستخدم: {editing.full_name} ({editing.username})
            </CardTitle>
            <CardDescription>
              🏢 {editing.company_name} · النطاق: {SCOPE_LABELS[editing.scope_type]?.label ?? editing.scope_type} · الفروع والمستودعات تُطبق فورًا على الخادم
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {/* ---------- ربط الشركة (النقل) + شركات التبديل ---------- */}
            <div className="rounded-lg border p-3 space-y-3 bg-muted/30">
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1">
                  <div className="text-xs font-semibold flex items-center gap-1.5">🏢 الشركة المرتبطة (الانتماء الأساسي)</div>
                  <select
                    className={inputCls}
                    value={editCompanyId ?? ""}
                    onChange={(e) => {
                      const next = Number(e.target.value);
                      setEditCompanyId(next);
                      if (editing && next !== editing.company_id) {
                        // النقل يُلغي منح الشركة القديمة — صفّرها في المحرر
                        setEditBranches([]);
                        setEditWarehouses([]);
                      } else {
                        setEditBranches(editing.branches);
                        setEditWarehouses(editing.warehouses);
                      }
                    }}
                  >
                    {companies.map((c) => (
                      <option key={c.id} value={c.id}>{c.name} ({c.code})</option>
                    ))}
                  </select>
                  {editorTransferring && (
                    <div className="rounded-md border border-amber-300 bg-amber-50 px-2 py-1.5 text-[11px] text-amber-900 leading-relaxed">
                      نقل إلى شركة أخرى: يُلغى كل منحه في شركته الحالية (فروع/مستودعات)، تُعاد ربط أدواره ({editRoles.join(", ") || "—"}) بالشركة الجديدة إن وُجدت بأكواد مطابقة، وتُنهى كل جلساته فورًا.
                    </div>
                  )}
                </div>
                <div className="space-y-1">
                  <div className="text-xs font-semibold">شركات إضافية للتبديل (مبدّل الشركة — لنطاق GLOBAL)</div>
                  <div className="max-h-28 overflow-y-auto rounded-md border p-2 space-y-1 bg-background">
                    {companies.filter((c) => c.id !== editCompanyId).map((c) => (
                      <label key={c.id} className="flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={editCompanies.includes(c.id)}
                          onChange={(e) =>
                            setEditCompanies((cur) => (e.target.checked ? [...cur, c.id] : cur.filter((x) => x !== c.id)))
                          }
                        />
                        <span>{c.name}</span>
                        <span className="text-[10px] text-muted-foreground" dir="ltr">{c.code}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {/* ---------- تعديل الأدوار (جديدة) ---------- */}
              <div className="space-y-1">
                <div className="text-xs font-semibold flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-primary" /> أدوار المستخدم (☑ = ممنوح)
                </div>
                {roles === null ? (
                  <div className="text-xs text-muted-foreground py-2">جارٍ تحميل الأدوار...</div>
                ) : (
                  <div className="max-h-40 overflow-y-auto rounded-md border p-2 space-y-1">
                    {roles.map((r) => (
                      <label key={r.id} className="flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={editRoles.includes(r.code)}
                          disabled={r.code === "OWNER" && editing.roles.some((x) => x.code === "OWNER") && editing.id === session.user.id}
                          onChange={(e) =>
                            setEditRoles((cur) => (e.target.checked ? [...cur, r.code] : cur.filter((x) => x !== r.code)))
                          }
                        />
                        <span>{r.name}</span>
                        <span className="text-[10px] text-muted-foreground font-mono" dir="ltr">{r.code}</span>
                      </label>
                    ))}
                  </div>
                )}
                <div className="text-[10px] text-muted-foreground leading-relaxed">
                  تغيير الأدوار يُعيد صلاحيات المستخدم فورًا · لا يمكن تعديل أدوارك الشخصية من هنا
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-xs font-semibold">الفروع (☑ = ممنوح)</div>
                <div className="max-h-40 overflow-y-auto rounded-md border p-2 space-y-1">
                  {branches.map((b) => (
                    <label key={b.id} className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={editBranches.includes(b.id)}
                        onChange={(e) =>
                          setEditBranches((cur) => (e.target.checked ? [...cur, b.id] : cur.filter((x) => x !== b.id)))
                        }
                      />
                      <span>{b.name}</span>
                      <span className="text-[10px] text-muted-foreground" dir="ltr">{b.code}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-xs font-semibold">المستودعات (☑ = ممنوح)</div>
                <div className="max-h-40 overflow-y-auto rounded-md border p-2 space-y-1">
                  {warehouses.map((w) => (
                    <label key={w.id} className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={editWarehouses.includes(w.id)}
                        onChange={(e) =>
                          setEditWarehouses((cur) => (e.target.checked ? [...cur, w.id] : cur.filter((x) => x !== w.id)))
                        }
                      />
                      <span>{w.name}</span>
                      <span className="text-[10px] text-muted-foreground" dir="ltr">{w.code}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                disabled={busy || editRoles.length === 0}
                onClick={async () => {
                  const transferring = editCompanyId != null && editCompanyId !== editing.company_id;
                  if (transferring && !window.confirm(
                    `نقل المستخدم "${editing.username}" إلى شركة "${companies.find((c) => c.id === editCompanyId)?.name ?? ""}"؟\n\n` +
                    "· سيُلغى كل منحه في شركته الحالية (فروع/مستودعات)\n" +
                    "· سيعاد ربط أدواره بالشركة الجديدة\n" +
                    "· ستُنهى كل جلساته فورًا"
                  )) return;
                  await patchUser(
                    editing.id,
                    {
                      ...(transferring ? { company_id: editCompanyId } : {}),
                      company_ids: editCompanies,
                      branch_ids: editBranches,
                      warehouse_ids: editWarehouses,
                      role_codes: editRoles,
                    },
                    transferring
                      ? `نُقل ${editing.username} إلى شركته الجديدة — بدّل الشركة لرؤيته في قائمة مستخدميها`
                      : `حُدّث نطاق وأدوار ${editing.username}`
                  );
                  setEditing(null);
                }}
              >
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : null} {editorTransferring ? "نقل المستخدم وحفظ" : "حفظ النطاق والأدوار"}
              </Button>
              <Button variant="outline" onClick={() => setEditing(null)}>إلغاء</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
