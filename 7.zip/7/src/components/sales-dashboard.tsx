"use client";

import * as React from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent } from "@/components/ui/tabs";
import { api, applyScopeSwitch, clearTokens, type LoginPayload, type ScopeCompany } from "@/lib/client-api";
import { OverviewTab } from "@/components/sales/overview-tab";
import { ProductsTab } from "@/components/sales/products-tab";
import { CustomersTab } from "@/components/sales/customers-tab";
import { InventoryTab } from "@/components/sales/inventory-tab";
import { NewInvoiceTab } from "@/components/sales/new-invoice-tab";
import { InvoicesTab } from "@/components/sales/invoices-tab";
import { FinanceTab } from "@/components/sales/finance-tab";
import { CashboxTab } from "@/components/sales/cashbox-tab";
import { AccountingTab } from "@/components/sales/accounting-tab";
import { PurchasesTab } from "@/components/sales/purchases-tab";
import { ReturnsTab } from "@/components/sales/returns-tab";
import { TransfersTab } from "@/components/sales/transfers-tab";
import { ReportsTab } from "@/components/sales/reports-tab";
import { FieldTab } from "@/components/sales/field-tab";
import { B2BTab } from "@/components/sales/b2b-tab";
import { OrdersTab } from "@/components/sales/orders-tab";
import { AlertsBell } from "@/components/sales/alerts-bell";
import { SupportBell } from "@/components/sales/support-bell";
import { GlobalSearch } from "@/components/sales/global-search";
import { StocktakeTab } from "@/components/sales/stocktake-tab";
import { QuotationsTab } from "@/components/sales/quotations-tab";
import { DeliveryTab } from "@/components/sales/delivery-tab";
import { Phase0Dashboard } from "@/components/phase0-dashboard";
import {
  Boxes, LayoutDashboard, LogOut, Menu, PackagePlus, Receipt, ShieldAlert, ShieldCheck, Store, Users, FileText,
  Wallet, ShoppingCart, RotateCcw, ArrowLeftRight, BarChart3, MapPin, Globe, ClipboardList, X,
  ClipboardCheck, FileSignature, Truck, GitBranch, Building2, ChevronsUpDown, ChevronsRight,
  Calculator,
} from "lucide-react";

export interface WarehouseInfo { id: number; code: string; name: string }

const SIDEBAR_COLLAPSED_KEY = "maydan.sidebar.collapsed";

type NavItem = { key: string; label: string; icon: React.ReactNode; visible: boolean };
type NavGroup = { title: string; items: NavItem[] };

export function SalesDashboard({ session, onSession, onLogout }: { session: LoginPayload; onSession: (s: LoginPayload) => void; onLogout: () => void }) {
  const [warehouses, setWarehouses] = React.useState<WarehouseInfo[]>([]);
  const [tab, setTabState] = React.useState("overview");
  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const [scopeTick, setScopeTick] = React.useState(0); // re-render scope after switch
  // ---- القائمة الجانبية القابلة للطي (سطح المكتب) — تُحفظ الحالة محليًا ----
  // (زر الطي داخل رأس القائمة الجانبية نفسها — لا يوجد زر طي في الهيدر)
  const [collapsed, setCollapsed] = React.useState(false);
  React.useEffect(() => {
    try { setCollapsed(window.localStorage.getItem(SIDEBAR_COLLAPSED_KEY) === "1"); } catch {}
  }, []);
  const toggleCollapsed = React.useCallback(() => {
    setCollapsed((v) => {
      try { window.localStorage.setItem(SIDEBAR_COLLAPSED_KEY, v ? "0" : "1"); } catch {}
      return !v;
    });
  }, []);

  React.useEffect(() => {
    api<{ warehouses: WarehouseInfo[] }>("/api/v1/auth/me").then(({ body }) => {
      if (body.success && body.data) setWarehouses(body.data.warehouses ?? []);
      else toast.error(body.message ?? "تعذر تحميل النطاق");
    });
  }, [scopeTick]);

  const scope = session.scope;
  const activeBranchName = scope?.branches.find((b) => b.id === (session.user.branch_id ?? scope?.active_branch_id))?.name
    ?? (scope && scope.branches.length === 1 ? scope.branches[0].name : null);
  // Multi-Company — اسم الشركة النشطة يظهر في القائمة الجانبية والفواتير
  const activeCompanyName = scope?.companies.find((c) => c.id === session.user.company_id)?.name
    ?? (scope && scope.companies.length === 1 ? scope.companies[0].name : "الشركة");
  // شعار الشركة النشطة — يظهر في القائمة الجانبية فقط (الفواتير تأخذه من API)
  const activeCompanyLogo = scope?.companies.find((c) => c.id === session.user.company_id)?.logo_url
    ?? (scope && scope.companies.length === 1 ? scope.companies[0].logo_url : null)
    ?? null;

  // ---- شعار النظام (هوية المنصة العامة) — مستقل عن شعار الشركة ----------
  // يظهر في الهيدر بجوار اسم النظام — القائمة الجانبية تعرض شعار الشركة.
  // يتحدث فورًا بعد الرفع/الإزالة عبر حدث sales:branding-changed.
  const [systemLogo, setSystemLogo] = React.useState<string | null>(null);
  const refreshSystemBranding = React.useCallback(() => {
    api<{ logo_url: string | null; logo_version: string | null }>("/api/v1/branding", { method: "GET" }, { skipAuth: true })
      .then(({ body }) => {
        setSystemLogo(body.success && body.data?.logo_url
          ? (body.data.logo_version ? `${body.data.logo_url}?v=${body.data.logo_version}` : body.data.logo_url)
          : null);
      })
      .catch(() => {});
  }, []);
  React.useEffect(() => { refreshSystemBranding(); }, [refreshSystemBranding]);
  React.useEffect(() => {
    function onBrandingChanged() { refreshSystemBranding(); }
    window.addEventListener("sales:branding-changed", onBrandingChanged);
    return () => window.removeEventListener("sales:branding-changed", onBrandingChanged);
  }, [refreshSystemBranding]);

  // ---- Branch Switcher (Phase 15) ---------------------------------------
  async function switchBranch(branchId: number) {
    const { res, body } = await api<{ access_token: string; scope: LoginPayload["scope"]; active_branch_id: number }>(
      "/api/v1/auth/switch-branch",
      { method: "POST", body: JSON.stringify({ branch_id: branchId }) }
    );
    if (!res.ok || !body.success || !body.data) {
      toast.error(body.message ?? "تعذر تغيير الفرع");
      return;
    }
    onSession(applyScopeSwitch(body.data, session));
    setScopeTick((t) => t + 1);
    toast.success(`تم التبديل إلى: ${scope?.branches.find((b) => b.id === branchId)?.name ?? ""}`);
  }

  // ---- Company Switcher (Phase 16) ---------------------------------------
  async function switchCompany(companyId: number) {
    const { res, body } = await api<{ access_token: string; scope: LoginPayload["scope"]; active_company_id: number }>(
      "/api/v1/auth/switch-company",
      { method: "POST", body: JSON.stringify({ company_id: companyId }) }
    );
    if (!res.ok || !body.success || !body.data) {
      // رسالة 423 ظاهرة: كود الخطأ + النص العربي (SUB_001 منتهية / SUB_002 معلّقة)
      toast.error(`${body.code ? body.code + " — " : ""}${body.message ?? "تعذر تغيير الشركة"}`, { duration: 8000 });
      return;
    }
    onSession(applyScopeSwitch(body.data, session));
    setScopeTick((t) => t + 1);
    const targetName = body.data.scope?.companies.find((c) => c.id === companyId)?.name ?? "";
    const sub = body.data.scope?.subscription;
    if (sub && (sub.status === "EXPIRED" || sub.status === "SUSPENDED")) {
      // المالك (GLOBAL) يدخل للإدارة — لكن رسالة الحالة تُعرض فورًا وبوضوح
      toast.error(
        sub.status === "EXPIRED"
          ? `SUB_001 (423): انتهت مدة اشتراك شركة «${targetName}» — مستخدموها ممنوعون من الدخول حتى التجديد (أنت تديرها بصلاحية المالك)`
          : `SUB_002 (423): شركة «${targetName}» معلّقة مؤقتًا — مستخدموها ممنوعون من الدخول (أنت تديرها بصلاحية المالك)`,
        { duration: 10000 }
      );
    } else {
      toast.success(`تم التبديل إلى: ${targetName}`);
      if (sub?.status === "EXPIRING_SOON") {
        toast.warning(`تنبيه: تنتهي مدة اشتراك الشركة بعد ${sub.days_left} يوم — راجع لوحة الشركات للتجديد`, { duration: 8000 });
      }
    }
  }

  // ---- رسالة حالة الاشتراك فور دخول شركة (دخول/تبديل/إعادة تحميل الصفحة) ----
  // تُطلق مرة لكل (شركة، حالة) — تغطي مسار تسجيل الدخول إلى شركة معينة أيضًا
  const subToastKey = React.useRef<string | null>(null);
  const scopeSubscription = scope?.subscription;
  React.useEffect(() => {
    if (!scopeSubscription) return;
    const key = `${session.user.company_id}:${scopeSubscription.status}`;
    if (subToastKey.current === key) return;
    subToastKey.current = key;
    if (scopeSubscription.status === "EXPIRED") {
      toast.error("SUB_001 (423): انتهت مدة اشتراك الشركة النشطة — مستخدموها ممنوعون من الدخول حتى التجديد (أنت تديرها بصلاحية المالك)", { duration: 10000 });
    } else if (scopeSubscription.status === "SUSPENDED") {
      toast.error("SUB_002 (423): الشركة النشطة معلّقة مؤقتًا من مالك النظام — مستخدموها ممنوعون من الدخول", { duration: 10000 });
    } else if (scopeSubscription.status === "EXPIRING_SOON") {
      toast.warning(`تنبيه: تنتهي مدة اشتراك الشركة بعد ${scopeSubscription.days_left} يوم`, { duration: 8000 });
    }
  }, [scopeSubscription, session.user.company_id]);

  const setTab = (t: string) => {
    setTabState(t);
    setDrawerOpen(false);
  };

  // إعادة طلب الفاتورة: فواتير ← نموذج فاتورة جديدة عبر حدث مخصص
  // (يستخدمه زر "إعادة طلب" في تفاصيل الفاتورة — تطوير الفاتورة جولة 2)
  React.useEffect(() => {
    function onGoto(e: Event) {
      const detail = (e as CustomEvent<string>).detail;
      if (typeof detail === "string") setTab(detail);
    }
    window.addEventListener("sales:goto-tab", onGoto);
    return () => window.removeEventListener("sales:goto-tab", onGoto);
  }, []);

  const has = (p: string) => session.permissions.includes(p);
  const canProducts = has("products.products.view");
  const canProductsEdit = has("products.products.create");
  const canCustomers = has("parties.customers.view");
  const canCustomersEdit = has("parties.customers.create");
  const canStock = has("inventory.stock.view");
  const canStockCreate = has("inventory.movements.create");
  const canSell = has("sales.invoices.create");
  const canInvoices = has("sales.invoices.view");
  const canFinance = has("finance.cashboxes.view") || has("finance.payments.view") || has("finance.receipts.view") || has("finance.payment_vouchers.view") || has("finance.cash_transfers.view") || has("finance.cash_closings.view");
  const canCashbox = has("finance.cashboxes.view") || has("finance.receipts.view") || has("finance.payment_vouchers.view") || has("finance.cash_transfers.view") || has("finance.cash_closings.view") || has("finance.statements.view") || has("finance.aging.view");
  const canAccounting = has("accounting.accounts.view") || has("accounting.journal_entries.view") || has("reports.accounting_reports.view");
  const canPay = has("finance.payments.create");
  const canExpense = has("finance.expenses.create");
  const canPurchases = has("purchasing.purchase_invoices.view");
  const canPurchasesCreate = has("purchasing.purchase_invoices.create");
  const canReturns = has("sales.returns.view");
  const canReturnsCreate = has("sales.returns.create");
  const canTransfers = has("inventory.transfers.view");
  const canTransfersCreate = has("inventory.transfers.create");
  const canReports = has("reports.reports.view");
  const canReportsExport = has("reports.reports.export");
  const canField = has("field.visits.view") || has("field.targets.view") || has("field.commissions.view") || has("field.routes.view");
  const canB2B = has("b2b.orders.view");
  const canOrders = has("sales.orders.view");
  const canOrdersCreate = has("sales.orders.create");
  const canOrdersEdit = has("sales.orders.edit");
  const canOrdersCancel = has("sales.orders.cancel");
  const canConvert = has("sales.invoices.create");
  const canQuotations = has("sales.quotations.view");
  const canQuotationsCreate = has("sales.quotations.create");
  const canQuotationsConvert = has("sales.quotations.post");
  const canStocktake = has("inventory.stocktakes.view");
  const canStocktakeCreate = has("inventory.stocktakes.create");
  const canStocktakePost = has("inventory.stocktakes.post");
  const canDelivery = has("sales.delivery_notes.view");
  const canDeliveryCreate = has("sales.delivery_notes.create");
  const canDeliveryEdit = has("sales.delivery_notes.edit");
  const isAdmin = has("system.users.view");

  const navGroups: NavGroup[] = [
    {
      title: "الرئيسية",
      items: [
        { key: "overview", label: "نظرة عامة", icon: <LayoutDashboard className="w-4 h-4" />, visible: true },
        { key: "reports", label: "التقارير", icon: <BarChart3 className="w-4 h-4" />, visible: canReports },
      ],
    },
    {
      title: "المبيعات",
      items: [
        { key: "new-invoice", label: "فاتورة جديدة", icon: <Receipt className="w-4 h-4" />, visible: canSell },
        { key: "quotations", label: "عروض الأسعار", icon: <FileSignature className="w-4 h-4" />, visible: canQuotations },
        { key: "orders", label: "أوامر البيع", icon: <ClipboardList className="w-4 h-4" />, visible: canOrders },
        { key: "invoices", label: "الفواتير", icon: <FileText className="w-4 h-4" />, visible: canInvoices },
        { key: "delivery", label: "إشعارات التسليم", icon: <Truck className="w-4 h-4" />, visible: canDelivery },
        { key: "returns", label: "المرتجعات", icon: <RotateCcw className="w-4 h-4" />, visible: canReturns },
      ],
    },
    {
      title: "المشتريات والمخزون",
      items: [
        { key: "purchases", label: "المشتريات", icon: <ShoppingCart className="w-4 h-4" />, visible: canPurchases },
        { key: "products", label: "المنتجات", icon: <PackagePlus className="w-4 h-4" />, visible: canProducts },
        { key: "inventory", label: "المخزون", icon: <Boxes className="w-4 h-4" />, visible: canStock },
        { key: "stocktake", label: "الجرد", icon: <ClipboardCheck className="w-4 h-4" />, visible: canStocktake },
        { key: "transfers", label: "التحويلات", icon: <ArrowLeftRight className="w-4 h-4" />, visible: canTransfers },
      ],
    },
    {
      title: "العملاء والميداني",
      items: [
        { key: "customers", label: "العملاء", icon: <Users className="w-4 h-4" />, visible: canCustomers },
        { key: "b2b", label: "بوابة العملاء", icon: <Globe className="w-4 h-4" />, visible: canB2B },
        { key: "field", label: "الميداني والمندوبون", icon: <MapPin className="w-4 h-4" />, visible: canField },
      ],
    },
    {
      title: "المالية والإدارة",
      items: [
        { key: "finance", label: "المالية", icon: <Wallet className="w-4 h-4" />, visible: canFinance },
        { key: "cashbox", label: "الصناديق", icon: <Wallet className="w-4 h-4" />, visible: canCashbox },
        { key: "accounting", label: "المحاسبة", icon: <Calculator className="w-4 h-4" />, visible: canAccounting },
        { key: "system", label: "النظام والأمان", icon: <ShieldCheck className="w-4 h-4" />, visible: isAdmin },
      ],
    },
  ];

  async function logout() {
    await api("/api/v1/auth/logout", { method: "POST" }, { skipAuth: true }).catch(() => {});
    clearTokens();
    onLogout();
  }

  // ---- شعار/أيقونة الهوية — نسختان منفصلتان -------------------------------
  // شعار النظام (الهيدر) — من system_brand
  const SystemBrandAvatar = ({ size = "w-10 h-10", imgCls = "", iconCls = "w-5 h-5" }: { size?: string; imgCls?: string; iconCls?: string }) =>
    systemLogo ? (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={systemLogo}
        alt="شعار النظام"
        className={`${size} rounded-xl object-cover bg-white/10 ring-1 ring-white/20 shrink-0 ${imgCls}`}
      />
    ) : (
      <div className={`${size} rounded-xl bg-gradient-to-br from-primary to-amber-500 flex items-center justify-center shrink-0 shadow-md ring-1 ring-white/20`}>
        <Store className={`${iconCls} text-white`} />
      </div>
    );
  // شعار الشركة (القائمة الجانبية) — من Company.logoUrl
  const CompanyBrandAvatar = ({ size = "w-10 h-10", imgCls = "", iconCls = "w-5 h-5" }: { size?: string; imgCls?: string; iconCls?: string }) =>
    activeCompanyLogo ? (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={activeCompanyLogo}
        alt="شعار الشركة"
        className={`${size} rounded-xl object-cover bg-white/10 ring-1 ring-white/20 shrink-0 ${imgCls}`}
      />
    ) : (
      <div className={`${size} rounded-xl bg-gradient-to-br from-primary to-amber-500 flex items-center justify-center shrink-0 shadow-md ring-1 ring-white/20`}>
        <Building2 className={`${iconCls} text-white`} />
      </div>
    );

  const SidebarContent = ({ onClose, collapsed: isCollapsed = false }: { onClose?: () => void; collapsed?: boolean }) => (
    <div className="flex flex-col h-full">
      {/* brand — اسم الشركة فقط أعلى القائمة (+ الشعار إن وُجد) */}
      <div className={`h-16 shrink-0 flex items-center border-b border-white/10 bg-gradient-to-l from-white/5 to-transparent ${isCollapsed ? "justify-center px-1" : "gap-3 px-4"}`}>
        <button
          type="button"
          onClick={isCollapsed && !onClose ? toggleCollapsed : undefined}
          title={isCollapsed && !onClose ? "توسيع القائمة" : undefined}
          aria-label={isCollapsed && !onClose ? "توسيع القائمة" : undefined}
          className={isCollapsed && !onClose ? "cursor-pointer" : "cursor-default"}
        >
          <CompanyBrandAvatar />
        </button>
        {!isCollapsed && (
          <div className="min-w-0 flex-1">
            <div className="font-bold leading-tight truncate" title={activeCompanyName}>{activeCompanyName}</div>
          </div>
        )}
        {!isCollapsed && (
          <>
            {onClose ? (
              <button onClick={onClose} className="lg:hidden text-slate-300 hover:text-white" aria-label="إغلاق القائمة">
                <X className="w-5 h-5" />
              </button>
            ) : (
              <button
                onClick={toggleCollapsed}
                className="hidden lg:inline-flex text-slate-400 hover:text-white hover:bg-white/10 rounded-md p-1 transition-colors"
                aria-label="طي القائمة الجانبية"
                title="طي القائمة"
              >
                <ChevronsRight className="w-4 h-4" />
              </button>
            )}
          </>
        )}
      </div>
      {/* nav */}
      <nav className={`flex-1 overflow-y-auto scroll-thin py-3 space-y-4 ${isCollapsed ? "px-1.5" : "px-2"}`}>
        {navGroups.map((g) => {
          const items = g.items.filter((i) => i.visible);
          if (!items.length) return null;
          if (isCollapsed) {
            return (
              <div key={g.title} className="pt-2 border-t border-white/10 first:border-0 first:pt-0">
                <div className="space-y-1">
                  {items.map((i) => (
                    <button
                      key={i.key}
                      onClick={() => setTab(i.key)}
                      title={i.label}
                      aria-label={i.label}
                      className={`w-full flex items-center justify-center rounded-lg py-2.5 transition-colors ${
                        tab === i.key
                          ? "bg-primary text-white shadow"
                          : "text-slate-300 hover:bg-white/10 hover:text-white"
                      }`}
                    >
                      {i.icon}
                    </button>
                  ))}
                </div>
              </div>
            );
          }
          return (
            <div key={g.title}>
              <div className="px-3 pb-1 text-[10px] font-semibold uppercase tracking-wider text-slate-400">{g.title}</div>
              <div className="space-y-0.5">
                {items.map((i) => (
                  <button
                    key={i.key}
                    onClick={() => setTab(i.key)}
                    className={`w-full flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition-colors ${
                      tab === i.key
                        ? "bg-primary text-white font-semibold shadow"
                        : "text-slate-300 hover:bg-white/10 hover:text-white"
                    }`}
                  >
                    {i.icon}
                    <span className="truncate">{i.label}</span>
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </nav>
      {/* لا يوجد ذيل للمستخدم في القائمة الجانبية — بيانات المستخدم وحالة الاشتراك وزر الخروج في الهيدر فقط */}
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Top bar */}
      <header className="sticky top-0 z-40 shadow-lg">
        <div className="bg-gradient-to-l from-slate-900 via-slate-800 to-slate-900 text-slate-100">
          <div className="max-w-full px-4 h-16 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              {/* mobile menu trigger */}
              <Button
                size="sm"
                variant="ghost"
                className="lg:hidden text-slate-200 hover:bg-white/10 hover:text-white px-2"
                onClick={() => setDrawerOpen(true)}
                aria-label="فتح القائمة"
              >
                <Menu className="w-5 h-5" />
              </Button>
              {/* لا يوجد زر طي في الهيدر — الطي/التوسيع من داخل القائمة الجانبية */}
              <SystemBrandAvatar />
              <div className="min-w-0 hidden sm:block">
                <div className="font-bold leading-tight truncate">نظام <span className="text-amber-400">ميدان</span> لمبيعات والتوزيع</div>
                {/* Phase 45 — permanent scope header */}
                <div className="text-[11px] text-slate-300 flex items-center gap-1.5 flex-wrap mt-0.5">
                  <span className="inline-flex items-center gap-1 rounded-full bg-white/10 px-2 py-0.5"><Building2 className="w-3 h-3 text-amber-400" /> {activeCompanyName}</span>
                  <span className="inline-flex items-center gap-1 rounded-full bg-white/10 px-2 py-0.5"><MapPin className="w-3 h-3 text-amber-400" /> {activeBranchName ?? (scope?.branches.length ? `${scope.branches.length} فروع` : "كل الفروع")}</span>
                  <span className="hidden xl:inline-flex items-center rounded-full bg-white/5 px-2 py-0.5 text-slate-400">بيع · مخزون · مشتريات · مالية · تقارير</span>
                </div>
              </div>
              {/* Phase 15/16 — Branch & Company switchers */}
              {scope && scope.branches.length > 1 && (
                <BranchSwitcher
                  branches={scope.branches.filter((b) => b.company_id === session.user.company_id)}
                  activeBranchId={session.user.branch_id ?? scope.active_branch_id}
                  onSwitch={switchBranch}
                />
              )}
              {scope && scope.companies.length > 1 && (
                <CompanySwitcher
                  companies={scope.companies}
                  activeCompanyId={session.user.company_id}
                  onSwitch={switchCompany}
                />
              )}
              {/* شارة حالة الشركة النشطة — منتهية/معلّقة/قاربت الانتهاء ظاهرة دائمًا في الترويسة */}
              {scope?.subscription && (scope.subscription.status === "EXPIRED" || scope.subscription.status === "SUSPENDED") && (
                <span className="hidden md:inline-flex items-center gap-1 rounded-md bg-red-500/90 px-2 py-1 text-[10px] font-bold text-white" title={scope.subscription.status === "EXPIRED" ? "SUB_001: انتهت مدة اشتراك الشركة" : "SUB_002: الشركة معلّقة من مالك النظام"}>
                  <ShieldAlert className="w-3 h-3" />
                  {scope.subscription.status === "EXPIRED" ? "اشتراك منتهٍ" : "معلّقة"}
                </span>
              )}
              {scope?.subscription?.status === "EXPIRING_SOON" && (
                <span className="hidden md:inline-flex items-center gap-1 rounded-md bg-amber-500/90 px-2 py-1 text-[10px] font-bold text-white" title={`ينتهي اشتراك الشركة بعد ${scope.subscription.days_left} يوم`}>
                  <ShieldAlert className="w-3 h-3" />
                  ينتهي بعد {scope.subscription.days_left} يوم
                </span>
              )}
            </div>
            <div className="flex items-center gap-1.5">
              <GlobalSearch onOpenTab={setTab} />
              <AlertsBell onOpenTab={setTab} />
              <SupportBell session={session} />
              {/* شريحة المستخدم — سطح المكتب */}
              <div className="hidden md:flex items-center gap-2 rounded-full bg-white/10 ring-1 ring-white/10 pl-3 pr-1 py-1 max-w-[14rem]" title={session.user.full_name}>
                <span className="w-7 h-7 rounded-full bg-gradient-to-br from-primary to-amber-500 text-white text-[11px] font-bold flex items-center justify-center shrink-0" aria-hidden>
                  {session.user.full_name.trim().split(/\s+/).slice(0, 2).map((w) => w[0] ?? "").join("")}
                </span>
                <span className="text-xs font-semibold truncate">{session.user.full_name}</span>
              </div>
              <Button size="sm" variant="ghost" className="text-slate-200 hover:bg-white/10 hover:text-white px-2" onClick={logout} aria-label="تسجيل الخروج" title="تسجيل الخروج">
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
        <div className="h-[3px] bg-gradient-to-l from-primary/10 via-primary to-primary/10" aria-hidden />
      </header>

      {/* body: sidebar + content */}
      <div className="flex">
        {/* desktop sidebar (RTL → appears on the right) — قابلة للطي */}
        <aside
          className={`hidden lg:flex flex-col sticky top-16 h-[calc(100vh-4rem)] shrink-0 bg-navy text-navy-foreground border-l border-white/10 transition-all duration-200 ${collapsed ? "w-[4.25rem]" : "w-64"}`}
        >
          <SidebarContent collapsed={collapsed} />
        </aside>

        {/* mobile drawer */}
        {drawerOpen ? (
          <div className="fixed inset-0 z-50 lg:hidden">
            <div className="absolute inset-0 bg-black/50" onClick={() => setDrawerOpen(false)} />
            <div className="absolute inset-y-0 right-0 w-72 max-w-[85vw] bg-navy text-navy-foreground shadow-2xl">
              <SidebarContent onClose={() => setDrawerOpen(false)} />
            </div>
          </div>
        ) : null}

        <main className="flex-1 min-w-0 px-4 py-6">
          <div className="max-w-7xl mx-auto">
            {/* لافتة حالة اشتراك الشركة — تحذير قبل الانتهاء / حالة التعليق */}
            {scope?.subscription && scope.subscription.status !== "OPEN" && scope.subscription.status !== "ACTIVE" && (
              <div
                className={`mb-4 rounded-lg border px-4 py-2.5 text-sm flex items-center gap-2 ${
                  scope.subscription.status === "EXPIRING_SOON"
                    ? "border-amber-300 bg-amber-50 text-amber-900 dark:bg-amber-950/40 dark:text-amber-200"
                    : "border-red-300 bg-red-50 text-red-900 dark:bg-red-950/40 dark:text-red-200"
                }`}
              >
                <ShieldAlert className="w-4 h-4 shrink-0" />
                {scope.subscription.status === "EXPIRING_SOON" && (
                  <span>
                    تنبيه: تنتهي مدة اشتراك الشركة بعد <b dir="ltr">{scope.subscription.days_left}</b> يوم
                    {scope.subscription.ends_at ? ` — بتاريخ ${new Intl.DateTimeFormat("ar-IQ", { dateStyle: "medium" }).format(new Date(scope.subscription.ends_at))}` : ""}
                    . يُرجى مراجعة مالك النظام للتجديد.
                  </span>
                )}
                {scope.subscription.status === "SUSPENDED" && (
                  <span>الشركة معلّقة مؤقتًا من مالك النظام — استخدم النظام حتى نهاية الجلسة الحالية فقط.</span>
                )}
                {scope.subscription.status === "EXPIRED" && (
                  <span>انتهت مدة اشتراك الشركة — لن يتمكن المستخدمون من الدخول حتى التجديد (أنت تديرها بصلاحية المالك).</span>
                )}
              </div>
            )}
            <Tabs value={tab} onValueChange={setTab} dir="rtl">
              <TabsContent value="overview">
                <OverviewTab session={session} onGoto={setTab} />
              </TabsContent>

              {canSell && (
                <TabsContent value="new-invoice">
                  <NewInvoiceTab warehouses={warehouses} onPosted={() => { setTab("invoices"); }} />
                </TabsContent>
              )}

              {canOrders && (
                <TabsContent value="orders">
                  <OrdersTab
                    warehouses={warehouses}
                    canCreate={canOrdersCreate}
                    canEdit={canOrdersEdit}
                    canCancel={canOrdersCancel}
                    canConvert={canConvert}
                  />
                </TabsContent>
              )}

              {canInvoices && (
                <TabsContent value="invoices">
                  {/* key = الشركة النشطة → إعادة تحميل الفواتير (وترويسة الطباعة) عند تبديل الشركة */}
                  <InvoicesTab key={session.user.company_id} />
                </TabsContent>
              )}

              {canQuotations && (
                <TabsContent value="quotations">
                  <QuotationsTab canCreate={canQuotationsCreate} canConvert={canQuotationsConvert} />
                </TabsContent>
              )}

              {canDelivery && (
                <TabsContent value="delivery">
                  <DeliveryTab warehouses={warehouses} canCreate={canDeliveryCreate} canEdit={canDeliveryEdit} />
                </TabsContent>
              )}

              {canReturns && (
                <TabsContent value="returns">
                  <ReturnsTab warehouses={warehouses} canCreate={canReturnsCreate} />
                </TabsContent>
              )}

              {canProducts && (
                <TabsContent value="products">
                  <ProductsTab canEdit={canProductsEdit} canImport={has("products.products.import")} canDelete={has("products.products.delete")} />
                </TabsContent>
              )}

              {canCustomers && (
                <TabsContent value="customers">
                  <CustomersTab canEdit={canCustomersEdit} canImport={has("parties.customers.import")} />
                </TabsContent>
              )}

              {canStock && (
                <TabsContent value="inventory">
                  <InventoryTab warehouses={warehouses} canCreate={canStockCreate} />
                </TabsContent>
              )}

              {canStocktake && (
                <TabsContent value="stocktake">
                  <StocktakeTab warehouses={warehouses} canCreate={canStocktakeCreate} canPost={canStocktakePost} />
                </TabsContent>
              )}

              {canPurchases && (
                <TabsContent value="purchases">
                  <PurchasesTab warehouses={warehouses} canCreate={canPurchasesCreate} canDeleteInvoice={has("purchasing.purchase_invoices.delete")} canManageSuppliers={has("parties.suppliers.create")} />
                </TabsContent>
              )}

              {canTransfers && (
                <TabsContent value="transfers">
                  <TransfersTab warehouses={warehouses} canCreate={canTransfersCreate} />
                </TabsContent>
              )}

              {canFinance && (
                <TabsContent value="finance">
                  <FinanceTab canPay={canPay} canExpense={canExpense} />
                </TabsContent>
              )}

              {canCashbox && (
                <TabsContent value="cashbox">
                  <CashboxTab />
                </TabsContent>
              )}

              {canAccounting && (
                <TabsContent value="accounting">
                  <AccountingTab />
                </TabsContent>
              )}

              {canReports && (
                <TabsContent value="reports">
                  <ReportsTab canExport={canReportsExport} canBackup={has("system.settings.edit")} />
                </TabsContent>
              )}

              {canField && (
                <TabsContent value="field">
                  <FieldTab session={session} />
                </TabsContent>
              )}

              {canB2B && (
                <TabsContent value="b2b">
                  <B2BTab warehouses={warehouses} canApprove={has("b2b.orders.approve")} canReject={has("b2b.orders.reject")} />
                </TabsContent>
              )}

              {isAdmin && (
                <TabsContent value="system">
                  <Phase0Dashboard session={session} onLogout={onLogout} onSession={onSession} embed />
                </TabsContent>
              )}
            </Tabs>
          </div>
        </main>
      </div>

      <footer className="border-t mt-8">
        <div className="max-w-7xl mx-auto px-4 py-4 text-xs text-muted-foreground flex items-center justify-between flex-wrap gap-2">
          <span>نظام ميدان لمبيعات والتوزيع — بيع · مرتجعات · مشتريات · مخزون · ميداني · بوابة B2B · مزامنة · مالية · تقارير</span>
          <span dir="ltr" className="font-mono">Next.js 16 · Prisma · argon2id · jose JWT</span>
        </div>
      </footer>
    </div>
  );
}

// ---- Small inline dropdowns (no extra deps) ------------------------------
function BranchSwitcher({ branches, activeBranchId, onSwitch }: {
  branches: { id: number; code: string; name: string }[];
  activeBranchId: number | null;
  onSwitch: (id: number) => void;
}) {
  const [open, setOpen] = React.useState(false);
  const active = branches.find((b) => b.id === activeBranchId);
  return (
    <div className="relative hidden md:block">
      <button
        onClick={() => setOpen((o) => !o)}
        className="inline-flex items-center gap-1.5 rounded-md bg-white/10 hover:bg-white/20 px-2.5 py-1.5 text-xs font-semibold transition-colors"
        aria-label="مبدّل الفرع"
      >
        <GitBranch className="w-3.5 h-3.5" />
        {active ? active.name : "كل الفروع"}
        <ChevronsUpDown className="w-3 h-3 opacity-70" />
      </button>
      {open && (
        <div className="absolute top-full mt-1 end-0 w-48 rounded-lg bg-white text-foreground shadow-xl border z-50 overflow-hidden">
          <div className="px-3 py-2 text-[10px] font-bold text-muted-foreground border-b">الفرع الحالي</div>
          {branches.map((b) => (
            <button
              key={b.id}
              onClick={() => { setOpen(false); onSwitch(b.id); }}
              className={`w-full text-right px-3 py-2 text-sm hover:bg-muted flex items-center justify-between ${b.id === activeBranchId ? "font-bold text-primary" : ""}`}
            >
              <span>{b.name}</span>
              <span className="text-[10px] text-muted-foreground" dir="ltr">{b.code}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function CompanySwitcher({ companies, activeCompanyId, onSwitch }: {
  companies: ScopeCompany[];
  activeCompanyId: number;
  onSwitch: (id: number) => void;
}) {
  const [open, setOpen] = React.useState(false);
  const active = companies.find((c) => c.id === activeCompanyId);
  const activeSub = active?.subscription;
  const activeBad = activeSub && (activeSub.status === "EXPIRED" || activeSub.status === "SUSPENDED");
  return (
    <div className="relative hidden md:block">
      <button
        onClick={() => setOpen((o) => !o)}
        className={`inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-semibold transition-colors ${activeBad ? "bg-red-500/90 hover:bg-red-500 text-white" : "bg-white/10 hover:bg-white/20"}`}
        aria-label="مبدّل الشركة"
      >
        <Building2 className="w-3.5 h-3.5" />
        {active?.name ?? "الشركة"}
        {activeBad && <ShieldAlert className="w-3.5 h-3.5" />}
        <ChevronsUpDown className="w-3 h-3 opacity-70" />
      </button>
      {open && (
        <div className="absolute top-full mt-1 end-0 w-72 rounded-lg bg-white text-foreground shadow-xl border z-50 overflow-hidden">
          <div className="px-3 py-2 text-[10px] font-bold text-muted-foreground border-b">الشركات — الحالة: نشطة / منتهية / معلّقة</div>
          {companies.map((c) => (
            <button
              key={c.id}
              onClick={() => { setOpen(false); onSwitch(c.id); }}
              className={`w-full text-right px-3 py-2 text-sm hover:bg-muted flex items-center justify-between gap-2 ${c.id === activeCompanyId ? "font-bold text-primary" : ""}`}
            >
              <span className="min-w-0 flex-1 truncate">{c.name}</span>
              <CompanyStatusChip sub={c.subscription} />
              {c.code && <span className="text-[10px] text-muted-foreground" dir="ltr">{c.code}</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/** لحظة حالة الشركة في المبدّل: نشطة/مفتوحة/ينتهي قريبًا/منتهية/معلّقة */
function CompanyStatusChip({ sub }: { sub?: ScopeCompany["subscription"] }) {
  if (!sub) return null;
  switch (sub.status) {
    case "OPEN":
      return <span className="shrink-0 rounded-full bg-emerald-100 text-emerald-800 px-1.5 py-0.5 text-[9px] font-bold">مفتوحة</span>;
    case "ACTIVE":
      return <span className="shrink-0 rounded-full bg-emerald-100 text-emerald-800 px-1.5 py-0.5 text-[9px] font-bold">نشطة · {sub.days_left} يوم</span>;
    case "EXPIRING_SOON":
      return <span className="shrink-0 rounded-full bg-amber-100 text-amber-800 px-1.5 py-0.5 text-[9px] font-bold">ينتهي بعد {sub.days_left} يوم</span>;
    case "EXPIRED":
      return <span className="shrink-0 rounded-full bg-red-100 text-red-800 px-1.5 py-0.5 text-[9px] font-bold">منتهية</span>;
    case "SUSPENDED":
      return <span className="shrink-0 rounded-full bg-red-100 text-red-800 px-1.5 py-0.5 text-[9px] font-bold">معلّقة</span>;
    default:
      return null;
  }
}
