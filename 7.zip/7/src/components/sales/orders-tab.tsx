"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { Decimal, dec, moneyR, num as decNum, qtyR, sumOf } from "@/lib/decimal";
import { formatIQD } from "@/lib/utils";
import { CheckCircle2, ClipboardList, FileDown, Plus, RefreshCcw, Search, Trash2, XCircle } from "lucide-react";

interface ProductRow { id: number; code: string; name: string; unit: string; sale_price: number; stock_total: number }
interface CustomerRow { id: number; name: string }
interface WarehouseRow { id: number; code: string; name: string }

interface OrderRow {
  id: number;
  number: string;
  status: string;
  order_date: string;
  expected_date: string | null;
  grand_total: number;
  lines_count: number;
  customer: { id: number; code: string; name: string };
  warehouse: { id: number; code: string; name: string };
  created_by: { id: number; full_name: string; username: string };
  invoice: { id: number; number: string } | null;
}

interface Line {
  key: number;
  product_id: number | "";
  qty: number | "";
  unit_price: number | "";
  discount_pct: number | "";
  stock: number;
}

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";

const STATUS_META: Record<string, { label: string; variant: "success" | "navy" | "accent" | "secondary" | "destructive" }> = {
  DRAFT: { label: "مسودة", variant: "secondary" },
  CONFIRMED: { label: "مؤكد", variant: "accent" },
  INVOICING: { label: "قيد التحويل", variant: "navy" },
  INVOICED: { label: "محوّل لفاتورة", variant: "success" },
  CANCELLED: { label: "ملغى", variant: "destructive" },
};

export function OrdersTab({
  warehouses,
  canCreate,
  canEdit,
  canCancel,
  canConvert,
  onChanged,
}: {
  warehouses: WarehouseRow[];
  canCreate: boolean;
  canEdit: boolean;
  canCancel: boolean;
  canConvert: boolean;
  onChanged?: () => void;
}) {
  const [rows, setRows] = React.useState<OrderRow[] | null>(null);
  const [status, setStatus] = React.useState("");
  const [q, setQ] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [showForm, setShowForm] = React.useState(false);
  const [saving, setSaving] = React.useState(false);
  const [busyId, setBusyId] = React.useState<number | null>(null);

  const [products, setProducts] = React.useState<ProductRow[]>([]);
  const [customers, setCustomers] = React.useState<CustomerRow[]>([]);
  const [lines, setLines] = React.useState<Line[]>([{ key: 1, product_id: "", qty: "", unit_price: "", discount_pct: "", stock: 0 }]);
  const keyRef = React.useRef(2);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ per_page: "50" });
      if (status) params.set("status", status);
      if (q) params.set("q", q);
      const { body } = await api<OrderRow[]>(`/api/v1/sales/orders?${params}`);
      if (body.success && body.data) setRows(body.data);
      else toast.error(body.message ?? "تعذر تحميل الأوامر");
    } finally {
      setLoading(false);
    }
  }, [status, q]);

  React.useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  React.useEffect(() => {
    api<ProductRow[]>("/api/v1/products?per_page=100").then(({ body }) => {
      if (body.success && body.data) setProducts(body.data);
    });
    api<CustomerRow[]>("/api/v1/customers?per_page=100").then(({ body }) => {
      if (body.success && body.data) setCustomers(body.data);
    });
  }, []);

  function setLine(key: number, patch: Partial<Line>) {
    setLines((ls) =>
      ls.map((l) => {
        if (l.key !== key) return l;
        const next = { ...l, ...patch };
        if (patch.product_id !== undefined) {
          const p = products.find((x) => x.id === patch.product_id);
          next.stock = p?.stock_total ?? 0;
          if (p && (next.unit_price === "" || next.unit_price == null)) next.unit_price = p.sale_price;
        }
        return next;
      })
    );
  }

  function addLine() {
    setLines((ls) => [...ls, { key: keyRef.current++, product_id: "", qty: "", unit_price: "", discount_pct: "", stock: 0 }]);
  }
  function removeLine(key: number) {
    setLines((ls) => (ls.length === 1 ? ls : ls.filter((l) => l.key !== key)));
  }
  // Phase 3: Decimal
  const lineTotal = (l: Line) => {
    if (l.product_id === "" || !l.qty) return 0;
    return decNum(moneyR(dec(l.qty).mul(l.unit_price || 0).mul(new Decimal(1).minus(dec(l.discount_pct || 0).div(100)))));
  };
  const grandTotal = decNum(moneyR(sumOf(lines, (l) => lineTotal(l))));

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const validLines = lines
      .filter((l) => l.product_id !== "" && Number(l.qty) > 0)
      .map((l) => ({
        product_id: Number(l.product_id),
        qty: Number(l.qty),
        unit_price: l.unit_price === "" ? undefined : Number(l.unit_price),
        discount_pct: l.discount_pct === "" ? undefined : Number(l.discount_pct),
      }));
    if (!validLines.length) {
      toast.error("أضف بندًا واحدًا على الأقل بكمية صحيحة");
      return;
    }
    setSaving(true);
    try {
      const { body } = await api<{ number: string; grand_total: number }>("/api/v1/sales/orders", {
        method: "POST",
        body: JSON.stringify({
          customer_id: Number(fd.get("customer_id")),
          warehouse_id: Number(fd.get("warehouse_id")),
          notes: fd.get("notes") || undefined,
          expected_date: fd.get("expected_date") || undefined,
          lines: validLines,
        }),
      });
      if (body.success && body.data) {
        toast.success(`أُنشئ أمر البيع ${body.data.number} — ${formatIQD(body.data.grand_total)} (مسودة)`);
        setLines([{ key: keyRef.current++, product_id: "", qty: "", unit_price: "", discount_pct: "", stock: 0 }]);
        setShowForm(false);
        await load();
        onChanged?.();
      } else {
        toast.error(body.message ?? "فشل إنشاء الأمر", { description: body.errors?.map((x) => x.message).join(" · ") });
      }
    } finally {
      setSaving(false);
    }
  }

  async function act(id: number, action: "confirm" | "cancel" | "convert", convertType?: "CASH" | "CREDIT") {
    setBusyId(id);
    try {
      const payload = action === "convert" ? { type: convertType ?? "CASH" } : {};
      const { body } = await api<{ number: string; status?: string; invoice_number?: string }>(
        `/api/v1/sales/orders/${id}/${action}`,
        { method: "POST", body: JSON.stringify(payload) }
      );
      if (body.success && body.data) {
        if (action === "convert") {
          toast.success(`تحوّل ${body.data.number} إلى الفاتورة ${body.data.invoice_number} ✓`);
        } else {
          toast.success(`${body.data.number}: ${body.data.status === "CONFIRMED" ? "مؤكد ✓" : "ملغى"}`);
        }
        await load();
        onChanged?.();
      } else {
        toast.error(body.message ?? "فشلت العملية");
      }
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <CardTitle className="flex items-center gap-2"><ClipboardList className="w-5 h-5 text-primary" /> أوامر البيع</CardTitle>
              <CardDescription>
                المسار: مسودة → مؤكد → فاتورة (التحويل يستخدم محرك الترحيل الذري) — الأوامر لا تلمس المخزون قبل التحويل
              </CardDescription>
            </div>
            <div className="flex gap-2 flex-wrap">
              <div className="relative">
                <Search className="w-4 h-4 absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input className="pr-8 w-40 h-9" placeholder="رقم أو عميل..." value={q} onChange={(e) => setQ(e.target.value)} />
              </div>
              <select className="h-9 rounded-md border bg-background px-3 text-sm" value={status} onChange={(e) => setStatus(e.target.value)}>
                <option value="">كل الحالات</option>
                <option value="DRAFT">مسودة</option>
                <option value="CONFIRMED">مؤكد</option>
                <option value="INVOICED">محوّل</option>
                <option value="CANCELLED">ملغى</option>
              </select>
              <Button size="sm" variant="outline" onClick={load} disabled={loading}>
                <RefreshCcw className={"w-4 h-4" + (loading ? " animate-spin" : "")} /> تحديث
              </Button>
              {canCreate && (
                <Button size="sm" onClick={() => setShowForm((v) => !v)}>
                  <Plus className="w-4 h-4" /> أمر جديد
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {showForm && canCreate && (
            <form onSubmit={submit} className="rounded-lg border p-4 mb-4 bg-muted/30 space-y-3">
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <label className="text-xs font-medium space-y-1">العميل *
                  <select name="customer_id" required className={inputCls} defaultValue="">
                    <option value="" disabled>— اختر العميل —</option>
                    {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </label>
                <label className="text-xs font-medium space-y-1">المستودع *
                  <select name="warehouse_id" required className={inputCls} defaultValue="">
                    <option value="" disabled>— اختر —</option>
                    {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
                  </select>
                </label>
                <label className="text-xs font-medium space-y-1">تاريخ التوريد المتوقع
                  <input name="expected_date" type="date" className={inputCls} dir="ltr" />
                </label>
                <label className="text-xs font-medium space-y-1">ملاحظات
                  <input name="notes" className={inputCls} placeholder="اختياري" />
                </label>
              </div>

              <div className="rounded-md border bg-background p-3 space-y-2">
                <div className="text-xs font-semibold text-muted-foreground">البنود</div>
                {lines.map((l) => (
                  <div key={l.key} className="grid gap-2 grid-cols-[1fr_90px_110px_80px_40px] items-center">
                    <select className={inputCls} value={l.product_id} onChange={(e) => setLine(l.key, { product_id: e.target.value ? Number(e.target.value) : "" })}>
                      <option value="" disabled>— اختر المنتج —</option>
                      {products.map((p) => (
                        <option key={p.id} value={p.id}>{p.name} — متاح {p.stock_total} {p.unit}</option>
                      ))}
                    </select>
                    <input className={inputCls} type="number" min="0" step="any" placeholder="الكمية" value={l.qty}
                      onChange={(e) => setLine(l.key, { qty: e.target.value === "" ? "" : Number(e.target.value) })} />
                    <input className={inputCls} type="number" min="0" step="any" placeholder="السعر" value={l.unit_price}
                      onChange={(e) => setLine(l.key, { unit_price: e.target.value === "" ? "" : Number(e.target.value) })} />
                    <input className={inputCls} type="number" min="0" max="100" step="any" placeholder="خصم%" value={l.discount_pct}
                      onChange={(e) => setLine(l.key, { discount_pct: e.target.value === "" ? "" : Number(e.target.value) })} />
                    <Button type="button" variant="ghost" size="sm" className="text-destructive" onClick={() => removeLine(l.key)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
                <div className="flex items-center justify-between">
                  <Button type="button" size="sm" variant="outline" onClick={addLine}><Plus className="w-4 h-4" /> بند</Button>
                  <div className="text-sm font-bold">الإجمالي: <span dir="ltr">{formatIQD(grandTotal)}</span></div>
                </div>
              </div>

              <Button type="submit" disabled={saving}>{saving ? "جارٍ الحفظ..." : "حفظ الأمر (مسودة)"}</Button>
            </form>
          )}

          {rows === null ? (
            <div className="py-10 text-center text-muted-foreground">جارٍ التحميل...</div>
          ) : rows.length === 0 ? (
            <div className="py-10 text-center text-muted-foreground">لا أوامر مطابقة</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الرقم</TableHead>
                  <TableHead>العميل</TableHead>
                  <TableHead>المستودع</TableHead>
                  <TableHead className="text-left">البنود</TableHead>
                  <TableHead className="text-left">الإجمالي</TableHead>
                  <TableHead>الحالة</TableHead>
                  <TableHead>إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((o) => {
                  const meta = STATUS_META[o.status] ?? { label: o.status, variant: "secondary" as const };
                  return (
                    <TableRow key={o.id}>
                      <TableCell dir="ltr" className="font-mono text-xs font-semibold">{o.number}</TableCell>
                      <TableCell className="text-sm">
                        <div className="font-medium">{o.customer.name}</div>
                        <div className="text-[11px] text-muted-foreground">بواسطة {o.created_by.full_name}</div>
                      </TableCell>
                      <TableCell className="text-xs">{o.warehouse.name}</TableCell>
                      <TableCell className="text-left" dir="ltr">{o.lines_count}</TableCell>
                      <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(o.grand_total)}</TableCell>
                      <TableCell>
                        <Badge variant={meta.variant} className="text-[10px]">{meta.label}</Badge>
                        {o.invoice && <div className="text-[10px] text-muted-foreground mt-1" dir="ltr">{o.invoice.number}</div>}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {canEdit && o.status === "DRAFT" && (
                            <Button size="sm" variant="outline" className="h-7 px-2 text-xs" disabled={busyId === o.id}
                              onClick={() => act(o.id, "confirm")}>
                              <CheckCircle2 className="w-3.5 h-3.5" /> تأكيد
                            </Button>
                          )}
                          {canConvert && o.status === "CONFIRMED" && (
                            <>
                              <Button size="sm" variant="outline" className="h-7 px-2 text-xs" disabled={busyId === o.id}
                                onClick={() => act(o.id, "convert", "CASH")}>
                                <FileDown className="w-3.5 h-3.5" /> فاتورة نقدية
                              </Button>
                              <Button size="sm" variant="outline" className="h-7 px-2 text-xs" disabled={busyId === o.id}
                                onClick={() => act(o.id, "convert", "CREDIT")}>
                                <FileDown className="w-3.5 h-3.5" /> آجل
                              </Button>
                            </>
                          )}
                          {canCancel && (o.status === "DRAFT" || o.status === "CONFIRMED") && (
                            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-destructive" disabled={busyId === o.id}
                              onClick={() => act(o.id, "cancel")}>
                              <XCircle className="w-3.5 h-3.5" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
