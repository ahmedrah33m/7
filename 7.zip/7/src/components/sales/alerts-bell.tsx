"use client";

import * as React from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { api } from "@/lib/client-api";
import {
  AlertTriangle, Bell, CalendarCheck, CreditCard, Globe,
  Loader2, PackageSearch, TrendingDown, Truck, Wallet,
} from "lucide-react";

interface AlertItem {
  type: string;
  severity: "HIGH" | "MEDIUM" | "LOW";
  title: string;
  message: string;
  count: number;
  tab: string;
}

const SEVERITY_META: Record<string, { cls: string; label: string }> = {
  HIGH: { cls: "bg-red-500", label: "عالي" },
  MEDIUM: { cls: "bg-amber-500", label: "متوسط" },
  LOW: { cls: "bg-sky-500", label: "منخفض" },
};

function AlertIcon({ type }: { type: string }) {
  const cls = "w-4 h-4 shrink-0";
  switch (type) {
    case "LOW_STOCK": return <PackageSearch className={cls} />;
    case "CREDIT_OVER": return <CreditCard className={cls} />;
    case "CREDIT_NEAR": return <CreditCard className={cls} />;
    case "OVERDUE": return <TrendingDown className={cls} />;
    case "PENDING_B2B": return <Globe className={cls} />;
    case "COMM_PENDING": return <Wallet className={cls} />;
    case "VISITS_TODAY": return <CalendarCheck className={cls} />;
    case "DELIVERY_SHORTAGE": return <Truck className={cls} />;
    default: return <AlertTriangle className={cls} />;
  }
}

export function AlertsBell({ onOpenTab }: { onOpenTab: (tab: string) => void }) {
  const [open, setOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [alerts, setAlerts] = React.useState<AlertItem[] | null>(null);
  const boxRef = React.useRef<HTMLDivElement>(null);

  const load = React.useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const { body } = await api<{ alerts: AlertItem[] }>("/api/v1/alerts");
      if (body.success && body.data) setAlerts(body.data.alerts);
      else if (!silent) toast.error(body.message ?? "تعذر تحميل التنبيهات");
    } finally {
      if (!silent) setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
    const t = setInterval(() => load(true), 60_000); // silent refresh each minute
    return () => clearInterval(t);
  }, [load]);

  // close on outside click
  React.useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const highCount = (alerts ?? []).filter((a) => a.severity === "HIGH").length;
  const totalCount = (alerts ?? []).length;

  return (
    <div className="relative" ref={boxRef}>
      <Button
        size="sm"
        variant="ghost"
        className="relative text-slate-200 hover:bg-white/10 hover:text-white"
        onClick={() => { setOpen((v) => !v); if (!open) load(); }}
        aria-label="التنبيهات"
      >
        <Bell className="w-4 h-4" />
        {totalCount > 0 && (
          <span className={"absolute -top-0.5 -left-0.5 min-w-[16px] h-4 px-1 rounded-full text-[10px] font-bold flex items-center justify-center text-white " + (highCount > 0 ? "bg-red-500" : "bg-amber-500")}>
            {totalCount}
          </span>
        )}
      </Button>

      {open && (
        <div className="absolute left-0 top-11 w-[min(92vw,26rem)] rounded-lg border bg-popover text-popover-foreground shadow-xl z-50 overflow-hidden">
          <div className="flex items-center justify-between px-3 py-2 border-b bg-muted/40">
            <div className="text-sm font-bold flex items-center gap-2">
              <Bell className="w-4 h-4 text-primary" /> مركز التنبيهات
              {highCount > 0 && <Badge className="bg-red-500 text-white text-[10px]">{highCount} عالي</Badge>}
            </div>
            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => load()}>
              {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : "تحديث"}
            </Button>
          </div>
          <div className="max-h-[60vh] overflow-y-auto divide-y">
            {alerts === null ? (
              <div className="py-8 text-center text-sm text-muted-foreground flex items-center justify-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" /> جارٍ الفحص...
              </div>
            ) : alerts.length === 0 ? (
              <div className="py-8 text-center text-sm text-muted-foreground">
                لا تنبيهات — كل شيء تحت السيطرة ✓
              </div>
            ) : (
              alerts.map((a, i) => {
                const sev = SEVERITY_META[a.severity] ?? SEVERITY_META.LOW;
                return (
                  <button
                    key={`${a.type}-${i}`}
                    className="w-full text-right px-3 py-2.5 hover:bg-muted/50 transition-colors flex gap-2.5 items-start"
                    onClick={() => { setOpen(false); onOpenTab(a.tab); }}
                  >
                    <span className={"mt-1 w-2 h-2 rounded-full shrink-0 " + sev.cls} />
                    <span className="flex-1 min-w-0">
                      <span className="flex items-center gap-1.5 text-sm font-semibold">
                        <AlertIcon type={a.type} />
                        {a.title}
                        <span className="text-[10px] font-normal text-muted-foreground">({sev.label})</span>
                      </span>
                      <span className="block text-xs text-muted-foreground leading-relaxed mt-0.5">{a.message}</span>
                    </span>
                  </button>
                );
              })
            )}
          </div>
          <div className="px-3 py-1.5 border-t bg-muted/30 text-[10px] text-muted-foreground">
            يُحدَّث تلقائيًا كل دقيقة · حسب صلاحياتك — اضغط أي تنبيه للانتقال لتبويبه
          </div>
        </div>
      )}
    </div>
  );
}
