"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { formatDateTime, formatIQD } from "@/lib/utils";
import { KpiCard } from "@/components/sales/kpi-card";
import { ArrowDownToLine, ArrowUpFromLine, Boxes, Coins, PackageX, Layers, TrendingUp, AlertTriangle, PackageOpen, Hourglass } from "lucide-react";

interface BalanceRow {
  product_id: number;
  product_code: string;
  product_name: string;
  unit: string;
  // v16 — معلومات التعبئة لعرض الكراتين
  pack_unit?: string | null;
  pack_qty?: number | null;
  min_stock: number;
  sale_price: number;
  warehouse: { id: number; code: string; name: string };
  qty: number;
  low: boolean;
}

interface MovementRow {
  id: number;
  direction: "IN" | "OUT";
  qty: number;
  ref_type: string;
  balance_after: number;
  note: string | null;
  product: { code: string; name: string; unit: string };
  warehouse: { name: string };
  created_at: string;
}

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";

export function InventoryTab({
  warehouses,
  canCreate,
  onDone,
}: {
  warehouses: { id: number; code: string; name: string }[];
  canCreate: boolean;
  onDone?: () => void;
}) {
  const [balances, setBalances] = React.useState<BalanceRow[] | null>(null);
  const [movements, setMovements] = React.useState<MovementRow[] | null>(null);
  const [whId, setWhId] = React.useState<number | "all">(warehouses[0]?.id ?? "all");
  const [saving, setSaving] = React.useState(false);
  const [summary, setSummary] = React.useState<{ total_qty: number; cost_value: number; sale_value: number; expected_profit: number; cogs: number; low_count: number; out_count: number; dead_count: number } | null>(null);

  React.useEffect(() => {
    api<{ rows: unknown[]; summary: { total_qty: number; cost_value: number; sale_value: number; expected_profit: number; cogs: number; low_count: number; out_count: number; dead_count: number } }>("/api/v1/reports/valuation").then(({ body }) => {
      if (body.success && body.data) setSummary(body.data.summary);
    });
  }, []);

  const load = React.useCallback(async () => {
    const qs = whId === "all" ? "" : `&warehouse_id=${whId}`;
    const [b, m] = await Promise.all([
      api<BalanceRow[]>(`/api/v1/inventory/balances?per_page=200${qs}`),
      api<MovementRow[]>("/api/v1/inventory/movements?per_page=15"),
    ]);
    if (b.body.success && b.body.data) setBalances(b.body.data);
    if (m.body.success && m.body.data) setMovements(m.body.data);
  }, [whId]);

  React.useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [whId]);

  const [products, setProducts] = React.useState<{ id: number; name: string; unit: string }[]>([]);
  React.useEffect(() => {
    api<{ id: number; name: string; unit: string }[]>("/api/v1/products?per_page=100").then(({ body }) => {
      if (body.success && body.data) setProducts(body.data);
    });
  }, []);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSaving(true);
    const fd = new FormData(e.currentTarget);
    try {
      const { body } = await api("/api/v1/inventory/movements", {
        method: "POST",
        body: JSON.stringify({
          warehouse_id: Number(fd.get("warehouse_id")),
          product_id: Number(fd.get("product_id")),
          direction: fd.get("direction"),
          qty: Number(fd.get("qty")),
          note: fd.get("note") || undefined,
        }),
      });
      if (body.success) {
        const d = body.data as { direction: string; balance_after: number };
        toast.success(`سُجلت الحركة ✓ — الرصيد الجديد: ${d.balance_after}`);
        (e.target as HTMLFormElement).reset();
        await load();
        onDone?.();
      } else toast.error(body.message ?? "فشل تسجيل الحركة");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4">
      {/* §66.1 — Inventory Overview: 8 costing & stock KPI cards */}
      {summary && (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <KpiCard tone="blue" icon={<Boxes className="w-5 h-5" />} label="إجمالي كمية المخزون" value={String(summary.total_qty)} sub="كل المستودعات" />
          <KpiCard tone="cyan" icon={<Coins className="w-5 h-5" />} label="قيمة المخزون بالتكلفة" value={formatIQD(summary.cost_value)} sub="سعر التكلفة" />
          <KpiCard tone="indigo" icon={<Layers className="w-5 h-5" />} label="القيمة البيعية المتوقعة" value={formatIQD(summary.sale_value)} sub="سعر البيع" />
          <KpiCard tone="emerald" icon={<TrendingUp className="w-5 h-5" />} label="الربح الإجمالي المتوقع" value={formatIQD(summary.expected_profit)} sub="بيعية − تكلفة" />
          <KpiCard tone="violet" icon={<Coins className="w-5 h-5" />} label="تكلفة البضاعة المباعة" value={formatIQD(summary.cogs)} sub="COGS — المبيعات" />
          <KpiCard tone="amber" icon={<AlertTriangle className="w-5 h-5" />} label="مخزون منخفض الكمية" value={String(summary.low_count)} sub="تحت حد إعادة الطلب" />
          <KpiCard tone="rose" icon={<PackageOpen className="w-5 h-5" />} label="منتجات نافدة" value={String(summary.out_count)} sub="بدون رصيد" />
          <KpiCard tone="slate" icon={<Hourglass className="w-5 h-5" />} label="مخزون راكد" value={String(summary.dead_count)} sub="بلا حركة 90 يومًا" />
        </div>
      )}

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <CardTitle className="flex items-center gap-2"><Boxes className="w-5 h-5 text-primary" /> أرصدة المخزون</CardTitle>
              <CardDescription>حسب المستودع — نطاقك فقط (SCOPE_002 يحمي باقي المستودعات)</CardDescription>
            </div>
            {warehouses.length > 1 && (
              <select className={inputCls + " w-56"} value={String(whId)} onChange={(e) => setWhId(e.target.value === "all" ? "all" : Number(e.target.value))}>
                <option value="all">كل مستودعاتي</option>
                {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
              </select>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {balances === null ? (
            <div className="py-10 text-center text-muted-foreground">جارٍ التحميل...</div>
          ) : balances.length === 0 ? (
            <div className="py-10 text-center text-muted-foreground">لا أرصدة — سجل إدخال مخزون أدناه</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>المنتج</TableHead>
                  <TableHead>المستودع</TableHead>
                  <TableHead className="text-left">الرصيد</TableHead>
                  <TableHead className="text-left">قيمة البيع التقديرية</TableHead>
                  <TableHead>الحالة</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {balances.map((b) => {
                  // v16 — عرض الكراتين + الحبات إن وُجدت تعبئة
                  const hasPack = !!b.pack_unit && !!b.pack_qty && Number(b.pack_qty) > 1;
                  const cartons = hasPack ? Math.floor(b.qty / Number(b.pack_qty)) : 0;
                  const pieces = hasPack
                    ? Math.round((b.qty - cartons * Number(b.pack_qty)) * 1e6) / 1e6
                    : b.qty;
                  return (
                  <TableRow key={`${b.warehouse.id}-${b.product_id}`}>
                    <TableCell>
                      <div className="font-medium">{b.product_name}</div>
                      <div dir="ltr" className="font-mono text-[11px] text-muted-foreground text-left">{b.product_code}</div>
                    </TableCell>
                    <TableCell className="text-sm">{b.warehouse.name}</TableCell>
                    <TableCell className="text-left font-semibold">
                      {/* v16 — عرض الكراتين + الحبات */}
                      {hasPack ? (
                        <div className="flex flex-col gap-0.5">
                          <div dir="ltr" className="font-medium">
                            {cartons > 0 && <span className="text-primary">{cartons} {b.pack_unit}</span>}
                            {cartons > 0 && pieces > 0 && <span className="text-muted-foreground mx-1">+</span>}
                            {pieces > 0 && <span>{pieces} {b.unit}</span>}
                            {cartons === 0 && pieces === 0 && <span className="text-muted-foreground">0</span>}
                          </div>
                          <div className="text-[10px] text-muted-foreground" dir="ltr">
                            الإجمالي: {b.qty} {b.unit}
                          </div>
                        </div>
                      ) : (
                        <span dir="ltr">{b.qty} {b.unit}</span>
                      )}
                    </TableCell>
                    <TableCell className="text-left text-sm" dir="ltr">{formatIQD(b.qty * b.sale_price)}</TableCell>
                    <TableCell>
                      {b.qty <= 0
                        ? <Badge variant="destructive" className="text-[10px]">منتهي</Badge>
                        : b.low ? <Badge variant="secondary" className="text-[10px]">تحت الحد ({b.min_stock})</Badge>
                        : <Badge variant="success" className="text-[10px]">متوفر</Badge>}
                    </TableCell>
                  </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {canCreate && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <ArrowDownToLine className="w-4 h-4 text-primary" /> إدخال / تسوية مخزون
            </CardTitle>
            <CardDescription>IN = إدخال أو رصيد افتتاحي · OUT = تسوية بالنقص — كل حركة تُسجل في دفتر غير قابل للتعديل</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={submit} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              <label className="text-xs font-medium space-y-1">المستودع *
                <select name="warehouse_id" required className={inputCls} defaultValue={warehouses[0]?.id}>
                  {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
                </select>
              </label>
              <label className="text-xs font-medium space-y-1">المنتج *
                <select name="product_id" required className={inputCls}>
                  {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </label>
              <label className="text-xs font-medium space-y-1">نوع الحركة *
                <select name="direction" className={inputCls} defaultValue="IN">
                  <option value="IN">إدخال (IN)</option>
                  <option value="OUT">إخراج/تسوية (OUT)</option>
                </select>
              </label>
              <label className="text-xs font-medium space-y-1">الكمية *
                <input name="qty" type="number" min="0.001" step="any" required className={inputCls} dir="ltr" />
              </label>
              <label className="text-xs font-medium space-y-1">ملاحظة
                <input name="note" className={inputCls} placeholder="اختياري" />
              </label>
              <div className="lg:col-span-5">
                <Button type="submit" disabled={saving}>{saving ? "جارٍ التسجيل..." : "تسجيل الحركة"}</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2"><ArrowUpFromLine className="w-4 h-4 text-primary" /> آخر الحركات (دفتر لاتحققي)</CardTitle>
        </CardHeader>
        <CardContent>
          {movements === null ? (
            <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div>
          ) : movements.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">لا حركات بعد</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الوقت</TableHead>
                  <TableHead>المنتج</TableHead>
                  <TableHead>المستودع</TableHead>
                  <TableHead>النوع</TableHead>
                  <TableHead className="text-left">الكمية</TableHead>
                  <TableHead className="text-left">الرصيد بعدها</TableHead>
                  <TableHead>المرجع</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {movements.map((m) => (
                  <TableRow key={m.id}>
                    <TableCell className="text-xs text-muted-foreground">{formatDateTime(m.created_at)}</TableCell>
                    <TableCell className="text-sm">{m.product.name}</TableCell>
                    <TableCell className="text-xs">{m.warehouse.name}</TableCell>
                    <TableCell>
                      <Badge variant={m.direction === "IN" ? "success" : "destructive"} className="text-[10px]">
                        {m.direction === "IN" ? "إدخال" : "إخراج"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-left font-medium" dir="ltr">{m.qty}</TableCell>
                    <TableCell className="text-left text-sm" dir="ltr">{m.balance_after}</TableCell>
                    <TableCell className="font-mono text-[10px] text-muted-foreground">{m.ref_type}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
