"use client";

import * as React from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { formatIQD } from "@/lib/utils";
import { Zap, Loader2 } from "lucide-react";

interface Cashbox { id: number; code: string; name: string }
interface OutstandingInvoice {
  id: number; number: string; invoice_date: string;
  grand_total: number; paid_amount: number; due_amount: number; age_days: number;
}
interface CustomerSummary { total_paid: number; payment_count: number; is_advance: boolean }

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";
const n = (v: number) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(v);

export function QuickReceiptForm({
  presetCustomerId,
  presetInvoiceId,
  onClose,
  onDone,
}: {
  presetCustomerId?: number | null;
  presetInvoiceId?: number | null;
  onClose: () => void;
  onDone?: () => void;
}) {
  const [customerId, setCustomerId] = React.useState<number | "">(presetCustomerId ?? "");
  const [cashboxes, setCashboxes] = React.useState<Cashbox[]>([]);
  const [cashboxId, setCashboxId] = React.useState<number | "">("");
  const [amount, setAmount] = React.useState<number | "">("");
  const [outstanding, setOutstanding] = React.useState<OutstandingInvoice[]>([]);
  const [allocations, setAllocations] = React.useState<Record<number, number>>({});
  const [saving, setSaving] = React.useState(false);
  const [summary, setSummary] = React.useState<CustomerSummary | null>(null);

  React.useEffect(() => {
    (async () => {
      const { body } = await api<Cashbox[]>("/api/v1/finance/cashboxes");
      if (body.success && body.data) {
        setCashboxes(body.data);
        if (body.data.length === 1) setCashboxId(body.data[0].id);
      }
    })();
  }, []);

  // Load outstanding invoices whenever the customer changes
  React.useEffect(() => {
    if (!customerId) { setOutstanding([]); setAllocations({}); setSummary(null); return; }
    (async () => {
      const [o, s] = await Promise.all([
        api<{ rows: OutstandingInvoice[]; total_due: number }>(`/api/v1/finance/customers/${customerId}/outstanding`),
        api<CustomerSummary>(`/api/v1/finance/customers/${customerId}/payment-summary`).catch(() => null),
      ]);
      if (o.body.success && o.body.data) {
        const rows = o.body.data.rows;
        setOutstanding(rows);
        // Pre-fill the preset invoice allocation
        const init: Record<number, number> = {};
        if (presetInvoiceId) {
          const inv = rows.find((r) => r.id === presetInvoiceId);
          if (inv) init[presetInvoiceId] = inv.due_amount;
        }
        setAllocations(init);
        if (presetInvoiceId) {
          const inv = rows.find((r) => r.id === presetInvoiceId);
          if (inv) setAmount(inv.due_amount);
        }
      }
      if (s?.body?.success && s.body.data) setSummary(s.body.data);
    })();
  }, [customerId, presetInvoiceId]);

  // FIFO auto-allocate
  function fifoAllocate(total: number) {
    if (!total) { setAllocations({}); return; }
    let remaining = total;
    const out: Record<number, number> = {};
    for (const inv of outstanding) {
      if (remaining <= 0) break;
      const alloc = Math.min(remaining, inv.due_amount);
      if (alloc > 0) {
        out[inv.id] = Number(alloc.toFixed(2));
        remaining -= alloc;
      }
    }
    setAllocations(out);
  }

  const allocatedTotal = Object.values(allocations).reduce((s, x) => s + x, 0);
  const advance = Math.max(0, (typeof amount === "number" ? amount : 0) - allocatedTotal);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!customerId) return toast.error("اختر العميل");
    if (!cashboxId) return toast.error("اختر الصندوق");
    const amt = typeof amount === "number" ? amount : 0;
    if (amt <= 0) return toast.error("أدخل مبلغًا صحيحًا");

    setSaving(true);
    try {
      const allocationsArr = Object.entries(allocations)
        .filter(([, v]) => v > 0)
        .map(([invId, amt2]) => ({ invoiceId: Number(invId), invoiceType: "SALES" as const, amount: amt2 }));
      const payload = allocationsArr.length
        ? {
            customer_id: customerId, cashbox_id: cashboxId, branch_id: 1,
            amount: amt, allocations: allocationsArr,
            idempotency_key: `qr-${customerId}-${Date.now()}`,
          }
        : {
            customer_id: customerId, cashbox_id: cashboxId, branch_id: 1,
            amount: amt,
            idempotency_key: `qr-${customerId}-${Date.now()}`,
          };
      const { body } = await api("/api/v1/finance/quick-receipt", {
        method: "POST",
        body: JSON.stringify(payload),
      });
      if (body.success) {
        const d = body.data as { number: string; advance_amount?: number };
        toast.success(`تم تحصيل ${d.number} ✓${d.advance_amount ? ` — دفعة مقدمة ${formatIQD(d.advance_amount)}` : ""}`);
        onDone?.();
        onClose();
      } else toast.error(body.message ?? "فشل التحصيل");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-[80] bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
      <Card className="w-[min(96vw,1100px)] max-h-[90vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
        <CardHeader className="pb-3 border-b">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-base"><Zap className="w-4 h-4 text-amber-500" /> تحصيل سريع من عميل</CardTitle>
              <CardDescription>FIFO يخصّص المبلغ على أقدم الفواتير غير المسددة؛ الباقي = دفعة مقدمة على الحساب</CardDescription>
            </div>
            <Button size="sm" variant="ghost" onClick={onClose}>✕</Button>
          </div>
        </CardHeader>
        <CardContent className="overflow-y-auto scroll-thin">
          <form onSubmit={submit} className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-3">
              <label className="text-xs space-y-1">رقم العميل
                <Input type="number" value={customerId} onChange={(e) => setCustomerId(e.target.value === "" ? "" : Number(e.target.value))} required />
              </label>
              <label className="text-xs space-y-1">الصندوق
                <select value={cashboxId} onChange={(e) => setCashboxId(e.target.value === "" ? "" : Number(e.target.value))} required className={inputCls}>
                  <option value="">— اختر —</option>
                  {cashboxes.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              </label>
              <label className="text-xs space-y-1">المبلغ المُحصَّل (د.ع)
                <Input type="number" step="0.0001" value={amount} onChange={(e) => setAmount(e.target.value === "" ? "" : Number(e.target.value))} required />
              </label>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button type="button" size="sm" variant="outline" onClick={() => fifoAllocate(typeof amount === "number" ? amount : 0)}>FIFO تلقائي</Button>
              <Button type="button" size="sm" variant="ghost" onClick={() => setAllocations({})}>مسح التخصيص</Button>
              {summary && (
                <span className="text-xs text-muted-foreground self-center">
                  إجمالي مدفوعات العميل سابقًا: {formatIQD(summary.total_paid)} ({summary.payment_count} دفعة){summary.is_advance ? " · لديه دفعة مقدمة" : ""}
                </span>
              )}
            </div>

            {outstanding.length > 0 && (
              <div className="rounded-lg border">
                <Table>
                  <TableHeader><TableRow>
                    <TableHead>الفاتورة</TableHead><TableHead>التاريخ</TableHead>
                    <TableHead className="text-left">الإجمالي</TableHead><TableHead className="text-left">المدفوع</TableHead>
                    <TableHead className="text-left">المتبقي</TableHead><TableHead>العمر</TableHead>
                    <TableHead className="text-left">تخصيص</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {outstanding.map((inv) => (
                      <TableRow key={inv.id}>
                        <TableCell dir="ltr" className="font-mono text-xs text-right">{inv.number}</TableCell>
                        <TableCell className="text-xs">{inv.invoice_date}</TableCell>
                        <TableCell className="text-left" dir="ltr">{n(inv.grand_total)}</TableCell>
                        <TableCell className="text-left" dir="ltr">{n(inv.paid_amount)}</TableCell>
                        <TableCell className="text-left font-semibold text-amber-600" dir="ltr">{n(inv.due_amount)}</TableCell>
                        <TableCell className="text-xs">{inv.age_days} يوم</TableCell>
                        <TableCell className="text-left">
                          <Input
                            type="number"
                            step="0.0001"
                            value={allocations[inv.id] ?? ""}
                            max={inv.due_amount}
                            onChange={(e) => {
                              const v = e.target.value === "" ? 0 : Math.min(Number(e.target.value), inv.due_amount);
                              setAllocations((prev) => ({ ...prev, [inv.id]: v }));
                            }}
                            className="h-8 w-28"
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}

            <div className="flex items-center justify-between rounded-lg bg-muted/30 px-3 py-2 text-sm">
              <span>المُخصَّص: <span dir="ltr" className="font-semibold">{formatIQD(allocatedTotal)}</span></span>
              <span>المتبقي كدفعة مقدمة: <span dir="ltr" className="font-bold text-emerald-600">{formatIQD(advance)}</span></span>
            </div>

            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={onClose}>إلغاء</Button>
              <Button type="submit" disabled={saving}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />} تسجيل التحصيل
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
