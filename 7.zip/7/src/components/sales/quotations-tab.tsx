"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { Decimal, dec, moneyR, num as decNum, sumOf } from "@/lib/decimal";
import { formatDateTime, formatIQD } from "@/lib/utils";
import { FileSignature, Loader2, Plus, Trash2, Send, Check, X, ReceiptText, MessageCircle } from "lucide-react";

interface Customer { id: number; code: string; name: string }
interface Product { id: number; name: string; unit: string; salePrice: number }

interface QuotationRow {
  id: number;
  number: string;
  status: string;
  customer: { code: string; name: string };
  quote_date: string;
  valid_until: string | null;
  items: number;
  grand_total: number;
  converted_invoice: string | null;
  notes: string | null;
  created_by: string;
}

interface QuotationDetail extends QuotationRow {
  uuid: string; // رمز المعاينة العامة (/verify/<uuid>)
  subtotal: number;
  discount_total: number;
  tax_total: number;
  lines: {
    product_id: number;
    code: string;
    product: string;
    unit: string;
    qty: number;
    unit_price: number;
    discount_pct: number;
    line_total: number;
  }[];
  customer: QuotationRow["customer"] & { whatsapp?: string | null };
}

interface Line { product_id: number; qty: number; discount_pct: number }

const STATUS_AR: Record<string, { label: string; variant: "secondary" | "default" | "success" | "destructive" | "outline" }> = {
  DRAFT: { label: "مسودة", variant: "secondary" },
  SENT: { label: "مُرسل", variant: "default" },
  ACCEPTED: { label: "مقبول", variant: "success" },
  REJECTED: { label: "مرفوض", variant: "destructive" },
  CONVERTED: { label: "محوَّل لفاتورة", variant: "success" },
  CANCELLED: { label: "ملغى", variant: "destructive" },
};

export function QuotationsTab({
  canCreate,
  canConvert,
}: {
  canCreate: boolean;
  canConvert: boolean;
}) {
  const [customers, setCustomers] = React.useState<Customer[]>([]);
  const [products, setProducts] = React.useState<Product[]>([]);
  const [rows, setRows] = React.useState<QuotationRow[] | null>(null);
  const [detail, setDetail] = React.useState<QuotationDetail | null>(null);
  const [lines, setLines] = React.useState<Line[]>([]);
  const [busy, setBusy] = React.useState(false);

  const load = React.useCallback(async () => {
    const [c, p, r] = await Promise.all([
      api<Customer[]>("/api/v1/customers?per_page=200"),
      api<Product[]>("/api/v1/products?per_page=200"),
      api<QuotationRow[]>("/api/v1/sales/quotations?per_page=30"),
    ]);
    if (c.body.success && c.body.data) setCustomers(c.body.data);
    if (p.body.success && p.body.data) setProducts(p.body.data as unknown as Product[]);
    if (r.body.success && r.body.data) setRows(r.body.data);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  function addLine() {
    const first = products[0];
    if (!first) return;
    setLines((prev) => [...prev, { product_id: first.id, qty: 1, discount_pct: 0 }]);
  }
  function setLine(idx: number, patch: Partial<Line>) {
    setLines((prev) => prev.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
  }

  // Phase 3: Decimal
  const draftTotal = decNum(moneyR(sumOf(lines, (l) => {
    const p = products.find((x) => x.id === l.product_id);
    if (!p) return 0;
    return dec(l.qty).mul(p.salePrice).mul(new Decimal(1).minus(dec(l.discount_pct).div(100)));
  })));

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!lines.length) return toast.error("أضف بندًا واحدًا على الأقل");
    setBusy(true);
    const fd = new FormData(e.currentTarget);
    try {
      const { body } = await api("/api/v1/sales/quotations", {
        method: "POST",
        body: JSON.stringify({
          customer_id: Number(fd.get("customer_id")),
          notes: fd.get("notes") || undefined,
          lines: lines.map((l) => ({ product_id: l.product_id, qty: l.qty, discount_pct: l.discount_pct || undefined })),
        }),
      });
      if (body.success) {
        toast.success(`أُنشئ عرض السعر ${(body.data as { number: string }).number}`);
        setLines([]);
        await load();
      } else toast.error(body.message ?? "فشل إنشاء العرض");
    } finally {
      setBusy(false);
    }
  }

  async function openDetail(id: number) {
    setDetail(null);
    const r = await api<QuotationDetail>(`/api/v1/sales/quotations/${id}`);
    if (r.body.success && r.body.data) setDetail(r.body.data);
    else toast.error(r.body.message ?? "فشل التحميل");
  }

  async function setStatus(id: number, status: "SENT" | "ACCEPTED" | "REJECTED" | "CANCELLED") {
    setBusy(true);
    try {
      const { body } = await api(`/api/v1/sales/quotations/${id}`, {
        method: "PATCH",
        body: JSON.stringify({ status }),
      });
      if (body.success) {
        toast.success("حُدّثت حالة العرض");
        setDetail(null);
        await load();
      } else toast.error(body.message ?? "فشل التحديث");
    } finally {
      setBusy(false);
    }
  }

  async function convert(q: QuotationDetail) {
    const cash = window.confirm(`تحويل ${q.number} إلى فاتورة نقدية؟\n(موافق = نقدي، إلغاء = آجل)`);
    setBusy(true);
    try {
      const { body } = await api<{ invoice_number: string }>(`/api/v1/sales/quotations/${q.id}`, {
        method: "POST",
        body: JSON.stringify({ pay_mode: cash ? "CASH" : "CREDIT" }),
      });
      if (body.success) {
        toast.success(`تحوّل للفاتورة ${body.data?.invoice_number ?? ""}`);
        setDetail(null);
        await load();
      } else toast.error(body.message ?? "فشل التحويل");
    } finally {
      setBusy(false);
    }
  }

  /** مشاركة العرض على واتساب — نص جاهز + رابط معاينة عامة، ويُعلّم DRAFT كمُرسل */
  async function shareWhatsApp() {
    if (!detail) return;
    const q = detail;
    const shareUrl = `${window.location.origin}/verify/${q.uuid}`;
    const items = q.lines.slice(0, 12).map((l) =>
      `• ${l.product} — ${n(l.qty)} ${l.unit} × ${n(l.unit_price)}${l.discount_pct > 0 ? ` (خصم ${n(l.discount_pct)}%)` : ""} = ${n(l.line_total)} د.ع`
    );
    const msg = [
      `*عرض سعر ${q.number}*`,
      `التاريخ: ${formatDateTime(q.quote_date)}`,
      q.valid_until ? `سارٍ حتى: ${formatDateTime(q.valid_until)}` : "",
      `العميل: ${q.customer.name}`,
      "",
      "البنود:",
      ...items,
      q.lines.length > 12 ? `… و${q.lines.length - 12} بندًا آخر` : "",
      "",
      `المجموع: ${n(q.subtotal)} د.ع`,
      q.discount_total > 0 ? `الخصم: ${n(q.discount_total)} د.ع` : "",
      `*الإجمالي النهائي: ${n(q.grand_total)} د.ع*`,
      q.notes ? `\nملاحظات: ${q.notes}` : "",
      `\nمعاينة العرض كاملاً:\n${shareUrl}`,
    ].filter(Boolean).join("\n");
    const phone = q.customer.whatsapp?.replace(/\D/g, "");
    const url = phone
      ? `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`
      : `https://wa.me/?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
    // مسار العمل الحقيقي: مشاركة العرض = إرساله للعميل
    if (q.status === "DRAFT") {
      const { body } = await api(`/api/v1/sales/quotations/${q.id}`, { method: "PATCH", body: JSON.stringify({ status: "SENT" }) });
      if (body.success) {
        setDetail({ ...q, status: "SENT" });
        await load();
        toast.success("أُرسل العرض للعميل وحُدّثت حالته إلى «مُرسل»");
      }
    }
  }

  const n = (v: number) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(v);

  return (
    <div className="space-y-4">
      {canCreate && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base"><FileSignature className="w-4 h-4" /> عرض سعر جديد</CardTitle>
            <CardDescription>لا يُخفّض المخزون — يُحوَّل لاحقًا لفاتورة فعلية عند قبول العميل</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={submit} className="space-y-3">
              <div className="flex flex-wrap gap-2 items-end">
                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground">العميل</label>
                  <select name="customer_id" className="h-9 rounded-md border bg-background px-3 text-sm min-w-52" defaultValue={customers[0]?.id ?? ""}>
                    {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div className="space-y-1 flex-1 min-w-48">
                  <label className="text-xs text-muted-foreground">ملاحظات</label>
                  <Input name="notes" className="h-9" placeholder="اختياري" />
                </div>
              </div>

              <div className="rounded-lg border p-2 space-y-2">
                {lines.map((l, i) => {
                  const p = products.find((x) => x.id === l.product_id);
                  return (
                    <div key={i} className="flex gap-2 items-center flex-wrap">
                      <select
                        className="h-8 rounded-md border bg-background px-2 text-sm min-w-44"
                        value={l.product_id}
                        onChange={(e) => setLine(i, { product_id: Number(e.target.value) })}
                      >
                        {products.map((p2) => <option key={p2.id} value={p2.id}>{p2.name}</option>)}
                      </select>
                      <Input type="number" step="any" min="0" className="h-8 w-24" dir="ltr" value={l.qty}
                        onChange={(e) => setLine(i, { qty: Number(e.target.value) })} title="الكمية" />
                      <span className="text-xs text-muted-foreground w-12">{p?.unit ?? ""}</span>
                      <span className="text-xs text-muted-foreground" dir="ltr">{formatIQD(p?.salePrice ?? 0)}</span>
                      <div className="flex items-center gap-1">
                        <Input type="number" min="0" max="100" className="h-8 w-20" dir="ltr" value={l.discount_pct}
                          onChange={(e) => setLine(i, { discount_pct: Number(e.target.value) })} title="خصم %" />
                        <span className="text-xs text-muted-foreground">%</span>
                      </div>
                      <span className="text-sm font-medium min-w-24 text-left" dir="ltr">
                        {formatIQD(decNum(moneyR(dec(l.qty).mul(p?.salePrice ?? 0).mul(new Decimal(1).minus(dec(l.discount_pct).div(100))))))}
                      </span>
                      <Button type="button" size="icon" variant="ghost" className="h-8 w-8" onClick={() => setLines((prev) => prev.filter((_, j) => j !== i))}>
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  );
                })}
                <div className="flex items-center justify-between">
                  <Button type="button" size="sm" variant="outline" onClick={addLine}><Plus className="w-4 h-4" /> بند</Button>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">الإجمالي:</span>
                    <span className="font-bold" dir="ltr">{formatIQD(draftTotal)}</span>
                    <Button type="submit" size="sm" disabled={busy || !customers.length}>
                      {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileSignature className="w-4 h-4" />} إنشاء العرض
                    </Button>
                  </div>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {detail && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  {detail.number}
                  <Badge variant={STATUS_AR[detail.status]?.variant ?? "secondary"}>{STATUS_AR[detail.status]?.label ?? detail.status}</Badge>
                </CardTitle>
                <CardDescription>
                  {detail.customer.name} — {detail.items} بندًا — الإجمالي: <span dir="ltr" className="font-semibold">{formatIQD(detail.grand_total)}</span>
                  {detail.converted_invoice ? ` — الفاتورة: ${detail.converted_invoice}` : ""}
                </CardDescription>
              </div>
              <div className="flex gap-2 flex-wrap">
                {detail.status !== "CANCELLED" && detail.status !== "CONVERTED" && (
                  <Button size="sm" variant="outline" onClick={shareWhatsApp} className="text-emerald-700 dark:text-emerald-400 border-emerald-600/40" title="إرسال العرض للعميل على واتساب">
                    <MessageCircle className="w-4 h-4" /> واتساب
                  </Button>
                )}
                {(detail.status === "DRAFT" || detail.status === "SENT") && (
                  <>
                    {detail.status === "DRAFT" && (
                      <Button size="sm" variant="outline" onClick={() => setStatus(detail.id, "SENT")} disabled={busy}><Send className="w-4 h-4" /> إرسال</Button>
                    )}
                    <Button size="sm" variant="outline" className="text-green-600" onClick={() => setStatus(detail.id, "ACCEPTED")} disabled={busy}><Check className="w-4 h-4" /> قبول</Button>
                    <Button size="sm" variant="outline" className="text-red-600" onClick={() => setStatus(detail.id, "REJECTED")} disabled={busy}><X className="w-4 h-4" /> رفض</Button>
                  </>
                )}
                {(detail.status === "DRAFT" || detail.status === "SENT" || detail.status === "ACCEPTED") && canConvert && (
                  <Button size="sm" onClick={() => convert(detail)} disabled={busy}><ReceiptText className="w-4 h-4" /> تحويل لفاتورة</Button>
                )}
                <Button size="sm" variant="ghost" onClick={() => setDetail(null)}>إغلاق</Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>المنتج</TableHead>
                  <TableHead className="text-left">الكمية</TableHead>
                  <TableHead className="text-left">سعر الوحدة</TableHead>
                  <TableHead className="text-left">خصم</TableHead>
                  <TableHead className="text-left">الإجمالي</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {detail.lines.map((l) => (
                  <TableRow key={l.product_id}>
                    <TableCell className="text-sm">{l.product} <span className="text-[10px] text-muted-foreground" dir="ltr">{l.code}</span></TableCell>
                    <TableCell className="text-left" dir="ltr">{l.qty} {l.unit}</TableCell>
                    <TableCell className="text-left" dir="ltr">{formatIQD(l.unit_price)}</TableCell>
                    <TableCell className="text-left" dir="ltr">{l.discount_pct}%</TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(l.line_total)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">عروض الأسعار</CardTitle>
        </CardHeader>
        <CardContent>
          {rows == null ? (
            <div className="py-8 text-center text-muted-foreground"><Loader2 className="w-5 h-5 animate-spin inline" /></div>
          ) : rows.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">لا عروض بعد</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الرقم</TableHead>
                  <TableHead>العميل</TableHead>
                  <TableHead className="text-left">الحالة</TableHead>
                  <TableHead className="text-left">بنود</TableHead>
                  <TableHead className="text-left">الإجمالي</TableHead>
                  <TableHead className="text-left">التاريخ</TableHead>
                  <TableHead />
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.id} className="cursor-pointer" onClick={() => openDetail(r.id)}>
                    <TableCell className="font-mono text-xs" dir="ltr">{r.number}</TableCell>
                    <TableCell className="text-sm">{r.customer.name}</TableCell>
                    <TableCell className="text-left"><Badge variant={STATUS_AR[r.status]?.variant ?? "secondary"} className="text-[10px]">{STATUS_AR[r.status]?.label ?? r.status}</Badge></TableCell>
                    <TableCell className="text-left" dir="ltr">{r.items}</TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(r.grand_total)}</TableCell>
                    <TableCell className="text-left text-xs text-muted-foreground" dir="ltr">{formatDateTime(r.quote_date)}</TableCell>
                    <TableCell><Button size="sm" variant="ghost">عرض</Button></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
