"use client";

import * as React from "react";
import { Moon, Sun, MonitorSmartphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { api } from "@/lib/client-api";

// =====================================================================
// §89 — Dark theme toggle (light → dark → system), persisted in
// localStorage (pre-paint in layout.tsx) and synced to the user record
// via PATCH /api/v1/auth/me so the preference follows the account.
// =====================================================================

type ThemeMode = "light" | "dark" | "system";
const STORAGE_KEY = "sds-theme";

export function applyTheme(mode: ThemeMode) {
  const dark =
    mode === "dark" ||
    (mode === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
}

export function ThemeToggle({ compact = false }: { compact?: boolean }) {
  const [mode, setMode] = React.useState<ThemeMode>("system");

  React.useEffect(() => {
    const stored = (localStorage.getItem(STORAGE_KEY) as ThemeMode | null) ?? "system";
    setMode(stored);
    applyTheme(stored);
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => {
      if ((localStorage.getItem(STORAGE_KEY) as ThemeMode | null ?? "system") === "system") applyTheme("system");
    };
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  function cycle() {
    const next: ThemeMode = mode === "light" ? "dark" : mode === "dark" ? "system" : "light";
    setMode(next);
    localStorage.setItem(STORAGE_KEY, next);
    applyTheme(next);
    document.documentElement.classList.add("theme-anim");
    setTimeout(() => document.documentElement.classList.remove("theme-anim"), 400);
    // sync preference to the account (best-effort)
    api("/api/v1/auth/me", { method: "PATCH", body: JSON.stringify({ theme: next }) }).catch(() => {});
    toast.success(
      next === "dark" ? "السمة الداكنة مفعّلة" : next === "light" ? "السمة الفاتحة مفعّلة" : "متابعة سمة النظام"
    );
  }

  const label = mode === "dark" ? "داكن" : mode === "light" ? "فاتح" : "النظام";
  return (
    <Button
      size="sm"
      variant="ghost"
      className="text-slate-200 hover:bg-white/10 hover:text-white gap-1.5"
      onClick={cycle}
      title={`السمة: ${label} (اضغط للتبديل)`}
    >
      {mode === "dark" ? <Moon className="w-4 h-4" /> : mode === "light" ? <Sun className="w-4 h-4" /> : <MonitorSmartphone className="w-4 h-4" />}
      {!compact && <span className="text-xs hidden md:inline">{label}</span>}
    </Button>
  );
}
