"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api, type LoginPayload } from "@/lib/client-api";
import { formatDateTime, formatIQD } from "@/lib/utils";
import { KpiCard } from "@/components/sales/kpi-card";
import { AlertTriangle, Boxes, ChevronLeft, Coins, Receipt, TrendingUp, Users, Wallet, Landmark, Banknote } from "lucide-react";

interface Stats {
  sales_today: { total: number; count: number };
  sales_month: { total: number };
  receivables: number;
  products_count: number;
  customers_count: number;
  low_stock: { code: string; name: string; unit: string; qty: number; min_stock: number }[];
  top_products: { code: string; name: string; qty: number; revenue: number }[];
  recent_invoices: { id: number; number: string; type: string; grand_total: number; customer: string; invoice_date: string }[];
}

export function OverviewTab({ session, onGoto }: { session: LoginPayload; onGoto: (tab: string) => void }) {
  const [stats, setStats] = React.useState<Stats | null>(null);
  const [cashboxKpis, setCashboxKpis] = React.useState<{
    receipts_today: number; payments_today: number; total_cash: number; open_cashboxes: number;
    top_cashboxes: { id: number; code: string; name: string; balance: number; branch?: { name: string } }[];
    pending_checks: { id: number; checkNumber: string; amount: number; dueDate: string; checkType: string }[];
  } | null>(null);

  React.useEffect(() => {
    (async () => {
      const { body } = await api<Stats>("/api/v1/dashboard/stats");
      if (body.success && body.data) setStats(body.data);
      else toast.error(body.message ?? "تعذر تحميل الإحصاءات");
    })();
    // Cashbox KPI widgets (advanced finance)
    (async () => {
      const { body } = await api<{
        receipts_today: number; payments_today: number; total_cash: number; open_cashboxes: number;
        top_cashboxes: { id: number; code: string; name: string; balance: number; branch?: { name: string } }[];
        pending_checks: { id: number; checkNumber: string; amount: number; dueDate: string; checkType: string }[];
      }>("/api/v1/finance/cashboxes?with_kpis=1");
      if (body.success && body.data) setCashboxKpis(body.data);
    })();
  }, []);

  const canSell = session.permissions.includes("sales.invoices.create");

  return (
    <div className="space-y-4">
      {/* KPI cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard tone="blue" icon={<TrendingUp className="w-5 h-5" />} label="مبيعات اليوم" value={formatIQD(stats?.sales_today.total ?? 0)} sub={`${stats?.sales_today.count ?? 0} فاتورة`} />
        <KpiCard tone="emerald" icon={<Coins className="w-5 h-5" />} label="مبيعات الشهر" value={formatIQD(stats?.sales_month.total ?? 0)} sub="منذ بداية الشهر" />
        <KpiCard tone="amber" icon={<Users className="w-5 h-5" />} label="ذمم العملاء (مدينة)" value={formatIQD(stats?.receivables ?? 0)} sub={`${stats?.customers_count ?? 0} عميل نشط`} />
        <KpiCard tone="violet" icon={<Boxes className="w-5 h-5" />} label="المنتجات النشطة" value={String(stats?.products_count ?? 0)} sub="في الكتالوج" />
      </div>

      {/* Cashbox dashboard widgets */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard tone="emerald" icon={<Receipt className="w-5 h-5" />} label="قبض اليوم" value={formatIQD(cashboxKpis?.receipts_today ?? 0)} sub="إجمالي وصولات القبض اليومية" />
        <KpiCard tone="amber" icon={<Wallet className="w-5 h-5" />} label="صرف اليوم" value={formatIQD(cashboxKpis?.payments_today ?? 0)} sub="إجمالي وصولات الصرف اليومية" />
        <KpiCard tone="blue" icon={<Coins className="w-5 h-5" />} label="إجمالي النقد" value={formatIQD(cashboxKpis?.total_cash ?? 0)} sub="في كل الصناديق" />
        <KpiCard tone="violet" icon={<Wallet className="w-5 h-5" />} label="صناديق مفتوحة" value={String(cashboxKpis?.open_cashboxes ?? 0)} sub="نشطة الآن" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Recent invoices */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base"><Receipt className="w-4 h-4 text-primary" /> أحدث الفواتير</CardTitle>
              <Button variant="ghost" size="sm" onClick={() => onGoto("invoices")}>
                الكل <ChevronLeft className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {!stats?.recent_invoices.length ? (
              <div className="py-8 text-center text-muted-foreground text-sm">لا فواتير بعد — أنشئ أول فاتورة</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الرقم</TableHead>
                    <TableHead>العميل</TableHead>
                    <TableHead>النوع</TableHead>
                    <TableHead className="text-left">الإجمالي</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stats.recent_invoices.map((inv) => (
                    <TableRow key={inv.id}>
                      <TableCell dir="ltr" className="font-mono text-xs text-right font-medium">{inv.number}</TableCell>
                      <TableCell className="text-sm">{inv.customer}</TableCell>
                      <TableCell>
                        <Badge variant={inv.type === "CASH" ? "success" : "navy"} className="text-[10px]">
                          {inv.type === "CASH" ? "نقدية" : "آجل"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-left text-sm font-semibold">{formatIQD(inv.grand_total)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
          {/* Low stock */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base"><AlertTriangle className="w-4 h-4 text-amber-500" /> تنبيهات نقص المخزون</CardTitle>
              <CardDescription>منتجات وصلت إلى الحد الأدنى في مستودعاتك</CardDescription>
            </CardHeader>
            <CardContent>
              {!stats?.low_stock.length ? (
                <div className="py-6 text-center text-sm text-muted-foreground">لا تنبيهات — كل الأرصدة فوق الحد الأدنى ✓</div>
              ) : (
                <div className="space-y-2">
                  {stats.low_stock.map((p) => (
                    <div key={p.code} className="flex items-center justify-between rounded-lg border px-3 py-2">
                      <div className="min-w-0">
                        <div className="text-sm font-medium truncate">{p.name}</div>
                        <div dir="ltr" className="font-mono text-[11px] text-muted-foreground text-left">{p.code}</div>
                      </div>
                      <Badge variant="destructive" className="text-[11px] shrink-0">
                        {p.qty} / حد {p.min_stock} {p.unit}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Top products */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base"><TrendingUp className="w-4 h-4 text-primary" /> الأكثر مبيعًا هذا الشهر</CardTitle>
            </CardHeader>
            <CardContent>
              {!stats?.top_products.length ? (
                <div className="py-6 text-center text-sm text-muted-foreground">لا مبيعات هذا الشهر بعد</div>
              ) : (
                <div className="space-y-2">
                  {stats.top_products.map((p, i) => (
                    <div key={p.code} className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center shrink-0">{i + 1}</div>
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-medium truncate">{p.name}</div>
                        <div className="text-[11px] text-muted-foreground">{p.qty} وحدة مباعة</div>
                      </div>
                      <div className="text-sm font-semibold shrink-0">{formatIQD(p.revenue)}</div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {canSell && (
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => onGoto("new-invoice")}><Receipt className="w-4 h-4" /> فاتورة بيع جديدة</Button>
          <Button variant="outline" onClick={() => onGoto("products")}>إدارة المنتجات</Button>
          <Button variant="outline" onClick={() => onGoto("inventory")}>المخزون</Button>
        </div>
      )}

      {/* Top cashboxes + pending checks */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base"><Wallet className="w-4 h-4 text-primary" /> أكبر 5 صناديق بالنقد</CardTitle>
            <CardDescription>ترتيب الصناديق حسب الرصيد المتاح</CardDescription>
          </CardHeader>
          <CardContent>
            {!cashboxKpis?.top_cashboxes?.length ? (
              <div className="py-6 text-center text-sm text-muted-foreground">لا صناديق بعد</div>
            ) : (
              <div className="space-y-2">
                {cashboxKpis.top_cashboxes.map((c, i) => (
                  <div key={c.id} className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center shrink-0">{i + 1}</div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium truncate">{c.name}</div>
                      <div className="text-[11px] text-muted-foreground" dir="ltr">{c.code}{c.branch?.name ? ` · ${c.branch.name}` : ""}</div>
                    </div>
                    <div className="text-sm font-semibold shrink-0">{formatIQD(c.balance)}</div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base"><Banknote className="w-4 h-4 text-primary" /> شيكات معلقة</CardTitle>
            <CardDescription>شيكات واردة/صادرة بحالة PENDING بانتظار التسوية</CardDescription>
          </CardHeader>
          <CardContent>
            {!cashboxKpis?.pending_checks?.length ? (
              <div className="py-6 text-center text-sm text-muted-foreground">لا شيكات معلقة ✓</div>
            ) : (
              <Table>
                <TableHeader><TableRow>
                  <TableHead>رقم الشيك</TableHead><TableHead>النوع</TableHead>
                  <TableHead>الاستحقاق</TableHead><TableHead className="text-left">المبلغ</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {cashboxKpis.pending_checks.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell dir="ltr" className="font-mono text-xs text-right">{c.checkNumber}</TableCell>
                      <TableCell><Badge variant={c.checkType === "RECEIVED" ? "success" : "secondary"} className="text-[10px]">{c.checkType === "RECEIVED" ? "وارد" : "صادر"}</Badge></TableCell>
                      <TableCell className="text-xs">{c.dueDate.slice(0, 10)}</TableCell>
                      <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(c.amount)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

