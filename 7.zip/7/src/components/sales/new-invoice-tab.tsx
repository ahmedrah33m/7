"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { SearchSelect } from "@/components/ui/search-select";
import { api } from "@/lib/client-api";
import { Decimal, dec, moneyR, num as decNum, qtyR, sumOf } from "@/lib/decimal";
import { formatDateTime, formatIQD, fmtMoney, getUsdRate, setUsdRate } from "@/lib/utils";
import {
  Plus, Receipt, Trash2, ScanBarcode, Wallet,
  AlertTriangle, Package, UserCheck, CalendarClock, ShieldQuestion, Printer, Ban,
} from "lucide-react";

interface ProductRow {
  id: number; code: string; name: string; unit: string; sale_price: number;
  stock_total: number; barcode?: string | null;
  pack_unit?: string | null; pack_qty?: number | null; pack_sale_price?: number | null;
  // ---- Phase 2 §6: العملة المصدر لكل سعر كما خُزّنت ----------------------
  sale_currency?: "IQD" | "USD"; sale_amount?: number;
  pack_sale_currency?: "IQD" | "USD"; pack_sale_amount?: number | null;
  cost_currency?: "IQD" | "USD"; cost_amount?: number;
}
interface CustomerOption { id: number; name: string; credit_limit: number; status?: string; customer_type?: string; is_walkin?: boolean }
interface DefaultWalkin { id: number; code: string; name: string; customer_type: string; labels?: Record<string, string> }

interface PreviewCustomer {
  id: number; code: string; name: string; shop_name: string | null; phone: string | null;
  whatsapp: string | null; address: string | null; area: string | null; status: string;
  credit_limit: number; credit_days: number; discount_pct: number;
  previous_balance: number; has_previous_balance: boolean;
  available_credit: number | null; no_debt: boolean;
}
interface MiniStatement {
  last_invoice: { number: string; date: string; total: number } | null;
  last_payment: { amount: number; date: string; note: string | null } | null;
}
interface PkgSummary {
  has_pack: boolean; text?: string;
  closed_packages?: number; open_packages?: number; open_qty?: number;
  total_pieces?: number; pack_unit?: string; pack_qty?: number;
}
interface PreviewData {
  customer: PreviewCustomer | null;
  warehouse: { id: number; name: string; code: string } | null;
  mini_statement: MiniStatement | null;
  settings: { footer_text: string; packaging_details_default: boolean; open_package_policy: string; credit_exceed_policy: "BLOCK" | "APPROVAL" };
  packages: Record<string, PkgSummary>;
}

interface Line {
  key: number;
  product_id: number | "";
  pkg_qty: number | "";      // عدد الكراتين/العبوات الكاملة
  loose_qty: number | "";    // عدد الحبات/العلب/الأكياس المفردة (وحدة المنتج الأساسية)
  pack_price: number | "";   // سعر الكرتونة — يُملأ تلقائيًا من المنتج وقابل للتعديل
  piece_price: number | "";  // سعر الحبة/الوحدة الأساسية — يُملأ تلقائيًا وقابل للتعديل
  discount_pct: number | "";
  discount_amount: number | "";
}

// الإجمالي = (كراتين × سعر الكرتونة) + (حبات × سعر الحبة) − الخصومات
const emptyLine = (key: number): Line => ({
  key, product_id: "", pkg_qty: "", loose_qty: "", pack_price: "", piece_price: "", discount_pct: "", discount_amount: "",
});

interface PostResult {
  id: number; number: string; sale_type: string; status: string; requires_approval: boolean;
  grand_total: number; paid_amount: number; due_amount: number;
  previous_balance: number; new_balance: number; available_credit: number;
  points_earned: number; due_date: string | null; verify_token: string | null;
  customer: { id: number; name: string; balance_after: number };
}

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";
const num = (v: number | "") => (v === "" ? 0 : Number(v));

// صياغة الوحدة حسب قواعد الأعداد العربية: 1 علبة · علبتين · 3-10 علب · 11+ علبة
const unitCount = (n: number, u?: string | null) => {
  const m = Math.abs(Math.round(n)) % 100;
  const forms: Record<string, [string, string, string]> = {
    "علبة": ["علبة", "علبتين", "علب"],
    "حبة": ["حبة", "حبتين", "حبات"],
    "قطعة": ["قطعة", "قطعتين", "قطع"],
    "كرتونة": ["كرتونة", "كرتونتين", "كراتين"],
    "كارتون": ["كارتون", "كارتونين", "كراتين"],
    "صندوق": ["صندوق", "صندوقين", "صناديق"],
  };
  const f = forms[u ?? ""];
  if (!f) return u ?? "وحدة";
  if (m === 1) return f[0];
  if (m === 2) return f[1];
  if (m >= 3 && m <= 10) return f[2];
  return f[0];
};

// صياغة كمية بلا ازدواج الرقم: 1 → «حبة» · 2 → «حبتين» · 3+ → «3 حبات»
const qtyWord = (n: number | null | undefined, u?: string | null) => {
  const m = Math.abs(Math.round(Number(n ?? 0)));
  const w = unitCount(m, u);
  return m === 1 || m === 2 ? w : `${m.toLocaleString("en-US")} ${w}`;
};

// توحيد صياغة الوحدات للمقارنة (همزات/تاء مربوطة) — §11: لا «1 كرتون = 11 كرتون» أبدًا
const sameUnit = (a?: string | null, b?: string | null) =>
  !!a && !!b && a.replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").trim() === b.replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").trim();

const CUSTOMER_STATUS: Record<string, { label: string; variant: "success" | "destructive" | "accent" }> = {
  ACTIVE: { label: "نشط", variant: "success" },
  BLOCKED: { label: "موقوف", variant: "destructive" },
  CREDIT_HOLD: { label: "حجز ائتماني", variant: "accent" },
};
const SALE_TYPE_LABEL: Record<string, string> = {
  CASH: "نقدي", CREDIT: "آجل", PARTIAL: "جزئي", SWAP: "استبدال", RETURN: "مرتجع",
};

export function NewInvoiceTab({
  warehouses,
  onPosted,
}: {
  warehouses: { id: number; code: string; name: string }[];
  onPosted?: () => void;
}) {
  const [products, setProducts] = React.useState<ProductRow[]>([]);
  const [customers, setCustomers] = React.useState<CustomerOption[]>([]);
  const [type, setType] = React.useState<"CASH" | "CREDIT" | "SWAP">("CASH");
  const [paidInput, setPaidInput] = React.useState<number | "">("");
  const [paymentMethod, setPaymentMethod] = React.useState("CASH");
  const [dueDate, setDueDate] = React.useState("");
  const [packagingDetails, setPackagingDetails] = React.useState(true);
  // إدخال قائمة قديمة بنفس رقمها المطبوع (فارغ = ترقيم تلقائي INV-…)
  const [customNumber, setCustomNumber] = React.useState("");
  const [preview, setPreview] = React.useState<PreviewData | null>(null);
  const [lines, setLines] = React.useState<Line[]>([emptyLine(1)]);
  const [saving, setSaving] = React.useState(false);
  const [result, setResult] = React.useState<PostResult | null>(null);
  // ---- عملة مزدوجة: دينار عراقي (أساس) + دولار — المبالغ تُخزّن بالدينار دائمًا
  const [currency, setCurrency] = React.useState<"IQD" | "USD">("IQD");
  const [rateInput, setRateInput] = React.useState<number | "">("");
  const rate = currency === "USD" ? (rateInput === "" ? 0 : Number(rateInput)) : 0;
  const keyRef = React.useRef(2);
  const [whId, setWhId] = React.useState<number | "">(warehouses[0]?.id ?? "");
  const [custId, setCustId] = React.useState<number | "">("");
  const [walkin, setWalkin] = React.useState<DefaultWalkin | null>(null);
  const [walkinInfo, setWalkinInfo] = React.useState({ name: "", phone: "", address: "" });
  const [showQuickCreate, setShowQuickCreate] = React.useState(false);
  const [quickCreate, setQuickCreate] = React.useState({ name: "", phone: "", credit_limit: 0 });
  // ---- ملاحظات الفاتورة + الصرف رغم نقص المخزون ---------------------------
  const [invoiceNotes, setInvoiceNotes] = React.useState("");
  const [allowNegative, setAllowNegative] = React.useState(false);

  React.useEffect(() => {
    api<ProductRow[]>("/api/v1/products?per_page=100").then(({ body }) => {
      if (body.success && body.data) setProducts(body.data);
      else toast.error(body.message ?? "تعذر تحميل المنتجات");
    });
    // آخر سعر صرف مستخدم (localStorage) كقيمة افتراضية لحقل الدولار
    // eslint-disable-next-line react-hooks/set-state-in-effect -- قراءة localStorage متزامنة عمداً عند التركيب
    setRateInput(getUsdRate());
    api<CustomerOption[]>("/api/v1/customers?per_page=100").then(({ body }) => {
      if (body.success && body.data) setCustomers(body.data);
    });
    // POS walk-in default (Phase 20/46): زبون نقدي جاهز للبيع السريع
    // (لا يطغى على عميل "إعادة الطلب": حرس مزدوج — مفتاح النسخ أو أن النسخ طُبّق فعلاً)
    api<DefaultWalkin>("/api/v1/customers/default-walkin").then(({ body }) => {
      if (body.success && body.data) {
        setWalkin(body.data);
        if (!sessionStorage.getItem("invoice_clone") && !cloneApplied.current) setCustId(body.data.id);
      }
    });
  }, []);

  // ---- إعادة طلب (تطوير الفاتورة — جولة 2) --------------------------------
  // تُقرأ بنود الفاتورة المنسوخة من sessionStorage وتُعبأ بعد تحميل المنتجات،
  // ثم يُنظّف المفتاح حتى لا يتكرر التعبئة عند كل زيارة للتبويب.
  const cloneApplied = React.useRef(false);
  React.useEffect(() => {
    if (cloneApplied.current || products.length === 0) return;
    const raw = sessionStorage.getItem("invoice_clone");
    if (!raw) return;
    // eslint-disable-next-line react-hooks/immutability -- علَم استهلاك مفتاح النسخ (ref داخل تأثير آمن)
    cloneApplied.current = true;
    sessionStorage.removeItem("invoice_clone");
    try {
      const payload = JSON.parse(raw) as {
        customer_id: number; warehouse_id: number | null; sale_type: string;
        source_number: string;
        lines: { product_id: string; product_id_num: number | null; package_qty: number; loose_qty: number; qty: number; unit_price: number; package_price: number | null; discount_pct: number }[];
      };
      // العميل: إن وُجد ضمن قائمة الشركة النشطة
      const custOk = customers.some((c) => c.id === payload.customer_id);
      if (custOk) setCustId(payload.customer_id);
      // المستودع: إن حُدد وكان ضمن القائمة
      if (payload.warehouse_id && warehouses.some((w) => w.id === payload.warehouse_id)) {
        setWhId(payload.warehouse_id);
      }
      if (payload.sale_type === "CASH" || payload.sale_type === "CREDIT") setType(payload.sale_type);
      // البنود: حل المنتج بالكود أو المعرف + استعادة الكرتون والحبات والسعرين
      const newLines: Line[] = [];
      let key = keyRef.current;
      for (const cl of payload.lines) {
        const p =
          products.find((x) => x.code === cl.product_id) ??
          (cl.product_id_num ? products.find((x) => x.id === cl.product_id_num) : undefined);
        if (!p) continue;
        key = keyRef.current++;
        const hasPackRow = !!p.pack_unit && !!p.pack_qty && Number(p.pack_qty) > 1;
        const pieceDef = p.sale_price;
        const packDef = hasPackRow
          ? (p.pack_sale_price != null ? Number(p.pack_sale_price) : Math.round(Number(p.pack_qty) * pieceDef * 100) / 100)
          : "";
        if (hasPackRow) {
          // unit_price المخزن = سعر الحبة دائمًا (§تخزين الخادم) — package_price سعر الكرتونة
          newLines.push({
            key, product_id: p.id,
            pkg_qty: cl.package_qty > 0 ? cl.package_qty : "",
            loose_qty: cl.loose_qty > 0 ? cl.loose_qty : "",
            pack_price: cl.package_qty > 0 ? (cl.package_price ?? packDef) : (packDef as number | ""),
            piece_price: cl.unit_price || pieceDef,
            discount_pct: cl.discount_pct || "", discount_amount: "",
          });
        } else {
          newLines.push({
            key, product_id: p.id,
            pkg_qty: "",
            loose_qty: (cl.qty || cl.loose_qty || ""),
            pack_price: "",
            piece_price: cl.unit_price || pieceDef,
            discount_pct: cl.discount_pct || "", discount_amount: "",
          });
        }
      }
      if (newLines.length) {
        setLines(newLines);
        toast.success(`نُسخت ${newLines.length} بنود من الفاتورة ${payload.source_number} — راجع الكميات ثم رحّل`);
      } else {
        toast.error("تعذر نسخ البنود — المنتجات الأصلية غير متوفرة في الشركة النشطة");
      }
    } catch {
      toast.error("بيانات إعادة الطلب تالفة — تم تجاهلها");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [products, customers]);

  const selectedCustomer = customers.find((c) => c.id === custId);
  const isWalkinSale = !!selectedCustomer?.is_walkin || (!!walkin && custId === walkin.id);

  // ---- طبقة العرض بالعملة المختارة ------------------------------------------
  // الداخلية كلها دينار؛ حين العملة دولار: العرض = دينار ÷ السعر، والإدخال
  // بالدولار تُحوّل عند الكتابة إلى دينار (منطق الخادم والحسابات لا يتغير).
  const money = (n: number) => fmtMoney(n, currency, currency === "USD" && rate > 0 ? rate : null);
  const toDisplay = (iqd: number | "") =>
    currency === "USD" && rate > 0 && iqd !== "" ? Math.round((Number(iqd) / rate) * 100) / 100 : iqd;
  const fromDisplay = (v: number | "") =>
    currency === "USD" && rate > 0 && v !== "" ? Math.round((Number(v) * rate) * 100) / 100 : v;

  const selectedProductIds = lines
    .filter((l) => l.product_id !== "")
    .map((l) => Number(l.product_id));

  // معاينة ذكية: بطاقة العميل + الرصيد السابق + كشف مختصر + حالة العبوات (§2/§3/§22/§27)
  const loadPreview = React.useCallback(async (customerId: number | "", warehouseId: number | "", productIds: number[]) => {
    if (customerId === "" || warehouseId === "") {
      setPreview(null);
      return;
    }
    const { body } = await api<PreviewData>("/api/v1/sales/invoices/preview", {
      method: "POST",
      body: JSON.stringify({
        customer_id: Number(customerId),
        warehouse_id: Number(warehouseId),
        ...(productIds.length ? { product_ids: [...new Set(productIds)].slice(0, 50) } : {}),
      }),
    });
    if (body.success && body.data) setPreview(body.data);
  }, []);

  React.useEffect(() => {
    loadPreview(custId, whId, selectedProductIds);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [custId, whId]);

  const refreshPreviewAfterLineChange = React.useRef<number | null>(null);
  // مرجع حي للبنود — جدولة تحديث المعاينة تُنفّذ بعد 400ms وتقرأ أحدث بنود
  // (بدونه تُرسل قائمة منتجات قديمة/فارغة فلا تُرجع المعاينة حالة العبوات)
  const linesRef = React.useRef<Line[]>(lines);
  React.useEffect(() => { linesRef.current = lines; });
  function schedulePreviewRefresh() {
    if (refreshPreviewAfterLineChange.current) window.clearTimeout(refreshPreviewAfterLineChange.current);
    refreshPreviewAfterLineChange.current = window.setTimeout(() => {
      loadPreview(custId, whId, linesRef.current.filter((l) => l.product_id !== "").map((l) => Number(l.product_id)));
    }, 400);
  }

  const productById = (id: number | "") => (id === "" ? undefined : products.find((p) => p.id === Number(id)));
  const productHasPack = (p?: ProductRow) => !!p?.pack_unit && !!p?.pack_qty && Number(p.pack_qty) > 1;
  const hasPack = (l: Line) => productHasPack(productById(l.product_id));
  const packQtyOf = (l: Line) => Number(productById(l.product_id)?.pack_qty ?? 1);
  // سعر الكرتونة الافتراضي من المنتج (للتعبئة التلقائية عند اختيار منتج)
  const packDefaultOf = (p: ProductRow): number | "" =>
    productHasPack(p)
      ? (p.pack_sale_price != null ? Number(p.pack_sale_price) : Math.round(Number(p.pack_qty) * p.sale_price * 100) / 100)
      : "";

  // الإجمالي الخام للسطر (محاكاة الخادم §18/§19): كراتين×سعر الكرتونة + حبات×سعر الحبة
  // كل كتابة تحسب لحالها — وإن كُتب الاثنان اجتمعا في إجمالي واحد
  function lineGross(l: Line): Decimal {
    const p = productById(l.product_id);
    if (!p) return dec(0);
    const pk = productHasPack(p) ? dec(num(l.pkg_qty)).mul(num(l.pack_price)) : dec(0);
    const ls = dec(num(l.loose_qty)).mul(num(l.piece_price));
    return pk.plus(ls);
  }

  function baseQty(l: Line): number {
    const p = productById(l.product_id);
    if (!p) return 0;
    if (!productHasPack(p)) return decNum(qtyR(dec(l.loose_qty)));
    return decNum(qtyR(dec(num(l.pkg_qty)).mul(Number(p.pack_qty)).plus(dec(l.loose_qty))));
  }

  // Phase 3: حساب السلة عبر Decimal — ممنوع float في الحساب المالي
  function lineTotal(l: Line): number {
    const after = lineGross(l).mul(new Decimal(1).minus(dec(l.discount_pct).div(100))).minus(dec(l.discount_amount));
    return decNum(Decimal.max(new Decimal(0), moneyR(after)));
  }

  function setLine(key: number, patch: Partial<Line>) {
    setLines((ls) =>
      ls.map((l) => {
        if (l.key !== key) return l;
        const next = { ...l, ...patch };
        if (patch.product_id !== undefined) {
          const p = productById(patch.product_id);
          next.piece_price = p ? p.sale_price : "";
          next.pack_price = p ? packDefaultOf(p) : "";
          next.pkg_qty = "";
          next.loose_qty = "";
          next.discount_pct = "";
          next.discount_amount = "";
          schedulePreviewRefresh();
        }
        return next;
      })
    );
  }

  function addLine() {
    setLines((ls) => [...ls, emptyLine(keyRef.current++)]);
  }

  function removeLine(key: number) {
    setLines((ls) => {
      const next = ls.length === 1 ? ls : ls.filter((l) => l.key !== key);
      return next;
    });
    schedulePreviewRefresh();
  }

  // ---- إجماليات + لوحة الرصيد المفصولة (§4) ------------------------------
  const subtotal = decNum(moneyR(sumOf(lines, (l) => decNum(lineGross(l)))));
  const grandTotal = decNum(moneyR(sumOf(lines, (l) => lineTotal(l))));
  const discountTotal = decNum(moneyR(dec(subtotal).minus(grandTotal)));

  const cust = preview?.customer ?? null;
  const previousBalance = cust?.previous_balance ?? 0;
  const paidNow = type === "CREDIT" ? decNum(moneyR(Decimal.min(Decimal.max(dec(paidInput), 0), dec(grandTotal)))) : grandTotal;
  const dueAmount = decNum(moneyR(dec(grandTotal).minus(paidNow)));
  const totalDue = decNum(moneyR(dec(previousBalance).plus(grandTotal)));
  const newBalance = Math.round((previousBalance + dueAmount + Number.EPSILON) * 100) / 100;

  const effectiveSaleType = type === "SWAP" ? "SWAP" : type === "CREDIT" ? (paidNow > 0 && paidNow < grandTotal ? "PARTIAL" : "CREDIT") : "CASH";
  const creditLimit = cust?.credit_limit ?? 0;
  const creditExceeded = type === "CREDIT" && creditLimit > 0 && newBalance > creditLimit;
  const creditPolicy = preview?.settings.credit_exceed_policy ?? "BLOCK";

  // هل يوجد بند يتجاوز المتاح؟ (لتظليل مربع الصرف رغم النقص)
  const stockShort = lines.some((l) => {
    if (l.product_id === "" || baseQty(l) <= 0) return false;
    const info = preview?.packages?.[String(l.product_id)];
    const avail = info?.has_pack ? (info.total_pieces ?? 0) : (productById(l.product_id)?.stock_total ?? 0);
    return baseQty(l) > avail;
  });

  // تاريخ الاستحقاق الافتراضي = اليوم + أيام الائتمان (§1)
  React.useEffect(() => {
    if (type === "CREDIT" && !dueDate && cust?.credit_days) {
      const d = new Date(Date.now() + cust.credit_days * 86400000);
      setDueDate(d.toISOString().slice(0, 10));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, cust?.credit_days]);

  // ---- باركود سريع -------------------------------------------------------
  const barcodeRef = React.useRef<HTMLInputElement>(null);
  function addByBarcode() {
    const raw = barcodeRef.current?.value?.trim();
    if (!raw) return;
    const p = products.find((x) => x.barcode === raw || x.code === raw);
    if (!p) {
      toast.error(`لا منتج بباركود/كود «${raw}»`);
      return;
    }
    const existing = lines.find((l) => l.product_id === p.id);
    if (existing) {
      // كل مسح = حبة واحدة إضافية على بند المنتج نفسه (الحبات خانة مستقلة عن الكراتين)
      setLine(existing.key, { loose_qty: num(existing.loose_qty) + 1 });
    } else {
      const empty = lines.find((l) => l.product_id === "");
      if (empty) {
        setLine(empty.key, { product_id: p.id });
        setLines((ls) => ls.map((x) => (x.key === empty.key ? { ...x, loose_qty: 1 } : x)));
        schedulePreviewRefresh();
      } else {
        setLines((ls) => [...ls, { key: keyRef.current++, product_id: p.id, pkg_qty: "", loose_qty: 1, pack_price: packDefaultOf(p), piece_price: p.sale_price, discount_pct: "", discount_amount: "" }]);
        schedulePreviewRefresh();
      }
    }
    if (barcodeRef.current) barcodeRef.current.value = "";
    toast.success(`أُضيف «${p.name}»`);
  }

  // ---- طباعة مسودة الفاتورة قبل الترحيل ----------------------------------
  function printDraft() {
    const filled = lines.filter((l) => l.product_id !== "" && baseQty(l) > 0);
    if (!filled.length) {
      toast.error("أضف بندًا واحدًا على الأقل لطباعة المسودة");
      return;
    }
    const custName = cust?.name ?? customers.find((c) => c.id === custId)?.name ?? `#${custId}`;
    const whName = warehouses.find((w) => w.id === whId)?.name ?? "";
    const rows = filled.map((l) => {
      const p = productById(l.product_id)!;
      const parts: string[] = [];
      if (num(l.pkg_qty) > 0) parts.push(qtyWord(num(l.pkg_qty), p.pack_unit));
      if (num(l.loose_qty) > 0) parts.push(qtyWord(num(l.loose_qty), p.unit));
      const qtyTxt = parts.join(" + ") || "—";
      const discTxt = [l.discount_pct ? `${l.discount_pct}%` : "", l.discount_amount ? money(num(l.discount_amount)) : ""].filter(Boolean).join(" + ") || "—";
      const packPriceTxt = productHasPack(p) ? money(num(l.pack_price)) : "—";
      const totalTxt = baseQty(l) > 0 ? qtyWord(baseQty(l), p.unit) : "—";
      const packsTxt = productHasPack(p) && baseQty(l) > 0
        ? qtyWord(Math.floor(baseQty(l) / Math.max(1, Number(p.pack_qty))), sameUnit(p.pack_unit, p.unit) ? "عبوة" : (p.pack_unit ?? "عبوة"))
        : "—";
      return `<tr><td>${p.name}<div class="dim">${p.code}</div></td><td>${p.unit}</td><td>${totalTxt}</td><td>${packsTxt}</td><td>${qtyTxt}</td><td>${packPriceTxt}</td><td>${money(num(l.piece_price))}</td><td>${discTxt}</td><td class="b">${money(lineTotal(l))}</td></tr>`;
    }).join("");
    const paidTxt = type === "CREDIT" ? money(paidNow) : money(grandTotal);
    const html = `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>مسودة فاتورة</title><style>
      *{font-family:system-ui,'Segoe UI',Tahoma,sans-serif;box-sizing:border-box}
      body{margin:24px;color:#111}
      .head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #222;padding-bottom:8px}
      .draft{background:#b91c1c;color:#fff;display:inline-block;padding:2px 10px;border-radius:4px;font-size:12px}
      h1{font-size:18px;margin:8px 0}
      .meta{font-size:12px;margin:10px 0;color:#333}
      table{width:100%;border-collapse:collapse;font-size:12px;margin-top:10px}
      th,td{border:1px solid #999;padding:6px;text-align:right}
      th{background:#f2f2f2}
      .dim{color:#777;font-size:10px}
      .b{font-weight:700}
      .tot{margin-top:10px;font-size:13px;text-align:left}
      .notes{margin-top:8px;font-size:12px;border-top:1px dashed #999;padding-top:6px}
      .foot{margin-top:14px;font-size:11px;color:#666;text-align:center}
    </style></head><body>
    <div class="head"><div><h1>فاتورة بيع — مسودة</h1><div class="dim">مستند غير مرحّل — لا أثر محاسبي</div></div><div class="draft">مسودة</div></div>
    <div class="meta">العميل: <b>${custName}</b> · المستودع: ${whName} · النوع: ${type === "CASH" ? "نقدي" : "آجل"} · التاريخ: ${new Date().toLocaleString("ar-IQ")}</div>
    <table><thead><tr><th>المنتج</th><th>الوحدة</th><th>الكمية</th><th>العبوات</th><th>عدد الكارتون + الحبات</th><th>سعر الكارتون</th><th>سعر الحبه</th><th>الخصم</th><th>الاجمالي</th></tr></thead><tbody>${rows}</tbody></table>
    <div class="tot">الإجمالي: <b>${money(grandTotal)}</b> · المدفوع: ${paidTxt} · المتبقي: ${money(dueAmount)}</div>
    ${invoiceNotes.trim() ? `<div class="notes">ملاحظات: ${invoiceNotes.trim()}</div>` : ""}
    ${preview?.settings.footer_text ? `<div class="foot">${preview.settings.footer_text}</div>` : ""}
    <script>window.onload=function(){window.print()}</script>
    </body></html>`;
    const w = window.open("", "_blank");
    if (!w) {
      toast.error("حجب المتصفح نافذة الطباعة — اسمح بالنوافذ المنبثقة");
      return;
    }
    w.document.write(html);
    w.document.close();
  }

  // ---- إلغاء الفاتورة قبل الترحيل — مسح كامل للنموذج ---------------------
  function cancelDraft() {
    if (!window.confirm("إلغاء المسودة ومسح كل البيانات المدخلة؟")) return;
    setLines([emptyLine(keyRef.current++)]);
    setCustId(walkin?.id ?? "");
    setType("CASH");
    setPaidInput("");
    setPaymentMethod("CASH");
    setDueDate("");
    setCustomNumber("");
    setCurrency("IQD");
    setInvoiceNotes("");
    setAllowNegative(false);
    setWalkinInfo({ name: "", phone: "", address: "" });
    setShowQuickCreate(false);
    setResult(null);
    setPreview(null);
    toast.info("أُلغيت المسودة — يمكنك البدء من جديد");
  }

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (custId === "" || whId === "") {
      toast.error("اختر العميل والمستودع");
      return;
    }
    if (currency === "USD" && !(rate > 0)) {
      toast.error("فاتورة الدولار تتطلب سعر صرف صحيحًا (د.ع لكل $1)");
      return;
    }
    // Phase 21 — credit restriction for walk-in (client mirror of WALK_001)
    if (isWalkinSale && type === "CREDIT") {
      toast.error("لا يمكن تسجيل بيع آجل لزبون متردد. يرجى اختيار عميل مسجل أو إنشاء حساب عميل.");
      return;
    }
    const validLines = lines
      .filter((l) => l.product_id !== "")
      .map((l) => ({
        product_id: Number(l.product_id),
        package_qty: hasPack(l) ? num(l.pkg_qty) : 0,
        loose_qty: num(l.loose_qty),
        package_price: hasPack(l) && l.pack_price !== "" ? Number(l.pack_price) : undefined,
        piece_price: l.piece_price === "" ? undefined : Number(l.piece_price),
        discount_pct: l.discount_pct === "" ? undefined : Number(l.discount_pct),
        discount_amount: l.discount_amount === "" ? undefined : Number(l.discount_amount),
      }))
      .filter((l) => l.package_qty! + l.loose_qty > 0);
    if (!validLines.length) {
      toast.error("أضف بندًا واحدًا على الأقل بكمية صحيحة");
      return;
    }
    setSaving(true);
    try {
      const fd = new FormData(e.currentTarget);
      const { body } = await api<PostResult>("/api/v1/sales/invoices", {
        method: "POST",
        body: JSON.stringify({
          customer_id: Number(custId),
          warehouse_id: Number(whId),
          type,
          sale_type: effectiveSaleType,
          ...(isWalkinSale ? { walkin_name: walkinInfo.name || undefined, walkin_phone: walkinInfo.phone || undefined, walkin_address: walkinInfo.address || undefined } : {}),
          payment_method: paymentMethod,
          due_date: type === "CREDIT" && dueDate ? new Date(dueDate + "T12:00:00Z").toISOString() : undefined,
          packaging_details: packagingDetails,
          receiver_name: (fd.get("receiver_name") as string) || undefined,
          receiver_phone: (fd.get("receiver_phone") as string) || undefined,
          rep_notes: (fd.get("rep_notes") as string) || undefined,
          customer_notes: invoiceNotes.trim() || undefined,
          admin_notes: (fd.get("admin_notes") as string) || undefined,
          paid_amount: type === "CREDIT" ? paidNow : undefined,
          currency,
          ...(currency === "USD" ? { exchange_rate: rate } : {}),
          custom_number: customNumber.trim() || undefined,
          allow_negative_stock: allowNegative || undefined,
          lines: validLines,
        }),
      });
      if (body.success && body.data) {
        const r = body.data;
        setResult(r);
        if (r.requires_approval) {
          toast.warning(`الفاتورة ${r.number} محفوظة بانتظار موافقة الإدارة (تجاوز الحد الائتماني)`);
        } else {
          toast.success(`سُجلت الفاتورة ${r.number} — ${money(r.grand_total)}${r.due_amount > 0 ? ` (على الحساب: ${money(r.due_amount)})` : ""}`);
        }
        setLines([emptyLine(keyRef.current++)]);
        setPaidInput("");
        setCustomNumber("");
        setInvoiceNotes("");
        setAllowNegative(false);
        loadPreview(custId, whId, []);
        onPosted?.();
      } else {
        toast.error(body.message ?? "فشل ترحيل الفاتورة", {
          description: body.errors?.map((x) => x.message).join(" · "),
        });
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2"><Receipt className="w-5 h-5 text-primary" /> فاتورة بيع ذكية</CardTitle>
          <CardDescription>
            مستند موحد: رصيد سابق + بيع حالي + مدفوعات + عبوات (كرتونة/حبات) + مخزون — كل رقم مرتبط بالسجلات الفعلية
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            {/* ---- رأس الفاتورة (§1) ---- */}
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <label className="text-xs font-medium space-y-1">العميل *
                <SearchSelect
                  value={custId === "" ? "" : String(custId)}
                  onChange={(v) => setCustId(v ? Number(v) : "")}
                  placeholder="— اكتب اسم العميل أو كوده للبحث —"
                  options={customers.map((c) => ({
                    value: String(c.id),
                    label: `${c.is_walkin ? "🚶 " : ""}${c.name}`,
                    hint: c.credit_limit > 0 ? `حد ${c.credit_limit.toLocaleString("en-US")}` : "نقدي",
                    disabled: c.status === "BLOCKED",
                  }))}
                />
              </label>
              <label className="text-xs font-medium space-y-1">المستودع (مصدر البضاعة) *
                <select className={inputCls} value={String(whId)} onChange={(e) => setWhId(e.target.value ? Number(e.target.value) : "")} required>
                  {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
                </select>
              </label>
              <label className="text-xs font-medium space-y-1">نوع البيع *
                <select
                  className={inputCls}
                  value={type}
                  onChange={(e) => {
                    const v = e.target.value as "CASH" | "CREDIT";
                    if (v === "CREDIT" && isWalkinSale) {
                      toast.error("لا يمكن تسجيل بيع آجل لزبون متردد. يرجى اختيار عميل مسجل أو إنشاء حساب عميل.");
                      return;
                    }
                    setType(v);
                  }}
                >
                  <option value="CASH">نقدي — تحسم فورًا</option>
                  <option value="CREDIT" disabled={isWalkinSale}>آجل — تُضاف للذمة{isWalkinSale ? " (غير متاح للمتردد)" : ""}</option>
                </select>
              </label>
              <label className="text-xs font-medium space-y-1">طريقة الدفع
                <select className={inputCls} value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                  <option value="CASH">نقدي</option>
                  <option value="CARD">بطاقة</option>
                  <option value="TRANSFER">حوالة</option>
                  <option value="CHEQUE">شيك</option>
                </select>
              </label>
              {type === "CREDIT" && (
                <label className="text-xs font-medium space-y-1">تاريخ الاستحقاق
                  <Input type="date" className="h-9" dir="ltr" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
                </label>
              )}
              <label className="text-xs font-medium space-y-1">عملة الفاتورة
                <select
                  className={inputCls}
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as "IQD" | "USD")}
                >
                  <option value="IQD">دينار عراقي (د.ع)</option>
                  <option value="USD">دولار أمريكي ($)</option>
                </select>
              </label>
              {currency === "USD" && (
                <label className="text-xs font-medium space-y-1">سعر الصرف (د.ع لكل $1) *
                  <input
                    type="number"
                    min="1"
                    step="any"
                    className={inputCls}
                    dir="ltr"
                    value={String(rateInput)}
                    onChange={(e) => {
                      const v = e.target.value === "" ? "" : Number(e.target.value);
                      setRateInput(v);
                      if (v !== "" && Number(v) > 0) setUsdRate(Number(v));
                    }}
                    placeholder="مثال: 1300"
                    required
                  />
                  <span className="text-[10px] text-muted-foreground block">الأسعار تُدخل وتُعرض بالدولار — التخزين والصندوق بالدينار المكافئ</span>
                </label>
              )}
              <label className="text-xs font-medium space-y-1">تفاصيل التعبئة (§20)
                <select className={inputCls} value={packagingDetails ? "ON" : "OFF"} onChange={(e) => setPackagingDetails(e.target.value === "ON")}>
                  <option value="ON">مفعّلة — عرض الكراتين والحبات</option>
                  <option value="OFF">معطلة — الكمية الأساسية فقط</option>
                </select>
              </label>
              <label className="text-xs font-medium space-y-1">
                رقم القائمة — إدخال قائمة قديمة (اختياري)
                <input
                  type="text"
                  className={inputCls}
                  dir="ltr"
                  value={customNumber}
                  onChange={(e) => setCustomNumber(e.target.value)}
                  placeholder="مثال: INV-2026-000001"
                  maxLength={40}
                />
                <span className="text-[10px] text-muted-foreground block">اتركه فارغًا للترقيم التلقائي — اكتب رقم قائمة مطبوعة سابقًا لتسجيلها بنفس رقمها</span>
              </label>
            </div>

            {/* ---- POS walk-in quick bar (Phase 46) ---- */}
            <div className="flex flex-wrap items-center gap-2 rounded-lg border bg-muted/40 p-2">
              <span className="text-xs font-semibold text-muted-foreground px-1">بيع سريع:</span>
              <Button type="button" size="sm" variant={isWalkinSale ? "default" : "outline"} onClick={() => walkin && setCustId(walkin.id)}>
                🚶 زبون نقدي {walkin ? `(${walkin.code})` : ""}
              </Button>
              <Button type="button" size="sm" variant="outline" onClick={() => setShowQuickCreate((v) => !v)}>
                <Plus className="w-3.5 h-3.5" /> إنشاء عميل
              </Button>
              {selectedCustomer && (
                <Badge variant={isWalkinSale ? "secondary" : "outline"} className="text-[10px]">
                  {isWalkinSale ? "WALK-IN · نقدي فقط" : "عميل مسجل"}
                </Badge>
              )}
              {isWalkinSale && (
                <span className="text-[11px] text-muted-foreground">بيانات المتردد اختيارية — لا تؤخر البيع (§23)</span>
              )}
            </div>

            {/* ---- quick create inline (Phase 46: بلا مغادرة الشاشة) ---- */}
            {showQuickCreate && (
              <div className="rounded-lg border p-3 space-y-2 bg-background">
                <div className="grid gap-2 sm:grid-cols-4">
                  <Input placeholder="اسم العميل *" value={quickCreate.name} onChange={(e) => setQuickCreate((q) => ({ ...q, name: e.target.value }))} />
                  <Input placeholder="الهاتف (اختياري)" dir="ltr" value={quickCreate.phone} onChange={(e) => setQuickCreate((q) => ({ ...q, phone: e.target.value }))} />
                  <Input placeholder="حد ائتماني (اختياري)" type="number" dir="ltr" value={quickCreate.credit_limit || ""} onChange={(e) => setQuickCreate((q) => ({ ...q, credit_limit: Number(e.target.value) || 0 }))} />
                  <Button
                    type="button"
                    disabled={quickCreate.name.trim().length < 2}
                    onClick={async () => {
                      const { res, body } = await api<{ id: number; name: string }>("/api/v1/customers", {
                        method: "POST",
                        body: JSON.stringify({ name: quickCreate.name.trim(), phone: quickCreate.phone || undefined, credit_limit: quickCreate.credit_limit }),
                      });
                      if (body.success && body.data) {
                        toast.success(`أُنشئ العميل ${body.data.name}`);
                        setCustomers((cs) => [...cs, { id: body.data!.id, name: body.data!.name, credit_limit: quickCreate.credit_limit, customer_type: "REGISTERED", is_walkin: false }]);
                        setCustId(body.data.id);
                        setQuickCreate({ name: "", phone: "", credit_limit: 0 });
                        setShowQuickCreate(false);
                      } else {
                        toast.error(body.message ?? "تعذر إنشاء العميل");
                      }
                      void res;
                    }}
                  >
                    حفظ واختيار
                  </Button>
                </div>
              </div>
            )}

            {/* ---- walk-in optional info (Phase 23) ---- */}
            {isWalkinSale && (
              <div className="grid gap-2 sm:grid-cols-3">
                <label className="text-xs font-medium space-y-1">اسم الزبون (اختياري)
                  <Input className="h-9" value={walkinInfo.name} onChange={(e) => setWalkinInfo((w) => ({ ...w, name: e.target.value }))} placeholder="يُطبع على الفاتورة" />
                </label>
                <label className="text-xs font-medium space-y-1">هاتف الزبون (اختياري)
                  <Input className="h-9" dir="ltr" value={walkinInfo.phone} onChange={(e) => setWalkinInfo((w) => ({ ...w, phone: e.target.value }))} />
                </label>
                <label className="text-xs font-medium space-y-1">العنوان (اختياري)
                  <Input className="h-9" value={walkinInfo.address} onChange={(e) => setWalkinInfo((w) => ({ ...w, address: e.target.value }))} />
                </label>
              </div>
            )}

            {/* ---- بطاقة العميل + الرصيد السابق (§2/§3) ---- */}
            {cust && (
              <div className="rounded-lg border bg-muted/30 p-3 grid gap-3 lg:grid-cols-3">
                <div className="space-y-1 text-sm lg:col-span-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <UserCheck className="w-4 h-4 text-primary" />
                    <span className="font-bold">{cust.name}</span>
                    <Badge variant={CUSTOMER_STATUS[cust.status]?.variant ?? "secondary"} className="text-[10px]">
                      {CUSTOMER_STATUS[cust.status]?.label ?? cust.status}
                    </Badge>
                    <span className="text-xs text-muted-foreground" dir="ltr">#{cust.code}</span>
                  </div>
                  <div className="text-xs text-muted-foreground grid gap-0.5 sm:grid-cols-2">
                    {cust.shop_name && <div>المحل: {cust.shop_name}</div>}
                    {cust.phone && <div dir="auto">هاتف: {cust.phone}{cust.whatsapp ? ` · واتساب: ${cust.whatsapp}` : ""}</div>}
                    {cust.area && <div>المنطقة: {cust.area}</div>}
                    {cust.address && <div>العنوان: {cust.address}</div>}
                  </div>
                  {preview?.mini_statement && (preview.mini_statement.last_invoice || preview.mini_statement.last_payment) && (
                    <div className="text-[11px] text-muted-foreground border-t pt-1 mt-1 space-y-0.5">
                      {preview.mini_statement.last_invoice && (
                        <div>آخر فاتورة: <span className="font-mono" dir="ltr">{preview.mini_statement.last_invoice.number}</span> · {formatDateTime(preview.mini_statement.last_invoice.date)} · {money(preview.mini_statement.last_invoice.total)}</div>
                      )}
                      {preview.mini_statement.last_payment && (
                        <div>آخر دفعة: {money(preview.mini_statement.last_payment.amount)} · {formatDateTime(preview.mini_statement.last_payment.date)}</div>
                      )}
                    </div>
                  )}
                </div>
                <div className="space-y-1 text-sm">
                  <div className={`flex justify-between rounded-md px-2 py-1.5 ${cust.no_debt ? "bg-success/10" : "bg-amber-500/10"}`}>
                    <span className="text-muted-foreground">الرصيد السابق:</span>
                    <span dir="ltr" className={`font-bold ${cust.no_debt ? "text-success" : "text-amber-600"}`}>{money(previousBalance)}</span>
                  </div>
                  {cust.no_debt && <div className="text-[11px] text-success">حساب العميل: لا توجد ذمة سابقة (§5)</div>}
                  {creditLimit > 0 && (
                    <>
                      <div className="flex justify-between text-xs px-2"><span className="text-muted-foreground">حد الائتمان:</span><span dir="ltr">{money(creditLimit)}</span></div>
                      <div className="flex justify-between text-xs px-2"><span className="text-muted-foreground">المتاح للبيع الآجل:</span><span dir="ltr">{money(Math.max(0, creditLimit - previousBalance))}</span></div>
                    </>
                  )}
                </div>
              </div>
            )}

            {/* ---- تحذير الحد الائتماني (§6) ---- */}
            {creditExceeded && (
              <div className={`rounded-lg border px-3 py-2 text-sm ${creditPolicy === "APPROVAL" ? "border-amber-300 bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-300" : "border-destructive/40 bg-destructive/10 text-destructive"}`}>
                <div className="flex items-center gap-2 font-semibold">
                  <AlertTriangle className="w-4 h-4" />
                  سيؤدي اعتماد هذه الفاتورة إلى تجاوز الحد الائتماني للعميل
                </div>
                <div className="text-xs mt-1">
                  الحد: {money(creditLimit)} · الرصيد الجديد المتوقع: {money(newBalance)}
                  {creditPolicy === "APPROVAL"
                    ? " — ستُحفظ الفاتورة «بانتظار موافقة الإدارة» دون خصم مخزون أو تحديث ذمة حتى الاعتماد."
                    : " — سيمنع الخادم العملية (CREDIT_001) ما لم تقلّل المبلغ أو حوّلها إلى نقدية."}
                </div>
              </div>
            )}

            {/* ---- الباركود ---- */}
            <div className="flex items-center gap-2 flex-wrap">
              <div className="relative">
                <ScanBarcode className="w-4 h-4 absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  ref={barcodeRef}
                  onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addByBarcode(); } }}
                  className={inputCls + " pr-8 w-64"}
                  dir="ltr"
                  placeholder="امسح الباركود ثم Enter (أو اكتب الكود)"
                />
              </div>
              <span className="text-[11px] text-muted-foreground">يضيف الصنف للفاتورة فورًا — مناسب لقارئ الباركود</span>
            </div>

            {/* ---- بنود الفاتورة مع العبوات (§7-§19) ---- */}
            <div className="rounded-lg border overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-xs text-muted-foreground">
                  <tr>
                    <th className="p-2 font-medium min-w-52">المنتج</th>
                    <th className="p-2 font-medium w-24">الوحدة</th>
                    <th className="p-2 font-medium w-24">الكمية</th>
                    <th className="p-2 font-medium w-24">العبوات</th>
                    <th className="p-2 font-medium w-24">عدد الكارتون</th>
                    <th className="p-2 font-medium w-24">عدد الحبات</th>
                    <th className="p-2 font-medium w-28">سعر الكارتون</th>
                    <th className="p-2 font-medium w-28">سعر الحبه</th>
                    <th className="p-2 font-medium w-28">الخصم</th>
                    <th className="p-2 font-medium w-28">الاجمالي</th>
                    <th className="p-2 w-10"></th>
                  </tr>
                </thead>
                <tbody>
                  {lines.map((l) => {
                    const packed = hasPack(l);
                    const p = productById(l.product_id);
                    const stockInfo = l.product_id !== "" ? preview?.packages?.[String(l.product_id)] : undefined;
                    return (
                      <tr key={l.key} className="border-t align-top">
                        <td className="p-2">
                          <SearchSelect
                            value={l.product_id === "" ? "" : String(l.product_id)}
                            onChange={(v) => setLine(l.key, { product_id: v ? Number(v) : "" })}
                            placeholder="— اكتب اسم المنتج أو كوده —"
                            options={products.map((p) => ({
                              value: String(p.id),
                              label: `${p.name}${p.pack_unit && p.pack_qty ? ` (${p.pack_unit} = ${Number(p.pack_qty)} ${p.unit})` : ""}`,
                              hint: p.stock_total > 0 ? `متاح ${p.stock_total} ${p.unit}` : "غير متوفر",
                            }))}
                          />
                          {l.product_id !== "" && (stockInfo?.has_pack ? (
                            <div className="text-[11px] text-sky-700 dark:text-sky-400 mt-1 flex items-start gap-1" title={`حالة العبوات في ${preview?.warehouse?.name ?? "المستودع"}`}>
                              <Package className="w-3 h-3 mt-0.5 shrink-0" />
                              <span>
                                المتاح: {qtyWord(stockInfo.closed_packages ?? 0, stockInfo.pack_unit)} كاملة + {qtyWord(stockInfo.open_packages ?? 0, stockInfo.pack_unit)} مفتوحة ({qtyWord(stockInfo.open_qty ?? 0, p?.unit)} منفصلة) — الإجمالي {qtyWord(stockInfo.total_pieces ?? 0, p?.unit)}
                              </span>
                            </div>
                          ) : (
                            <div className="text-[11px] text-sky-700 dark:text-sky-400 mt-1 flex items-start gap-1">
                              <Package className="w-3 h-3 mt-0.5 shrink-0" />
                              <span>المتاح: {qtyWord(stockInfo?.total_pieces ?? p?.stock_total ?? 0, p?.unit)}</span>
                            </div>
                          ))}
                          {stockInfo?.has_pack && baseQty(l) > (stockInfo.total_pieces ?? 0) && (
                            <div className="text-[11px] text-destructive mt-0.5">الكمية تتجاوز المتاح ({qtyWord(stockInfo.total_pieces ?? 0, p?.unit)}) — فعّل «الصرف رغم النقص» أسفل الجدول أو سيُرفض STOCK_001</div>
                          )}
                          {!stockInfo?.has_pack && l.product_id !== "" && baseQty(l) > (p?.stock_total ?? 0) && (
                            <div className="text-[11px] text-destructive mt-0.5">الكمية تتجاوز المتاح ({p?.stock_total}) — فعّل «الصرف رغم النقص» أو سيُرفض STOCK_001</div>
                          )}
                        </td>
                        <td className="p-2 text-center">
                          <div className="font-medium pt-1.5">{p?.unit ?? "—"}</div>
                          {packed && p && (
                            <div className="text-[10px] text-muted-foreground mt-0.5 whitespace-nowrap">1 {sameUnit(p.pack_unit, p.unit) ? "عبوة" : (p.pack_unit ?? "عبوة")} = {packQtyOf(l)} {p.unit}</div>
                          )}
                        </td>
                        <td className="p-2 text-center pt-3">
                          {p && baseQty(l) > 0 ? <span className="font-medium">{qtyWord(baseQty(l), p.unit)}</span> : <span className="text-muted-foreground">—</span>}
                        </td>
                        <td className="p-2 text-center pt-3">
                          {packed && p && baseQty(l) > 0 ? (
                            <span className="font-medium">{qtyWord(Math.floor(baseQty(l) / Math.max(1, packQtyOf(l))), sameUnit(p.pack_unit, p.unit) ? "عبوة" : (p.pack_unit ?? "عبوة"))}</span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                        <td className="p-2">
                          {packed ? (
                            <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={String(l.pkg_qty)} onChange={(e) => setLine(l.key, { pkg_qty: e.target.value === "" ? "" : Number(e.target.value) })} placeholder="0" />
                          ) : (
                            <div className="text-center text-muted-foreground pt-2" title="هذا المنتج يُباع بالوحدة الأساسية فقط — بلا تعبئة كراتين">—</div>
                          )}
                        </td>
                        <td className="p-2">
                          <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={String(l.loose_qty)} onChange={(e) => setLine(l.key, { loose_qty: e.target.value === "" ? "" : Number(e.target.value) })} placeholder="0" />
                        </td>
                        <td className="p-2">
                          {packed ? (
                            <>
                              <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={String(toDisplay(l.pack_price))} onChange={(e) => setLine(l.key, { pack_price: e.target.value === "" ? "" : fromDisplay(Number(e.target.value)) })} />
                              {num(l.pkg_qty) > 0 && (
                                <div className="text-[10px] text-muted-foreground mt-1">
                                  {qtyWord(num(l.pkg_qty), p?.pack_unit)} × {money(num(l.pack_price))} = <span className="font-medium" dir="ltr">{money(decNum(dec(num(l.pkg_qty)).mul(num(l.pack_price))))}</span>
                                </div>
                              )}
                            </>
                          ) : (
                            <div className="text-center text-muted-foreground pt-2">—</div>
                          )}
                        </td>
                        <td className="p-2">
                          <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={String(toDisplay(l.piece_price))} onChange={(e) => setLine(l.key, { piece_price: e.target.value === "" ? "" : fromDisplay(Number(e.target.value)) })} />
                          {num(l.loose_qty) > 0 && (
                            <div className="text-[10px] text-muted-foreground mt-1">
                              {qtyWord(num(l.loose_qty), p?.unit)} × {money(num(l.piece_price))} = <span className="font-medium" dir="ltr">{money(decNum(dec(num(l.loose_qty)).mul(num(l.piece_price))))}</span>
                            </div>
                          )}
                        </td>
                        <td className="p-2 space-y-1">
                          <input type="number" min="0" max="100" step="any" className={inputCls} dir="ltr" placeholder="%" title="خصم بالنسبة المئوية" value={String(l.discount_pct)} onChange={(e) => setLine(l.key, { discount_pct: e.target.value === "" ? "" : Number(e.target.value) })} />
                          <input type="number" min="0" step="any" className={inputCls} dir="ltr" placeholder={currency === "USD" ? "$" : "د.ع"} title="خصم بمبلغ ثابت" value={String(toDisplay(l.discount_amount))} onChange={(e) => setLine(l.key, { discount_amount: e.target.value === "" ? "" : fromDisplay(Number(e.target.value)) })} />
                        </td>
                        <td className="p-2 font-semibold" dir="ltr">
                          {money(lineTotal(l))}
                          {p && baseQty(l) > 0 && (
                            <div className="text-[10px] font-normal text-muted-foreground mt-0.5" dir="rtl">
                              = {qtyWord(baseQty(l), p.unit)}
                            </div>
                          )}
                        </td>
                        <td className="p-2">
                          <Button type="button" variant="ghost" size="sm" onClick={() => removeLine(l.key)} disabled={lines.length === 1} aria-label="حذف البند">
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <div className="p-2 border-t">
                <Button type="button" variant="outline" size="sm" onClick={addLine}><Plus className="w-4 h-4" /> إضافة بند</Button>
              </div>
            </div>

            {/* ---- ملاحظات الفاتورة — ظاهرة مباشرة عند الإنشاء ---- */}
            <label className="text-xs font-medium space-y-1 block">
              ملاحظات الفاتورة <span className="font-normal text-muted-foreground">(تظهر على نسخة العميل — اختياري)</span>
              <textarea
                className={inputCls + " min-h-16 py-2"}
                value={invoiceNotes}
                maxLength={500}
                onChange={(e) => setInvoiceNotes(e.target.value)}
                placeholder="مثال: التسليم صباح الخميس — التجميع مع الفاتورة السابقة"
              />
            </label>

            {/* ---- الصرف رغم نقص المخزون — تجاوز STOCK_001 لهذه الفاتورة ---- */}
            <label
              className={`flex items-center gap-2 text-xs rounded-md border px-3 py-2 cursor-pointer select-none ${
                stockShort
                  ? "border-amber-300 bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-300"
                  : "text-muted-foreground"
              }`}
            >
              <input type="checkbox" checked={allowNegative} onChange={(e) => setAllowNegative(e.target.checked)} className="accent-primary" />
              <span>
                السماح بالصرف رغم نقص المخزون — تُخصم الكمية ويصبح رصيد المنتج سالبًا (يُدوّن في التدقيق){stockShort ? " — بند حالي يتجاوز المتاح!" : ""}
              </span>
            </label>

            {/* ---- لوحة الرصيد المفصولة (§4/§21/§23) ---- */}
            <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
              <div className="rounded-lg border p-3 space-y-1.5 text-sm min-w-72 bg-muted/20">
                <div className="text-xs font-semibold text-muted-foreground border-b pb-1 mb-1">ملخص الحساب — فصل الرصيد السابق عن الفاتورة</div>
                <div className="flex justify-between"><span className="text-muted-foreground">الرصيد السابق:</span><span dir="ltr" className="font-semibold">{money(previousBalance)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">مبيعات حالية (الفاتورة):</span><span dir="ltr" className="font-semibold">{money(grandTotal)}</span></div>
                {discountTotal > 0 && <div className="flex justify-between text-xs"><span className="text-muted-foreground">منها خصومات:</span><span dir="ltr">− {money(discountTotal)}</span></div>}
                <div className="flex justify-between border-t pt-1.5 text-base font-bold">
                  <span>الإجمالي المستحق:</span><span dir="ltr" className="text-primary">{money(totalDue)}</span>
                </div>
                {currency === "USD" && rate > 0 && (
                  <div className="flex justify-between text-[11px] text-muted-foreground">
                    <span>المكافئ بالدينار (سعر {rate.toLocaleString("en-US")}):</span><span dir="ltr">{formatIQD(totalDue)}</span>
                  </div>
                )}
                {type === "CREDIT" ? (
                  <label className="block space-y-1 pt-1">
                    <span className="text-xs text-muted-foreground">المدفوع الآن {currency === "USD" ? "($)" : "(د.ع)"} (جزئي أو صفر):</span>
                    <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={String(toDisplay(paidInput))} onChange={(e) => setPaidInput(e.target.value === "" ? "" : fromDisplay(Number(e.target.value)))} placeholder="0" />
                  </label>
                ) : (
                  <div className="flex justify-between"><span className="text-muted-foreground">المدفوع:</span><span dir="ltr" className="font-semibold">{money(paidNow)}</span></div>
                )}
                <div className="flex justify-between"><span className="text-muted-foreground">المتبقي من الفاتورة:</span><span dir="ltr">{money(dueAmount)}</span></div>
                <div className="flex justify-between border-t pt-1.5 text-base font-bold">
                  <span>الرصيد الجديد:</span><span dir="ltr" className={newBalance > 0 ? "text-amber-600" : "text-success"}>{money(newBalance)}</span>
                </div>
                <div className="flex justify-between text-xs pt-1">
                  <span className="text-muted-foreground">نوع البيع:</span>
                  <Badge variant={effectiveSaleType === "CASH" ? "success" : effectiveSaleType === "PARTIAL" ? "accent" : "navy"} className="text-[10px]">
                    {SALE_TYPE_LABEL[effectiveSaleType]}
                  </Badge>
                </div>
                {type === "CREDIT" && cust && (
                  <div className="text-[11px] text-muted-foreground flex items-center gap-1 pt-1">
                    <Wallet className="w-3 h-3" /> المتاح بعد الفاتورة: {money(Math.max(0, creditLimit - newBalance))}
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <div className="flex gap-2">
                  <Button type="button" variant="outline" onClick={printDraft} className="h-11" title="طباعة نسخة مسودة قبل الترحيل">
                    <Printer className="w-4 h-4" /> طباعة مسودة
                  </Button>
                  <Button type="button" variant="outline" onClick={cancelDraft} className="h-11 text-destructive hover:text-destructive" title="مسح النموذج بالكامل">
                    <Ban className="w-4 h-4" /> إلغاء الفاتورة
                  </Button>
                </div>
                <Button type="submit" size="lg" disabled={saving} className="min-w-40 h-11 w-full lg:w-auto">
                  {saving ? "جارٍ الترحيل..." : "ترحيل الفاتورة"}
                </Button>
              </div>
            </div>

            {/* ---- المستلم والملاحظات (§36/§40) ---- */}
            <details className="rounded-lg border p-3 text-sm">
              <summary className="cursor-pointer text-xs font-semibold text-muted-foreground">بيانات المستلم والملاحظات التفصيلية (اختياري)</summary>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 mt-3">
                <label className="text-xs font-medium space-y-1">اسم المستلم
                  <Input name="receiver_name" className="h-9" placeholder="اختياري" />
                </label>
                <label className="text-xs font-medium space-y-1">هاتف المستلم
                  <Input name="receiver_phone" className="h-9" dir="ltr" placeholder="07XX..." />
                </label>
                <label className="text-xs font-medium space-y-1 flex items-end gap-2 text-muted-foreground">
                  <CalendarClock className="w-4 h-4" /> توقيع العميل والمندوب يُسجل عند التسليم من تبويب الفواتير
                </label>
                <label className="text-xs font-medium space-y-1">ملاحظات المندوب
                  <Input name="rep_notes" className="h-9" placeholder="يراه المندوب والإدارة" />
                </label>
                <label className="text-xs font-medium space-y-1">ملاحظات الإدارة
                  <Input name="admin_notes" className="h-9" placeholder="داخلية — لا تُطبع" />
                </label>
              </div>
            </details>
          </form>
        </CardContent>
      </Card>

      {/* ---- نتيجة الترحيل ---- */}
      {result && (
        <Card className="border-primary/40">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <ShieldQuestion className="w-4 h-4 text-primary" />
              نتيجة الفاتورة <span dir="ltr" className="font-mono">{result.number}</span>
              {result.requires_approval
                ? <Badge variant="accent" className="text-[10px]">بانتظار موافقة الإدارة</Badge>
                : <Badge variant="success" className="text-[10px]">معتمدة</Badge>}
            </CardTitle>
            <CardDescription>
              {result.requires_approval
                ? "تجاوز الحد الائتماني بسياسة الموافقة — لن يُخصم المخزون ولا يُحدَّث الرصيد حتى يعتمدها المدير"
                : "كل الأرقام مرتبطة بالحركات الفعلية: المخزون، العبوات، الذمة (§47)"}
            </CardDescription>
          </CardHeader>
          <CardContent className="grid gap-2 text-sm sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-md bg-muted/40 px-3 py-2"><div className="text-[11px] text-muted-foreground">قيمة الفاتورة</div><div dir="ltr" className="font-bold">{money(result.grand_total)}</div></div>
            <div className="rounded-md bg-muted/40 px-3 py-2"><div className="text-[11px] text-muted-foreground">الرصيد السابق</div><div dir="ltr" className="font-semibold">{money(result.previous_balance)}</div></div>
            <div className="rounded-md bg-muted/40 px-3 py-2"><div className="text-[11px] text-muted-foreground">المدفوع / المتبقي</div><div dir="ltr" className="font-semibold">{money(result.paid_amount)} / {money(result.due_amount)}</div></div>
            <div className="rounded-md bg-amber-500/10 px-3 py-2"><div className="text-[11px] text-muted-foreground">الرصيد الجديد للعميل</div><div dir="ltr" className="font-bold text-amber-600">{money(result.new_balance)}</div></div>
            {result.due_date && <div className="text-xs text-muted-foreground lg:col-span-2">تاريخ الاستحقاق: {formatDateTime(result.due_date)}</div>}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
