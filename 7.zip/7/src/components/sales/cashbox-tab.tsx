"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { api } from "@/lib/client-api";
import { formatDateTime, formatIQD } from "@/lib/utils";
import { Coins, Wallet, ArrowLeftRight, Landmark, CalendarClock, RefreshCw, FileText, ScrollText, ListChecks, Banknote, Plus, QrCode, Printer, ReceiptText, Search, X, Loader2, Zap, Pencil, LockOpen, Scale, History, UserCheck, BellRing, FileBarChart, Activity, AlertTriangle, Send } from "lucide-react";

// =====================================================================
// Types
// =====================================================================
interface Cashbox {
  id: number; code: string; name: string; balance: number;
  is_active: boolean; type?: string; status?: string; currency?: string;
  description?: string | null;
  branch?: { name: string };
}
interface PaymentRow {
  id: number; number: string; payment_date: string;
  total_amount: number; cash_amount?: number | null;
  card_amount?: number | null; bank_amount?: number | null;
  on_account_amount?: number | null;
  payment_method: string; status: string;
  customer?: { id: number; name: string } | null;
  supplier?: { id: number; name: string } | null;
}
interface ReceiptRow {
  id: number; number: string; receiptDate: string; recipientName: string;
  amount: number; paymentMethod: string; status: string; referenceNumber?: string | null;
  customer?: { id: number; name: string; code: string } | null; supplier?: { id: number; name: string; code: string } | null;
  cashbox?: { id: number; name: string } | null;
}
interface VoucherRow {
  id: number; number: string; paymentDate: string; beneficiaryName: string;
  amount: number; reason: string; status: string; referenceNumber?: string | null;
  customer?: { id: number; name: string; code: string } | null; supplier?: { id: number; name: string; code: string } | null;
  cashbox?: { id: number; name: string; code: string; currency: string } | null;
}
interface CustomerOption { id: number; code: string; name: string; phone?: string | null; balance?: number }
interface SupplierOption { id: number; code: string; name: string; phone?: string | null; balance?: number }
interface CashboxOption { id: number; code: string; name: string; currency?: string }
interface OutstandingInvoice {
  id: number; number: string; invoice_date: string;
  grand_total: number; paid_amount: number; due_amount: number; age_days: number;
}
interface TransferRow {
  id: number; number: string; transferDate: string;
  amount: number; currency: string; status: string;
  fromCashbox?: { name: string } | null; toCashbox?: { name: string } | null;
}
interface ClosingRow {
  id: number; number: string; closingDate: string;
  openingBalance: number; bookBalance: number; actualCash: number; difference: number;
  status: string;
  cashbox?: { name: string } | null;
}
interface StatementRow {
  date: string; kind: string; ref: string; description: string;
  debit: number; credit: number; running: number;
}
interface StatementData {
  customer?: { id: number; code: string; name: string; phone: string | null; balance: number; creditLimit: number; creditDays: number };
  supplier?: { id: number; code: string; name: string; phone: string | null; balance: number };
  rows: StatementRow[];
  totals: { debit: number; credit: number };
  closing_balance: number;
  opening_balance?: number;
}
interface AgingRow {
  customer_id?: number; supplier_id?: number;
  code: string; name: string; balance: number;
  buckets: { current: number; d1_30: number; d31_60: number; d61_90: number; d90_plus: number };
}
interface AgingData { rows: AgingRow[]; totals: { current: number; d1_30: number; d31_60: number; d61_90: number; d90_plus: number } }
interface BankAccount { id: number; code: string; name: string; bankName: string; accountNumber: string; currency: string; balance: number; status: string }
interface CheckRow {
  id: number; checkNumber: string; checkType: string; direction: string;
  beneficiaryName: string | null; amount: number; currency: string;
  issueDate: string; dueDate: string; status: string;
}
interface CashierShiftRow {
  id: number; number: string; cashier: string; cashbox: string;
  clockInAt: string; clockOutAt: string | null;
  openingBalance: number; closingBalance: number | null;
  totalReceipts: number; totalPayments: number; transactionsCount: number; status: string;
}
interface RecurringExpenseRow {
  id: number; name: string; amount: number; currency: string; frequency: string;
  nextRunAt: string; status: string;
}
interface ExpenseCategoryRow { id: number; code: string; name: string; type: string; monthlyBudget: number | null }

const n = (v: number) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(v);
const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";

// =====================================================================
// Main tab component
// =====================================================================
export function CashboxTab() {
  const [sub, setSub] = React.useState("cashboxes");

  return (
    <div className="space-y-4">
      <Tabs value={sub} onValueChange={setSub} dir="rtl">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="cashboxes" className="text-xs"><Wallet className="w-4 h-4 ml-1" /> الصناديق</TabsTrigger>
          <TabsTrigger value="receipts" className="text-xs"><FileText className="w-4 h-4 ml-1" /> وصولات القبض</TabsTrigger>
          <TabsTrigger value="vouchers" className="text-xs"><ScrollText className="w-4 h-4 ml-1" /> وصولات الصرف</TabsTrigger>
          <TabsTrigger value="transfers" className="text-xs"><ArrowLeftRight className="w-4 h-4 ml-1" /> تحويلات</TabsTrigger>
          <TabsTrigger value="payments" className="text-xs"><Banknote className="w-4 h-4 ml-1" /> سجل الدفعات</TabsTrigger>
          <TabsTrigger value="banks" className="text-xs"><Landmark className="w-4 h-4 ml-1" /> البنوك والشيكات</TabsTrigger>
          <TabsTrigger value="shifts" className="text-xs"><CalendarClock className="w-4 h-4 ml-1" /> ورديات الكاشير</TabsTrigger>
          <TabsTrigger value="recurring" className="text-xs"><RefreshCw className="w-4 h-4 ml-1" /> مصروفات متكررة</TabsTrigger>
          <TabsTrigger value="closing" className="text-xs"><ListChecks className="w-4 h-4 ml-1" /> إغلاق وجرد</TabsTrigger>
          <TabsTrigger value="statement" className="text-xs"><FileText className="w-4 h-4 ml-1" /> كشف حساب</TabsTrigger>
          <TabsTrigger value="aging" className="text-xs"><Coins className="w-4 h-4 ml-1" /> أعمار الديون</TabsTrigger>
          {/* v15 — new panels */}
          <TabsTrigger value="rep-settlements" className="text-xs"><UserCheck className="w-4 h-4 ml-1" /> تسليمات المندوبين</TabsTrigger>
          <TabsTrigger value="overdue" className="text-xs"><BellRing className="w-4 h-4 ml-1" /> الديون المتأخرة</TabsTrigger>
          <TabsTrigger value="budget" className="text-xs"><Activity className="w-4 h-4 ml-1" /> الموازنة</TabsTrigger>
          <TabsTrigger value="audit" className="text-xs"><FileBarChart className="w-4 h-4 ml-1" /> تدقيق مالي</TabsTrigger>
        </TabsList>

        <TabsContent value="cashboxes"><CashboxesPanel /></TabsContent>
        <TabsContent value="receipts"><ReceiptsPanel /></TabsContent>
        <TabsContent value="vouchers"><VouchersPanel /></TabsContent>
        <TabsContent value="transfers"><TransfersPanel /></TabsContent>
        <TabsContent value="payments"><PaymentsPanel /></TabsContent>
        <TabsContent value="banks"><BanksPanel /></TabsContent>
        <TabsContent value="shifts"><ShiftsPanel /></TabsContent>
        <TabsContent value="recurring"><RecurringPanel /></TabsContent>
        <TabsContent value="closing"><ClosingPanel /></TabsContent>
        <TabsContent value="statement"><StatementPanel /></TabsContent>
        <TabsContent value="aging"><AgingPanel /></TabsContent>
        {/* v15 — new panels */}
        <TabsContent value="rep-settlements"><RepSettlementsPanel /></TabsContent>
        <TabsContent value="overdue"><OverdueNotificationsPanel /></TabsContent>
        <TabsContent value="budget"><BudgetVsActualPanel /></TabsContent>
        <TabsContent value="audit"><FinanceAuditPanel /></TabsContent>
      </Tabs>
    </div>
  );
}

// =====================================================================
// 1) Cashboxes panel
// =====================================================================
function CashboxesPanel() {
  const [rows, setRows] = React.useState<Cashbox[] | null>(null);
  const [showForm, setShowForm] = React.useState(false);
  const [editing, setEditing] = React.useState<Cashbox | null>(null);
  const [reconcileTarget, setReconcileTarget] = React.useState<Cashbox | null>(null);
  const [showTxFor, setShowTxFor] = React.useState<Cashbox | null>(null);

  const load = React.useCallback(async () => {
    const { body } = await api<Cashbox[]>("/api/v1/finance/cashboxes");
    if (body.success && body.data) setRows(body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const branchId = Number(fd.get("branch_id"));
    const payload = {
      code: String(fd.get("code")),
      name: String(fd.get("name")),
      branch_id: branchId,
      type: String(fd.get("type") || "BRANCH"),
      currency: String(fd.get("currency") || "IQD"),
      opening_balance: Number(fd.get("opening_balance") || 0),
      description: String(fd.get("description") || undefined),
    };
    const { body } = await api("/api/v1/finance/cashboxes", { method: "POST", body: JSON.stringify(payload) });
    if (body.success) {
      toast.success("تم إنشاء الصندوق ✓");
      setShowForm(false);
      await load();
    } else toast.error(body.message ?? "فشل الإنشاء");
  }

  async function saveEdit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!editing) return;
    const fd = new FormData(e.currentTarget);
    const payload: Record<string, unknown> = {};
    const name = String(fd.get("name") ?? "").trim();
    if (name) payload.name = name;
    const description = String(fd.get("description") ?? "").trim();
    payload.description = description || null;
    const type = String(fd.get("type") ?? "");
    if (type) payload.type = type;
    const status = String(fd.get("status") ?? "");
    if (status) payload.status = status;
    const isActive = fd.get("is_active") === "on";
    payload.isActive = isActive;

    const { body } = await api(`/api/v1/finance/cashboxes/${editing.id}`, { method: "PATCH", body: JSON.stringify(payload) });
    if (body.success) {
      toast.success("تم تحديث الصندوق ✓");
      setEditing(null);
      await load();
    } else toast.error(body.message ?? "فشل التحديث");
  }

  async function reopenCashbox(c: Cashbox) {
    const reason = window.prompt(`سبب فتح الصندوق «${c.name}»؟`);
    if (!reason) return;
    const { body } = await api(`/api/v1/finance/cashboxes/${c.id}/reopen`, {
      method: "POST",
      body: JSON.stringify({ reason }),
    });
    if (body.success) {
      toast.success("تم فتح الصندوق ✓");
      await load();
    } else toast.error(body.message ?? "فشل الفتح");
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-base"><Wallet className="w-4 h-4 text-primary" /> صناديق النقدية</CardTitle>
            <CardDescription>كل صندوق مرتبط بفرع وله رصيد متحرك + نوع (MAIN/BRANCH/REP/CUSTOM/BANK) — الرصيد مشتق من دفتر الحركة ولا يُعدّل يدويًا</CardDescription>
          </div>
          <Button size="sm" onClick={() => setShowForm((v) => !v)}><Plus className="w-4 h-4" /> صندوق جديد</Button>
        </div>
      </CardHeader>
      <CardContent>
        {showForm && (
          <form onSubmit={submit} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 mb-4 p-3 rounded-lg border bg-muted/30">
            <label className="text-xs space-y-1">الكود<input name="code" required className={inputCls} placeholder="CASH-001" /></label>
            <label className="text-xs space-y-1">الاسم<input name="name" required className={inputCls} placeholder="الصندوق الرئيسي" /></label>
            <label className="text-xs space-y-1">رقم الفرع<input name="branch_id" type="number" required className={inputCls} defaultValue={1} /></label>
            <label className="text-xs space-y-1">النوع
              <select name="type" className={inputCls}>
                <option value="MAIN">MAIN</option>
                <option value="BRANCH">BRANCH</option>
                <option value="REP">REP</option>
                <option value="CUSTOM">CUSTOM</option>
                <option value="BANK">BANK</option>
              </select>
            </label>
            <label className="text-xs space-y-1">العملة
              <select name="currency" className={inputCls}><option>IQD</option><option>USD</option></select>
            </label>
            <label className="text-xs space-y-1">رصيد افتتاحي<input name="opening_balance" type="number" step="0.0001" defaultValue={0} className={inputCls} /></label>
            <label className="text-xs space-y-1 lg:col-span-2">وصف<input name="description" className={inputCls} /></label>
            <div className="lg:col-span-4 flex justify-end gap-2">
              <Button type="button" variant="ghost" size="sm" onClick={() => setShowForm(false)}>إلغاء</Button>
              <Button type="submit" size="sm">حفظ</Button>
            </div>
          </form>
        )}

        {editing && (
          <form onSubmit={saveEdit} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 mb-4 p-3 rounded-lg border bg-amber-50/50 dark:bg-amber-950/20">
            <div className="lg:col-span-4 text-xs font-medium text-amber-700 dark:text-amber-300">تعديل الصندوق «{editing.name}» ({editing.code}) — الرصيد غير قابل للتعديل المباشر</div>
            <label className="text-xs space-y-1">الاسم<input name="name" defaultValue={editing.name} required className={inputCls} /></label>
            <label className="text-xs space-y-1">النوع
              <select name="type" defaultValue={editing.type ?? "BRANCH"} className={inputCls}>
                <option value="MAIN">MAIN</option>
                <option value="BRANCH">BRANCH</option>
                <option value="REP">REP</option>
                <option value="CUSTOM">CUSTOM</option>
                <option value="BANK">BANK</option>
              </select>
            </label>
            <label className="text-xs space-y-1">الحالة
              <select name="status" defaultValue={editing.status ?? "ACTIVE"} className={inputCls}>
                <option value="ACTIVE">ACTIVE</option>
                <option value="SUSPENDED">SUSPENDED</option>
              </select>
            </label>
            <label className="text-xs space-y-1 flex items-center gap-2 pt-4">
              <input type="checkbox" name="is_active" defaultChecked={editing.is_active} className="w-4 h-4" />
              نشط
            </label>
            <label className="text-xs space-y-1 lg:col-span-4">وصف<input name="description" defaultValue={editing.description ?? ""} className={inputCls} /></label>
            <div className="lg:col-span-4 flex justify-end gap-2">
              <Button type="button" variant="ghost" size="sm" onClick={() => setEditing(null)}>إلغاء</Button>
              <Button type="submit" size="sm">حفظ التعديل</Button>
            </div>
          </form>
        )}

        {!rows ? <div className="py-6 text-center text-muted-foreground">جارٍ التحميل...</div> :
          rows.length === 0 ? <div className="py-6 text-center text-muted-foreground">لا صناديق</div> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>الكود</TableHead><TableHead>الاسم</TableHead><TableHead>النوع</TableHead>
              <TableHead>العملة</TableHead><TableHead className="text-left">الرصيد</TableHead>
              <TableHead>الحالة</TableHead><TableHead className="text-left">إجراءات</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell dir="ltr" className="font-mono text-xs text-right">{r.code}</TableCell>
                  <TableCell className="text-sm font-medium">{r.name}</TableCell>
                  <TableCell><Badge variant="secondary" className="text-[10px]">{r.type ?? "BRANCH"}</Badge></TableCell>
                  <TableCell>{r.currency ?? "IQD"}</TableCell>
                  <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(r.balance)}</TableCell>
                  <TableCell>{r.is_active ? <Badge variant="success" className="text-[10px]">نشط</Badge> : <Badge variant="destructive" className="text-[10px]">معطل</Badge>}</TableCell>
                  <TableCell className="text-left">
                    <div className="flex gap-1 justify-end">
                      <Button size="sm" variant="ghost" className="h-7 w-7 p-0" title="تعديل" onClick={() => setEditing(r)}>
                        <Pencil className="w-3.5 h-3.5" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-7 w-7 p-0" title="حركة الصندوق" onClick={() => setShowTxFor(r)}>
                        <History className="w-3.5 h-3.5" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-7 w-7 p-0" title="تسوية/جرد" onClick={() => setReconcileTarget(r)}>
                        <Scale className="w-3.5 h-3.5" />
                      </Button>
                      {r.status === "CLOSED" && (
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-emerald-600" title="فتح الصندوق" onClick={() => reopenCashbox(r)}>
                          <LockOpen className="w-3.5 h-3.5" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>}

        {reconcileTarget && (
          <ReconcileModal cashbox={reconcileTarget} onClose={() => setReconcileTarget(null)} onDone={() => { setReconcileTarget(null); load(); }} />
        )}
        {showTxFor && (
          <CashboxTransactionsModal cashbox={showTxFor} onClose={() => setShowTxFor(null)} />
        )}
      </CardContent>
    </Card>
  );
}

// =====================================================================
// 1b) ReconcileModal — POST /cashboxes/[id]/reconcile (المرحلة 67)
// =====================================================================
function ReconcileModal({ cashbox, onClose, onDone }: { cashbox: Cashbox; onClose: () => void; onDone: () => void }) {
  const [saving, setSaving] = React.useState(false);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSaving(true);
    try {
      const fd = new FormData(e.currentTarget);
      const payload: Record<string, unknown> = { notes: String(fd.get("notes") ?? "") };
      const actual = Number(fd.get("actual_cash"));
      if (!Number.isNaN(actual) && actual >= 0) payload.actualCash = actual;
      const { body } = await api(`/api/v1/finance/cashboxes/${cashbox.id}/reconcile`, {
        method: "POST",
        body: JSON.stringify(payload),
      });
      if (body.success) {
        const d = body.data as { number: string; book_balance: number; actual_cash: number; difference: number; status: string };
        toast.success(
          `تمت التسوية ✓ ${d.number} — دفتر: ${formatIQD(d.book_balance)} | فعلي: ${formatIQD(d.actual_cash)} | الفرق: ${formatIQD(d.difference)}`
        );
        onDone();
      } else toast.error(body.message ?? "فشلت التسوية");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <Card className="w-full max-w-lg">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2"><Scale className="w-4 h-4" /> تسوية / جرد الصندوق</CardTitle>
            <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={onClose}><X className="w-4 h-4" /></Button>
          </div>
          <CardDescription>{cashbox.name} ({cashbox.code}) — يُنشئ سجل DRAFT بلا إغلاق</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-3">
            <label className="text-xs space-y-1 block">النقد الفعلي المعدود (IQD)
              <input name="actual_cash" type="number" step="0.0001" min="0" required className={inputCls} dir="ltr" />
            </label>
            <label className="text-xs space-y-1 block">ملاحظات
              <textarea name="notes" rows={2} className={inputCls} placeholder="اختياري" />
            </label>
            <div className="text-xs text-muted-foreground bg-muted/40 p-2 rounded">
              سيُحسب الرصيد الدفتري تلقائيًا (افتتاحي + مقبوضات − مدفوعات + تحويلات داخلة − خارجة) ويُقارن بالفعلي. النتيجة تُحفظ بسجل DRAFT يمكنك ترقيته لإغلاق لاحقًا.
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="ghost" size="sm" onClick={onClose}>إلغاء</Button>
              <Button type="submit" size="sm" disabled={saving}>{saving ? "جارٍ الحساب..." : "تنفيذ التسوية"}</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

// =====================================================================
// 1c) CashboxTransactionsModal — GET /cashboxes/[id]/transactions
// =====================================================================
function CashboxTransactionsModal({ cashbox, onClose }: { cashbox: Cashbox; onClose: () => void }) {
  const [data, setData] = React.useState<{
    total: number; rows: Array<{
      id: number; direction: string; category: string; transaction_type: string | null;
      transaction_number: string | null; amount: number; balance_after: number;
      balance_before: number | null; note: string | null; is_reversed: boolean;
      customer: { id: number; name: string } | null; supplier: { id: number; name: string } | null;
      created_at: string;
    }>
  } | null>(null);

  React.useEffect(() => {
    api<{ total: number; rows: unknown[] }>(`/api/v1/finance/cashboxes/${cashbox.id}/transactions?limit=50`)
      .then(({ body }) => {
        if (body.success && body.data) setData(body.data as never);
      });
  }, [cashbox.id]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <Card className="w-full max-w-4xl max-h-[85vh] flex flex-col">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2"><History className="w-4 h-4" /> دفتر حركة الصندوق</CardTitle>
            <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={onClose}><X className="w-4 h-4" /></Button>
          </div>
          <CardDescription>{cashbox.name} ({cashbox.code}) — آخر 50 حركة</CardDescription>
        </CardHeader>
        <CardContent className="overflow-y-auto flex-1">
          {!data ? <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div> :
            data.rows.length === 0 ? <div className="py-8 text-center text-muted-foreground">لا حركات</div> :
            <Table>
              <TableHeader><TableRow>
                <TableHead>الوقت</TableHead><TableHead>النوع</TableHead><TableHead>الطرف</TableHead>
                <TableHead>رقم الحركة</TableHead><TableHead className="text-left">المبلغ</TableHead>
                <TableHead className="text-left">الرصيد بعدها</TableHead><TableHead>البيان</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {data.rows.map((t) => (
                  <TableRow key={t.id}>
                    <TableCell className="text-xs">{formatDateTime(t.created_at)}</TableCell>
                    <TableCell>
                      <Badge variant={t.direction === "IN" ? "success" : "destructive"} className="text-[10px]">
                        {t.direction === "IN" ? "وارد" : "صادر"}{t.is_reversed ? " (معكوس)" : ""}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs">{t.customer?.name ?? t.supplier?.name ?? "—"}</TableCell>
                    <TableCell dir="ltr" className="font-mono text-[10px]">{t.transaction_number ?? "—"}</TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">
                      {t.direction === "IN" ? "+" : "−"}{formatIQD(t.amount)}
                    </TableCell>
                    <TableCell className="text-left text-xs" dir="ltr">{formatIQD(t.balance_after)}</TableCell>
                    <TableCell className="text-xs text-muted-foreground max-w-48 truncate">{t.note ?? ""}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>}
        </CardContent>
      </Card>
    </div>
  );
}

// =====================================================================
// 1d) PaymentsPanel — GET /finance/payments (سجل الدفعات الموحدة UPAY-)
// =====================================================================
function PaymentsPanel() {
  const [data, setData] = React.useState<{ rows: PaymentRow[]; total: number } | null>(null);
  const [search, setSearch] = React.useState("");
  const [statusFilter, setStatusFilter] = React.useState("");
  const [methodFilter, setMethodFilter] = React.useState("");

  const load = React.useCallback(async () => {
    const params = new URLSearchParams({ per_page: "100" });
    if (search) params.set("search", search);
    if (statusFilter) params.set("status", statusFilter);
    if (methodFilter) params.set("payment_method", methodFilter);
    const { body } = await api<{ rows: PaymentRow[]; total: number }>(`/api/v1/finance/payments?${params}`);
    if (body.success && body.data) setData(body.data);
  }, [search, statusFilter, methodFilter]);
  React.useEffect(() => { load(); }, [load]);

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><Banknote className="w-4 h-4 text-primary" /> سجل الدفعات الموحدة (UPAY-2026-)</CardTitle>
        <CardDescription>كل دفعة مرتبطة بوصل قبض/صرف + تخصيصها على الفواتير — مع دعم الدفع المختلط (نقد + بطاقة + تحويل + آجل)</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-3 flex-wrap">
          <input
            placeholder="بحث برقم الدفعة / المرجع / الوصف..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-9 flex-1 min-w-[200px] rounded-md border bg-background px-3 text-sm"
          />
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className={inputCls + " w-32"}>
            <option value="">كل الحالات</option>
            <option value="POSTED">POSTED</option>
            <option value="CANCELLED">CANCELLED</option>
          </select>
          <select value={methodFilter} onChange={(e) => setMethodFilter(e.target.value)} className={inputCls + " w-40"}>
            <option value="">كل الطرق</option>
            <option value="CASH">نقد</option>
            <option value="CARD">بطاقة</option>
            <option value="BANK_TRANSFER">تحويل بنكي</option>
            <option value="MIXED">مختلط</option>
            <option value="ON_ACCOUNT">آجل</option>
          </select>
        </div>

        {!data ? <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div> :
          data.rows.length === 0 ? <div className="py-8 text-center text-muted-foreground">لا دفعات</div> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>رقم الدفعة</TableHead><TableHead>التاريخ</TableHead><TableHead>الطرف</TableHead>
              <TableHead>الطريقة</TableHead><TableHead className="text-left">الإجمالي</TableHead>
              <TableHead className="text-left">المخصص</TableHead><TableHead className="text-left">غير المخصص</TableHead>
              <TableHead>الحالة</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {data.rows.map((p) => {
                const allocated = (p.cash_amount || 0) + (p.card_amount || 0) + (p.bank_amount || 0) + (p.on_account_amount || 0);
                return (
                  <TableRow key={p.id}>
                    <TableCell dir="ltr" className="font-mono text-[10px]">{p.number}</TableCell>
                    <TableCell className="text-xs">{formatDateTime(p.payment_date)}</TableCell>
                    <TableCell className="text-xs">{p.customer?.name ?? p.supplier?.name ?? "—"}</TableCell>
                    <TableCell><Badge variant="secondary" className="text-[10px]">{p.payment_method}</Badge></TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(p.total_amount)}</TableCell>
                    <TableCell className="text-left text-xs" dir="ltr">{formatIQD(allocated)}</TableCell>
                    <TableCell className="text-left text-xs" dir="ltr">{formatIQD(p.total_amount - allocated)}</TableCell>
                    <TableCell>{p.status === "POSTED" ? <Badge variant="success" className="text-[10px]">مرحّل</Badge> : <Badge variant="destructive" className="text-[10px]">ملغى</Badge>}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>}
      </CardContent>
    </Card>
  );
}

// =====================================================================
// 2) Receipts panel — with search + inline new-receipt form
// =====================================================================
function ReceiptsPanel() {
  const [rows, setRows] = React.useState<ReceiptRow[] | null>(null);
  const [search, setSearch] = React.useState("");
  const [statusFilter, setStatusFilter] = React.useState<string>("");
  const [dateFrom, setDateFrom] = React.useState<string>("");
  const [dateTo, setDateTo] = React.useState<string>("");
  const [showNew, setShowNew] = React.useState(false);

  const load = React.useCallback(async () => {
    setRows(null);
    const params = new URLSearchParams();
    params.set("per_page", "100");
    if (search.trim()) params.set("search", search.trim());
    if (statusFilter) params.set("status", statusFilter);
    if (dateFrom) params.set("date_from", dateFrom);
    if (dateTo) params.set("date_to", dateTo);
    const { body } = await api<ReceiptRow[]>("/api/v1/finance/receipts?" + params.toString());
    if (body.success && body.data) setRows(body.data);
  }, [search, statusFilter, dateFrom, dateTo]);

  React.useEffect(() => { load(); }, [load]);

  async function cancel(id: number) {
    const reason = window.prompt("سبب الإلغاء؟");
    if (!reason) return;
    const { body } = await api(`/api/v1/finance/receipts/${id}/cancel`, { method: "POST", body: JSON.stringify({ reason }) });
    if (body.success) { toast.success("تم إلغاء الوصل ✓"); await load(); }
    else toast.error(body.message ?? "فشل الإلغاء");
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div>
            <CardTitle className="flex items-center gap-2 text-base"><FileText className="w-4 h-4 text-primary" /> وصولات القبض</CardTitle>
            <CardDescription>كل وصل قبض يُرقّم RCPT-YYYY-NNNNNN — مرتبط برصيد العميل/المورد</CardDescription>
          </div>
          <Button size="sm" onClick={() => setShowNew(true)}><Plus className="w-4 h-4" /> وصل قبض جديد</Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap items-end gap-2 mb-3">
          <label className="text-xs space-y-1">
            بحث (رقم/اسم/مرجع)
            <div className="relative">
              <Search className="absolute right-2 top-2.5 w-4 h-4 text-muted-foreground" />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث..." className="pr-8 w-56" />
            </div>
          </label>
          <label className="text-xs space-y-1">الحالة
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className={inputCls + " w-32"}>
              <option value="">— الكل —</option>
              <option value="POSTED">ساري</option>
              <option value="CANCELLED">ملغى</option>
            </select>
          </label>
          <label className="text-xs space-y-1">من تاريخ
            <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-40" />
          </label>
          <label className="text-xs space-y-1">إلى تاريخ
            <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-40" />
          </label>
          <Button size="sm" variant="outline" onClick={load}><Search className="w-4 h-4" /> بحث</Button>
          {(search || statusFilter || dateFrom || dateTo) && (
            <Button size="sm" variant="ghost" onClick={() => { setSearch(""); setStatusFilter(""); setDateFrom(""); setDateTo(""); }}><X className="w-4 h-4" /> مسح</Button>
          )}
        </div>

        {!rows ? <div className="py-6 text-center text-muted-foreground">جارٍ التحميل...</div> :
          rows.length === 0 ? <div className="py-6 text-center text-muted-foreground">لا وصولات مطابقة</div> :
          <div className="max-h-[480px] overflow-y-auto scroll-thin">
            <Table>
              <TableHeader><TableRow>
                <TableHead>الرقم</TableHead><TableHead>التاريخ</TableHead><TableHead>المستلم</TableHead>
                <TableHead>الصندوق</TableHead><TableHead className="text-left">المبلغ</TableHead>
                <TableHead>الطريقة</TableHead><TableHead>الحالة</TableHead><TableHead></TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell dir="ltr" className="font-mono text-xs text-right">{r.number}</TableCell>
                    <TableCell className="text-xs">{formatDateTime(r.receiptDate)}</TableCell>
                    <TableCell className="text-sm">{r.customer?.name ?? r.supplier?.name ?? r.recipientName}</TableCell>
                    <TableCell className="text-xs">{r.cashbox?.name ?? "—"}</TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(r.amount)}</TableCell>
                    <TableCell><Badge variant="secondary" className="text-[10px]">{r.paymentMethod}</Badge></TableCell>
                    <TableCell>{r.status === "POSTED" ? <Badge variant="success" className="text-[10px]">ساري</Badge> : <Badge variant="destructive" className="text-[10px]">ملغى</Badge>}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        {r.status === "POSTED" && (
                          <>
                            <a href={"/api/v1/finance/receipts/" + r.id + "/pdf"} target="_blank" title="طباعة A4 PDF">
                              <Button size="sm" variant="ghost" className="h-7 w-7 p-0"><Printer className="w-3.5 h-3.5" /></Button>
                            </a>
                            <a href={"/api/v1/finance/receipts/" + r.id + "/thermal"} target="_blank" title="طباعة حرارية 80mm">
                              <Button size="sm" variant="ghost" className="h-7 w-7 p-0"><ReceiptText className="w-3.5 h-3.5" /></Button>
                            </a>
                            {/* v15 Phase 12-14 — ESC/POS raw bytes for direct thermal printers */}
                            <a href={"/api/v1/finance/receipts/" + r.id + "/escpos"} target="_blank" title="ESC/POS أوامر مباشرة للطابعة الحرارية">
                              <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-emerald-600"><Zap className="w-3.5 h-3.5" /></Button>
                            </a>
                            <a href={"/api/v1/finance/receipts/" + r.id + "/qr"} target="_blank" title="QR">
                              <Button size="sm" variant="ghost" className="h-7 w-7 p-0"><QrCode className="w-3.5 h-3.5" /></Button>
                            </a>
                            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-red-600" onClick={() => cancel(r.id)}>إلغاء</Button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>}

        {showNew && <NewReceiptForm onClose={() => setShowNew(false)} onDone={() => { setShowNew(false); load(); }} />}
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------
// New receipt form — inline modal linked to customer/supplier balance
// ---------------------------------------------------------------------
function NewReceiptForm({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [customers, setCustomers] = React.useState<CustomerOption[]>([]);
  const [suppliers, setSuppliers] = React.useState<SupplierOption[]>([]);
  const [cashboxes, setCashboxes] = React.useState<CashboxOption[]>([]);
  const [actorType, setActorType] = React.useState<"customer" | "supplier">("customer");
  const [actorId, setActorId] = React.useState<number | "">("");
  const [cashboxId, setCashboxId] = React.useState<number | "">("");
  const [amount, setAmount] = React.useState<number | "">("");
  const [paymentMethod, setPaymentMethod] = React.useState<string>("CASH");
  const [referenceNumber, setReferenceNumber] = React.useState("");
  const [receivedBy, setReceivedBy] = React.useState("");
  const [notes, setNotes] = React.useState("");
  const [outstanding, setOutstanding] = React.useState<OutstandingInvoice[]>([]);
  const [allocations, setAllocations] = React.useState<Record<number, number>>({});
  const [saving, setSaving] = React.useState(false);
  const [partySearch, setPartySearch] = React.useState("");

  React.useEffect(() => {
    (async () => {
      const [c, s, cb] = await Promise.all([
        api<CustomerOption[]>(`/api/v1/customers?per_page=100${partySearch ? "&q=" + encodeURIComponent(partySearch) : ""}`),
        api<SupplierOption[]>(`/api/v1/suppliers${partySearch ? "?q=" + encodeURIComponent(partySearch) : ""}`),
        api<CashboxOption[]>(`/api/v1/finance/cashboxes`),
      ]);
      if (c.body.success && c.body.data) setCustomers(c.body.data);
      if (s.body.success && s.body.data) setSuppliers(s.body.data);
      if (cb.body.success && cb.body.data) { setCashboxes(cb.body.data); if (cb.body.data.length === 1) setCashboxId(cb.body.data[0].id); }
    })();
  }, [partySearch]);

  // Load outstanding invoices when a customer is selected
  React.useEffect(() => {
    if (actorType !== "customer" || !actorId) { setOutstanding([]); setAllocations({}); return; }
    (async () => {
      const { body } = await api<{ rows: OutstandingInvoice[]; total_due: number }>(`/api/v1/finance/customers/${actorId}/outstanding`);
      if (body.success && body.data) setOutstanding(body.data.rows);
    })();
  }, [actorType, actorId]);

  function fifoAllocate(total: number) {
    if (!total) { setAllocations({}); return; }
    let remaining = total;
    const out: Record<number, number> = {};
    for (const inv of outstanding) {
      if (remaining <= 0) break;
      const alloc = Math.min(remaining, inv.due_amount);
      if (alloc > 0) { out[inv.id] = Number(alloc.toFixed(2)); remaining -= alloc; }
    }
    setAllocations(out);
  }

  const allocatedTotal = Object.values(allocations).reduce((s, x) => s + x, 0);
  const advance = Math.max(0, (typeof amount === "number" ? amount : 0) - allocatedTotal);
  const selectedActor = actorType === "customer"
    ? customers.find((c) => c.id === actorId)
    : suppliers.find((s) => s.id === actorId);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!actorId) return toast.error("اختر العميل أو المورد");
    if (!cashboxId) return toast.error("اختر الصندوق");
    const amt = typeof amount === "number" ? amount : 0;
    if (amt <= 0) return toast.error("أدخل مبلغًا صحيحًا");
    setSaving(true);
    try {
      const allocationsArr = Object.entries(allocations)
        .filter(([, v]) => v > 0)
        .map(([invId, amt2]) => ({ invoiceId: Number(invId), invoiceType: "SALES" as const, amount: amt2 }));
      const payload: any = {
        cashbox_id: cashboxId,
        branch_id: 1,
        amount: amt,
        payment_method: paymentMethod,
        reference_number: referenceNumber || null,
        received_by: receivedBy || null,
        notes: notes || null,
        idempotency_key: `rcpt-${actorId}-${Date.now()}`,
      };
      if (actorType === "customer") payload.customer_id = actorId;
      else payload.supplier_id = actorId;
      if (allocationsArr.length) payload.allocations = allocationsArr;
      const { body } = await api<{ number?: string }>("/api/v1/finance/receipts", { method: "POST", body: JSON.stringify(payload) });
      if (body.success) {
        toast.success(`تم حفظ الوصل ${body.data?.number ?? ""} ✓`);
        onDone();
      } else toast.error(body.message ?? "فشل حفظ الوصل");
    } finally { setSaving(false); }
  }

  return (
    <div className="fixed inset-0 z-[80] bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
      <Card className="w-[min(96vw,1100px)] max-h-[90vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
        <CardHeader className="pb-3 border-b">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-base"><Plus className="w-4 h-4 text-emerald-600" /> وصل قبض جديد</CardTitle>
              <CardDescription>يرتبط برصيد العميل/المورد — يخصّص المبلغ على الفواتير (FIFO) أو يُسجّل كدفعة مقدمة</CardDescription>
            </div>
            <Button size="sm" variant="ghost" onClick={onClose}>✕</Button>
          </div>
        </CardHeader>
        <CardContent className="overflow-y-auto scroll-thin">
          <form onSubmit={submit} className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-4">
              <label className="text-xs space-y-1">النوع
                <select value={actorType} onChange={(e) => { setActorType(e.target.value as "customer" | "supplier"); setActorId(""); setOutstanding([]); setAllocations({}); }} className={inputCls}>
                  <option value="customer">عميل</option>
                  <option value="supplier">مورد</option>
                </select>
              </label>
              <label className="text-xs space-y-1">البحث عن {actorType === "customer" ? "عميل" : "مورد"}
                <Input value={partySearch} onChange={(e) => setPartySearch(e.target.value)} placeholder="اسم/كود/هاتف" className="w-full" />
              </label>
              <label className="text-xs space-y-1">{actorType === "customer" ? "العميل" : "المورد"}
                <select value={actorId} onChange={(e) => setActorId(e.target.value === "" ? "" : Number(e.target.value))} className={inputCls} required>
                  <option value="">— اختر —</option>
                  {(actorType === "customer" ? customers : suppliers).map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.code} — {p.name}{p.balance ? ` (رصيد: ${formatIQD(Number(p.balance))})` : ""}
                    </option>
                  ))}
                </select>
              </label>
              <label className="text-xs space-y-1">الصندوق
                <select value={cashboxId} onChange={(e) => setCashboxId(e.target.value === "" ? "" : Number(e.target.value))} className={inputCls} required>
                  <option value="">— اختر —</option>
                  {cashboxes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </label>
            </div>

            <div className="grid gap-3 sm:grid-cols-4">
              <label className="text-xs space-y-1">المبلغ (د.ع)
                <Input type="number" step="0.0001" value={amount} onChange={(e) => setAmount(e.target.value === "" ? "" : Number(e.target.value))} required />
              </label>
              <label className="text-xs space-y-1">طريقة الدفع
                <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)} className={inputCls}>
                  <option value="CASH">نقدي</option>
                  <option value="CARD">بطاقة</option>
                  <option value="BANK_TRANSFER">تحويل بنكي</option>
                  <option value="ELECTRONIC">إلكتروني</option>
                  <option value="ON_ACCOUNT">على الحساب</option>
                </select>
              </label>
              <label className="text-xs space-y-1">رقم مرجعي
                <Input value={referenceNumber} onChange={(e) => setReferenceNumber(e.target.value)} placeholder="رقم الشيك/الإيصال" />
              </label>
              <label className="text-xs space-y-1">استلم منه
                <Input value={receivedBy} onChange={(e) => setReceivedBy(e.target.value)} placeholder="اسم المستلم" />
              </label>
            </div>

            {selectedActor && (
              <div className="rounded-lg border p-2 bg-muted/30 text-sm flex flex-wrap gap-4">
                <span>الرصيد الحالي: <span dir="ltr" className="font-bold text-amber-600">{formatIQD(Number(selectedActor.balance ?? 0))}</span></span>
                <span>المبلغ المُدخل: <span dir="ltr" className="font-bold">{formatIQD(typeof amount === "number" ? amount : 0)}</span></span>
                <span>الرصيد بعد التحصيل: <span dir="ltr" className="font-bold text-emerald-600">{formatIQD(Number(selectedActor.balance ?? 0) - (typeof amount === "number" ? amount : 0))}</span></span>
              </div>
            )}

            {actorType === "customer" && outstanding.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-2">
                <Button type="button" size="sm" variant="outline" onClick={() => fifoAllocate(typeof amount === "number" ? amount : 0)}><Zap className="w-3.5 h-3.5" /> FIFO تلقائي</Button>
                <Button type="button" size="sm" variant="ghost" onClick={() => setAllocations({})}>مسح التخصيص</Button>
              </div>
            )}

            {actorType === "customer" && outstanding.length > 0 && (
              <div className="rounded-lg border max-h-[220px] overflow-y-auto scroll-thin">
                <Table>
                  <TableHeader><TableRow>
                    <TableHead>الفاتورة</TableHead><TableHead>التاريخ</TableHead>
                    <TableHead className="text-left">الإجمالي</TableHead><TableHead className="text-left">المدفوع</TableHead>
                    <TableHead className="text-left">المتبقي</TableHead><TableHead>العمر</TableHead>
                    <TableHead className="text-left">تخصيص</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {outstanding.map((inv) => (
                      <TableRow key={inv.id}>
                        <TableCell dir="ltr" className="font-mono text-xs text-right">{inv.number}</TableCell>
                        <TableCell className="text-xs">{inv.invoice_date}</TableCell>
                        <TableCell className="text-left" dir="ltr">{n(inv.grand_total)}</TableCell>
                        <TableCell className="text-left" dir="ltr">{n(inv.paid_amount)}</TableCell>
                        <TableCell className="text-left font-semibold text-amber-600" dir="ltr">{n(inv.due_amount)}</TableCell>
                        <TableCell className="text-xs">{inv.age_days} يوم</TableCell>
                        <TableCell className="text-left">
                          <Input type="number" step="0.0001" value={allocations[inv.id] ?? ""} max={inv.due_amount}
                            onChange={(e) => {
                              const v = e.target.value === "" ? 0 : Math.min(Number(e.target.value), inv.due_amount);
                              setAllocations((prev) => ({ ...prev, [inv.id]: v }));
                            }} className="h-8 w-28" />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}

            {actorType === "customer" && (
              <div className="flex items-center justify-between rounded-lg bg-muted/30 px-3 py-2 text-sm">
                <span>المُخصَّص: <span dir="ltr" className="font-semibold">{formatIQD(allocatedTotal)}</span></span>
                <span>المتبقي كدفعة مقدمة: <span dir="ltr" className="font-bold text-emerald-600">{formatIQD(advance)}</span></span>
              </div>
            )}

            <label className="text-xs space-y-1 block">ملاحظات
              <textarea value={notes} onChange={(e) => setNotes(e.target.value)} className={inputCls + " min-h-[40px]"} placeholder="ملاحظات اختيارية" />
            </label>

            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={onClose}>إلغاء</Button>
              <Button type="submit" disabled={saving}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} حفظ الوصل
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

// =====================================================================
// 3) Payment vouchers panel — with search + inline new-voucher form
// =====================================================================
function VouchersPanel() {
  const [rows, setRows] = React.useState<VoucherRow[] | null>(null);
  const [search, setSearch] = React.useState("");
  const [statusFilter, setStatusFilter] = React.useState<string>("");
  const [reasonFilter, setReasonFilter] = React.useState<string>("");
  const [dateFrom, setDateFrom] = React.useState<string>("");
  const [dateTo, setDateTo] = React.useState<string>("");
  const [showNew, setShowNew] = React.useState(false);

  const load = React.useCallback(async () => {
    setRows(null);
    const params = new URLSearchParams();
    params.set("per_page", "100");
    if (search.trim()) params.set("search", search.trim());
    if (statusFilter) params.set("status", statusFilter);
    if (reasonFilter) params.set("reason", reasonFilter);
    if (dateFrom) params.set("date_from", dateFrom);
    if (dateTo) params.set("date_to", dateTo);
    const { body } = await api<VoucherRow[]>("/api/v1/finance/payment-vouchers?" + params.toString());
    if (body.success && body.data) setRows(body.data);
  }, [search, statusFilter, reasonFilter, dateFrom, dateTo]);

  React.useEffect(() => { load(); }, [load]);

  async function cancel(id: number) {
    const reason = window.prompt("سبب الإلغاء؟");
    if (!reason) return;
    const { body } = await api(`/api/v1/finance/payment-vouchers/${id}/cancel`, { method: "POST", body: JSON.stringify({ reason }) });
    if (body.success) { toast.success("تم إلغاء الوصل ✓"); await load(); }
    else toast.error(body.message ?? "فشل الإلغاء");
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div>
            <CardTitle className="flex items-center gap-2 text-base"><ScrollText className="w-4 h-4 text-primary" /> وصولات الصرف</CardTitle>
            <CardDescription>كل وصل صرف يُرقّم PAY-YYYY-NNNNNN — مرتبط برصيد المورد/العميل + المصروف النقدي والمحمَّل</CardDescription>
          </div>
          <Button size="sm" onClick={() => setShowNew(true)}><Plus className="w-4 h-4" /> وصل صرف جديد</Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap items-end gap-2 mb-3">
          <label className="text-xs space-y-1">بحث (رقم/اسم/مرجع)
            <div className="relative">
              <Search className="absolute right-2 top-2.5 w-4 h-4 text-muted-foreground" />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث..." className="pr-8 w-56" />
            </div>
          </label>
          <label className="text-xs space-y-1">الحالة
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className={inputCls + " w-32"}>
              <option value="">— الكل —</option>
              <option value="POSTED">ساري</option>
              <option value="CANCELLED">ملغى</option>
            </select>
          </label>
          <label className="text-xs space-y-1">السبب
            <select value={reasonFilter} onChange={(e) => setReasonFilter(e.target.value)} className={inputCls + " w-44"}>
              <option value="">— الكل —</option>
              <option value="PAYMENT_TO_SUPPLIER">دفع لمورد</option>
              <option value="EXPENSE">مصروف</option>
              <option value="ADVANCE">سلفة</option>
              <option value="DIRECT_PURCHASE">شراء مباشر</option>
              <option value="REFUND">رد مبلغ</option>
              <option value="OPERATING_EXPENSE">مصاريف تشغيل</option>
              <option value="BANK_TRANSFER">تحويل بنكي</option>
              <option value="OTHER">أخرى</option>
            </select>
          </label>
          <label className="text-xs space-y-1">من تاريخ
            <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-40" />
          </label>
          <label className="text-xs space-y-1">إلى تاريخ
            <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-40" />
          </label>
          <Button size="sm" variant="outline" onClick={load}><Search className="w-4 h-4" /> بحث</Button>
          {(search || statusFilter || reasonFilter || dateFrom || dateTo) && (
            <Button size="sm" variant="ghost" onClick={() => { setSearch(""); setStatusFilter(""); setReasonFilter(""); setDateFrom(""); setDateTo(""); }}><X className="w-4 h-4" /> مسح</Button>
          )}
        </div>

        {!rows ? <div className="py-6 text-center text-muted-foreground">جارٍ التحميل...</div> :
          rows.length === 0 ? <div className="py-6 text-center text-muted-foreground">لا أواصل صرف مطابقة</div> :
          <div className="max-h-[480px] overflow-y-auto scroll-thin">
            <Table>
              <TableHeader><TableRow>
                <TableHead>الرقم</TableHead><TableHead>التاريخ</TableHead><TableHead>المستفيد</TableHead>
                <TableHead>الصندوق</TableHead><TableHead className="text-left">المبلغ</TableHead>
                <TableHead>السبب</TableHead><TableHead>الحالة</TableHead><TableHead></TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell dir="ltr" className="font-mono text-xs text-right">{r.number}</TableCell>
                    <TableCell className="text-xs">{formatDateTime(r.paymentDate)}</TableCell>
                    <TableCell className="text-sm">{r.customer?.name ?? r.supplier?.name ?? r.beneficiaryName}</TableCell>
                    <TableCell className="text-xs">{r.cashbox?.name ?? <Badge variant="accent" className="text-[10px]">محمَّل</Badge>}</TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(r.amount)}</TableCell>
                    <TableCell className="text-xs max-w-[200px] truncate" title={r.reason}>{r.reason}</TableCell>
                    <TableCell>{r.status === "POSTED" ? <Badge variant="success" className="text-[10px]">ساري</Badge> : <Badge variant="destructive" className="text-[10px]">ملغى</Badge>}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        {r.status === "POSTED" && (
                          <>
                            <a href={"/api/v1/finance/payment-vouchers/" + r.id + "/pdf"} target="_blank" title="طباعة A4 PDF">
                              <Button size="sm" variant="ghost" className="h-7 w-7 p-0"><Printer className="w-3.5 h-3.5" /></Button>
                            </a>
                            <a href={"/api/v1/finance/payment-vouchers/" + r.id + "/thermal"} target="_blank" title="طباعة حرارية 80mm">
                              <Button size="sm" variant="ghost" className="h-7 w-7 p-0"><ReceiptText className="w-3.5 h-3.5" /></Button>
                            </a>
                            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-red-600" onClick={() => cancel(r.id)}>إلغاء</Button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>}

        {showNew && <NewPaymentVoucherForm onClose={() => setShowNew(false)} onDone={() => { setShowNew(false); load(); }} />}
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------
// New payment voucher form — inline modal linked to supplier/customer balance
// ---------------------------------------------------------------------
function NewPaymentVoucherForm({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [customers, setCustomers] = React.useState<CustomerOption[]>([]);
  const [suppliers, setSuppliers] = React.useState<SupplierOption[]>([]);
  const [cashboxes, setCashboxes] = React.useState<CashboxOption[]>([]);
  const [actorType, setActorType] = React.useState<"supplier" | "customer" | "none">("supplier");
  const [actorId, setActorId] = React.useState<number | "">("");
  const [cashboxId, setCashboxId] = React.useState<number | "">("");
  const [amount, setAmount] = React.useState<number | "">("");
  const [paymentMethod, setPaymentMethod] = React.useState<string>("CASH");
  const [reason, setReason] = React.useState<string>("PAYMENT_TO_SUPPLIER");
  const [beneficiaryName, setBeneficiaryName] = React.useState("");
  const [referenceNumber, setReferenceNumber] = React.useState("");
  const [paidTo, setPaidTo] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [notes, setNotes] = React.useState("");
  const [saving, setSaving] = React.useState(false);
  const [partySearch, setPartySearch] = React.useState("");

  React.useEffect(() => {
    (async () => {
      const [c, s, cb] = await Promise.all([
        api<CustomerOption[]>(`/api/v1/customers?per_page=100${partySearch ? "&q=" + encodeURIComponent(partySearch) : ""}`),
        api<SupplierOption[]>(`/api/v1/suppliers${partySearch ? "?q=" + encodeURIComponent(partySearch) : ""}`),
        api<CashboxOption[]>(`/api/v1/finance/cashboxes`),
      ]);
      if (c.body.success && c.body.data) setCustomers(c.body.data);
      if (s.body.success && s.body.data) setSuppliers(s.body.data);
      if (cb.body.success && cb.body.data) { setCashboxes(cb.body.data); if (cb.body.data.length === 1) setCashboxId(cb.body.data[0].id); }
    })();
  }, [partySearch]);

  const selectedActor = actorType === "supplier"
    ? suppliers.find((s) => s.id === actorId)
    : customers.find((c) => c.id === actorId);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!cashboxId) return toast.error("اختر الصندوق");
    const amt = typeof amount === "number" ? amount : 0;
    if (amt <= 0) return toast.error("أدخل مبلغًا صحيحًا");
    setSaving(true);
    try {
      const payload: any = {
        cashbox_id: cashboxId,
        amount: amt,
        payment_method: paymentMethod,
        reason,
        beneficiary_name: beneficiaryName || selectedActor?.name || null,
        reference_number: referenceNumber || undefined,
        paid_to: paidTo || undefined,
        description: description || undefined,
        notes: notes || undefined,
        idempotency_key: `pay-${actorId || "exp"}-${Date.now()}`,
      };
      if (actorType === "supplier" && actorId) payload.supplier_id = actorId;
      else if (actorType === "customer" && actorId) payload.customer_id = actorId;
      const { body } = await api<{ number?: string }>("/api/v1/finance/payment-vouchers", { method: "POST", body: JSON.stringify(payload) });
      if (body.success) {
        toast.success(`تم حفظ الوصل ${body.data?.number ?? ""} ✓`);
        onDone();
      } else toast.error(body.message ?? "فشل حفظ الوصل");
    } finally { setSaving(false); }
  }

  return (
    <div className="fixed inset-0 z-[80] bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
      <Card className="w-[min(96vw,1100px)] max-h-[90vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
        <CardHeader className="pb-3 border-b">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-base"><Plus className="w-4 h-4 text-red-600" /> وصل صرف جديد</CardTitle>
              <CardDescription>يخصم من رصيد الصندوق ويرتبط برصيد المورد/العميل</CardDescription>
            </div>
            <Button size="sm" variant="ghost" onClick={onClose}>✕</Button>
          </div>
        </CardHeader>
        <CardContent className="overflow-y-auto scroll-thin">
          <form onSubmit={submit} className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-4">
              <label className="text-xs space-y-1">النوع
                <select value={actorType} onChange={(e) => { setActorType(e.target.value as "supplier" | "customer"); setActorId(""); }} className={inputCls}>
                  <option value="supplier">مورد</option>
                  <option value="customer">عميل</option>
                  <option value="none">مصروف (لا أحد)</option>
                </select>
              </label>
              <label className="text-xs space-y-1">البحث
                <Input value={partySearch} onChange={(e) => setPartySearch(e.target.value)} placeholder="اسم/كود/هاتف" disabled={actorType === "none"} />
              </label>
              <label className="text-xs space-y-1">{actorType === "supplier" ? "المورد" : "العميل"}
                <select value={actorId} onChange={(e) => setActorId(e.target.value === "" ? "" : Number(e.target.value))} className={inputCls} disabled={actorType === "none"}>
                  <option value="">— اختر —</option>
                  {(actorType === "supplier" ? suppliers : customers).map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.code} — {p.name}{p.balance ? ` (رصيد: ${formatIQD(Number(p.balance))})` : ""}
                    </option>
                  ))}
                </select>
              </label>
              <label className="text-xs space-y-1">الصندوق
                <select value={cashboxId} onChange={(e) => setCashboxId(e.target.value === "" ? "" : Number(e.target.value))} className={inputCls} required>
                  <option value="">— اختر —</option>
                  {cashboxes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </label>
            </div>

            <div className="grid gap-3 sm:grid-cols-4">
              <label className="text-xs space-y-1">المبلغ (د.ع)
                <Input type="number" step="0.0001" value={amount} onChange={(e) => setAmount(e.target.value === "" ? "" : Number(e.target.value))} required />
              </label>
              <label className="text-xs space-y-1">طريقة الدفع
                <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)} className={inputCls}>
                  <option value="CASH">نقدي</option>
                  <option value="CARD">بطاقة</option>
                  <option value="BANK_TRANSFER">تحويل بنكي</option>
                  <option value="ELECTRONIC">إلكتروني</option>
                </select>
              </label>
              <label className="text-xs space-y-1">السبب
                <select value={reason} onChange={(e) => setReason(e.target.value)} className={inputCls}>
                  <option value="PAYMENT_TO_SUPPLIER">دفع لمورد</option>
                  <option value="EXPENSE">مصروف</option>
                  <option value="ADVANCE">سلفة</option>
                  <option value="DIRECT_PURCHASE">شراء مباشر</option>
                  <option value="REFUND">رد مبلغ</option>
                  <option value="OPERATING_EXPENSE">مصاريف تشغيل</option>
                  <option value="BANK_TRANSFER">تحويل بنكي</option>
                  <option value="OTHER">أخرى</option>
                </select>
              </label>
              <label className="text-xs space-y-1">رقم مرجعي
                <Input value={referenceNumber} onChange={(e) => setReferenceNumber(e.target.value)} placeholder="رقم الشيك/الإيصال" />
              </label>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              <label className="text-xs space-y-1">المستفيد
                <Input value={beneficiaryName} onChange={(e) => setBeneficiaryName(e.target.value)} placeholder={selectedActor?.name ?? "اسم المستفيد"} />
              </label>
              <label className="text-xs space-y-1">استلمه
                <Input value={paidTo} onChange={(e) => setPaidTo(e.target.value)} placeholder="اسم المستلم" />
              </label>
            </div>

            {selectedActor && (
              <div className="rounded-lg border p-2 bg-muted/30 text-sm flex flex-wrap gap-4">
                <span>الرصيد الحالي: <span dir="ltr" className="font-bold text-amber-600">{formatIQD(Number(selectedActor.balance ?? 0))}</span></span>
                <span>المبلغ المُدخل: <span dir="ltr" className="font-bold">{formatIQD(typeof amount === "number" ? amount : 0)}</span></span>
                <span>الرصيد بعد الصرف: <span dir="ltr" className="font-bold text-red-600">{formatIQD(Number(selectedActor.balance ?? 0) + (typeof amount === "number" ? amount : 0))}</span></span>
              </div>
            )}

            <label className="text-xs space-y-1 block">الوصف
              <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="وصف مختصر للصرف" />
            </label>
            <label className="text-xs space-y-1 block">ملاحظات
              <textarea value={notes} onChange={(e) => setNotes(e.target.value)} className={inputCls + " min-h-[40px]"} placeholder="ملاحظات اختيارية" />
            </label>

            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={onClose}>إلغاء</Button>
              <Button type="submit" disabled={saving}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} حفظ الوصل
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

// =====================================================================
// 4) Transfers panel
// =====================================================================
function TransfersPanel() {
  const [rows, setRows] = React.useState<TransferRow[] | null>(null);
  const load = React.useCallback(async () => {
    const { body } = await api<TransferRow[]>("/api/v1/finance/cash-transfers?per_page=50");
    if (body.success && body.data) setRows(body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  async function cancel(id: number) {
    const reason = window.prompt("سبب الإلغاء؟");
    if (!reason) return;
    const { body } = await api(`/api/v1/finance/cash-transfers/${id}/cancel`, { method: "POST", body: JSON.stringify({ reason }) });
    if (body.success) { toast.success("تم إلغاء التحويل ✓"); await load(); }
    else toast.error(body.message ?? "فشل الإلغاء");
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><ArrowLeftRight className="w-4 h-4 text-primary" /> تحويلات الصناديق</CardTitle>
        <CardDescription>كل تحويل = وصل واحد (CASH-TRF-YYYY-NNNNNN) + حركتي نقد (OUT من المصدر + IN للوجهة)</CardDescription>
      </CardHeader>
      <CardContent>
        {!rows ? <div className="py-6 text-center text-muted-foreground">جارٍ التحميل...</div> :
          rows.length === 0 ? <div className="py-6 text-center text-muted-foreground">لا تحويلات</div> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>الرقم</TableHead><TableHead>التاريخ</TableHead><TableHead>من</TableHead><TableHead>إلى</TableHead>
              <TableHead className="text-left">المبلغ</TableHead><TableHead>الحالة</TableHead><TableHead></TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell dir="ltr" className="font-mono text-xs text-right">{r.number}</TableCell>
                  <TableCell className="text-xs">{formatDateTime(r.transferDate)}</TableCell>
                  <TableCell className="text-xs">{r.fromCashbox?.name ?? "—"}</TableCell>
                  <TableCell className="text-xs">{r.toCashbox?.name ?? "—"}</TableCell>
                  <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(r.amount)} {r.currency}</TableCell>
                  <TableCell>{r.status === "POSTED" ? <Badge variant="success" className="text-[10px]">ساري</Badge> : <Badge variant="destructive" className="text-[10px]">ملغى</Badge>}</TableCell>
                  <TableCell>
                    {r.status === "POSTED" && <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-red-600" onClick={() => cancel(r.id)}>إلغاء</Button>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>}
      </CardContent>
    </Card>
  );
}

// =====================================================================
// 5) Banks & Checks panel
// =====================================================================
function BanksPanel() {
  const [accounts, setAccounts] = React.useState<BankAccount[]>([]);
  const [checks, setChecks] = React.useState<CheckRow[]>([]);
  const [showAccount, setShowAccount] = React.useState(false);

  const load = React.useCallback(async () => {
    const [a, c] = await Promise.all([
      api<BankAccount[]>("/api/v1/finance/bank-accounts"),
      api<CheckRow[]>("/api/v1/finance/checks"),
    ]);
    if (a.body.success && a.body.data) setAccounts(a.body.data);
    if (c.body.success && c.body.data) setChecks(c.body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  async function submitAccount(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const { body } = await api("/api/v1/finance/bank-accounts", {
      method: "POST",
      body: JSON.stringify({
        code: String(fd.get("code")),
        name: String(fd.get("name")),
        bank_name: String(fd.get("bank_name")),
        account_number: String(fd.get("account_number")),
        currency: String(fd.get("currency") || "IQD"),
      }),
    });
    if (body.success) { toast.success("تم إضافة الحساب ✓"); setShowAccount(false); await load(); }
    else toast.error(body.message ?? "فشل");
  }

  async function clearCheck(id: number) {
    const cashboxId = window.prompt("رقم الصندوق للإيداع/السحب:") ?? "";
    if (!cashboxId) return;
    const { body } = await api(`/api/v1/finance/checks/${id}/clear`, {
      method: "POST",
      body: JSON.stringify({ cashbox_id: Number(cashboxId), branch_id: 1 }),
    });
    if (body.success) { toast.success("تمت تسوية الشيك ✓"); await load(); }
    else toast.error(body.message ?? "فشل");
  }
  async function bounceCheck(id: number) {
    const reason = window.prompt("سبب الارتداد:") ?? "";
    if (!reason) return;
    const { body } = await api(`/api/v1/finance/checks/${id}/bounce`, { method: "POST", body: JSON.stringify({ reason }) });
    if (body.success) { toast.success("تم تسجيل الارتداد ✓"); await load(); }
    else toast.error(body.message ?? "فشل");
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-base"><Landmark className="w-4 h-4 text-primary" /> الحسابات البنكية</CardTitle>
              <CardDescription>الحسابات المرتبطة بالشركات — رصيد متحرك لكل حساب</CardDescription>
            </div>
            <Button size="sm" onClick={() => setShowAccount(v => !v)}><Plus className="w-4 h-4" /> حساب جديد</Button>
          </div>
        </CardHeader>
        <CardContent>
          {showAccount && (
            <form onSubmit={submitAccount} className="grid gap-3 sm:grid-cols-3 lg:grid-cols-5 mb-4 p-3 rounded-lg border bg-muted/30">
              <label className="text-xs space-y-1">الكود<input name="code" required className={inputCls} /></label>
              <label className="text-xs space-y-1">الاسم<input name="name" required className={inputCls} /></label>
              <label className="text-xs space-y-1">البنك<input name="bank_name" required className={inputCls} /></label>
              <label className="text-xs space-y-1">رقم الحساب<input name="account_number" required className={inputCls} /></label>
              <label className="text-xs space-y-1">العملة<select name="currency" className={inputCls}><option>IQD</option><option>USD</option></select></label>
              <div className="sm:col-span-3 lg:col-span-5 flex justify-end"><Button type="submit" size="sm">حفظ</Button></div>
            </form>
          )}
          <Table>
            <TableHeader><TableRow>
              <TableHead>الكود</TableHead><TableHead>الحساب</TableHead><TableHead>البنك</TableHead>
              <TableHead>العملة</TableHead><TableHead className="text-left">الرصيد</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {accounts.map((a) => (
                <TableRow key={a.id}>
                  <TableCell dir="ltr" className="font-mono text-xs text-right">{a.code}</TableCell>
                  <TableCell className="text-sm">{a.name}</TableCell>
                  <TableCell className="text-xs">{a.bankName} · {a.accountNumber}</TableCell>
                  <TableCell>{a.currency}</TableCell>
                  <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(a.balance)}</TableCell>
                </TableRow>
              ))}
              {accounts.length === 0 && <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-4">لا حسابات بعد</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base"><Banknote className="w-4 h-4 text-primary" /> الشيكات</CardTitle>
          <CardDescription>شيكات واردة (RECEIVED) أو صادرة (ISSUED) — التسوية تُنشئ وصل قبض/صرف تلقائيًا</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader><TableRow>
              <TableHead>رقم الشيك</TableHead><TableHead>النوع</TableHead><TableHead>المستفيد</TableHead>
              <TableHead className="text-left">المبلغ</TableHead><TableHead>الاستحقاق</TableHead>
              <TableHead>الحالة</TableHead><TableHead></TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {checks.map((c) => (
                <TableRow key={c.id}>
                  <TableCell dir="ltr" className="font-mono text-xs text-right">{c.checkNumber}</TableCell>
                  <TableCell><Badge variant={c.checkType === "RECEIVED" ? "success" : "secondary"} className="text-[10px]">{c.checkType === "RECEIVED" ? "وارد" : "صادر"}</Badge></TableCell>
                  <TableCell className="text-sm">{c.beneficiaryName ?? "—"}</TableCell>
                  <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(c.amount)} {c.currency}</TableCell>
                  <TableCell className="text-xs">{c.dueDate.slice(0, 10)}</TableCell>
                  <TableCell>
                    <Badge variant={c.status === "CLEARED" ? "success" : c.status === "BOUNCED" ? "destructive" : "accent"} className="text-[10px]">
                      {c.status === "PENDING" ? "معلق" : c.status === "CLEARED" ? "مسوى" : c.status === "BOUNCED" ? "مرتد" : c.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {c.status === "PENDING" && (
                      <div className="flex gap-1">
                        <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-emerald-700" onClick={() => clearCheck(c.id)}>تسوية</Button>
                        <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-red-600" onClick={() => bounceCheck(c.id)}>ارتداد</Button>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {checks.length === 0 && <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-4">لا شيكات</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

// =====================================================================
// 6) Cashier shifts panel
// =====================================================================
function ShiftsPanel() {
  const [rows, setRows] = React.useState<CashierShiftRow[] | null>(null);
  const [cashboxId, setCashboxId] = React.useState<number | "">("");

  const load = React.useCallback(async () => {
    const { body } = await api<CashierShiftRow[]>("/api/v1/finance/cashier-shifts");
    if (body.success && body.data) setRows(body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  async function clockIn(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const { body } = await api("/api/v1/finance/cashier-shifts", {
      method: "POST",
      body: JSON.stringify({
        cashbox_id: Number(fd.get("cashbox_id")),
        branch_id: Number(fd.get("branch_id") || 1),
        opening_balance: Number(fd.get("opening_balance") || 0),
      }),
    });
    if (body.success) { toast.success("بدأت الوردية ✓"); await load(); }
    else toast.error(body.message ?? "فشل");
  }
  async function clockOut(id: number) {
    const actual = window.prompt("النقد الفعلي عند الإغلاق:") ?? "";
    if (!actual) return;
    const { body } = await api(`/api/v1/finance/cashier-shifts/${id}/clock-out`, {
      method: "POST",
      body: JSON.stringify({ closing_balance: Number(actual) }),
    });
    if (body.success) { toast.success("أُغلقت الوردية ✓"); await load(); }
    else toast.error(body.message ?? "فشل");
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><CalendarClock className="w-4 h-4 text-primary" /> ورديات الكاشير</CardTitle>
        <CardDescription>فتح/إغلاق ورديات الكاشير — يُرقّم SHIFT-YYYY-NNNNNN</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={clockIn} className="grid gap-3 sm:grid-cols-3 mb-4 p-3 rounded-lg border bg-muted/30">
          <label className="text-xs space-y-1">رقم الصندوق<input name="cashbox_id" type="number" required value={cashboxId} onChange={(e) => setCashboxId(e.target.value === "" ? "" : Number(e.target.value))} className={inputCls} /></label>
          <label className="text-xs space-y-1">رقم الفرع<input name="branch_id" type="number" defaultValue={1} className={inputCls} /></label>
          <label className="text-xs space-y-1">رصيد الافتتاح<input name="opening_balance" type="number" step="0.0001" defaultValue={0} className={inputCls} /></label>
          <div className="sm:col-span-3 flex justify-end"><Button type="submit" size="sm"><CalendarClock className="w-4 h-4" /> بدء وردية</Button></div>
        </form>

        {!rows ? <div className="py-6 text-center text-muted-foreground">جارٍ التحميل...</div> :
          rows.length === 0 ? <div className="py-6 text-center text-muted-foreground">لا ورديات</div> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>الرقم</TableHead><TableHead>الكاشير</TableHead><TableHead>الصندوق</TableHead>
              <TableHead>بدء</TableHead><TableHead>إغلاق</TableHead>
              <TableHead className="text-left">افتتاح</TableHead><TableHead className="text-left">ختام</TableHead>
              <TableHead className="text-left">قبض</TableHead><TableHead className="text-left">صرف</TableHead>
              <TableHead>الحالة</TableHead><TableHead></TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell dir="ltr" className="font-mono text-xs text-right">{r.number}</TableCell>
                  <TableCell className="text-sm">{r.cashier}</TableCell>
                  <TableCell className="text-xs">{r.cashbox}</TableCell>
                  <TableCell className="text-xs">{formatDateTime(r.clockInAt)}</TableCell>
                  <TableCell className="text-xs">{r.clockOutAt ? formatDateTime(r.clockOutAt) : "—"}</TableCell>
                  <TableCell className="text-left" dir="ltr">{n(r.openingBalance)}</TableCell>
                  <TableCell className="text-left" dir="ltr">{r.closingBalance != null ? n(r.closingBalance) : "—"}</TableCell>
                  <TableCell className="text-left" dir="ltr">{n(r.totalReceipts)}</TableCell>
                  <TableCell className="text-left" dir="ltr">{n(r.totalPayments)}</TableCell>
                  <TableCell>{r.status === "OPEN" ? <Badge variant="success" className="text-[10px]">مفتوحة</Badge> : <Badge variant="secondary" className="text-[10px]">مغلقة</Badge>}</TableCell>
                  <TableCell>
                    {r.status === "OPEN" && <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => clockOut(r.id)}>إغلاق</Button>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>}
      </CardContent>
    </Card>
  );
}

// =====================================================================
// 7) Recurring expenses panel
// =====================================================================
function RecurringPanel() {
  const [rows, setRows] = React.useState<RecurringExpenseRow[] | null>(null);
  const [showForm, setShowForm] = React.useState(false);
  const load = React.useCallback(async () => {
    const { body } = await api<RecurringExpenseRow[]>("/api/v1/finance/recurring-expenses");
    if (body.success && body.data) setRows(body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const { body } = await api("/api/v1/finance/recurring-expenses", {
      method: "POST",
      body: JSON.stringify({
        name: String(fd.get("name")),
        amount: Number(fd.get("amount")),
        currency: String(fd.get("currency") || "IQD"),
        frequency: String(fd.get("frequency")),
        day_of_month: Number(fd.get("day_of_month") || 1),
        cashbox_id: Number(fd.get("cashbox_id") || 1),
        branch_id: Number(fd.get("branch_id") || 1),
      }),
    });
    if (body.success) { toast.success("تمت إضافة المصروف ✓"); setShowForm(false); await load(); }
    else toast.error(body.message ?? "فشل");
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-base"><RefreshCw className="w-4 h-4 text-primary" /> المصروفات المتكررة</CardTitle>
            <CardDescription>إيجار · رواتب · إنترنت — جدولة شهرية/أسبوعية/سنوية</CardDescription>
          </div>
          <Button size="sm" onClick={() => setShowForm(v => !v)}><Plus className="w-4 h-4" /> جديد</Button>
        </div>
      </CardHeader>
      <CardContent>
        {showForm && (
          <form onSubmit={submit} className="grid gap-3 sm:grid-cols-3 mb-4 p-3 rounded-lg border bg-muted/30">
            <label className="text-xs space-y-1">الاسم<input name="name" required className={inputCls} /></label>
            <label className="text-xs space-y-1">المبلغ<input name="amount" type="number" step="0.0001" required className={inputCls} /></label>
            <label className="text-xs space-y-1">العملة<select name="currency" className={inputCls}><option>IQD</option><option>USD</option></select></label>
            <label className="text-xs space-y-1">التكرار<select name="frequency" className={inputCls}><option>MONTHLY</option><option>WEEKLY</option><option>QUARTERLY</option><option>YEARLY</option></select></label>
            <label className="text-xs space-y-1">يوم الشهر<input name="day_of_month" type="number" defaultValue={1} className={inputCls} /></label>
            <label className="text-xs space-y-1">رقم الصندوق<input name="cashbox_id" type="number" defaultValue={1} className={inputCls} /></label>
            <label className="text-xs space-y-1">رقم الفرع<input name="branch_id" type="number" defaultValue={1} className={inputCls} /></label>
            <div className="sm:col-span-3 flex justify-end"><Button type="submit" size="sm">حفظ</Button></div>
          </form>
        )}
        {!rows ? <div className="py-6 text-center text-muted-foreground">جارٍ التحميل...</div> :
          rows.length === 0 ? <div className="py-6 text-center text-muted-foreground">لا مصروفات متكررة</div> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>الاسم</TableHead><TableHead className="text-left">المبلغ</TableHead>
              <TableHead>العملة</TableHead><TableHead>التكرار</TableHead>
              <TableHead>التنفيذ القادم</TableHead><TableHead>الحالة</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="text-sm">{r.name}</TableCell>
                  <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(r.amount)}</TableCell>
                  <TableCell>{r.currency}</TableCell>
                  <TableCell><Badge variant="secondary" className="text-[10px]">{r.frequency}</Badge></TableCell>
                  <TableCell className="text-xs">{formatDateTime(r.nextRunAt)}</TableCell>
                  <TableCell>{r.status === "ACTIVE" ? <Badge variant="success" className="text-[10px]">نشط</Badge> : <Badge variant="destructive" className="text-[10px]">متوقف</Badge>}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>}
      </CardContent>
    </Card>
  );
}

// =====================================================================
// 8) Cashbox closing panel
// =====================================================================
function ClosingPanel() {
  const [rows, setRows] = React.useState<ClosingRow[] | null>(null);
  const [showForm, setShowForm] = React.useState(false);
  const load = React.useCallback(async () => {
    const { body } = await api<ClosingRow[]>("/api/v1/finance/cash-closings?per_page=50");
    if (body.success && body.data) setRows(body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const denominations: { denomination: number; count: number }[] = [];
    ["25000", "10000", "5000", "1000", "500", "250"].forEach((d) => {
      const cnt = Number(fd.get(`cnt_${d}`) || 0);
      if (cnt > 0) denominations.push({ denomination: Number(d), count: cnt });
    });
    const { body } = await api("/api/v1/finance/cash-closings", {
      method: "POST",
      body: JSON.stringify({
        cashbox_id: Number(fd.get("cashbox_id")),
        branch_id: Number(fd.get("branch_id") || 1),
        actual_cash: denominations.length ? undefined : Number(fd.get("actual_cash") || 0),
        denominations: denominations.length ? denominations : undefined,
        difference_reason: String(fd.get("difference_reason") || undefined),
      }),
    });
    if (body.success) { toast.success("تم الإغلاق ✓"); setShowForm(false); await load(); }
    else toast.error(body.message ?? "فشل");
  }
  async function reopen(id: number) {
    const reason = window.prompt("سبب إعادة الفتح:") ?? "";
    if (!reason) return;
    const { body } = await api(`/api/v1/finance/cash-closings/${id}/reopen`, { method: "POST", body: JSON.stringify({ reason }) });
    if (body.success) { toast.success("تمت إعادة الفتح ✓"); await load(); }
    else toast.error(body.message ?? "فشل");
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-base"><ListChecks className="w-4 h-4 text-primary" /> إغلاق وجرد الصندوق</CardTitle>
            <CardDescription>يُقارن الرصيد الدفتري مع النقد الفعلي + فئات الإصدار النقدي</CardDescription>
          </div>
          <Button size="sm" onClick={() => setShowForm(v => !v)}><Plus className="w-4 h-4" /> إغلاق جديد</Button>
          {/* v15 Phase 18-20 — Daily receipts PDF report button */}
          <a href="/api/v1/finance/reports/daily-receipts" target="_blank" title="تقرير المقبوضات اليومية PDF">
            <Button size="sm" variant="outline"><FileBarChart className="w-4 h-4 ml-1" /> تقرير المقبوضات</Button>
          </a>
        </div>
      </CardHeader>
      <CardContent>
        {showForm && (
          <form onSubmit={submit} className="grid gap-3 sm:grid-cols-3 mb-4 p-3 rounded-lg border bg-muted/30">
            <label className="text-xs space-y-1">رقم الصندوق<input name="cashbox_id" type="number" required className={inputCls} /></label>
            <label className="text-xs space-y-1">رقم الفرع<input name="branch_id" type="number" defaultValue={1} className={inputCls} /></label>
            <label className="text-xs space-y-1">سبب الفرق<input name="difference_reason" className={inputCls} /></label>
            <div className="sm:col-span-3 grid grid-cols-3 sm:grid-cols-6 gap-2">
              {["25000", "10000", "5000", "1000", "500", "250"].map((d) => (
                <label key={d} className="text-xs space-y-1 text-center">
                  {Number(d).toLocaleString()}
                  <input name={`cnt_${d}`} type="number" defaultValue={0} className={inputCls} />
                </label>
              ))}
            </div>
            <label className="text-xs space-y-1 sm:col-span-3">أو النقد الفعلي مباشرة<input name="actual_cash" type="number" step="0.0001" className={inputCls} /></label>
            <div className="sm:col-span-3 flex justify-end"><Button type="submit" size="sm">حفظ الإغلاق</Button></div>
          </form>
        )}
        {!rows ? <div className="py-6 text-center text-muted-foreground">جارٍ التحميل...</div> :
          rows.length === 0 ? <div className="py-6 text-center text-muted-foreground">لا إغلاقات</div> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>الرقم</TableHead><TableHead>التاريخ</TableHead><TableHead>الصندوق</TableHead>
              <TableHead className="text-left">افتتاح</TableHead><TableHead className="text-left">دفتري</TableHead>
              <TableHead className="text-left">فعلي</TableHead><TableHead className="text-left">الفرق</TableHead>
              <TableHead>الحالة</TableHead><TableHead></TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell dir="ltr" className="font-mono text-xs text-right">{r.number}</TableCell>
                  <TableCell className="text-xs">{formatDateTime(r.closingDate)}</TableCell>
                  <TableCell className="text-xs">{r.cashbox?.name ?? "—"}</TableCell>
                  <TableCell className="text-left" dir="ltr">{n(r.openingBalance)}</TableCell>
                  <TableCell className="text-left" dir="ltr">{n(r.bookBalance)}</TableCell>
                  <TableCell className="text-left" dir="ltr">{n(r.actualCash)}</TableCell>
                  <TableCell className={`text-left ${r.difference > 0 ? "text-emerald-600" : r.difference < 0 ? "text-red-600" : ""}`} dir="ltr">{n(r.difference)}</TableCell>
                  <TableCell>{r.status === "CLOSED" ? <Badge variant="success" className="text-[10px]">مغلق</Badge> : r.status === "REOPENED" ? <Badge variant="accent" className="text-[10px]">مُعاد فتحه</Badge> : <Badge variant="secondary" className="text-[10px]">DRAFT</Badge>}</TableCell>
                  <TableCell>
                    {r.status === "CLOSED" && <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => reopen(r.id)}>إعادة فتح</Button>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>}
      </CardContent>
    </Card>
  );
}

// =====================================================================
// 9) Statement panel — customer/supplier ledger
// =====================================================================
function StatementPanel() {
  const [party, setParty] = React.useState<"customer" | "supplier">("customer");
  const [partyId, setPartyId] = React.useState<number | "">("");
  const [data, setData] = React.useState<StatementData | null>(null);

  async function load() {
    if (!partyId) return;
    const { body } = await api<StatementData>(`/api/v1/finance/statements/${party}/${partyId}?days=365`);
    if (body.success && body.data) setData(body.data);
    else toast.error(body.message ?? "تعذر تحميل الكشف");
  }

  const cust = data?.customer ?? data?.supplier;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><FileText className="w-4 h-4 text-primary" /> كشف حساب</CardTitle>
        <CardDescription>دفتر الذمة بحركة — رصيد جاري بعد كل قيد</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2 mb-3">
          <select value={party} onChange={(e) => setParty(e.target.value as "customer" | "supplier")} className={inputCls + " w-32"}>
            <option value="customer">عميل</option>
            <option value="supplier">مورد</option>
          </select>
          <Input type="number" placeholder={`رقم ال${party === "customer" ? "عميل" : "مورد"}`} value={partyId} onChange={(e) => setPartyId(e.target.value === "" ? "" : Number(e.target.value))} className="w-40" />
          <Button size="sm" onClick={load}><FileText className="w-4 h-4" /> تحميل</Button>
        </div>

        {data && cust && (
          <div className="space-y-3">
            <div className="rounded-lg border p-3 bg-muted/30">
              <div className="font-semibold">{cust.name} <span dir="ltr" className="font-mono text-xs text-muted-foreground">{cust.code}</span></div>
              <div className="text-xs text-muted-foreground">الرصيد الختامي: <span dir="ltr" className="font-semibold">{formatIQD(data.closing_balance)}</span></div>
            </div>
            {data.rows.length === 0 ? <div className="py-4 text-center text-muted-foreground text-sm">لا حركات خلال الفترة</div> :
              <div className="max-h-[400px] overflow-y-auto scroll-thin">
                <Table>
                  <TableHeader><TableRow>
                    <TableHead>التاريخ</TableHead><TableHead>النوع</TableHead><TableHead>المرجع</TableHead>
                    <TableHead>الوصف</TableHead><TableHead className="text-left">مدين</TableHead>
                    <TableHead className="text-left">دائن</TableHead><TableHead className="text-left">الرصيد</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {data.rows.map((r, i) => (
                      <TableRow key={i}>
                        <TableCell className="text-xs">{r.date}</TableCell>
                        <TableCell><Badge variant="secondary" className="text-[10px]">{r.kind}</Badge></TableCell>
                        <TableCell dir="ltr" className="font-mono text-xs text-right">{r.ref}</TableCell>
                        <TableCell className="text-xs">{r.description}</TableCell>
                        <TableCell className="text-left" dir="ltr">{r.debit > 0 ? n(r.debit) : "—"}</TableCell>
                        <TableCell className="text-left" dir="ltr">{r.credit > 0 ? n(r.credit) : "—"}</TableCell>
                        <TableCell className="text-left font-semibold" dir="ltr">{n(r.running)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// =====================================================================
// 10) Aging panel — 5 buckets + per-actor print buttons
// =====================================================================
function AgingPanel() {
  const [type, setType] = React.useState<"customers" | "suppliers">("customers");
  const [data, setData] = React.useState<AgingData | null>(null);
  const [search, setSearch] = React.useState("");

  async function load() {
    const { body } = await api<AgingData>(`/api/v1/finance/aging?type=${type}`);
    if (body.success && body.data) setData(body.data);
    else toast.error(body.message ?? "تعذر التحميل");
  }
  React.useEffect(() => { setData(null); load(); }, [type]);

  if (!data) return <div className="py-6 text-center text-muted-foreground">جارٍ التحميل...</div>;

  const filteredRows = search.trim()
    ? data.rows.filter((r) => r.name.includes(search.trim()) || r.code.includes(search.trim()))
    : data.rows;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base"><Coins className="w-4 h-4 text-primary" /> أعمار الديون</CardTitle>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute right-2 top-2.5 w-4 h-4 text-muted-foreground" />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث بالاسم/الكود" className="pr-8 w-48" />
            </div>
            <select value={type} onChange={(e) => setType(e.target.value as "customers" | "suppliers")} className={inputCls + " w-40"}>
              <option value="customers">عملاء</option>
              <option value="suppliers">موردون</option>
            </select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-5 gap-2 mb-4 text-center">
          {[
            { label: "حالي", v: data.totals.current },
            { label: "1-30", v: data.totals.d1_30 },
            { label: "31-60", v: data.totals.d31_60 },
            { label: "61-90", v: data.totals.d61_90 },
            { label: "+90", v: data.totals.d90_plus },
          ].map((b) => (
            <div key={b.label} className="rounded-lg border p-2">
              <div className="text-[10px] text-muted-foreground">{b.label}</div>
              <div className="text-sm font-bold" dir="ltr">{formatIQD(b.v)}</div>
            </div>
          ))}
        </div>
        {filteredRows.length === 0 ? <div className="py-4 text-center text-muted-foreground text-sm">لا أرصدة مستحقة</div> :
          <div className="max-h-[400px] overflow-y-auto scroll-thin">
            <Table>
              <TableHeader><TableRow>
                <TableHead>الكود</TableHead><TableHead>الاسم</TableHead>
                <TableHead className="text-left">الرصيد</TableHead>
                <TableHead className="text-left">حالي</TableHead><TableHead className="text-left">1-30</TableHead>
                <TableHead className="text-left">31-60</TableHead><TableHead className="text-left">61-90</TableHead>
                <TableHead className="text-left">+90</TableHead>
                <TableHead></TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {filteredRows.map((r) => {
                  const actorId = r.customer_id ?? r.supplier_id;
                  return (
                    <TableRow key={r.code}>
                      <TableCell dir="ltr" className="font-mono text-xs text-right">{r.code}</TableCell>
                      <TableCell className="text-sm">{r.name}</TableCell>
                      <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(r.balance)}</TableCell>
                      <TableCell className="text-left" dir="ltr">{n(r.buckets.current)}</TableCell>
                      <TableCell className="text-left" dir="ltr">{n(r.buckets.d1_30)}</TableCell>
                      <TableCell className="text-left" dir="ltr">{n(r.buckets.d31_60)}</TableCell>
                      <TableCell className="text-left" dir="ltr">{n(r.buckets.d61_90)}</TableCell>
                      <TableCell className="text-left text-red-600" dir="ltr">{n(r.buckets.d90_plus)}</TableCell>
                      <TableCell>
                        {actorId ? (
                          <a href={`/api/v1/finance/aging/${actorId}/pdf?type=${type}`} target="_blank" title="طباعة كشف أعمار الديون">
                            <Button size="sm" variant="ghost" className="h-7 w-7 p-0"><Printer className="w-3.5 h-3.5" /></Button>
                          </a>
                        ) : null}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>}
      </CardContent>
    </Card>
  );
}

// =====================================================================
// v15 — Phase 4-7: RepSettlementsPanel (تسليمات المندوبين REP-STL-)
// =====================================================================
interface RepSettlementRow {
  id: number; number: string; settlement_date: string;
  rep_user: { id: number; fullName: string } | null;
  from_cashbox: { id: number; name: string; code: string; balance: number } | null;
  to_cashbox: { id: number; name: string; code: string; balance: number } | null;
  collected_amount: number; delivered_amount: number; difference: number;
  difference_reason: string | null; received_by: string | null;
  status: string; description: string | null; notes: string | null;
  created_at: string;
}

function RepSettlementsPanel() {
  const [rows, setRows] = React.useState<RepSettlementRow[] | null>(null);

  const load = React.useCallback(async () => {
    const { body } = await api<RepSettlementRow[]>("/api/v1/finance/rep-settlements");
    if (body.success && body.data) setRows(body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  async function cancel(id: number) {
    const reason = window.prompt("سبب إلغاء التسليم؟");
    if (!reason) return;
    const { body } = await api(`/api/v1/finance/rep-settlements/${id}/cancel`, {
      method: "POST", body: JSON.stringify({ reason }),
    });
    if (body.success) { toast.success("تم إلغاء التسليم ✓"); await load(); }
    else toast.error(body.message ?? "فشل الإلغاء");
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><UserCheck className="w-4 h-4 text-primary" /> تسليمات المندوبين (REP-STL-2026-)</CardTitle>
        <CardDescription>المندوب يحصّل من العملاء → صندوقه → يسلم لصندوق الفرع بحركة موثّقة + توقيع المستلم</CardDescription>
      </CardHeader>
      <CardContent>
        {!rows ? <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div> :
          rows.length === 0 ? <div className="py-8 text-center text-muted-foreground">لا تسليمات بعد</div> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>رقم التسليم</TableHead><TableHead>التاريخ</TableHead><TableHead>المندوب</TableHead>
              <TableHead>من صندوق</TableHead><TableHead>إلى صندوق</TableHead>
              <TableHead className="text-left">المحصّل</TableHead><TableHead className="text-left">المُسلّم</TableHead>
              <TableHead className="text-left">الفرق</TableHead><TableHead>المستلم</TableHead><TableHead>الحالة</TableHead><TableHead className="text-left">إجراءات</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell dir="ltr" className="font-mono text-[10px]">{r.number}</TableCell>
                  <TableCell className="text-xs">{formatDateTime(r.settlement_date)}</TableCell>
                  <TableCell className="text-xs">{r.rep_user?.fullName ?? "—"}</TableCell>
                  <TableCell className="text-xs">{r.from_cashbox?.name ?? "—"}</TableCell>
                  <TableCell className="text-xs">{r.to_cashbox?.name ?? "—"}</TableCell>
                  <TableCell className="text-left text-xs" dir="ltr">{formatIQD(r.collected_amount)}</TableCell>
                  <TableCell className="text-left text-xs font-semibold" dir="ltr">{formatIQD(r.delivered_amount)}</TableCell>
                  <TableCell className="text-left text-xs" dir="ltr">
                    {r.difference !== 0 ? <span className={r.difference < 0 ? "text-red-600" : "text-amber-600"}>{formatIQD(r.difference)}</span> : "—"}
                  </TableCell>
                  <TableCell className="text-xs">{r.received_by ?? "—"}</TableCell>
                  <TableCell>{r.status === "POSTED" ? <Badge variant="success" className="text-[10px]">مرحّل</Badge> : <Badge variant="destructive" className="text-[10px]">ملغى</Badge>}</TableCell>
                  <TableCell className="text-left">
                    {r.status === "POSTED" && (
                      <Button size="sm" variant="ghost" className="h-7 text-xs text-red-600" onClick={() => cancel(r.id)}>إلغاء</Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>}
      </CardContent>
    </Card>
  );
}

// =====================================================================
// v15 — Phase 8-11: OverdueNotificationsPanel (الديون المتأخرة)
// =====================================================================
interface OverdueRow {
  id: number; bucket: string; age_days: number; amount_due: number;
  channel: string; status: string; sent_at: string | null;
  whatsapp_url: string | null; message_body: string | null;
  customer: { id: number; name: string; code: string; whatsapp: string | null; phone: string | null };
  invoice: { id: number; number: string; invoiceDate: string; grandTotal: number; paidAmount: number };
  created_at: string;
}

const BUCKET_AR: Record<string, string> = {
  CURRENT: "حالي", D1_30: "1-30 يوم", D31_60: "31-60 يوم",
  D61_90: "61-90 يوم", D90_PLUS: "+90 يوم",
};

function OverdueNotificationsPanel() {
  const [rows, setRows] = React.useState<OverdueRow[] | null>(null);
  const [scanning, setScanning] = React.useState(false);
  const [bucketFilter, setBucketFilter] = React.useState("");

  const load = React.useCallback(async () => {
    const params = new URLSearchParams({ status: "PENDING" });
    if (bucketFilter) params.set("bucket", bucketFilter);
    const { body } = await api<OverdueRow[]>(`/api/v1/finance/overdue-notifications?${params}`);
    if (body.success && body.data) setRows(body.data);
  }, [bucketFilter]);
  React.useEffect(() => { load(); }, [load]);

  async function scan() {
    setScanning(true);
    try {
      const { body } = await api("/api/v1/finance/overdue-notifications", {
        method: "POST", body: JSON.stringify({ buckets: ["D1_30", "D31_60", "D61_90", "D90_PLUS"] }),
      });
      if (body.success) {
        const d = body.data as { scanned: number; created: number; skipped: number };
        toast.success(`فحص ✓ — ${d.scanned} فاتورة، ${d.created} إشعار جديد، ${d.skipped} موجود مسبقًا`);
        await load();
      } else toast.error(body.message ?? "فشل الفحص");
    } finally { setScanning(false); }
  }

  async function markSent(id: number) {
    const { body } = await api(`/api/v1/finance/overdue-notifications/${id}/mark-sent`, { method: "POST" });
    if (body.success) { toast.success("تم تحديد الإشعار كمُرسل ✓"); await load(); }
    else toast.error(body.message ?? "فشل التحديث");
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-base"><BellRing className="w-4 h-4 text-amber-500" /> إشعارات الديون المتأخرة</CardTitle>
            <CardDescription>تنبيهات WhatsApp للعملاء عن الفواتير المتأخرة — تُولّد مرة واحدة لكل (فاتورة، فترة تأخير)</CardDescription>
          </div>
          <Button size="sm" onClick={scan} disabled={scanning}>
            {scanning ? <Loader2 className="w-4 h-4 ml-1 animate-spin" /> : <Zap className="w-4 h-4 ml-1" />}
            {scanning ? "جارٍ الفحص..." : "فحص الديون"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-3 flex-wrap">
          <select value={bucketFilter} onChange={(e) => setBucketFilter(e.target.value)} className={inputCls + " w-48"}>
            <option value="">كل الفترات</option>
            <option value="D1_30">1-30 يوم</option>
            <option value="D31_60">31-60 يوم</option>
            <option value="D61_90">61-90 يوم</option>
            <option value="D90_PLUS">+90 يوم</option>
          </select>
        </div>

        {!rows ? <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div> :
          rows.length === 0 ? <div className="py-8 text-center text-muted-foreground">لا إشعارات معلّقة — اضغط «فحص الديون» لاكتشاف المتأخرات</div> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>العميل</TableHead><TableHead>الفاتورة</TableHead>
              <TableHead>فترة التأخير</TableHead><TableHead className="text-left">عمر الفاتورة</TableHead>
              <TableHead className="text-left">المتبقي</TableHead><TableHead>الحالة</TableHead><TableHead className="text-left">إجراءات</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell>
                    <div className="text-xs font-medium">{r.customer.name}</div>
                    <div className="text-[10px] text-muted-foreground">{r.customer.code}</div>
                  </TableCell>
                  <TableCell dir="ltr" className="font-mono text-[10px]">{r.invoice.number}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="text-[10px]">
                      {BUCKET_AR[r.bucket] ?? r.bucket}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-left text-xs" dir="ltr">{r.age_days} يوم</TableCell>
                  <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(r.amount_due)}</TableCell>
                  <TableCell>{r.status === "SENT" ? <Badge variant="success" className="text-[10px]">مُرسل</Badge> : <Badge variant="outline" className="text-[10px]">معلّق</Badge>}</TableCell>
                  <TableCell className="text-left">
                    <div className="flex gap-1 justify-end">
                      {r.whatsapp_url && (
                        <a href={r.whatsapp_url} target="_blank" rel="noopener noreferrer" onClick={() => markSent(r.id)}>
                          <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-emerald-600" title="إرسال واتساب">
                            <Send className="w-3.5 h-3.5" />
                          </Button>
                        </a>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>}
      </CardContent>
    </Card>
  );
}

// =====================================================================
// v15 — Phase 23-25: BudgetVsActualPanel (الموازنة مقابل الفعلي)
// =====================================================================
interface BudgetRow {
  category_id: number; category_code: string; category_name: string;
  monthly_budget: number; actual: number; variance: number;
  usage_pct: number; alert: boolean; alert_level: string;
}
interface BudgetData { period: string; totals: { budget: number; actual: number; variance: number; alerts: number }; rows: BudgetRow[] }

function BudgetVsActualPanel() {
  const [data, setData] = React.useState<BudgetData | null>(null);
  const [period, setPeriod] = React.useState(new Date().toISOString().slice(0, 7));

  const load = React.useCallback(async () => {
    const { body } = await api<BudgetData>(`/api/v1/finance/budget-vs-actual?period=${period}`);
    if (body.success && body.data) setData(body.data);
  }, [period]);
  React.useEffect(() => { load(); }, [load]);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-base"><Activity className="w-4 h-4 text-primary" /> الموازنة مقابل الفعلي</CardTitle>
            <CardDescription>مقارنة المصروفات الفعلية بالميزانية الشهرية + تنبيه عند تجاوز 80%</CardDescription>
          </div>
          <input type="month" value={period} onChange={(e) => setPeriod(e.target.value)} className={inputCls + " w-40"} />
        </div>
      </CardHeader>
      <CardContent>
        {!data ? <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div> :
          <>
            <div className="grid gap-3 sm:grid-cols-4 mb-4">
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">الموازنة</div>
                <div className="font-bold text-lg" dir="ltr">{formatIQD(data.totals.budget)}</div>
              </div>
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">الفعلي</div>
                <div className="font-bold text-lg" dir="ltr">{formatIQD(data.totals.actual)}</div>
              </div>
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">التباين</div>
                <div className={"font-bold text-lg " + (data.totals.variance > 0 ? "text-red-600" : "text-emerald-600")} dir="ltr">
                  {data.totals.variance > 0 ? "+" : ""}{formatIQD(data.totals.variance)}
                </div>
              </div>
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">تنبيهات</div>
                <div className={"font-bold text-lg " + (data.totals.alerts > 0 ? "text-amber-600" : "")}>{data.totals.alerts}</div>
              </div>
            </div>

            {data.rows.length === 0 ? <div className="py-6 text-center text-muted-foreground">لا تصنيفات مصروفات بموازنة محددة</div> :
            <Table>
              <TableHeader><TableRow>
                <TableHead>الكود</TableHead><TableHead>التصنيف</TableHead>
                <TableHead className="text-left">الموازنة</TableHead>
                <TableHead className="text-left">الفعلي</TableHead>
                <TableHead className="text-left">التباين</TableHead>
                <TableHead className="text-left">نسبة الاستخدام</TableHead>
                <TableHead>الحالة</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {data.rows.map((r) => (
                  <TableRow key={r.category_id}>
                    <TableCell dir="ltr" className="font-mono text-[10px]">{r.category_code}</TableCell>
                    <TableCell className="text-sm font-medium">{r.category_name}</TableCell>
                    <TableCell className="text-left" dir="ltr">{formatIQD(r.monthly_budget)}</TableCell>
                    <TableCell className="text-left" dir="ltr">{formatIQD(r.actual)}</TableCell>
                    <TableCell className="text-left" dir="ltr">
                      <span className={r.variance > 0 ? "text-red-600" : "text-emerald-600"}>
                        {r.variance > 0 ? "+" : ""}{formatIQD(r.variance)}
                      </span>
                    </TableCell>
                    <TableCell className="text-left" dir="ltr">
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-muted rounded-full h-2">
                          <div className={"h-2 rounded-full " + (r.usage_pct >= 100 ? "bg-red-500" : r.usage_pct >= 80 ? "bg-amber-500" : "bg-emerald-500")}
                            style={{ width: `${Math.min(100, r.usage_pct)}%` }} />
                        </div>
                        <span className="text-xs">{r.usage_pct.toFixed(0)}%</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {r.alert_level === "OVER" ? <Badge variant="destructive" className="text-[10px]">تجاوز</Badge> :
                       r.alert_level === "WARNING" ? <Badge variant="default" className="text-[10px] bg-amber-500"><AlertTriangle className="w-3 h-3 ml-1" />قرب</Badge> :
                       <Badge variant="success" className="text-[10px]">ضمن</Badge>}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>}
          </>}
      </CardContent>
    </Card>
  );
}

// =====================================================================
// v15 — Phase 15-17: FinanceAuditPanel (سجل التدقيق المالي)
// =====================================================================
interface AuditLogRow {
  id: number; action: string; module: string; entity_type: string;
  entity_id: number | null; old_values: string | null; new_values: string | null;
  ip_address: string | null; user_agent: string | null;
  user: { id: number; fullName: string; username: string } | null;
  created_at: string;
}

function FinanceAuditPanel() {
  const [data, setData] = React.useState<{ rows: AuditLogRow[]; total: number } | null>(null);
  const [actionFilter, setActionFilter] = React.useState("");
  const [entityFilter, setEntityFilter] = React.useState("");

  const load = React.useCallback(async () => {
    const params = new URLSearchParams({ per_page: "100" });
    if (actionFilter) params.set("action", actionFilter);
    if (entityFilter) params.set("entity_type", entityFilter);
    const { body } = await api<{ rows: AuditLogRow[]; total: number }>(`/api/v1/finance/audit-logs?${params}`);
    if (body.success && body.data) setData(body.data);
  }, [actionFilter, entityFilter]);
  React.useEffect(() => { load(); }, [load]);

  const ACTION_AR: Record<string, string> = {
    CREATE: "إنشاء", UPDATE: "تعديل", DELETE: "حذف", POST: "ترحيل",
    CANCEL: "إلغاء", REVERSE: "عكس", REOPEN: "فتح", APPROVE: "اعتماد",
    EXPORT: "تصدير", LOGIN: "دخول",
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><FileBarChart className="w-4 h-4 text-primary" /> سجل التدقيق المالي</CardTitle>
        <CardDescription>كل عمليات الإنشاء/التعديل/الإلغاء على الصناديق، الوصولات، التحويلات، التسويات</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-3 flex-wrap">
          <select value={actionFilter} onChange={(e) => setActionFilter(e.target.value)} className={inputCls + " w-40"}>
            <option value="">كل الإجراءات</option>
            <option value="CREATE">إنشاء</option>
            <option value="UPDATE">تعديل</option>
            <option value="POST">ترحيل</option>
            <option value="CANCEL">إلغاء</option>
            <option value="REVERSE">عكس</option>
            <option value="REOPEN">فتح</option>
          </select>
          <select value={entityFilter} onChange={(e) => setEntityFilter(e.target.value)} className={inputCls + " w-48"}>
            <option value="">كل الأنواع</option>
            <option value="cashbox">صناديق</option>
            <option value="receipt_voucher">وصولات قبض</option>
            <option value="payment_voucher">وصولات صرف</option>
            <option value="cash_transfer">تحويلات</option>
            <option value="cashbox_closing">إغلاق</option>
            <option value="rep_settlement">تسليمات مندوبين</option>
            <option value="overdue_notification_scan">فحص الديون</option>
          </select>
        </div>

        {!data ? <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div> :
          data.rows.length === 0 ? <div className="py-8 text-center text-muted-foreground">لا سجلات تطابق الفلاتر</div> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>الوقت</TableHead><TableHead>الإجراء</TableHead><TableHead>النوع</TableHead>
              <TableHead>المعرّف</TableHead><TableHead>المستخدم</TableHead><TableHead>القيم الجديدة</TableHead>
              <TableHead>IP</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {data.rows.map((r) => {
                let parsedNew: any = null;
                try { parsedNew = r.new_values ? JSON.parse(r.new_values) : null; } catch {}
                return (
                  <TableRow key={r.id}>
                    <TableCell className="text-xs">{formatDateTime(r.created_at)}</TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-[10px]">{ACTION_AR[r.action] ?? r.action}</Badge>
                    </TableCell>
                    <TableCell className="text-xs">{r.entity_type}</TableCell>
                    <TableCell dir="ltr" className="font-mono text-[10px]">{r.entity_id ?? "—"}</TableCell>
                    <TableCell className="text-xs">{r.user?.fullName ?? "—"}</TableCell>
                    <TableCell className="text-xs max-w-xs truncate">
                      {parsedNew ? <code dir="ltr" className="text-[10px] bg-muted px-1 py-0.5 rounded">{JSON.stringify(parsedNew).slice(0, 100)}</code> : "—"}
                    </TableCell>
                    <TableCell dir="ltr" className="text-[10px] text-muted-foreground">{r.ip_address ?? "—"}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>}
      </CardContent>
    </Card>
  );
}
