"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { api } from "@/lib/client-api";
import { formatIQD } from "@/lib/utils";
import { BookOpen, FileText, Scale, Landmark, TrendingUp, Plus } from "lucide-react";

interface Account { id: number; code: string; name: string; type: string; currentBalance: number; openingBalance: number }
interface JournalEntry { id: number; number: string; entryDate: string; description: string | null; source: string; totalDebit: number; totalCredit: number; status: string }
interface TrialBalanceRow { account_id: number; code: string; name: string; type: string; debit: number; credit: number }
interface BalanceSheetRow { code: string; name: string; type: string; balance: number }
interface IncomeRow { code: string; name: string; type: string; amount: number }

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";

export function AccountingTab() {
  const [sub, setSub] = React.useState("accounts");

  return (
    <div className="space-y-4">
      <Tabs value={sub} onValueChange={setSub} dir="rtl">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="accounts" className="text-xs"><BookOpen className="w-4 h-4 ml-1" /> دليل الحسابات</TabsTrigger>
          <TabsTrigger value="journal" className="text-xs"><FileText className="w-4 h-4 ml-1" /> قيود اليومية</TabsTrigger>
          <TabsTrigger value="trial" className="text-xs"><Scale className="w-4 h-4 ml-1" /> ميزان المراجعة</TabsTrigger>
          <TabsTrigger value="balance" className="text-xs"><Landmark className="w-4 h-4 ml-1" /> الميزانية العمومية</TabsTrigger>
          <TabsTrigger value="income" className="text-xs"><TrendingUp className="w-4 h-4 ml-1" /> قائمة الدخل</TabsTrigger>
        </TabsList>
        <TabsContent value="accounts"><AccountsPanel /></TabsContent>
        <TabsContent value="journal"><JournalPanel /></TabsContent>
        <TabsContent value="trial"><TrialBalancePanel /></TabsContent>
        <TabsContent value="balance"><BalanceSheetPanel /></TabsContent>
        <TabsContent value="income"><IncomeStatementPanel /></TabsContent>
      </Tabs>
    </div>
  );
}

function AccountsPanel() {
  const [rows, setRows] = React.useState<Account[] | null>(null);

  const load = React.useCallback(async () => {
    const { body } = await api<Account[]>("/api/v1/finance/accounts");
    if (body.success && body.data) setRows(body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  async function initStd() {
    const { body } = await api("/api/v1/finance/accounts", { method: "POST", body: JSON.stringify({ action: "init_standard" }) });
    if (body.success) { toast.success("تمت تهيئة دليل الحسابات ✓"); await load(); }
    else toast.error(body.message ?? "فشل");
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-base"><BookOpen className="w-4 h-4 text-primary" /> دليل الحسابات</CardTitle>
            <CardDescription>28 حساباً قياسياً — أصول · خصوم · حقوق ملكية · إيرادات · مصروفات</CardDescription>
          </div>
          <Button size="sm" variant="outline" onClick={initStd}><Plus className="w-4 h-4" /> تهيئة الدليل القياسي</Button>
        </div>
      </CardHeader>
      <CardContent>
        {!rows ? <div className="py-6 text-center text-muted-foreground">جارٍ التحميل...</div> :
          rows.length === 0 ? <div className="py-6 text-center text-muted-foreground">لا حسابات — اضغط «تهيئة الدليل القياسي»</div> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>الكود</TableHead><TableHead>الاسم</TableHead><TableHead>النوع</TableHead>
              <TableHead className="text-left">افتتاحي</TableHead><TableHead className="text-left">الرصيد الحالي</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell dir="ltr" className="font-mono text-xs text-right">{r.code}</TableCell>
                  <TableCell className="text-sm">{r.name}</TableCell>
                  <TableCell><Badge variant="secondary" className="text-[10px]">{r.type}</Badge></TableCell>
                  <TableCell className="text-left" dir="ltr">{formatIQD(r.openingBalance)}</TableCell>
                  <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(r.currentBalance)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>}
      </CardContent>
    </Card>
  );
}

function JournalPanel() {
  const [rows, setRows] = React.useState<JournalEntry[] | null>(null);
  const [showForm, setShowForm] = React.useState(false);

  const load = React.useCallback(async () => {
    const { body } = await api<JournalEntry[]>("/api/v1/finance/journal-entries?per_page=50");
    if (body.success && body.data) setRows(body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const desc = String(fd.get("description") || "");
    const lines = [{ accountCode: "1010", debit: Number(fd.get("debit1") || 0), credit: 0 }, { accountCode: "4000", debit: 0, credit: Number(fd.get("debit1") || 0) }];
    const { body } = await api("/api/v1/finance/journal-entries", {
      method: "POST",
      body: JSON.stringify({ description: desc, lines }),
    });
    if (body.success) { toast.success("تم تسجيل القيد ✓"); setShowForm(false); await load(); }
    else toast.error(body.message ?? "فشل");
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-base"><FileText className="w-4 h-4 text-primary" /> قيود اليومية</CardTitle>
            <CardDescription>قيود يدوية متوازنة (Σ مدين = Σ دائن) + قيود تلقائية من وصول القبض/الصرف</CardDescription>
          </div>
          <Button size="sm" onClick={() => setShowForm(v => !v)}><Plus className="w-4 h-4" /> قيد جديد</Button>
        </div>
      </CardHeader>
      <CardContent>
        {showForm && (
          <form onSubmit={submit} className="grid gap-3 sm:grid-cols-3 mb-4 p-3 rounded-lg border bg-muted/30">
            <label className="text-xs space-y-1">الوصف<input name="description" required className={inputCls} /></label>
            <label className="text-xs space-y-1">المبلغ (مدين/دائن)<input name="debit1" type="number" step="0.0001" required className={inputCls} /></label>
            <div className="sm:col-span-3 flex justify-end"><Button type="submit" size="sm">حفظ القيد</Button></div>
            <div className="sm:col-span-3 text-[10px] text-muted-foreground">قيد مبسّط: من النقدية (1010) إلى إيرادات المبيعات (4000)</div>
          </form>
        )}
        {!rows ? <div className="py-6 text-center text-muted-foreground">جارٍ التحميل...</div> :
          rows.length === 0 ? <div className="py-6 text-center text-muted-foreground">لا قيود</div> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>الرقم</TableHead><TableHead>التاريخ</TableHead><TableHead>الوصف</TableHead>
              <TableHead>المصدر</TableHead><TableHead className="text-left">مدين</TableHead>
              <TableHead className="text-left">دائن</TableHead><TableHead>الحالة</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell dir="ltr" className="font-mono text-xs text-right">{r.number}</TableCell>
                  <TableCell className="text-xs">{r.entryDate.slice(0, 10)}</TableCell>
                  <TableCell className="text-sm">{r.description ?? "—"}</TableCell>
                  <TableCell><Badge variant="secondary" className="text-[10px]">{r.source}</Badge></TableCell>
                  <TableCell className="text-left" dir="ltr">{formatIQD(r.totalDebit)}</TableCell>
                  <TableCell className="text-left" dir="ltr">{formatIQD(r.totalCredit)}</TableCell>
                  <TableCell><Badge variant={r.status === "POSTED" ? "success" : "secondary"} className="text-[10px]">{r.status}</Badge></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>}
      </CardContent>
    </Card>
  );
}

function TrialBalancePanel() {
  const [data, setData] = React.useState<{ rows: TrialBalanceRow[]; totals: { debit: number; credit: number }; is_balanced: boolean } | null>(null);

  const load = React.useCallback(async () => {
    const { body } = await api<{ rows: TrialBalanceRow[]; totals: { debit: number; credit: number }; is_balanced: boolean }>("/api/v1/finance/reports/trial-balance");
    if (body.success && body.data) setData(body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  if (!data) return <div className="py-6 text-center text-muted-foreground">جارٍ التحميل...</div>;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><Scale className="w-4 h-4 text-primary" /> ميزان المراجعة</CardTitle>
        <CardDescription>يجب أن يتساوى مجموع المدين والدائن — مرجع التوازن المحاسبي</CardDescription>
      </CardHeader>
      <CardContent>
        <div className={`mb-3 rounded-lg p-2 text-sm ${data.is_balanced ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-800"}`}>
          {data.is_balanced ? `✓ متوازن — مدين = دائن = ${formatIQD(data.totals.debit)}` : `✗ غير متوازن — مدين ${formatIQD(data.totals.debit)} ≠ دائن ${formatIQD(data.totals.credit)}`}
        </div>
        <Table>
          <TableHeader><TableRow>
            <TableHead>الكود</TableHead><TableHead>الحساب</TableHead><TableHead>النوع</TableHead>
            <TableHead className="text-left">مدين</TableHead><TableHead className="text-left">دائن</TableHead>
          </TableRow></TableHeader>
          <TableBody>
            {data.rows.map((r) => (
              <TableRow key={r.account_id}>
                <TableCell dir="ltr" className="font-mono text-xs text-right">{r.code}</TableCell>
                <TableCell className="text-sm">{r.name}</TableCell>
                <TableCell><Badge variant="secondary" className="text-[10px]">{r.type}</Badge></TableCell>
                <TableCell className="text-left" dir="ltr">{r.debit > 0 ? formatIQD(r.debit) : "—"}</TableCell>
                <TableCell className="text-left" dir="ltr">{r.credit > 0 ? formatIQD(r.credit) : "—"}</TableCell>
              </TableRow>
            ))}
            <TableRow>
              <TableCell colSpan={3} className="font-bold text-left">الإجمالي</TableCell>
              <TableCell className="text-left font-bold" dir="ltr">{formatIQD(data.totals.debit)}</TableCell>
              <TableCell className="text-left font-bold" dir="ltr">{formatIQD(data.totals.credit)}</TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

function BalanceSheetPanel() {
  const [data, setData] = React.useState<{ rows: BalanceSheetRow[]; summary: { assets: number; liabilities: number; equity: number; total_liabilities_equity: number; is_balanced: boolean } } | null>(null);

  const load = React.useCallback(async () => {
    const { body } = await api<{ rows: BalanceSheetRow[]; summary: { assets: number; liabilities: number; equity: number; total_liabilities_equity: number; is_balanced: boolean } }>("/api/v1/finance/reports/balance-sheet");
    if (body.success && body.data) setData(body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  if (!data) return <div className="py-6 text-center text-muted-foreground">جارٍ التحميل...</div>;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><Landmark className="w-4 h-4 text-primary" /> الميزانية العمومية</CardTitle>
        <CardDescription>الأصول = الخصوم + حقوق الملكية — المعادلة المحاسبية</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="rounded-lg border p-3 text-center"><div className="text-[10px] text-muted-foreground">الأصول</div><div className="font-bold" dir="ltr">{formatIQD(data.summary.assets)}</div></div>
          <div className="rounded-lg border p-3 text-center"><div className="text-[10px] text-muted-foreground">الخصوم</div><div className="font-bold" dir="ltr">{formatIQD(data.summary.liabilities)}</div></div>
          <div className="rounded-lg border p-3 text-center"><div className="text-[10px] text-muted-foreground">حقوق الملكية</div><div className="font-bold" dir="ltr">{formatIQD(data.summary.equity)}</div></div>
        </div>
        <div className={`mb-3 rounded-lg p-2 text-sm ${data.summary.is_balanced ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-800"}`}>
          {data.summary.is_balanced ? `✓ متوازنة` : `✗ غير متوازنة — الأصول ≠ الخصوم + حقوق الملكية`}
        </div>
        <Table>
          <TableHeader><TableRow>
            <TableHead>الكود</TableHead><TableHead>الحساب</TableHead><TableHead>النوع</TableHead>
            <TableHead className="text-left">الرصيد</TableHead>
          </TableRow></TableHeader>
          <TableBody>
            {data.rows.map((r) => (
              <TableRow key={r.code}>
                <TableCell dir="ltr" className="font-mono text-xs text-right">{r.code}</TableCell>
                <TableCell className="text-sm">{r.name}</TableCell>
                <TableCell><Badge variant="secondary" className="text-[10px]">{r.type}</Badge></TableCell>
                <TableCell className="text-left" dir="ltr">{formatIQD(r.balance)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

function IncomeStatementPanel() {
  const [data, setData] = React.useState<{ rows: IncomeRow[]; summary: { total_revenue: number; total_expense: number; net_income: number } } | null>(null);

  const load = React.useCallback(async () => {
    const { body } = await api<{ rows: IncomeRow[]; summary: { total_revenue: number; total_expense: number; net_income: number } }>("/api/v1/finance/reports/income-statement");
    if (body.success && body.data) setData(body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  if (!data) return <div className="py-6 text-center text-muted-foreground">جارٍ التحميل...</div>;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><TrendingUp className="w-4 h-4 text-primary" /> قائمة الدخل</CardTitle>
        <CardDescription>الإيرادات − المصروفات = صافي الربح</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="rounded-lg border p-3 text-center"><div className="text-[10px] text-muted-foreground">الإيرادات</div><div className="font-bold text-emerald-600" dir="ltr">{formatIQD(data.summary.total_revenue)}</div></div>
          <div className="rounded-lg border p-3 text-center"><div className="text-[10px] text-muted-foreground">المصروفات</div><div className="font-bold text-red-600" dir="ltr">{formatIQD(data.summary.total_expense)}</div></div>
          <div className={`rounded-lg border p-3 text-center ${data.summary.net_income >= 0 ? "bg-emerald-50" : "bg-red-50"}`}>
            <div className="text-[10px] text-muted-foreground">صافي الربح</div>
            <div className="font-bold" dir="ltr">{formatIQD(data.summary.net_income)}</div>
          </div>
        </div>
        <Table>
          <TableHeader><TableRow>
            <TableHead>الكود</TableHead><TableHead>الحساب</TableHead><TableHead>النوع</TableHead>
            <TableHead className="text-left">المبلغ</TableHead>
          </TableRow></TableHeader>
          <TableBody>
            {data.rows.map((r) => (
              <TableRow key={r.code}>
                <TableCell dir="ltr" className="font-mono text-xs text-right">{r.code}</TableCell>
                <TableCell className="text-sm">{r.name}</TableCell>
                <TableCell><Badge variant={r.type === "REVENUE" ? "success" : "destructive"} className="text-[10px]">{r.type === "REVENUE" ? "إيراد" : "مصروف"}</Badge></TableCell>
                <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(r.amount)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
