"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { formatDateTime, formatIQD, formatUSD, fmtMoney } from "@/lib/utils";
import { Ban, BellRing, Check, Copy, Download, Eye, Loader2, Mail, MessageCircle, Package, PenLine, Printer, Receipt, RefreshCcw, Search, Wallet, X, Zap } from "lucide-react";
import { QuickReceiptForm } from "@/components/sales/quick-receipt-form";

interface InvoiceRow {
  id: number; number: string; type: string; sale_type: string; status: string;
  credit_exceeded: boolean; invoice_date: string; due_date: string | null;
  currency_code?: string; exchange_rate?: number | null;
  customer: { name: string }; warehouse: { name: string }; rep: string; customer_type?: string;
  lines_count: number; grand_total: number; paid_amount: number; due_amount: number;
  previous_balance: number; new_balance: number; created_by: string;
}

interface DetailLine {
  id: number;
  product: { code: string; name: string; unit: string; packUnit: string | null; packQty: number | null };
  qty: number; ordered_qty: number;
  package_qty: number; loose_qty: number;
  package_type: string | null; package_type_label: string | null; package_conversion: number;
  package_price: number | null; unit_price: number;
  discount_pct: number; discount_amount: number; tax_amount: number; line_total: number;
  stock_before: number; stock_after: number; package_note: string | null; qty_text: string;
}
interface Detail {
  id: number; number: string; type: string; sale_type: string; status: string;
  stock_applied: boolean; credit_exceeded: boolean;
  invoice_date: string; due_date: string | null; payment_method: string;
  currency_code?: "IQD" | "USD"; exchange_rate?: number | null; // العملة المزدوجة: عرض الدولار = المخزن ÷ السعر
  customer: { id: number; code: string; name: string; shopName: string | null; phone: string | null; whatsapp: string | null; address: string | null; area: string | null; status: string; balance: number; creditLimit: number };
  warehouse: { code: string; name: string }; branch: string | null;
  created_by: string; rep: { id: number; name: string } | null;
  previous_balance: number; grand_total: number; total_due: number;
  paid_amount: number; due_amount: number; credit_note_adjustment: number; new_balance: number;
  credit_limit: number; available_credit: number;
  packaging_details: boolean;
  packaging_ledger: { packageCode: string; packageType: string; direction: string; openingQty: number; issuedQty: number; remainingQty: number; note: string | null; createdAt: string }[];
  receiver_name: string | null; receiver_phone: string | null;
  delivered_at: string | null; signed_at: string | null;
  rep_notes: string | null; customer_notes: string | null; admin_notes: string | null; notes: string | null;
  verify_token: string | null;
  subtotal: number; discount_total: number; tax_total: number;
  source_orders: string[]; source_quotations: string[];
  delivery_notes: { number: string; status: string; driver: string | null; deliveredAt: string | null }[];
  mini_statement: { last_invoice: { number: string; date: string; total: number } | null; last_payment: { amount: number; date: string } | null; balance_before_invoice: number } | null;
  footer_text: string;
  // سجل المدفوعات المفصلة (تطوير الفاتورة — جولة 2)
  payments?: PaymentRow[];
  lines: DetailLine[];
}
interface PaymentRow {
  id: number; direction: string; category: string;
  amount: number; note: string | null; cashbox: string; created_at: string; by: string;
}
interface QrData { svg: string; tlv_base64: string; seller: string; tax_number: string }
interface ListSummary { count: number; total: number; paid: number; due: number }

const SALE_TYPE_LABEL: Record<string, string> = { CASH: "نقدي", CREDIT: "آجل", PARTIAL: "جزئي", SWAP: "استبدال", RETURN: "مرتجع" };
const PAY_LABEL: Record<string, string> = { CASH: "نقدي", CARD: "بطاقة", TRANSFER: "حوالة", CHEQUE: "شيك" };
const STATUS_INFO: Record<string, { label: string; variant: "success" | "destructive" | "accent" | "secondary" | "navy" }> = {
  POSTED: { label: "معتمدة", variant: "success" },
  PENDING_APPROVAL: { label: "بانتظار الاعتماد", variant: "accent" },
  REJECTED: { label: "مرفوضة", variant: "destructive" },
  VOID: { label: "ملغاة", variant: "secondary" },
};
const n = (v: number) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(v);

export function InvoicesTab() {
  const [rows, setRows] = React.useState<InvoiceRow[] | null>(null);
  const [q, setQ] = React.useState("");
  const [type, setType] = React.useState("");
  const [status, setStatus] = React.useState("");
  const [dateFrom, setDateFrom] = React.useState("");
  const [dateTo, setDateTo] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [page, setPage] = React.useState(1);
  const [totalPages, setTotalPages] = React.useState(1);
  const [summary, setSummary] = React.useState<ListSummary | null>(null);
  const [detail, setDetail] = React.useState<Detail | null>(null);
  const [printMode, setPrintMode] = React.useState<"A4" | "THERMAL" | null>(null);
  const [qr, setQr] = React.useState<QrData | null>(null);
  const [perms, setPerms] = React.useState<Set<string>>(new Set());
  const [company, setCompany] = React.useState<{ name: string; phone: string | null; address: string | null; taxNumber: string | null; email?: string | null; logoUrl?: string | null } | null>(null);
  // تحصيل سريع + إلغاء (تطوير الفاتورة)
  const [cashboxes, setCashboxes] = React.useState<{ id: number; name: string }[]>([]);
  const [payCashbox, setPayCashbox] = React.useState<number | "">("");
  const [payAmount, setPayAmount] = React.useState<number | "">("");
  const [paying, setPaying] = React.useState(false);
  const [voiding, setVoiding] = React.useState(false);
  // تأكيد الاستلام والتوقيع (تطوير الفاتورة — جولة 2)
  const [showReceiptForm, setShowReceiptForm] = React.useState(false);
  const [receipt, setReceipt] = React.useState({ name: "", phone: "" });
  const [confirming, setConfirming] = React.useState(false);
  // واتساب سريع من الصف (مشاركة/تذكير) — جولة المشاركة مع العملاء
  const [waBusyId, setWaBusyId] = React.useState<number | null>(null);
  // تحصيل سريع من قائمة الفواتير (Zap button)
  const [quickReceiptInv, setQuickReceiptInv] = React.useState<{ customerId: number; invoiceId: number } | null>(null);

  const canApprove = perms.has("sales.invoices.approve");
  const canReject = perms.has("sales.invoices.reject");

  React.useEffect(() => {
    api<{ company: typeof company; permissions: string[] }>("/api/v1/auth/me").then(({ body }) => {
      if (body.success && body.data) {
        setCompany(body.data.company);
        setPerms(new Set(body.data.permissions ?? []));
      }
    });
  }, []);

  const PER_PAGE = 50;

  const load = React.useCallback(async (p = 1) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ per_page: String(PER_PAGE), page: String(p) });
      if (q) params.set("q", q);
      if (type) params.set("type", type);
      if (status) params.set("status", status);
      if (dateFrom) params.set("date_from", dateFrom);
      if (dateTo) params.set("date_to", dateTo);
      const { body } = await api<InvoiceRow[]>(`/api/v1/sales/invoices?${params}`);
      if (body.success && body.data) {
        setRows(body.data);
        const total = Number(body.meta?.total ?? body.data.length);
        setTotalPages(Math.max(1, Math.ceil(total / PER_PAGE)));
        setPage(Number(body.meta?.page ?? p));
        const s = body.meta?.summary as ListSummary | undefined;
        if (s) setSummary(s);
      } else toast.error(body.message ?? "تعذر تحميل الفواتير");
    } finally {
      setLoading(false);
    }
  }, [q, type, status, dateFrom, dateTo]);

  // تحميل تلقائي مؤجل عند أي تغيير في الفلاتر (يشمل التحميل الأول)
  React.useEffect(() => {
    const t = setTimeout(() => { load(1); }, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [load]);

  // صناديق النقد لزر التحصيل السريع
  React.useEffect(() => {
    if (perms.has("finance.payments.create") && cashboxes.length === 0) {
      api<{ id: number; name: string; is_active: boolean }[]>("/api/v1/finance/cashboxes").then(({ body }) => {
        if (body.success && body.data) setCashboxes(body.data.filter((b) => b.is_active));
      });
    }
  }, [perms, cashboxes.length]);

  async function openDetail(id: number) {
    const { body } = await api<Detail>(`/api/v1/sales/invoices/${id}`);
    if (body.success && body.data) {
      setDetail(body.data);
      setQr(null);
      api<QrData>(`/api/v1/sales/invoices/${id}/qr`).then(({ body: qb }) => {
        if (qb.success && qb.data) setQr(qb.data);
      });
    } else toast.error(body.message ?? "تعذر تحميل الفاتورة");
  }

  async function act(id: number, action: "approve" | "reject") {
    const { body } = await api(`/api/v1/sales/invoices/${id}/${action}`, {
      method: "POST",
      body: JSON.stringify(action === "reject" ? { reason: "رفض يدوي من الإدارة" } : {}),
    });
    if (body.success) {
      toast.success(action === "approve" ? "اعتُمدت الفاتورة وطُبقت آثارها (مخزون + ذمة + عبوات)" : "رُفضت الفاتورة دون أي أثر محاسبي");
      openDetail(id);
      load(page);
    } else {
      toast.error(body.message ?? "فشلت العملية");
    }
  }

  // ==================== تطوير الفاتورة — أزرار إضافية ====================

  /** بناء رسالة واتساب للفاتورة — يُستخدم من التفاصيل ومن الصف السريع */
  function waMessageFromDetail(x: Detail): string {
    const usd = x.currency_code === "USD" && x.exchange_rate;
    const m = (v: number) => (usd ? formatUSD(v / (x.exchange_rate as number)) : `${n(v)} د.ع`);
    const verifyUrl = x.verify_token ? `${window.location.origin}/verify/${x.verify_token}` : "";
    return [
      `*فاتورة ${x.number}*`,
      `التاريخ: ${formatDateTime(x.invoice_date)}`,
      `العميل: ${x.customer.name}`,
      `عدد البنود: ${x.lines.length}`,
      `الإجمالي: ${m(x.grand_total)}`,
      `المدفوع: ${m(x.paid_amount)}`,
      x.due_amount > 0 ? `المتبقي: ${m(x.due_amount)}` : "",
      `الرصيد السابق: ${m(x.previous_balance)}`,
      `الرصيد الجديد: ${m(x.new_balance)}`,
      usd ? `سعر الصرف: ${n(x.exchange_rate as number)} د.ع لكل $1` : "",
      verifyUrl ? `\nمعاينة وتحقق من الفاتورة:\n${verifyUrl}` : "",
    ].filter(Boolean).join("\n");
  }

  /** فتح واتساب برسالة جاهزة — رقم العميل إن وُجد وإلا مشاركة حرة */
  function openWhatsApp(x: Detail, msg: string) {
    const phone = x.customer.whatsapp?.replace(/\D/g, "");
    const url = phone
      ? `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`
      : `https://wa.me/?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
  }

  /** مشاركة ملخص الفاتورة عبر واتساب مع رابط التحقق العام */
  function shareWhatsApp() {
    if (!d) return;
    openWhatsApp(d, waMessageFromDetail(d));
  }

  /** مشاركة سريعة من صف القائمة — تجلب التفاصيل ثم تبني نفس الرسالة */
  async function quickShare(id: number) {
    setWaBusyId(id);
    try {
      const { body } = await api<Detail>(`/api/v1/sales/invoices/${id}`);
      if (body.success && body.data) openWhatsApp(body.data, waMessageFromDetail(body.data));
      else toast.error(body.message ?? "تعذر تحميل الفاتورة");
    } finally { setWaBusyId(null); }
  }

  /** تذكير سداد ودّي — للفواتير الآجلة غير المسددة */
  async function quickRemind(id: number) {
    setWaBusyId(id);
    try {
      const { body } = await api<Detail>(`/api/v1/sales/invoices/${id}`);
      if (!body.success || !body.data) { toast.error(body.message ?? "تعذر تحميل الفاتورة"); return; }
      const x = body.data;
      const msg = [
        `السلام عليكم ${x.customer.name}`,
        `تذكير ودّي بخصوص الفاتورة *${x.number}*`,
        `المتبقي: ${n(x.due_amount)} د.ع${x.due_date ? ` (الاستحقاق: ${formatDateTime(x.due_date)})` : ""}`,
        `رصيدكم الحالي لدينا: ${n(x.new_balance)} د.ع`,
        `نرجو التكرم بالسداد في أقرب فرصة، وشكراً لحسن تعاملكم.`,
      ].join("\n");
      openWhatsApp(x, msg);
    } finally { setWaBusyId(null); }
  }

  /** تحصيل سريع على الفاتورة — يستخدم واجهة المالية kind=collection مع invoice_id */
  async function recordPayment() {
    if (!d) return;
    if (!payCashbox) { toast.error("اختر صندوق النقد أولاً"); return; }
    const amount = Number(payAmount);
    if (!amount || amount <= 0) { toast.error("أدخل مبلغ تحصيل صحيحاً"); return; }
    if (amount > d.due_amount + 0.001) {
      toast.error(`المبلغ يتجاوز المتبقي على الفاتورة (${n(d.due_amount)} د.ع)`);
      return;
    }
    setPaying(true);
    try {
      const { body } = await api("/api/v1/finance/transactions", {
        method: "POST",
        body: JSON.stringify({
          kind: "collection",
          customer_id: d.customer.id,
          cashbox_id: payCashbox,
          amount,
          invoice_id: d.id,
          note: `تحصيل على الفاتورة ${d.number}`,
        }),
      });
      if (body.success) {
        toast.success("سُجل التحصيل وحدُث رصيد العميل ✓");
        setPayAmount("");
        openDetail(d.id);
        load(page);
      } else toast.error(body.message ?? "فشل تسجيل التحصيل");
    } finally {
      setPaying(false);
    }
  }

  /** إلغاء الفاتورة مع عكس الآثار (مخزون + عبوات + ذمة) */
  async function voidInvoice() {
    if (!d) return;
    const reason = window.prompt("سبب إلغاء الفاتورة (يُسجل في سجل التدقيق):") ?? "";
    if (!reason.trim()) return;
    if (!window.confirm(
      `تأكيد إلغاء الفاتورة ${d.number}؟\n${d.stock_applied ? "سيُعاد المخزون والعبوات ويُخصم المتبقي من ذمة العميل." : "لم تُطبق آثاراً بعد — إلغاء بسيط."}`
    )) return;
    setVoiding(true);
    try {
      const { body } = await api(`/api/v1/sales/invoices/${d.id}/void`, {
        method: "POST",
        body: JSON.stringify({ reason: reason.trim() }),
      });
      if (body.success) {
        toast.success("أُلغيت الفاتورة وعُكست آثارها بالكامل");
        openDetail(d.id);
        load(page);
      } else toast.error(body.message ?? "فشل الإلغاء");
    } finally {
      setVoiding(false);
    }
  }

  /** تأكيد الاستلام والتوقيع — يسجل المستلم ويضبط وقت التوقيع (غير قابل للتكرار) */
  async function confirmReceipt() {
    if (!d) return;
    if (receipt.name.trim().length < 2) { toast.error("أدخل اسم المستلم (حرفان على الأقل)"); return; }
    setConfirming(true);
    try {
      const { body } = await api(`/api/v1/sales/invoices/${d.id}/confirm-receipt`, {
        method: "POST",
        body: JSON.stringify({ receiver_name: receipt.name.trim(), receiver_phone: receipt.phone.trim() || null }),
      });
      if (body.success) {
        toast.success(`سُجل استلام الفاتورة ${d.number} وتوقيع ${receipt.name.trim()} ✓`);
        setShowReceiptForm(false);
        setReceipt({ name: "", phone: "" });
        openDetail(d.id);
        load(page);
      } else toast.error(body.message ?? "فشل تأكيد الاستلام");
    } finally {
      setConfirming(false);
    }
  }

  /** إعادة طلب — ينسخ بنود الفاتورة إلى نموذج فاتورة جديدة جاهزة للترحيل */
  function cloneInvoice() {
    if (!d) return;
    if (d.status !== "POSTED" && d.status !== "PENDING_APPROVAL") {
      toast.error("لا يمكن إعادة طلب فاتورة ملغاة/مرفوضة");
      return;
    }
    const clonePayload = {
      customer_id: d.customer.id,
      warehouse_id: null, // سيُستخدم المستودع الافتراضي — الأمان على الخادم
      sale_type: d.sale_type === "CASH" ? "CASH" : "CREDIT",
      source_number: d.number,
      lines: d.lines.map((l) => ({
        product_id: l.product.code, // يُحل بالكود ثم بالمعرف في نموذج الفاتورة
        product_id_num: null,
        package_qty: l.package_qty,
        loose_qty: l.loose_qty,
        qty: l.qty,
        unit_price: l.unit_price,
        package_price: l.package_price,
        discount_pct: l.discount_pct,
      })),
    };
    sessionStorage.setItem("invoice_clone", JSON.stringify(clonePayload));
    window.dispatchEvent(new CustomEvent("sales:goto-tab", { detail: "new-invoice" }));
    toast.success(`جاهز: أعيد تحميل بنود ${d.number} في نموذج فاتورة جديدة — راجع الكميات والأسعار ثم رحّل`);
  }

  /** مشاركة الفاتورة بالبريد الإلكتروني (mailto) */
  function shareEmail() {
    if (!d) return;
    const usd = d.currency_code === "USD" && d.exchange_rate;
    const m = (v: number) => (usd ? formatUSD(v / (d.exchange_rate as number)) : `${n(v)} د.ع`);
    const verifyUrl = d.verify_token ? `${window.location.origin}/verify/${d.verify_token}` : "";
    const subject = `فاتورة ${d.number} — ${d.customer.name}`;
    const body = [
      `فاتورة ${d.number}`,
      `التاريخ: ${formatDateTime(d.invoice_date)}`,
      `العميل: ${d.customer.name}`,
      `عدد البنود: ${d.lines.length}`,
      `الإجمالي: ${m(d.grand_total)}`,
      `المدفوع: ${m(d.paid_amount)}`,
      d.due_amount > 0 ? `المتبقي: ${m(d.due_amount)}` : "",
      `الرصيد الجديد: ${m(d.new_balance)}`,
      usd ? `سعر الصرف: ${n(d.exchange_rate as number)} د.ع لكل $1` : "",
      verifyUrl ? `\nتحقق من صحة الفاتورة:\n${verifyUrl}` : "",
    ].filter(Boolean).join("\n");
    // mailto بلا مستلم — يفتح نافذة الإنشاء ليعيد المرسل إرفاق العنوان أو نسخ النص
    window.location.assign(`mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
  }

  /** تصدير الصفحة الحالية CSV (يدعم العربية عبر BOM) */
  function exportCsv() {
    if (!rows?.length) { toast.error("لا بيانات للتصدير"); return; }
    const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const head = ["الرقم", "التاريخ", "العميل", "النوع", "الحالة", "الإجمالي", "المدفوع", "المتبقي", "رصيد سابق", "رصيد جديد", "المندوب", "المستودع"];
    const lines = rows.map((r) => [
      r.number, formatDateTime(r.invoice_date), r.customer.name,
      SALE_TYPE_LABEL[r.sale_type] ?? r.sale_type,
      STATUS_INFO[r.status]?.label ?? r.status,
      r.grand_total, r.paid_amount, r.due_amount, r.previous_balance, r.new_balance,
      r.rep, r.warehouse.name,
    ].map(esc).join(","));
    const csv = "\uFEFF" + [head.map(esc).join(","), ...lines].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `invoices-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
    toast.success(`صُدّرت ${rows.length} فاتورة ✓`);
  }

  React.useEffect(() => {
    return () => { document.body.classList.remove("print-thermal"); };
  }, []);

  const d = detail;
  // ---- العملة المزدوجة: عرض مبالغ الفاتورة بعملتها ----------------------------------
  // IQD: كما كانت (أرقام عادية) · USD: المبالغ بالدولار = المخزن ÷ سعر الصرف
  const isUsd = d?.currency_code === "USD";
  const dRate = d?.exchange_rate ?? null;
  const mn = (v: number) => (isUsd && dRate ? formatUSD(v / dRate) : n(v));
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <CardTitle className="flex items-center gap-2"><Receipt className="w-5 h-5 text-primary" /> فواتير البيع</CardTitle>
              <CardDescription>الفاتورة الذكية: رصيد سابق مفصول + عبوات + حد ائتماني — بصلاحية sales.invoices.view</CardDescription>
            </div>
            <div className="flex gap-2 flex-wrap">
              <div className="relative">
                <Search className="w-4 h-4 absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input className="pr-8 w-44 h-9" placeholder="رقم أو عميل..." value={q} onChange={(e) => setQ(e.target.value)} />
              </div>
              <input type="date" className="h-9 rounded-md border bg-background px-2 text-sm" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} aria-label="من تاريخ" title="من تاريخ" />
              <input type="date" className="h-9 rounded-md border bg-background px-2 text-sm" value={dateTo} onChange={(e) => setDateTo(e.target.value)} aria-label="إلى تاريخ" title="إلى تاريخ" />
              <select className="h-9 rounded-md border bg-background px-3 text-sm" value={type} onChange={(e) => setType(e.target.value)}>
                <option value="">كل الأنواع</option>
                <option value="CASH">نقدية</option>
                <option value="CREDIT">آجل</option>
              </select>
              <select className="h-9 rounded-md border bg-background px-3 text-sm" value={status} onChange={(e) => setStatus(e.target.value)}>
                <option value="">كل الحالات</option>
                <option value="POSTED">معتمدة</option>
                <option value="PENDING_APPROVAL">بانتظار الاعتماد</option>
                <option value="REJECTED">مرفوضة</option>
                <option value="VOID">ملغاة</option>
              </select>
              {(q || type || status || dateFrom || dateTo) && (
                <Button size="sm" variant="ghost" onClick={() => { setQ(""); setType(""); setStatus(""); setDateFrom(""); setDateTo(""); }}>
                  <X className="w-4 h-4" /> مسح الفلاتر
                </Button>
              )}
              <Button size="sm" variant="outline" onClick={exportCsv} disabled={!rows?.length}>
                <Download className="w-4 h-4" /> CSV
              </Button>
              <Button size="sm" variant="outline" onClick={() => load(page)} disabled={loading}>
                <RefreshCcw className={"w-4 h-4" + (loading ? " animate-spin" : "")} /> تحديث
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* شريط الملخص الإحصائي — يغطي كل النتائج المطابقة للفلاتر */}
          {summary && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 mb-4">
              <div className="rounded-lg border bg-muted/30 p-2.5">
                <div className="text-[11px] text-muted-foreground">عدد الفواتير</div>
                <div className="text-lg font-bold" dir="ltr">{n(summary.count)}</div>
              </div>
              <div className="rounded-lg border bg-primary/5 p-2.5">
                <div className="text-[11px] text-muted-foreground">إجمالي الفواتير (د.ع)</div>
                <div className="text-lg font-bold text-primary" dir="ltr">{n(summary.total)}</div>
              </div>
              <div className="rounded-lg border bg-emerald-500/5 p-2.5">
                <div className="text-[11px] text-muted-foreground">المُحصّل</div>
                <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400" dir="ltr">{n(summary.paid)}</div>
              </div>
              <div className="rounded-lg border bg-amber-500/5 p-2.5">
                <div className="text-[11px] text-muted-foreground">المتبقي (ذمم)</div>
                <div className="text-lg font-bold text-amber-600 dark:text-amber-400" dir="ltr">{n(summary.due)}</div>
              </div>
            </div>
          )}
          {rows === null ? (
            <div className="py-10 text-center text-muted-foreground">جارٍ التحميل...</div>
          ) : rows.length === 0 ? (
            <div className="py-10 text-center text-muted-foreground">لا فواتير مطابقة</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الرقم</TableHead>
                  <TableHead>التاريخ</TableHead>
                  <TableHead>العميل</TableHead>
                  <TableHead>نوع العميل</TableHead>
                  <TableHead>النوع</TableHead>
                  <TableHead>الحالة</TableHead>
                  <TableHead className="text-left">الفاتورة</TableHead>
                  <TableHead className="text-left">رصيد سابق</TableHead>
                  <TableHead className="text-left">رصيد جديد</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((inv) => (
                  <TableRow key={inv.id} className="cursor-pointer hover:bg-muted/40" onClick={() => openDetail(inv.id)}>
                    <TableCell dir="ltr" className="font-mono text-xs text-right font-semibold">{inv.number}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{formatDateTime(inv.invoice_date)}</TableCell>
                    <TableCell className="text-sm font-medium">{inv.customer.name}</TableCell>
                    <TableCell>
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${inv.customer_type === "REGISTERED" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"}`}>
                        {inv.customer_type === "REGISTERED" ? "مسجل" : inv.customer_type === "WALK_IN" ? "WALK-IN" : inv.customer_type === "CASH_CUSTOMER" ? "CASH" : "GUEST"}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge variant={inv.sale_type === "CASH" ? "success" : inv.sale_type === "PARTIAL" ? "accent" : "navy"} className="text-[10px]">
                        {SALE_TYPE_LABEL[inv.sale_type] ?? inv.sale_type}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={STATUS_INFO[inv.status]?.variant ?? "secondary"} className="text-[10px]">
                        {STATUS_INFO[inv.status]?.label ?? inv.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">
                      {inv.currency_code === "USD" && inv.exchange_rate ? (
                        <span className="text-sky-700 dark:text-sky-400">{fmtMoney(inv.grand_total, "USD", inv.exchange_rate)}</span>
                      ) : formatIQD(inv.grand_total)}
                    </TableCell>
                    <TableCell className="text-left text-xs" dir="ltr">{n(inv.previous_balance)}</TableCell>
                    <TableCell className="text-left font-semibold text-amber-600" dir="ltr">{n(inv.new_balance)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-0.5" onClick={(e) => e.stopPropagation()}>
                        <Button
                          size="icon" variant="ghost" className="h-7 w-7 text-emerald-700 dark:text-emerald-400 hover:text-emerald-600"
                          disabled={waBusyId === inv.id}
                          onClick={() => quickShare(inv.id)}
                          title="إرسال الفاتورة على واتساب"
                        >
                          {waBusyId === inv.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <MessageCircle className="w-3.5 h-3.5" />}
                        </Button>
                        {inv.sale_type !== "CASH" && inv.due_amount > 0 && inv.status === "POSTED" && (
                          <Button
                            size="icon" variant="ghost" className="h-7 w-7 text-amber-600 hover:text-amber-500"
                            disabled={waBusyId === inv.id}
                            onClick={() => setQuickReceiptInv({ customerId: (inv as InvoiceRow & { customer_id?: number }).customer_id ?? 0, invoiceId: inv.id })}
                            title="استلام دفعة سريعة"
                          >
                            <Zap className="w-3.5 h-3.5" />
                          </Button>
                        )}
                        {inv.sale_type !== "CASH" && inv.due_amount > 0 && inv.status === "POSTED" && (
                          <Button
                            size="icon" variant="ghost" className="h-7 w-7 text-amber-600 hover:text-amber-500"
                            disabled={waBusyId === inv.id}
                            onClick={() => quickRemind(inv.id)}
                            title="تذكير العميل بالسداد"
                          >
                            {waBusyId === inv.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <BellRing className="w-3.5 h-3.5" />}
                          </Button>
                        )}
                        <Eye className="w-4 h-4 text-muted-foreground ml-1" />
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}

          {/* ترقيم الصفحات */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-3 pt-4">
              <Button size="sm" variant="outline" disabled={page <= 1 || loading} onClick={() => load(page - 1)}>السابق</Button>
              <span className="text-sm text-muted-foreground">صفحة <span dir="ltr" className="font-semibold">{page} / {totalPages}</span></span>
              <Button size="sm" variant="outline" disabled={page >= totalPages || loading} onClick={() => load(page + 1)}>التالي</Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ===================== عرض الفاتورة الذكية ===================== */}
      {d && (
        <Card className="border-primary/40">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <CardTitle dir="ltr" className="font-mono flex items-center gap-2">
                  {d.number}
                  <Badge variant={STATUS_INFO[d.status]?.variant ?? "secondary"} className="text-[10px]">{STATUS_INFO[d.status]?.label ?? d.status}</Badge>
                </CardTitle>
                <CardDescription>
                  {d.customer.name} · {SALE_TYPE_LABEL[d.sale_type] ?? d.sale_type} · {PAY_LABEL[d.payment_method] ?? d.payment_method} · {formatDateTime(d.invoice_date)} · بواسطة {d.created_by}{d.rep ? ` · مندوب: ${d.rep.name}` : ""}
                </CardDescription>
              </div>
              <div className="flex gap-2 flex-wrap">
                {d.status === "PENDING_APPROVAL" && canApprove && (
                  <Button size="sm" onClick={() => act(d.id, "approve")}><Check className="w-4 h-4" /> اعتماد وتطبيق الآثار</Button>
                )}
                {d.status === "PENDING_APPROVAL" && canReject && (
                  <Button size="sm" variant="destructive" onClick={() => act(d.id, "reject")}><X className="w-4 h-4" /> رفض</Button>
                )}
                {(d.status === "POSTED" || d.status === "PENDING_APPROVAL") && perms.has("sales.invoices.cancel") && (
                  <Button size="sm" variant="destructive" onClick={voidInvoice} disabled={voiding}>
                    <Ban className="w-4 h-4" /> {voiding ? "جارٍ الإلغاء..." : "إلغاء الفاتورة"}
                  </Button>
                )}
                {d.customer.whatsapp && d.status !== "REJECTED" && d.status !== "VOID" && (
                  <Button size="sm" variant="outline" onClick={shareWhatsApp} className="text-emerald-700 dark:text-emerald-400 border-emerald-600/40">
                    <MessageCircle className="w-4 h-4" /> واتساب
                  </Button>
                )}
                {d.status !== "REJECTED" && d.status !== "VOID" && (
                  <Button size="sm" variant="outline" onClick={shareEmail} title="مشاركة بالبريد الإلكتروني">
                    <Mail className="w-4 h-4" /> بريد
                  </Button>
                )}
                {(d.status === "POSTED" || d.status === "PENDING_APPROVAL") && perms.has("sales.invoices.create") && (
                  <Button size="sm" variant="outline" onClick={cloneInvoice} title="نسخ البنود إلى فاتورة جديدة">
                    <Copy className="w-4 h-4" /> إعادة طلب
                  </Button>
                )}
                <Button variant="outline" size="sm" onClick={() => { setPrintMode("A4"); document.body.classList.remove("print-thermal"); setTimeout(() => window.print(), 150); }}>
                  <Printer className="w-4 h-4" /> طباعة A4
                </Button>
                <Button variant="outline" size="sm" onClick={() => { setPrintMode("THERMAL"); document.body.classList.add("print-thermal"); setTimeout(() => window.print(), 150); }}>
                  <Printer className="w-4 h-4" /> حرارية 80mm
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setDetail(null)}>إغلاق ✕</Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* بطاقة العميل */}
            <div className="rounded-lg border bg-muted/30 p-3 grid gap-2 text-sm lg:grid-cols-3">
              <div className="lg:col-span-2 space-y-0.5">
                <div className="font-bold flex items-center gap-2">{d.customer.name}
                  <Badge variant={d.customer.status === "ACTIVE" ? "success" : d.customer.status === "BLOCKED" ? "destructive" : "accent"} className="text-[10px]">
                    {d.customer.status === "ACTIVE" ? "نشط" : d.customer.status === "BLOCKED" ? "موقوف" : "حجز ائتماني"}
                  </Badge>
                  <span className="text-xs text-muted-foreground font-normal" dir="ltr">#{d.customer.code}</span>
                </div>
                <div className="text-xs text-muted-foreground">
                  {d.customer.shopName && <>المحل: {d.customer.shopName} · </>}
                  {d.customer.phone && <span dir="auto">هاتف: {d.customer.phone}</span>}
                  {d.customer.whatsapp && <span dir="auto"> · واتساب: {d.customer.whatsapp}</span>}
                  {d.customer.area && <> · المنطقة: {d.customer.area}</>}
                </div>
                <div className="text-xs text-muted-foreground">
                  المستودع: {d.warehouse.name}{d.branch ? ` · الفرع: ${d.branch}` : ""}
                  {d.due_date && <> · <span className="text-amber-600">الاستحقاق: {formatDateTime(d.due_date)}</span></>}
                </div>
                {(d.source_orders.length > 0 || d.source_quotations.length > 0 || d.delivery_notes.length > 0) && (
                  <div className="text-xs text-muted-foreground">
                    {d.source_orders.length > 0 && <>أمر بيع: <span className="font-mono" dir="ltr">{d.source_orders.join(", ")}</span> </>}
                    {d.source_quotations.length > 0 && <>· عرض سعر: <span className="font-mono" dir="ltr">{d.source_quotations.join(", ")}</span> </>}
                    {d.delivery_notes.map((dn) => (
                      <span key={dn.number}>· تسليم: <span className="font-mono" dir="ltr">{dn.number}</span> ({dn.status === "DELIVERED" ? `سُلمت${dn.driver ? ` — سائق: ${dn.driver}` : ""}` : "قيد التوصيل"}) </span>
                    ))}
                  </div>
                )}
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs"><span className="text-muted-foreground">المستلم:</span><span>{d.receiver_name || "—"}{d.receiver_phone ? ` · ${d.receiver_phone}` : ""}</span></div>
                <div className="flex justify-between text-xs"><span className="text-muted-foreground">توقيع العميل:</span><span>{d.signed_at ? formatDateTime(d.signed_at) : "—"}</span></div>
                <div className="flex justify-between text-xs"><span className="text-muted-foreground">وقت التسليم:</span><span>{d.delivered_at ? formatDateTime(d.delivered_at) : "—"}</span></div>
              </div>
            </div>

            {/* البنود مع العبوات */}
            <div className="rounded-lg border overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-xs text-muted-foreground">
                  <tr>
                    <th className="p-2 font-medium text-right">المنتج</th>
                    <th className="p-2 font-medium">التعبئة</th>
                    <th className="p-2 font-medium">الكمية</th>
                    <th className="p-2 font-medium">إجمالي الحبات</th>
                    <th className="p-2 font-medium">سعر الحبة</th>
                    <th className="p-2 font-medium">سعر العبوة</th>
                    <th className="p-2 font-medium">خصم</th>
                    <th className="p-2 font-medium">الإجمالي</th>
                    <th className="p-2 font-medium">قبل → بعد</th>
                  </tr>
                </thead>
                <tbody>
                  {d.lines.map((l) => (
                    <tr key={l.id} className="border-t">
                      <TableCell className="font-medium">{l.product.name}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {l.product.packUnit && l.product.packQty ? `1 ${l.product.packUnit} = ${n(Number(l.product.packQty))} ${l.product.unit}` : "—"}
                      </TableCell>
                      <TableCell className="text-xs">
                        {d.packaging_details && l.package_qty > 0
                          ? <span dir="ltr">{n(l.package_qty)} {l.package_type_label ?? "عبوة"} + {n(l.loose_qty)} {l.product.unit}</span>
                          : <span dir="ltr">{n(l.qty)} {l.product.unit}</span>}
                        {l.package_note && <div className="text-[10px] text-sky-700 dark:text-sky-400 flex items-center gap-1"><Package className="w-3 h-3" />{l.package_note}</div>}
                      </TableCell>
                      <TableCell dir="ltr">{n(l.qty)}</TableCell>
                      <TableCell dir="ltr">{mn(l.unit_price)}</TableCell>
                      <TableCell dir="ltr">{l.package_price != null ? mn(l.package_price) : "—"}</TableCell>
                      <TableCell dir="ltr" className="text-xs">{l.discount_pct ? `${l.discount_pct}%` : ""}{l.discount_amount ? ` ${mn(l.discount_amount)}` : ""}{!l.discount_pct && !l.discount_amount ? "—" : ""}</TableCell>
                      <TableCell className="font-semibold" dir="ltr">{mn(l.line_total)}</TableCell>
                      <TableCell className="text-xs text-muted-foreground" dir="ltr">{l.stock_before || l.stock_after ? `${n(l.stock_before)} → ${n(l.stock_after)}` : "—"}</TableCell>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* فصل الرصيد + الدفع */}
            <div className="grid gap-4 lg:grid-cols-2">
              <div className="rounded-lg border p-3 space-y-1.5 text-sm">
                <div className="text-xs font-semibold text-muted-foreground border-b pb-1">حساب العميل — الرصيد مفصول عن الفاتورة (§4){isUsd ? " — بالدولار بسعر الصرف المثبّت" : ""}</div>
                <div className="flex justify-between"><span className="text-muted-foreground">الرصيد السابق:</span><span dir="ltr" className="font-semibold">{mn(d.previous_balance)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">إجمالي الفاتورة:</span><span dir="ltr" className="font-semibold">{mn(d.grand_total)}</span></div>
                <div className="flex justify-between border-t pt-1.5 font-bold"><span>الإجمالي المستحق:</span><span dir="ltr">{mn(d.total_due)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">المدفوع:</span><span dir="ltr">{mn(d.paid_amount)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">المتبقي من الفاتورة:</span><span dir="ltr">{mn(d.due_amount)}</span></div>
                {d.credit_note_adjustment > 0 && (
                  <div className="flex justify-between text-[11px] text-success"><span className="text-muted-foreground">مسدّد بإشعار دائن (مرتجعات لاحقة):</span><span dir="ltr">− {n(d.credit_note_adjustment)}</span></div>
                )}
                <div className="flex justify-between border-t pt-1.5 text-base font-bold"><span>الرصيد الجديد:</span><span dir="ltr" className="text-amber-600">{mn(d.new_balance)}</span></div>
                {isUsd && dRate ? (
                  <div className="flex justify-between text-[11px] text-muted-foreground pt-1">
                    <span>القيد المحاسبي بالدينار — سعر الصرف المثبّت:</span><span dir="ltr">{n(dRate)} د.ع/$</span>
                  </div>
                ) : null}
                <div className="flex justify-between text-xs text-muted-foreground pt-1">
                  <span>حد الائتمان: <span dir="ltr">{n(d.credit_limit)}</span></span>
                  <span>المتاح بعدها: <span dir="ltr">{n(d.available_credit)}</span></span>
                </div>
                {d.mini_statement && (d.mini_statement.last_invoice || d.mini_statement.last_payment) && (
                  <div className="text-[11px] text-muted-foreground border-t pt-1.5 mt-1 space-y-0.5">
                    {d.mini_statement.last_invoice && <div>آخر فاتورة سابقة: <span className="font-mono" dir="ltr">{d.mini_statement.last_invoice.number}</span> · {n(d.mini_statement.last_invoice.total)}</div>}
                    {d.mini_statement.last_payment && <div>آخر دفعة: {n(d.mini_statement.last_payment.amount)}</div>}
                  </div>
                )}
              </div>
              <div className="space-y-3">
                <div className="rounded-lg border p-3 text-sm space-y-1">
                  <div className="text-xs font-semibold text-muted-foreground border-b pb-1">مجاميع الفاتورة{isUsd ? " — دولار" : ""}</div>
                  <div className="flex justify-between"><span className="text-muted-foreground">المجموع:</span><span dir="ltr">{mn(d.subtotal)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">الخصم:</span><span dir="ltr">− {mn(d.discount_total)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">الضريبة:</span><span dir="ltr">{mn(d.tax_total)}</span></div>
                  <div className="flex justify-between font-bold border-t pt-1"><span>الإجمالي:</span><span dir="ltr" className="text-primary">{mn(d.grand_total)}</span></div>
                  {isUsd && dRate ? (
                    <div className="flex justify-between text-[11px] text-muted-foreground"><span>المكافئ بالدينار:</span><span dir="ltr">{formatIQD(d.grand_total)}</span></div>
                  ) : null}
                </div>
                {d.packaging_ledger.length > 0 && (
                  <div className="rounded-lg border p-3 text-sm">
                    <div className="text-xs font-semibold text-muted-foreground border-b pb-1 mb-1">سجل التعبئة — Packaging Ledger (§13)</div>
                    <div className="space-y-1 text-xs max-h-40 overflow-y-auto">
                      {d.packaging_ledger.map((e, i) => (
                        <div key={i} className="flex justify-between gap-2 border-b border-dashed pb-0.5">
                          <span className="font-mono" dir="ltr">{e.packageCode}</span>
                          <span className="text-muted-foreground">{e.direction === "OPEN" ? "فتح عبوة" : e.direction === "ISSUE" ? "سحب" : "إرجاع"}</span>
                          <span dir="ltr">{n(e.openingQty)} → سحب {n(e.issuedQty)} → بقي {n(e.remainingQty)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* تحصيل سريع على الفاتورة (تطوير الفاتورة) */}
            {d.status === "POSTED" && d.due_amount > 0 && perms.has("finance.payments.create") && (
              <div className="rounded-lg border border-emerald-600/30 bg-emerald-500/5 p-3">
                <div className="text-xs font-semibold mb-2 flex items-center gap-1.5 flex-wrap">
                  <Wallet className="w-3.5 h-3.5" /> تحصيل سريع على هذه الفاتورة — المتبقي:
                  <span dir="ltr" className="font-bold">{n(d.due_amount)} د.ع</span>
                </div>
                <div className="flex gap-2 flex-wrap items-center">
                  <select className="h-9 rounded-md border bg-background px-3 text-sm min-w-40" value={payCashbox} onChange={(e) => setPayCashbox(e.target.value ? Number(e.target.value) : "")}>
                    <option value="">— اختر الصندوق —</option>
                    {cashboxes.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                  <input type="number" min="0" step="any" dir="ltr" className="h-9 w-40 rounded-md border bg-background px-3 text-sm" placeholder="المبلغ (د.ع)" value={payAmount} onChange={(e) => setPayAmount(e.target.value === "" ? "" : Number(e.target.value))} />
                  <Button size="sm" onClick={recordPayment} disabled={paying || !cashboxes.length}>
                    {paying ? "جارٍ التسجيل..." : "تسجيل التحصيل"}
                  </Button>
                  {!cashboxes.length && <span className="text-[11px] text-muted-foreground">لا صناديق نقد نشطة — أنشئ صندوقاً من قسم المالية</span>}
                </div>
              </div>
            )}

            {/* تأكيد الاستلام والتوقيع (تطوير الفاتورة — جولة 2) */}
            {d.status === "POSTED" && !d.signed_at && perms.has("sales.invoices.edit") && (
              <div className="rounded-lg border border-sky-600/30 bg-sky-500/5 p-3">
                <div className="text-xs font-semibold mb-2 flex items-center gap-1.5">
                  <PenLine className="w-3.5 h-3.5" /> تأكيد الاستلام والتوقيع — سجّل من استلم البضاعة ووقّعها
                </div>
                {!showReceiptForm ? (
                  <Button size="sm" variant="outline" onClick={() => setShowReceiptForm(true)}>
                    <PenLine className="w-3.5 h-3.5" /> تسجيل الاستلام والتوقيع
                  </Button>
                ) : (
                  <div className="flex gap-2 flex-wrap items-center">
                    <Input className="h-9 w-48" placeholder="اسم المستلم *" value={receipt.name} onChange={(e) => setReceipt((r) => ({ ...r, name: e.target.value }))} />
                    <Input className="h-9 w-40" placeholder="هاتف المستلم" dir="ltr" value={receipt.phone} onChange={(e) => setReceipt((r) => ({ ...r, phone: e.target.value }))} />
                    <Button size="sm" onClick={confirmReceipt} disabled={confirming}>
                      {confirming ? "جارٍ التسجيل..." : "تأكيد التوقيع"}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setShowReceiptForm(false)}>إلغاء</Button>
                  </div>
                )}
              </div>
            )}

            {/* سجل المدفوعات المفصلة على الفاتورة (تطوير الفاتورة — جولة 2) */}
            {d.payments && d.payments.length > 0 && (
              <div className="rounded-lg border p-3">
                <div className="text-xs font-semibold text-muted-foreground border-b pb-1 mb-2 flex items-center gap-1.5">
                  <Wallet className="w-3.5 h-3.5" /> سجل المدفوعات على هذه الفاتورة — {d.payments.length} حركة من كشف الصندوق
                </div>
                <div className="max-h-44 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="h-8">الوصل</TableHead>
                        <TableHead className="h-8">النوع</TableHead>
                        <TableHead className="h-8">الصندوق</TableHead>
                        <TableHead className="h-8 text-left">المبلغ</TableHead>
                        <TableHead className="h-8">بواسطة</TableHead>
                        <TableHead className="h-8">التاريخ</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {d.payments.map((p) => (
                        <TableRow key={p.id}>
                          <TableCell className="font-mono text-xs" dir="ltr">#{p.id}</TableCell>
                          <TableCell>
                            <Badge variant={p.direction === "IN" ? "success" : "destructive"} className="text-[10px]">
                              {p.direction === "IN" ? "تحصيل" : "استرداد"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-xs">{p.cashbox}</TableCell>
                          <TableCell className="text-left font-semibold text-xs" dir="ltr">{p.direction === "IN" ? "" : "−"}{n(p.amount)}</TableCell>
                          <TableCell className="text-xs text-muted-foreground">{p.by}</TableCell>
                          <TableCell className="text-xs text-muted-foreground">{formatDateTime(p.created_at)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {/* الملاحظات */}
            {(d.rep_notes || d.customer_notes || d.admin_notes || d.notes) && (
              <div className="grid gap-2 text-xs sm:grid-cols-2 lg:grid-cols-4">
                {d.rep_notes && <div className="rounded-md border p-2"><span className="text-muted-foreground">ملاحظات المندوب:</span> {d.rep_notes}</div>}
                {d.customer_notes && <div className="rounded-md border p-2"><span className="text-muted-foreground">ملاحظات العميل:</span> {d.customer_notes}</div>}
                {d.admin_notes && <div className="rounded-md border p-2"><span className="text-muted-foreground">ملاحظات الإدارة:</span> {d.admin_notes}</div>}
                {d.notes && <div className="rounded-md border p-2"><span className="text-muted-foreground">ملاحظات عامة:</span> {d.notes}</div>}
              </div>
            )}

            {qr && (
              <div className="flex items-center gap-3 border-t pt-3">
                <div className="w-20 h-20 shrink-0 [&>svg]:w-full [&>svg]:h-full" dangerouslySetInnerHTML={{ __html: qr.svg }} />
                <div className="text-xs text-muted-foreground leading-relaxed">
                  <div className="font-semibold text-foreground">QR التحقق — يحمل رمز تحقق آمن فقط (§37)</div>
                  <div dir="ltr" className="font-mono break-all">{d.verify_token}</div>
                  <div>امسحه بالهاتف للتأكد من صحة الفاتورة عبر صفحة التحقق العامة</div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* ===================== طباعة A4 ===================== */}
      {d && printMode === "A4" && (
        <PrintSheet onClose={() => setPrintMode(null)}>
          <div className="max-w-[820px] mx-auto" dir="rtl">
            <div className="text-center mb-2">
              {company?.logoUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={company.logoUrl} alt="شعار الشركة" className="w-14 h-14 object-contain mx-auto mb-1" />
              ) : null}
              <div className="text-xl font-bold">{company?.name ?? "—"}</div>
              <div className="text-xs text-gray-600">SALES INVOICE — فاتورة بيع</div>
              {(company?.phone || company?.address) && <div className="text-xs text-gray-600">هاتف: <span dir="ltr">{company?.phone}</span>{company?.address ? ` · ${company.address}` : ""}</div>}
              {company?.taxNumber && <div className="text-xs text-gray-600">الرقم الضريبي: <span dir="ltr">{company.taxNumber}</span></div>}
            </div>
            <div className="border-y-2 border-black py-2 mb-3 flex items-center justify-between">
              <div>
                <div className="font-mono font-bold text-lg" dir="ltr">{d.number}</div>
                <div className="text-xs">{formatDateTime(d.invoice_date)}{d.due_date ? ` · الاستحقاق: ${formatDateTime(d.due_date)}` : ""}</div>
              </div>
              <div className="text-left text-sm">
                <div>نوع البيع: <b>{SALE_TYPE_LABEL[d.sale_type] ?? d.sale_type}</b></div>
                <div>طريقة الدفع: {PAY_LABEL[d.payment_method] ?? d.payment_method}</div>
                {isUsd && dRate ? <div>العملة: دولار أمريكي · سعر الصرف: <b dir="ltr">{n(dRate)} د.ع/$</b></div> : null}
                <div>المندوب: {d.rep?.name ?? d.created_by} · المستودع: {d.warehouse.name}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm mb-3">
              <div className="border rounded p-2">
                <div className="font-bold">{d.customer.name} <span className="text-xs text-gray-500" dir="ltr">#{d.customer.code}</span></div>
                <div className="text-xs text-gray-600">
                  {d.customer.shopName ? `${d.customer.shopName} · ` : ""}<span dir="auto">{d.customer.phone ?? ""}</span>
                  {d.customer.area ? ` · ${d.customer.area}` : ""}
                </div>
              </div>
              <div className="border rounded p-2 text-xs">
                {d.receiver_name && <div>المستلم: {d.receiver_name} <span dir="ltr">{d.receiver_phone ?? ""}</span></div>}
                {d.source_orders.length > 0 && <div>أمر بيع: <span dir="ltr">{d.source_orders.join(", ")}</span></div>}
                {d.source_quotations.length > 0 && <div>عرض سعر: <span dir="ltr">{d.source_quotations.join(", ")}</span></div>}
                {d.delivery_notes.map((dn) => <div key={dn.number}>إشعار تسليم: <span dir="ltr">{dn.number}</span></div>)}
              </div>
            </div>
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 px-2 py-1 text-right">#</th>
                  <th className="border border-gray-300 px-2 py-1 text-right">المنتج</th>
                  <th className="border border-gray-300 px-2 py-1">الوحدة</th>
                  <th className="border border-gray-300 px-2 py-1">التعبئة</th>
                  <th className="border border-gray-300 px-2 py-1">الكمية</th>
                  <th className="border border-gray-300 px-2 py-1">حبات</th>
                  <th className="border border-gray-300 px-2 py-1">سعر الحبة</th>
                  <th className="border border-gray-300 px-2 py-1">سعر العبوة</th>
                  <th className="border border-gray-300 px-2 py-1">خصم</th>
                  <th className="border border-gray-300 px-2 py-1">الإجمالي</th>
                </tr>
              </thead>
              <tbody>
                {d.lines.map((l, i) => (
                  <tr key={l.id}>
                    <td className="border border-gray-300 px-2 py-1 text-center" dir="ltr">{i + 1}</td>
                    <td className="border border-gray-300 px-2 py-1">{l.product.name}</td>
                    <td className="border border-gray-300 px-2 py-1 text-center text-xs">{l.product.unit}</td>
                    <td className="border border-gray-300 px-2 py-1 text-center text-xs">{l.product.packUnit && l.product.packQty ? `1 ${l.product.packUnit} = ${n(Number(l.product.packQty))}` : "—"}</td>
                    <td className="border border-gray-300 px-2 py-1 text-center" dir="ltr">{d.packaging_details && l.package_qty > 0 ? `${n(l.package_qty)} ${l.package_type_label ?? "عبوة"} + ${n(l.loose_qty)}` : `${n(l.qty)} ${l.product.unit}`}</td>
                    <td className="border border-gray-300 px-2 py-1 text-center" dir="ltr">{n(l.qty)}</td>
                    <td className="border border-gray-300 px-2 py-1 text-center" dir="ltr">{mn(l.unit_price)}</td>
                    <td className="border border-gray-300 px-2 py-1 text-center" dir="ltr">{l.package_price != null ? mn(l.package_price) : "—"}</td>
                    <td className="border border-gray-300 px-2 py-1 text-center" dir="ltr">{l.discount_pct ? `${l.discount_pct}%` : l.discount_amount ? mn(l.discount_amount) : "—"}</td>
                    <td className="border border-gray-300 px-2 py-1 text-center font-semibold" dir="ltr">{mn(l.line_total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="mt-3 grid grid-cols-2 gap-4">
              <div className="text-sm space-y-1">
                <div className="flex justify-between border-b pb-1"><span className="text-gray-600">الرصيد السابق:</span><span dir="ltr" className="font-semibold">{mn(d.previous_balance)}</span></div>
                <div className="flex justify-between border-b pb-1"><span className="text-gray-600">إجمالي الفاتورة:</span><span dir="ltr" className="font-semibold">{mn(d.grand_total)}</span></div>
                <div className="flex justify-between border-b-2 border-black pb-1 font-bold"><span>الإجمالي المستحق:</span><span dir="ltr">{mn(d.total_due)}</span></div>
                <div className="flex justify-between border-b pb-1"><span className="text-gray-600">المدفوع:</span><span dir="ltr">{mn(d.paid_amount)}</span></div>
                <div className="flex justify-between border-b pb-1"><span className="text-gray-600">المتبقي من الفاتورة:</span><span dir="ltr">{mn(d.due_amount)}</span></div>
                <div className="flex justify-between text-base font-bold"><span>الرصيد الجديد:</span><span dir="ltr">{mn(d.new_balance)}</span></div>
                {isUsd && dRate ? <div className="text-[10px] text-gray-500">القيد المحاسبي بالدينار العراقي — سعر الصرف: {n(dRate)} د.ع لكل $1</div> : null}
                <div className="text-[10px] text-gray-500 pt-1">
                  {d.customer.creditLimit > 0 && <>حد الائتمان: {n(d.customer.creditLimit)} · المتاح: {n(d.available_credit)}</>}
                </div>
              </div>
              <div className="text-xs text-gray-600 self-end">
                <div className="flex gap-8 mb-2">
                  <div>توقيع العميل: ______________________<div className="text-[9px]">{d.signed_at ? `وقّع ${formatDateTime(d.signed_at)}` : ""}</div></div>
                  <div>توقيع المندوب: ______________________</div>
                </div>
                <div>المستلم: {d.receiver_name ?? "______________________"} <span dir="ltr">{d.receiver_phone ?? ""}</span></div>
                {qr && (
                  <div className="mt-3 flex items-center gap-2">
                    <div className="w-20 h-20 [&>svg]:w-full [&>svg]:h-full" dangerouslySetInnerHTML={{ __html: qr.svg }} />
                    <div className="text-[9px] text-gray-500 leading-snug">
                      فاتورة موثقة برمز تحقق<br />امسح للتحقق من الصحة
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="mt-4 border-t pt-2 text-center text-[10px] text-gray-500 whitespace-pre-line">{d.footer_text}</div>
            <div className="mt-2 text-center text-[9px] text-gray-400">
              طُبعت من نظام ميدان لمبيعات والتوزيع · {new Date().toLocaleString("ar-IQ")}
            </div>
          </div>
        </PrintSheet>
      )}

      {/* ===================== طباعة حرارية 80mm ===================== */}
      {d && printMode === "THERMAL" && (
        <PrintSheet thermal onClose={() => setPrintMode(null)}>
          <div className="mx-auto thermal-receipt" dir="rtl">
            <div className="text-center">
              {company?.logoUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={company.logoUrl} alt="شعار الشركة" className="w-10 h-10 object-contain mx-auto mb-0.5" />
              ) : null}
              <div className="font-bold text-sm">{company?.name ?? "—"}</div>
              <div className="text-[10px]">{company?.phone} {company?.address ? `· ${company.address}` : ""}</div>
            </div>
            <div className="my-1 border-t border-dashed border-black" />
            <div className="text-[10px] flex justify-between"><span dir="ltr">{d.number}</span><span>{formatDateTime(d.invoice_date)}</span></div>
            <div className="text-[10px]">العميل: {d.customer.name}</div>
            <div className="text-[10px]">المندوب: {d.rep?.name ?? d.created_by} · {SALE_TYPE_LABEL[d.sale_type] ?? d.sale_type}</div>
            <div className="text-[10px] font-bold">الرصيد السابق: {mn(d.previous_balance)}</div>
            <div className="my-1 border-t border-dashed border-black" />
            {d.lines.map((l) => (
              <div key={l.id} className="mb-1.5">
                <div className="text-[11px] font-bold">{l.product.name}</div>
                <div className="text-[10px] flex justify-between">
                  <span>{d.packaging_details && l.package_qty > 0 ? `${n(l.package_qty)} ${l.package_type_label ?? "عبوة"} + ${n(l.loose_qty)} ${l.product.unit}` : `${n(l.qty)} ${l.product.unit}`}</span>
                  <span dir="ltr">إجمالي: {n(l.qty)}</span>
                </div>
                <div className="text-[10px] flex justify-between font-semibold"><span>السعر:</span><span dir="ltr">{mn(l.line_total)}</span></div>
              </div>
            ))}
            <div className="my-1 border-t border-dashed border-black" />
            <div className="text-[10px] flex justify-between"><span>المجموع:</span><span dir="ltr">{mn(d.subtotal)}</span></div>
            {d.discount_total > 0 && <div className="text-[10px] flex justify-between"><span>الخصم:</span><span dir="ltr">-{mn(d.discount_total)}</span></div>}
            <div className="text-[11px] flex justify-between font-bold"><span>الفاتورة:</span><span dir="ltr">{mn(d.grand_total)}</span></div>
            <div className="text-[10px] flex justify-between"><span>الرصيد السابق:</span><span dir="ltr">{mn(d.previous_balance)}</span></div>
            <div className="text-[10px] flex justify-between"><span>المدفوع:</span><span dir="ltr">{mn(d.paid_amount)}</span></div>
            <div className="text-[11px] flex justify-between font-bold border-t border-black mt-1 pt-1"><span>الرصيد الجديد:</span><span dir="ltr">{mn(d.new_balance)}</span></div>
            {isUsd && dRate ? <div className="text-[9px] text-gray-500">سعر الصرف: {n(dRate)} د.ع/$ — القيد المحاسبي بالدينار</div> : null}
            {d.due_date && <div className="text-[10px]">الاستحقاق: {formatDateTime(d.due_date)}</div>}
            <div className="my-1 border-t border-dashed border-black" />
            {qr && <div className="flex justify-center py-1"><div className="w-24 h-24 [&>svg]:w-full [&>svg]:h-full" dangerouslySetInnerHTML={{ __html: qr.svg }} /></div>}
            <div className="text-center text-[9px] whitespace-pre-line">{d.footer_text}</div>
            <div className="text-center text-[9px] mt-1">توقيع العميل: ________ · المندوب: ________</div>
          </div>
        </PrintSheet>
      )}

      {/* تحصيل سريع من قائمة الفواتير */}
      {quickReceiptInv && (
        <QuickReceiptForm
          presetCustomerId={quickReceiptInv.customerId || null}
          presetInvoiceId={quickReceiptInv.invoiceId}
          onClose={() => setQuickReceiptInv(null)}
          onDone={() => load(page)}
        />
      )}
    </div>
  );
}

/** Fullscreen print overlay — only this node visible in @media print. */
function PrintSheet({ children, onClose, thermal }: { children: React.ReactNode; onClose: () => void; thermal?: boolean }) {
  return (
    <div id="invoice-print-area" className="fixed inset-0 z-[90] overflow-auto bg-white text-black print:static print:overflow-visible">
      <div className={thermal ? "p-3" : "p-6"}>
        {children}
        <div className="mt-4 text-center print:hidden">
          <button className="border px-4 py-2 rounded text-sm font-semibold" onClick={() => window.print()}>طباعة الآن</button>
          {" "}
          <button className="border px-4 py-2 rounded text-sm" onClick={onClose}>إغلاق</button>
        </div>
      </div>
    </div>
  );
}
