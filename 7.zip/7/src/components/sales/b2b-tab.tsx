"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { api } from "@/lib/client-api";
import { formatDateTime } from "@/lib/utils";
import {
  CloudDownload, Globe, Inbox, LogIn, RefreshCw, ShoppingCart, Upload, UserCheck, XCircle,
} from "lucide-react";

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";
const fmtIQD = (n: number) => new Intl.NumberFormat("ar-IQ", { maximumFractionDigits: 0 }).format(n);

interface B2BOrderRow {
  id: number; number: string; status: string;
  customer: { id: number; code: string; name: string };
  grand_total: number; subtotal: number; notes: string | null;
  lines: { product: { code: string; name: string; unit: string }; qty: number; unit_price: number; line_total: number }[];
  confirmed_invoice: string | null;
  created_at: string;
}
interface PortalProduct {
  id: number; code: string; name: string; category: string | null; unit: string;
  list_price: number; discount_pct: number; your_price: number;
}
interface PortalState {
  token: string;
  customer: { id: number; code: string; name: string; discount_pct: number; balance: number; credit_limit: number };
}
interface StatementData {
  customer: { code: string; name: string; balance: number; credit_limit: number };
  invoices: { id: number; number: string; invoiceDate: string; type: string; grandTotal: number; due_amount: number; status: string }[];
  orders: { id: number; number: string; status: string; grandTotal: number; createdAt: string }[];
}

const ORDER_STATUS: Record<string, { label: string; variant: "secondary" | "default" | "success" | "destructive" }> = {
  SUBMITTED: { label: "مقدّم", variant: "secondary" },
  CONFIRMED: { label: "معتمد ← فاتورة", variant: "success" },
  REJECTED: { label: "مرفوض", variant: "destructive" },
  CANCELLED: { label: "ملغى", variant: "destructive" },
};

export function B2BTab({ warehouses, canApprove, canReject }: {
  warehouses: { id: number; code: string; name: string }[];
  canApprove: boolean; canReject: boolean;
}) {
  return (
    <Tabs defaultValue="orders" dir="rtl">
      <TabsList className="w-full justify-start overflow-x-auto scroll-thin h-auto py-1">
        <TabsTrigger value="orders"><Inbox className="w-4 h-4" /> طلبات البوابة</TabsTrigger>
        <TabsTrigger value="portal"><Globe className="w-4 h-4" /> تجربة بوابة العميل</TabsTrigger>
        <TabsTrigger value="sync"><RefreshCw className="w-4 h-4" /> المزامنة (دون اتصال)</TabsTrigger>
      </TabsList>

      <TabsContent value="orders"><OrdersQueue warehouses={warehouses} canApprove={canApprove} canReject={canReject} /></TabsContent>
      <TabsContent value="portal"><PortalSimulator /></TabsContent>
      <TabsContent value="sync"><SyncPanel warehouses={warehouses} /></TabsContent>
    </Tabs>
  );
}

// ---------------------------------------------------------------------
// طابور طلبات B2B (الجهة الإدارية)
// ---------------------------------------------------------------------
function OrdersQueue({ warehouses, canApprove, canReject }: {
  warehouses: { id: number; code: string; name: string }[]; canApprove: boolean; canReject: boolean;
}) {
  const [rows, setRows] = React.useState<B2BOrderRow[] | null>(null);
  const [acting, setActing] = React.useState<number | null>(null);
  const [whId, setWhId] = React.useState<number | undefined>(warehouses[0]?.id);
  const [type, setType] = React.useState<"CASH" | "CREDIT">("CASH");

  const load = React.useCallback(async () => {
    const { body } = await api<B2BOrderRow[]>("/api/v1/b2b/admin/orders");
    if (body.success && body.data) setRows(body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  async function confirmOrder(id: number) {
    if (!whId) return toast.error("اختر المستودع");
    setActing(id);
    try {
      const { body } = await api(`/api/v1/b2b/admin/orders/${id}/confirm`, {
        method: "POST",
        body: JSON.stringify({ warehouse_id: whId, type }),
      });
      if (body.success) {
        const d = body.data as { invoice: { number: string } };
        toast.success(`اعتُمد الطلب وأُصدرت فاتورة ${d.invoice.number} — المخزون والذمة حُدّثا ✓`);
        await load();
      } else toast.error(body.message ?? "فشل الاعتماد");
    } finally { setActing(null); }
  }

  async function rejectOrder(id: number) {
    setActing(id);
    try {
      const { body } = await api(`/api/v1/b2b/admin/orders/${id}/reject`, { method: "POST", body: "{}" });
      if (body.success) { toast.success("رُفض الطلب"); await load(); }
      else toast.error(body.message ?? "فشل الرفض");
    } finally { setActing(null); }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2"><Inbox className="w-5 h-5 text-primary" /> طلبات بوابة العملاء</CardTitle>
          <CardDescription>
            الاعتماد يُصدر فاتورة حقيقية عبر محرك الترحيل نفسه (خصم مخزون + حاجز ائتمان) — الاعتماد المكرر يُرفض (VAL_004)
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center gap-3 flex-wrap">
          <label className="text-xs font-medium space-y-1 w-56">مستودع الاعتماد
            <select className={inputCls} value={whId} onChange={(e) => setWhId(Number(e.target.value))}>
              {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
            </select>
          </label>
          <label className="text-xs font-medium space-y-1 w-40">نوع الفاتورة
            <select className={inputCls} value={type} onChange={(e) => setType(e.target.value as "CASH" | "CREDIT")}>
              <option value="CASH">نقدية</option>
              <option value="CREDIT">آجل</option>
            </select>
          </label>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          {rows === null ? (
            <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div>
          ) : rows.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">لا طلبات B2B بعد — جرّب «تجربة بوابة العميل» لتقديم طلب</div>
          ) : (
            <div className="space-y-3">
              {rows.map((o) => {
                const st = ORDER_STATUS[o.status] ?? { label: o.status, variant: "secondary" as const };
                return (
                  <div key={o.id} className="rounded-lg border p-3 space-y-2">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs" dir="ltr">{o.number}</span>
                        <Badge variant={st.variant} className="text-[10px]">{st.label}</Badge>
                        <b className="text-sm">{o.customer.name}</b>
                        <span className="font-mono text-[10px] text-muted-foreground" dir="ltr">{o.customer.code}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold">{fmtIQD(o.grand_total)} IQD</span>
                        {o.status === "SUBMITTED" && canApprove && (
                          <Button size="sm" onClick={() => confirmOrder(o.id)} disabled={acting === o.id}>
                            <UserCheck className="w-4 h-4" /> اعتماد ← فاتورة
                          </Button>
                        )}
                        {o.status === "SUBMITTED" && canReject && (
                          <Button size="sm" variant="outline" onClick={() => rejectOrder(o.id)} disabled={acting === o.id}>
                            <XCircle className="w-4 h-4" /> رفض
                          </Button>
                        )}
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground flex flex-wrap gap-x-4">
                      {o.lines.map((l, i) => (
                        <span key={i}>{l.product.name}: <b dir="ltr">{l.qty}</b> {l.product.unit} × <b dir="ltr">{fmtIQD(l.unit_price)}</b></span>
                      ))}
                    </div>
                    <div className="text-[11px] text-muted-foreground">
                      أُرسل {formatDateTime(o.created_at)}{o.confirmed_invoice ? ` · الفاتورة: ${o.confirmed_invoice}` : ""}{o.notes ? ` · ${o.notes}` : ""}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------
// محاكاة بوابة العميل — نفس النداءات التي سيستخدمها تطبيق العميل الفعلي
// ---------------------------------------------------------------------
function PortalSimulator() {
  const [portal, setPortal] = React.useState<PortalState | null>(null);
  const [products, setProducts] = React.useState<PortalProduct[]>([]);
  const [qty, setQty] = React.useState<Record<number, string>>({});
  const [statement, setStatement] = React.useState<StatementData | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [lastOrder, setLastOrder] = React.useState<string | null>(null);

  async function login(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setBusy(true);
    try {
      const { body } = await api<{ token: string; expires_in: number; customer: PortalState["customer"] }>(
        "/api/v1/b2b/auth",
        { method: "POST", body: JSON.stringify({ code: fd.get("code"), pin: fd.get("pin") }) },
        { skipAuth: true }
      );
      if (body.success && body.data) {
        setPortal({ token: body.data.token, customer: body.data.customer });
        await loadCatalog(body.data.token);
        toast.success("مرحبًا بك في بوابة العملاء ✓");
      } else toast.error(body.message ?? "فشل الدخول");
    } finally { setBusy(false); }
  }

  async function loadCatalog(token: string) {
    const res = await fetch("/api/v1/b2b/catalog", { headers: { Authorization: `Bearer ${token}` } });
    const body = await res.json();
    if (body.success) setProducts(body.data.products as PortalProduct[]);
  }

  async function loadStatement(token: string) {
    const res = await fetch("/api/v1/b2b/statement", { headers: { Authorization: `Bearer ${token}` } });
    const body = await res.json();
    if (body.success) setStatement(body.data as StatementData);
  }

  async function submitOrder(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!portal) return;
    const lines = Object.entries(qty)
      .map(([pid, q]) => ({ product_id: Number(pid), qty: Number(q) }))
      .filter((l) => l.qty > 0);
    if (!lines.length) return toast.error("أدخل كمية منتج واحد على الأقل");
    setBusy(true);
    try {
      const res = await fetch("/api/v1/b2b/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${portal.token}` },
        body: JSON.stringify({ lines }),
      });
      const body = await res.json();
      if (body.success) {
        setLastOrder(body.data.number);
        setQty({});
        toast.success(`قُدّم الطلب ${body.data.number} — سيظهر في طابور الإدارة ✓`);
        await loadStatement(portal.token);
      } else toast.error(body.message ?? "فشل تقديم الطلب");
    } finally { setBusy(false); }
  }

  if (!portal) {
    return (
      <Card className="max-w-lg">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2"><Globe className="w-5 h-5 text-primary" /> دخول بوابة العملاء</CardTitle>
          <CardDescription>
            العميل يدخل برمزه ورقم البوابة. حسابات تجريبية: <span dir="ltr" className="font-mono">C-00001 / 1122</span> (خصم 2%) ·{" "}
            <span dir="ltr" className="font-mono">C-00002 / 2211</span> (خصم 3%)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={login} className="space-y-3">
            <label className="text-xs font-medium space-y-1 block">رمز العميل *
              <input name="code" required className={inputCls} dir="ltr" placeholder="C-00001" defaultValue="C-00001" />
            </label>
            <label className="text-xs font-medium space-y-1 block">رقم البوابة (PIN) *
              <input name="pin" required type="password" inputMode="numeric" className={inputCls} dir="ltr" placeholder="1122" defaultValue="1122" />
            </label>
            <Button type="submit" disabled={busy}><LogIn className="w-4 h-4" /> {busy ? "جارٍ الدخول..." : "دخول البوابة"}</Button>
          </form>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center justify-between flex-wrap gap-2">
            <span className="flex items-center gap-2"><ShoppingCart className="w-5 h-5 text-primary" /> كتالوج {portal.customer.name}</span>
            <Button size="sm" variant="outline" onClick={() => { setPortal(null); setStatement(null); setLastOrder(null); }}>خروج</Button>
          </CardTitle>
          <CardDescription>
            أسعارك الخاصة فقط (خصم <b dir="ltr">{portal.customer.discount_pct}%</b>) — رصيدك الحالي: <b>{fmtIQD(portal.customer.balance)}</b> من حد <b>{fmtIQD(portal.customer.credit_limit)}</b>
            {lastOrder && <> · آخر طلب: <span className="font-mono" dir="ltr">{lastOrder}</span></>}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submitOrder} className="space-y-3">
            <div className="rounded-lg border divide-y max-h-96 overflow-y-auto scroll-thin">
              {products.map((p) => (
                <div key={p.id} className="grid grid-cols-[1fr_110px_120px] sm:grid-cols-[1fr_130px_130px_110px] items-center gap-2 p-2.5">
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate">{p.name}</div>
                    <div className="text-[11px] text-muted-foreground">{p.category ?? "—"} · {p.unit}</div>
                  </div>
                  <div className="text-xs text-muted-foreground line-through hidden sm:block" dir="ltr">{fmtIQD(p.list_price)}</div>
                  <div className="text-sm font-bold text-primary" dir="ltr">{fmtIQD(p.your_price)} IQD</div>
                  <input
                    type="number" min="0" step="any" placeholder="كمية" dir="ltr"
                    className="h-9 w-full rounded-md border bg-background px-2 text-sm"
                    value={qty[p.id] ?? ""} onChange={(e) => setQty((prev) => ({ ...prev, [p.id]: e.target.value }))}
                  />
                </div>
              ))}
            </div>
            <Button type="submit" disabled={busy}><ShoppingCart className="w-4 h-4" /> تقديم الطلب إلى الشركة</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">كشف حسابك</CardTitle>
          <Button size="sm" variant="outline" onClick={() => loadStatement(portal.token)} className="w-fit"><RefreshCw className="w-4 h-4" /> تحديث</Button>
        </CardHeader>
        <CardContent className="space-y-2">
          {statement === null ? (
            <div className="text-sm text-muted-foreground">اضغط «تحديث» لعرض كشف حسابك</div>
          ) : (
            <>
              {statement.invoices.map((i) => (
                <div key={i.id} className="flex items-center justify-between text-sm border-b pb-1.5">
                  <span className="font-mono text-xs" dir="ltr">{i.number}</span>
                  <span>{formatDateTime(i.invoiceDate)}</span>
                  <span>{fmtIQD(i.grandTotal)} IQD</span>
                  <Badge variant={i.due_amount > 0 ? "secondary" : "success"} className="text-[10px]">
                    {i.due_amount > 0 ? `متبقي ${fmtIQD(i.due_amount)}` : "مسدد"}
                  </Badge>
                </div>
              ))}
              {statement.orders.length > 0 && (
                <div className="pt-2">
                  <div className="text-xs font-medium mb-1">طلباتك من البوابة</div>
                  {statement.orders.map((o) => (
                    <div key={o.id} className="flex items-center justify-between text-xs border-b py-1">
                      <span className="font-mono" dir="ltr">{o.number}</span>
                      <span>{ORDER_STATUS[o.status]?.label ?? o.status}</span>
                      <span dir="ltr">{fmtIQD(o.grandTotal)} IQD</span>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------
// المزامنة — دفع/سحب حي بنفس عقد العملاء دون اتصال
// ---------------------------------------------------------------------
function SyncPanel({ warehouses }: { warehouses: { id: number; code: string; name: string }[] }) {
  const [opUuid, setOpUuid] = React.useState(`demo-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-0001`);
  const [pushResult, setPushResult] = React.useState<unknown>(null);
  const [pullResult, setPullResult] = React.useState<unknown>(null);
  const [cursor, setCursor] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  async function doPush() {
    setBusy(true);
    try {
      // نجلب أول عميل ومنتج لبناء عملية صالحة (نفس ما يفعله تطبيق المندوب)
      const [c, p] = await Promise.all([
        api<{ id: number }>("/api/v1/customers?per_page=1"),
        api<{ id: number }>("/api/v1/products?per_page=1"),
      ]);
      const customerId = c.body.success && Array.isArray(c.body.data) ? c.body.data[0]?.id : undefined;
      const productId = p.body.success && Array.isArray(p.body.data) ? p.body.data[0]?.id : undefined;
      if (!customerId || !productId) {
        toast.error("لا بيانات أساسية لبناء عملية تجريبية");
        return;
      }
      const { body } = await api("/api/v1/sync/push", {
        method: "POST",
        body: JSON.stringify({
          device_id: "demo-device-01",
          operations: [
            {
              op_uuid: opUuid,
              entity: "sales_invoice",
              action: "create",
              payload: { customer_id: customerId, warehouse_id: warehouses[0]?.id, type: "CASH", lines: [{ product_id: productId, qty: 1 }] },
            },
          ],
        }),
      });
      setPushResult(body);
      if (body.success) {
        const summary = (body.data as { summary?: { applied?: number; duplicates?: number; rejected?: number } }).summary;
        if (summary?.duplicates) toast.info("عملية مكررة — أُعيدت النتيجة الأصلية (SYNC_001)");
        else if (summary?.applied) toast.success("عُزلت العملية من الطابور ✓");
        else toast.error(body.message ?? "رُفضت العملية");
      } else toast.error(body.message ?? "فشل الدفع");
    } finally { setBusy(false); }
  }

  return (
    <div className="space-y-4">
      <SyncInstructions />
      <PushForm opUuid={opUuid} setOpUuid={setOpUuid} pushResult={pushResult} busy={busy} onPush={doPush} />
      <PullSection cursor={cursor} setCursor={setCursor} busy={busy} />
    </div>
  );
}

function SyncInstructions() {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2"><RefreshCw className="w-5 h-5 text-primary" /> عقد المزامنة للعمل دون اتصال</CardTitle>
        <CardDescription>
          تطبيق المندوب يخزن العمليات محليًا ثم يدفعها بمعرّف فريد <span dir="ltr" className="font-mono">op_uuid</span> —
          إعادة دفع نفس المعرّف تُعيد <b>النتيجة الأصلية</b> مع <span dir="ltr" className="font-mono">SYNC_001</span> بلا ازدواج. السحب يعمل بمنحنى دلتا (cursor) للمنتجات والعملاء والأرصدة.
        </CardDescription>
      </CardHeader>
    </Card>
  );
}

function PushForm({ opUuid, setOpUuid, pushResult, busy, onPush }: {
  opUuid: string; setOpUuid: (v: string) => void; pushResult: unknown; busy: boolean; onPush: () => void;
}) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2"><Upload className="w-5 h-5 text-primary" /> دفع عملية من الطابور (Push)</CardTitle>
        <CardDescription>اضغط مرتين بنفس المعرّف: المرة الأولى APPLIED والثانية DUPLICATE/SYNC_001 بنفس رقم الفاتورة — لا ازدواج أبدًا</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <label className="text-xs font-medium space-y-1 block">op_uuid
          <input className={`${inputCls} font-mono`} dir="ltr" value={opUuid} onChange={(e) => setOpUuid(e.target.value)} />
        </label>
        <Button onClick={onPush} disabled={busy || !opUuid}><Upload className="w-4 h-4" /> {busy ? "جارٍ الدفع..." : "دفع العملية (فاتورة نقدية ×1 من أول منتج)"}</Button>
        {pushResult != null && (
          <pre className="rounded-md bg-muted p-3 text-[11px] overflow-x-auto max-h-72 overflow-y-auto scroll-thin" dir="ltr">
            {JSON.stringify(pushResult, null, 2)}
          </pre>
        )}
      </CardContent>
    </Card>
  );
}

function PullSection({ cursor, setCursor, busy }: {
  cursor: string; setCursor: (v: string) => void; busy: boolean;
}) {
  const [pullResult, setPullResult] = React.useState<unknown>(null);
  const loading = busy;

  async function pull() {
    try {
      const q = cursor ? `?cursor=${encodeURIComponent(cursor)}` : "";
      const { body } = await api(`/api/v1/sync/pull${q}`);
      setPullResult(body);
      if (body.success) toast.success("استُلمت الدلتا — انظر next_cursor");
      else toast.error(body.message ?? "فشل التنزيل");
    } catch {
      toast.error("فشل التنزيل");
    }
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2"><CloudDownload className="w-5 h-5 text-primary" /> تنزيل دلتا (Pull)</CardTitle>
        <CardDescription>المنحنى cursor = آخر updated_at استلمته — أرسله في المرة القادمة لتستلم الجديد فقط</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <label className="text-xs font-medium space-y-1 block">cursor (اختياري — فارغ = آخر 7 أيام)
          <input className={`${inputCls} font-mono`} dir="ltr" value={cursor} onChange={(e) => setCursor(e.target.value)} placeholder="2026-09-01T00:00:00.000Z" />
        </label>
        <Button onClick={pull} disabled={loading}><CloudDownload className="w-4 h-4" /> {loading ? "جارٍ التنزيل..." : "تنزيل الدلتا"}</Button>
        {pullResult != null && (
          <pre className="rounded-md bg-muted p-3 text-[11px] overflow-x-auto max-h-72 overflow-y-auto scroll-thin" dir="ltr">
            {JSON.stringify(pullResult, null, 2)}
          </pre>
        )}
      </CardContent>
    </Card>
  );
}
