"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { formatIQD, formatUSD, usdEquivalent, getUsdRate, setUsdRate } from "@/lib/utils";
import { FileUp, PackagePlus, Pencil, Plus, Search, Trash2, Sparkles, Info, Calculator } from "lucide-react";

// ---- v16: قوائم الوحدات القابلة للتخصيص ----------------------------
const UNIT_OPTIONS_BASE = ["حبة", "علبة", "قطعة"];
const UNIT_OPTIONS_PACK = ["كرتون", "صندوق", "باكيت"];

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";

/**
 * v16 — قائمة منسدلة مع خيار «أخرى...» لإدخال قيمة مخصّصة.
 * تستخدم للوحدة الأساسية ووحدة التعبئة.
 */
function UnitSelect({
  value, onChange, options, placeholder, name, required,
}: {
  value: string;
  onChange: (v: string) => void;
  options: string[];
  placeholder: string;
  name?: string;
  required?: boolean;
}) {
  const [customMode, setCustomMode] = React.useState(false);

  // If value is non-empty and not in options → custom mode
  React.useEffect(() => {
    if (value && !options.includes(value) && value !== "") {
      setCustomMode(true);
    }
  }, [value, options]);

  return (
    <div className="relative">
      {!customMode ? (
        <select
          name={name}
          required={required}
          className={inputCls}
          value={value}
          onChange={(e) => {
            if (e.target.value === "__custom__") {
              setCustomMode(true);
              onChange("");
            } else {
              onChange(e.target.value);
            }
          }}
        >
          <option value="">{placeholder}</option>
          {options.map((opt) => (
            <option key={opt} value={opt}>{opt}</option>
          ))}
          <option value="__custom__">+ أخرى...</option>
        </select>
      ) : (
        <div className="flex gap-1">
          <input
            name={name}
            required={required}
            className={inputCls}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder="أدخل الوحدة..."
            autoFocus
          />
          <button
            type="button"
            onClick={() => { setCustomMode(false); onChange(""); }}
            className="h-9 w-9 flex items-center justify-center rounded-md border bg-background hover:bg-muted text-muted-foreground"
            title="رجوع للقائمة"
          >
            ←
          </button>
        </div>
      )}
    </div>
  );
}

interface ProductRow {
  id: number;
  code: string;
  name: string;
  unit: string;
  barcode?: string | null;
  category: { id: number; name: string } | null;
  pack_unit?: string | null;
  pack_qty?: number | null;
  pack_sale_price?: number | null;
  cost_price: number;
  sale_price: number;
  // ---- Phase 2 §6: العملة المصدر لكل سعر كما خُزّنت ----------------------
  sale_currency?: "IQD" | "USD";
  sale_amount?: number;
  pack_sale_currency?: "IQD" | "USD";
  pack_sale_amount?: number | null;
  cost_currency?: "IQD" | "USD";
  cost_amount?: number;
  company_usd_rate?: number | null;
  tax_rate_pct: number;
  min_stock: number;
  is_active: boolean;
  stock_total: number;
}

interface CategoryRow { id: number; name: string; products_count: number }

type Cur = "IQD" | "USD";

/** مبدّل عملة السعر (د.ع / $) — السعر يُخزَّن بعملته كما دخل (Phase 2 §6) */
function PriceCurrencyToggle({ value, onChange }: { value: Cur; onChange: (c: Cur) => void }) {
  return (
    <div className="flex rounded-md border overflow-hidden" dir="ltr">
      <button type="button" onClick={() => onChange("IQD")}
        className={`px-2 py-0.5 text-[10px] font-bold transition-colors ${value === "IQD" ? "bg-primary text-primary-foreground" : "bg-background text-muted-foreground hover:bg-muted"}`}>
        د.ع
      </button>
      <button type="button" onClick={() => onChange("USD")}
        className={`px-2 py-0.5 text-[10px] font-bold transition-colors ${value === "USD" ? "bg-primary text-primary-foreground" : "bg-background text-muted-foreground hover:bg-muted"}`}>
        $
      </button>
    </div>
  );
}

/** حقول سعر واحدة (مبدّل + إدخال + تلميح المكافئ) — تُستخدم للتكلفة/البيع/العبوة */
function PriceField(props: {
  label: string; cur: Cur; val: string; rate: number | "";
  onCur: (c: Cur) => void; onVal: (v: string) => void;
  required?: boolean; placeholder?: string; hint?: string;
}) {
  const n = Number(props.val);
  const rateN = Number(props.rate);
  return (
    <div className="text-xs font-medium space-y-1">
      <div className="flex items-center justify-between gap-2">
        <span>{props.label}{props.required ? " *" : ""}</span>
        <PriceCurrencyToggle value={props.cur} onChange={props.onCur} />
      </div>
      <input type="number" min="0" step="any" dir="ltr" className={inputCls}
        required={props.required} value={props.val} onChange={(e) => props.onVal(e.target.value)}
        placeholder={props.placeholder ?? (props.cur === "USD" ? "بالدينار" : "")} />
      {props.cur === "USD" && n > 0 && rateN > 0 ? (
        <div className="text-[10px] font-semibold text-sky-700 dark:text-sky-400" dir="ltr">≈ {formatIQD(n * rateN)}</div>
      ) : props.cur === "IQD" && n > 0 && rateN > 0 ? (
        <div className="text-[10px] text-muted-foreground" dir="ltr">≈ {formatUSD(usdEquivalent(n, rateN))}</div>
      ) : props.hint ? (
        <div className="text-[10px] text-muted-foreground">{props.hint}</div>
      ) : null}
    </div>
  );
}

export function ProductsTab({ canEdit, canImport, canDelete }: { canEdit: boolean; canImport?: boolean; canDelete?: boolean }) {
  const [rows, setRows] = React.useState<ProductRow[] | null>(null);
  const [cats, setCats] = React.useState<CategoryRow[]>([]);
  const [q, setQ] = React.useState("");
  const [showForm, setShowForm] = React.useState(false);
  const [showImport, setShowImport] = React.useState(false);
  const [saving, setSaving] = React.useState(false);
  const [importing, setImporting] = React.useState(false);
  // ---- تعديل المنتجات + سعر الصرف للعرض المزدوج (د.ع لكل $1)
  const [editing, setEditing] = React.useState<ProductRow | null>(null);
  const [editingSaving, setEditingSaving] = React.useState(false);
  const [usdRate, setUsdRateState] = React.useState<number | "">("");
  const [rateDirty, setRateDirty] = React.useState(false);

  // ---- Phase 2 §6: حالة الأسعار الثلاثة (القيمة بعملتها كما ستُخزَّن) ----
  // نموذج الإضافة
  const [addCost, setAddCost] = React.useState({ cur: "IQD" as Cur, val: "" });
  const [addSale, setAddSale] = React.useState({ cur: "IQD" as Cur, val: "" });
  const [addPack, setAddPack] = React.useState({ cur: "IQD" as Cur, val: "" });
  // v16 — قوائم الوحدات المنسدلة القابلة للتخصيص
  const [addUnit, setAddUnit] = React.useState("حبة");
  const [addPackUnit, setAddPackUnit] = React.useState("");
  const [addPackQty, setAddPackQty] = React.useState<number | "">("");
  // نموذج التعديل
  const [editCost, setEditCost] = React.useState({ cur: "IQD" as Cur, val: "" });
  const [editSale, setEditSale] = React.useState({ cur: "IQD" as Cur, val: "" });
  const [editPack, setEditPack] = React.useState({ cur: "IQD" as Cur, val: "" });
  const [editUnit, setEditUnit] = React.useState("");
  const [editPackUnit, setEditPackUnit] = React.useState("");
  const [editPackQty, setEditPackQty] = React.useState<number | "">("");

  const anyUsdAdd = addCost.cur === "USD" || addSale.cur === "USD" || addPack.cur === "USD";
  const anyUsdEdit = editCost.cur === "USD" || editSale.cur === "USD" || editPack.cur === "USD";

  // v16 — حساب سعر الحبة (بيع) تلقائياً من سعر الكرتونة ÷ عدد الحبات
  const addPackQtyNum = Number(addPackQty || 0);
  const addPackValNum = Number(addPack.val || 0);
  const autoPieceSaleAdd = (addPackQtyNum > 0 && addPackValNum > 0)
    ? Math.round((addPackValNum / addPackQtyNum) * 100) / 100
    : null;

  const editPackQtyNum = Number(editPackQty || 0);
  const editPackValNum = Number(editPack.val || 0);
  const autoPieceSaleEdit = (editPackQtyNum > 0 && editPackValNum > 0)
    ? Math.round((editPackValNum / editPackQtyNum) * 100) / 100
    : null;

  const load = React.useCallback(async (search = "") => {
    const { body } = await api<ProductRow[]>(`/api/v1/products?per_page=100${search ? `&q=${encodeURIComponent(search)}` : ""}`);
    if (body.success && body.data) {
      setRows(body.data);
      // سعر صرف الشركة المعتمد يتفوق على أي قيمة محلية قديمة (منع 1300 → $0.02)
      const serverRate = body.data.find((r) => r.company_usd_rate)?.company_usd_rate ?? null;
      setUsdRateState((prev) => {
        if (rateDirty && prev !== "") return prev;
        if (serverRate) { setUsdRate(Number(serverRate)); return Number(serverRate); }
        return prev === "" ? getUsdRate() : prev;
      });
    } else toast.error(body.message ?? "تعذر تحميل المنتجات");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  React.useEffect(() => {
    load();
    api<CategoryRow[]>("/api/v1/categories").then(({ body }) => {
      if (body.success && body.data) setCats(body.data);
    });
    api<{ rate: number | null }>("/api/v1/settings/usd-rate").then(({ body }) => {
      if (body.success && body.data?.rate) {
        setUsdRateState((prev) => (rateDirty && prev !== "" ? prev : Number(body.data!.rate)));
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /** حفظ سعر الصرف المعتمد على الخادم (إعداد الشركة) */
  async function persistRate(rate: number) {
    try {
      await api("/api/v1/settings/usd-rate", { method: "PUT", body: JSON.stringify({ rate }) });
    } catch { /* العرض المحلي يبقى سارياً — الرفض صامت */ }
  }

  /** تحقق عميل سريع قبل الإرسال — القاعدة النهائية في الخادم (§3) */
  function clientPackCheck(unit: string, packUnit: string | null, packQty: number | null): string | null {
    const u = (unit || "").trim();
    const pu = (packUnit || "").trim();
    if (pu && (packQty == null || !(packQty > 0))) return "وحدة التعبئة تتطلب عدد الوحدات (مثل 11)";
    if (pu && packQty != null && packQty <= 1) return "عدد الوحدات في العبوة يجب أن يكون أكبر من 1";
    const norm = (s: string) => s.replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/\s+/g, "");
    if (pu && u && norm(u) === norm(pu)) return "وحدة التعبئة يجب أن تختلف عن الوحدة الأساسية — مثال صحيح: الأساسية «علبة» + التعبئة «كرتون» = 11";
    return null;
  }

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    // v16 — استخدم القيم من state (التي تتحكم بها UnitSelect) بدل قراءة FormData
    const unit = addUnit.trim() || "حبة";
    const packUnit = addPackUnit.trim() || null;
    const packQty = addPackQty !== "" ? Number(addPackQty) : null;
    const packErr = clientPackCheck(unit, packUnit, packQty);
    if (packErr) { toast.error(packErr); return; }
    const rateN = Number(usdRate || 0);
    if (anyUsdAdd && !(rateN > 0)) {
      toast.error("أدخل سعر الصرف (د.ع لكل $1) — مطلوب للأسعار بالدولار");
      return;
    }
    const costVal = Number(addCost.val || 0);
    // v16 — سعر الحبة (بيع) تلقائي من سعر الكرتونة إن لم يُدخل يدوياً
    const saleValManual = Number(addSale.val || 0);
    const saleVal = saleValManual > 0 ? saleValManual : (autoPieceSaleAdd ?? 0);
    const packVal = Number(addPack.val || 0);
    if (addPack.cur === "USD" && packVal > 0 && !(rateN > 0)) { toast.error("سعر الصرف مطلوب لسعر العبوة بالدولار"); return; }
    setSaving(true);
    try {
      const { body } = await api("/api/v1/products", {
        method: "POST",
        body: JSON.stringify({
          name: fd.get("name"),
          category_id: fd.get("category_id") ? Number(fd.get("category_id")) : null,
          unit,
          pack_unit: packUnit,
          pack_qty: packQty,
          pack_sale_price: packVal > 0 ? packVal : null,
          // ---- Phase 2 §6: السعر يُخزَّن بعملته كما دخل (لا تحويل عند الحفظ)
          cost_price: costVal,
          cost_currency: addCost.cur,
          sale_price: saleVal,
          sale_currency: autoPieceSaleAdd != null ? addPack.cur : addSale.cur,
          pack_sale_currency: addPack.cur,
          exchange_rate: rateN > 0 ? rateN : null,
          min_stock: Number(fd.get("min_stock") || 0),
          barcode: fd.get("barcode") || undefined,
        }),
      });
      if (body.success) {
        toast.success(`أُنشئ المنتج ${String((body.data as { code: string }).code)} ✓`);
        setShowForm(false);
        setAddCost({ cur: "IQD", val: "" }); setAddSale({ cur: "IQD", val: "" }); setAddPack({ cur: "IQD", val: "" });
        setAddUnit("حبة"); setAddPackUnit(""); setAddPackQty("");
        if (rateN > 0) { setUsdRate(rateN); persistRate(rateN); }
        await load();
      } else {
        toast.error(body.message ?? "فشل الإنشاء");
      }
    } finally {
      setSaving(false);
    }
  }

  async function addCategory(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget; // التقاط المرجع قبل الـ await — currentTarget يصبح null بعدها
    const fd = new FormData(form);
    const name = String(fd.get("cat_name") ?? "").trim();
    if (!name) return;
    const { body } = await api("/api/v1/categories", { method: "POST", body: JSON.stringify({ name }) });
    if (body.success) {
      toast.success("أُضيف التصنيف ✓");
      form?.reset?.(); // أمان: النموذج قد يكون أُزيل من DOM (ref null)
      api<CategoryRow[]>("/api/v1/categories").then(({ body: b }) => { if (b.success && b.data) setCats(b.data); });
    } else toast.error(body.message ?? "فشل");
  }

  /** حفظ تعديلات المنتج (PATCH) — الأسعار بعملتها كما دخلت (§6) */
  async function submitEdit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!editing) return;
    const fd = new FormData(e.currentTarget);
    // v16 — استخدم القيم من state
    const unit = editUnit.trim() || "حبة";
    const packUnit = editPackUnit.trim() || null;
    const packQty = editPackQty !== "" ? Number(editPackQty) : null;
    const packErr = clientPackCheck(unit, packUnit, packQty);
    if (packErr) { toast.error(packErr); return; }
    const rateN = Number(usdRate || 0);
    if (anyUsdEdit && !(rateN > 0)) {
      toast.error("أدخل سعر الصرف (د.ع لكل $1) — مطلوب للأسعار بالدولار");
      return;
    }
    const costVal = Number(editCost.val || 0);
    // v16 — سعر الحبة تلقائي من سعر الكرتونة إن لم يُدخل يدوياً
    const saleValManual = Number(editSale.val || 0);
    const saleVal = saleValManual > 0 ? saleValManual : (autoPieceSaleEdit ?? 0);
    const packVal = Number(editPack.val || 0);
    setEditingSaving(true);
    try {
      const { body } = await api(`/api/v1/products/${editing.id}`, {
        method: "PATCH",
        body: JSON.stringify({
          name: fd.get("name"),
          category_id: fd.get("category_id") ? Number(fd.get("category_id")) : null,
          unit,
          barcode: fd.get("barcode") || null,
          pack_unit: packUnit,
          pack_qty: packQty,
          pack_sale_price: packVal > 0 ? packVal : null,
          cost_price: costVal,
          cost_currency: editCost.cur,
          sale_price: saleVal,
          sale_currency: autoPieceSaleEdit != null ? editPack.cur : editSale.cur,
          pack_sale_currency: editPack.cur,
          exchange_rate: rateN > 0 ? rateN : null,
          min_stock: Number(fd.get("min_stock") || 0),
          is_active: fd.get("is_active") === "on",
        }),
      });
      if (body.success) {
        toast.success(`حُدّث المنتج ${editing.code} ✓`);
        setEditing(null);
        setEditCost({ cur: "IQD", val: "" }); setEditSale({ cur: "IQD", val: "" }); setEditPack({ cur: "IQD", val: "" });
        setEditUnit(""); setEditPackUnit(""); setEditPackQty("");
        if (rateN > 0) { setUsdRate(rateN); persistRate(rateN); }
        await load();
      } else toast.error(body.message ?? "فشل التعديل");
    } finally {
      setEditingSaving(false);
    }
  }

  /** تعبئة حقول التعديل من قيم المنتج المخزنة بعملاتها (§6) */
  function openEdit(p: ProductRow) {
    setEditing(p);
    setShowForm(false);
    setEditCost({ cur: p.cost_currency ?? "IQD", val: String(p.cost_amount ?? p.cost_price ?? "") });
    setEditSale({ cur: p.sale_currency ?? "IQD", val: String(p.sale_amount ?? p.sale_price ?? "") });
    setEditPack({
      cur: p.pack_sale_currency ?? "IQD",
      val: p.pack_sale_amount != null ? String(p.pack_sale_amount) : p.pack_sale_price != null ? String(p.pack_sale_price) : "",
    });
    // v16 — تعيين قيم الوحدات
    setEditUnit(p.unit ?? "حبة");
    setEditPackUnit(p.pack_unit ?? "");
    setEditPackQty(p.pack_qty ?? "");
  }

  /** حذف منتج (soft delete) — يُرفض من الخادم إذا كان له مخزون */
  async function deleteProduct(p: ProductRow) {
    if (!confirm(`حذف المنتج «${p.name}»؟

سيُخفى من الكتالوج نهائيًا ولا يمكن بيعه، وتبقى فواتيره التاريخية سليمة.
لا يمكن الحذف إذا كان للمنتج مخزون.`)) return;
    const { body } = await api(`/api/v1/products/${p.id}`, { method: "DELETE" });
    if (body.success) {
      toast.success(`حُذف المنتج ${p.code} ✓`);
      if (editing?.id === p.id) setEditing(null);
      await load(q);
    } else toast.error(body.message ?? "فشل الحذف");
  }

  async function importCsv(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const csv = String(fd.get("csv") ?? "").trim();
    if (!csv) {
      toast.error("الصق محتوى CSV أولًا");
      return;
    }
    setImporting(true);
    try {
      const { body } = await api<{ created: number; skipped: number; errors: { line: number; message: string }[] }>(
        "/api/v1/products/import",
        { method: "POST", body: JSON.stringify({ csv }) }
      );
      if (body.success && body.data) {
        const d = body.data;
        toast.success(`استيراد المنتجات: ${d.created} جديد · ${d.skipped} مكرر${d.errors.length ? ` · ${d.errors.length} سطر خاطئ` : ""}`);
        if (d.errors.length) toast.warning(d.errors.slice(0, 3).map((x) => `سطر ${x.line}: ${x.message}`).join(" · "));
        setShowImport(false);
        await load();
      } else toast.error(body.message ?? "فشل الاستيراد");
    } finally {
      setImporting(false);
    }
  }

  // ---- عرض السعر بعملته المخزنة + المكافئ (§6/DoD: لا عرض خاطئ للعملة) ----
  const rateNum = Number(usdRate || 0);
  function priceCell(amountIqd: number, currency: Cur | undefined, storedAmount?: number) {
    const cur = currency ?? "IQD";
    if (cur === "USD" && storedAmount != null) {
      return (
        <>
          <span className="font-semibold">{formatUSD(storedAmount)}</span>
          {rateNum > 0 && <div className="text-[10px] text-muted-foreground" dir="ltr">≈ {formatIQD(Math.round(storedAmount * rateNum * 100) / 100)}</div>}
        </>
      );
    }
    return (
      <>
        <span>{formatIQD(amountIqd)}</span>
        {rateNum > 0 && amountIqd > 0 && <div className="text-[10px] text-muted-foreground" dir="ltr">≈ {formatUSD(usdEquivalent(amountIqd, rateNum))}</div>}
      </>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <CardTitle className="flex items-center gap-2"><PackagePlus className="w-5 h-5 text-primary" /> كتالوج المنتجات</CardTitle>
              <CardDescription>الوحدة الأساسية + التعبئة + الأسعار بعملتها (د.ع / $) — الصلاحية: products.products.*</CardDescription>
            </div>
            {canEdit && (
              <div className="flex gap-2">
                <div className="relative">
                  <Search className="w-4 h-4 absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input className="pr-8 w-48 h-9" placeholder="بحث بالاسم/الكود..." value={q}
                    onChange={(e) => { setQ(e.target.value); load(e.target.value); }} />
                </div>
                {canImport && (
                  <Button size="sm" variant="outline" onClick={() => setShowImport((v) => !v)}>
                    <FileUp className="w-4 h-4" /> استيراد CSV
                  </Button>
                )}
                <Button size="sm" onClick={() => setShowForm((v) => !v)}>
                  <Plus className="w-4 h-4" /> منتج جديد
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {showForm && canEdit && (
            <form onSubmit={submit} className="rounded-lg border p-4 mb-4 bg-muted/30 space-y-4">
              {/* القسم 1: المعلومات الأساسية */}
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <label className="text-xs font-medium space-y-1">اسم المنتج *
                  <input name="name" required minLength={2} className={inputCls} placeholder="مثال: شامبو لوميرا 400 مل" />
                </label>
                <label className="text-xs font-medium space-y-1">التصنيف
                  <select name="category_id" className={inputCls} defaultValue="">
                    <option value="">— بدون —</option>
                    {cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </label>
                <label className="text-xs font-medium space-y-1">الباركود (اختياري)
                  <input name="barcode" className={inputCls} dir="ltr" placeholder="اختياري" />
                </label>
                <label className="text-xs font-medium space-y-1">الحد الأدنى للمخزون
                  <input name="min_stock" type="number" min="0" step="any" className={inputCls} dir="ltr" placeholder="0" />
                </label>
              </div>

              {/* القسم 2: الوحدات والتعبئة */}
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 rounded-md border p-3 bg-background/50">
                <div className="text-xs font-semibold text-muted-foreground sm:col-span-2 lg:col-span-4 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" /> الوحدات والتعبئة
                </div>
                <label className="text-xs font-medium space-y-1">الوحدة الأساسية *
                  <UnitSelect
                    value={addUnit}
                    onChange={setAddUnit}
                    options={UNIT_OPTIONS_BASE}
                    placeholder="اختر..."
                    name="unit"
                    required
                  />
                </label>
                <label className="text-xs font-medium space-y-1">وحدة التعبئة (اختياري)
                  <UnitSelect
                    value={addPackUnit}
                    onChange={setAddPackUnit}
                    options={UNIT_OPTIONS_PACK}
                    placeholder="بدون تعبئة"
                    name="pack_unit"
                  />
                </label>
                <label className="text-xs font-medium space-y-1">
                  الكرتونة = كم {addUnit || "وحدة"}؟
                  <input
                    name="pack_qty"
                    type="number"
                    min="2"
                    step="any"
                    className={inputCls}
                    dir="ltr"
                    placeholder="مثال: 11 أو 12"
                    value={String(addPackQty)}
                    onChange={(e) => setAddPackQty(e.target.value === "" ? "" : Number(e.target.value))}
                    disabled={!addPackUnit}
                  />
                  {!addPackUnit && (
                    <span className="text-[10px] text-muted-foreground">اختر وحدة التعبئة أولاً</span>
                  )}
                </label>
                {addPackUnit && addPackQty && Number(addPackQty) > 0 && (
                  <div className="flex items-end">
                    <div className="w-full rounded-md bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900 p-2 text-center">
                      <div className="text-[10px] text-emerald-700 dark:text-emerald-400">التحويل</div>
                      <div className="text-xs font-bold text-emerald-800 dark:text-emerald-300" dir="ltr">
                        1 {addPackUnit} = {addPackQty} {addUnit}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* القسم 3: الأسعار */}
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 rounded-md border p-3 bg-background/50">
                <div className="text-xs font-semibold text-muted-foreground sm:col-span-2 lg:col-span-3 flex items-center gap-1">
                  <Calculator className="w-3.5 h-3.5 text-sky-500" /> الأسعار (تُخزَّن بعملتها كما تُدخل)
                </div>
                <PriceField label="سعر الكرتونة (بيع)" cur={addPack.cur} val={addPack.val} rate={usdRate}
                  onCur={(c) => setAddPack((s) => ({ ...s, cur: c }))} onVal={(v) => setAddPack((s) => ({ ...s, val: v }))}
                  hint={addPackUnit ? `مثال: 26$ لل${addPackUnit}` : "يتطلب وحدة تعبئة أولاً"} />
                <PriceField label="سعر التكلفة (للكرتونة)" cur={addCost.cur} val={addCost.val} rate={usdRate}
                  onCur={(c) => setAddCost((s) => ({ ...s, cur: c }))} onVal={(v) => setAddCost((s) => ({ ...s, val: v }))}
                  hint="تكلفة شراء الكرتونة من المورد" />
                {/* سعر الحبة — محسوب تلقائياً أو يدوي */}
                <div className="text-xs font-medium space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span>سعر الحبة (بيع)</span>
                    <PriceCurrencyToggle value={addSale.cur} onChange={(c) => setAddSale((s) => ({ ...s, cur: c }))} />
                  </div>
                  <input
                    type="number" min="0" step="any" dir="ltr" className={inputCls}
                    value={addSale.val}
                    onChange={(e) => setAddSale((s) => ({ ...s, val: e.target.value }))}
                    placeholder={autoPieceSaleAdd != null ? String(autoPieceSaleAdd) : "أدخل أو احسب تلقائياً"}
                  />
                  {autoPieceSaleAdd != null && addSale.val === "" ? (
                    <div className="flex items-center gap-1 text-[10px] text-emerald-700 dark:text-emerald-400 font-semibold">
                      <Info className="w-3 h-3" /> محسوب تلقائياً: {addPack.val} {addPack.cur} ÷ {addPackQty} = <strong dir="ltr">{autoPieceSaleAdd} {addSale.cur}</strong>
                    </div>
                  ) : autoPieceSaleAdd != null ? (
                    <div className="text-[10px] text-muted-foreground" dir="ltr">
                      المحسوب: {autoPieceSaleAdd} {addSale.cur} (تجاهلت القيمة اليدوية)
                    </div>
                  ) : (
                    <div className="text-[10px] text-muted-foreground">يُحسب تلقائياً من سعر الكرتونة ÷ عدد الحبات</div>
                  )}
                </div>
              </div>

              <div className="flex justify-end">
                <Button type="submit" disabled={saving}>
                  {saving ? "جارٍ الحفظ..." : "حفظ المنتج"}
                </Button>
              </div>
            </form>
          )}

          {editing && canEdit && (
            <form key={editing.id} onSubmit={submitEdit} className="rounded-lg border-2 border-primary/40 p-4 mb-4 bg-primary/5 space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="text-sm font-bold flex items-center gap-2">
                  <Pencil className="w-4 h-4 text-primary" /> تعديل المنتج
                  <span className="font-mono text-xs text-muted-foreground" dir="ltr">{editing.code}</span>
                </div>
                <Button type="button" size="sm" variant="ghost" onClick={() => setEditing(null)}>إلغاء التعديل</Button>
              </div>

              {/* القسم 1: المعلومات الأساسية */}
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <label className="text-xs font-medium space-y-1">اسم المنتج *
                  <input name="name" required minLength={2} defaultValue={editing.name} className={inputCls} />
                </label>
                <label className="text-xs font-medium space-y-1">التصنيف
                  <select name="category_id" className={inputCls} defaultValue={editing.category?.id ? String(editing.category.id) : ""}>
                    <option value="">— بدون —</option>
                    {cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </label>
                <label className="text-xs font-medium space-y-1">الباركود (اختياري)
                  <input name="barcode" defaultValue={editing.barcode ?? ""} className={inputCls} dir="ltr" />
                </label>
                <label className="text-xs font-medium space-y-1">الحد الأدنى للمخزون
                  <input name="min_stock" type="number" min="0" step="any" defaultValue={editing.min_stock} className={inputCls} dir="ltr" />
                </label>
              </div>

              {/* القسم 2: الوحدات والتعبئة */}
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 rounded-md border p-3 bg-background/50">
                <div className="text-xs font-semibold text-muted-foreground sm:col-span-2 lg:col-span-4 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" /> الوحدات والتعبئة
                </div>
                <label className="text-xs font-medium space-y-1">الوحدة الأساسية *
                  <UnitSelect
                    value={editUnit}
                    onChange={setEditUnit}
                    options={UNIT_OPTIONS_BASE}
                    placeholder="اختر..."
                    name="unit"
                    required
                  />
                </label>
                <label className="text-xs font-medium space-y-1">وحدة التعبئة (اختياري)
                  <UnitSelect
                    value={editPackUnit}
                    onChange={setEditPackUnit}
                    options={UNIT_OPTIONS_PACK}
                    placeholder="بدون تعبئة"
                    name="pack_unit"
                  />
                </label>
                <label className="text-xs font-medium space-y-1">
                  الكرتونة = كم {editUnit || "وحدة"}؟
                  <input
                    name="pack_qty"
                    type="number"
                    min="2"
                    step="any"
                    className={inputCls}
                    dir="ltr"
                    placeholder="مثال: 11 أو 12"
                    value={String(editPackQty)}
                    onChange={(e) => setEditPackQty(e.target.value === "" ? "" : Number(e.target.value))}
                    disabled={!editPackUnit}
                  />
                  {!editPackUnit && <span className="text-[10px] text-muted-foreground">اختر وحدة التعبئة أولاً</span>}
                </label>
                {editPackUnit && editPackQty && Number(editPackQty) > 0 && (
                  <div className="flex items-end">
                    <div className="w-full rounded-md bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900 p-2 text-center">
                      <div className="text-[10px] text-emerald-700 dark:text-emerald-400">التحويل</div>
                      <div className="text-xs font-bold text-emerald-800 dark:text-emerald-300" dir="ltr">
                        1 {editPackUnit} = {editPackQty} {editUnit}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* القسم 3: الأسعار */}
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 rounded-md border p-3 bg-background/50">
                <div className="text-xs font-semibold text-muted-foreground sm:col-span-2 lg:col-span-3 flex items-center gap-1">
                  <Calculator className="w-3.5 h-3.5 text-sky-500" /> الأسعار
                </div>
                <PriceField label="سعر الكرتونة (بيع)" cur={editPack.cur} val={editPack.val} rate={usdRate}
                  onCur={(c) => setEditPack((s) => ({ ...s, cur: c }))} onVal={(v) => setEditPack((s) => ({ ...s, val: v }))}
                  hint={editPackUnit ? `سعر ال${editPackUnit} الواحدة` : "يتطلب وحدة تعبئة"} />
                <PriceField label="سعر التكلفة (للكرتونة)" cur={editCost.cur} val={editCost.val} rate={usdRate}
                  onCur={(c) => setEditCost((s) => ({ ...s, cur: c }))} onVal={(v) => setEditCost((s) => ({ ...s, val: v }))}
                  hint="تكلفة الشراء من المورد" />
                {/* سعر الحبة — محسوب تلقائياً أو يدوي */}
                <div className="text-xs font-medium space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span>سعر الحبة (بيع)</span>
                    <PriceCurrencyToggle value={editSale.cur} onChange={(c) => setEditSale((s) => ({ ...s, cur: c }))} />
                  </div>
                  <input
                    type="number" min="0" step="any" dir="ltr" className={inputCls}
                    value={editSale.val}
                    onChange={(e) => setEditSale((s) => ({ ...s, val: e.target.value }))}
                    placeholder={autoPieceSaleEdit != null ? String(autoPieceSaleEdit) : "أدخل أو احسب تلقائياً"}
                  />
                  {autoPieceSaleEdit != null && editSale.val === "" ? (
                    <div className="flex items-center gap-1 text-[10px] text-emerald-700 dark:text-emerald-400 font-semibold">
                      <Info className="w-3 h-3" /> محسوب تلقائياً: {editPack.val} {editPack.cur} ÷ {editPackQty} = <strong dir="ltr">{autoPieceSaleEdit} {editSale.cur}</strong>
                    </div>
                  ) : autoPieceSaleEdit != null ? (
                    <div className="text-[10px] text-muted-foreground" dir="ltr">
                      المحسوب: {autoPieceSaleEdit} {editSale.cur}
                    </div>
                  ) : (
                    <div className="text-[10px] text-muted-foreground">يُحسب تلقائياً من سعر الكرتونة ÷ عدد الحبات</div>
                  )}
                </div>
              </div>

              {/* القسم 4: الحالة */}
              <div className="flex items-center justify-between flex-wrap gap-2">
                <label className="text-xs font-medium flex items-center gap-2">
                  <input name="is_active" type="checkbox" defaultChecked={editing.is_active} className="w-4 h-4" />
                  منتج نشط (متاح للبيع)
                </label>
                <Button type="submit" disabled={editingSaving}>
                  {editingSaving ? "جارٍ الحفظ..." : "حفظ التعديلات"}
                </Button>
              </div>
            </form>
          )}

          {showImport && canImport && (
            <form onSubmit={importCsv} className="rounded-lg border p-4 mb-4 bg-muted/30 space-y-2">
              <div className="text-xs font-semibold">استيراد منتجات من CSV — الترتيب: الاسم, سعر البيع, سعر التكلفة, الوحدة, الباركود, حد التنبيه, وحدة التعبئة, عدد الوحدات, سعر الكرتونة</div>
              <div className="text-[11px] text-muted-foreground" dir="ltr">شامبو 400 مل, 3663.64, 38750, علبة, 5010201010, 20, كرتون, 11, 40300</div>
              <textarea name="csv" rows={5} className={inputCls + " font-mono text-xs"} dir="ltr" placeholder="الصق الأسطر هنا..." />
              <Button type="submit" size="sm" disabled={importing}>{importing ? "جارٍ الاستيراد..." : "استيراد"}</Button>
            </form>
          )}

          {rows === null ? (
            <div className="py-10 text-center text-muted-foreground">جارٍ التحميل...</div>
          ) : rows.length === 0 ? (
            <div className="py-10 text-center text-muted-foreground">لا منتجات — أضف أول منتج</div>
          ) : (
            <>
            {/* شريط سعر الصرف — يُحفظ كإعداد معتمد للشركة (§7) */}
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3 flex-wrap">
              <span className="font-semibold text-sky-700 dark:text-sky-400">$</span>
              <span>سعر الصرف المعتمد للشركة:</span>
              <input
                type="number"
                min="1"
                step="any"
                className="h-7 w-24 rounded-md border bg-background px-2 text-xs"
                dir="ltr"
                value={String(usdRate)}
                onChange={(e) => {
                  const v = e.target.value === "" ? "" : Number(e.target.value);
                  setRateDirty(true);
                  setUsdRateState(v);
                  if (v !== "" && Number(v) > 0) setUsdRate(Number(v));
                }}
                onBlur={(e) => { const v = Number(e.target.value); if (v > 0) persistRate(v); }}
              />
              <span>د.ع لكل $1 — يُستخدم لتحويل الأسعار المخزنة بالدولار وللفواتير</span>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الكود</TableHead>
                  <TableHead>المنتج</TableHead>
                  <TableHead>التصنيف</TableHead>
                  <TableHead>الوحدة الأساسية</TableHead>
                  <TableHead>وحدة التعبئة</TableHead>
                  <TableHead>الكرتونة =</TableHead>
                  <TableHead className="text-left">التكلفة</TableHead>
                  <TableHead className="text-left">سعر الكرتونة</TableHead>
                  <TableHead className="text-left">سعر الحبة (بيع)</TableHead>
                  <TableHead className="text-left">المخزون</TableHead>
                  <TableHead>الحالة</TableHead>
                  {(canEdit || canDelete) && <TableHead className="w-20"></TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((p) => {
                  const hasPack = !!p.pack_unit && !!p.pack_qty && Number(p.pack_qty) > 1;
                  return (
                  <TableRow key={p.id}>
                    <TableCell dir="ltr" className="font-mono text-xs text-right">{p.code}</TableCell>
                    <TableCell className="font-medium">
                      {p.name}
                      {p.barcode && <div className="text-[10px] text-muted-foreground font-mono" dir="ltr">{p.barcode}</div>}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{p.category?.name ?? "—"}</TableCell>
                    <TableCell className="text-sm font-medium">{p.unit}</TableCell>
                    <TableCell className="text-sm">{p.pack_unit ?? <span className="text-muted-foreground">—</span>}</TableCell>
                    <TableCell className="text-sm" dir="ltr">
                      {hasPack ? <span className="font-medium">{p.pack_qty} {p.unit}</span> : <span className="text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell className="text-left text-sm" dir="ltr">
                      {priceCell(p.cost_price, p.cost_currency, p.cost_amount)}
                    </TableCell>
                    <TableCell className="text-left text-sm" dir="ltr">
                      {hasPack ? priceCell(p.pack_sale_price ?? 0, p.pack_sale_currency, p.pack_sale_amount ?? undefined) : <span className="text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell className="text-left text-sm font-semibold" dir="ltr">
                      {priceCell(p.sale_price, p.sale_currency, p.sale_amount)}
                    </TableCell>
                    <TableCell className="text-left">
                      <Badge variant={p.stock_total <= 0 ? "destructive" : p.min_stock > 0 && p.stock_total <= p.min_stock ? "secondary" : "success"} className="text-[11px]">
                        {p.stock_total} {p.unit}
                      </Badge>
                    </TableCell>
                    <TableCell>{p.is_active ? <Badge variant="success" className="text-[10px]">نشط</Badge> : <Badge variant="destructive" className="text-[10px]">معطل</Badge>}</TableCell>
                    {(canEdit || canDelete) && (
                      <TableCell>
                        <div className="flex items-center gap-0.5">
                          {canEdit && (
                            <Button size="sm" variant="ghost" onClick={() => openEdit(p)} aria-label={`تعديل ${p.name}`} title="تعديل المنتج">
                              <Pencil className="w-4 h-4 text-primary" />
                            </Button>
                          )}
                          {canDelete && (
                            <Button size="sm" variant="ghost" onClick={() => deleteProduct(p)} aria-label={`حذف ${p.name}`} title="حذف المنتج">
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                  );
                })}
              </TableBody>
            </Table>
            </>
          )}
        </CardContent>
      </Card>

      {canEdit && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">التصنيفات</CardTitle>
            <CardDescription>تنظيم المنتجات في مجموعات</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <form onSubmit={addCategory} className="flex gap-2 max-w-md">
              <input name="cat_name" required minLength={2} className={inputCls} placeholder="اسم تصنيف جديد (مثال: مواد غذائية)" />
              <Button type="submit" size="sm" variant="outline"><Plus className="w-4 h-4" /> إضافة</Button>
            </form>
            <div className="flex flex-wrap gap-2">
              {cats.map((c) => (
                <Badge key={c.id} variant="navy">{c.name} <span className="opacity-70">({c.products_count})</span></Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
