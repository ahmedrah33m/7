"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { Decimal, dec, moneyR, num as decNum, qtyR, sumOf } from "@/lib/decimal";
import { formatDateTime, formatIQD } from "@/lib/utils";
import { Plus, ShoppingCart, Trash2, Truck, Zap, Search, X, FileText, DollarSign, Package, Calculator, Sparkles, ReceiptText } from "lucide-react";
import { QuickPaymentVoucherForm } from "@/components/sales/quick-payment-voucher-form";

interface Supplier { id: number; code: string; name: string; phone?: string | null; address?: string | null; balance: number; is_active: boolean }
interface Product {
  id: number; name: string; unit: string; cost_price: number; sale_price: number;
  pack_unit?: string | null; pack_qty?: number | null; pack_sale_price?: number | null;
}
interface PurchaseRow {
  id: number;
  number: string;
  invoice_date: string;
  supplier_id?: number;
  supplier: { code: string; name: string };
  warehouse: { name: string };
  lines_count: number;
  grand_total: number;
  paid_amount: number;
  due_amount: number;
  currency_code?: string;
  exchange_rate?: number | null;
  created_by: string;
}
interface InvoiceDetail {
  id: number;
  number: string;
  status: string;
  invoice_date: string;
  supplier: { id: number; code: string; name: string; phone?: string | null };
  warehouse: { id: number; code: string; name: string };
  branch: { id: number; name: string };
  creator: { id: number; fullName: string };
  currency_code: string;
  exchange_rate: number | null;
  notes: string | null;
  subtotal: number;
  grand_total: number;
  paid_amount: number;
  due_amount: number;
  lines: Array<{
    id: number;
    product_id: number;
    product: {
      id: number; code: string; name: string; unit: string;
      packUnit: string | null; packQty: string | null;
      costPrice: number; salePrice: number; packSalePrice: string | null;
    };
    qty: number;
    unit_cost: number;
    line_total: number;
    cartons: number;
    pieces: number;
    pack_qty: number;
    pack_unit: string | null;
    wholesale_sale_price: number | null;
    retail_sale_price: number | null;
  }>;
}

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";

// بند الشراء: يُدخل بالكراتين والعلب (للمعبأة) أو كمية مباشرة (لغير المعبأة)
// — التحويل إلى حبات (الوحدة الأساس) يحدث هنا قبل الإرسال للخادم
interface Line {
  product_id: number;
  cartons: number | "";       // عدد الكارتون
  boxes: number | "";         // عدد الحبات المفردة
  qty: number | "";           // الكمية المباشرة للمنتجات غير المعبأة
  cost: number | "";          // سعر تكلفة الكارتون (أو الحبة لغير المعبأ)
  cost_basis: "PIECE" | "PACKAGE";
  carton_sale_price: number | "";   // سعر بيع الكارتون — v17
  wholesale_price: number | "";     // سعر البيع جمله — v17
  retail_price: number | "";        // سعر البيع مفرد (للحبة) — v17
}

const num = (v: number | "") => (v === "" ? 0 : Number(v));
// صياغة الوحدة حسب قواعد الأعداد العربية: 1 علبة · علبتين · 3-10 علب · 11+ علبة
const unitCount = (n: number, u?: string | null) => {
  const m = Math.abs(Math.round(n)) % 100;
  const forms: Record<string, [string, string, string]> = {
    "علبة": ["علبة", "علبتين", "علب"],
    "حبة": ["حبة", "حبتين", "حبات"],
    "قطعة": ["قطعة", "قطعتين", "قطع"],
    "كرتونة": ["كرتونة", "كرتونتين", "كراتين"],
    "كارتون": ["كارتون", "كارتونين", "كراتين"],
    "صندوق": ["صندوق", "صندوقين", "صناديق"],
  };
  const f = forms[u ?? ""];
  if (!f) return u ?? "وحدة";
  if (m === 1) return f[0];
  if (m === 2) return f[1];
  if (m >= 3 && m <= 10) return f[2];
  return f[0];
};

export function PurchasesTab({ warehouses, canCreate, canDeleteInvoice, canManageSuppliers }: { warehouses: { id: number; name: string }[]; canCreate: boolean; canDeleteInvoice?: boolean; canManageSuppliers?: boolean }) {
  const [suppliers, setSuppliers] = React.useState<Supplier[]>([]);
  const [products, setProducts] = React.useState<Product[]>([]);
  const [rows, setRows] = React.useState<PurchaseRow[] | null>(null);
  const [lines, setLines] = React.useState<Line[]>([]);
  const [saving, setSaving] = React.useState(false);
  const [addingSupplier, setAddingSupplier] = React.useState(false);
  // دفع سريع لمورد من قائمة فواتير الشراء (Zap button)
  const [quickPay, setQuickPay] = React.useState<{ supplierId: number; invoiceId: number } | null>(null);
  // v15 — البحث عن فاتورة
  const [search, setSearch] = React.useState("");
  // v15 — فتح الفاتورة عند الضغط
  const [openedInvoice, setOpenedInvoice] = React.useState<InvoiceDetail | null>(null);
  const [loadingInvoice, setLoadingInvoice] = React.useState<number | null>(null);
  // v15 — العملة (IQD | USD)
  const [currencyCode, setCurrencyCode] = React.useState<"IQD" | "USD">("IQD");
  const [exchangeRate, setExchangeRate] = React.useState<string>("");

  const load = React.useCallback(async () => {
    const [s, p, r] = await Promise.all([
      api<Supplier[]>("/api/v1/suppliers"),
      api<Product[]>("/api/v1/products?per_page=200"),
      api<PurchaseRow[]>("/api/v1/purchases/invoices?per_page=50"),
    ]);
    if (s.body.success && s.body.data) setSuppliers(s.body.data);
    if (p.body.success && p.body.data) setProducts(p.body.data);
    if (r.body.success && r.body.data) setRows(r.body.data);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  // ---- حسابات العبوات: كل شيء يُحوّل إلى حبات (الوحدة الأساس) ----------
  const productById = (id: number) => products.find((p) => p.id === id);
  const hasPack = (l: Line) => {
    const p = productById(l.product_id);
    return !!p?.pack_unit && !!p?.pack_qty && Number(p.pack_qty) > 1;
  };
  const packQtyOf = (l: Line) => Number(productById(l.product_id)?.pack_qty ?? 1);
  /** إجمالي الحبات للبند = كراتين × عدد الحبات + العلب المفردة */
  const baseQtyOf = (l: Line) =>
    hasPack(l)
      ? Math.round((num(l.cartons) * packQtyOf(l) + num(l.boxes)) * 1e6) / 1e6
      : num(l.qty);
  /** تكلفة الحبة الفعلية (هكذا تُخزن في الخادم — أساس المتوسط المرجّح) */
  const perPieceCostOf = (l: Line) => {
    const c = num(l.cost);
    if (!hasPack(l) || l.cost_basis === "PIECE") return c;
    return decNum(qtyR(dec(c).div(packQtyOf(l))));
  };
  /** تكلفة الكرتونة (إن وُجدت) — للعرض فقط */
  const cartonCostOf = (l: Line) => {
    if (!hasPack(l)) return null;
    return l.cost_basis === "PACKAGE" ? num(l.cost) : decNum(moneyR(qtyR(dec(perPieceCostOf(l))).mul(packQtyOf(l))));
  };
  const lineTotalOf = (l: Line) => decNum(moneyR(qtyR(dec(baseQtyOf(l))).mul(perPieceCostOf(l))));

  const total = decNum(moneyR(sumOf(lines, (l) => lineTotalOf(l))));

  function addLine() {
    const first = products[0];
    if (!first) return;
    setLines((prev) => [...prev, {
      product_id: first.id, cartons: "", boxes: "", qty: "",
      cost: first.cost_price, cost_basis: "PIECE",
      carton_sale_price: first.pack_sale_price ?? "",
      wholesale_price: first.pack_sale_price ?? "",
      retail_price: first.sale_price ?? "",
    }]);
  }

  function setLine(idx: number, patch: Partial<Line>) {
    setLines((prev) =>
      prev.map((l, i) => {
        if (i !== idx) return l;
        const next = { ...l, ...patch };
        // تبديل المنتج: تصفير الكميات + تكلفة المنتج الجديد + أسعار البيع
        if (patch.product_id !== undefined) {
          const p = productById(Number(patch.product_id));
          next.cost = p?.cost_price ?? "";
          next.cost_basis = "PIECE";
          next.cartons = "";
          next.boxes = "";
          next.qty = "";
          next.carton_sale_price = p?.pack_sale_price ?? "";
          next.wholesale_price = p?.pack_sale_price ?? "";
          next.retail_price = p?.sale_price ?? "";
        }
        // تبديل أساس التكلفة: تحويل الرقم المدخل تلقائياً (حبة ↔ كرتون)
        if (patch.cost_basis && patch.cost_basis !== l.cost_basis && next.cost !== "") {
          const pq = Number(productById(l.product_id)?.pack_qty ?? 1);
          next.cost = Math.round((patch.cost_basis === "PACKAGE" ? num(l.cost) * pq : num(l.cost) / pq) * 100) / 100;
        }
        // v17 — عند تغيير سعر بيع الكارتون: حدّث سعر المفرد تلقائياً إن كان فارغاً
        if (patch.carton_sale_price !== undefined && next.carton_sale_price !== "") {
          const pq = Number(productById(l.product_id)?.pack_qty ?? 1);
          if (pq > 1 && num(next.carton_sale_price) > 0) {
            // سعر المفرد = سعر بيع الكارتون ÷ عدد الحبات
            const autoRetail = Math.round((num(next.carton_sale_price) / pq) * 100) / 100;
            // فقط حدّث إن كان retail_price فارغاً أو لم يُدخل يدوياً
            if (next.retail_price === "" || num(next.retail_price) === 0) {
              next.retail_price = autoRetail;
            }
          }
        }
        return next;
      })
    );
  }

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!lines.length) return toast.error("أضف بندًا واحدًا على الأقل");
    const invalid = lines.find((l) => baseQtyOf(l) <= 0);
    if (invalid) {
      toast.error(`أدخل كمية أكبر من صفر للمنتج «${productById(invalid.product_id)?.name ?? ""}»`);
      return;
    }
    // v15 — تحقق سعر الصرف عند اختيار الدولار
    if (currencyCode === "USD" && (!exchangeRate || Number(exchangeRate) <= 0)) {
      toast.error("أدخل سعر صرف الدولار مقابل الدينار (مثلاً 1310)");
      return;
    }
    setSaving(true);
    const fd = new FormData(e.currentTarget);
    try {
      const { body } = await api("/api/v1/purchases/invoices", {
        method: "POST",
        body: JSON.stringify({
          supplier_id: Number(fd.get("supplier_id")),
          warehouse_id: Number(fd.get("warehouse_id")),
          type: fd.get("type"),
          paid_amount: fd.get("paid_amount") ? Number(fd.get("paid_amount")) : undefined,
          notes: fd.get("notes") || undefined,
          currency_code: currencyCode,
          exchange_rate: currencyCode === "USD" ? Number(exchangeRate) : null,
          lines: lines.map((l) => ({
            product_id: l.product_id,
            qty: baseQtyOf(l),                                   // حبات (الوحدة الأساس)
            unit_cost: l.cost === "" ? undefined : perPieceCostOf(l), // تكلفة الحبة
            wholesale_sale_price: l.wholesale_price === "" ? null : Number(l.wholesale_price),  // سعر البيع جمله
            retail_sale_price: l.retail_price === "" ? null : Number(l.retail_price),          // سعر البيع مفرد
          })),
        }),
      });
      if (body.success) {
        const d = body.data as { number: string; due_amount: number };
        toast.success(`فاتورة الشراء ${d.number} رُحّلت ✓ — مستحق للمورد: ${formatIQD(d.due_amount)}`);
        setLines([]);
        (e.target as HTMLFormElement).reset();
        await load();
      } else toast.error(body.message ?? "فشل ترحيل الفاتورة");
    } finally {
      setSaving(false);
    }
  }

  async function deleteInvoice(r: PurchaseRow) {
    if (!confirm(`حذف فاتورة الشراء ${r.number}؟

سيتم عكس كل آثارها دفعة واحدة:
· إرجاع الكميات من المخزون (${r.lines_count} بند) — يُرفض إذا بيعت البضاعة
· خصم مستحق المورد (${formatIQD(r.due_amount)})
· إرجاع المسدد للصندوق (${formatIQD(r.paid_amount)})`)) return;
    const { body } = await api(`/api/v1/purchases/invoices/${r.id}`, { method: "DELETE" });
    if (body.success) {
      toast.success(`حُذفت فاتورة الشراء ${r.number} وعُكست آثارها ✓`);
      await load();
    } else toast.error(body.message ?? "فشل حذف الفاتورة");
  }

  // v15 — فتح الفاتورة عند الضغط على صفها
  async function openInvoice(id: number) {
    setLoadingInvoice(id);
    try {
      const { body } = await api<InvoiceDetail>(`/api/v1/purchases/invoices/${id}`);
      if (body.success && body.data) setOpenedInvoice(body.data);
      else toast.error(body.message ?? "فشل تحميل الفاتورة");
    } finally { setLoadingInvoice(null); }
  }

  async function addSupplier(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget; // التقاط المرجع قبل الـ await
    const fd = new FormData(form);
    setAddingSupplier(true);
    try {
      const { body } = await api("/api/v1/suppliers", {
        method: "POST",
        body: JSON.stringify({
          name: fd.get("name"),
          phone: fd.get("phone") || undefined,
          address: fd.get("address") || undefined,
          opening_balance: fd.get("opening_balance") ? Number(fd.get("opening_balance")) : 0,
        }),
      });
      if (body.success) {
        const d = body.data as { code: string; name: string };
        toast.success(`أُضيف المورد ${d.name} (${d.code}) ✓`);
        form.reset();
        await load();
      } else toast.error(body.message ?? "فشل إضافة المورد");
    } finally {
      setAddingSupplier(false);
    }
  }

  // v15 — فلتر البحث
  const filteredRows = React.useMemo(() => {
    if (!rows) return null;
    if (!search.trim()) return rows;
    const q = search.trim().toLowerCase();
    return rows.filter((r) =>
      r.number.toLowerCase().includes(q) ||
      r.supplier.name.toLowerCase().includes(q) ||
      r.supplier.code.toLowerCase().includes(q)
    );
  }, [rows, search]);

  // صياغة المبلغ حسب العملة
  const formatAmount = (amount: number, currency?: string) => {
    if (currency === "USD") return `$${new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(amount)}`;
    return formatIQD(amount);
  };

  return (
    <div className="space-y-4">
      {canCreate && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><ShoppingCart className="w-5 h-5 text-primary" /> فاتورة شراء جديدة</CardTitle>
            <CardDescription>
              أدخل الكمية كراتين وعلب (حبات) للمنتجات المعبأة — يُحولها النظام تلقائياً إلى حبات في المخزون وتُحدَّث التكلفة (متوسط مرجّح) وذمة المورد، وستظهر نفس الكراتين مباشرة في فواتير البيع
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={submit} className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
                <label className="text-xs font-medium space-y-1">المورد *
                  <select name="supplier_id" required className={inputCls}>
                    {suppliers.filter((s) => s.is_active).map((s) => (
                      <option key={s.id} value={s.id}>{s.name} {s.balance > 0 ? `(مستحق ${formatIQD(s.balance)})` : ""}</option>
                    ))}
                  </select>
                </label>
                <label className="text-xs font-medium space-y-1">مستودع الاستلام *
                  <select name="warehouse_id" required className={inputCls} defaultValue={warehouses[0]?.id}>
                    {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
                  </select>
                </label>
                <label className="text-xs font-medium space-y-1">نوع الفاتورة *
                  <select name="type" className={inputCls} defaultValue="CASH">
                    <option value="CASH">نقدية (سداد فوري من الصندوق)</option>
                    <option value="CREDIT">آجلة (تُضاف لذمة المورد)</option>
                  </select>
                </label>
                <label className="text-xs font-medium space-y-1">مدفوع مقدماً (للآجلة)
                  <input name="paid_amount" type="number" min="0" step="any" className={inputCls} dir="ltr" placeholder="0" />
                </label>
                {/* v15 — اختيار العملة (IQD | USD) */}
                <label className="text-xs font-medium space-y-1">
                  العملة *
                  <select
                    value={currencyCode}
                    onChange={(e) => setCurrencyCode(e.target.value as "IQD" | "USD")}
                    className={inputCls}
                  >
                    <option value="IQD">دينار عراقي (IQD)</option>
                    <option value="USD">دولار أمريكي (USD)</option>
                  </select>
                </label>
                {/* v15 — سعر الصرف (يظهر فقط عند اختيار الدولار) */}
                {currencyCode === "USD" && (
                  <label className="text-xs font-medium space-y-1">
                    سعر الصرف (د.ع / $1) *
                    <input
                      type="number"
                      min="1"
                      step="any"
                      value={exchangeRate}
                      onChange={(e) => setExchangeRate(e.target.value)}
                      className={inputCls}
                      dir="ltr"
                      placeholder="1310"
                      required
                    />
                  </label>
                )}
                <label className="text-xs font-medium space-y-1">ملاحظات
                  <input name="notes" className={inputCls} placeholder="اختياري" />
                </label>
              </div>

              {/* lines */}
              <div className="rounded-lg border p-3 space-y-2 overflow-x-auto">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-medium">البنود ({lines.length})</div>
                  <Button type="button" size="sm" variant="outline" onClick={addLine}><Plus className="w-4 h-4" /> بند</Button>
                </div>
                {lines.length === 0 ? (
                  <div className="py-4 text-center text-sm text-muted-foreground">لا بنود — اضغط «بند» لإضافة صنف</div>
                ) : (
                  <div className="space-y-3">
                    {lines.map((l, i) => {
                      const p = productById(l.product_id);
                      const packed = hasPack(l);
                      const pq = packQtyOf(l);
                      const pieces = baseQtyOf(l);
                      const perPiece = perPieceCostOf(l);
                      const cartonCost = cartonCostOf(l);
                      const autoRetail = (packed && pq > 1 && num(l.carton_sale_price) > 0)
                        ? Math.round((num(l.carton_sale_price) / pq) * 100) / 100
                        : null;
                      const cartonProfit = (cartonCost != null && num(l.carton_sale_price) > 0)
                        ? num(l.carton_sale_price) - cartonCost
                        : null;
                      const pieceProfit = (perPiece > 0 && num(l.retail_price) > 0)
                        ? num(l.retail_price) - perPiece
                        : null;
                      return (
                        <div key={i} className="rounded-lg border p-3 space-y-3 bg-muted/30">
                          {/* شريط علوي: رقم البند + شارات */}
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-muted-foreground">بند #{i + 1}</span>
                            <div className="flex items-center gap-2">
                              {cartonProfit != null && cartonProfit !== 0 && (
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${cartonProfit > 0 ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300" : "bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-300"}`}>
                                  ربح {p?.pack_unit ?? "كرتون"}: {formatAmount(Math.round(cartonProfit * 100) / 100, currencyCode)}
                                </span>
                              )}
                              {pieceProfit != null && pieceProfit !== 0 && (
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${pieceProfit > 0 ? "bg-sky-100 text-sky-700 dark:bg-sky-950/40 dark:text-sky-300" : "bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-300"}`}>
                                  ربح {p?.unit ?? "حبة"}: {formatAmount(Math.round(pieceProfit * 100) / 100, currencyCode)}
                                </span>
                              )}
                              <Button type="button" size="icon" variant="ghost" className="h-7 w-7" onClick={() => setLines((prev) => prev.filter((_, j) => j !== i))} aria-label="حذف البند">
                                <Trash2 className="w-4 h-4 text-red-500" />
                              </Button>
                            </div>
                          </div>

                          {/* القسم 1: المنتج + الكميات */}
                          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 rounded-md border p-3 bg-background/50">
                            <div className="text-xs font-semibold text-muted-foreground lg:col-span-4 flex items-center gap-1">
                              <Package className="w-3.5 h-3.5" /> المنتج والكميات
                            </div>
                            <label className="text-xs font-medium space-y-1">المنتج
                              <select
                                className={inputCls}
                                value={l.product_id}
                                onChange={(e) => setLine(i, { product_id: Number(e.target.value) })}
                                title={packed ? `التعبئة: 1 ${p?.pack_unit} = ${pq} ${p?.unit}` : `الوحدة: ${p?.unit ?? ""}`}
                              >
                                {products.map((p) => (
                                  <option key={p.id} value={p.id}>
                                    {p.name}
                                    {p.pack_unit && p.pack_qty && Number(p.pack_qty) > 1 ? ` (1 ${p.pack_unit} = ${Number(p.pack_qty)} ${p.unit})` : ""}
                                  </option>
                                ))}
                              </select>
                            </label>
                            {packed ? (
                              <>
                                <label className="text-xs font-medium space-y-1">عدد الكارتون
                                  <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={String(l.cartons)} onChange={(e) => setLine(i, { cartons: e.target.value === "" ? "" : Number(e.target.value) })} placeholder="0" />
                                </label>
                                <label className="text-xs font-medium space-y-1">عدد الحبات
                                  <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={String(l.boxes)} onChange={(e) => setLine(i, { boxes: e.target.value === "" ? "" : Number(e.target.value) })} placeholder="0" />
                                </label>
                                <label className="text-xs font-medium space-y-1">إجمالي الحبات
                                  <div className="h-9 flex items-center justify-center text-sm font-bold border rounded-md bg-primary/5 text-primary" dir="ltr">
                                    {pieces > 0 ? pieces : "—"}
                                  </div>
                                  {packed && <span className="text-[10px] text-muted-foreground">1 {p?.pack_unit} = {pq} {p?.unit}</span>}
                                </label>
                              </>
                            ) : (
                              <label className="text-xs font-medium space-y-1 lg:col-span-3">الكمية ({p?.unit ?? "وحدة"})
                                <input type="number" min="0.001" step="any" className={inputCls} dir="ltr" value={String(l.qty)} onChange={(e) => setLine(i, { qty: e.target.value === "" ? "" : Number(e.target.value) })} placeholder="0" />
                              </label>
                            )}
                          </div>

                          {/* القسم 2: أسعار الكارتونة */}
                          {packed && (
                            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 rounded-md border p-3 bg-background/50">
                              <div className="text-xs font-semibold text-muted-foreground lg:col-span-3 flex items-center gap-1">
                                <Calculator className="w-3.5 h-3.5" /> أسعار {p?.pack_unit ?? "الكرتون"}
                              </div>
                              <label className="text-xs font-medium space-y-1">
                                تكلفة {p?.pack_unit ?? "كرتون"}
                                <input type="number" min="0" step="any" className={inputCls} dir="ltr"
                                  value={String(l.cost)}
                                  onChange={(e) => setLine(i, { cost: e.target.value === "" ? "" : Number(e.target.value) })}
                                  placeholder="0"
                                />
                                <select className={inputCls + " h-7 text-xs"} value={l.cost_basis} onChange={(e) => setLine(i, { cost_basis: e.target.value as "PIECE" | "PACKAGE" })} title="أدخل التكلفة لهذا الأساس">
                                  <option value="PIECE">سعر ال{p?.unit ?? "حبة"}</option>
                                  <option value="PACKAGE">سعر ال{p?.pack_unit ?? "كرتون"}</option>
                                </select>
                              </label>
                              <label className="text-xs font-medium space-y-1">
                                {`سعر بيع ${p?.pack_unit ?? "كرتون"}`}
                                <input type="number" min="0" step="any" className={inputCls} dir="ltr"
                                  value={String(l.carton_sale_price)}
                                  onChange={(e) => setLine(i, { carton_sale_price: e.target.value === "" ? "" : Number(e.target.value) })}
                                  placeholder="0"
                                  title="سعر بيع الكرتونة الواحدة"
                                />
                              </label>
                              <label className="text-xs font-medium space-y-1">
                                سعر البيع جمله
                                <input type="number" min="0" step="any" className={inputCls} dir="ltr"
                                  value={String(l.wholesale_price)}
                                  onChange={(e) => setLine(i, { wholesale_price: e.target.value === "" ? "" : Number(e.target.value) })}
                                  placeholder="0"
                                  title="سعر البيع بالجملة"
                                />
                              </label>
                            </div>
                          )}

                          {/* القسم 3: أسعار الحبة */}
                          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 rounded-md border p-3 bg-background/50">
                            <div className="text-xs font-semibold text-muted-foreground lg:col-span-3 flex items-center gap-1">
                              <Sparkles className="w-3.5 h-3.5 text-amber-500" /> أسعار {p?.unit ?? "الحبة"}
                            </div>
                            <label className="text-xs font-medium space-y-1">
                              {packed ? `تكلفة ال${p?.unit ?? "حبة"}` : `تكلفة ال${p?.unit ?? "حبة"}`}
                              <div className="h-9 flex items-center border rounded-md bg-muted/30 px-3 text-sm font-bold" dir="ltr">
                                {perPiece > 0 ? formatAmount(Math.round(perPiece * 100) / 100, currencyCode) : "—"}
                              </div>
                              <span className="text-[10px] text-muted-foreground">
                                {packed && cartonCost != null && cartonCost > 0 ? `محسوب: ${cartonCost} ÷ ${pq}` : "تكلفة الشراء للحبة"}
                              </span>
                            </label>
                            <label className="text-xs font-medium space-y-1">
                              {`سعر بيع ${p?.unit ?? "حبة"}`}
                              <input type="number" min="0" step="any"
                                className={inputCls + " " + (autoRetail != null && l.retail_price === "" ? "border-emerald-400 bg-emerald-50/30 dark:bg-emerald-950/20" : "")}
                                dir="ltr"
                                value={String(l.retail_price)}
                                onChange={(e) => setLine(i, { retail_price: e.target.value === "" ? "" : Number(e.target.value) })}
                                placeholder={autoRetail != null ? String(autoRetail) : "0"}
                                title="سعر البيع بالمفرد — محسوب تلقائياً = سعر الكارتون ÷ عدد الحبات"
                              />
                              {autoRetail != null && l.retail_price === "" && (
                                <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-semibold">
                                  ⚡ تلقائي: {num(l.carton_sale_price)} ÷ {pq} = {autoRetail}
                                </span>
                              )}
                              {autoRetail != null && l.retail_price !== "" && num(l.retail_price) !== autoRetail && (
                                <span className="text-[10px] text-muted-foreground">
                                  تلقائي: {autoRetail}
                                </span>
                              )}
                            </label>
                            <label className="text-xs font-medium space-y-1">
                              ربح {p?.unit ?? "حبة"}
                              <div className={`h-9 flex items-center border rounded-md px-3 text-sm font-bold ${pieceProfit != null && pieceProfit > 0 ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-300" : pieceProfit != null && pieceProfit < 0 ? "bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300" : "bg-muted/30 text-muted-foreground"}`} dir="ltr">
                                {pieceProfit != null && pieceProfit !== 0 ? formatAmount(Math.round(pieceProfit * 100) / 100, currencyCode) : "—"}
                              </div>
                              <span className="text-[10px] text-muted-foreground">
                                {pieceProfit != null && pieceProfit > 0 ? "ربح" : pieceProfit != null && pieceProfit < 0 ? "خسارة" : "بيع − تكلفة"}
                              </span>
                            </label>
                          </div>

                          {/* القسم 4: الإجمالي */}
                          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 rounded-md border p-3 bg-primary/5">
                            <div className="text-xs font-semibold text-muted-foreground lg:col-span-4 flex items-center gap-1">
                              <ReceiptText className="w-3.5 h-3.5" /> الإجمالي
                            </div>
                            <div className="text-xs">
                              <div className="text-muted-foreground">إجمالي الحبات</div>
                              <div className="font-bold text-sm" dir="ltr">{pieces > 0 ? `${pieces} ${p?.unit ?? "حبة"}` : "—"}</div>
                            </div>
                            {packed && pieces > 0 && (
                              <div className="text-xs">
                                <div className="text-muted-foreground">توزيع</div>
                                <div className="font-bold text-sm" dir="ltr">
                                  {Math.floor(pieces / pq)} {p?.pack_unit ?? "كرتون"}
                                  {pieces % pq > 0 ? ` + ${Math.round((pieces % pq) * 1e6) / 1e6} ${p?.unit ?? "حبة"}` : ""}
                                </div>
                              </div>
                            )}
                            <div className="text-xs">
                              <div className="text-muted-foreground">تكلفة {p?.unit ?? "الحبة"}</div>
                              <div className="font-bold text-sm" dir="ltr">{perPiece > 0 ? formatAmount(Math.round(perPiece * 100) / 100, currencyCode) : "—"}</div>
                            </div>
                            <div className="text-xs text-left">
                              <div className="text-muted-foreground">إجمالي البند</div>
                              <div className="text-lg font-bold text-primary" dir="ltr">{formatAmount(lineTotalOf(l), currencyCode)}</div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                    <div className="text-left font-bold pt-2 border-t-2" dir="ltr">
                      <span className="text-sm text-muted-foreground">إجمالي الفاتورة: </span>
                      <span className="text-lg">{formatAmount(total, currencyCode)}</span>
                      {currencyCode === "USD" && exchangeRate && (
                        <span className="text-xs text-muted-foreground ml-2">
                          (~ {formatIQD(total * Number(exchangeRate))})
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>

              <Button type="submit" disabled={saving || lines.length === 0}>{saving ? "جارٍ الترحيل..." : "ترحيل فاتورة الشراء"}</Button>
            </form>
          </CardContent>
        </Card>
      )}

      {/* الموردون — إدارة موردي الشركة (إضافة/عرض الأرصدة) */}
      {canManageSuppliers && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><Truck className="w-5 h-5 text-primary" /> الموردون</CardTitle>
            <CardDescription>أضف موردي الشركة وتابع أرصدتهم المستحقة — الصلاحية: parties.suppliers.*</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={addSupplier} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5 rounded-lg border p-4 bg-muted/30">
              <label className="text-xs font-medium space-y-1">اسم المورد *
                <input name="name" required minLength={2} maxLength={120} className={inputCls} placeholder="مثال: شركة الغذاء الوطنية" />
              </label>
              <label className="text-xs font-medium space-y-1">الهاتف
                <input name="phone" className={inputCls} dir="ltr" placeholder="07XX XXX XXXX" />
              </label>
              <label className="text-xs font-medium space-y-1">العنوان
                <input name="address" className={inputCls} placeholder="اختياري" />
              </label>
              <label className="text-xs font-medium space-y-1">رصيد افتتاحي مستحق
                <input name="opening_balance" type="number" min="0" step="any" className={inputCls} dir="ltr" placeholder="0" />
              </label>
              <div className="flex items-end">
                <Button type="submit" className="w-full" disabled={addingSupplier}>
                  <Plus className="w-4 h-4" /> {addingSupplier ? "جارٍ الحفظ..." : "إضافة مورد"}
                </Button>
              </div>
            </form>
            {suppliers.length === 0 ? (
              <div className="py-4 text-center text-sm text-muted-foreground">لا موردين بعد — أضف أول مورد</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الكود</TableHead>
                    <TableHead>المورد</TableHead>
                    <TableHead>الهاتف</TableHead>
                    <TableHead className="text-left">الرصيد المستحق</TableHead>
                    <TableHead>الحالة</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {suppliers.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell className="font-mono text-xs" dir="ltr">{s.code}</TableCell>
                      <TableCell className="text-sm font-medium">
                        {s.name}
                        {s.address && <div className="text-[10px] text-muted-foreground">{s.address}</div>}
                      </TableCell>
                      <TableCell className="text-xs" dir="ltr">{s.phone || "—"}</TableCell>
                      <TableCell className="text-left font-semibold" dir="ltr">
                        {s.balance > 0 ? <span className="text-red-600">{formatIQD(s.balance)}</span> : "—"}
                      </TableCell>
                      <TableCell>
                        <Badge variant={s.is_active ? "success" : "destructive"} className="text-[10px]">
                          {s.is_active ? "نشط" : "معطل"}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="w-4 h-4 text-primary" /> فواتير الشراء
            </CardTitle>
            {/* v15 — البحث عن فاتورة */}
            <div className="relative w-64">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="بحث برقم الفاتورة أو المورد..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className={inputCls + " pr-10"}
              />
              {search && (
                <button
                  type="button"
                  onClick={() => setSearch("")}
                  className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
          <CardDescription className="text-xs">
            اضغط على أي فاتورة لعرض تفاصيلها الكاملة (بنود + أسعار البيع + العملة)
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredRows === null ? (
            <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div>
          ) : filteredRows.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">
              {search ? `لا نتائج للبحث «${search}»` : "لا فواتير شراء بعد"}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الرقم</TableHead>
                  <TableHead>التاريخ</TableHead>
                  <TableHead>المورد</TableHead>
                  <TableHead>المستودع</TableHead>
                  <TableHead>العملة</TableHead>
                  <TableHead className="text-left">البنود</TableHead>
                  <TableHead className="text-left">الإجمالي</TableHead>
                  <TableHead className="text-left">المستحق</TableHead>
                  <TableHead>الحالة</TableHead>
                  {canDeleteInvoice && <TableHead className="w-14"></TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRows.map((r) => (
                  <TableRow
                    key={r.id}
                    className="cursor-pointer hover:bg-accent/50 transition-colors"
                    onClick={() => openInvoice(r.id)}
                  >
                    <TableCell className="font-mono text-xs" dir="ltr">
                      {loadingInvoice === r.id ? (
                        <span className="text-muted-foreground">جارٍ...</span>
                      ) : r.number}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">{formatDateTime(r.invoice_date)}</TableCell>
                    <TableCell className="text-sm">{r.supplier.name}</TableCell>
                    <TableCell className="text-xs">{r.warehouse.name}</TableCell>
                    <TableCell>
                      <Badge variant={r.currency_code === "USD" ? "default" : "secondary"} className="text-[10px]">
                        {r.currency_code === "USD" ? (
                          <><DollarSign className="w-3 h-3 ml-1" />USD</>
                        ) : "IQD"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-left">{r.lines_count}</TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">{formatAmount(r.grand_total, r.currency_code)}</TableCell>
                    <TableCell className="text-left" dir="ltr">
                      {r.due_amount > 0 ? <span className="text-red-600 font-medium">{formatAmount(r.due_amount, r.currency_code)}</span> : "—"}
                    </TableCell>
                    <TableCell>
                      <Badge variant={r.due_amount > 0 ? "secondary" : "success"} className="text-[10px]">
                        {r.due_amount > 0 ? "آجلة" : "مسددة"}
                      </Badge>
                    </TableCell>
                    {canDeleteInvoice && (
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center gap-1">
                          {r.due_amount > 0 && (
                            <Button size="icon" variant="ghost" className="h-7 w-7 text-amber-600 hover:text-amber-500" onClick={() => setQuickPay({ supplierId: r.supplier_id ?? 0, invoiceId: r.id })} title="دفع سريع">
                              <Zap className="w-4 h-4" />
                            </Button>
                          )}
                          <Button size="icon" variant="ghost" onClick={() => deleteInvoice(r)} aria-label={`حذف ${r.number}`} title="حذف الفاتورة وعكس آثارها">
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {quickPay && (
        <QuickPaymentVoucherForm
          presetSupplierId={quickPay.supplierId || null}
          presetPurchaseInvoiceId={quickPay.invoiceId}
          onClose={() => setQuickPay(null)}
          onDone={() => load()}
        />
      )}

      {/* v15 — نافذة تفاصيل الفاتورة عند الضغط عليها */}
      {openedInvoice && (
        <InvoiceDetailModal
          invoice={openedInvoice}
          onClose={() => setOpenedInvoice(null)}
        />
      )}
    </div>
  );
}

// =====================================================================
// v15 — InvoiceDetailModal — نافذة عرض تفاصيل فاتورة الشراء
// =====================================================================
function InvoiceDetailModal({ invoice, onClose }: { invoice: InvoiceDetail; onClose: () => void }) {
  const formatLineAmount = (amount: number) => {
    if (invoice.currency_code === "USD") return `$${new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(amount)}`;
    return formatIQD(amount);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <Card className="w-full max-w-5xl max-h-[90vh] flex flex-col">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <FileText className="w-4 h-4" /> فاتورة شراء {invoice.number}
              </CardTitle>
              <CardDescription className="text-xs">
                {invoice.supplier.name} · {invoice.warehouse.name} · {formatDateTime(invoice.invoice_date)}
              </CardDescription>
            </div>
            <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="overflow-y-auto flex-1 space-y-4">
          {/* رأس الفاتورة */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
            <div>
              <div className="text-xs text-muted-foreground">المورد</div>
              <div className="font-medium">{invoice.supplier.name}</div>
              <div className="text-xs text-muted-foreground font-mono" dir="ltr">{invoice.supplier.code}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">المستودع</div>
              <div className="font-medium">{invoice.warehouse.name}</div>
              <div className="text-xs text-muted-foreground font-mono" dir="ltr">{invoice.warehouse.code}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">العملة</div>
              <div className="font-medium">
                {invoice.currency_code === "USD" ? "دولار أمريكي (USD)" : "دينار عراقي (IQD)"}
                {invoice.exchange_rate && (
                  <span className="text-xs text-muted-foreground mr-2" dir="ltr">
                    (1$ = {invoice.exchange_rate})
                  </span>
                )}
              </div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">المستخدم</div>
              <div className="font-medium">{invoice.creator.fullName}</div>
            </div>
          </div>

          {/* بنود الفاتورة */}
          <div className="rounded-lg border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>المنتج</TableHead>
                  <TableHead className="text-center">كراتين</TableHead>
                  <TableHead className="text-center">حبات</TableHead>
                  <TableHead className="text-center">إجمالي الحبات</TableHead>
                  <TableHead className="text-left">تكلفة الحبة</TableHead>
                  <TableHead className="text-left">بيع جمله</TableHead>
                  <TableHead className="text-left">بيع مفرد</TableHead>
                  <TableHead className="text-left">إجمالي البند</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invoice.lines.map((l) => (
                  <TableRow key={l.id}>
                    <TableCell>
                      <div className="text-sm font-medium">{l.product.name}</div>
                      <div className="text-[10px] text-muted-foreground font-mono" dir="ltr">
                        {l.product.code}
                        {l.product.packUnit && Number(l.product.packQty) > 1
                          ? ` · 1 ${l.product.packUnit} = ${Number(l.product.packQty)} ${l.product.unit}`
                          : ""}
                      </div>
                    </TableCell>
                    <TableCell className="text-center text-xs" dir="ltr">{l.cartons > 0 ? l.cartons : "—"}</TableCell>
                    <TableCell className="text-center text-xs" dir="ltr">{l.pieces > 0 ? l.pieces : "—"}</TableCell>
                    <TableCell className="text-center font-medium" dir="ltr">{l.qty}</TableCell>
                    <TableCell className="text-left text-xs" dir="ltr">{formatLineAmount(l.unit_cost)}</TableCell>
                    <TableCell className="text-left text-xs" dir="ltr">
                      {l.wholesale_sale_price != null ? formatLineAmount(l.wholesale_sale_price) : "—"}
                    </TableCell>
                    <TableCell className="text-left text-xs" dir="ltr">
                      {l.retail_sale_price != null ? formatLineAmount(l.retail_sale_price) : "—"}
                    </TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">{formatLineAmount(l.line_total)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* الإجماليات */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="rounded-lg border p-3">
              <div className="text-xs text-muted-foreground">الإجمالي الفرعي</div>
              <div className="font-bold" dir="ltr">{formatLineAmount(invoice.subtotal)}</div>
            </div>
            <div className="rounded-lg border p-3">
              <div className="text-xs text-muted-foreground">الإجمالي الكلي</div>
              <div className="font-bold" dir="ltr">{formatLineAmount(invoice.grand_total)}</div>
            </div>
            <div className="rounded-lg border p-3">
              <div className="text-xs text-muted-foreground">المسدد</div>
              <div className="font-bold text-emerald-600" dir="ltr">{formatLineAmount(invoice.paid_amount)}</div>
            </div>
            <div className="rounded-lg border p-3">
              <div className="text-xs text-muted-foreground">المستحق</div>
              <div className={"font-bold " + (invoice.due_amount > 0 ? "text-red-600" : "text-emerald-600")} dir="ltr">
                {formatLineAmount(invoice.due_amount)}
              </div>
            </div>
          </div>

          {invoice.notes && (
            <div className="rounded-lg border p-3 bg-muted/30">
              <div className="text-xs text-muted-foreground mb-1">ملاحظات</div>
              <div className="text-sm">{invoice.notes}</div>
            </div>
          )}

          {/* عرض قيمة الدولار إذا كانت الفاتورة بالدولار */}
          {invoice.currency_code === "USD" && invoice.exchange_rate && (
            <div className="rounded-lg border border-blue-200 bg-blue-50/50 dark:bg-blue-950/20 p-3">
              <div className="text-xs text-muted-foreground mb-1">تحويل العملة</div>
              <div className="text-sm" dir="ltr">
                {invoice.grand_total} USD × {invoice.exchange_rate} = <strong>{formatIQD(invoice.grand_total * invoice.exchange_rate)} IQD</strong>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
