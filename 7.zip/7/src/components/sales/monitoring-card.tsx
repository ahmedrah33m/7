"use client";

import * as React from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { Activity, RefreshCcw, Gauge } from "lucide-react";

// =====================================================================
// §71 — live monitoring card (system.monitoring.view): process vitals,
// HTTP counters per route, database vitals. Polls /monitoring/metrics.
// =====================================================================

interface MetricsSnapshot {
  process: { pid: number; node: string; uptime_sec: number; rss_mb: number; heap_used_mb: number; heap_total_mb: number };
  http: { total_requests: number; total_errors: number; error_rate_pct: number; tracked_routes: number; top_routes: { path: string; requests: number; errors: number; avg_ms: number; last_status: number }[] };
  database: { engine?: string; tables?: number; size_bytes?: number; counts?: Record<string, number>; error?: string };
  generated_at: string;
}

function humanUptime(sec: number): string {
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return d > 0 ? `${d} يوم ${h} ساعة` : h > 0 ? `${h} ساعة ${m} دقيقة` : `${m} دقيقة`;
}

export function MonitoringCard() {
  const [snap, setSnap] = React.useState<MetricsSnapshot | null>(null);
  const [loading, setLoading] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const { body } = await api<MetricsSnapshot>("/api/v1/monitoring/metrics");
      if (body.success && body.data) setSnap(body.data);
      else toast.error(body.message ?? "تعذر تحميل المقاييس");
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
    const t = setInterval(() => load(), 30_000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <CardTitle className="flex items-center gap-2"><Gauge className="w-5 h-5 text-primary" /> مراقبة النظام الحية (§71)</CardTitle>
            <CardDescription>مقاييس العملية والطلبات وقاعدة البيانات — تُحدَّث كل 30 ثانية · الصلاحية: system.monitoring.view</CardDescription>
          </div>
          <Button size="sm" variant="outline" onClick={load} disabled={loading}>
            <RefreshCcw className={"w-4 h-4" + (loading ? " animate-spin" : "")} /> تحديث الآن
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {!snap ? (
          <div className="py-6 text-center text-sm text-muted-foreground flex items-center justify-center gap-2">
            <Activity className="w-4 h-4 animate-pulse" /> جارٍ جمع المقاييس...
          </div>
        ) : (
          <>
            <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
              <div className="rounded-lg border p-3"><div className="text-[11px] text-muted-foreground">مدة التشغيل</div><div className="text-sm font-bold">{humanUptime(snap.process.uptime_sec)}</div></div>
              <div className="rounded-lg border p-3"><div className="text-[11px] text-muted-foreground">الذاكرة RSS</div><div className="text-sm font-bold" dir="ltr">{snap.process.rss_mb} MB</div></div>
              <div className="rounded-lg border p-3"><div className="text-[11px] text-muted-foreground">إجمالي الطلبات</div><div className="text-sm font-bold" dir="ltr">{snap.http.total_requests}</div></div>
              <div className="rounded-lg border p-3"><div className="text-[11px] text-muted-foreground">نسبة الأخطاء</div><div className="text-sm font-bold" dir="ltr">{snap.http.error_rate_pct}%</div></div>
              <div className="rounded-lg border p-3"><div className="text-[11px] text-muted-foreground">جداول القاعدة</div><div className="text-sm font-bold" dir="ltr">{snap.database.tables ?? "—"}</div></div>
              <div className="rounded-lg border p-3"><div className="text-[11px] text-muted-foreground">حجم القاعدة</div><div className="text-sm font-bold" dir="ltr">{snap.database.size_bytes ? Math.round(snap.database.size_bytes / 1024) + " KB" : "—"}</div></div>
            </div>

            <div className="rounded-lg border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المسار (مطبع)</TableHead>
                    <TableHead className="text-left">الطلبات</TableHead>
                    <TableHead className="text-left">الأخطاء</TableHead>
                    <TableHead className="text-left">متوسط زمن الاستجابة</TableHead>
                    <TableHead className="text-left">آخر حالة</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {snap.http.top_routes.map((r) => (
                    <TableRow key={r.path}>
                      <TableCell className="font-mono text-xs" dir="ltr">{r.path}</TableCell>
                      <TableCell className="text-left">{r.requests}</TableCell>
                      <TableCell className={"text-left" + (r.errors > 0 ? " text-destructive font-semibold" : "")}>{r.errors}</TableCell>
                      <TableCell className="text-left" dir="ltr">{r.avg_ms} ms</TableCell>
                      <TableCell className="text-left" dir="ltr">{r.last_status}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <div className="text-[11px] text-muted-foreground">
              المحرك: {snap.database.engine ?? "—"} · الفواتير: {snap.database.counts?.invoices ?? 0} · المنتجات: {snap.database.counts?.products ?? 0} · حركات المخزون: {snap.database.counts?.stock_movements ?? 0} · تدقيق: {snap.database.counts?.audit_logs ?? 0} · آخر قياس: {snap.generated_at.slice(11, 19)} UTC — صيغة Prometheus متاحة عبر <span dir="ltr" className="font-mono">?format=text</span>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
