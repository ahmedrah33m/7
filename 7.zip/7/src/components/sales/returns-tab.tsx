"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { Decimal, dec, moneyR, num as decNum, qtyR, sumOf } from "@/lib/decimal";
import { formatDateTime, formatIQD } from "@/lib/utils";
import { ClipboardList, MessageCircle, RotateCcw } from "lucide-react";

interface InvoiceLite { id: number; number: string; customer: { name: string }; grand_total: number; due_amount: number }
interface InvoiceDetail {
  id: number;
  number: string;
  type: string;
  customer: { name: string };
  grand_total: number;
  paid_amount: number;
  due_amount: number;
  lines: { id: number; product: { name: string; unit: string }; qty: number; unit_price: number; line_total: number }[];
}
interface ReturnRow {
  id: number;
  number: string;
  return_date: string;
  customer: { name: string; whatsapp?: string | null };
  invoice: { number: string } | null;
  total_amount: number;
  credit_note: number;
  refund_cash: number;
  created_by: string;
}

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";

export function ReturnsTab({ warehouses, canCreate }: { warehouses: { id: number; name: string }[]; canCreate: boolean }) {
  const [invoices, setInvoices] = React.useState<InvoiceLite[]>([]);
  const [detail, setDetail] = React.useState<InvoiceDetail | null>(null);
  const [qtyMap, setQtyMap] = React.useState<Record<number, number>>({});
  const [refundCash, setRefundCash] = React.useState(0);
  const [rows, setRows] = React.useState<ReturnRow[] | null>(null);
  const [saving, setSaving] = React.useState(false);

  const load = React.useCallback(async () => {
    const [inv, ret] = await Promise.all([
      api<InvoiceLite[]>("/api/v1/sales/invoices?per_page=50"),
      api<ReturnRow[]>("/api/v1/sales/returns?per_page=25"),
    ]);
    if (inv.body.success && inv.body.data) setInvoices(inv.body.data);
    if (ret.body.success && ret.body.data) setRows(ret.body.data);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  const total = decNum(moneyR(sumOf(detail?.lines ?? [], (l) => dec(qtyMap[l.id] ?? 0).mul(l.unit_price))));
  const cash = decNum(Decimal.min(dec(refundCash || 0), dec(total)));
  const credit = decNum(moneyR(dec(total).minus(cash)));

  async function pickInvoice(idStr: string) {
    setDetail(null);
    setQtyMap({});
    setRefundCash(0);
    if (!idStr) return;
    const { body } = await api<InvoiceDetail>(`/api/v1/sales/invoices/${idStr}`);
    if (body.success && body.data) setDetail(body.data);
    else toast.error(body.message ?? "تعذر تحميل الفاتورة");
  }

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!detail) return toast.error("اختر الفاتورة أولًا");
    const lines = Object.entries(qtyMap)
      .filter(([, q]) => q > 0)
      .map(([id, q]) => ({ invoice_line_id: Number(id), qty: q }));
    if (!lines.length) return toast.error("أدخل كمية مرتجعة لبند واحد على الأقل");
    setSaving(true);
    const fd = new FormData(e.currentTarget);
    try {
      const { body } = await api("/api/v1/sales/returns", {
        method: "POST",
        body: JSON.stringify({
          invoice_id: detail.id,
          cashbox_id: cash > 0 && fd.get("cashbox_id") ? Number(fd.get("cashbox_id")) : undefined,
          refund_cash: cash,
          notes: fd.get("notes") || undefined,
          lines,
        }),
      });
      if (body.success) {
        const d = body.data as { number: string; credit_note: number; refund_cash: number };
        toast.success(`مرتجع ${d.number} رُحّل ✓ — إشعار دائن: ${formatIQD(d.credit_note)} · رد نقدي: ${formatIQD(d.refund_cash)}`);
        setDetail(null);
        setQtyMap({});
        setRefundCash(0);
        (e.target as HTMLFormElement).reset();
        await load();
      } else toast.error(body.message ?? "فشل ترحيل المرتجع");
    } finally {
      setSaving(false);
    }
  }

  /** إشعار العميل بالمرتجع عبر واتساب — رسالة إشعار دائن جاهزة من بيانات الصف */
  function shareReturn(r: ReturnRow) {
    const msg = [
      `السلام عليكم ${r.customer.name}`,
      `سجّلنا لكم مرتجعًا بإشعار دائن *${r.number}*`,
      r.invoice?.number ? `على الفاتورة: ${r.invoice.number}` : "",
      `التاريخ: ${formatDateTime(r.return_date)}`,
      `إجمالي المرتجع: ${formatIQD(r.total_amount)}`,
      r.credit_note > 0 ? `رُحّل إلى رصيدكم كإشعار دائن: ${formatIQD(r.credit_note)}` : "",
      r.refund_cash > 0 ? `الرد النقدي: ${formatIQD(r.refund_cash)}` : "",
      `شكرًا لتعاملكم معنا، ونسعد بخدمتكم دائمًا.`,
    ].filter(Boolean).join("\n");
    const phone = r.customer.whatsapp?.replace(/\D/g, "");
    const url = phone
      ? `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`
      : `https://wa.me/?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
  }

  return (
    <div className="space-y-4">
      {canCreate && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><RotateCcw className="w-5 h-5 text-primary" /> مرتجع بيع جديد</CardTitle>
            <CardDescription>المرتجع على فاتورة محددة وبسعرها الأصلي — الكمية لا تتجاوز المتبقي (المباع − المرتجع سابقًا). المخزون يعود فورًا والذمة تُخفّض بإشعار دائن أو رد نقدي.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={submit} className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <label className="text-xs font-medium space-y-1 lg:col-span-2">الفاتورة *
                  <select className={inputCls} onChange={(e) => pickInvoice(e.target.value)} defaultValue="">
                    <option value="">— اختر فاتورة —</option>
                    {invoices.map((i) => (
                      <option key={i.id} value={i.id}>{i.number} — {i.customer.name} ({formatIQD(i.grand_total)})</option>
                    ))}
                  </select>
                </label>
                {cash > 0 && (
                  <label className="text-xs font-medium space-y-1">صندوق الرد النقدي *
                    <select name="cashbox_id" className={inputCls} defaultValue={warehouses[0]?.id ?? ""}>
                      {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
                    </select>
                  </label>
                )}
                <label className="text-xs font-medium space-y-1">ملاحظة
                  <input name="notes" className={inputCls} placeholder="سبب الإرجاع (اختياري)" />
                </label>
              </div>

              {detail && (
                <div className="rounded-lg border p-3 space-y-2">
                  <div className="text-sm font-medium">بنود {detail.number} — أدخل الكمية المرتجعة لكل بند</div>
                  <div className="space-y-2">
                    {detail.lines.map((l) => (
                      <div key={l.id} className="grid grid-cols-[1fr_100px_110px_110px] items-center gap-2">
                        <div className="text-sm">{l.product.name} <span className="text-xs text-muted-foreground">({l.qty} {l.product.unit} مباع)</span></div>
                        <div className="text-left text-sm" dir="ltr">{formatIQD(l.unit_price)}</div>
                        <input type="number" min="0" max={l.qty} step="any" className={inputCls} dir="ltr" placeholder="مرتجع"
                          value={qtyMap[l.id] ?? ""}
                          onChange={(e) => setQtyMap((m) => ({ ...m, [l.id]: Math.min(Number(e.target.value || 0), l.qty) }))} />
                        <div className="text-left text-sm font-medium" dir="ltr">{formatIQD((qtyMap[l.id] ?? 0) * l.unit_price)}</div>
                      </div>
                    ))}
                  </div>
                  <div className="grid gap-3 sm:grid-cols-3 pt-2 border-t">
                    <div className="text-sm font-bold">إجمالي المرتجع: <span dir="ltr">{formatIQD(total)}</span></div>
                    <label className="text-xs font-medium space-y-1">رد نقدي الآن (IQD)
                      <input type="number" min="0" max={total} step="any" className={inputCls} dir="ltr" value={refundCash || ""}
                        onChange={(e) => setRefundCash(Math.min(Number(e.target.value || 0), total))} />
                    </label>
                    <div className="text-sm">باقٍ إشعار دائن (على الذمة): <span className="font-bold" dir="ltr">{formatIQD(credit)}</span></div>
                  </div>
                </div>
              )}

              <Button type="submit" disabled={saving || !detail || total <= 0}>{saving ? "جارٍ الترحيل..." : "ترحيل المرتجع"}</Button>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base flex items-center gap-2"><ClipboardList className="w-4 h-4 text-primary" /> المرتجعات</CardTitle></CardHeader>
        <CardContent>
          {rows === null ? (
            <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div>
          ) : rows.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">لا مرتجعات بعد</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الرقم</TableHead>
                  <TableHead>التاريخ</TableHead>
                  <TableHead>العميل</TableHead>
                  <TableHead>على فاتورة</TableHead>
                  <TableHead className="text-left">الإجمالي</TableHead>
                  <TableHead className="text-left">إشعار دائن</TableHead>
                  <TableHead className="text-left">رد نقدي</TableHead>
                  <TableHead className="text-left">واتساب</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-mono text-xs" dir="ltr">{r.number}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{formatDateTime(r.return_date)}</TableCell>
                    <TableCell className="text-sm">{r.customer.name}</TableCell>
                    <TableCell className="font-mono text-xs" dir="ltr">{r.invoice?.number ?? "—"}</TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(r.total_amount)}</TableCell>
                    <TableCell className="text-left" dir="ltr">{r.credit_note > 0 ? formatIQD(r.credit_note) : "—"}</TableCell>
                    <TableCell className="text-left" dir="ltr">
                      {r.refund_cash > 0 ? <Badge variant="secondary" className="text-[10px]" dir="ltr">{formatIQD(r.refund_cash)}</Badge> : "—"}
                    </TableCell>
                    <TableCell className="text-left">
                      <Button variant="outline" size="sm" className="h-8 gap-1.5" title="إرسال إشعار دائن على واتساب" onClick={() => shareReturn(r)}>
                        <MessageCircle className="w-4 h-4 text-green-600" />
                        إشعار
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
