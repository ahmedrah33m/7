"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

export type KpiTone =
  | "blue"
  | "cyan"
  | "indigo"
  | "violet"
  | "emerald"
  | "amber"
  | "rose"
  | "slate";

/** Static class strings (kept literal so Tailwind JIT generates them). */
const TONES: Record<KpiTone, { bg: string; shadow: string }> = {
  blue: { bg: "bg-gradient-to-br from-blue-600 to-indigo-700", shadow: "shadow-blue-600/20" },
  cyan: { bg: "bg-gradient-to-br from-cyan-600 to-blue-700", shadow: "shadow-cyan-600/20" },
  indigo: { bg: "bg-gradient-to-br from-indigo-600 to-violet-700", shadow: "shadow-indigo-600/20" },
  violet: { bg: "bg-gradient-to-br from-violet-600 to-purple-700", shadow: "shadow-violet-600/20" },
  emerald: { bg: "bg-gradient-to-br from-emerald-600 to-teal-700", shadow: "shadow-emerald-600/20" },
  amber: { bg: "bg-gradient-to-br from-amber-500 to-orange-600", shadow: "shadow-amber-500/20" },
  rose: { bg: "bg-gradient-to-br from-rose-600 to-red-700", shadow: "shadow-rose-600/20" },
  slate: { bg: "bg-gradient-to-br from-slate-600 to-slate-800", shadow: "shadow-slate-600/20" },
};

export function KpiCard({
  icon,
  label,
  value,
  sub,
  tone = "blue",
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
  tone?: KpiTone;
}) {
  const t = TONES[tone];
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl p-5 text-white shadow-lg transition-transform hover:-translate-y-0.5",
        t.bg,
        t.shadow
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="text-[13px] font-medium text-white/80">{label}</div>
          <div className="mt-1.5 text-2xl font-bold leading-none" dir="ltr">
            {value}
          </div>
          {sub ? <div className="mt-2 text-[11px] text-white/70">{sub}</div> : null}
        </div>
        <div className="text-white/90">{icon}</div>
      </div>
      {/* watermark icon */}
      <div className="pointer-events-none absolute -bottom-7 -left-5 opacity-20">
        <div className="scale-[2.6]">{icon}</div>
      </div>
    </div>
  );
}
