"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { formatIQD } from "@/lib/utils";
import { FileUp, Plus, ReceiptText, Search, Users, UserCheck, MessageCircle, Zap } from "lucide-react";
import { QuickReceiptForm } from "@/components/sales/quick-receipt-form";

interface CustomerRow {
  id: number;
  code: string;
  name: string;
  phone: string | null;
  whatsapp?: string | null;
  address: string | null;
  credit_limit: number;
  credit_days: number;
  balance: number;
  is_active: boolean;
  customer_type?: string;
  is_walkin?: boolean;
  converted_from_walk_in?: boolean;
}

const TYPE_META: Record<string, { label: string; cls: string }> = {
  REGISTERED: { label: "مسجل", cls: "bg-emerald-100 text-emerald-800" },
  WALK_IN: { label: "WALK-IN متردد", cls: "bg-amber-100 text-amber-800" },
  CASH_CUSTOMER: { label: "CASH كاشي", cls: "bg-amber-100 text-amber-800" },
  GUEST: { label: "GUEST ضيف", cls: "bg-amber-100 text-amber-800" },
};

interface StatementRow {
  date: string;
  kind: "INVOICE" | "RETURN" | "COLLECTION" | "PAYMENT";
  ref: string;
  description: string;
  debit: number;
  credit: number;
  running: number;
}

interface StatementData {
  customer: { id: number; code: string; name: string; phone: string | null; whatsapp?: string | null; balance: number; creditLimit: number; creditDays: number };
  rows: StatementRow[];
  totals: { debit: number; credit: number };
  opening_balance?: number;
  closing_balance: number;
}

// v14 — إلغاء نظام نقاط الولاء (طلب المالك): حُذفت واجهات الولاء والاستبدال
// — الحركات التاريخية (إن وُجدت) تبقى ظاهرة في كشف الحساب فقط.

const KIND_META: Record<string, { label: string; cls: string }> = {
  INVOICE: { label: "فاتورة", cls: "bg-navy text-white" },
  PAYMENT: { label: "سداد فوري", cls: "bg-green-100 text-green-800" },
  RETURN: { label: "مرتجع", cls: "bg-amber-100 text-amber-800" },
  COLLECTION: { label: "تحصيل", cls: "bg-green-100 text-green-800" },
  LOYALTY: { label: "نقاط ولاء", cls: "bg-purple-100 text-purple-800" },
};

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";

export function CustomersTab({ canEdit, canImport }: { canEdit: boolean; canImport?: boolean }) {
  const [rows, setRows] = React.useState<CustomerRow[] | null>(null);
  const [q, setQ] = React.useState("");
  const [typeFilter, setTypeFilter] = React.useState("");
  const [showForm, setShowForm] = React.useState(false);
  const [showImport, setShowImport] = React.useState(false);
  const [saving, setSaving] = React.useState(false);
  const [importing, setImporting] = React.useState(false);
  const [statement, setStatement] = React.useState<StatementData | null>(null);
  const [stmtLoading, setStmtLoading] = React.useState(false);
  // تحصيل سريع من قائمة العملاء (Zap button)
  const [quickReceiptCust, setQuickReceiptCust] = React.useState<number | null>(null);

  const load = React.useCallback(async (search = "", type = "") => {
    const { body } = await api<CustomerRow[]>(`/api/v1/customers?per_page=100${search ? `&q=${encodeURIComponent(search)}` : ""}${type ? `&type=${type}` : ""}`);
    if (body.success && body.data) setRows(body.data);
    else toast.error(body.message ?? "تعذر تحميل العملاء");
  }, []);

  React.useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSaving(true);
    const fd = new FormData(e.currentTarget);
    try {
      const { body } = await api("/api/v1/customers", {
        method: "POST",
        body: JSON.stringify({
          name: fd.get("name"),
          phone: fd.get("phone") || undefined,
          address: fd.get("address") || undefined,
          credit_limit: Number(fd.get("credit_limit") || 0),
          credit_days: Number(fd.get("credit_days") || 0),
        }),
      });
      if (body.success) {
        toast.success(`أُنشئ العميل ${String((body.data as { code: string }).code)} ✓`);
        setShowForm(false);
        await load();
      } else toast.error(body.message ?? "فشل الإنشاء");
    } finally {
      setSaving(false);
    }
  }

  async function convertWalkin(c: CustomerRow) {
    const name = window.prompt(`تحويل «${c.name}» (${c.code}) إلى عميل مسجل — أدخل الاسم الكامل:`, c.customer_type === "WALK_IN" && c.code.startsWith("CASH-") ? "" : c.name);
    if (!name || name.trim().length < 2) return;
    const phone = window.prompt("الهاتف (اختياري):") ?? "";
    const creditLimit = Number(window.prompt("حد الائتمان (0 = نقدي فقط):", "0") || 0);
    const { res, body } = await api<{ code: string; name: string }>(`/api/v1/customers/${c.id}/convert`, {
      method: "POST",
      body: JSON.stringify({ name: name.trim(), phone: phone || undefined, credit_limit: Math.max(0, creditLimit) }),
    });
    if (body.success && body.data) {
      toast.success(`حُوّل إلى عميل مسجل: ${body.data.name} (${body.data.code}) — التاريخ محفوظ`);
      await load(q, typeFilter);
    } else {
      toast.error(body.message ?? "فشل التحويل");
    }
    void res;
  }

  async function openStatement(c: CustomerRow) {
    setStmtLoading(true);
    try {
      const { body } = await api<StatementData>(`/api/v1/reports/customer-statement?customer_id=${c.id}&days=365`);
      if (body.success && body.data) setStatement(body.data);
      else toast.error(body.message ?? "تعذر تحميل كشف الحساب");
    } finally {
      setStmtLoading(false);
    }
  }

  // v14 — إلغاء نقاط الولاء: حُذفت دوال فتح السجل والاستبدال

  function downloadStatementCsv(s: StatementData) {
    const head = "التاريخ,النوع,المرجع,الوصف,مدين,دائن,الرصيد";
    const lines = s.rows.map((r) =>
      [r.date, KIND_META[r.kind]?.label ?? r.kind, r.ref, r.description.replace(/[,"]/g, " "), r.debit, r.credit, r.running].join(",")
    );
    const csv = "\uFEFF" + [head, ...lines, ["", "", "", "الإجمالي", s.totals.debit, s.totals.credit, s.closing_balance].join(",")].join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `statement-${s.customer.code}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  /** إرسال كشف الحساب للعميل على واتساب — ملخص تنفيذي + آخر 8 حركات */
  function shareStatementWhatsApp(s: StatementData) {
    const fmt = (v: number) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(v);
    const KIND_SHORT: Record<string, string> = { INVOICE: "فاتورة", RETURN: "مرتجع", COLLECTION: "تحصيل", PAYMENT: "سداد" };
    const lastRows = s.rows.slice(-8).map((r) =>
      `• ${r.date} ${KIND_SHORT[r.kind] ?? r.kind} ${r.ref} — ${r.debit > 0 ? `عليه ${fmt(r.debit)}` : `له ${fmt(r.credit)}`} د.ع`
    );
    const msg = [
      `*كشف حساب — ${s.customer.name}*`,
      `العميل: ${s.customer.code} (آخر 365 يومًا)`,
      "",
      `إجمالي المستحقات (فواتير): ${fmt(s.totals.debit)} د.ع`,
      `إجمالي المسدد والمرتجع: ${fmt(s.totals.credit)} د.ع`,
      `*الرصيد الحالي: ${fmt(s.closing_balance)} د.ع*`,
      lastRows.length ? `\nآخر الحركات:\n${lastRows.join("\n")}` : "",
      "\nنرجو مراجعة الكشف وإبلاغنا بأي استفسار، وشكراً لتعاملكم معنا.",
    ].filter(Boolean).join("\n");
    const phone = s.customer.whatsapp?.replace(/\D/g, "");
    const url = phone
      ? `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`
      : `https://wa.me/?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
  }

  async function importCsv(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const csv = String(fd.get("csv") ?? "").trim();
    if (!csv) {
      toast.error("الصق محتوى CSV أولًا");
      return;
    }
    setImporting(true);
    try {
      const { body } = await api<{ created: number; skipped: number; errors: { line: number; message: string }[] }>(
        "/api/v1/customers/import",
        { method: "POST", body: JSON.stringify({ csv }) }
      );
      if (body.success && body.data) {
        const d = body.data;
        toast.success(`استيراد العملاء: ${d.created} جديد · ${d.skipped} مكرر${d.errors.length ? ` · ${d.errors.length} سطر خاطئ` : ""}`);
        if (d.errors.length) toast.warning(d.errors.slice(0, 3).map((x) => `سطر ${x.line}: ${x.message}`).join(" · "));
        setShowImport(false);
        await load();
      } else toast.error(body.message ?? "فشل الاستيراد");
    } finally {
      setImporting(false);
    }
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <CardTitle className="flex items-center gap-2"><Users className="w-5 h-5 text-primary" /> العملاء</CardTitle>
            <CardDescription>أرصدتهم المدينة وحدود الائتمان — الصلاحية: parties.customers.*</CardDescription>
          </div>
          {canEdit && (
            <div className="flex gap-2">
              <div className="relative">
                <Search className="w-4 h-4 absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input className="pr-8 w-48 h-9" placeholder="بحث بالاسم/الهاتف..." value={q}
                  onChange={(e) => { setQ(e.target.value); load(e.target.value, typeFilter); }} />
                <select
                  className="h-9 rounded-md border bg-background px-2 text-xs"
                  value={typeFilter}
                  onChange={(e) => { setTypeFilter(e.target.value); load(q, e.target.value); }}
                  aria-label="فلترة حسب نوع العميل"
                >
                  <option value="">كل الأنواع</option>
                  <option value="REGISTERED">مسجل</option>
                  <option value="WALK_IN">متردد / نقدي</option>
                  <option value="CASH_CUSTOMER">كاشي</option>
                  <option value="GUEST">ضيف</option>
                </select>
              </div>
              {canImport && (
                <Button size="sm" variant="outline" onClick={() => setShowImport((v) => !v)}>
                  <FileUp className="w-4 h-4" /> استيراد CSV
                </Button>
              )}
              <Button size="sm" onClick={() => setShowForm((v) => !v)}>
                <Plus className="w-4 h-4" /> عميل جديد
              </Button>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {showForm && canEdit && (
          <form onSubmit={submit} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 rounded-lg border p-4 mb-4 bg-muted/30">
            <label className="text-xs font-medium space-y-1">اسم العميل *
              <input name="name" required minLength={2} className={inputCls} placeholder="مثال: بقالة الأمانة" />
            </label>
            <label className="text-xs font-medium space-y-1">الهاتف
              <input name="phone" className={inputCls} dir="ltr" placeholder="0770..." />
            </label>
            <label className="text-xs font-medium space-y-1">العنوان
              <input name="address" className={inputCls} placeholder="اختياري" />
            </label>
            <label className="text-xs font-medium space-y-1">حد الائتمان (د.ع) — 0 = نقدي فقط
              <input name="credit_limit" type="number" min="0" step="any" className={inputCls} dir="ltr" placeholder="0" />
            </label>
            <label className="text-xs font-medium space-y-1">مهلة السداد (يوم)
              <input name="credit_days" type="number" min="0" max="365" className={inputCls} dir="ltr" placeholder="0" />
            </label>
            <div className="flex items-end">
              <Button type="submit" className="w-full" disabled={saving}>{saving ? "جارٍ الحفظ..." : "حفظ العميل"}</Button>
            </div>
          </form>
        )}

        {showImport && canImport && (
          <form onSubmit={importCsv} className="rounded-lg border p-4 mb-4 bg-muted/30 space-y-2">
            <div className="text-xs font-semibold">استيراد عملاء من CSV — الترتيب: الاسم, الهاتف, العنوان, حد الائتمان, مهلة السداد</div>
            <div className="text-[11px] text-muted-foreground" dir="ltr">بقالة الأمانة, 07701234567, الكرادة, 500000, 30</div>
            <textarea name="csv" rows={5} className={inputCls + " font-mono text-xs"} dir="ltr" placeholder="الصق الأسطر هنا..." />
            <Button type="submit" size="sm" disabled={importing}>{importing ? "جارٍ الاستيراد..." : "استيراد"}</Button>
          </form>
        )}

        {rows === null ? (
          <div className="py-10 text-center text-muted-foreground">جارٍ التحميل...</div>
        ) : rows.length === 0 ? (
          <div className="py-10 text-center text-muted-foreground">لا عملاء بعد</div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الكود</TableHead>
                <TableHead>العميل</TableHead>
                <TableHead>النوع</TableHead>
                <TableHead>الهاتف</TableHead>
                <TableHead className="text-left">حد الائتمان</TableHead>
                <TableHead className="text-left">الرصيد المدين</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((c) => (
                <TableRow key={c.id}>
                  <TableCell dir="ltr" className="font-mono text-xs text-right">{c.code}</TableCell>
                  <TableCell className="font-medium">
                    {c.name}
                    {c.address && <div className="text-[11px] text-muted-foreground">{c.address}</div>}
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col items-start gap-1">
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${TYPE_META[c.customer_type ?? "REGISTERED"]?.cls ?? TYPE_META.REGISTERED.cls}`}>
                        {TYPE_META[c.customer_type ?? "REGISTERED"]?.label ?? c.customer_type}
                      </span>
                      {c.converted_from_walk_in && (
                        <span className="text-[9px] text-muted-foreground">محوَّل من متردد</span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell dir="ltr" className="text-sm text-right">{c.phone ?? "—"}</TableCell>
                  <TableCell className="text-left text-sm" dir="ltr">{c.credit_limit > 0 ? formatIQD(c.credit_limit) : "نقدي فقط"}</TableCell>
                  <TableCell className="text-left">
                    {c.balance > 0
                      ? <Badge variant="secondary">{formatIQD(c.balance)}</Badge>
                      : <span className="text-sm text-muted-foreground">0</span>}
                  </TableCell>
                  <TableCell>{c.is_active ? <Badge variant="success" className="text-[10px]">نشط</Badge> : <Badge variant="destructive" className="text-[10px]">معطل</Badge>}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      {c.balance > 0 && (
                        <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-amber-600 hover:text-amber-500" onClick={() => setQuickReceiptCust(c.id)} title="استلام دفعة سريعة">
                          <Zap className="w-3.5 h-3.5" /> استلام دفعة
                        </Button>
                      )}
                      <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" disabled={stmtLoading} onClick={() => openStatement(c)}>
                        <ReceiptText className="w-3.5 h-3.5" /> كشف حساب
                      </Button>
                      {c.is_walkin && canEdit && (
                        <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-amber-700" onClick={() => convertWalkin(c)} title="Convert to Customer (المرحلة 22)">
                          <UserCheck className="w-3.5 h-3.5" /> تحويل لمسجل
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>

      {/* Customer statement overlay */}
      {statement && (
        <div className="fixed inset-0 z-[80] bg-black/50 flex items-center justify-center p-4" onClick={() => setStatement(null)}>
          <div className="bg-background rounded-lg border shadow-2xl w-[min(96vw,900px)] max-h-[90vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()} dir="rtl">
            <div className="flex items-center justify-between px-4 py-3 border-b bg-muted/40">
              <div>
                <div className="font-bold">كشف حساب — {statement.customer.name}</div>
                <div className="text-xs text-muted-foreground">
                  <span dir="ltr" className="font-mono">{statement.customer.code}</span>
                  {statement.customer.phone ? ` · ${statement.customer.phone}` : ""}
                  {" · الرصيد الختامي: "}
                  <span dir="ltr" className="font-semibold">{formatIQD(statement.closing_balance)}</span>
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => shareStatementWhatsApp(statement)} className="text-emerald-700 dark:text-emerald-400 border-emerald-600/40" title="إرسال الكشف للعميل على واتساب">
                  <MessageCircle className="w-4 h-4" /> واتساب
                </Button>
                <Button size="sm" variant="outline" onClick={() => downloadStatementCsv(statement)}>تصدير CSV</Button>
                <Button size="sm" variant="ghost" onClick={() => setStatement(null)}>إغلاق ✕</Button>
              </div>
            </div>
            <div className="overflow-y-auto">
              {statement.rows.length === 0 ? (
                <div className="py-10 text-center text-muted-foreground text-sm">لا حركات خلال آخر 365 يومًا</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>التاريخ</TableHead>
                      <TableHead>النوع</TableHead>
                      <TableHead>المرجع</TableHead>
                      <TableHead>الوصف</TableHead>
                      <TableHead className="text-left">مدين</TableHead>
                      <TableHead className="text-left">دائن</TableHead>
                      <TableHead className="text-left">الرصيد الجاري</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {statement.rows.map((r, i) => {
                      const km = KIND_META[r.kind] ?? { label: r.kind, cls: "" };
                      return (
                        <TableRow key={i}>
                          <TableCell className="text-xs text-muted-foreground" dir="ltr">{r.date}</TableCell>
                          <TableCell><span className={`text-[10px] px-1.5 py-0.5 rounded ${km.cls}`}>{km.label}</span></TableCell>
                          <TableCell className="font-mono text-xs" dir="ltr">{r.ref}</TableCell>
                          <TableCell className="text-xs">{r.description}</TableCell>
                          <TableCell className="text-left text-sm" dir="ltr">{r.debit ? formatIQD(r.debit) : "—"}</TableCell>
                          <TableCell className="text-left text-sm" dir="ltr">{r.credit ? formatIQD(r.credit) : "—"}</TableCell>
                          <TableCell className="text-left text-sm font-semibold" dir="ltr">{formatIQD(r.running)}</TableCell>
                        </TableRow>
                      );
                    })}
                    <TableRow className="bg-muted/40 font-bold">
                      <TableCell colSpan={4}>الإجمالي</TableCell>
                      <TableCell className="text-left" dir="ltr">{formatIQD(statement.totals.debit)}</TableCell>
                      <TableCell className="text-left" dir="ltr">{formatIQD(statement.totals.credit)}</TableCell>
                      <TableCell className="text-left" dir="ltr">{formatIQD(statement.closing_balance)}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              )}
            </div>
          </div>
        </div>
      )}

      {quickReceiptCust && (
        <QuickReceiptForm
          presetCustomerId={quickReceiptCust}
          presetInvoiceId={null}
          onClose={() => setQuickReceiptCust(null)}
          onDone={() => load(q, typeFilter)}
        />
      )}
      // v14 — أُزيلت نافذة نقاط الولاء (إلغاء النظام)
    </Card>
  );
}
