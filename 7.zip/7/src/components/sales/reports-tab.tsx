"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api, getAccessToken } from "@/lib/client-api";
import { formatIQD } from "@/lib/utils";
import { KpiCard } from "@/components/sales/kpi-card";
import {
  BarChart3, Download, Loader2, DatabaseBackup, Boxes, Coins, TrendingUp,
  ShoppingCart, Package, Wallet, MapPin,
} from "lucide-react";

type ReportKey =
  // sales
  | "sales-daily" | "monthly-sales" | "top-products" | "sales-by-customer"
  | "sales-by-category" | "sales-by-branch" | "sales-by-payment-method" | "rep-performance"
  // inventory
  | "valuation" | "stock-balance" | "stock-ledger" | "low-stock" | "out-of-stock"
  | "dead-stock" | "transfers-report" | "adjustments-report" | "damages-report" | "returns-report"
  // finance
  | "aging" | "receivables" | "payables" | "collections-report" | "expenses-report"
  | "cashbox-report" | "profit" | "customer-statement"
  // reps
  | "rep-targets" | "rep-commissions" | "rep-visits" | "rep-customers" | "rep-returns"
  | "sales-by-customer-type" | "walkin-kpis"
  // advanced finance (v4)
  | "cashbox-movement" | "daily-receipts" | "daily-payments" | "expense-by-category"
  | "collection-rate" | "cashier-shift-report" | "top-late-customers"
  | "cash-flow-statement" | "budget-alerts" | "fraud-alerts"
  | "pending-receipts" | "aging-trend";

type ColAlign = "left" | "center";
interface ColumnDef {
  key: string;
  label: string;
  align?: ColAlign; // default: right (RTL start)
  money?: boolean;
  pct?: boolean;
}

interface ReportDef {
  key: ReportKey;
  title: string;
  desc: string;
  group: "المبيعات" | "المخزون" | "المالية" | "المندوبون" | "الحسابات";
  columns?: ColumnDef[]; // generic renderer (rows-based)
  summaryLabels?: Record<string, string>;
  summaryMoney?: string[]; // which summary keys are currency
}

const REPORTS: ReportDef[] = [
  // ---- المبيعات
  { key: "sales-daily", title: "المبيعات اليومية", desc: "آخر 14 يومًا — عدد الفواتير والإجمالي (نقدي/آجل)", group: "المبيعات" },
  { key: "monthly-sales", title: "المبيعات الشهرية", desc: "آخر 12 شهرًا — الإجمالي الشهري مع تقسيم نقدي/آجل", group: "المبيعات",
    columns: [
      { key: "month", label: "الشهر" },
      { key: "count", label: "الفواتير", align: "left" },
      { key: "cash", label: "نقدي", align: "left", money: true },
      { key: "credit", label: "آجل", align: "left", money: true },
      { key: "total", label: "الإجمالي", align: "left", money: true },
    ],
    summaryLabels: { total: "إجمالي الفترة", invoice_count: "عدد الفواتير", months_with_sales: "أشهر بمبيعات", best_month_total: "أفضل شهر" }, summaryMoney: ["total", "best_month_total"] },
  { key: "top-products", title: "أفضل المنتجات", desc: "أعلى 10 منتجات حسب الإيراد", group: "المبيعات" },
  { key: "sales-by-customer", title: "المبيعات حسب العميل", desc: "أعلى 30 عميلًا — الإيراد والمحصّل والمستحق", group: "المبيعات",
    columns: [
      { key: "code", label: "الكود" },
      { key: "name", label: "العميل" },
      { key: "invoices", label: "الفواتير", align: "left" },
      { key: "revenue", label: "الإيراد", align: "left", money: true },
      { key: "paid", label: "المحصّل", align: "left", money: true },
      { key: "due", label: "المستحق", align: "left", money: true },
    ],
    summaryLabels: { customers_with_sales: "عملاء بمبيعات", total_revenue: "إجمالي الإيراد", total_due: "إجمالي المستحق" }, summaryMoney: ["total_revenue", "total_due"] },
  { key: "sales-by-category", title: "المبيعات حسب التصنيف", desc: "الإيراد والكمية ونسبة الحصة لكل تصنيف", group: "المبيعات",
    columns: [
      { key: "category", label: "التصنيف" },
      { key: "qty", label: "الكمية", align: "left" },
      { key: "revenue", label: "الإيراد", align: "left", money: true },
      { key: "share_pct", label: "الحصة %", align: "left", pct: true },
    ],
    summaryLabels: { categories: "التصنيفات", total_revenue: "الإيراد" }, summaryMoney: ["total_revenue"] },
  { key: "sales-by-branch", title: "المبيعات حسب الفرع", desc: "الإيراد والمحصّل لكل فرع", group: "المبيعات",
    columns: [
      { key: "code", label: "الكود" },
      { key: "branch", label: "الفرع" },
      { key: "invoices", label: "الفواتير", align: "left" },
      { key: "revenue", label: "الإيراد", align: "left", money: true },
      { key: "collected", label: "المحصّل", align: "left", money: true },
    ],
    summaryLabels: { branches: "الفروع", total_revenue: "الإيراد" }, summaryMoney: ["total_revenue"] },
  { key: "sales-by-payment-method", title: "نقدي مقابل آجل", desc: "توزيع المبيعات حسب طريقة الدفع", group: "المبيعات",
    columns: [
      { key: "method", label: "الطريقة" },
      { key: "count", label: "الفواتير", align: "left" },
      { key: "total", label: "الإجمالي", align: "left", money: true },
      { key: "share_pct", label: "الحصة %", align: "left", pct: true },
    ],
    summaryLabels: { total: "الإجمالي", invoices: "كل الفواتير" }, summaryMoney: ["total"] },
  { key: "rep-performance", title: "أداء المندوبين", desc: "آخر 30 يومًا — فواتير، مبيعات، زيارات مكتملة، تحصيلات، عمولات", group: "المبيعات" },

  // ---- المخزون
  { key: "valuation", title: "تقييم المخزون", desc: "قيمة المخزون بالتكلفة وسعر البيع لكل مستودع", group: "المخزون" },
  { key: "stock-balance", title: "أرصدة المخزون", desc: "كل رصيد منتج × مستودع مع قيمته", group: "المخزون",
    columns: [
      { key: "warehouse", label: "المستودع" },
      { key: "product_code", label: "الكود" },
      { key: "product", label: "المنتج" },
      { key: "qty", label: "الرصيد", align: "left" },
      { key: "cost_value", label: "قيمة التكلفة", align: "left", money: true },
      { key: "sale_value", label: "القيمة البيعية", align: "left", money: true },
    ],
    summaryLabels: { lines: "الأسطر", total_cost: "قيمة التكلفة", total_sale: "القيمة البيعية" }, summaryMoney: ["total_cost", "total_sale"] },
  { key: "stock-ledger", title: "دفتر حركة المخزون", desc: "آخر 300 حركة (وارد/صادر) مع الرصيد بعدها", group: "المخزون",
    columns: [
      { key: "date", label: "التاريخ" },
      { key: "warehouse", label: "المستودع" },
      { key: "product", label: "المنتج" },
      { key: "direction", label: "الاتجاه" },
      { key: "qty", label: "الكمية", align: "left" },
      { key: "ref_type", label: "المرجع" },
      { key: "balance_after", label: "الرصيد بعدها", align: "left" },
    ],
    summaryLabels: { shown: "عدد الحركات المعروضة" } },
  { key: "low-stock", title: "تحت الحد الأدنى", desc: "منتجات وصلت لحد الطلب — كمية النقص وتكلفة الإعادة", group: "المخزون",
    columns: [
      { key: "code", label: "الكود" },
      { key: "product", label: "المنتج" },
      { key: "on_hand", label: "المتوفر", align: "left" },
      { key: "min_stock", label: "الحد الأدنى", align: "left" },
      { key: "shortage", label: "النقص", align: "left" },
      { key: "restock_cost", label: "تكلفة الإعادة", align: "left", money: true },
    ],
    summaryLabels: { items: "أصناف", shortage_qty: "كمية النقص", restock_cost: "تكلفة الإعادة" }, summaryMoney: ["restock_cost"] },
  { key: "out-of-stock", title: "منتهي المخزون", desc: "منتجات نشطة بلا أي رصيد متاح", group: "المخزون",
    columns: [
      { key: "code", label: "الكود" },
      { key: "product", label: "المنتج" },
      { key: "sale_price", label: "سعر البيع", align: "left", money: true },
    ],
    summaryLabels: { items: "أصناف نافدة", lost_sale_value: "مجموع أسعار البيع" }, summaryMoney: ["lost_sale_value"] },
  { key: "dead-stock", title: "المخزون الراكد", desc: "بلا أي حركة منذ 90 يومًا — رأس مال مجمّد", group: "المخزون",
    columns: [
      { key: "warehouse", label: "المستودع" },
      { key: "code", label: "الكود" },
      { key: "product", label: "المنتج" },
      { key: "qty", label: "الكمية", align: "left" },
      { key: "frozen_cost", label: "رأس مال مجمّد", align: "left", money: true },
    ],
    summaryLabels: { items: "أصناف راكدة", frozen_cost: "إجمالي المجمّد" }, summaryMoney: ["frozen_cost"] },
  { key: "transfers-report", title: "التحويلات", desc: "تحويلات آخر 30 يومًا بين المستودعات", group: "المخزون",
    columns: [
      { key: "number", label: "الرقم" },
      { key: "from", label: "من" },
      { key: "to", label: "إلى" },
      { key: "status", label: "الحالة" },
      { key: "items", label: "بنود", align: "left" },
      { key: "qty", label: "الكمية", align: "left" },
      { key: "date", label: "التاريخ" },
    ],
    summaryLabels: { transfers: "عدد التحويلات", dispatched: "مُرسلة" } },
  { key: "adjustments-report", title: "تسويات المخزون", desc: "آخر 300 تسوية (زيادة/نقص) بكل تفاصيلها", group: "المخزون",
    columns: [
      { key: "date", label: "التاريخ" },
      { key: "warehouse", label: "المستودع" },
      { key: "product", label: "المنتج" },
      { key: "direction", label: "الاتجاه" },
      { key: "qty", label: "الكمية", align: "left" },
      { key: "note", label: "السبب" },
    ],
    summaryLabels: { count: "عدد التسويات", increase_qty: "كمية الزيادات", decrease_qty: "كمية النواقص" } },
  { key: "damages-report", title: "الهالك والعجز", desc: "تسويات صادرة (عجز/هالك) مع قيمة الخسارة", group: "المخزون",
    columns: [
      { key: "date", label: "التاريخ" },
      { key: "warehouse", label: "المستودع" },
      { key: "product", label: "المنتج" },
      { key: "qty", label: "الكمية", align: "left" },
      { key: "cost_loss", label: "قيمة الخسارة", align: "left", money: true },
      { key: "note", label: "السبب" },
    ],
    summaryLabels: { events: "عدد الحالات", total_loss: "إجمالي الخسارة" }, summaryMoney: ["total_loss"] },
  { key: "returns-report", title: "المرتجعات", desc: "مرتجعات آخر 30 يومًا — نقد مرجع وإشعار دائن", group: "المخزون",
    columns: [
      { key: "number", label: "الرقم" },
      { key: "date", label: "التاريخ" },
      { key: "customer", label: "العميل" },
      { key: "items", label: "بنود", align: "left" },
      { key: "total", label: "الإجمالي", align: "left", money: true },
      { key: "refund_cash", label: "رد نقدي", align: "left", money: true },
      { key: "credit_note", label: "إشعار دائن", align: "left", money: true },
    ],
    summaryLabels: { returns: "عدد المرتجعات", total: "إجمالي المرتجع", cash_refunds: "الرد النقدي" }, summaryMoney: ["total", "cash_refunds"] },

  // ---- المالية
  { key: "aging", title: "أعمار الذمم", desc: "توزيع المستحقات على العملاء حسب عمر الفاتورة", group: "المالية" },
  { key: "receivables", title: "الذمم المدينة", desc: "كل فاتورة غير مسددة مع عمرها — الأقدم أولًا", group: "المالية",
    columns: [
      { key: "invoice", label: "الفاتورة" },
      { key: "date", label: "التاريخ" },
      { key: "customer", label: "العميل" },
      { key: "total", label: "الإجمالي", align: "left", money: true },
      { key: "paid", label: "المسدد", align: "left", money: true },
      { key: "due", label: "المستحق", align: "left", money: true },
      { key: "age_days", label: "العمر (يوم)", align: "left" },
    ],
    summaryLabels: { open_invoices: "فواتير مفتوحة", total_due: "إجمالي المستحق", over_60d: "أقدم من 60 يوم" }, summaryMoney: ["total_due", "over_60d"] },
  { key: "payables", title: "الذمم الدائنة", desc: "مستحقات الموردين — الرصيد الدفتري وفواتير غير مسددة", group: "المالية",
    columns: [
      { key: "code", label: "الكود" },
      { key: "supplier", label: "المورد" },
      { key: "phone", label: "الهاتف" },
      { key: "ledger_balance", label: "الرصيد الدفتري", align: "left", money: true },
      { key: "unpaid_invoices", label: "فواتير غير مسددة", align: "left", money: true },
    ],
    summaryLabels: { suppliers_with_due: "موردون بمستحقات", total_payable: "إجمالي المستحق" }, summaryMoney: ["total_payable"] },
  { key: "collections-report", title: "التحصيلات", desc: "تحصيلات آخر 30 يومًا لكل صندوق", group: "المالية",
    columns: [
      { key: "date", label: "التاريخ" },
      { key: "cashbox", label: "الصندوق" },
      { key: "customer", label: "العميل" },
      { key: "amount", label: "المبلغ", align: "left", money: true },
      { key: "note", label: "ملاحظة" },
    ],
    summaryLabels: { transactions: "عدد العمليات", total: "إجمالي التحصيل" }, summaryMoney: ["total"] },
  { key: "expenses-report", title: "المصروفات", desc: "مصروفات آخر 30 يومًا لكل صندوق", group: "المالية",
    columns: [
      { key: "date", label: "التاريخ" },
      { key: "cashbox", label: "الصندوق" },
      { key: "amount", label: "المبلغ", align: "left", money: true },
      { key: "note", label: "البيان" },
    ],
    summaryLabels: { transactions: "عدد العمليات", total: "إجمالي المصروف" }, summaryMoney: ["total"] },
  { key: "cashbox-report", title: "أرصدة الصناديق", desc: "رصيد كل صندوق مع حركة آخر 30 يومًا", group: "المالية",
    columns: [
      { key: "code", label: "الكود" },
      { key: "cashbox", label: "الصندوق" },
      { key: "balance", label: "الرصيد", align: "left", money: true },
      { key: "inflow_30d", label: "وارد 30 يوم", align: "left", money: true },
      { key: "outflow_30d", label: "صادر 30 يوم", align: "left", money: true },
    ],
    summaryLabels: { cashboxes: "الصناديق", total_balance: "إجمالي الأرصدة" }, summaryMoney: ["total_balance"] },
  { key: "profit", title: "الربحية الإجمالية", desc: "الإيراد − التكلفة الفعلية وقت البيع لكل منتج", group: "المالية" },
  // ---- المالية المتقدمة (v4)
  { key: "cashbox-movement", title: "حركة الصندوق", desc: "كل حركات IN/OUT لصندوق محدد خلال فترة — مع balanceBefore/After", group: "المالية",
    columns: [
      { key: "date", label: "التاريخ" },
      { key: "cashbox", label: "الصندوق" },
      { key: "direction", label: "الاتجاه" },
      { key: "type", label: "النوع" },
      { key: "number", label: "الرقم" },
      { key: "amount", label: "المبلغ", align: "left", money: true },
      { key: "balance_before", label: "قبل", align: "left", money: true },
      { key: "balance_after", label: "بعد", align: "left", money: true },
    ],
    summaryLabels: { total_in: "إجمالي الوارد", total_out: "إجمالي الصادر", net: "الصافي", transactions_count: "عدد الحركات" }, summaryMoney: ["total_in", "total_out", "net"] },
  { key: "daily-receipts", title: "المقبوضات اليومية", desc: "كل وصولات القبض خلال فترة — مجمع حسب التاريخ", group: "المالية",
    columns: [
      { key: "number", label: "رقم الوصل" },
      { key: "date", label: "التاريخ" },
      { key: "recipient", label: "المستلم منه" },
      { key: "cashbox", label: "الصندوق" },
      { key: "amount", label: "المبلغ", align: "left", money: true },
      { key: "payment_method", label: "الطريقة" },
    ],
    summaryLabels: { total: "الإجمالي", count: "عدد الوصولات" }, summaryMoney: ["total"] },
  { key: "daily-payments", title: "المدفوعات اليومية", desc: "كل وصولات الصرف خلال فترة", group: "المالية",
    columns: [
      { key: "number", label: "رقم الوصل" },
      { key: "date", label: "التاريخ" },
      { key: "beneficiary", label: "المستفيد" },
      { key: "cashbox", label: "الصندوق" },
      { key: "amount", label: "المبلغ", align: "left", money: true },
      { key: "reason", label: "السبب" },
    ],
    summaryLabels: { total: "الإجمالي", count: "عدد الوصولات" }, summaryMoney: ["total"] },
  { key: "expense-by-category", title: "تحليل المصروفات", desc: "نسبة كل بند مصروف من الإجمالي — Pie chart", group: "المالية",
    columns: [
      { key: "category", label: "البند" },
      { key: "count", label: "عدد", align: "left" },
      { key: "total", label: "المبلغ", align: "left", money: true },
      { key: "pct", label: "النسبة %", align: "left", pct: true },
    ],
    summaryLabels: { total: "الإجمالي", count: "عدد البنود" }, summaryMoney: ["total"] },
  { key: "collection-rate", title: "نسبة التحصيل", desc: "مقبوضات اليوم ÷ فواتير اليوم × 100%", group: "المالية",
    summaryLabels: { collected_today: "مقبوضات اليوم", invoiced_today: "فواتير اليوم", rate_pct: "نسبة التحصيل %", outstanding_receivables: "إجمالي المستحق" }, summaryMoney: ["collected_today", "invoiced_today", "outstanding_receivables"] },
  { key: "cashier-shift-report", title: "تقرير وردية الكاشير", desc: "كل الورديات — افتتاحي/ختامي + المقبوضات/المدفوعات + المدة", group: "المالية",
    columns: [
      { key: "number", label: "رقم الوردية" },
      { key: "user", label: "الكاشير" },
      { key: "cashbox", label: "الصندوق" },
      { key: "clock_in_at", label: "البداية" },
      { key: "clock_out_at", label: "النهاية" },
      { key: "opening_balance", label: "افتتاحي", align: "left", money: true },
      { key: "closing_balance", label: "ختامي", align: "left", money: true },
      { key: "total_receipts", label: "مقبوضات", align: "left", money: true },
      { key: "total_payments", label: "مدفوعات", align: "left", money: true },
      { key: "duration_minutes", label: "المدة (د)", align: "left" },
    ],
    summaryLabels: { total_shifts: "إجمالي الورديات", open_shifts: "مفتوحة", closed_shifts: "مغلقة", total_receipts: "إجمالي المقبوضات", total_payments: "إجمالي المدفوعات" }, summaryMoney: ["total_receipts", "total_payments"] },
  { key: "top-late-customers", title: "Top 10 عملاء متأخرون", desc: "أكثر 10 عملاء تأخرًا في السداد — مع overdue_days", group: "المالية",
    columns: [
      { key: "customer.code", label: "الكود" },
      { key: "customer.name", label: "العميل" },
      { key: "balance", label: "الرصيد", align: "left", money: true },
      { key: "overdue_days", label: "أيام التأخر", align: "left" },
      { key: "oldest_invoice", label: "أقدم فاتورة" },
      { key: "invoices_count", label: "عدد الفواتير", align: "left" },
    ],
    summaryLabels: { total_overdue: "إجمالي المتأخر", count: "عدد العملاء" }, summaryMoney: ["total_overdue"] },
  { key: "cash-flow-statement", title: "قائمة التدفقات النقدية", desc: "شهري: نقد من العمليات + الاستثمار + صافي التدفق", group: "المالية",
    columns: [
      { key: "category", label: "الفئة" },
      { key: "inflow", label: "وارد", align: "left", money: true },
      { key: "outflow", label: "صادر", align: "left", money: true },
      { key: "net", label: "الصافي", align: "left", money: true },
    ],
    summaryLabels: { net_cash_flow: "صافي التدفق النقدي" }, summaryMoney: ["net_cash_flow"] },
  { key: "budget-alerts", title: "ميزانية المصروفات", desc: "% استهلاك الميزانية الشهرية + تنبيه عند تجاوز 80%", group: "المالية",
    columns: [
      { key: "category", label: "البند" },
      { key: "name", label: "الاسم" },
      { key: "budget", label: "الميزانية", align: "left", money: true },
      { key: "spent", label: "المصروف", align: "left", money: true },
      { key: "remaining", label: "المتبقي", align: "left", money: true },
      { key: "pct_used", label: "% استهلاك", align: "left", pct: true },
      { key: "alert", label: "الحالة" },
    ],
    summaryLabels: { total_budget: "إجمالي الميزانية", total_spent: "إجمالي المصروف", alerts_count: "تنبيهات" }, summaryMoney: ["total_budget", "total_spent"] },
  { key: "fraud-alerts", title: "كشف الاحتيال", desc: "تنبيهات ذكية: دفعات مكررة، فروق جرد كبيرة، حركات بعد ساعات العمل", group: "المالية",
    columns: [
      { key: "type", label: "النوع" },
      { key: "severity", label: "الخطورة" },
      { key: "message", label: "الرسالة" },
      { key: "amount", label: "المبلغ", align: "left", money: true },
    ],
    summaryLabels: { total_alerts: "إجمالي التنبيهات", high: "عالية", medium: "متوسطة", low: "منخفضة" } },
  { key: "pending-receipts", title: "وصولات بانتظار الموافقة", desc: "وصولات DRAFT تحتاج اعتماد", group: "المالية",
    columns: [
      { key: "number", label: "رقم الوصل" },
      { key: "receipt_date", label: "التاريخ" },
      { key: "recipient_name", label: "المستلم منه" },
      { key: "cashbox", label: "الصندوق" },
      { key: "amount", label: "المبلغ", align: "left", money: true },
    ],
    summaryLabels: { count: "عدد الوصولات", total_amount: "الإجمالي" }, summaryMoney: ["total_amount"] },
  { key: "aging-trend", title: "اتجاه أعمار الديون", desc: "6 أشهر — توزيع المستحقات على الفئات شهريًا", group: "المالية",
    columns: [
      { key: "month", label: "الشهر" },
      { key: "current", label: "حالي", align: "left", money: true },
      { key: "1_30", label: "1-30", align: "left", money: true },
      { key: "31_60", label: "31-60", align: "left", money: true },
      { key: "61_90", label: "61-90", align: "left", money: true },
      { key: "90+", label: "+90", align: "left", money: true },
      { key: "total", label: "الإجمالي", align: "left", money: true },
    ],
    summaryLabels: { months: "أشهر", latest_total: "آخر إجمالي" }, summaryMoney: ["latest_total"] },
  { key: "customer-statement", title: "كشف حساب عميل", desc: "حركة العميل: فواتير، مرتجعات، تحصيلات، ولاء — مع رصيد متسلسل", group: "الحسابات" },

  // ---- المندوبون
  { key: "rep-targets", title: "المستهدف والإنجاز", desc: "مستهدفات الشهر الحالي والسابق مقابل المبيعات الفعلية", group: "المندوبون",
    columns: [
      { key: "period", label: "الشهر" },
      { key: "rep", label: "المندوب" },
      { key: "target", label: "المستهدف", align: "left", money: true },
      { key: "achieved", label: "المنجز", align: "left", money: true },
      { key: "achievement_pct", label: "الإنجاز %", align: "left", pct: true },
      { key: "gap", label: "الفارق", align: "left", money: true },
    ],
    summaryLabels: { target_rows: "صفوف المستهدف", total_target_cur: "مستهدف الشهر الحالي" }, summaryMoney: ["total_target_cur"] },
  { key: "rep-commissions", title: "العمولات", desc: "آخر 90 يومًا — العمولات بحالتها (معلقة/معتمدة/مدفوعة)", group: "المندوبون",
    columns: [
      { key: "period", label: "الشهر" },
      { key: "rep", label: "المندوب" },
      { key: "invoice", label: "الفاتورة" },
      { key: "base_amount", label: "الأساس", align: "left", money: true },
      { key: "amount", label: "العمولة", align: "left", money: true },
      { key: "status", label: "الحالة" },
    ],
    summaryLabels: { count: "عدد العمولات", total: "الإجمالي", pending: "المعلقة" }, summaryMoney: ["total", "pending"] },
  { key: "rep-visits", title: "الزيارات", desc: "آخر 30 يومًا — مخططة/مكتملة/نتائج الزيارات لكل مندوب", group: "المندوبون",
    columns: [
      { key: "rep", label: "المندوب" },
      { key: "planned", label: "مخططة/أخرى", align: "left" },
      { key: "completed", label: "مكتملة", align: "left" },
      { key: "cancelled", label: "ملغاة", align: "left" },
      { key: "ordered", label: "بطلب", align: "left" },
      { key: "no_order", label: "بلا طلب", align: "left" },
      { key: "collection", label: "تحصيل", align: "left" },
      { key: "order_value", label: "قيمة الطلبات", align: "left", money: true },
    ],
    summaryLabels: { total_visits: "كل الزيارات", completed: "المكتملة", order_value: "قيمة الطلبات" }, summaryMoney: ["order_value"] },
  { key: "rep-customers", title: "تغطية العملاء", desc: "آخر 90 يومًا — كم عميلًا زار كل مندوب وكم مرة", group: "المندوبون",
    columns: [
      { key: "rep", label: "المندوب" },
      { key: "visited_customers", label: "عملاء مزارون", align: "left" },
      { key: "visits_90d", label: "زيارات 90 يوم", align: "left" },
      { key: "visits_per_customer", label: "زيارة/عميل", align: "left" },
    ],
    summaryLabels: { reps: "المندوبون", total_visits: "الزيارات" } },
  { key: "rep-returns", title: "مرتجعات المندوبين", desc: "آخر 90 يومًا — المرتجعات حسب مَن سجّلها", group: "المندوبون",
    columns: [
      { key: "rep", label: "المسجِّل" },
      { key: "returns", label: "مرتجعات", align: "left" },
      { key: "items", label: "بنود", align: "left" },
      { key: "total", label: "القيمة", align: "left", money: true },
    ],
    summaryLabels: { returns: "المرتجعات", total: "القيمة" }, summaryMoney: ["total"] },
  { key: "sales-by-customer-type", title: "المبيعات حسب نوع العميل", desc: "مسجل / متردد / كاشي / ضيف (المرحلة 28)", group: "المبيعات",
    columns: [
      { key: "label", label: "نوع العميل" },
      { key: "invoices", label: "الفواتير", align: "left" },
      { key: "total", label: "الإجمالي", align: "left" },
      { key: "paid", label: "المحصّل", align: "left" },
    ],
    summaryLabels: { total: "الإجمالي", invoice_count: "عدد الفواتير", walkin_total: "مبيعات المتردد", registered_total: "مبيعات المسجلين" },
    summaryMoney: ["total", "walkin_total", "registered_total"] },
  { key: "walkin-kpis", title: "مؤشرات الزبون المتردد", desc: "مبيعات المتردد، العمليات، معدل التحويل (المرحلة 29)", group: "المبيعات",
    columns: [
      { key: "kpi", label: "المؤشر" },
      { key: "value", label: "القيمة", align: "left" },
      { key: "unit", label: "الوحدة", align: "left" },
    ],
    summaryLabels: { walkin_sales: "مبيعات المتردد", registered_sales: "مبيعات المسجلين", conversion_rate: "معدل التحويل %" },
    summaryMoney: ["walkin_sales", "registered_sales"] },

];

const GROUP_ICONS: Record<ReportDef["group"], React.ReactNode> = {
  المبيعات: <ShoppingCart className="w-3.5 h-3.5" />,
  المخزون: <Package className="w-3.5 h-3.5" />,
  المالية: <Wallet className="w-3.5 h-3.5" />,
  المندوبون: <MapPin className="w-3.5 h-3.5" />,
  الحسابات: <BarChart3 className="w-3.5 h-3.5" />,
};

function toCsv(rows: Record<string, unknown>[]): string {
  if (!rows.length) return "";
  const headers = Object.keys(rows[0]);
  const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  return "\uFEFF" + [headers.join(","), ...rows.map((r) => headers.map((h) => esc(r[h])).join(","))].join("\n");
}

function downloadCsv(name: string, rows: Record<string, unknown>[]) {
  const blob = new Blob([toCsv(rows)], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${name}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export function ReportsTab({ canExport, canBackup }: { canExport: boolean; canBackup?: boolean }) {
  const [active, setActive] = React.useState<ReportKey>("sales-daily");
  const [group, setGroup] = React.useState<ReportDef["group"]>("المبيعات");
  const [data, setData] = React.useState<unknown>(null);
  const [loading, setLoading] = React.useState(false);
  const [backingUp, setBackingUp] = React.useState(false);
  const [customers, setCustomers] = React.useState<{ id: number; name: string }[]>([]);
  const [statementCustomerId, setStatementCustomerId] = React.useState<number>(0);

  React.useEffect(() => {
    api<{ id: number; name: string }[]>("/api/v1/customers?per_page=200").then(({ body }) => {
      if (body.success && body.data) {
        setCustomers(body.data);
        if (body.data[0]) setStatementCustomerId(body.data[0].id);
      }
    });
  }, []);

  const switchReport = (key: ReportKey) => {
    if (key === active) return;
    setData(null);
    setLoading(true);
    setActive(key);
  };

  async function downloadBackup() {
    setBackingUp(true);
    try {
      await api("/api/v1/auth/me");
      const res = await fetch("/api/v1/admin/backup", {
        headers: { Authorization: `Bearer ${getAccessToken() ?? ""}` },
      });
      if (!res.ok) {
        const j = await res.json().catch(() => null);
        toast.error(j?.message ?? `فشل النسخ الاحتياطي (${res.status})`);
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = res.headers.get("Content-Disposition")?.match(/filename="?([^"]+)"?/)?.[1] ?? "backup.json";
      a.click();
      URL.revokeObjectURL(url);
      toast.success("نُزّلت النسخة الاحتياطية الشاملة (JSON)");
    } finally {
      setBackingUp(false);
    }
  }

  const load = React.useCallback(async (key: ReportKey, customerId?: number) => {
    setLoading(true);
    setData(null);
    try {
      const qs = key === "customer-statement" && customerId ? `?customer_id=${customerId}` : "";
      const { body } = await api(`/api/v1/reports/${key}${qs}`);
      if (body.success) setData(body.data as unknown);
      else toast.error(body.message ?? "فشل تحميل التقرير");
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => { load(active); }, [active, load]);

  const asRows = (d: unknown): Record<string, unknown>[] => {
    if (Array.isArray(d)) return d as Record<string, unknown>[];
    if (d && typeof d === "object" && Array.isArray((d as { rows?: unknown[] }).rows)) {
      return (d as { rows: Record<string, unknown>[] }).rows;
    }
    return [];
  };
  const asSummary = (d: unknown): Record<string, number | string> | null =>
    d && typeof d === "object" && !Array.isArray(d) && (d as { summary?: unknown }).summary
      ? ((d as { summary: Record<string, number | string> }).summary)
      : null;

  const def = REPORTS.find((r) => r.key === active)!;
  const groupedList = REPORTS.filter((r) => r.group === group);

  function renderSummary() {
    const s = asSummary(data);
    if (!s) return null;
    const labels = def.summaryLabels ?? {};
    const moneyKeys = def.summaryMoney ?? [];
    const tones = ["blue", "cyan", "indigo", "emerald", "amber", "rose"] as const;
    const icons = [<Coins key="i0" className="w-5 h-5" />, <Boxes key="i1" className="w-5 h-5" />, <TrendingUp key="i2" className="w-5 h-5" />];
    return (
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {Object.entries(labels).map(([k, label], i) => {
          const v = s[k];
          const display = moneyKeys.includes(k) && typeof v === "number" ? formatIQD(v) : String(v ?? "—");
          return (
            <KpiCard key={k} tone={tones[i % tones.length]} icon={icons[i % icons.length]} label={label} value={display} />
          );
        })}
      </div>
    );
  }

  function renderGenericTable() {
    const rows = asRows(data);
    const cols = def.columns;
    if (!cols) return null;
    if (!rows.length) return <div className="py-8 text-center text-muted-foreground">لا بيانات لهذا التقرير بعد</div>;
    return (
      <Table>
        <TableHeader>
          <TableRow>
            {cols.map((c) => (
              <TableHead key={c.key} className={c.align === "left" ? "text-left" : ""}>{c.label}</TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((r, ri) => (
            <TableRow key={ri}>
              {cols.map((c) => {
                const v = r[c.key];
                return (
                  <TableCell key={c.key} className={`${c.align === "left" ? "text-left" : ""} ${c.money ? "font-medium" : ""} text-sm`}
                    dir={c.money || c.pct || typeof v === "number" ? "ltr" : undefined}>
                    {c.money ? formatIQD(Number(v ?? 0)) : c.pct ? `${v ?? 0}%` : String(v ?? "—")}
                  </TableCell>
                );
              })}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );
  }

  return (
    <div className="space-y-4">
      {/* group selector */}
      <div className="flex gap-2 flex-wrap items-center">
        {(Object.keys(GROUP_ICONS) as ReportDef["group"][]).map((g) => (
          <Button key={g} size="sm" variant={group === g ? "default" : "outline"} onClick={() => setGroup(g)}>
            {GROUP_ICONS[g]} {g}
            <Badge variant="secondary" className="text-[10px] ms-1">{REPORTS.filter((r) => r.group === g).length}</Badge>
          </Button>
        ))}
        {canBackup && (
          <Button size="sm" variant="outline" className="mr-auto" onClick={downloadBackup} disabled={backingUp} title="تنزيل كل بيانات الشركة JSON">
            {backingUp ? <Loader2 className="w-4 h-4 animate-spin" /> : <DatabaseBackup className="w-4 h-4" />} نسخة احتياطية شاملة
          </Button>
        )}
      </div>

      {/* reports within group */}
      <div className="flex gap-2 flex-wrap">
        {groupedList.map((r) => (
          <Button key={r.key} size="sm" variant={active === r.key ? "default" : "outline"} onClick={() => switchReport(r.key)}>
            <BarChart3 className="w-4 h-4" /> {r.title}
          </Button>
        ))}
      </div>

      {/* customer picker for statement */}
      {active === "customer-statement" && (
        <div className="flex gap-2 items-end flex-wrap">
          <div className="space-y-1">
            <label className="text-xs text-muted-foreground">العميل</label>
            <select
              className="h-9 rounded-md border bg-background px-3 text-sm min-w-56"
              value={statementCustomerId || ""}
              onChange={(e) => setStatementCustomerId(Number(e.target.value))}
            >
              {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <Button size="sm" onClick={() => load("customer-statement", statementCustomerId)} disabled={!statementCustomerId || loading}>
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <BarChart3 className="w-4 h-4" />} عرض الكشف
          </Button>
        </div>
      )}

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <CardTitle>{def.title}</CardTitle>
              <CardDescription>{def.desc}</CardDescription>
            </div>
            {canExport && data !== null ? (
              <Button
                size="sm"
                variant="outline"
                onClick={() =>
                  downloadCsv(
                    active,
                    active === "rep-performance"
                      ? ((data as { rows?: Record<string, unknown>[] }).rows ?? [])
                      : asRows(data)
                  )
                }
              >
                <Download className="w-4 h-4" /> تصدير CSV
              </Button>
            ) : null}
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="py-10 flex items-center justify-center text-muted-foreground"><Loader2 className="w-5 h-5 animate-spin" /></div>
          ) : data == null ? (
            <div className="py-10 text-center text-muted-foreground">لا بيانات</div>
          ) : active === "sales-daily" ? (
            <div className="space-y-4">
              {/* 14-day bar chart (SVG, no deps) */}
              <div className="rounded-lg border p-3">
                <div className="text-xs font-semibold text-muted-foreground mb-2">إجمالي المبيعات اليومية (د.ع) — آخر 14 يومًا</div>
                <svg viewBox="0 0 700 160" className="w-full h-40" preserveAspectRatio="none">
                  {(() => {
                    const rows = asRows(data);
                    const max = Math.max(1, ...rows.map((r) => Number(r.total)));
                    const bw = 700 / Math.max(1, rows.length);
                    return rows.map((r, i) => {
                      const h = (Number(r.total) / max) * 130;
                      const x = i * bw + bw * 0.15;
                      const w = bw * 0.7;
                      const isToday = i === rows.length - 1;
                      return (
                        <g key={String(r.date)}>
                          <rect x={x} y={140 - h} width={w} height={h} rx="2"
                            fill={isToday ? "#f97316" : "#1e3a5f"} opacity={isToday ? 1 : 0.85}>
                            <title>{`${r.date}: ${Number(r.total).toLocaleString("en-US")} د.ع (${r.count} فاتورة)`}</title>
                          </rect>
                          {Number(r.total) > 0 && (
                            <text x={x + w / 2} y={136 - h} fontSize="9" textAnchor="middle" fill="#64748b">
                              {Number(r.total) >= 1000 ? `${Math.round(Number(r.total) / 1000)}k` : Math.round(Number(r.total))}
                            </text>
                          )}
                          <text x={x + w / 2} y={152} fontSize="8" textAnchor="middle" fill="#94a3b8">
                            {String(r.date).slice(5)}
                          </text>
                        </g>
                      );
                    });
                  })()}
                </svg>
              </div>
              <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>اليوم</TableHead>
                  <TableHead className="text-left">عدد الفواتير</TableHead>
                  <TableHead className="text-left">نقدي</TableHead>
                  <TableHead className="text-left">آجل</TableHead>
                  <TableHead className="text-left">الإجمالي</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {asRows(data).map((r) => (
                  <TableRow key={String(r.date)}>
                    <TableCell dir="ltr" className="font-mono text-xs">{String(r.date)}</TableCell>
                    <TableCell className="text-left">{String(r.count)}</TableCell>
                    <TableCell className="text-left" dir="ltr">{formatIQD(Number(r.cash))}</TableCell>
                    <TableCell className="text-left" dir="ltr">{formatIQD(Number(r.credit))}</TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(Number(r.total))}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            </div>
          ) : active === "rep-performance" ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>المندوب</TableHead>
                  <TableHead className="text-left">الفواتير</TableHead>
                  <TableHead className="text-left">المبيعات</TableHead>
                  <TableHead className="text-left">زيارات مكتملة</TableHead>
                  <TableHead className="text-left">تحصيلات</TableHead>
                  <TableHead className="text-left">عمولات مولّدة</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(Array.isArray((data as { rows?: Record<string, unknown>[] }).rows)
                  ? (data as { rows: Record<string, unknown>[] }).rows
                  : []
                ).map((r) => (
                  <TableRow key={String(r.rep_id)}>
                    <TableCell className="text-sm font-medium">{String(r.name)} <span className="text-[10px] text-muted-foreground" dir="ltr">@{String(r.username)}</span></TableCell>
                    <TableCell className="text-left" dir="ltr">{String(r.invoices_count)}</TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(Number(r.sales_total))}</TableCell>
                    <TableCell className="text-left" dir="ltr">{String(r.completed_visits)}</TableCell>
                    <TableCell className="text-left" dir="ltr">{formatIQD(Number(r.collected_total))}</TableCell>
                    <TableCell className="text-left" dir="ltr">{formatIQD(Number(r.commissions_total))}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : active === "top-products" ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>#</TableHead>
                  <TableHead>المنتج</TableHead>
                  <TableHead className="text-left">الكمية المبيعة</TableHead>
                  <TableHead className="text-left">الإيراد</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {asRows(data).map((r, i) => (
                  <TableRow key={String(r.product_id)}>
                    <TableCell>{i + 1}</TableCell>
                    <TableCell className="text-sm font-medium">{String(r.name)}</TableCell>
                    <TableCell className="text-left" dir="ltr">{String(r.qty)} {String(r.unit)}</TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(Number(r.revenue))}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : active === "aging" ? (
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-4">
                {(data as { buckets: { label: string; total: number; count: number }[] }).buckets.map((b) => (
                  <div key={b.label} className="rounded-lg border p-3">
                    <div className="text-xs text-muted-foreground">{b.label}</div>
                    <div className="text-lg font-bold" dir="ltr">{formatIQD(b.total)}</div>
                    <div className="text-[11px] text-muted-foreground">{b.count} فاتورة</div>
                  </div>
                ))}
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>كود العميل</TableHead>
                    <TableHead>الاسم</TableHead>
                    <TableHead className="text-left">إجمالي المستحق</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(data as { top_customers: { code: string; name: string; total: number }[] }).top_customers.map((c) => (
                    <TableRow key={c.code}>
                      <TableCell className="font-mono text-xs" dir="ltr">{c.code}</TableCell>
                      <TableCell className="text-sm">{c.name}</TableCell>
                      <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(c.total)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : active === "valuation" ? (
            <div className="space-y-4">
              {asSummary(data) && (
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  <KpiCard tone="blue" icon={<Boxes className="w-5 h-5" />} label="إجمالي الكمية" value={String(Number(asSummary(data)!.total_qty))} />
                  <KpiCard tone="cyan" icon={<Coins className="w-5 h-5" />} label="قيمة التكلفة" value={formatIQD(Number(asSummary(data)!.cost_value))} />
                  <KpiCard tone="indigo" icon={<Coins className="w-5 h-5" />} label="القيمة البيعية" value={formatIQD(Number(asSummary(data)!.sale_value))} />
                  <KpiCard tone="emerald" icon={<TrendingUp className="w-5 h-5" />} label="الربح المتوقع" value={formatIQD(Number(asSummary(data)!.expected_profit))} />
                </div>
              )}
              <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>المستودع</TableHead>
                  <TableHead className="text-left">الأصناف</TableHead>
                  <TableHead className="text-left">تحت الحد</TableHead>
                  <TableHead className="text-left">قيمة بالتكلفة</TableHead>
                  <TableHead className="text-left">قيمة بالبيع</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {asRows(data).map((r) => (
                  <TableRow key={String(r.code)}>
                    <TableCell className="text-sm font-medium">{String(r.warehouse)}</TableCell>
                    <TableCell className="text-left">{String(r.items)}</TableCell>
                    <TableCell className="text-left">{Number(r.low) > 0 ? <Badge variant="secondary" className="text-[10px]">{String(r.low)}</Badge> : "0"}</TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(Number(r.cost_value))}</TableCell>
                    <TableCell className="text-left" dir="ltr">{formatIQD(Number(r.sale_value))}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            </div>
          ) : active === "profit" ? (
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-4">
                <div className="rounded-lg border p-3"><div className="text-xs text-muted-foreground">الإيراد</div><div className="text-lg font-bold" dir="ltr">{formatIQD(Number((data as { revenue: number }).revenue))}</div></div>
                <div className="rounded-lg border p-3"><div className="text-xs text-muted-foreground">التكلفة</div><div className="text-lg font-bold" dir="ltr">{formatIQD(Number((data as { cost: number }).cost))}</div></div>
                <div className="rounded-lg border p-3"><div className="text-xs text-muted-foreground">الربح الإجمالي</div><div className="text-lg font-bold text-green-600" dir="ltr">{formatIQD(Number((data as { gross_profit: number }).gross_profit))}</div></div>
                <div className="rounded-lg border p-3"><div className="text-xs text-muted-foreground">هامش الربح</div><div className="text-lg font-bold" dir="ltr">{String((data as { margin_pct: number }).margin_pct)}%</div></div>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المنتج</TableHead>
                    <TableHead className="text-left">الكمية</TableHead>
                    <TableHead className="text-left">الإيراد</TableHead>
                    <TableHead className="text-left">التكلفة</TableHead>
                    <TableHead className="text-left">الربح</TableHead>
                    <TableHead className="text-left">الهامش</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(data as { products: { name: string; qty: number; revenue: number; cost: number; profit: number; margin_pct: number }[] }).products.map((p) => (
                    <TableRow key={p.name}>
                      <TableCell className="text-sm">{p.name}</TableCell>
                      <TableCell className="text-left" dir="ltr">{p.qty}</TableCell>
                      <TableCell className="text-left" dir="ltr">{formatIQD(p.revenue)}</TableCell>
                      <TableCell className="text-left" dir="ltr">{formatIQD(p.cost)}</TableCell>
                      <TableCell className="text-left font-semibold text-green-600" dir="ltr">{formatIQD(p.profit)}</TableCell>
                      <TableCell className="text-left" dir="ltr">{p.margin_pct}%</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : active === "customer-statement" ? (
            (() => {
              const d = data as {
                customer: { code: string; name: string; balance: number };
                rows: { date: string; kind: string; ref: string; description: string; debit: number; credit: number; running: number }[];
                totals: { debit: number; credit: number };
                closing_balance: number;
              };
              if (!d?.rows) return <div className="py-8 text-center text-muted-foreground">اختر عميلًا واضغط «عرض الكشف»</div>;
              const kindAr: Record<string, string> = {
                INVOICE: "فاتورة", RETURN: "مرتجع", COLLECTION: "تحصيل", PAYMENT: "سداد", LOYALTY: "ولاء",
              };
              return (
                <div className="space-y-4">
                  <div className="grid gap-3 sm:grid-cols-3">
                    <div className="rounded-lg border p-3"><div className="text-xs text-muted-foreground">إجمالي مدين</div><div className="text-lg font-bold" dir="ltr">{formatIQD(d.totals.debit)}</div></div>
                    <div className="rounded-lg border p-3"><div className="text-xs text-muted-foreground">إجمالي دائن</div><div className="text-lg font-bold" dir="ltr">{formatIQD(d.totals.credit)}</div></div>
                    <div className="rounded-lg border p-3"><div className="text-xs text-muted-foreground">الرصيد الختامي</div><div className="text-lg font-bold" dir="ltr">{formatIQD(d.closing_balance)}</div></div>
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>التاريخ</TableHead>
                        <TableHead>النوع</TableHead>
                        <TableHead>المرجع</TableHead>
                        <TableHead>الوصف</TableHead>
                        <TableHead className="text-left">مدين</TableHead>
                        <TableHead className="text-left">دائن</TableHead>
                        <TableHead className="text-left">الرصيد</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {d.rows.map((r, i) => (
                        <TableRow key={i}>
                          <TableCell className="font-mono text-xs" dir="ltr">{r.date}</TableCell>
                          <TableCell><Badge variant="secondary" className="text-[10px]">{kindAr[r.kind] ?? r.kind}</Badge></TableCell>
                          <TableCell className="font-mono text-xs" dir="ltr">{r.ref}</TableCell>
                          <TableCell className="text-sm">{r.description}</TableCell>
                          <TableCell className="text-left" dir="ltr">{r.debit ? formatIQD(r.debit) : "—"}</TableCell>
                          <TableCell className="text-left" dir="ltr">{r.credit ? formatIQD(r.credit) : "—"}</TableCell>
                          <TableCell className="text-left font-semibold" dir="ltr">{formatIQD(r.running)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              );
            })()
          ) : (
            /* generic rows+summary renderer for the 22 new reports */
            <div className="space-y-4">
              {renderSummary()}
              {renderGenericTable()}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
