"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { formatDateTime } from "@/lib/utils";
import { Truck, Loader2, PackageCheck, Ban, RefreshCw, FileText, Eye, ArrowLeftCircle } from "lucide-react";

interface Customer { id: number; code: string; name: string }
interface Product { id: number; code: string; name: string; unit: string }
interface OrderRow { id: number; number: string; customer: { name: string } }
interface InvoiceRow { id: number; number: string; customer?: { name: string } | null }

interface ProgressLine {
  line_id: number;
  product: { id: number; code: string; name: string; unit: string };
  ordered_qty: number;
  delivered_qty: number;
  pending_qty: number;
  remaining_qty: number;
}
interface OrderProgress {
  order: { id: number; number: string; status: string };
  delivery_status: string;
  lines: ProgressLine[];
  notes: { id: number; number: string; status: string; deliveredAt: string | null }[];
}

interface DeliveryLine {
  id: number;
  product: { id: number; code: string; name: string; unit: string; packUnit: string | null };
  ordered_qty: number;
  previously_delivered_qty: number;
  current_delivered_qty: number;
  remaining_qty: number;
  deliverable_qty: number;
  package_qty: number;
  loose_qty: number;
}
interface DeliveryDetail {
  id: number;
  number: string;
  status: string;
  sales_order?: { id: number; number: string; status: string } | null;
  invoice?: { id: number; number: string } | null;
  received_by: string | null;
  delivered_by: string | null;
  cancelled_by: string | null;
  delivered_at: string | null;
  cancelled_at: string | null;
  lines: DeliveryLine[];
}

interface DeliveryRow {
  id: number;
  number: string;
  status: "PENDING" | "PARTIAL" | "DELIVERED" | "CANCELLED";
  customer: { code: string; name: string; phone: string | null };
  invoice: string | null;
  sales_order: string | null;
  lines_count: number;
  warehouse: { code: string; name: string };
  ship_date: string;
  delivered_at: string | null;
  driver: string | null;
  driver_phone: string | null;
  address: string | null;
  received_by: string | null;
  notes: string | null;
  created_by: string;
}

const STATUS_AR: Record<string, { label: string; variant: "secondary" | "default" | "success" | "destructive" | "accent" }> = {
  PENDING: { label: "قيد التوصيل", variant: "secondary" },
  PARTIAL: { label: "تسليم جزئي", variant: "accent" },
  DELIVERED: { label: "مسلَّم", variant: "success" },
  CANCELLED: { label: "ملغى", variant: "destructive" },
};

const DELIVERY_STATUS_AR: Record<string, string> = {
  PENDING: "لم يبدأ التسليم",
  PARTIAL: "تسليم جزئي جارٍ",
  DELIVERED: "مكتمل التسليم",
};

export function DeliveryTab({
  warehouses,
  canCreate,
  canEdit,
}: {
  warehouses: { id: number; code: string; name: string }[];
  canCreate: boolean;
  canEdit: boolean;
}) {
  const [customers, setCustomers] = React.useState<Customer[]>([]);
  const [products, setProducts] = React.useState<Product[]>([]);
  const [orders, setOrders] = React.useState<OrderRow[]>([]);
  const [invoices, setInvoices] = React.useState<InvoiceRow[]>([]);
  const [rows, setRows] = React.useState<DeliveryRow[] | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [statusFilter, setStatusFilter] = React.useState<string>("");

  // إنشاء — المصدر
  const [source, setSource] = React.useState<"order" | "invoice" | "standalone">("order");
  const [progress, setProgress] = React.useState<OrderProgress | null>(null);
  const [lineQtys, setLineQtys] = React.useState<Record<number, string>>({});
  // إنشاء — مستقل
  const [stProductId, setStProductId] = React.useState<string>("");
  const [stQty, setStQty] = React.useState<string>("");
  const [stLines, setStLines] = React.useState<{ product_id: number; name: string; qty: number }[]>([]);

  // لوحات العرض
  const [detail, setDetail] = React.useState<DeliveryDetail | null>(null);
  const [deliverPanel, setDeliverPanel] = React.useState<DeliveryDetail | null>(null);
  const [deliverQtys, setDeliverQtys] = React.useState<Record<number, string>>({});
  const [receivedBy, setReceivedBy] = React.useState<string>("");

  const load = React.useCallback(async () => {
    const [c, p, o, i, r] = await Promise.all([
      api<Customer[]>("/api/v1/customers?per_page=200"),
      api<Product[]>("/api/v1/products?per_page=200"),
      api<OrderRow[]>("/api/v1/sales/orders?status=CONFIRMED&per_page=100"),
      api<InvoiceRow[]>("/api/v1/sales/invoices?per_page=50"),
      api<DeliveryRow[]>(`/api/v1/sales/delivery-notes?per_page=30${statusFilter ? `&status=${statusFilter}` : ""}`),
    ]);
    if (c.body.success && c.body.data) setCustomers(c.body.data);
    if (p.body.success && p.body.data) setProducts(p.body.data);
    if (o.body.success && o.body.data) setOrders(o.body.data);
    if (i.body.success && i.body.data) setInvoices(i.body.data);
    if (r.body.success && r.body.data) setRows(r.body.data);
  }, [statusFilter]);

  React.useEffect(() => { load(); }, [load]);

  async function pickOrder(orderId: string) {
    setProgress(null);
    setLineQtys({});
    if (!orderId) return;
    const { body } = await api<OrderProgress>(`/api/v1/sales/orders/${orderId}/delivery-progress`);
    if (body.success && body.data) {
      setProgress(body.data);
      const qtys: Record<number, string> = {};
      for (const l of body.data.lines) qtys[l.line_id] = String(l.remaining_qty);
      setLineQtys(qtys);
    } else toast.error(body.message ?? "فشل تحميل تقدم الأمر");
  }

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    const fd = new FormData(e.currentTarget);
    try {
      let payload: Record<string, unknown> | null = null;
      if (source === "order") {
        if (!progress) { toast.error("اختر أمر البيع"); return; }
        const lines = progress.lines
          .map((l) => ({ sales_order_line_id: l.line_id, qty: Number(lineQtys[l.line_id] ?? 0) }))
          .filter((l) => l.qty > 0);
        if (!lines.length) { toast.error("أدخل كمية تسليم لبند واحد على الأقل"); return; }
        payload = {
          order_id: progress.order.id,
          driver: fd.get("driver") || undefined,
          driver_phone: fd.get("driver_phone") || undefined,
          address: fd.get("address") || undefined,
          notes: fd.get("notes") || undefined,
          lines,
        };
      } else if (source === "invoice") {
        const invoiceId = Number(fd.get("invoice_id") || 0);
        if (!invoiceId) { toast.error("اختر الفاتورة"); return; }
        payload = {
          customer_id: Number(fd.get("customer_id") || 0) || undefined,
          invoice_id: invoiceId,
          driver: fd.get("driver") || undefined,
          driver_phone: fd.get("driver_phone") || undefined,
          address: fd.get("address") || undefined,
          notes: fd.get("notes") || undefined,
        };
      } else {
        const customerId = Number(fd.get("customer_id") || 0);
        if (!customerId) { toast.error("اختر العميل"); return; }
        if (!stLines.length) { toast.error("أضف بند تسليم واحد على الأقل"); return; }
        payload = {
          customer_id: customerId,
          warehouse_id: Number(fd.get("warehouse_id") || 0) || undefined,
          lines: stLines.map((l) => ({ product_id: l.product_id, qty: l.qty })),
          driver: fd.get("driver") || undefined,
          driver_phone: fd.get("driver_phone") || undefined,
          address: fd.get("address") || undefined,
          notes: fd.get("notes") || undefined,
        };
      }
      const { body } = await api("/api/v1/sales/delivery-notes", {
        method: "POST",
        body: JSON.stringify(payload),
      });
      if (body.success) {
        const d = body.data as { number: string; lines_count: number };
        toast.success(`أُنشئ إشعار التسليم ${d.number} — ${d.lines_count} بند (PENDING — لا يخصم المخزون)`);
        setProgress(null); setLineQtys({}); setStLines([]);
        (e.target as HTMLFormElement).reset();
        await load();
      } else toast.error(body.message ?? "فشل الإنشاء");
    } finally {
      setBusy(false);
    }
  }

  function addStandaloneLine() {
    const pid = Number(stProductId || 0);
    const qty = Number(stQty || 0);
    const p = products.find((x) => x.id === pid);
    if (!p) { toast.error("اختر المنتج"); return; }
    if (!(qty > 0)) { toast.error("أدخل الكمية"); return; }
    setStLines((prev) => [...prev, { product_id: pid, name: `${p.code} — ${p.name}`, qty }]);
    setStProductId(""); setStQty("");
  }

  async function openDetail(id: number) {
    const { body } = await api<DeliveryDetail>(`/api/v1/sales/delivery-notes/${id}`);
    if (body.success && body.data) setDetail(body.data);
    else toast.error(body.message ?? "فشل التحميل");
  }

  async function openDeliver(id: number) {
    const { body } = await api<DeliveryDetail>(`/api/v1/sales/delivery-notes/${id}`);
    if (body.success && body.data) {
      setDeliverPanel(body.data);
      const qtys: Record<number, string> = {};
      for (const l of body.data.lines) qtys[l.id] = String(l.current_delivered_qty);
      setDeliverQtys(qtys);
      setReceivedBy(body.data.received_by ?? "");
    } else toast.error(body.message ?? "فشل التحميل");
  }

  async function confirmDeliver() {
    if (!deliverPanel) return;
    setBusy(true);
    try {
      const lines = deliverPanel.lines.map((l) => ({ line_id: l.id, qty: Number(deliverQtys[l.id] ?? 0) }));
      const { body } = await api(`/api/v1/sales/delivery-notes/${deliverPanel.id}`, {
        method: "PATCH",
        body: JSON.stringify({ action: "deliver", received_by: receivedBy || undefined, lines }),
      });
      if (body.success) {
        const st = (body.data as { status: string }).status;
        toast.success(st === "DELIVERED" ? "سُجّل التسليم الكامل" : "سُجّل التسليم الجزئي — بقي متبقٍ على المصدر");
        setDeliverPanel(null);
        await load();
      } else toast.error(body.message ?? "فشل التسليم");
    } finally {
      setBusy(false);
    }
  }

  async function convertToInvoice(id: number) {
    const t = window.prompt("نوع الفاتورة عند التحويل — اكتب CASH للنقدي أو CREDIT للآجل:", "CASH");
    if (t === null) return;
    const type = t.trim().toUpperCase() === "CREDIT" ? "CREDIT" : "CASH";
    setBusy(true);
    try {
      const { body } = await api(`/api/v1/sales/delivery-notes/${id}/convert`, {
        method: "POST",
        body: JSON.stringify({ type }),
      });
      if (body.success) {
        const r = body.data as { invoice_number: string; order_status: string };
        toast.success(`أُصدرت الفاتورة ${r.invoice_number} — حالة الأمر: ${r.order_status}`);
        await load();
      } else toast.error(body.message ?? "فشل التحويل");
    } finally {
      setBusy(false);
    }
  }

  async function act(id: number, action: "cancel") {
    setBusy(true);
    try {
      const { body } = await api(`/api/v1/sales/delivery-notes/${id}`, {
        method: "PATCH",
        body: JSON.stringify({ action }),
      });
      if (body.success) {
        toast.success("أُلغي الإشعار — الكميات عادت للمتبقي");
        await load();
      } else toast.error(body.message ?? "فشلت العملية");
    } finally {
      setBusy(false);
    }
  }

  const orderBackedDelivered = (r: DeliveryRow) =>
    r.sales_order && (r.status === "DELIVERED" || r.status === "PARTIAL");

  return (
    <div className="space-y-4">
      {canCreate && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base"><Truck className="w-4 h-4" /> إشعار تسليم جديد</CardTitle>
            <CardDescription>
              السلسلة: أمر بيع → إشعار تسليم → فاتورة · تسليم جزئي مدعوم — الإشعار لا يخصم المخزون (الفاتورة تخصم)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={submit} className="space-y-3">
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground">المصدر</label>
                  <select
                    className="h-9 w-full rounded-md border bg-background px-3 text-sm"
                    value={source}
                    onChange={(e) => { setSource(e.target.value as typeof source); setProgress(null); setLineQtys({}); }}
                  >
                    <option value="order">من أمر بيع (تسليم جزئي)</option>
                    <option value="invoice">من فاتورة صادرة (لوجستي)</option>
                    <option value="standalone">مستقل ببنود يدوية</option>
                  </select>
                </div>

                {source === "order" && (
                  <div className="space-y-1">
                    <label className="text-xs text-muted-foreground">أمر البيع المؤكد *</label>
                    <select className="h-9 w-full rounded-md border bg-background px-3 text-sm" defaultValue="" onChange={(e) => pickOrder(e.target.value)}>
                      <option value="">— اختر الأمر —</option>
                      {orders.map((o) => <option key={o.id} value={o.id}>{o.number} — {o.customer.name}</option>)}
                    </select>
                  </div>
                )}

                {source === "invoice" && (
                  <>
                    <div className="space-y-1">
                      <label className="text-xs text-muted-foreground">العميل *</label>
                      <select name="customer_id" className="h-9 w-full rounded-md border bg-background px-3 text-sm" defaultValue={customers[0]?.id ?? ""}>
                        {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs text-muted-foreground">الفاتورة المرجعية *</label>
                      <select name="invoice_id" className="h-9 w-full rounded-md border bg-background px-3 text-sm" defaultValue="">
                        <option value="">— اختر الفاتورة —</option>
                        {invoices.map((i) => <option key={i.id} value={i.id}>{i.number} — {i.customer?.name ?? ""}</option>)}
                      </select>
                    </div>
                  </>
                )}

                {source === "standalone" && (
                  <>
                    <div className="space-y-1">
                      <label className="text-xs text-muted-foreground">العميل *</label>
                      <select name="customer_id" className="h-9 w-full rounded-md border bg-background px-3 text-sm" defaultValue={customers[0]?.id ?? ""}>
                        {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                    </div>
                    {warehouses.length > 0 && (
                      <div className="space-y-1">
                        <label className="text-xs text-muted-foreground">المستودع</label>
                        <select name="warehouse_id" className="h-9 w-full rounded-md border bg-background px-3 text-sm" defaultValue={warehouses[0]?.id ?? ""}>
                          {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
                        </select>
                      </div>
                    )}
                  </>
                )}

                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground">السائق</label>
                  <Input name="driver" className="h-9" placeholder="اسم السائق" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground">هاتف السائق</label>
                  <Input name="driver_phone" className="h-9" dir="ltr" placeholder="+9647xx" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground">عنوان التسليم</label>
                  <Input name="address" className="h-9" placeholder="المدينة — المنطقة" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground">ملاحظات</label>
                  <Input name="notes" className="h-9" placeholder="اختياري" />
                </div>
              </div>

              {source === "order" && progress && (
                <div className="rounded-md border p-3">
                  <div className="mb-2 flex items-center justify-between text-xs">
                    <span className="font-medium">بنود الأمر {progress.order.number} — {DELIVERY_STATUS_AR[progress.delivery_status] ?? progress.delivery_status}</span>
                    <span className="text-muted-foreground">اترك 0 لتخطي البند — منع over-delivery مفروض</span>
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>المنتج</TableHead>
                        <TableHead className="text-left">المطلوب</TableHead>
                        <TableHead className="text-left">المسلَّم سابقاً</TableHead>
                        <TableHead className="text-left">قيد الإشعارات المعلقة</TableHead>
                        <TableHead className="text-left">المتبقي</TableHead>
                        <TableHead className="text-left">كمية هذا الإشعار</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {progress.lines.map((l) => (
                        <TableRow key={l.line_id}>
                          <TableCell className="text-sm">{l.product.name} <span className="text-[10px] text-muted-foreground">({l.product.unit})</span></TableCell>
                          <TableCell className="text-left text-sm" dir="ltr">{l.ordered_qty}</TableCell>
                          <TableCell className="text-left text-sm" dir="ltr">{l.delivered_qty}</TableCell>
                          <TableCell className="text-left text-sm text-muted-foreground" dir="ltr">{l.pending_qty}</TableCell>
                          <TableCell className="text-left text-sm font-medium" dir="ltr">{l.remaining_qty}</TableCell>
                          <TableCell className="text-left">
                            <Input
                              type="number" min={0} max={l.remaining_qty} step="any"
                              className="h-8 w-24 text-left" dir="ltr"
                              value={lineQtys[l.line_id] ?? ""}
                              disabled={l.remaining_qty <= 0}
                              onChange={(e) => setLineQtys((prev) => ({ ...prev, [l.line_id]: e.target.value }))}
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              {source === "standalone" && (
                <div className="rounded-md border p-3 space-y-2">
                  <div className="flex flex-wrap gap-2 items-end">
                    <div className="space-y-1 min-w-48 flex-1">
                      <label className="text-xs text-muted-foreground">المنتج</label>
                      <select className="h-9 w-full rounded-md border bg-background px-3 text-sm" value={stProductId} onChange={(e) => setStProductId(e.target.value)}>
                        <option value="">— اختر المنتج —</option>
                        {products.map((p) => <option key={p.id} value={p.id}>{p.code} — {p.name}</option>)}
                      </select>
                    </div>
                    <div className="space-y-1 w-28">
                      <label className="text-xs text-muted-foreground">الكمية (حبات)</label>
                      <Input type="number" min={0} step="any" className="h-9" dir="ltr" value={stQty} onChange={(e) => setStQty(e.target.value)} />
                    </div>
                    <Button type="button" size="sm" variant="secondary" onClick={addStandaloneLine}>إضافة بند</Button>
                  </div>
                  {stLines.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {stLines.map((l, idx) => (
                        <Badge key={idx} variant="secondary" className="text-[11px]">
                          {l.name} × {l.qty}
                          <button type="button" className="mr-1 text-red-500" onClick={() => setStLines((prev) => prev.filter((_, i) => i !== idx))}>✕</button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              )}

              <Button type="submit" size="sm" disabled={busy}>
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Truck className="w-4 h-4" />} إنشاء الإشعار
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      {deliverPanel && (
        <Card className="border-green-600/40">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base text-green-700 dark:text-green-400">
              <PackageCheck className="w-4 h-4" /> تسجيل تسليم {deliverPanel.number}
            </CardTitle>
            <CardDescription>عدّل الكميات الفعلية المسلَّمة (أقل من المخطط = تسليم جزئي) — لا يخصم المخزون</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>المنتج</TableHead>
                  <TableHead className="text-left">المطلوب</TableHead>
                  <TableHead className="text-left">المخطط لهذا الإشعار</TableHead>
                  <TableHead className="text-left">المسلَّم فعلياً</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {deliverPanel.lines.map((l) => (
                  <TableRow key={l.id}>
                    <TableCell className="text-sm">{l.product.name}</TableCell>
                    <TableCell className="text-left text-sm" dir="ltr">{l.ordered_qty}</TableCell>
                    <TableCell className="text-left text-sm" dir="ltr">{l.current_delivered_qty}</TableCell>
                    <TableCell className="text-left">
                      <Input
                        type="number" min={0} max={l.current_delivered_qty} step="any"
                        className="h-8 w-24 text-left" dir="ltr"
                        value={deliverQtys[l.id] ?? ""}
                        onChange={(e) => setDeliverQtys((prev) => ({ ...prev, [l.id]: e.target.value }))}
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <div className="flex flex-wrap gap-2 items-end">
              <div className="space-y-1 w-56">
                <label className="text-xs text-muted-foreground">اسم المستلِم</label>
                <Input className="h-9" value={receivedBy} onChange={(e) => setReceivedBy(e.target.value)} placeholder="من استلم البضاعة" />
              </div>
              <Button size="sm" onClick={confirmDeliver} disabled={busy}>
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <PackageCheck className="w-4 h-4" />} تأكيد التسليم
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setDeliverPanel(null)}>إلغاء</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {detail && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base"><Eye className="w-4 h-4" /> تفاصيل {detail.number}</CardTitle>
            <CardDescription>
              {detail.sales_order ? `أمر بيع: ${detail.sales_order.number}` : detail.invoice ? `فاتورة: ${detail.invoice.number}` : "مستقل"} · استلمها: {detail.received_by ?? "—"} · سجّلها: {detail.delivered_by ?? detail.cancelled_by ?? "—"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>المنتج</TableHead>
                  <TableHead className="text-left">المطلوب</TableHead>
                  <TableHead className="text-left">مسلَّم سابقاً</TableHead>
                  <TableHead className="text-left">مسلَّم الآن</TableHead>
                  <TableHead className="text-left">المتبقي</TableHead>
                  <TableHead>التعبئة</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {detail.lines.map((l) => (
                  <TableRow key={l.id}>
                    <TableCell className="text-sm">{l.product.name}</TableCell>
                    <TableCell className="text-left text-sm" dir="ltr">{l.ordered_qty}</TableCell>
                    <TableCell className="text-left text-sm" dir="ltr">{l.previously_delivered_qty}</TableCell>
                    <TableCell className="text-left text-sm font-medium" dir="ltr">{l.current_delivered_qty}</TableCell>
                    <TableCell className="text-left text-sm" dir="ltr">{l.remaining_qty}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {l.package_qty > 0 ? `${l.package_qty} عبوة كاملة + ` : ""}{l.loose_qty} {l.product.unit}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <Button size="sm" variant="ghost" className="mt-2" onClick={() => setDetail(null)}>إغلاق</Button>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <CardTitle className="text-base">إشعارات التسليم</CardTitle>
            <div className="flex gap-2 items-center">
              <select
                className="h-8 rounded-md border bg-background px-2 text-xs"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="">الكل</option>
                <option value="PENDING">قيد التوصيل</option>
                <option value="PARTIAL">تسليم جزئي</option>
                <option value="DELIVERED">مسلَّم</option>
                <option value="CANCELLED">ملغى</option>
              </select>
              <Button size="sm" variant="ghost" onClick={load}><RefreshCw className="w-4 h-4" /></Button>
            </div>
          </div>
          <CardDescription>{warehouses.length ? "" : ""}</CardDescription>
        </CardHeader>
        <CardContent>
          {rows == null ? (
            <div className="py-8 text-center text-muted-foreground"><Loader2 className="w-5 h-5 animate-spin inline" /></div>
          ) : rows.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">لا إشعارات — أنشئ إشعارًا جديدًا</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الرقم</TableHead>
                  <TableHead>العميل</TableHead>
                  <TableHead>المصدر</TableHead>
                  <TableHead className="text-left">البنود</TableHead>
                  <TableHead className="text-left">الحالة</TableHead>
                  <TableHead>السائق</TableHead>
                  <TableHead className="text-left">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-mono text-xs" dir="ltr">{r.number}</TableCell>
                    <TableCell className="text-sm">
                      {r.customer.name}
                      {r.customer.phone && <span className="block text-[10px] text-muted-foreground" dir="ltr">{r.customer.phone}</span>}
                    </TableCell>
                    <TableCell className="font-mono text-xs" dir="ltr">
                      {r.sales_order ? <span className="flex items-center gap-1"><FileText className="w-3 h-3" />{r.sales_order}</span>
                        : r.invoice ?? "—"}
                    </TableCell>
                    <TableCell className="text-left text-sm" dir="ltr">{r.lines_count}</TableCell>
                    <TableCell className="text-left"><Badge variant={STATUS_AR[r.status]?.variant ?? "secondary"} className="text-[10px]">{STATUS_AR[r.status]?.label ?? r.status}</Badge></TableCell>
                    <TableCell className="text-sm">{r.driver ?? "—"}{r.address && <span className="block text-[10px] text-muted-foreground">{r.address}</span>}</TableCell>
                    <TableCell className="text-left">
                      <div className="flex gap-1 flex-wrap">
                        <Button size="icon" variant="ghost" className="h-7 w-7" title="تفاصيل" onClick={() => openDetail(r.id)} disabled={busy}>
                          <Eye className="w-4 h-4" />
                        </Button>
                        {r.status === "PENDING" && canEdit && (
                          <>
                            <Button size="icon" variant="ghost" className="h-7 w-7" title="تسجيل تسليم (جزئي أو كامل)" onClick={() => openDeliver(r.id)} disabled={busy}>
                              <PackageCheck className="w-4 h-4 text-green-600" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7" title="إلغاء" onClick={() => act(r.id, "cancel")} disabled={busy}>
                              <Ban className="w-4 h-4 text-red-500" />
                            </Button>
                          </>
                        )}
                        {orderBackedDelivered(r) && canEdit && (
                          <Button size="icon" variant="ghost" className="h-7 w-7" title="تحويل إلى فاتورة بالكميات المسلَّمة" onClick={() => convertToInvoice(r.id)} disabled={busy}>
                            <ArrowLeftCircle className="w-4 h-4 text-amber-600" />
                          </Button>
                        )}
                        {(r.status === "DELIVERED" || r.status === "PARTIAL") && (
                          <span className="text-[11px] text-muted-foreground">استلمها: {r.received_by ?? "—"}</span>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
