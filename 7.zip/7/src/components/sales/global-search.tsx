"use client";

import * as React from "react";
import { api } from "@/lib/client-api";
import { Search, CornerDownLeft, Loader2 } from "lucide-react";

interface Hit {
  type: string;
  id: number;
  label: string;
  sublabel: string;
  tab: string;
}
interface Group {
  type: string;
  title: string;
  hits: Hit[];
}
interface SearchData {
  query: string;
  groups: Group[];
  total: number;
  hint?: string;
}

const TYPE_ICON: Record<string, string> = {
  product: "📦",
  customer: "🧑‍💼",
  invoice: "🧾",
  order: "📋",
  supplier: "🚚",
  b2b: "🌐",
};

/**
 * GlobalSearch — بحث شامل في الهيدر (Development pack 2).
 * بحث واحد يجيب من كل ما يملكه المستخدم صلاحية رؤيته: منتجات، عملاء،
 * فواتير، أوامر بيع، موردون، طلبات B2B — مع تنقّل مباشر للتبويب.
 */
export function GlobalSearch({ onOpenTab }: { onOpenTab: (tab: string) => void }) {
  const [q, setQ] = React.useState("");
  const [data, setData] = React.useState<SearchData | null>(null);
  const [open, setOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const boxRef = React.useRef<HTMLDivElement>(null);
  const timerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  // إغلاق عند النقر خارج الصندوق
  React.useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  // بحث مؤجَّل (debounce 250ms) — يبدأ من حرفين
  React.useEffect(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    if (q.trim().length < 2) {
      setData(null);
      return;
    }
    setLoading(true);
    timerRef.current = setTimeout(async () => {
      try {
        const { body } = await api<SearchData>(`/api/v1/search?q=${encodeURIComponent(q.trim())}`);
        if (body.success && body.data) {
          setData(body.data);
          setOpen(true);
        }
      } finally {
        setLoading(false);
      }
    }, 250);
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [q]);

  function go(hit: Hit) {
    onOpenTab(hit.tab);
    setOpen(false);
    setQ("");
  }

  function onKey(e: React.KeyboardEvent) {
    if (e.key === "Escape") setOpen(false);
    if (e.key === "Enter" && data?.groups.length) {
      const first = data.groups[0].hits[0];
      if (first) go(first);
    }
  }

  return (
    <div ref={boxRef} className="relative">
      <Search className="w-4 h-4 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-300 pointer-events-none" />
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        onFocus={() => data && setOpen(true)}
        onKeyDown={onKey}
        placeholder="بحث شامل: منتج · عميل · فاتورة..."
        className="h-9 w-44 sm:w-56 rounded-md bg-white/10 border border-white/20 text-sm text-white placeholder:text-slate-300 pr-8 pl-2 outline-none focus:bg-white/15 focus:border-white/40 transition"
      />
      {loading && <Loader2 className="w-3.5 h-3.5 absolute left-2 top-1/2 -translate-y-1/2 text-slate-300 animate-spin" />}

      {open && data && (
        <div className="absolute top-11 right-0 w-[min(92vw,420px)] max-h-[70vh] overflow-y-auto rounded-lg border bg-background shadow-2xl z-50" dir="rtl">
          {data.groups.length === 0 ? (
            <div className="p-4 text-center text-sm text-muted-foreground">
              {q.trim().length < 2 ? "اكتب حرفين على الأقل" : `لا نتائج مطابقة لـ «${data.query}»`}
            </div>
          ) : (
            <>
              {data.groups.map((g) => (
                <div key={g.type} className="border-b last:border-b-0">
                  <div className="px-3 pt-2 pb-1 text-[11px] font-semibold text-muted-foreground">{g.title}</div>
                  {g.hits.map((h) => (
                    <button
                      key={`${h.type}-${h.id}`}
                      onClick={() => go(h)}
                      className="w-full text-right px-3 py-2 hover:bg-muted/60 flex items-start gap-2"
                    >
                      <span className="text-base leading-none mt-0.5">{TYPE_ICON[h.type] ?? "•"}</span>
                      <span className="min-w-0">
                        <span className="block text-sm font-medium truncate">{h.label}</span>
                        <span className="block text-[11px] text-muted-foreground truncate">{h.sublabel}</span>
                      </span>
                    </button>
                  ))}
                </div>
              ))}
              <div className="px-3 py-1.5 text-[10px] text-muted-foreground flex items-center gap-1">
                <CornerDownLeft className="w-3 h-3" /> Enter يفتح أول نتيجة · Esc يغلق
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
