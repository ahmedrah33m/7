"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { api } from "@/lib/client-api";
import { formatDateTime } from "@/lib/utils";
import { ArrowLeftRight, CheckCircle2, Plus, Trash2, XCircle } from "lucide-react";

interface Product { id: number; name: string; unit: string }
interface TransferRow {
  id: number;
  number: string;
  status: "DRAFT" | "IN_TRANSIT" | "RECEIVED" | "CANCELLED";
  from: { code: string; name: string };
  to: { code: string; name: string };
  lines: { product: { name: string; unit: string }; qty: number }[];
  dispatched_at: string | null;
  received_at: string | null;
  created_by: string;
  created_at: string;
}

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";
const STATUS_AR: Record<string, { label: string; variant: "secondary" | "default" | "success" | "destructive" }> = {
  DRAFT: { label: "مسودة", variant: "secondary" },
  IN_TRANSIT: { label: "في الطريق", variant: "default" },
  RECEIVED: { label: "مستلم", variant: "success" },
  CANCELLED: { label: "ملغى", variant: "destructive" },
};

interface Line { product_id: number; qty: number }

export function TransfersTab({ warehouses, canCreate }: { warehouses: { id: number; code: string; name: string }[]; canCreate: boolean }) {
  const [products, setProducts] = React.useState<Product[]>([]);
  const [rows, setRows] = React.useState<TransferRow[] | null>(null);
  const [lines, setLines] = React.useState<Line[]>([]);
  const [saving, setSaving] = React.useState(false);
  const [acting, setActing] = React.useState<number | null>(null);

  const load = React.useCallback(async () => {
    const [p, r] = await Promise.all([
      api<Product[]>("/api/v1/products?per_page=200"),
      api<TransferRow[]>("/api/v1/inventory/transfers?per_page=25"),
    ]);
    if (p.body.success && p.body.data) setProducts(p.body.data);
    if (r.body.success && r.body.data) setRows(r.body.data);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  function addLine() {
    const first = products[0];
    if (!first) return;
    setLines((prev) => [...prev, { product_id: first.id, qty: 1 }]);
  }
  function setLine(idx: number, patch: Partial<Line>) {
    setLines((prev) => prev.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
  }

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!lines.length) return toast.error("أضف بندًا واحدًا على الأقل");
    setSaving(true);
    const fd = new FormData(e.currentTarget);
    const from = Number(fd.get("from"));
    const to = Number(fd.get("to"));
    try {
      if (from === to) { toast.error("اختر مستودعين مختلفين"); return; }
      const { body } = await api("/api/v1/inventory/transfers", {
        method: "POST",
        body: JSON.stringify({
          from_warehouse_id: from,
          to_warehouse_id: to,
          notes: fd.get("notes") || undefined,
          lines: lines.map((l) => ({ product_id: l.product_id, qty: l.qty })),
        }),
      });
      if (body.success) {
        const d = body.data as { number: string; status: string };
        toast.success(`تحويل ${d.number} أُرسل ✓ — الحالة: ${STATUS_AR[d.status]?.label ?? d.status}`);
        setLines([]);
        (e.target as HTMLFormElement).reset();
        await load();
      } else toast.error(body.message ?? "فشل إنشاء التحويل");
    } finally {
      setSaving(false);
    }
  }

  async function act(id: number, action: "receive" | "cancel") {
    setActing(id);
    try {
      const { body } = await api(`/api/v1/inventory/transfers/${id}/${action}`, { method: "POST", body: "{}" });
      if (body.success) {
        toast.success(action === "receive" ? "استُلم التحويل — المخزون أُضيف للمستودع الوجهة ✓" : "أُلغي التحويل");
        await load();
      } else toast.error(body.message ?? "فشلت العملية");
    } finally {
      setActing(null);
    }
  }

  return (
    <div className="space-y-4">
      {canCreate && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><ArrowLeftRight className="w-5 h-5 text-primary" /> تحويل بين مستودعين</CardTitle>
            <CardDescription>الإرسال يخصم فورًا من المصدر (TRANSFER_OUT) — الاستلام يضيف للوجهة (TRANSFER_IN) مرة واحدة فقط؛ الاستلام المكرر يُرفض (VAL_004)</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={submit} className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
                <label className="text-xs font-medium space-y-1">من مستودع *
                  <select name="from" required className={inputCls} defaultValue={warehouses[0]?.id}>
                    {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
                  </select>
                </label>
                <label className="text-xs font-medium space-y-1">إلى مستودع *
                  <select name="to" required className={inputCls} defaultValue={warehouses[1]?.id ?? warehouses[0]?.id}>
                    {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
                  </select>
                </label>
                <label className="text-xs font-medium space-y-1 lg:col-span-2">ملاحظة
                  <input name="notes" className={inputCls} placeholder="اختياري — مثال: تحميل سيارة المندوب" />
                </label>
              </div>
              <div className="rounded-lg border p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-medium">البنود ({lines.length})</div>
                  <Button type="button" size="sm" variant="outline" onClick={addLine}><Plus className="w-4 h-4" /> بند</Button>
                </div>
                {lines.length === 0 ? (
                  <div className="py-4 text-center text-sm text-muted-foreground">لا بنود — اضغط «بند» لإضافة صنف</div>
                ) : (
                  <div className="space-y-2">
                    {lines.map((l, i) => (
                      <div key={i} className="grid grid-cols-[1fr_120px_36px] items-center gap-2">
                        <select className={inputCls} value={l.product_id} onChange={(e) => setLine(i, { product_id: Number(e.target.value) })}>
                          {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                        </select>
                        <input type="number" min="0.001" step="any" className={inputCls} dir="ltr" value={l.qty} onChange={(e) => setLine(i, { qty: Number(e.target.value) })} placeholder="كمية" />
                        <Button type="button" size="icon" variant="ghost" onClick={() => setLines((prev) => prev.filter((_, j) => j !== i))}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <Button type="submit" disabled={saving || lines.length === 0}>{saving ? "جارٍ الإرسال..." : "إنشاء وإرسال التحويل"}</Button>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">التحويلات المخزنية</CardTitle></CardHeader>
        <CardContent>
          {rows === null ? (
            <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div>
          ) : rows.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">لا تحويلات بعد</div>
          ) : (
            <div className="space-y-3">
              {rows.map((t) => {
                const st = STATUS_AR[t.status] ?? { label: t.status, variant: "secondary" as const };
                return (
                  <div key={t.id} className="rounded-lg border p-3">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs" dir="ltr">{t.number}</span>
                        <Badge variant={st.variant} className="text-[10px]">{st.label}</Badge>
                        <span className="text-sm">{t.from.name}</span>
                        <ArrowLeftRight className="w-3.5 h-3.5 text-muted-foreground" />
                        <span className="text-sm">{t.to.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {t.status === "IN_TRANSIT" && canCreate && (
                          <Button size="sm" onClick={() => act(t.id, "receive")} disabled={acting === t.id}>
                            <CheckCircle2 className="w-4 h-4" /> استلام
                          </Button>
                        )}
                        {t.status === "DRAFT" && canCreate && (
                          <Button size="sm" variant="outline" onClick={() => act(t.id, "cancel")} disabled={acting === t.id}>
                            <XCircle className="w-4 h-4" /> إلغاء
                          </Button>
                        )}
                      </div>
                    </div>
                    <div className="mt-2 text-xs text-muted-foreground flex flex-wrap gap-x-4">
                      {t.lines.map((l, i) => <span key={i}>{l.product.name}: <b dir="ltr">{l.qty}</b> {l.product.unit}</span>)}
                    </div>
                    <div className="mt-1 text-[11px] text-muted-foreground">
                      بواسطة {t.created_by} · أُنشئ {formatDateTime(t.created_at ?? "")}
                      {t.received_at ? ` · استُلم ${formatDateTime(t.received_at)}` : ""}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

    </div>
  );
}
