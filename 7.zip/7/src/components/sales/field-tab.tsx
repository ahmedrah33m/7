"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { api, type LoginPayload } from "@/lib/client-api";
import { formatDateTime } from "@/lib/utils";
import {
  CalendarCheck, CheckCircle2, ClipboardList, Coins, MapPin, Navigation, Plus, Target, Users2, XCircle,
} from "lucide-react";

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";

const fmtIQD = (n: number) => new Intl.NumberFormat("ar-IQ", { maximumFractionDigits: 0 }).format(n);

interface RepPerf {
  repId: number; repName: string; username: string;
  sales: number; invoicesCount: number; target: number | null; achievementPct: number | null;
  commissionsPending: number; commissionsApproved: number; commissionsPaid: number; visitsThisMonth: number;
}
interface VisitRow {
  id: number; status: string; planned_date: string;
  customer: { id: number; code: string; name: string };
  rep: { id: number; fullName: string };
  route: { id: number; name: string } | null;
  checkin_at: string | null;
  gps: { lat: number; lng: number } | null;
  outcome: string | null; order_value: number; notes: string | null;
}
interface RouteRow {
  id: number; code: string; name: string; day_of_week: number | null;
  rep: { id: number; fullName: string } | null;
  customers: { seq: number; id: number; code: string; name: string; balance: number }[];
  visits_count: number;
}
interface CommissionRow {
  id: number; rule: string; rule_type: string;
  rep: { id: number; name: string; username: string };
  invoice: { id: number; number: string; grand_total: number; date: string };
  period: string; base_amount: number; total_qty: number; amount: number; status: string;
}
interface CustomerOpt { id: number; name: string; code: string }

const VISIT_STATUS: Record<string, { label: string; variant: "secondary" | "default" | "success" | "destructive" }> = {
  PLANNED: { label: "مخططة", variant: "secondary" },
  CHECKED_IN: { label: "حاضر (في الموقع)", variant: "default" },
  COMPLETED: { label: "منتهية", variant: "success" },
  CANCELLED: { label: "ملغاة", variant: "destructive" },
};
const OUTCOME_AR: Record<string, string> = {
  ORDERED: "طلبية", NO_ORDER: "بدون طلبية", COLLECTION: "تحصيل", POSTPONED: "مؤجلة",
};
const COMMISSION_STATUS: Record<string, { label: string; variant: "secondary" | "default" | "success" }> = {
  PENDING: { label: "معلّقة", variant: "secondary" },
  APPROVED: { label: "معتمدة", variant: "default" },
  PAID: { label: "مصروفة", variant: "success" },
};
const RULE_TYPE_AR: Record<string, string> = {
  PERCENT_OF_SALES: "نسبة من المبيعات",
  PER_UNIT: "لكل وحدة",
  FIXED_PER_INVOICE: "ثابتة للفاتورة",
  TIER_BY_TARGET: "شرائح الهدف",
};
const DAYS_AR = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];

function currentPeriod(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function FieldTab({ session }: { session: LoginPayload }) {
  const has = (p: string) => session.permissions.includes(p);
  const canTargets = has("field.targets.view");
  const canTargetsCreate = has("field.targets.create");
  const canVisits = has("field.visits.view");
  const canVisitsCreate = has("field.visits.create");
  const canVisitsEdit = has("field.visits.edit");
  const canVisitsCancel = has("field.visits.cancel");
  const canRoutes = has("field.routes.view");
  const canRoutesCreate = has("field.routes.create");
  const canCommissions = has("field.commissions.view");
  const canCommissionApprove = has("field.commissions.approve");
  const isRep = session.roles.some((r: { code?: string } | string) => (typeof r === "string" ? r === "SALES_REP" : r.code === "SALES_REP"));

  return (
    <Tabs defaultValue="performance" dir="rtl">
      <TabsList className="w-full justify-start overflow-x-auto scroll-thin h-auto py-1">
        {(canTargets || canCommissions) && <TabsTrigger value="performance"><Target className="w-4 h-4" /> الأداء والأهداف</TabsTrigger>}
        {canVisits && <TabsTrigger value="visits"><CalendarCheck className="w-4 h-4" /> الزيارات (GPS)</TabsTrigger>}
        {canRoutes && <TabsTrigger value="routes"><Users2 className="w-4 h-4" /> المسارات</TabsTrigger>}
        {canCommissions && <TabsTrigger value="commissions"><Coins className="w-4 h-4" /> العمولات</TabsTrigger>}
      </TabsList>

      {(canTargets || canCommissions) && (
        <TabsContent value="performance">
          <PerformanceSection canTargetsCreate={canTargetsCreate} isRep={isRep} />
        </TabsContent>
      )}
      {canVisits && (
        <TabsContent value="visits">
          <VisitsSection
            canCreate={canVisitsCreate} canEdit={canVisitsEdit} canCancel={canVisitsCancel} isRep={isRep}
          />
        </TabsContent>
      )}
      {canRoutes && (
        <TabsContent value="routes">
          <RoutesSection canCreate={canRoutesCreate} isRep={isRep} />
        </TabsContent>
      )}
      {canCommissions && (
        <TabsContent value="commissions">
          <CommissionsSection canApprove={canCommissionApprove} />
        </TabsContent>
      )}
    </Tabs>
  );
}

// ---------------------------------------------------------------------
// الأداء والأهداف
// ---------------------------------------------------------------------
function PerformanceSection({ canTargetsCreate, isRep }: { canTargetsCreate: boolean; isRep: boolean }) {
  const [rows, setRows] = React.useState<RepPerf[] | null>(null);
  const [period, setPeriod] = React.useState(currentPeriod());
  const [saving, setSaving] = React.useState(false);

  const load = React.useCallback(async (p: string) => {
    const { body } = await api<RepPerf[]>(`/api/v1/field/targets?period=${p}`);
    if (body.success && body.data) setRows(body.data);
    else toast.error(body.message ?? "تعذر تحميل الأداء");
  }, []);

  React.useEffect(() => { load(period); }, [load, period]);

  async function setTarget(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setSaving(true);
    try {
      const { body } = await api("/api/v1/field/targets", {
        method: "POST",
        body: JSON.stringify({
          rep_id: Number(fd.get("rep_id")),
          period: fd.get("period"),
          target_amount: Number(fd.get("target_amount")),
        }),
      });
      if (body.success) {
        toast.success("حُفظ الهدف الشهري ✓");
        await load(period);
      } else toast.error(body.message ?? "فشل حفظ الهدف");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 flex-wrap">
        <label className="text-xs text-muted-foreground">الفترة</label>
        <input type="month" className={`${inputCls} w-40`} value={period} onChange={(e) => setPeriod(e.target.value || currentPeriod())} />
      </div>

      {rows === null ? (
        <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div>
      ) : rows.length === 0 ? (
        <Card><CardContent className="py-8 text-center text-muted-foreground">لا مندوبين مفعّلين بعد</CardContent></Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {rows.map((r) => {
            const pct = r.achievementPct ?? 0;
            const tier = pct >= 100 ? "تجاوز الهدف" : pct >= 80 ? "قرب الهدف" : pct >= 50 ? "نصف الهدف" : "أقل من النصف";
            return (
              <Card key={r.repId}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center justify-between">
                    <span>{r.repName}</span>
                    <Badge variant={pct >= 100 ? "success" : pct >= 50 ? "accent" : "secondary"} className="text-[10px]">{tier}</Badge>
                  </CardTitle>
                  <CardDescription dir="ltr" className="text-[11px]">@{r.username} · {r.invoicesCount} فاتورة · {r.visitsThisMonth} زيارة هذا الشهر</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>المبيعات: <b>{fmtIQD(r.sales)}</b></span>
                      <span className="text-muted-foreground">الهدف: {r.target ? fmtIQD(r.target) : "—"}</span>
                    </div>
                    <div className="h-2.5 rounded-full bg-muted overflow-hidden">
                      <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${Math.min(100, pct)}%` }} />
                    </div>
                    <div className="text-[11px] text-muted-foreground mt-1">التحقيق: {r.achievementPct != null ? `${pct.toFixed(1)}%` : "لم يُحدد هدف"}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center text-xs">
                    <div className="rounded-md border p-2"><div className="text-muted-foreground">عمولات معلّقة</div><b>{fmtIQD(r.commissionsPending)}</b></div>
                    <div className="rounded-md border p-2"><div className="text-muted-foreground">معتمدة</div><b>{fmtIQD(r.commissionsApproved)}</b></div>
                    <div className="rounded-md border p-2"><div className="text-muted-foreground">مصروفة</div><b>{fmtIQD(r.commissionsPaid)}</b></div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {canTargetsCreate && <TargetForm rows={rows} period={period} saving={saving} onSubmit={setTarget} />}
      {isRep && <p className="text-xs text-muted-foreground">ترى أداءك أنت فقط — عزل المندوب مطبّق على مستوى الخادم.</p>}
    </div>
  );
}

function TargetForm({ rows, period, saving, onSubmit }: {
  rows: RepPerf[] | null; period: string; saving: boolean;
  onSubmit: (e: React.FormEvent<HTMLFormElement>) => void;
}) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2"><Target className="w-5 h-5 text-primary" /> تعيين هدف شهري</CardTitle>
        <CardDescription>الهدف يحرّك محرك عمولة الشرائح (TIER_BY_TARGET) — التحقيق يُحسب من فواتير المندوب في الفترة</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={onSubmit} className="grid gap-3 sm:grid-cols-3">
          <label className="text-xs font-medium space-y-1">المندوب *
            <select name="rep_id" required className={inputCls}>
              {(rows ?? []).map((r) => <option key={r.repId} value={r.repId}>{r.repName}</option>)}
            </select>
          </label>
          <label className="text-xs font-medium space-y-1">الفترة *
            <input name="period" required className={inputCls} dir="ltr" defaultValue={period} placeholder="YYYY-MM" />
          </label>
          <label className="text-xs font-medium space-y-1">قيمة الهدف (IQD) *
            <input name="target_amount" type="number" min="1" step="any" required className={inputCls} dir="ltr" placeholder="3000000" />
          </label>
          <div className="sm:col-span-3">
            <Button type="submit" disabled={saving || !rows?.length}>{saving ? "جارٍ الحفظ..." : "حفظ الهدف"}</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------
// الزيارات
// ---------------------------------------------------------------------
function VisitsSection({ canCreate, canEdit, canCancel, isRep }: {
  canCreate: boolean; canEdit: boolean; canCancel: boolean; isRep: boolean;
}) {
  const [rows, setRows] = React.useState<VisitRow[] | null>(null);
  const [customers, setCustomers] = React.useState<CustomerOpt[]>([]);
  const [routes, setRoutes] = React.useState<RouteRow[]>([]);
  const [saving, setSaving] = React.useState(false);
  const [acting, setActing] = React.useState<number | null>(null);
  const [completing, setCompleting] = React.useState<VisitRow | null>(null);
  const [outcome, setOutcome] = React.useState("ORDERED");
  const [orderValue, setOrderValue] = React.useState("");

  const load = React.useCallback(async () => {
    const [v, c, r] = await Promise.all([
      api<VisitRow[]>("/api/v1/field/visits"),
      api<CustomerOpt[]>("/api/v1/customers?per_page=200").catch(() => ({ body: { success: false, data: [] } as never })),
      api<RouteRow[]>("/api/v1/field/routes").catch(() => ({ body: { success: false, data: [] } as never })),
    ]);
    if (v.body.success && v.body.data) setRows(v.body.data);
    if (c.body.success && c.body.data) setCustomers(c.body.data as CustomerOpt[]);
    if (r.body.success && r.body.data) setRoutes(r.body.data as RouteRow[]);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  async function planVisit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setSaving(true);
    try {
      const { body } = await api("/api/v1/field/visits", {
        method: "POST",
        body: JSON.stringify({
          customer_id: Number(fd.get("customer_id")),
          planned_date: fd.get("planned_date"),
          route_id: fd.get("route_id") ? Number(fd.get("route_id")) : undefined,
          notes: fd.get("notes") || undefined,
          ...(isRep ? {} : { rep_id: undefined }),
        }),
      });
      if (body.success) { toast.success("خُططت الزيارة ✓"); (e.target as HTMLFormElement).reset(); await load(); }
      else toast.error(body.message ?? "فشل تخطيط الزيارة");
    } finally { setSaving(false); }
  }

  function getGPS(): Promise<{ lat: number; lng: number }> {
    return new Promise((resolve) => {
      if (typeof navigator !== "undefined" && navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
          () => resolve({ lat: 33.3152, lng: 44.3661 }), // fallback بغداد — ساندبوكس بلا GPS
          { timeout: 3000 }
        );
      } else resolve({ lat: 33.3152, lng: 44.3661 });
    });
  }

  async function checkin(v: VisitRow) {
    setActing(v.id);
    try {
      const gps = await getGPS();
      const { body } = await api(`/api/v1/field/visits/${v.id}/checkin`, { method: "POST", body: JSON.stringify(gps) });
      if (body.success) toast.success(`سُجل الحضور بموقع (GPS ${gps.lat.toFixed(4)}, ${gps.lng.toFixed(4)}) ✓`);
      else toast.error(body.message ?? "فشل تسجيل الحضور");
      await load();
    } finally { setActing(null); }
  }

  async function complete(e: React.FormEvent<HTMLFormElement>, v: VisitRow) {
    e.preventDefault();
    setActing(v.id);
    try {
      const { body } = await api(`/api/v1/field/visits/${v.id}/complete`, {
        method: "POST",
        body: JSON.stringify({ outcome, order_value: Number(orderValue || 0), notes: v.notes ?? undefined }),
      });
      if (body.success) { toast.success("أُتمت الزيارة ✓"); setCompleting(null); await load(); }
      else toast.error(body.message ?? "فشل إتمام الزيارة");
    } finally { setActing(null); }
  }

  async function cancel(v: VisitRow) {
    setActing(v.id);
    try {
      const { body } = await api(`/api/v1/field/visits/${v.id}/cancel`, { method: "POST", body: "{}" });
      if (body.success) toast.success("أُلغيت الزيارة");
      else toast.error(body.message ?? "فشل الإلغاء");
      await load();
    } finally { setActing(null); }
  }

  return (
    <div className="space-y-4">
      {canCreate && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><ClipboardList className="w-5 h-5 text-primary" /> تخطيط زيارة</CardTitle>
            <CardDescription>المندوب يخطط لزياراته تلقائيًا؛ المديرون يعيّنون الزيارة لأي مندوب. آلة الحالة: مخططة ← حاضر ← منتهية</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={planVisit} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <label className="text-xs font-medium space-y-1">العميل *
                <select name="customer_id" required className={inputCls}>
                  {customers.map((c) => <option key={c.id} value={c.id}>{c.code} — {c.name}</option>)}
                </select>
              </label>
              <label className="text-xs font-medium space-y-1">التاريخ والوقت *
                <input name="planned_date" type="datetime-local" required className={inputCls} dir="ltr" />
              </label>
              <label className="text-xs font-medium space-y-1">المسار (اختياري)
                <select name="route_id" className={inputCls}>
                  <option value="">— بدون —</option>
                  {routes.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
              </label>
              <label className="text-xs font-medium space-y-1">ملاحظة
                <input name="notes" className={inputCls} placeholder="اختياري" />
              </label>
              <div className="sm:col-span-2 lg:col-span-4">
                <Button type="submit" disabled={saving || customers.length === 0}>{saving ? "جارٍ التخطيط..." : "تخطيط الزيارة"}</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">جدول الزيارات</CardTitle></CardHeader>
        <CardContent>
          {rows === null ? (
            <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div>
          ) : rows.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">لا زيارات بعد</div>
          ) : (
            <div className="space-y-3">
              {rows.map((v) => {
                const st = VISIT_STATUS[v.status] ?? { label: v.status, variant: "secondary" as const };
                return (
                  <div key={v.id} className="rounded-lg border p-3 space-y-2">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant={st.variant} className="text-[10px]">{st.label}</Badge>
                        <span className="font-medium text-sm">{v.customer.name}</span>
                        <span className="font-mono text-[10px] text-muted-foreground" dir="ltr">{v.customer.code}</span>
                        <span className="text-xs text-muted-foreground">· {v.rep.fullName}</span>
                        {v.route && <span className="text-xs text-muted-foreground">· {v.route.name}</span>}
                      </div>
                      <div className="text-xs text-muted-foreground">{formatDateTime(v.planned_date)}</div>
                    </div>
                    {v.gps && (
                      <div className="text-xs text-muted-foreground flex items-center gap-1" dir="ltr">
                        <MapPin className="w-3.5 h-3.5 text-primary" /> GPS {v.gps.lat.toFixed(5)}, {v.gps.lng.toFixed(5)} · {v.checkin_at ? formatDateTime(v.checkin_at) : ""}
                      </div>
                    )}
                    {v.outcome && (
                      <div className="text-xs">النتيجة: <b>{OUTCOME_AR[v.outcome] ?? v.outcome}</b>{v.order_value > 0 ? ` — قيمة ${fmtIQD(v.order_value)} IQD` : ""}</div>
                    )}
                    {(v.status === "PLANNED" || v.status === "CHECKED_IN") && (
                      <div className="flex items-center gap-2 flex-wrap">
                        {v.status === "PLANNED" && canEdit && (
                          <Button size="sm" onClick={() => checkin(v)} disabled={acting === v.id}>
                            <Navigation className="w-4 h-4" /> تسجيل حضور (GPS)
                          </Button>
                        )}
                        {v.status === "CHECKED_IN" && canEdit && (
                          <Button size="sm" onClick={() => { setCompleting(completing?.id === v.id ? null : v); setOutcome("ORDERED"); setOrderValue(""); }}>
                            <CheckCircle2 className="w-4 h-4" /> إتمام الزيارة
                          </Button>
                        )}
                        {canCancel && (
                          <Button size="sm" variant="outline" onClick={() => cancel(v)} disabled={acting === v.id}>
                            <XCircle className="w-4 h-4" /> إلغاء
                          </Button>
                        )}
                      </div>
                    )}
                    {completing?.id === v.id && (
                      <form onSubmit={(e) => complete(e, v)} className="rounded-md bg-muted/40 p-3 grid gap-2 sm:grid-cols-[160px_1fr_auto] items-end">
                        <label className="text-xs font-medium space-y-1">النتيجة *
                          <select className={inputCls} value={outcome} onChange={(e) => setOutcome(e.target.value)}>
                            {Object.entries(OUTCOME_AR).map(([k, label]) => <option key={k} value={k}>{label}</option>)}
                          </select>
                        </label>
                        <label className="text-xs font-medium space-y-1">قيمة الطلبية (IQD)
                          <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={orderValue} onChange={(e) => setOrderValue(e.target.value)} placeholder="0" disabled={outcome !== "ORDERED"} />
                        </label>
                        <Button type="submit" disabled={acting === v.id}>تأكيد الإتمام</Button>
                      </form>
                    )}
                    {v.notes && <div className="text-[11px] text-muted-foreground">{v.notes}</div>}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------
// المسارات
// ---------------------------------------------------------------------
function RoutesSection({ canCreate, isRep }: { canCreate: boolean; isRep: boolean }) {
  const [rows, setRows] = React.useState<RouteRow[] | null>(null);
  const [customers, setCustomers] = React.useState<CustomerOpt[]>([]);
  const [picked, setPicked] = React.useState<number[]>([]);
  const [saving, setSaving] = React.useState(false);

  const load = React.useCallback(async () => {
    const [r, c] = await Promise.all([
      api<RouteRow[]>("/api/v1/field/routes"),
      api<CustomerOpt[]>("/api/v1/customers?per_page=200").catch(() => ({ body: { success: false, data: [] } as never })),
    ]);
    if (r.body.success && r.body.data) setRows(r.body.data);
    if (c.body.success && c.body.data) setCustomers(c.body.data as CustomerOpt[]);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  async function createRoute(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setSaving(true);
    try {
      const { body } = await api("/api/v1/field/routes", {
        method: "POST",
        body: JSON.stringify({
          name: fd.get("name"),
          day_of_week: fd.get("day") ? Number(fd.get("day")) : null,
          customer_ids: picked,
          ...(isRep ? {} : {}),
        }),
      });
      if (body.success) {
        toast.success(`أُنشئ المسار ✓ — ${picked.length} عميل`);
        setPicked([]);
        (e.target as HTMLFormElement).reset();
        await load();
      } else toast.error(body.message ?? "فشل إنشاء المسار");
    } finally { setSaving(false); }
  }

  return (
    <div className="space-y-4">
      {canCreate && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><Plus className="w-5 h-5 text-primary" /> مسار توزيع جديد</CardTitle>
            <CardDescription>المسار يرتب العملاء بترتيب زيارة أسبوعي ثابت</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={createRoute} className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="text-xs font-medium space-y-1">اسم المسار *
                  <input name="name" required className={inputCls} placeholder="مثال: مسار الأعظمية — الثلاثاء" />
                </label>
                <label className="text-xs font-medium space-y-1">يوم الأسبوع
                  <select name="day" className={inputCls} defaultValue="0">
                    {DAYS_AR.map((d, i) => <option key={i} value={i}>{d}</option>)}
                  </select>
                </label>
              </div>
              <div className="rounded-lg border p-3">
                <div className="text-sm font-medium mb-2">عملاء المسار ({picked.length})</div>
                <div className="max-h-40 overflow-y-auto scroll-thin space-y-1.5">
                  {customers.map((c) => (
                    <label key={c.id} className="flex items-center gap-2 text-sm cursor-pointer">
                      <input
                        type="checkbox"
                        checked={picked.includes(c.id)}
                        onChange={(e) => setPicked((prev) => e.target.checked ? [...prev, c.id] : prev.filter((x) => x !== c.id))}
                      />
                      {c.code} — {c.name}
                    </label>
                  ))}
                </div>
              </div>
              <Button type="submit" disabled={saving}>{saving ? "جارٍ الإنشاء..." : "إنشاء المسار"}</Button>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">مسارات التوزيع</CardTitle></CardHeader>
        <CardContent>
          {rows === null ? (
            <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div>
          ) : rows.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">لا مسارات بعد</div>
          ) : (
            <div className="grid gap-3 md:grid-cols-2">
              {rows.map((r) => (
                <div key={r.id} className="rounded-lg border p-3">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs" dir="ltr">{r.code}</span>
                      <b className="text-sm">{r.name}</b>
                    </div>
                    <Badge variant="secondary" className="text-[10px]">{r.day_of_week != null ? DAYS_AR[r.day_of_week] : "بدون يوم"}</Badge>
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">المندوب: {r.rep?.fullName ?? "—"} · زيارات مسجلة: {r.visits_count}</div>
                  <ol className="mt-2 space-y-1 text-sm list-decimal list-inside">
                    {r.customers.map((rc) => (
                      <li key={rc.id}>{rc.name} <span className="text-[10px] text-muted-foreground" dir="ltr">({rc.code})</span></li>
                    ))}
                  </ol>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------
// العمولات
// ---------------------------------------------------------------------
function CommissionsSection({ canApprove }: { canApprove: boolean }) {
  const [rows, setRows] = React.useState<CommissionRow[] | null>(null);
  const [acting, setActing] = React.useState<number | null>(null);

  const load = React.useCallback(async () => {
    const { body } = await api<CommissionRow[]>("/api/v1/field/commissions");
    if (body.success && body.data) setRows(body.data);
  }, []);
  React.useEffect(() => { load(); }, [load]);

  async function decide(id: number, action: "approve" | "pay") {
    setActing(id);
    try {
      const { body } = await api(`/api/v1/field/commissions/${id}/${action}`, { method: "POST", body: "{}" });
      if (body.success) toast.success(action === "approve" ? "اعتُمدت العمولة ✓" : "صُرفت العمولة ✓");
      else toast.error(body.message ?? "فشلت العملية");
      await load();
    } finally { setActing(null); }
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2"><Coins className="w-5 h-5 text-primary" /> عمولات المندوبين</CardTitle>
        <CardDescription>
          المحرك يعمل تلقائيًا مع كل فاتورة مندوب: نسبة من المبيعات · لكل وحدة · ثابتة للفاتورة · شرائح الهدف —
          قيد فريد (فاتورة × قاعدة) يجعل العمولة المزدوجة مستحيلة بنيويًا
        </CardDescription>
      </CardHeader>
      <CardContent>
        {rows === null ? (
          <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div>
        ) : rows.length === 0 ? (
          <div className="py-8 text-center text-muted-foreground">لا عمولات بعد — أصدر فاتورة بحساب مندوب لتوليدها تلقائيًا</div>
        ) : (
          <div className="space-y-3">
            {rows.map((c) => {
              const st = COMMISSION_STATUS[c.status] ?? { label: c.status, variant: "secondary" as const };
              return (
                <div key={c.id} className="rounded-lg border p-3">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant={st.variant} className="text-[10px]">{st.label}</Badge>
                      <b className="text-sm">{fmtIQD(c.amount)} IQD</b>
                      <span className="text-xs text-muted-foreground">— {c.rep.name} · {RULE_TYPE_AR[c.rule_type] ?? c.rule_type} · «{c.rule}»</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {c.status === "PENDING" && canApprove && (
                        <Button size="sm" onClick={() => decide(c.id, "approve")} disabled={acting === c.id}><CheckCircle2 className="w-4 h-4" /> اعتماد</Button>
                      )}
                      {c.status === "APPROVED" && canApprove && (
                        <Button size="sm" onClick={() => decide(c.id, "pay")} disabled={acting === c.id}><Coins className="w-4 h-4" /> صرف</Button>
                      )}
                    </div>
                  </div>
                  <div className="mt-1.5 text-[11px] text-muted-foreground flex flex-wrap gap-x-3" dir="rtl">
                    <span>الفاتورة: <b className="font-mono" dir="ltr">{c.invoice.number}</b></span>
                    <span>الأساس: {fmtIQD(c.base_amount)} IQD</span>
                    <span>الكمية: {c.total_qty}</span>
                    <span>الفترة: <span dir="ltr">{c.period}</span></span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
