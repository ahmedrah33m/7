"use client";

// =====================================================================
// Users & Branches management (Task 25) — إضافة المندوبين ومديري الفروع
// وأي مستخدم بيوزر خاص، وإنشاء فروع جديدة تجهز آليًا (مستودع + صندوق
// + مدير بيوزر). بيانات الدخول تُعرض مرة واحدة بعد الإنشاء لتسليمها
// لصاحب الحساب — لا يُخزن نص كلمة المرور في أي مكان.
// =====================================================================

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api, type LoginPayload } from "@/lib/client-api";
import { formatDateTime } from "@/lib/utils";
import {
  Users, Building2, Plus, UserPlus, Truck, ShieldCheck, Calculator, Store, Settings2,
  KeyRound, PowerOff, Power, CopyCheck, Loader2, ClipboardList,
} from "lucide-react";

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";

interface UserRow {
  id: number;
  username: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  is_active: boolean;
  last_login_at: string | null;
  branch: string | null;
  roles: { code: string; name: string }[];
}

interface RoleRow {
  id: number;
  code: string;
  name: string;
  description?: string | null;
}

interface BranchRow {
  id: number;
  code: string;
  name: string;
  city: string | null;
  phone: string | null;
  is_active: boolean;
  users_count: number;
  warehouses_count: number;
  invoices_count: number;
}

interface WarehouseInfo { id: number; code: string; name: string; type?: string }

interface Credentials { title: string; username: string; password: string; note?: string }

const PRESETS = [
  { key: "SALES_REP", label: "مندوب مبيعات", icon: Truck, roles: ["SALES_REP"], hint: "يبيع من مخزن سيارته — يُنشأ له مخزن آليًا" },
  { key: "BRANCH_MANAGER", label: "مدير فرع", icon: Building2, roles: ["BRANCH_MANAGER"], hint: "يرى بيانات فرعه فقط — عزل كامل" },
  { key: "CASHIER", label: "كاشير", icon: Store, roles: ["CASHIER"], hint: "بيع نقدي من نقطة البيع" },
  { key: "ACCOUNTANT", label: "محاسب", icon: Calculator, roles: ["ACCOUNTANT"], hint: "المدفوعات والذمم والمصروفات" },
  { key: "CASH_KEEPER", label: "أمين الصندوق", icon: ShieldCheck, roles: ["CASH_KEEPER"], hint: "إشعارات التسليم فقط — يُبلَّغ حصراً بحالات النقص (v14)" },
  { key: "CUSTOM", label: "مخصص", icon: Settings2, roles: [] as string[], hint: "اختر الأدوار يدويًا" },
];

function generatePassword(): string {
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const lower = "abcdefghijkmnpqrstuvwxyz";
  const digits = "23456789";
  const all = upper + lower + digits + "@#$%!";
  const pick = (set: string) => set[crypto.getRandomValues(new Uint32Array(1))[0] % set.length];
  const base = [pick(upper), pick(lower), pick(digits), pick(all)];
  while (base.length < 12) base.push(pick(all));
  for (let i = base.length - 1; i > 0; i--) {
    const j = crypto.getRandomValues(new Uint32Array(1))[0] % (i + 1);
    [base[i], base[j]] = [base[j], base[i]];
  }
  return base.join("");
}

export function UsersBranchesTab({
  session,
  warehouses,
}: {
  session: LoginPayload;
  warehouses: WarehouseInfo[];
}) {
  const perms = new Set(session.permissions);
  const canUsersView = perms.has("system.users.view");
  const canUsersCreate = perms.has("system.users.create");
  const canUsersEdit = perms.has("system.users.edit");
  const canBranchesView = perms.has("system.branches.view");
  const canBranchesCreate = perms.has("system.branches.create");
  const canBranchesEdit = perms.has("system.branches.edit");

  const [users, setUsers] = React.useState<UserRow[] | null>(null);
  const [branches, setBranches] = React.useState<BranchRow[] | null>(null);
  const [roles, setRoles] = React.useState<RoleRow[]>([]);
  const [busy, setBusy] = React.useState(false);
  const [creds, setCreds] = React.useState<Credentials | null>(null);
  const [scopeAll, setScopeAll] = React.useState(true);

  // ── نموذج إضافة مستخدم ──
  const [showAdd, setShowAdd] = React.useState(false);
  const [presetKey, setPresetKey] = React.useState("SALES_REP");
  const [fUsername, setFUsername] = React.useState("");
  const [fName, setFName] = React.useState("");
  const [fPhone, setFPhone] = React.useState("");
  const [fPassword, setFPassword] = React.useState(() => generatePassword());
  const [fBranchId, setFBranchId] = React.useState<number | "">("");
  const [customRoles, setCustomRoles] = React.useState<string[]>([]);

  // ── تصفير كلمة المرور ──
  const [resetTarget, setResetTarget] = React.useState<UserRow | null>(null);
  const [resetPassword, setResetPassword] = React.useState(() => generatePassword());

  // ── تعديل مستخدم ──
  const [editTarget, setEditTarget] = React.useState<UserRow | null>(null);
  const [eName, setEName] = React.useState("");
  const [ePhone, setEPhone] = React.useState("");
  const [eBranchId, setEBranchId] = React.useState<number | "">("");
  const [eRoles, setERoles] = React.useState<string[]>([]);

  // ── نموذج إضافة فرع ──
  const [showAddBranch, setShowAddBranch] = React.useState(false);
  const [bCode, setBCode] = React.useState("");
  const [bName, setBName] = React.useState("");
  const [bCity, setBCity] = React.useState("");
  const [bPhone, setBPhone] = React.useState("");
  const [bWithManager, setBWithManager] = React.useState(true);
  const [bMgrUser, setBMgrUser] = React.useState("");
  const [bMgrName, setBMgrName] = React.useState("");
  const [bMgrPass, setBMgrPass] = React.useState(() => generatePassword());

  const loadUsers = React.useCallback(async () => {
    const { body } = await api<UserRow[]>("/api/v1/admin/users");
    if (body.success && body.data) setUsers(body.data);
  }, []);
  const loadBranches = React.useCallback(async () => {
    const { body } = await api<BranchRow[]>("/api/v1/admin/branches");
    if (body.success && body.data) setBranches(body.data);
  }, []);
  const loadRoles = React.useCallback(async () => {
    const { body } = await api<RoleRow[]>("/api/v1/admin/roles");
    if (body.success && body.data) setRoles(body.data);
  }, []);

  React.useEffect(() => {
    api<{ branch_scope?: { all: boolean; ids: number[] } }>("/api/v1/auth/me").then(({ body }) => {
      if (body.success && body.data?.branch_scope) setScopeAll(Boolean(body.data.branch_scope.all));
    });
    if (canUsersView) loadUsers().catch(() => setUsers([]));
    if (canUsersView) loadRoles().catch(() => setRoles([]));
    if (canBranchesView) loadBranches().catch(() => setBranches([]));
  }, [canUsersView, canBranchesView, loadUsers, loadBranches, loadRoles]);

  const preset = PRESETS.find((p) => p.key === presetKey)!;
  const effectiveRoles = presetKey === "CUSTOM" ? customRoles : preset.roles;

  function openAdd() {
    setShowAdd(true);
    setPresetKey("SALES_REP");
    setFUsername("");
    setFName("");
    setFPhone("");
    setFPassword(generatePassword());
    setFBranchId("");
    setCustomRoles([]);
  }

  async function submitUser(e: React.FormEvent) {
    e.preventDefault();
    if (!fUsername.trim() || !fName.trim() || effectiveRoles.length === 0) {
      toast.error("أكمل الاسم واسم المستخدم والدور");
      return;
    }
    setBusy(true);
    const { res, body } = await api<{ id: number }>("/api/v1/admin/users", {
      method: "POST",
      body: JSON.stringify({
        username: fUsername.trim(),
        password: fPassword,
        full_name: fName.trim(),
        phone: fPhone.trim() || null,
        branch_id: fBranchId === "" ? null : fBranchId,
        role_codes: effectiveRoles,
        bind_to_branch: fBranchId !== "",
      }),
    });
    setBusy(false);
    if (res.status === 201 || body.success) {
      toast.success("أُنشئ المستخدم — يمكنك الدخول الآن بنفس البيانات");
      setCreds({ title: `بيانات دخول: ${fName.trim()}`, username: fUsername.trim(), password: fPassword, note: preset.hint });
      setShowAdd(false);
      loadUsers();
      loadBranches();
    } else {
      toast.error(body.message ?? "فشل إنشاء المستخدم");
    }
  }

  async function toggleActive(u: UserRow) {
    const { body } = await api(`/api/v1/admin/users/${u.id}`, {
      method: "PATCH",
      body: JSON.stringify({ is_active: !u.is_active }),
    });
    if (body.success) {
      toast.success(u.is_active ? "عُطل الحساب — لن يتمكن من الدخول" : "فُعّل الحساب");
      loadUsers();
    } else toast.error(body.message ?? "فشل التعديل");
  }

  async function submitReset(e: React.FormEvent) {
    e.preventDefault();
    if (!resetTarget) return;
    setBusy(true);
    const { body } = await api(`/api/v1/admin/users/${resetTarget.id}`, {
      method: "PATCH",
      body: JSON.stringify({ password: resetPassword }),
    });
    setBusy(false);
    if (body.success) {
      setCreds({ title: `كلمة مرور جديدة: ${resetTarget.full_name}`, username: resetTarget.username, password: resetPassword });
      setResetTarget(null);
      loadUsers();
    } else toast.error(body.message ?? "فشل التصفير");
  }

  function openEdit(u: UserRow) {
    setEditTarget(u);
    setEName(u.full_name);
    setEPhone(u.phone ?? "");
    setERoles(u.roles.map((r) => r.code));
    const br = branches?.find((b) => b.name === u.branch);
    setEBranchId(br ? br.id : "");
  }

  async function submitEdit(e: React.FormEvent) {
    e.preventDefault();
    if (!editTarget) return;
    setBusy(true);
    const payload: Record<string, unknown> = { full_name: eName.trim(), phone: ePhone.trim() || null, role_codes: eRoles };
    if (eBranchId !== "") payload.branch_id = eBranchId;
    const { body } = await api(`/api/v1/admin/users/${editTarget.id}`, { method: "PATCH", body: JSON.stringify(payload) });
    setBusy(false);
    if (body.success) {
      toast.success("حُدث المستخدم");
      setEditTarget(null);
      loadUsers();
    } else toast.error(body.message ?? "فشل التحديث");
  }

  async function submitBranch(e: React.FormEvent) {
    e.preventDefault();
    if (!bCode.trim() || !bName.trim()) {
      toast.error("الكود والاسم مطلوبان");
      return;
    }
    if (bWithManager && (!bMgrUser.trim() || !bMgrName.trim())) {
      toast.error("أكمل بيانات مدير الفرع أو ألغِ إنشاء المدير");
      return;
    }
    setBusy(true);
    const { res, body } = await api<{ code: string; warehouse: { code: string }; cashbox: { code: string } }>("/api/v1/admin/branches", {
      method: "POST",
      body: JSON.stringify({
        code: bCode.trim(),
        name: bName.trim(),
        city: bCity.trim() || null,
        phone: bPhone.trim() || null,
        manager: bWithManager
          ? { username: bMgrUser.trim(), password: bMgrPass, full_name: bMgrName.trim() }
          : undefined,
      }),
    });
    setBusy(false);
    if (res.status === 201 || body.success) {
      toast.success(`أُنشئ فرع ${bName.trim()} بمستودع وصندوق آليين`);
      if (bWithManager) {
        setCreds({
          title: `مدير فرع: ${bName.trim()}`,
          username: bMgrUser.trim(),
          password: bMgrPass,
          note: "يرى بيانات فرعه فقط ويدخل بنفس بيانات هذا الحساب",
        });
      }
      setShowAddBranch(false);
      setBCode(""); setBName(""); setBCity(""); setBPhone("");
      setBMgrUser(""); setBMgrName(""); setBMgrPass(generatePassword());
      loadBranches();
      loadUsers();
    } else {
      toast.error(body.message ?? "فشل إنشاء الفرع");
    }
  }

  async function toggleBranch(b: BranchRow) {
    const { body } = await api(`/api/v1/admin/branches/${b.id}`, {
      method: "PATCH",
      body: JSON.stringify({ is_active: !b.is_active }),
    });
    if (body.success) {
      toast.success(b.is_active ? "عُطل الفرع" : "فُعّل الفرع");
      loadBranches();
    } else toast.error(body.message ?? "فشل التعديل");
  }

  function toggleCustomRole(code: string) {
    setCustomRoles((prev) => (prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]));
  }

  const anyAccess = canUsersView || canBranchesView;

  return (
    <div className="space-y-4">
      {/* بيانات الدخول المُنشأة — تُعرض مرة واحدة */}
      {creds && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setCreds(null)}>
          <Card className="w-full max-w-md" onClick={(e) => e.stopPropagation()}>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2"><CopyCheck className="w-5 h-5 text-green-600" /> {creds.title}</CardTitle>
              <CardDescription>سجّل هذه البيانات الآن — لن تُعرض كلمة المرور مرة أخرى</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3" dir="ltr">
              <div className="rounded-md border p-3 font-mono text-sm space-y-1.5">
                <div className="flex justify-between gap-2"><span className="text-muted-foreground">username</span><span className="font-bold">{creds.username}</span></div>
                <div className="flex justify-between gap-2"><span className="text-muted-foreground">password</span><span className="font-bold">{creds.password}</span></div>
              </div>
              {creds.note && <p className="text-xs text-muted-foreground" dir="rtl">{creds.note}</p>}
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => navigator.clipboard.writeText(`${creds.username} / ${creds.password}`).then(() => toast.success("نُسخت البيانات"))}
                >
                  <CopyCheck className="w-4 h-4" /> نسخ
                </Button>
                <Button className="flex-1" onClick={() => setCreds(null)}>تم</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {!anyAccess && (
        <Card><CardContent className="py-8 text-center text-sm text-muted-foreground">ليست لديك صلاحية إدارة المستخدمين أو الفروع</CardContent></Card>
      )}

      {/* ═══════════ المستخدمون ═══════════ */}
      {canUsersView && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <CardTitle className="text-base flex items-center gap-2"><Users className="w-5 h-5 text-primary" /> المستخدمون والمندوبون ({users?.length ?? "…"})</CardTitle>
                <CardDescription>كل مستخدم له يوزر خاص يدخل به إلى النظام — المندوب يُنشأ له مخزن سيارة آليًا</CardDescription>
              </div>
              {canUsersCreate && (
                <Button size="sm" onClick={openAdd}><UserPlus className="w-4 h-4" /> إضافة مستخدم</Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {showAdd && (
              <form onSubmit={submitUser} className="rounded-lg border p-3 space-y-3 bg-muted/30">
                <div className="flex flex-wrap gap-2">
                  {PRESETS.map((p) => (
                    <button
                      key={p.key}
                      type="button"
                      onClick={() => setPresetKey(p.key)}
                      className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${presetKey === p.key ? "bg-primary text-primary-foreground border-primary" : "bg-background hover:bg-muted"}`}
                    >
                      <p.icon className="w-3.5 h-3.5" /> {p.label}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">{preset.hint}</p>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  <div><label className="text-xs text-muted-foreground block mb-1">الاسم الكامل *</label>
                    <Input className={inputCls} value={fName} onChange={(e) => setFName(e.target.value)} placeholder="مثال: حسين المندوب" required /></div>
                  <div><label className="text-xs text-muted-foreground block mb-1">اسم المستخدم (بالإنجليزية) *</label>
                    <Input className={inputCls} dir="ltr" value={fUsername} onChange={(e) => setFUsername(e.target.value)} placeholder="rep.hussein" required /></div>
                  <div><label className="text-xs text-muted-foreground block mb-1">الهاتف</label>
                    <Input className={inputCls} dir="ltr" value={fPhone} onChange={(e) => setFPhone(e.target.value)} placeholder="07xxxxxxxxx" /></div>
                  <div>
                    <label className="text-xs text-muted-foreground block mb-1">الفرع {presetKey === "BRANCH_MANAGER" ? "*" : "(يحدد نطاق الرؤية)"}</label>
                    <select className={inputCls} value={String(fBranchId)} onChange={(e) => setFBranchId(e.target.value === "" ? "" : Number(e.target.value))}>
                      <option value="">— بلا فرع (كل الفروع) —</option>
                      {(branches ?? []).filter((b) => b.is_active).map((b) => <option key={b.id} value={b.id}>{b.name} ({b.code})</option>)}
                    </select>
                  </div>
                  <div className="lg:col-span-2">
                    <label className="text-xs text-muted-foreground block mb-1">كلمة المرور</label>
                    <div className="flex gap-2">
                      <Input className={inputCls} dir="ltr" value={fPassword} onChange={(e) => setFPassword(e.target.value)} required />
                      <Button type="button" variant="outline" size="sm" className="h-9 shrink-0" onClick={() => setFPassword(generatePassword())}>توليد</Button>
                    </div>
                  </div>
                </div>

                {presetKey === "CUSTOM" && (
                  <div className="flex flex-wrap gap-2">
                    {roles.map((r) => (
                      <label key={r.code} className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs cursor-pointer ${customRoles.includes(r.code) ? "bg-primary text-primary-foreground border-primary" : "bg-background"}`}>
                        <input type="checkbox" className="sr-only" checked={customRoles.includes(r.code)} onChange={() => toggleCustomRole(r.code)} />
                        <ShieldCheck className="w-3 h-3" /> {r.name}
                      </label>
                    ))}
                  </div>
                )}

                <div className="flex gap-2">
                  <Button type="submit" size="sm" disabled={busy}>{busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} إنشاء الحساب</Button>
                  <Button type="button" variant="outline" size="sm" onClick={() => setShowAdd(false)}>إلغاء</Button>
                </div>
              </form>
            )}

            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المستخدم</TableHead>
                    <TableHead>الأدوار</TableHead>
                    <TableHead>الفرع</TableHead>
                    <TableHead>الهاتف</TableHead>
                    <TableHead>آخر دخول</TableHead>
                    <TableHead>الحالة</TableHead>
                    {canUsersEdit && <TableHead className="text-left">إجراءات</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(users ?? []).map((u) => (
                    <TableRow key={u.id}>
                      <TableCell>
                        <div className="font-medium">{u.full_name}</div>
                        <div className="text-xs text-muted-foreground font-mono" dir="ltr">{u.username}</div>
                      </TableCell>
                      <TableCell className="flex flex-wrap gap-1">
                        {u.roles.map((r) => <Badge key={r.code} variant="secondary" className="text-[10px]">{r.name}</Badge>)}
                      </TableCell>
                      <TableCell className="text-xs">{u.branch ?? "—"}</TableCell>
                      <TableCell className="text-xs" dir="ltr">{u.phone ?? "—"}</TableCell>
                      <TableCell className="text-xs">{u.last_login_at ? formatDateTime(u.last_login_at) : "لم يدخل بعد"}</TableCell>
                      <TableCell>
                        <Badge variant={u.is_active ? "default" : "destructive"} className="text-[10px]">{u.is_active ? "نشط" : "معطل"}</Badge>
                      </TableCell>
                      {canUsersEdit && (
                        <TableCell className="text-left">
                          <div className="inline-flex gap-1">
                            <Button variant="ghost" size="sm" className="h-7 px-2" title="تصفير كلمة المرور" onClick={() => { setResetTarget(u); setResetPassword(generatePassword()); }}>
                              <KeyRound className="w-3.5 h-3.5" />
                            </Button>
                            <Button variant="ghost" size="sm" className="h-7 px-2" title="تعديل" onClick={() => openEdit(u)}>
                              <Settings2 className="w-3.5 h-3.5" />
                            </Button>
                            <Button variant="ghost" size="sm" className="h-7 px-2" title={u.is_active ? "تعطيل" : "تفعيل"} onClick={() => toggleActive(u)} disabled={u.username === session.user.username}>
                              {u.is_active ? <PowerOff className="w-3.5 h-3.5 text-red-500" /> : <Power className="w-3.5 h-3.5 text-green-600" />}
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                  {users && users.length === 0 && (
                    <TableRow><TableCell colSpan={7} className="text-center text-sm text-muted-foreground py-6">لا مستخدمين بعد</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ═══════════ الفروع ═══════════ */}
      {canBranchesView && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <CardTitle className="text-base flex items-center gap-2"><Building2 className="w-5 h-5 text-primary" /> الفروع ({branches?.length ?? "…"})</CardTitle>
                <CardDescription>كل فرع جديد يجهز آليًا: مستودع رئيسي + صندوق نقدية + مدير بيوزر خاص (اختياري)</CardDescription>
              </div>
              {canBranchesCreate && scopeAll && (
                <Button size="sm" onClick={() => setShowAddBranch((v) => !v)}><Plus className="w-4 h-4" /> إضافة فرع</Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {showAddBranch && (
              <form onSubmit={submitBranch} className="rounded-lg border p-3 space-y-3 bg-muted/30">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div><label className="text-xs text-muted-foreground block mb-1">كود الفرع * <span className="text-[10px]">(إنجليزي قصير)</span></label>
                    <Input className={inputCls} dir="ltr" value={bCode} onChange={(e) => setBCode(e.target.value.toUpperCase())} placeholder="BAS" required /></div>
                  <div><label className="text-xs text-muted-foreground block mb-1">اسم الفرع *</label>
                    <Input className={inputCls} value={bName} onChange={(e) => setBName(e.target.value)} placeholder="فرع أربيل" required /></div>
                  <div><label className="text-xs text-muted-foreground block mb-1">المدينة</label>
                    <Input className={inputCls} value={bCity} onChange={(e) => setBCity(e.target.value)} placeholder="أربيل" /></div>
                  <div><label className="text-xs text-muted-foreground block mb-1">الهاتف</label>
                    <Input className={inputCls} dir="ltr" value={bPhone} onChange={(e) => setBPhone(e.target.value)} placeholder="07xxxxxxxxx" /></div>
                </div>

                <label className="inline-flex items-center gap-2 text-sm cursor-pointer">
                  <input type="checkbox" checked={bWithManager} onChange={(e) => setBWithManager(e.target.checked)} />
                  <ClipboardList className="w-4 h-4 text-primary" /> إنشاء مدير للفرع الآن (يوزر خاص يدخل فورًا)
                </label>

                {bWithManager && (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 rounded-md border p-3">
                    <div><label className="text-xs text-muted-foreground block mb-1">اسم المدير *</label>
                      <Input className={inputCls} value={bMgrName} onChange={(e) => setBMgrName(e.target.value)} placeholder="كريم الفرع" /></div>
                    <div><label className="text-xs text-muted-foreground block mb-1">اسم المستخدم *</label>
                      <Input className={inputCls} dir="ltr" value={bMgrUser} onChange={(e) => setBMgrUser(e.target.value)} placeholder="erbil.manager" /></div>
                    <div><label className="text-xs text-muted-foreground block mb-1">كلمة المرور</label>
                      <div className="flex gap-2">
                        <Input className={inputCls} dir="ltr" value={bMgrPass} onChange={(e) => setBMgrPass(e.target.value)} />
                        <Button type="button" variant="outline" size="sm" className="h-9 shrink-0" onClick={() => setBMgrPass(generatePassword())}>توليد</Button>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button type="submit" size="sm" disabled={busy}>{busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} إنشاء الفرع</Button>
                  <Button type="button" variant="outline" size="sm" onClick={() => setShowAddBranch(false)}>إلغاء</Button>
                </div>
              </form>
            )}

            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الفرع</TableHead>
                    <TableHead>المدينة</TableHead>
                    <TableHead>الهاتف</TableHead>
                    <TableHead>المستخدمون</TableHead>
                    <TableHead>المستودعات</TableHead>
                    <TableHead>الفواتير</TableHead>
                    <TableHead>الحالة</TableHead>
                    {canBranchesEdit && <TableHead className="text-left">إجراءات</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(branches ?? []).map((b) => (
                    <TableRow key={b.id}>
                      <TableCell>
                        <div className="font-medium">{b.name}</div>
                        <div className="text-xs text-muted-foreground font-mono" dir="ltr">{b.code}</div>
                      </TableCell>
                      <TableCell className="text-xs">{b.city ?? "—"}</TableCell>
                      <TableCell className="text-xs" dir="ltr">{b.phone ?? "—"}</TableCell>
                      <TableCell className="text-sm">{b.users_count}</TableCell>
                      <TableCell className="text-sm">{b.warehouses_count}</TableCell>
                      <TableCell className="text-sm">{b.invoices_count}</TableCell>
                      <TableCell><Badge variant={b.is_active ? "default" : "destructive"} className="text-[10px]">{b.is_active ? "نشط" : "معطل"}</Badge></TableCell>
                      {canBranchesEdit && (
                        <TableCell className="text-left">
                          <Button variant="ghost" size="sm" className="h-7 px-2" title={b.is_active ? "تعطيل الفرع" : "تفعيل الفرع"} onClick={() => toggleBranch(b)}>
                            {b.is_active ? <PowerOff className="w-3.5 h-3.5 text-red-500" /> : <Power className="w-3.5 h-3.5 text-green-600" />}
                          </Button>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                  {branches && branches.length === 0 && (
                    <TableRow><TableCell colSpan={8} className="text-center text-sm text-muted-foreground py-6">لا فروع بعد</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ═══════════ تصفير كلمة المرور ═══════════ */}
      {resetTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setResetTarget(null)}>
          <Card className="w-full max-w-sm" onClick={(e) => e.stopPropagation()}>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2"><KeyRound className="w-5 h-5 text-primary" /> تصفير كلمة المرور</CardTitle>
              <CardDescription>{resetTarget.full_name} ({resetTarget.username})</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={submitReset} className="space-y-3">
                <div className="flex gap-2">
                  <Input className={inputCls} dir="ltr" value={resetPassword} onChange={(e) => setResetPassword(e.target.value)} required />
                  <Button type="button" variant="outline" size="sm" className="h-9 shrink-0" onClick={() => setResetPassword(generatePassword())}>توليد</Button>
                </div>
                <div className="flex gap-2">
                  <Button type="submit" size="sm" className="flex-1" disabled={busy}>حفظ</Button>
                  <Button type="button" variant="outline" size="sm" className="flex-1" onClick={() => setResetTarget(null)}>إلغاء</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}

      {/* ═══════════ تعديل مستخدم ═══════════ */}
      {editTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setEditTarget(null)}>
          <Card className="w-full max-w-md" onClick={(e) => e.stopPropagation()}>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2"><Settings2 className="w-5 h-5 text-primary" /> تعديل المستخدم</CardTitle>
              <CardDescription dir="ltr" className="font-mono">{editTarget.username}</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={submitEdit} className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="text-xs text-muted-foreground block mb-1">الاسم</label>
                    <Input className={inputCls} value={eName} onChange={(e) => setEName(e.target.value)} required /></div>
                  <div><label className="text-xs text-muted-foreground block mb-1">الهاتف</label>
                    <Input className={inputCls} dir="ltr" value={ePhone} onChange={(e) => setEPhone(e.target.value)} /></div>
                  <div className="col-span-2">
                    <label className="text-xs text-muted-foreground block mb-1">الفرع</label>
                    <select className={inputCls} value={String(eBranchId)} onChange={(e) => setEBranchId(e.target.value === "" ? "" : Number(e.target.value))}>
                      <option value="">— بلا فرع (كل الفروع) —</option>
                      {(branches ?? []).map((b) => <option key={b.id} value={b.id}>{b.name} ({b.code})</option>)}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground block mb-1">الأدوار</label>
                  <div className="flex flex-wrap gap-2">
                    {roles.map((r) => (
                      <label key={r.code} className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs cursor-pointer ${eRoles.includes(r.code) ? "bg-primary text-primary-foreground border-primary" : "bg-background"}`}>
                        <input type="checkbox" className="sr-only" checked={eRoles.includes(r.code)} onChange={() => setERoles((p) => (p.includes(r.code) ? p.filter((c) => c !== r.code) : [...p, r.code]))} />
                        {r.name}
                      </label>
                    ))}
                  </div>
                </div>
                <p className="text-[11px] text-muted-foreground">تغيير الأدوار يعيد ربطها بالفرع المحدد أعلاه (نطاق الرؤية)</p>
                <div className="flex gap-2">
                  <Button type="submit" size="sm" className="flex-1" disabled={busy || eRoles.length === 0}>حفظ</Button>
                  <Button type="button" variant="outline" size="sm" className="flex-1" onClick={() => setEditTarget(null)}>إلغاء</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}

      {/* ملاحظة الوصول للمستودعات */}
      {warehouses.length > 0 && (
        <p className="text-[11px] text-muted-foreground">
          ملاحظة: عند إنشاء مستخدم مرتبط بفرع يُمنح وصولًا آليًا إلى كل مستودعات ذلك الفرع، والمندوب يُنشأ له مخزن سيارة خاص مستقل.
        </p>
      )}
    </div>
  );
}
