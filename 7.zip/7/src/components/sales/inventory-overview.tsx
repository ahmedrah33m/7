"use client";

// =====================================================================
// §66 — قسم «حالة المخزون» داخل النظرة العامة (Overview).
// يحوّل الجرد والتكلفة إلى بطاقات ومؤشرات مباشرة — كل الأرقام حية من
// /api/v1/inventory/valuation (لا أرقام ثابتة):
//   · 8 بطاقات: الكمية/قيمة التكلفة/القيمة البيعية/الربح المتوقع
//     + COGS الشهر + منخفض/نافد/راكد
//   · Widgets: توزيع المخزون حسب الموقع · قيمة مخزون المندوبين ·
//     توزيع القيمة حسب النوع · فروقات الجرد والتسويات · الأعلى قيمة ·
//     الأكثر حركة · المواد الراكدة · أين توجد المادة؟
// =====================================================================

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { formatIQD } from "@/lib/utils";
import { KpiCard } from "@/components/sales/kpi-card";
import {
  AlertTriangle, ArrowDownRight, ArrowUpRight, Boxes, CircleDollarSign,
  MapPin, PackageMinus, PackageSearch, RefreshCw, Search, Timer, TrendingUp, Truck,
} from "lucide-react";

interface Valuation {
  totals: { total_qty: number; cost_value: number; sales_value: number; potential_profit: number; items_count: number };
  health: { low_stock: number; out_of_stock: number; dead_stock: { count: number; value: number } };
  cogs: { revenue: number; returns_value: number; net_sales: number; cogs: number; returned_cogs: number; gross_profit: number; margin_pct: number };
  by_location: { warehouse_id: number; code: string; name: string; type: string; branch: string; qty: number; cost_value: number; sales_value: number; pct: number }[];
  by_type: { type: string; label: string; qty: number; cost_value: number; pct: number }[];
  rep_inventory: { items: { warehouse_id: number; name: string; branch: string; qty: number; cost_value: number; sales_value: number }[]; total_value: number };
  adjustments: { count: number; surplus_qty: number; surplus_value: number; shortage_qty: number; shortage_value: number; net_value: number; recent: { id: number; direction: string; qty: number; value: number; product: string; unit: string; warehouse: string; note: string | null; at: string }[] };
  top_value_items: { id: number; code: string; name: string; unit: string; qty: number; avg_cost: number; cost_value: number; sales_value: number; pct: number }[];
  most_moving_items: { id: number; code: string; name: string; unit: string; out_qty: number }[];
  dead_items: { id: number; code: string; name: string; unit: string; qty: number; value: number; last_out: string | null; days_since: number | null }[];
  meta: { cost_method: string; dead_days: number; generated_at: string; warehouses_scoped: number };
}

interface WhereItem {
  product: {
    id: number; code: string; name: string; unit: string; salePrice: number; costPrice: number;
    avg_cost: number | null; last_cost: number | null; applicable_cost: number;
    locations: { warehouse: string; warehouse_type: string; qty: number; cost_value: number }[];
    totals: { qty: number; cost_value: number; sales_value: number; potential_profit: number };
  } | null;
}

function fmtQty(n: number): string {
  return new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(n ?? 0);
}

export function InventoryOverviewSection() {
  const [data, setData] = React.useState<Valuation | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [searchQ, setSearchQ] = React.useState("");
  const [searching, setSearching] = React.useState(false);
  const [whereResult, setWhereResult] = React.useState<WhereItem["product"] | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    const { body } = await api<Valuation>("/api/v1/inventory/valuation");
    if (body.success && body.data) setData(body.data);
    else toast.error(body.message ?? "تعذر تحميل مؤشرات المخزون");
    setLoading(false);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  // «أين توجد المادة؟» — بحث بالاسم أو الكود ثم أول تطابق يُفصَّل حسب الموقع
  const runSearch = async () => {
    const q = searchQ.trim();
    if (!q) return;
    setSearching(true);
    setWhereResult(null);
    const { body } = await api<{ id: number; code: string; name: string }[]>(
      `/api/v1/products?per_page=1&q=${encodeURIComponent(q)}`,
    );
    const hit = body.success && Array.isArray(body.data) ? body.data[0] : null;
    if (!hit) { toast.info("لا منتج مطابق"); setSearching(false); return; }
    const w = await api<WhereItem>(`/api/v1/inventory/valuation?product_id=${hit.id}`);
    if (w.body.success && w.body.data?.product) setWhereResult(w.body.data.product);
    else toast.error(w.body.message ?? "تعذر جلب تفصيل المواقع");
    setSearching(false);
  };

  const t = data?.totals;
  const c = data?.cogs;
  const h = data?.health;

  return (
    <div className="space-y-4">
      {/* رأس القسم */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h3 className="text-lg font-bold flex items-center gap-2">
            <Boxes className="w-5 h-5 text-primary" /> حالة المخزون
            <Badge variant="outline" className="text-[10px]">{data?.meta.cost_method === "WEIGHTED_AVERAGE" ? "متوسط مرجح" : data?.meta.cost_method === "STANDARD" ? "تكلفة معيارية" : data?.meta.cost_method ?? "…"}</Badge>
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            جرد وتقييم وتكلفة — أرقام حية من دفتر الحركات ({data?.meta.warehouses_scoped ?? 0} مستودعًا في نطاقك)
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading}>
          <RefreshCw className={"w-4 h-4" + (loading ? " animate-spin" : "")} /> تحديث
        </Button>
      </div>

      {/* البطاقات الثماني (§66.1 / §66.26) — لون مميز لكل مؤشر */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard tone="blue" icon={<Boxes className="w-5 h-5" />} label="إجمالي المخزون" value={`${fmtQty(t?.total_qty ?? 0)} وحدة`} sub={`${t?.items_count ?? 0} مادة موجودة`} />
        <KpiCard tone="cyan" icon={<CircleDollarSign className="w-5 h-5" />} label="قيمة المخزون (تكلفة)" value={formatIQD(t?.cost_value ?? 0)} sub="بالتكلفة القابلة للتطبيق" />
        <KpiCard tone="indigo" icon={<TrendingUp className="w-5 h-5" />} label="القيمة البيعية" value={formatIQD(t?.sales_value ?? 0)} sub="بسعر البيع الحالي" />
        <KpiCard tone="emerald" icon={<TrendingUp className="w-5 h-5" />} label="الربح المتوقع" value={formatIQD(t?.potential_profit ?? 0)} sub="القيمة البيعية − التكلفة" />
        <KpiCard tone="violet" icon={<CircleDollarSign className="w-5 h-5" />} label="تكلفة البضاعة المباعة (الشهر)" value={formatIQD(c?.cogs ?? 0)} sub={`صافي المبيعات ${formatIQD(c?.net_sales ?? 0)} · ربح ${formatIQD(c?.gross_profit ?? 0)} (${c?.margin_pct ?? 0}%)`} />
        <KpiCard tone="amber" icon={<AlertTriangle className="w-5 h-5" />} label="منخفض المخزون" value={`${h?.low_stock ?? 0} مادة`} sub="بلغت أو تحت الحد الأدنى" />
        <KpiCard tone="rose" icon={<PackageMinus className="w-5 h-5" />} label="نافد" value={`${h?.out_of_stock ?? 0} مادة`} sub="رصيدها صفر أو لا يوجد" />
        <KpiCard tone="slate" icon={<Timer className="w-5 h-5" />} label={`راكد (${data?.meta.dead_days ?? 90} يوم)`} value={`${h?.dead_stock.count ?? 0} مادة`} sub={`قيمة مجمدة ${formatIQD(h?.dead_stock.value ?? 0)}`} />
      </div>

      {/* الصف الأول: توزيع حسب الموقع + المندوبون */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base"><MapPin className="w-4 h-4 text-primary" /> توزيع المخزون حسب الموقع</CardTitle>
            <CardDescription>الكمية والقيمة والنسبة لكل مستودع (§66.2)</CardDescription>
          </CardHeader>
          <CardContent>
            {!data?.by_location.length ? (
              <Empty text="لا أرصدة في مستودعات نطاقك بعد" />
            ) : (
              <div className="space-y-3">
                {data.by_location.map((w) => (
                  <div key={w.warehouse_id}>
                    <div className="flex items-center justify-between text-sm">
                      <div className="min-w-0">
                        <span className="font-medium truncate">{w.name}</span>
                        <span className="text-[10px] text-muted-foreground mr-2">({w.branch})</span>
                      </div>
                      <span className="shrink-0 font-semibold" dir="ltr">{fmtQty(w.qty)} · {formatIQD(w.cost_value)}</span>
                    </div>
                    <div className="h-2 rounded-full bg-muted mt-1 overflow-hidden">
                      <div className="h-full bg-primary rounded-full" style={{ width: `${Math.min(w.pct, 100)}%` }} />
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">النسبة {w.pct}% · بيعية {formatIQD(w.sales_value)}</div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base"><Truck className="w-4 h-4 text-primary" /> قيمة مخزون المندوبين (§66.27)</CardTitle>
              <CardDescription>من مخازن السيارات الفعلية — الإجمالي {formatIQD(data?.rep_inventory.total_value ?? 0)}</CardDescription>
            </CardHeader>
            <CardContent>
              {!data?.rep_inventory.items.length ? (
                <Empty text="لا مخازن مندوبين فيها أرصدة" />
              ) : (
                <div className="space-y-2">
                  {data.rep_inventory.items.map((r) => (
                    <div key={r.warehouse_id} className="flex items-center justify-between rounded-lg border px-3 py-2">
                      <div className="min-w-0">
                        <div className="text-sm font-medium truncate">{r.name}</div>
                        <div className="text-[11px] text-muted-foreground">{r.branch} · {fmtQty(r.qty)} وحدة · بيعية {formatIQD(r.sales_value)}</div>
                      </div>
                      <span className="text-sm font-semibold shrink-0" dir="ltr">{formatIQD(r.cost_value)}</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base"><PackageSearch className="w-4 h-4 text-primary" /> توزيع قيمة المخزون حسب النوع (§66.28)</CardTitle>
            </CardHeader>
            <CardContent>
              {!data?.by_type.length ? (
                <Empty text="لا بيانات" />
              ) : (
                <div className="space-y-2">
                  {data.by_type.map((r) => (
                    <div key={r.type} className="flex items-center gap-3">
                      <Badge variant="navy" className="text-[10px] w-32 shrink-0 justify-center">{r.label}</Badge>
                      <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: `${Math.min(r.pct, 100)}%` }} />
                      </div>
                      <span className="text-xs font-semibold shrink-0 w-28 text-left" dir="ltr">{formatIQD(r.cost_value)} · {r.pct}%</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* الصف الثاني: فروقات الجرد + أعلى قيمة + الأكثر حركة + الراكد */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base"><AlertTriangle className="w-4 h-4 text-amber-500" /> فروقات الجرد والتسويات (§66.14–66.16)</CardTitle>
            <CardDescription>ما قُيّد فعليًا كتسويات جرد — {data?.adjustments.count ?? 0} حركة</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-2 mb-3">
              <MiniStat label="زيادة" value={fmtQty(data?.adjustments.surplus_qty ?? 0)} sub={formatIQD(data?.adjustments.surplus_value ?? 0)} tone="text-emerald-600" icon={<ArrowUpRight className="w-3.5 h-3.5" />} />
              <MiniStat label="عجز" value={fmtQty(data?.adjustments.shortage_qty ?? 0)} sub={formatIQD(data?.adjustments.shortage_value ?? 0)} tone="text-red-600" icon={<ArrowDownRight className="w-3.5 h-3.5" />} />
              <MiniStat label="الصافي" value={formatIQD(data?.adjustments.net_value ?? 0)} sub="قيمة الفروقات" tone={(data?.adjustments.net_value ?? 0) < 0 ? "text-red-600" : "text-emerald-600"} icon={<CircleDollarSign className="w-3.5 h-3.5" />} />
            </div>
            {!data?.adjustments.recent.length ? (
              <Empty text="لا تسويات جرد مسجلة — الفروقات صفر" />
            ) : (
              <div className="space-y-1.5">
                {data.adjustments.recent.map((a) => (
                  <div key={a.id} className="flex items-center justify-between text-xs rounded border px-2.5 py-1.5">
                    <span className="truncate">{a.direction === "IN" ? "زيادة" : "عجز"} · {a.product} <span className="text-muted-foreground">({a.warehouse})</span></span>
                    <span className="shrink-0 font-mono" dir="ltr">{a.direction === "IN" ? "+" : "−"}{fmtQty(a.qty)} {a.unit}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base"><Search className="w-4 h-4 text-primary" /> أين توجد المادة؟ (§66.4)</CardTitle>
            <CardDescription>ابحث باسم المنتج أو كوده لترى مواقعه وتكلفته في كل مستودع</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Input
                value={searchQ}
                onChange={(e) => setSearchQ(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && runSearch()}
                placeholder="مثال: شامبو طبي أو P-001"
              />
              <Button onClick={runSearch} disabled={searching || !searchQ.trim()}>
                {searching ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />} بحث
              </Button>
            </div>
            {whereResult && (
              <div className="mt-3 space-y-2">
                <div className="text-sm font-semibold">{whereResult.name} <span dir="ltr" className="font-mono text-[11px] text-muted-foreground">{whereResult.code}</span></div>
                {whereResult.locations.map((l, i) => (
                  <div key={i} className="flex items-center justify-between rounded border px-3 py-1.5 text-sm">
                    <span>{l.warehouse}</span>
                    <span className="font-semibold" dir="ltr">{fmtQty(l.qty)} · {formatIQD(l.cost_value)}</span>
                  </div>
                ))}
                <div className="flex items-center justify-between rounded bg-primary/5 border border-primary/20 px-3 py-2 text-sm font-semibold">
                  <span>الإجمالي</span>
                  <span dir="ltr">{fmtQty(whereResult.totals.qty)} · تكلفة {formatIQD(whereResult.totals.cost_value)}</span>
                </div>
                <div className="text-[11px] text-muted-foreground">
                  متوسط التكلفة {formatIQD(whereResult.avg_cost ?? whereResult.applicable_cost)} · آخر تكلفة شراء {whereResult.last_cost ? formatIQD(whereResult.last_cost) : "—"} · القيمة البيعية {formatIQD(whereResult.totals.sales_value)}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-base flex items-center gap-2"><CircleDollarSign className="w-4 h-4 text-primary" /> المواد الأعلى قيمة</CardTitle></CardHeader>
          <CardContent>
            {!data?.top_value_items.length ? <Empty text="لا مخزون" /> : (
              <div className="space-y-2">
                {data.top_value_items.slice(0, 5).map((p, i) => (
                  <ItemRow key={p.id} rank={i + 1} name={p.name} code={p.code} right={formatIQD(p.cost_value)} sub={`${fmtQty(p.qty)} ${p.unit} · متوسط ${formatIQD(p.avg_cost)} · ${p.pct}%`} />
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-base flex items-center gap-2"><TrendingUp className="w-4 h-4 text-primary" /> الأكثر حركة (30 يومًا)</CardTitle></CardHeader>
          <CardContent>
            {!data?.most_moving_items.length ? <Empty text="لا حركات خارجة آخر 30 يومًا" /> : (
              <div className="space-y-2">
                {data.most_moving_items.slice(0, 5).map((p, i) => (
                  <ItemRow key={p.id} rank={i + 1} name={p.name} code={p.code} right={`${fmtQty(p.out_qty)} ${p.unit}`} sub="إجمالي الخارج" />
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-base flex items-center gap-2"><Timer className="w-4 h-4 text-amber-500" /> المواد الراكدة ({data?.meta.dead_days ?? 90} يومًا)</CardTitle></CardHeader>
          <CardContent>
            {!data?.dead_items.length ? <Empty text="لا مواد راكدة — ممتاز" /> : (
              <div className="space-y-2">
                {data.dead_items.slice(0, 5).map((p) => (
                  <ItemRow key={p.id} name={p.name} code={p.code} right={formatIQD(p.value)} sub={`${fmtQty(p.qty)} ${p.unit} · آخر خروج: ${p.days_since != null ? `قبل ${p.days_since} يومًا` : "لا خروج مسجل"}`} />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return <div className="py-6 text-center text-sm text-muted-foreground">{text}</div>;
}

function ItemRow({ rank, name, code, right, sub }: { rank?: number; name: string; code: string; right: string; sub: string }) {
  return (
    <div className="flex items-center gap-3">
      {rank != null && (
        <div className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center shrink-0">{rank}</div>
      )}
      <div className="min-w-0 flex-1">
        <div className="text-sm font-medium truncate">{name} <span dir="ltr" className="font-mono text-[10px] text-muted-foreground">{code}</span></div>
        <div className="text-[11px] text-muted-foreground truncate">{sub}</div>
      </div>
      <div className="text-sm font-semibold shrink-0" dir="ltr">{right}</div>
    </div>
  );
}

function MiniStat({ label, value, sub, tone, icon }: { label: string; value: string; sub: string; tone: string; icon: React.ReactNode }) {
  return (
    <div className="rounded-lg border px-3 py-2">
      <div className={`flex items-center gap-1 text-[11px] font-medium ${tone}`}>{icon}{label}</div>
      <div className="text-sm font-bold mt-1" dir="ltr">{value}</div>
      <div className="text-[10px] text-muted-foreground" dir="ltr">{sub}</div>
    </div>
  );
}
