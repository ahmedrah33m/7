"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { formatDateTime, formatIQD } from "@/lib/utils";
import { ClipboardCheck, Loader2, Save, Send, Ban, RefreshCw } from "lucide-react";

interface Warehouse { id: number; code: string; name: string }

interface StocktakeRow {
  id: number;
  number: string;
  status: "DRAFT" | "POSTED" | "CANCELLED";
  warehouse: { code: string; name: string };
  take_date: string;
  lines_count: number;
  diff_count: number;
  diff_value: number;
  notes: string | null;
  created_by: string;
  posted_at: string | null;
}

interface StocktakeDetail {
  id: number;
  number: string;
  status: string;
  warehouse: { code: string; name: string };
  diff_count: number;
  diff_value: number;
  lines: {
    product_id: number;
    code: string;
    product: string;
    unit: string;
    system_qty: number;
    counted_qty: number;
    diff_qty: number;
    unit_cost: number;
  }[];
}

const STATUS_AR: Record<string, { label: string; variant: "secondary" | "default" | "success" | "destructive" }> = {
  DRAFT: { label: "مسودة", variant: "secondary" },
  POSTED: { label: "مُرحّل", variant: "success" },
  CANCELLED: { label: "ملغى", variant: "destructive" },
};

export function StocktakeTab({
  warehouses,
  canCreate,
  canPost,
}: {
  warehouses: Warehouse[];
  canCreate: boolean;
  canPost: boolean;
}) {
  const [rows, setRows] = React.useState<StocktakeRow[] | null>(null);
  const [detail, setDetail] = React.useState<StocktakeDetail | null>(null);
  const [counts, setCounts] = React.useState<Record<number, string>>({});
  const [busy, setBusy] = React.useState(false);

  const load = React.useCallback(async () => {
    const r = await api<StocktakeRow[]>("/api/v1/inventory/stocktakes?per_page=30");
    if (r.body.success && r.body.data) setRows(r.body.data);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  async function openDetail(id: number) {
    setDetail(null);
    const r = await api<StocktakeDetail>(`/api/v1/inventory/stocktakes/${id}`);
    if (r.body.success && r.body.data) {
      setDetail(r.body.data);
      const c: Record<number, string> = {};
      for (const l of r.body.data.lines) c[l.product_id] = String(l.counted_qty);
      setCounts(c);
    } else toast.error(r.body.message ?? "فشل تحميل الجرد");
  }

  async function createSheet(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const wh = Number(fd.get("warehouse_id"));
    if (!wh) return toast.error("اختر المستودع");
    setBusy(true);
    try {
      const { body } = await api("/api/v1/inventory/stocktakes", {
        method: "POST",
        body: JSON.stringify({ warehouse_id: wh, notes: fd.get("notes") || undefined }),
      });
      if (body.success) {
        toast.success(`فُتح أمر الجرد ${(body.data as { number: string }).number}`);
        await load();
        await openDetail((body.data as { id: number }).id);
      } else toast.error(body.message ?? "فشل فتح الجرد");
    } finally {
      setBusy(false);
    }
  }

  async function saveCounts() {
    if (!detail) return;
    const payload = Object.entries(counts)
      .map(([pid, v]) => ({ product_id: Number(pid), counted_qty: Number(v) }))
      .filter((c) => Number.isFinite(c.counted_qty) && c.counted_qty >= 0);
    if (!payload.length) return toast.error("أدخل الكميات المعدودة");
    setBusy(true);
    try {
      const { body } = await api<StocktakeDetail>("/api/v1/inventory/stocktakes", {
        method: "PATCH",
        body: JSON.stringify({ id: detail.id, counts: payload }),
      });
      if (body.success) {
        toast.success("حُفظت الكميات المعدودة");
        setDetail(body.data ?? null);
        await load();
      } else toast.error(body.message ?? "فشل الحفظ");
    } finally {
      setBusy(false);
    }
  }

  async function act(id: number, action: "post" | "cancel") {
    setBusy(true);
    try {
      const { body } = await api(`/api/v1/inventory/stocktakes/${id}`, {
        method: "POST",
        body: JSON.stringify({ action }),
      });
      if (body.success) {
        toast.success(action === "post" ? "رُحّل الجرد — حُدّثت الأرصدة" : "أُلغي أمر الجرد");
        setDetail(null);
        await load();
      } else toast.error(body.message ?? "فشلت العملية");
    } finally {
      setBusy(false);
    }
  }

  const dirtyDiffs = detail
    ? detail.lines.reduce((n, l) => {
        const v = Number(counts[l.product_id]);
        return n + (Number.isFinite(v) && Math.abs(v - l.system_qty) > 0.0001 ? 1 : 0);
      }, 0)
    : 0;

  return (
    <div className="space-y-4">
      {canCreate && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base"><ClipboardCheck className="w-4 h-4" /> فتح أمر جرد جديد</CardTitle>
            <CardDescription>يُلتقط رصيد النظام الحالي للمستودع كمسودة — عدّ فعليًا ثم أدخل الكميات ثم رحّل</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={createSheet} className="flex flex-wrap gap-2 items-end">
              <div className="space-y-1">
                <label className="text-xs text-muted-foreground">المستودع</label>
                <select name="warehouse_id" className="h-9 rounded-md border bg-background px-3 text-sm min-w-48" defaultValue={warehouses[0]?.id ?? ""}>
                  {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
                </select>
              </div>
              <div className="space-y-1 flex-1 min-w-48">
                <label className="text-xs text-muted-foreground">ملاحظات (اختياري)</label>
                <Input name="notes" placeholder="مثال: جرد نهاية الشهر" className="h-9" />
              </div>
              <Button type="submit" disabled={busy || !warehouses.length}>
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <ClipboardCheck className="w-4 h-4" />} فتح الجرد
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      {detail && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  {detail.number}
                  <Badge variant={STATUS_AR[detail.status]?.variant ?? "secondary"}>{STATUS_AR[detail.status]?.label ?? detail.status}</Badge>
                </CardTitle>
                <CardDescription>{detail.warehouse.name} — فرق: {detail.diff_count} · قيمة الفرق: {formatIQD(detail.diff_value)}</CardDescription>
              </div>
              <div className="flex gap-2">
                {detail.status === "DRAFT" && (
                  <>
                    <Button size="sm" variant="outline" onClick={saveCounts} disabled={busy}>
                      {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} حفظ العدّ
                    </Button>
                    {canPost && (
                      <Button size="sm" onClick={() => act(detail.id, "post")} disabled={busy}>
                        <Send className="w-4 h-4" /> ترحيل الفروقات
                      </Button>
                    )}
                    {canPost && (
                      <Button size="sm" variant="destructive" onClick={() => act(detail.id, "cancel")} disabled={busy}>
                        <Ban className="w-4 h-4" /> إلغاء
                      </Button>
                    )}
                  </>
                )}
                <Button size="sm" variant="ghost" onClick={() => setDetail(null)}>إغلاق</Button>
              </div>
            </div>
            {detail.status === "DRAFT" && dirtyDiffs > 0 && (
              <p className="text-xs text-amber-600 mt-1">⚠ عدّلت {dirtyDiffs} بندًا — احفظ العدّ قبل الترحيل</p>
            )}
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>المنتج</TableHead>
                  <TableHead className="text-left">رصيد النظام</TableHead>
                  <TableHead className="text-left w-28">العدّ الفعلي</TableHead>
                  <TableHead className="text-left">الفرق</TableHead>
                  <TableHead className="text-left">قيمة الفرق</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {detail.lines.map((l) => {
                  const counted = Number(counts[l.product_id]);
                  const diff = Number.isFinite(counted) ? counted - l.system_qty : l.diff_qty;
                  return (
                    <TableRow key={l.product_id}>
                      <TableCell className="text-sm">{l.product} <span className="text-[10px] text-muted-foreground" dir="ltr">{l.code}</span></TableCell>
                      <TableCell className="text-left" dir="ltr">{l.system_qty} {l.unit}</TableCell>
                      <TableCell>
                        <Input
                          className="h-8 text-left"
                          dir="ltr"
                          type="number"
                          step="any"
                          min="0"
                          disabled={detail.status !== "DRAFT"}
                          value={counts[l.product_id] ?? ""}
                          onChange={(e) => setCounts((p) => ({ ...p, [l.product_id]: e.target.value }))}
                        />
                      </TableCell>
                      <TableCell className="text-left">
                        {Math.abs(diff) > 0.0001 ? (
                          <Badge variant={diff > 0 ? "success" : "destructive"} className="text-[10px]" dir="ltr">
                            {diff > 0 ? "+" : ""}{Math.round(diff * 1000) / 1000}
                          </Badge>
                        ) : "—"}
                      </TableCell>
                      <TableCell className="text-left" dir="ltr">{formatIQD(Math.round(diff * l.unit_cost * 100) / 100)}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">أوامر الجرد</CardTitle>
            <Button size="sm" variant="ghost" onClick={load}><RefreshCw className="w-4 h-4" /></Button>
          </div>
        </CardHeader>
        <CardContent>
          {rows == null ? (
            <div className="py-8 text-center text-muted-foreground"><Loader2 className="w-5 h-5 animate-spin inline" /></div>
          ) : rows.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">لا أوامر جرد بعد — افتح أمرًا جديدًا</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الرقم</TableHead>
                  <TableHead>المستودع</TableHead>
                  <TableHead className="text-left">الحالة</TableHead>
                  <TableHead className="text-left">بنود</TableHead>
                  <TableHead className="text-left">فروقات</TableHead>
                  <TableHead className="text-left">قيمة الفرق</TableHead>
                  <TableHead className="text-left">التاريخ</TableHead>
                  <TableHead />
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.id} className="cursor-pointer" onClick={() => openDetail(r.id)}>
                    <TableCell className="font-mono text-xs" dir="ltr">{r.number}</TableCell>
                    <TableCell className="text-sm">{r.warehouse.name}</TableCell>
                    <TableCell className="text-left"><Badge variant={STATUS_AR[r.status]?.variant ?? "secondary"} className="text-[10px]">{STATUS_AR[r.status]?.label ?? r.status}</Badge></TableCell>
                    <TableCell className="text-left" dir="ltr">{r.lines_count}</TableCell>
                    <TableCell className="text-left" dir="ltr">{r.diff_count}</TableCell>
                    <TableCell className="text-left" dir="ltr">{formatIQD(r.diff_value)}</TableCell>
                    <TableCell className="text-left text-xs text-muted-foreground" dir="ltr">{formatDateTime(r.take_date)}</TableCell>
                    <TableCell><Button size="sm" variant="ghost">عرض</Button></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
