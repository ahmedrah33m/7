"use client";

import * as React from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/lib/client-api";
import { Decimal, dec, moneyR, num as decNum, qtyR, sumOf } from "@/lib/decimal";
import { formatDateTime, formatIQD } from "@/lib/utils";
import { ArrowDownToLine, ArrowUpFromLine, HandCoins, ReceiptText, Wallet, TrendingUp, TrendingDown, AlertTriangle, Activity, BarChart3, Bell } from "lucide-react";

interface Cashbox { id: number; code: string; name: string; balance: number; is_active: boolean; currency?: string; type?: string }
interface TxRow {
  id: number;
  direction: "IN" | "OUT";
  category: string;
  amount: number;
  balance_after: number;
  cashbox: { code: string; name: string };
  customer: { id: string; name: string } | null;
  supplier: { id: string; name: string } | null;
  note: string | null;
  created_at: string;
}
interface Party { id: number; name: string; balance: number }

const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";
const CATEGORY_AR: Record<string, string> = {
  COLLECTION: "تحصيل من عميل",
  SUPPLIER_PAYMENT: "سداد لمورد",
  EXPENSE: "مصروف",
  OPENING: "رصيد افتتاحي",
  REFUND: "رد نقدي (مرتجع)",
  OTHER: "أخرى",
};

type OpKind = "collection" | "supplier" | "expense";

export function FinanceTab({ canPay, canExpense }: { canPay: boolean; canExpense: boolean }) {
  const [boxes, setBoxes] = React.useState<Cashbox[] | null>(null);
  const [txs, setTxs] = React.useState<TxRow[] | null>(null);
  const [customers, setCustomers] = React.useState<Party[]>([]);
  const [suppliers, setSuppliers] = React.useState<Party[]>([]);
  const [kind, setKind] = React.useState<OpKind>("collection");
  const [saving, setSaving] = React.useState(false);

  const load = React.useCallback(async () => {
    const [b, t, c, s] = await Promise.all([
      api<Cashbox[]>("/api/v1/finance/cashboxes"),
      api<TxRow[]>("/api/v1/finance/transactions?per_page=25"),
      api<Party[]>("/api/v1/customers?per_page=100"),
      api<Party[]>("/api/v1/suppliers"),
    ]);
    if (b.body.success && b.body.data) setBoxes(b.body.data);
    if (t.body.success && t.body.data) setTxs(t.body.data);
    if (c.body.success && c.body.data) setCustomers(c.body.data);
    if (s.body.success && s.body.data) setSuppliers(s.body.data);
  }, []);

  React.useEffect(() => { load(); }, [load]);

  const totalCash = decNum(moneyR(sumOf(boxes ?? [], (b) => b.balance)));

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSaving(true);
    const fd = new FormData(e.currentTarget);
    const amount = Number(fd.get("amount"));
    try {
      const payload =
        kind === "collection"
          ? {
              kind: "collection",
              customer_id: Number(fd.get("customer_id")),
              cashbox_id: Number(fd.get("cashbox_id")),
              amount,
              note: fd.get("note") || undefined,
            }
          : kind === "supplier"
            ? {
                kind: "supplier",
                supplier_id: Number(fd.get("supplier_id")),
                cashbox_id: Number(fd.get("cashbox_id")),
                amount,
                note: fd.get("note") || undefined,
              }
            : {
                kind: "expense",
                cashbox_id: Number(fd.get("cashbox_id")),
                amount,
                title: String(fd.get("title") ?? "").trim(),
                note: fd.get("note") || undefined,
              };
      const { body } = await api("/api/v1/finance/transactions", { method: "POST", body: JSON.stringify(payload) });
      if (body.success) {
        const d = body.data as { number: string; cashbox?: { balance_after: number } };
        toast.success(`سُجل ✓ ${d.number} — رصيد الصندوق: ${formatIQD(d.cashbox?.balance_after ?? 0)}`);
        (e.target as HTMLFormElement).reset();
        await load();
      } else toast.error(body.message ?? "فشلت العملية");
    } finally {
      setSaving(false);
    }
  }

  // Phase 31-33 — Enhanced KPI computations
  const todayTxs = (txs ?? []).filter((t) => {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    return new Date(t.created_at) >= today;
  });
  const inToday = decNum(moneyR(sumOf(todayTxs.filter((t) => t.direction === "IN"), (t) => dec(t.amount))));
  const outToday = decNum(moneyR(sumOf(todayTxs.filter((t) => t.direction === "OUT"), (t) => dec(t.amount))));
  const netFlow = inToday - outToday;
  const lowBalanceThreshold = 100000; // IQD — Phase 18: low balance alert
  const lowBalanceBoxes = (boxes ?? []).filter((b) => b.balance < lowBalanceThreshold && b.is_active);
  const openBoxesCount = (boxes ?? []).filter((b) => b.is_active).length;

  return (
    <div className="space-y-4">
      {/* Phase 31-33 — Enhanced KPI cards with trends */}
      <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Wallet className="w-4 h-4 text-primary" /> إجمالي النقد</CardTitle></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" dir="ltr">{boxes === null ? "…" : formatIQD(totalCash)}</div>
            <div className="text-xs text-muted-foreground mt-1">{openBoxesCount} صندوق نشط</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><TrendingUp className="w-4 h-4 text-emerald-600" /> مقبوضات اليوم</CardTitle></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-600" dir="ltr">{boxes === null ? "…" : formatIQD(inToday)}</div>
            <div className="text-xs text-muted-foreground mt-1">{todayTxs.filter((t) => t.direction === "IN").length} حركة واردة</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><TrendingDown className="w-4 h-4 text-red-600" /> مدفوعات اليوم</CardTitle></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600" dir="ltr">{boxes === null ? "…" : formatIQD(outToday)}</div>
            <div className="text-xs text-muted-foreground mt-1">{todayTxs.filter((t) => t.direction === "OUT").length} حركة صادرة</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Activity className="w-4 h-4 text-primary" /> صافي التدفق اليوم</CardTitle></CardHeader>
          <CardContent>
            <div className={"text-2xl font-bold " + (netFlow >= 0 ? "text-emerald-600" : "text-red-600")} dir="ltr">
              {netFlow >= 0 ? "+" : ""}{formatIQD(netFlow)}
            </div>
            <div className="text-xs text-muted-foreground mt-1">وارد − صادر</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm">ذمم العملاء</CardTitle></CardHeader>
          <CardContent><div className="text-2xl font-bold text-amber-600" dir="ltr">{boxes === null ? "…" : formatIQD(decNum(moneyR(sumOf(customers, (c) => (dec(c.balance).isPositive() ? c.balance : 0)))))}</div></CardContent>
        </Card>
      </div>

      {/* Phase 42 — Low balance alerts (if any cashbox < threshold) */}
      {lowBalanceBoxes.length > 0 && (
        <Card className="border-amber-300 bg-amber-50/50 dark:bg-amber-950/20">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2 text-amber-700 dark:text-amber-300">
              <Bell className="w-4 h-4" /> تنبيه: رصيد منخفض في {lowBalanceBoxes.length} صندوق
            </CardTitle>
            <CardDescription>الصناديق النشطة برصيد أقل من {formatIQD(lowBalanceThreshold)} — قد تحتاج إيداع نقدي</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {lowBalanceBoxes.map((b) => (
                <div key={b.id} className="flex items-center justify-between p-2 rounded border border-amber-200 bg-background">
                  <div>
                    <div className="text-sm font-medium">{b.name}</div>
                    <div className="text-xs text-muted-foreground font-mono" dir="ltr">{b.code}</div>
                  </div>
                  <div className="text-amber-600 font-bold" dir="ltr">{formatIQD(b.balance)}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Phase 31-33 — Simple cash movement chart (last 7 transactions as bar visualization) */}
      {(txs ?? []).length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><BarChart3 className="w-4 h-4 text-primary" /> حركة النقد — آخر {Math.min(10, (txs ?? []).length)} حركات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end gap-1 h-24">
              {(txs ?? []).slice(0, 10).reverse().map((t, i) => {
                const max = Math.max(...(txs ?? []).slice(0, 10).map((x) => x.amount), 1);
                const heightPct = (t.amount / max) * 100;
                return (
                  <div key={t.id} className="flex-1 flex flex-col items-center justify-end gap-1" title={`${t.direction === "IN" ? "+" : "−"}${formatIQD(t.amount)} — ${t.cashbox.name}`}>
                    <div
                      className={"w-full rounded-t " + (t.direction === "IN" ? "bg-emerald-500" : "bg-red-500")}
                      style={{ height: `${Math.max(4, heightPct)}%` }}
                    />
                    <div className="text-[8px] text-muted-foreground font-mono" dir="ltr">{new Date(t.created_at).toLocaleTimeString("ar-IQ", { hour: "2-digit", minute: "2-digit" })}</div>
                  </div>
                );
              })}
            </div>
            <div className="flex justify-between mt-2 text-xs">
              <div className="flex items-center gap-1"><span className="w-2 h-2 bg-emerald-500 rounded" /> وارد</div>
              <div className="flex items-center gap-1"><span className="w-2 h-2 bg-red-500 rounded" /> صادر</div>
            </div>
          </CardContent>
        </Card>
      )}

      {canPay && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><HandCoins className="w-4 h-4 text-primary" /> عملية نقدية جديدة</CardTitle>
            <CardDescription>كل عملية تُرقّم تسلسليًا وتُسجل في دفتر النقدية اللاتحققي مع رصيد بعد كل حركة</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2 mb-3 flex-wrap">
              <Button type="button" size="sm" variant={kind === "collection" ? "default" : "outline"} onClick={() => setKind("collection")}><ArrowDownToLine className="w-4 h-4" /> تحصيل من عميل</Button>
              <Button type="button" size="sm" variant={kind === "supplier" ? "default" : "outline"} onClick={() => setKind("supplier")}><ArrowUpFromLine className="w-4 h-4" /> سداد لمورد</Button>
              {canExpense && <Button type="button" size="sm" variant={kind === "expense" ? "default" : "outline"} onClick={() => setKind("expense")}><ReceiptText className="w-4 h-4" /> مصروف</Button>}
            </div>
            <form key={kind} onSubmit={submit} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              {kind === "collection" && (
                <label className="text-xs font-medium space-y-1 lg:col-span-2">العميل *
                  <select name="customer_id" required className={inputCls}>
                    {customers.filter((c) => c.balance > 0).map((c) => (
                      <option key={c.id} value={c.id}>{c.name} — مديونية {formatIQD(c.balance)}</option>
                    ))}
                    {customers.filter((c) => c.balance > 0).length === 0 && <option value="">لا عملاء بمديونية</option>}
                  </select>
                </label>
              )}
              {kind === "supplier" && (
                <label className="text-xs font-medium space-y-1 lg:col-span-2">المورد *
                  <select name="supplier_id" required className={inputCls}>
                    {suppliers.filter((s) => s.balance > 0).map((s) => (
                      <option key={s.id} value={s.id}>{s.name} — مستحق {formatIQD(s.balance)}</option>
                    ))}
                    {suppliers.filter((s) => s.balance > 0).length === 0 && <option value="">لا موردين بمستحقات</option>}
                  </select>
                </label>
              )}
              {kind === "expense" && (
                <label className="text-xs font-medium space-y-1 lg:col-span-2">بيان المصروف *
                  <input name="title" required minLength={2} maxLength={200} className={inputCls} placeholder="مثال: كهرباء ومياه" />
                </label>
              )}
              <label className="text-xs font-medium space-y-1">الصندوق *
                <select name="cashbox_id" required className={inputCls}>
                  {(boxes ?? []).filter((b) => b.is_active).map((b) => (
                    <option key={b.id} value={b.id}>{b.name} ({formatIQD(b.balance)})</option>
                  ))}
                </select>
              </label>
              <label className="text-xs font-medium space-y-1">المبلغ (IQD) *
                <input name="amount" type="number" min="1" step="any" required className={inputCls} dir="ltr" />
              </label>
              <label className="text-xs font-medium space-y-1">ملاحظة
                <input name="note" className={inputCls} placeholder="اختياري" />
              </label>
              <div className="lg:col-span-5">
                <Button type="submit" disabled={saving}>{saving ? "جارٍ التسجيل..." : "تسجيل العملية"}</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Cashboxes */}
      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">الصناديق النقدية</CardTitle></CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {(boxes ?? []).map((b) => (
              <div key={b.id} className="rounded-lg border p-3">
                <div className="text-sm font-medium">{b.name}</div>
                <div className="font-mono text-[10px] text-muted-foreground" dir="ltr">{b.code}</div>
                <div className="mt-1 text-xl font-bold" dir="ltr">{formatIQD(b.balance)}</div>
              </div>
            ))}
            {boxes !== null && boxes.length === 0 && <div className="text-sm text-muted-foreground">لا صناديق بعد</div>}
          </div>
        </CardContent>
      </Card>

      {/* Ledger */}
      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">دفتر النقدية (لاتحققي)</CardTitle></CardHeader>
        <CardContent>
          {txs === null ? (
            <div className="py-8 text-center text-muted-foreground">جارٍ التحميل...</div>
          ) : txs.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">لا حركات نقدية بعد</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الوقت</TableHead>
                  <TableHead>النوع</TableHead>
                  <TableHead>الطرف</TableHead>
                  <TableHead>الصندوق</TableHead>
                  <TableHead className="text-left">المبلغ</TableHead>
                  <TableHead className="text-left">الرصيد بعدها</TableHead>
                  <TableHead>البيان</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {txs.map((t) => (
                  <TableRow key={t.id}>
                    <TableCell className="text-xs text-muted-foreground">{formatDateTime(t.created_at)}</TableCell>
                    <TableCell>
                      <Badge variant={t.direction === "IN" ? "success" : "destructive"} className="text-[10px]">
                        {CATEGORY_AR[t.category] ?? t.category}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">{t.customer?.name ?? t.supplier?.name ?? "—"}</TableCell>
                    <TableCell className="text-xs">{t.cashbox.name}</TableCell>
                    <TableCell className="text-left font-semibold" dir="ltr">
                      {t.direction === "IN" ? "+" : "−"}{formatIQD(t.amount)}
                    </TableCell>
                    <TableCell className="text-left text-sm" dir="ltr">{formatIQD(t.balance_after)}</TableCell>
                    <TableCell className="text-xs text-muted-foreground max-w-48 truncate">{t.note ?? ""}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
