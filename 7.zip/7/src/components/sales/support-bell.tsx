"use client";

import * as React from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { api, type LoginPayload } from "@/lib/client-api";
import {
  Headphones, Loader2, MessageSquare, CheckCircle2, Clock, LifeBuoy, Send, X,
} from "lucide-react";

interface SupportMessage {
  id: number;
  subject: string;
  body: string;
  priority: "LOW" | "NORMAL" | "HIGH";
  status: "OPEN" | "RESOLVED";
  createdAt: string;
  resolvedAt: string | null;
  user: { id: number; fullName: string; username: string } | null;
  company: { id: number; name: string } | null;
}

const PRIORITY_META: Record<SupportMessage["priority"], { cls: string; label: string }> = {
  HIGH: { cls: "bg-red-500/20 text-red-400 border-red-500/30", label: "عاجل" },
  NORMAL: { cls: "bg-amber-500/20 text-amber-400 border-amber-500/30", label: "عادي" },
  LOW: { cls: "bg-slate-500/20 text-slate-300 border-slate-500/30", label: "بسيط" },
};

export function SupportBell({ session }: { session: LoginPayload }) {
  const [open, setOpen] = React.useState(false);
  const [view, setView] = React.useState<"compose" | "inbox">("compose");
  const [loading, setLoading] = React.useState(false);
  const [messages, setMessages] = React.useState<SupportMessage[] | null>(null);
  const [openCount, setOpenCount] = React.useState(0);

  // compose form
  const [subject, setSubject] = React.useState("");
  const [body, setBody] = React.useState("");
  const [priority, setPriority] = React.useState<SupportMessage["priority"]>("NORMAL");
  const [sending, setSending] = React.useState(false);

  const boxRef = React.useRef<HTMLDivElement>(null);

  const isOwner = session.user.scope_type === "GLOBAL" || session.scope?.scope_type === "GLOBAL";

  const load = React.useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const scope = isOwner ? "scope=open" : "";
      const { body: res } = await api<{ messages: SupportMessage[]; open_count: number }>(
        `/api/v1/support${scope ? `?${scope}` : ""}`
      );
      if (res.success && res.data) {
        setMessages(res.data.messages);
        if (typeof res.data.open_count === "number") setOpenCount(res.data.open_count);
      } else if (!silent) {
        toast.error(res.message ?? "تعذر تحميل رسائل الدعم");
      }
    } finally {
      if (!silent) setLoading(false);
    }
  }, [isOwner]);

  React.useEffect(() => {
    load(true);
    const t = setInterval(() => load(true), 60_000);
    return () => clearInterval(t);
  }, [load]);

  // close on outside click
  React.useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const send = async () => {
    if (!subject.trim() || body.trim().length < 10) {
      toast.error("الموضوع مطلوب، واشرح المشكلة بعشرة أحرف على الأقل");
      return;
    }
    setSending(true);
    try {
      const { body: res } = await api<{ message: SupportMessage }>("/api/v1/support", {
        method: "POST",
        body: JSON.stringify({ subject: subject.trim(), body: body.trim(), priority }),
      });
      if (res.success) {
        toast.success("أُرسلت رسالتك إلى فريق الدعم ✓");
        setSubject("");
        setBody("");
        setPriority("NORMAL");
        setView("inbox");
        load(true);
      } else {
        toast.error(res.message ?? "تعذر إرسال الرسالة");
      }
    } finally {
      setSending(false);
    }
  };

  const resolve = async (id: number) => {
    try {
      const { body: res } = await api<{ message: { id: number; status: string } }>(`/api/v1/support?id=${id}`, {
        method: "PATCH",
      });
      if (res.success) {
        toast.success("حُولت الرسالة كمحلولة ✓");
        load(true);
      } else {
        toast.error(res.message ?? "تعذر تحديث الحالة");
      }
    } catch {
      toast.error("تعذر تحديث الحالة");
    }
  };

  const fmt = (iso: string) =>
    new Intl.DateTimeFormat("ar-IQ", { dateStyle: "medium", timeStyle: "short" }).format(new Date(iso));

  return (
    <div className="relative" ref={boxRef}>
      <Button
        size="sm"
        variant="ghost"
        className="relative text-slate-200 hover:bg-white/10 hover:text-white"
        onClick={() => { setOpen((v) => !v); if (!open) { setView("compose"); load(false); } }}
        aria-label="الدعم الفني"
        title="الدعم الفني"
      >
        <Headphones className="w-4 h-4" />
        {isOwner && openCount > 0 && (
          <span className="absolute -top-0.5 -left-0.5 min-w-[16px] h-4 px-1 rounded-full text-[10px] font-bold flex items-center justify-center text-white bg-primary">
            {openCount}
          </span>
        )}
      </Button>

      {open && (
        <div className="absolute left-0 top-11 w-[min(92vw,24rem)] rounded-lg border bg-popover text-popover-foreground shadow-xl z-50 overflow-hidden">
          {/* رأس النافذة */}
          <div className="flex items-center justify-between px-3 py-2 border-b bg-muted/40">
            <div className="text-sm font-bold flex items-center gap-2">
              <LifeBuoy className="w-4 h-4 text-primary" /> الدعم الفني
            </div>
            <div className="flex items-center gap-1">
              {isOwner && (
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 px-2 text-xs"
                  onClick={() => { setView(view === "compose" ? "inbox" : "compose"); if (view === "compose") load(); }}
                >
                  {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : view === "compose" ? <MessageSquare className="w-3.5 h-3.5" /> : <Send className="w-3.5 h-3.5" />}
                  {view === "compose" ? "رسائل" : "إرسال"}
                </Button>
              )}
              <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => load()}>
                <Loader2 className={"w-3.5 h-3.5 " + (loading ? "animate-spin" : "")} />
              </Button>
              <Button size="sm" variant="ghost" className="h-7 px-1 text-xs" onClick={() => setOpen(false)} aria-label="إغلاق">
                <X className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>

          {/* المحتوى */}
          <div className="max-h-[60vh] overflow-y-auto p-3 space-y-2">
            {view === "compose" ? (
              <>
                <div className="text-xs text-muted-foreground leading-relaxed">
                  وصفِ المشكلة بوضوح وسيصلك رد — أرفِق الخطوات التي ظهرت بها المشكلة لتُحل أسرع.
                </div>
                <Input
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="موضوع الرسالة (مثال: لا يمكن طباعة فاتورة)"
                  className="bg-background"
                  maxLength={160}
                />
                <textarea
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder="اشرح المشكلة بالتفصيل…"
                  className="w-full min-h-[88px] rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/60"
                  maxLength={2000}
                />
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {(Object.keys(PRIORITY_META) as SupportMessage["priority"][]).map((p) => (
                      <button
                        key={p}
                        onClick={() => setPriority(p)}
                        className={"rounded-full border px-2.5 py-1 text-[11px] font-semibold transition-colors " +
                          (priority === p ? PRIORITY_META[p].cls : "border-white/10 text-muted-foreground hover:bg-muted")}
                      >
                        {PRIORITY_META[p].label}
                      </button>
                    ))}
                  </div>
                  <Button size="sm" className="gap-1.5" onClick={send} disabled={sending}>
                    {sending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                    إرسال للدعم
                  </Button>
                </div>
              </>
            ) : (
              <div className="space-y-2">
                {loading && messages === null ? (
                  <div className="py-6 text-center text-sm text-muted-foreground flex items-center justify-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" /> جارٍ التحميل...
                  </div>
                ) : !messages?.length ? (
                  <div className="py-6 text-center text-sm text-muted-foreground">لا توجد رسائل بعد</div>
                ) : (
                  messages.map((m) => {
                    const pr = PRIORITY_META[m.priority] ?? PRIORITY_META.NORMAL;
                    return (
                      <div key={m.id} className="rounded-lg border p-2.5 space-y-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-semibold truncate">{m.subject}</span>
                          <span className={"shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-bold " + pr.cls}>{pr.label}</span>
                        </div>
                        <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap break-words">{m.body}</p>
                        <div className="flex items-center justify-between gap-2 pt-0.5">
                          <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                            {m.status === "RESOLVED" ? (
                              <>
                                <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                                <span className="text-emerald-600 font-semibold">حُلت</span>
                                <span>{m.resolvedAt ? fmt(m.resolvedAt) : ""}</span>
                              </>
                            ) : (
                              <>
                                <Clock className="w-3 h-3 text-amber-500" />
                                <span className="text-amber-600 font-semibold">قيد المعالجة</span>
                              </>
                            )}
                          </div>
                          <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                            {m.company && <span className="truncate max-w-[7rem]">{m.company.name}</span>}
                            {m.user && <span className="truncate max-w-[5rem]">{m.user.fullName}</span>}
                          </div>
                          {isOwner && m.status === "OPEN" && (
                            <Button size="sm" variant="outline" className="h-6 px-2 text-[10px] gap-1" onClick={() => resolve(m.id)}>
                              <CheckCircle2 className="w-3 h-3" /> حل
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </div>

          {/* تذييل */}
          <div className="px-3 py-1.5 border-t bg-muted/30 text-[10px] text-muted-foreground flex items-center justify-between">
            <span>رسائلك تصلك مباشرة — الرقم المرجعي يُحفظ تلقائيًا</span>
            {isOwner && openCount > 0 && (
              <Badge className="bg-primary text-white text-[10px]">{openCount} مفتوحة</Badge>
            )}
          </div>
        </div>
      )}
    </div>
  );
}