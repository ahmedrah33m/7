// =====================================================================
// Phase 4 — Cost Layer Engine (محرك طبقات التكلفة) — المستند §1-§8
//
// النقطة الوحيدة لحساب تكلفة البضاعة في النظام. كل وحدة تدخل المخزون
// تُسجَّل كطبقة (CostLayer) بمصدرها وتكلفتها، وكل صرف يستهلك من الطبقات
// حسب طريقة التكلفة المعتمدة للشركة:
//
//   FIFO            → الأقدم أولاً — كل قطعة بتكلفة طبقتها الفعلية
//   WEIGHTED_AVERAGE→ avg = Σ قيمة الطبقات المتبقية ÷ Σ كمياتها (§4) —
//                     تُحدَّث بعد كل استلام مؤهل، والصرف كله بذلك المتوسط
//   STANDARD_COST   → تكلفة معيارية منفصلة عن آخر تكلفة شراء (§5)
//   LAST_COST       → آخر تكلفة شراء فعلية
//
// مصادر الطبقات (§2): PURCHASE · OPENING_BALANCE · STOCK_ADJUSTMENT ·
//   TRANSFER_RECEIPT · SALES_RETURN · PRODUCTION · VOID_RESTORE
//
// ضمانات §6 (لقطة COGS): كل صرف يكتب CostConsumption غير قابل للتغيير
//   ويعيد التكلفة الفعلية — الفاتورة تخزن (unitCost/total/method/layers)
//   فلا تتغير فاتورة قديمة عند تغير التكلفة لاحقاً.
//
// §8 (التحويلات): تنقل الكمية والطبقات بتكلفتها الفعلية — لا تكلفة
//   جديدة عشوائية أبداً (استهلاك فيزيائي FIFO-order دائماً للتحويل).
//
// Phase 3: كل الحساب المالي هنا Decimal — سياسة R1-R10 في ./decimal.ts.
// كل الدوال MUST تُستدعى داخل معاملة المستدعي (نمط inventory.ts).
// =====================================================================

import { ApiError } from "./api";
import { db } from "./db";
import { Decimal, dec, moneyR, qtyR, sumOf } from "./decimal";

export type CostMethod = "FIFO" | "WEIGHTED_AVERAGE" | "STANDARD_COST" | "LAST_COST";
export type CostLayerSourceType =
  | "PURCHASE"
  | "OPENING_BALANCE"
  | "STOCK_ADJUSTMENT"
  | "TRANSFER_RECEIPT"
  | "SALES_RETURN"
  | "PRODUCTION"
  | "VOID_RESTORE";

/** عميل المعاملة — نمط inventory.ts (يعمل مع أي tx client). */
export type Tx = Parameters<Parameters<typeof db.$transaction>[0]>[0];

/**
 * تطبيع طريقة التكلفة: WAVG (المعرّف القديم) مرادف WEIGHTED_AVERAGE،
 * وغير المعروف يرفض صراحة — لا تخمين (نمط المرحلة 2).
 */
export function normalizeCostMethod(v: string | null | undefined): CostMethod {
  const s = String(v ?? "").trim().toUpperCase();
  if (s === "WAVG" || s === "WEIGHTED_AVERAGE" || s === "WEIGHTED AVG" || s === "AVG") return "WEIGHTED_AVERAGE";
  if (s === "FIFO") return "FIFO";
  if (s === "STANDARD_COST" || s === "STANDARD") return "STANDARD_COST";
  if (s === "LAST_COST" || s === "LAST") return "LAST_COST";
  throw new ApiError("VAL_001", `طريقة التكلفة غير معروفة: ${v || "(فارغة)"}`, [
    { field: "costing_method", message: "القيم المسموحة: FIFO · WEIGHTED_AVERAGE · STANDARD_COST · LAST_COST" },
  ]);
}

/** طريقة التكلفة المعتمدة للشركة (Company.costingMethod). */
export async function getCompanyCostMethod(companyId: number): Promise<CostMethod> {
  const company = await db.company.findUnique({
    where: { id: companyId },
    select: { costingMethod: true },
  });
  return normalizeCostMethod(company?.costingMethod ?? "WAVG");
}

// ---------------------------------------------------------------------
// §1/§2 — استلام: كل دخول للبضاعة ينشئ طبقة تكلفة جديدة
// ---------------------------------------------------------------------
export interface ReceiveCostLayerArgs {
  tx: Tx;
  companyId: number;
  warehouseId: number;
  productId: number;
  sourceType: CostLayerSourceType;
  sourceId?: number | null;
  sourceLineId?: number | null;
  quantity: Decimal | number;
  unitCost: Decimal | number;
  currency?: string;
  createdBy?: number | null;
}

export async function receiveCostLayer(args: ReceiveCostLayerArgs) {
  const qty = qtyR(dec(args.quantity));
  if (!qty.isPositive()) {
    throw new ApiError("VAL_001", "كمية طبقة التكلفة يجب أن تكون أكبر من صفر");
  }
  const cost = moneyR(dec(args.unitCost));
  if (cost.isNegative()) {
    throw new ApiError("VAL_001", "تكلفة الطبقة لا يمكن أن تكون سالبة");
  }
  return args.tx.costLayer.create({
    data: {
      companyId: args.companyId,
      warehouseId: args.warehouseId,
      productId: args.productId,
      sourceType: args.sourceType,
      sourceId: args.sourceId ?? null,
      sourceLineId: args.sourceLineId ?? null,
      quantity: qty,
      remainingQuantity: qty,
      unitCost: cost,
      currency: args.currency ?? "IQD",
      status: "ACTIVE",
      createdBy: args.createdBy ?? null,
    },
  });
}

// ---------------------------------------------------------------------
// §3/§4/§5/§6 — الصرف: استهلاك من الطبقات حسب الطريقة + سجل CostConsumption
// ---------------------------------------------------------------------
export interface ConsumeCostArgs {
  tx: Tx;
  companyId: number;
  warehouseId: number;
  productId: number;
  qty: Decimal | number;
  method: CostMethod;
  /** التكلفة البديلة حين لا طبقات (مخزون سابق للمرحلة 4 / مخزون سالب مسموح). */
  fallbackCost: Decimal | number;
  refType: "SALES_INVOICE" | "TRANSFER_OUT" | "ADJUSTMENT" | "RETURN_OUT";
  refId?: number | null;
  refLineId?: number | null;
  userId?: number | null;
}

export interface ConsumptionPiece {
  layerId: number | null;
  qty: Decimal;
  unitCost: Decimal;
  totalCost: Decimal;
}

export interface ConsumeCostResult {
  method: CostMethod;
  /** التكلفة الفعلية للوحدة (مرجّحة على القطع المصروفة) — moneyR. */
  unitCost: Decimal;
  /** إجمالي تكلفة الكمية المصروفة — moneyR(Σ قطع). */
  totalCost: Decimal;
  /** القطع المستهلكة (مراجع الطبقات للفاتورة §6). */
  pieces: ConsumptionPiece[];
}

export async function consumeCost(args: ConsumeCostArgs): Promise<ConsumeCostResult> {
  const { tx, companyId, warehouseId, productId, method } = args;
  const qty = qtyR(dec(args.qty));
  if (!qty.isPositive()) {
    throw new ApiError("VAL_001", "كمية الصرف من الطبقات يجب أن تكون أكبر من صفر");
  }

  // الطبقات المفتوحة بالترتيب الأقدم أولاً (FIFO identity — createdAt/id)
  const layers = await tx.costLayer.findMany({
    where: { warehouseId, productId, status: "ACTIVE", remainingQuantity: { gt: 0 } },
    orderBy: [{ createdAt: "asc" }, { id: "asc" }],
  });

  // التكلفة المطبقة حسب الطريقة (§3/§4/§5) — بدقة كاملة داخل السلسلة الحسابية
  // (R9) والتقريب فقط عند حدود التخزين (R2)
  let appliedCost: Decimal | null = null;
  if (method === "FIFO") {
    appliedCost = null; // تكلفة كل قطعة = تكلفة طبقتها
  } else if (method === "WEIGHTED_AVERAGE") {
    // §4 — avg = إجمالي قيمة المخزون المتبقي ÷ إجمالي كميته (من الطبقات)
    // بلا تقريب وسيط: 120 × (160000/150) = 128000 بالضبط
    const totalQty = sumOf(layers, (l) => l.remainingQuantity);
    const totalValue = sumOf(layers, (l) => qtyR(dec(l.remainingQuantity)).mul(moneyR(dec(l.unitCost))));
    appliedCost = totalQty.isPositive() ? totalValue.div(totalQty) : dec(args.fallbackCost);
  } else if (method === "STANDARD_COST") {
    const product = await tx.product.findUnique({
      where: { id: productId },
      select: { standardCost: true, costPrice: true },
    });
    appliedCost = product?.standardCost != null ? dec(product.standardCost) : dec(args.fallbackCost);
  } else {
    // LAST_COST
    const product = await tx.product.findUnique({
      where: { id: productId },
      select: { lastCost: true, costPrice: true },
    });
    appliedCost = product?.lastCost != null ? dec(product.lastCost) : dec(args.fallbackCost);
  }

  // الحصاد الفيزيائي من الطبقات (الأقدم أولاً دائماً — حتى تحت WAVG/STD/LAST
  // يجب إنزال remainingQuantity لكي تبقى الطبقات مرآة للمخزون الفعلي)
  const pieces: ConsumptionPiece[] = [];
  let need = qty;
  for (const layer of layers) {
    if (!need.isPositive()) break;
    const remaining = qtyR(dec(layer.remainingQuantity));
    if (!remaining.isPositive()) continue;
    const take = Decimal.min(remaining, need);
    // التكلفة الكاملة للحساب + المقرب المخزن للسجل (R2/R6)
    const costFull = method === "FIFO" ? dec(layer.unitCost) : appliedCost as Decimal;
    const costStored = moneyR(costFull);
    pieces.push({ layerId: layer.id, qty: take, unitCost: costStored, totalCost: moneyR(take.mul(costFull)) });
    need = need.minus(take);
    const newRemaining = remaining.minus(take);
    await tx.costLayer.update({
      where: { id: layer.id },
      data: {
        remainingQuantity: newRemaining,
        status: newRemaining.isZero() ? "EXHAUSTED" : "ACTIVE",
      },
    });
  }

  // عجز طبقات (مخزون سالب مسموح سياسياً / مخزون سابق للمرحلة 4):
  // الباقي يُكلف بالتكلفة البديلة (متوسط ساري) بلا طبقة (layerId=null)
  if (need.isPositive()) {
    const cost = moneyR(dec(args.fallbackCost));
    pieces.push({ layerId: null, qty: need, unitCost: cost, totalCost: moneyR(need.mul(cost)) });
  }

  const totalCost = moneyR(sumOf(pieces, (p) => p.totalCost));
  const unitCost = moneyR(totalCost.div(qty));

  // §6 — سجل الصرف غير القابل للتغيير (أثر دائم لكل قطعة)
  for (const p of pieces) {
    await tx.costConsumption.create({
      data: {
        companyId,
        layerId: p.layerId,
        warehouseId,
        productId,
        refType: args.refType,
        refId: args.refId ?? null,
        refLineId: args.refLineId ?? null,
        qty: p.qty,
        unitCost: p.unitCost,
        totalCost: p.totalCost,
      },
    });
  }

  return { method, unitCost, totalCost, pieces };
}

// ---------------------------------------------------------------------
// §7/§6 — الاسترجاع: مرتجع بيع أو إلغاء فاتورة يعيد البضاعة للمخزون
// بتكلفتها الفعلية لحظة الصرف (من سجل CostConsumption) — معالجة محاسبية
// صحيحة: الكلفة تعود كما خرجت، وفواتير أخرى لا تتأثر.
// ---------------------------------------------------------------------
export interface RestoreLayersArgs {
  tx: Tx;
  companyId: number;
  warehouseId: number;
  productId: number;
  /** مرجع الصرف الأصلي — مثال: (SALES_INVOICE, invoiceId, lineId) */
  sourceRefType: "SALES_INVOICE" | "TRANSFER_OUT" | "ADJUSTMENT" | "RETURN_OUT";
  sourceRefId?: number | null;
  sourceRefLineId?: number | null;
  qtyToRestore: Decimal | number;
  /** نوع طبقة الاسترجاع الجديدة + مرجع المستند المرجِع */
  newSourceType: CostLayerSourceType; // VOID_RESTORE | SALES_RETURN | TRANSFER_RECEIPT | ...
  newSourceId?: number | null;
  /** تكلفة بديلة حين لا يوجد سجل صرف (فواتير سابقة للمرحلة 4) */
  fallbackCost: Decimal | number;
  createdBy?: number | null;
}

export interface RestoreLayersResult {
  layers: { id: number; qty: Decimal; unitCost: Decimal }[];
  unitCost: Decimal; // المتوسط المرجّح للمُسترجَع
  totalCost: Decimal;
}

export async function restoreLayersFromConsumptions(args: RestoreLayersArgs): Promise<RestoreLayersResult> {
  const { tx, companyId, warehouseId, productId } = args;
  const need = qtyR(dec(args.qtyToRestore));
  if (!need.isPositive()) {
    throw new ApiError("VAL_001", "كمية الاسترجاع يجب أن تكون أكبر من صفر");
  }

  // سجل الصرف الأصلي بالترتيب الزمني
  const consumptions = await tx.costConsumption.findMany({
    where: {
      warehouseId,
      productId,
      refType: args.sourceRefType,
      refId: args.sourceRefId ?? null,
      refLineId: args.sourceRefLineId ?? null,
    },
    orderBy: { id: "asc" },
  });

  // حارس الاسترجاع المزدوج: كل سجل صرف يُسترجع مرة واحدة فقط
  // (المسترجَع سابقاً = مجموع كميات الطبقات المولدة من نفس سجل الصرف)
  let restoredBefore = new Decimal(0);
  let legacyRestored = new Decimal(0);
  if (consumptions.length) {
    const rows = await tx.costLayer.findMany({
      where: {
        warehouseId,
        productId,
        sourceType: { in: ["VOID_RESTORE", "SALES_RETURN", "TRANSFER_RECEIPT"] },
        sourceLineId: { in: consumptions.map((c) => c.id) },
      },
      select: { sourceLineId: true, quantity: true },
    });
    const perConsumption = new Map<number, Decimal>();
    for (const r of rows) {
      if (r.sourceLineId == null) continue;
      perConsumption.set(r.sourceLineId, (perConsumption.get(r.sourceLineId) ?? new Decimal(0)).plus(qtyR(dec(r.quantity))));
    }
    for (const c of consumptions) restoredBefore = restoredBefore.plus(perConsumption.get(c.id) ?? new Decimal(0));
  } else {
    // سجل قديم (قبل المرحلة 4): حارس بمجموع ما أُعيد لهذا المستند/السطر
    const rows = await tx.costLayer.aggregate({
      where: {
        warehouseId,
        productId,
        sourceType: { in: ["VOID_RESTORE", "SALES_RETURN"] },
        sourceId: args.newSourceId ?? 0,
      },
      _sum: { quantity: true },
    });
    legacyRestored = qtyR(dec(rows._sum.quantity));
  }

  const allowed = need.minus(restoredBefore).minus(legacyRestored);
  if (!allowed.isPositive()) {
    // استُرجع كاملاً سابقاً — لا طبقات جديدة (لا ازدواج مخزون)
    return { layers: [], unitCost: moneyR(dec(args.fallbackCost)), totalCost: new Decimal(0) };
  }

  // المشي على سجلات الصرف بتكاليفها الفعلية
  const layers: { id: number; qty: Decimal; unitCost: Decimal }[] = [];
  let remainingToRestore = allowed;
  for (const c of consumptions) {
    if (!remainingToRestore.isPositive()) break;
    const consumed = qtyR(dec(c.qty));
    const piece = Decimal.min(consumed, remainingToRestore);
    const cost = moneyR(dec(c.unitCost));
    const layer = await receiveCostLayer({
      tx,
      companyId,
      warehouseId,
      productId,
      sourceType: args.newSourceType,
      sourceId: args.newSourceId ?? null,
      sourceLineId: c.id, // ربط الاسترجاع بسجل الصرف الأصلي (حارس الازدواج)
      quantity: piece,
      unitCost: cost,
      createdBy: args.createdBy ?? null,
    });
    layers.push({ id: layer.id, qty: piece, unitCost: cost });
    remainingToRestore = remainingToRestore.minus(piece);
  }

  // بقايا بلا سجل صرف (فواتير قديمة / عجز سجل): طبقة بالتكلفة البديلة
  if (remainingToRestore.isPositive()) {
    const cost = moneyR(dec(args.fallbackCost));
    const layer = await receiveCostLayer({
      tx,
      companyId,
      warehouseId,
      productId,
      sourceType: args.newSourceType,
      sourceId: args.newSourceId ?? null,
      quantity: remainingToRestore,
      unitCost: cost,
      createdBy: args.createdBy ?? null,
    });
    layers.push({ id: layer.id, qty: remainingToRestore, unitCost: cost });
  }

  const totalQty = sumOf(layers, (l) => l.qty);
  const totalCost = moneyR(sumOf(layers, (l) => l.qty.mul(l.unitCost)));
  const unitCost = totalQty.isPositive() ? moneyR(totalCost.div(totalQty)) : moneyR(dec(args.fallbackCost));
  return { layers, unitCost, totalCost };
}

// ---------------------------------------------------------------------
// حذف فاتورة شراء — إبطال طبقاتها المتبقية (المستهلك تاريخه محفوظ في
// CostConsumption — الفواتير القديمة لا تتغير §6)
// ---------------------------------------------------------------------
export async function voidLayersForSource(
  tx: Tx,
  args: { companyId: number; sourceType: CostLayerSourceType | "PURCHASE"; sourceId: number }
) {
  const layers = await tx.costLayer.findMany({
    where: { companyId: args.companyId, sourceType: args.sourceType, sourceId: args.sourceId, status: { not: "VOID" } },
    select: { id: true },
  });
  for (const l of layers) {
    await tx.costLayer.update({
      where: { id: l.id },
      data: { remainingQuantity: new Decimal(0), status: "VOID" },
    });
  }
  return layers.length;
}

// ---------------------------------------------------------------------
// §8 — التحويلات: تنقل الكمية والطبقات بتكلفتها الفعلية.
// الإرسال: استهلاك فيزيائي FIFO-order (دائماً — هوية التكلفة تحفظ)
// الاستلام: طبقات جديدة بالتكاليف نفسها (لا تكلفة جديدة عشوائية)
// ---------------------------------------------------------------------
export interface TransferMoveResult {
  pieces: { qty: Decimal; unitCost: Decimal }[];
  unitCost: Decimal;
  totalCost: Decimal;
}

/** إرسال — يُستهلك من طبقات المصدر فيزيائياً (FIFO-order) ويسجل TRANSFER_OUT. */
export async function transferConsumeLayers(
  tx: Tx,
  args: {
    companyId: number;
    warehouseId: number;
    productId: number;
    qty: Decimal | number;
    transferId: number;
    transferLineId?: number | null;
    fallbackCost: Decimal | number;
    userId?: number | null;
  }
): Promise<TransferMoveResult> {
  const qty = qtyR(dec(args.qty));
  const layers = await tx.costLayer.findMany({
    where: { warehouseId: args.warehouseId, productId: args.productId, status: "ACTIVE", remainingQuantity: { gt: 0 } },
    orderBy: [{ createdAt: "asc" }, { id: "asc" }],
  });

  const pieces: { qty: Decimal; unitCost: Decimal }[] = [];
  let need = qty;
  for (const layer of layers) {
    if (!need.isPositive()) break;
    const remaining = qtyR(dec(layer.remainingQuantity));
    if (!remaining.isPositive()) continue;
    const take = Decimal.min(remaining, need);
    const cost = moneyR(dec(layer.unitCost));
    pieces.push({ qty: take, unitCost: cost });
    need = need.minus(take);
    const newRemaining = remaining.minus(take);
    await tx.costLayer.update({
      where: { id: layer.id },
      data: { remainingQuantity: newRemaining, status: newRemaining.isZero() ? "EXHAUSTED" : "ACTIVE" },
    });
    await tx.costConsumption.create({
      data: {
        companyId: args.companyId,
        layerId: layer.id,
        warehouseId: args.warehouseId,
        productId: args.productId,
        refType: "TRANSFER_OUT",
        refId: args.transferId,
        refLineId: args.transferLineId ?? null,
        qty: take,
        unitCost: cost,
        totalCost: moneyR(take.mul(cost)),
      },
    });
  }
  if (need.isPositive()) {
    const cost = moneyR(dec(args.fallbackCost));
    pieces.push({ qty: need, unitCost: cost });
    await tx.costConsumption.create({
      data: {
        companyId: args.companyId,
        layerId: null,
        warehouseId: args.warehouseId,
        productId: args.productId,
        refType: "TRANSFER_OUT",
        refId: args.transferId,
        refLineId: args.transferLineId ?? null,
        qty: need,
        unitCost: cost,
        totalCost: moneyR(need.mul(cost)),
      },
    });
  }

  const totalCost = moneyR(sumOf(pieces, (p) => p.qty.mul(p.unitCost)));
  const unitCost = moneyR(totalCost.div(qty));
  return { pieces, unitCost, totalCost };
}

/**
 * استلام — ينشئ طبقات الوجهة من قطع الصرف (بتكاليف الإرسال نفسها).
 * الدالة idempotent جزئياً: لا تعيد استلام قطعة استُلمت سابقاً
 * (الاستلامات السابقة تُقاس من طبقات TRANSFER_RECEIPT المرتبطة بسجلات الصرف).
 */
export async function transferReceiveLayers(
  tx: Tx,
  args: {
    companyId: number;
    toWarehouseId: number;
    productId: number;
    qty: Decimal | number;
    transferId: number;
    transferLineId?: number | null;
    fallbackCost: Decimal | number;
    createdBy?: number | null;
  }
): Promise<TransferMoveResult> {
  const need = qtyR(dec(args.qty));
  const consumptions = await tx.costConsumption.findMany({
    where: { warehouseId: { not: args.toWarehouseId }, productId: args.productId, refType: "TRANSFER_OUT", refId: args.transferId },
    orderBy: { id: "asc" },
  });
  // استهلاكات بند التحويل تحديداً (عندما يتوفر معرف السطر)
  const lineConsumptions = args.transferLineId != null
    ? consumptions.filter((c) => c.refLineId === args.transferLineId)
    : consumptions;

  // ما استُلم سابقاً من كل سجل صرف (استلام جزئي/مزدوج حارس)
  const rows = lineConsumptions.length
    ? await tx.costLayer.findMany({
        where: {
          warehouseId: args.toWarehouseId,
          productId: args.productId,
          sourceType: "TRANSFER_RECEIPT",
          sourceId: args.transferId,
          sourceLineId: { in: lineConsumptions.map((c) => c.id) },
        },
        select: { sourceLineId: true, quantity: true },
      })
    : [];
  const receivedPerConsumption = new Map<number, Decimal>();
  for (const r of rows) {
    if (r.sourceLineId == null) continue;
    receivedPerConsumption.set(r.sourceLineId, (receivedPerConsumption.get(r.sourceLineId) ?? new Decimal(0)).plus(qtyR(dec(r.quantity))));
  }
  // بلا سجلات صرف (تحويل قديم قبل المرحلة 4): استُلم سابقاً = طبقات TRANSFER_RECEIPT لنفس التحويل
  let legacyReceived = new Decimal(0);
  if (!lineConsumptions.length) {
    const agg = await tx.costLayer.aggregate({
      where: { warehouseId: args.toWarehouseId, productId: args.productId, sourceType: "TRANSFER_RECEIPT", sourceId: args.transferId },
      _sum: { quantity: true },
    });
    legacyReceived = qtyR(dec(agg._sum.quantity));
  }

  const toReceive = need.minus(legacyReceived);
  const pieces: { qty: Decimal; unitCost: Decimal }[] = [];
  let remaining = toReceive;
  for (const c of lineConsumptions) {
    if (!remaining.isPositive()) break;
    const already = receivedPerConsumption.get(c.id) ?? new Decimal(0);
    const available = qtyR(dec(c.qty)).minus(already);
    if (!available.isPositive()) continue;
    const take = Decimal.min(available, remaining);
    const cost = moneyR(dec(c.unitCost));
    await receiveCostLayer({
      tx,
      companyId: args.companyId,
      warehouseId: args.toWarehouseId,
      productId: args.productId,
      sourceType: "TRANSFER_RECEIPT",
      sourceId: args.transferId,
      sourceLineId: c.id,
      quantity: take,
      unitCost: cost,
      createdBy: args.createdBy ?? null,
    });
    pieces.push({ qty: take, unitCost: cost });
    remaining = remaining.minus(take);
  }
  // تحويل قديم بلا سجلات: طبقة بالتكلفة البديلة
  if (!lineConsumptions.length && remaining.isPositive()) {
    const cost = moneyR(dec(args.fallbackCost));
    await receiveCostLayer({
      tx,
      companyId: args.companyId,
      warehouseId: args.toWarehouseId,
      productId: args.productId,
      sourceType: "TRANSFER_RECEIPT",
      sourceId: args.transferId,
      quantity: remaining,
      unitCost: cost,
      createdBy: args.createdBy ?? null,
    });
    pieces.push({ qty: remaining, unitCost: cost });
  }

  const totalQty = sumOf(pieces, (p) => p.qty);
  const totalCost = moneyR(sumOf(pieces, (p) => p.qty.mul(p.unitCost)));
  const unitCost = totalQty.isPositive() ? moneyR(totalCost.div(totalQty)) : new Decimal(0);
  return { pieces, unitCost, totalCost };
}

// ---------------------------------------------------------------------
// قيمة المخزون من الطبقات (§9 Inventory Value) — Σ remaining × unitCost
// ---------------------------------------------------------------------
export async function layersInventoryValue(
  txOrDb: Tx | typeof db,
  args: { companyId: number; warehouseId?: number; productId?: number }
): Promise<{ qty: Decimal; value: Decimal }> {
  const client = txOrDb as typeof db;
  const layers = await client.costLayer.findMany({
    where: {
      companyId: args.companyId,
      status: "ACTIVE",
      ...(args.warehouseId ? { warehouseId: args.warehouseId } : {}),
      ...(args.productId ? { productId: args.productId } : {}),
    },
    select: { remainingQuantity: true, unitCost: true },
  });
  const qty = qtyR(sumOf(layers, (l) => l.remainingQuantity));
  const value = moneyR(sumOf(layers, (l) => qtyR(dec(l.remainingQuantity)).mul(moneyR(dec(l.unitCost)))));
  return { qty, value };
}
