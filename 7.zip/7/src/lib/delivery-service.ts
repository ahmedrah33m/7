// =====================================================================
// Delivery notes service (إشعارات التسليم) — Phase 5 محرك التسليم الجزئي
//
// السلسلة المعتمدة:  Quotation → Sales Order → Delivery Note → Invoice
//
// ⚠️ قاعدة المخزون الوحيدة (نطاق المرحلة 5 §5):
//    الفاتورة هي التي تخصم المخزون (createSalesInvoice → applyInvoiceEffects
//    + محرك طبقات التكلفة). إشعار التسليم مستند شحن/تسليم لوجستي لا يلمس
//    المخزون إطلاقاً — لا يوجد خصم مزدوج بحكم التصميم.
//
// الحالات (§6):  PENDING → (PARTIAL | DELIVERED)  |  CANCELLED (من PENDING فقط)
//    · PARTIAL   = سُلّم لكن ما زالت كميات متبقية على المصدر (أو سلّم أقل
//                  من الكمية المخططة في بنود الإشعار نفسها)
//    · DELIVERED = اكتمل التسليم (لا متبقٍ على بنود الإشعار ومصدرها)
//    · المُلغى يُستبعد من كل حسابات الكميات (كمياته تعود للمجpool)
//
// الكميات الأربعة لكل بند (§2): orderedQty / previouslyDeliveredQty /
//    currentDeliveredQty / remainingQty — لقطات Decimal لا تتغير بعد التسليم.
//
// دفعة الكميات المعتمدة (pool): الكميات المسلّمة فعلياً = Σ current من
//    إشعارات بحالة DELIVERED/PARTIAL فقط — الإشعارات PENDING لا تحجز
//    (لا حجوزات ناعمة) ومنع over-delivery يُطبَّق عند الإنشاء وعند التسليم
//    معاً ضد المجموع المسلّم الحي (§4: delivered > ordered ممنوع).
//
// §7 Audit: createdById / deliveredById / cancelledById + timestamps
//           + warehouse + branch + company على الرأس.
// =====================================================================

import { ApiError } from "./api";
import { db } from "./db";
import { nextDocumentNumber } from "./document-number";
import { writeAudit } from "./audit";
// Phase 3: كل حساب الكميات هنا Decimal — سياسة R1-R10 في ./decimal.ts
import { Decimal, dec, qtyR, num, sumOf } from "./decimal";
import { packInfoOf, packSplit } from "./packaging";
import { createSalesInvoice, type InvoiceActor } from "./sales-service";

interface Ctx {
  userId: number;
  companyId: number;
  warehouseIds: number[];
}

export type DeliveryActor = InvoiceActor;

export const DELIVERY_STATUSES = ["PENDING", "PARTIAL", "DELIVERED", "CANCELLED"] as const;
export type DeliveryStatus = (typeof DELIVERY_STATUSES)[number];

/** الحالات التي تُعَدّ كمياتها «مسلّمة فعلياً» ضد مصدرها */
export const DELIVERED_LIKE: string[] = ["DELIVERED", "PARTIAL"];

// ---------------------------------------------------------------------
// Line input shapes (R10 — حدود الوحدة تستقبل numbers من API)
// ---------------------------------------------------------------------

export interface DeliveryLineInput {
  product_id?: number; // للمستقل
  sales_order_line_id?: number; // للتسليم على أمر بيع
  invoice_line_id?: number; // للتسليم على فاتورة صادرة
  qty: number; // كمية هذا الإشعار (حبات — الوحدة الأساسية)
  note?: string | null;
}

export interface CreateDeliveryInput {
  customerId?: number | null;
  orderId?: number | null;
  invoiceId?: number | null;
  warehouseId?: number | null;
  driver?: string | null;
  driverPhone?: string | null;
  address?: string | null;
  notes?: string | null;
  lines?: DeliveryLineInput[] | null; // default = كل المتبقي على المصدر
}

export interface DeliverLineInput {
  line_id: number;
  qty: number;
}

export interface DeliverInput {
  receivedBy?: string | null;
  lines?: DeliverLineInput[] | null; // default = الكميات المخططة كاملة
}

// ---------------------------------------------------------------------
// Helpers — الكمية المسلّمة الحية ضد مرساة المصدر (سطر أمر/سطر فاتورة)
// ---------------------------------------------------------------------

async function deliveredAgainstOrderLine(tx: { deliveryNoteLine: { aggregate: Function } }, orderLineId: number): Promise<Decimal> {
  const agg = await tx.deliveryNoteLine.aggregate({
    where: {
      salesOrderLineId: orderLineId,
      deliveryNote: { status: { in: DELIVERED_LIKE }, deletedAt: null },
    },
    _sum: { currentDeliveredQty: true },
  });
  return dec(agg._sum.currentDeliveredQty ?? 0);
}

async function deliveredAgainstInvoiceLine(tx: { deliveryNoteLine: { aggregate: Function } }, invoiceLineId: number): Promise<Decimal> {
  const agg = await tx.deliveryNoteLine.aggregate({
    where: {
      invoiceLineId,
      deliveryNote: { status: { in: DELIVERED_LIKE }, deletedAt: null },
    },
    _sum: { currentDeliveredQty: true },
  });
  return dec(agg._sum.currentDeliveredQty ?? 0);
}

/** لقطة التعبئة العرضية لبند التسليم (لا أثر على المخزون) */
function packagingSnapshot(product: { unit: string; packUnit: string | null; packQty: Decimal | number | null }, qty: Decimal) {
  const info = packInfoOf(product);
  const split = packSplit(qty, info.packQty);
  return {
    packageQty: new Decimal(split.packages),
    looseQty: dec(split.loose),
    packageType: info.hasPack ? info.packageType : null,
    packageConversion: new Decimal(info.packQty),
    packUnitLabel: info.packUnit,
  };
}

async function assertWarehouseInScope(ctx: Ctx, warehouseId: number | null | undefined) {
  if (warehouseId && !ctx.warehouseIds.includes(warehouseId)) {
    throw new ApiError("SCOPE_002", "المستودع خارج نطاق جلسة المستخدم");
  }
}

// ---------------------------------------------------------------------
// Create — من أمر بيع (أساسي) / فاتورة صادرة / مستقل
// ---------------------------------------------------------------------

export async function createDeliveryNote(ctx: Ctx, input: CreateDeliveryInput) {
  const companyId = ctx.companyId;

  const hasExplicitLines = !!input.lines?.length;

  // ---- المصدر: أمر بيع (المسار الأساسي للتسليم الجزئي) --------------------
  if (input.orderId) {
    if (input.invoiceId) throw new ApiError("VAL_001", "اختر مصدراً واحداً — أمر بيع أو فاتورة وليس الاثنين");
    const order = await db.salesOrder.findFirst({
      where: { id: input.orderId, companyId, deletedAt: null },
      include: {
        lines: { include: { product: { select: { id: true, unit: true, packUnit: true, packQty: true } } } },
      },
    });
    if (!order) throw new ApiError("VAL_003", "أمر البيع غير موجود");
    if (order.status === "DRAFT") throw new ApiError("DLV_004", "أوصل أوامر البيع المؤكدة فقط — أكّد الأمر أولاً");
    if (order.status === "CANCELLED") throw new ApiError("DLV_004", "أمر البيع ملغى — لا يمكن التسليم منه");
    if (order.status !== "CONFIRMED") {
      throw new ApiError("DLV_004", `التسليم يتطلب أمراً مؤكداً — الحالة الحالية: ${order.status}`);
    }
    await assertWarehouseInScope(ctx, order.warehouseId);

    const computed = await db.$transaction(async (tx) => {
      const linesOut: {
        productId: number; salesOrderLineId: number; orderedQty: Decimal;
        previouslyDeliveredQty: Decimal; currentDeliveredQty: Decimal; note: string | null;
        pack: ReturnType<typeof packagingSnapshot>;
      }[] = [];

      if (hasExplicitLines) {
        const lineMap = new Map(order.lines.map((l) => [l.id, l]));
        for (const rl of input.lines!) {
          const src = rl.sales_order_line_id ? lineMap.get(Number(rl.sales_order_line_id)) : undefined;
          if (!src) throw new ApiError("VAL_001", "كل بند يجب أن يشير إلى سطر من أمر البيع المرجعي");
          const current = qtyR(dec(rl.qty));
          if (!current.isPositive()) throw new ApiError("VAL_001", "كمية التسليم يجب أن تكون أكبر من صفر");
          const previously = await deliveredAgainstOrderLine(tx, src.id);
          const remaining = qtyR(dec(src.qty).minus(previously));
          if (current.gt(remaining)) {
            throw new ApiError("DLV_003", `over-delivery ممنوع — المطلوب ${num(src.qty)} والمسلّم سابقاً ${num(previously)} والمتبقي ${num(remaining)}`);
          }
          linesOut.push({
            productId: src.productId, salesOrderLineId: src.id,
            orderedQty: dec(src.qty), previouslyDeliveredQty: previously, currentDeliveredQty: current,
            note: rl.note ?? null,
            pack: packagingSnapshot(src.product, current),
          });
        }
      } else {
        // default: كل المتبقي على كل بنود الأمر
        for (const src of order.lines) {
          const previously = await deliveredAgainstOrderLine(tx, src.id);
          const remaining = qtyR(dec(src.qty).minus(previously));
          if (!remaining.isPositive()) continue; // بند مكتمل — يتخطى
          linesOut.push({
            productId: src.productId, salesOrderLineId: src.id,
            orderedQty: dec(src.qty), previouslyDeliveredQty: previously, currentDeliveredQty: remaining,
            note: null,
            pack: packagingSnapshot(src.product, remaining),
          });
        }
      }
      if (!linesOut.length) throw new ApiError("DLV_004", "لا كميات متبقية على أمر البيع — كل بنوده مسلّمة");
      return linesOut;
    });

    const customerId = order.customerId;
    if (input.customerId && input.customerId !== customerId) {
      throw new ApiError("VAL_001", "العميل لا يطابق عميل أمر البيع");
    }

    return db.$transaction(async (tx) => {
      const number = await nextDocumentNumber(tx, companyId, "DLV");
      return tx.deliveryNote.create({
        data: {
          companyId,
          branchId: order.branchId,
          number,
          salesOrderId: order.id,
          customerId,
          warehouseId: order.warehouseId,
          status: "PENDING",
          driver: input.driver ?? null,
          driverPhone: input.driverPhone ?? null,
          address: input.address ?? null,
          notes: input.notes ?? null,
          createdById: ctx.userId,
          lines: {
            create: computed.map((l) => ({
              productId: l.productId,
              salesOrderLineId: l.salesOrderLineId,
              orderedQty: l.orderedQty,
              previouslyDeliveredQty: l.previouslyDeliveredQty,
              currentDeliveredQty: l.currentDeliveredQty,
              packageQty: l.pack.packageQty,
              looseQty: l.pack.looseQty,
              packageType: l.pack.packageType,
              packageConversion: l.pack.packageConversion,
              note: l.note,
            })),
          },
        },
        include: { lines: true },
      });
    });
  }

  // ---- المصدر: فاتورة صادرة (تسليم لوجستي — الفاتورة خصمت المخزون أصلاً) --
  if (input.invoiceId) {
    const inv = await db.salesInvoice.findFirst({
      where: { id: input.invoiceId, companyId, deletedAt: null },
      include: {
        lines: { include: { product: { select: { id: true, unit: true, packUnit: true, packQty: true } } } },
      },
    });
    if (!inv) throw new ApiError("VAL_003", "الفاتورة المرجعية غير موجودة");
    if (inv.status !== "POSTED") throw new ApiError("DLV_004", "التسليم يطالب فواتير مرحّلة (POSTED) فقط");
    await assertWarehouseInScope(ctx, inv.warehouseId);

    const customerId = inv.customerId;
    if (input.customerId && input.customerId !== customerId) {
      throw new ApiError("VAL_001", "الفاتورة لا تعود لنفس العميل");
    }

    const computed = await db.$transaction(async (tx) => {
      const linesOut: {
        productId: number; invoiceLineId: number; orderedQty: Decimal;
        previouslyDeliveredQty: Decimal; currentDeliveredQty: Decimal; note: string | null;
        pack: ReturnType<typeof packagingSnapshot>;
      }[] = [];
      const lineMap = new Map(inv.lines.map((l) => [l.id, l]));

      if (hasExplicitLines) {
        for (const rl of input.lines!) {
          const src = rl.invoice_line_id ? lineMap.get(Number(rl.invoice_line_id)) : undefined;
          if (!src) throw new ApiError("VAL_001", "كل بند يجب أن يشير إلى سطر من الفاتورة المرجعية");
          const current = qtyR(dec(rl.qty));
          if (!current.isPositive()) throw new ApiError("VAL_001", "كمية التسليم يجب أن تكون أكبر من صفر");
          const previously = await deliveredAgainstInvoiceLine(tx, src.id);
          const remaining = qtyR(dec(src.qty).minus(previously));
          if (current.gt(remaining)) {
            throw new ApiError("DLV_003", `over-delivery ممنوع — المطلوب ${num(src.qty)} والمسلّم سابقاً ${num(previously)} والمتبقي ${num(remaining)}`);
          }
          linesOut.push({
            productId: src.productId, invoiceLineId: src.id,
            orderedQty: dec(src.qty), previouslyDeliveredQty: previously, currentDeliveredQty: current,
            note: rl.note ?? null,
            pack: packagingSnapshot(src.product, current),
          });
        }
      } else {
        for (const src of inv.lines) {
          const previously = await deliveredAgainstInvoiceLine(tx, src.id);
          const remaining = qtyR(dec(src.qty).minus(previously));
          if (!remaining.isPositive()) continue;
          linesOut.push({
            productId: src.productId, invoiceLineId: src.id,
            orderedQty: dec(src.qty), previouslyDeliveredQty: previously, currentDeliveredQty: remaining,
            note: null,
            pack: packagingSnapshot(src.product, remaining),
          });
        }
      }
      if (!linesOut.length) throw new ApiError("DLV_004", "لا كميات متبقية على الفاتورة — كل بنودها مسلّمة");
      return linesOut;
    });

    return db.$transaction(async (tx) => {
      const number = await nextDocumentNumber(tx, companyId, "DLV");
      return tx.deliveryNote.create({
        data: {
          companyId,
          branchId: inv.branchId,
          number,
          invoiceId: inv.id,
          customerId,
          warehouseId: inv.warehouseId,
          status: "PENDING",
          driver: input.driver ?? null,
          driverPhone: input.driverPhone ?? null,
          address: input.address ?? null,
          notes: input.notes ?? null,
          createdById: ctx.userId,
          lines: {
            create: computed.map((l) => ({
              productId: l.productId,
              invoiceLineId: l.invoiceLineId,
              orderedQty: l.orderedQty,
              previouslyDeliveredQty: l.previouslyDeliveredQty,
              currentDeliveredQty: l.currentDeliveredQty,
              packageQty: l.pack.packageQty,
              looseQty: l.pack.looseQty,
              packageType: l.pack.packageType,
              packageConversion: l.pack.packageConversion,
              note: l.note,
            })),
          },
        },
        include: { lines: true },
      });
    });
  }

  // ---- مستقل: بنود يدوية لعميل (تسليم بضاعة بلا أمر/فاتورة مسبقة) ---------
  const customerId = input.customerId;
  if (!customerId) throw new ApiError("VAL_001", "حدد العميل");
  const customer = await db.customer.findFirst({
    where: { id: customerId, companyId, deletedAt: null },
    select: { id: true },
  });
  if (!customer) throw new ApiError("VAL_003", "العميل غير موجود");

  if (!hasExplicitLines) throw new ApiError("VAL_001", "أضف بنود التسليم — الإشعار المستقل يُبنى ببنود يدوية");
  if (!input.lines!.every((l) => l.product_id)) {
    throw new ApiError("VAL_001", "كل بند مستقل يتطلب product_id");
  }

  let warehouseId = input.warehouseId ?? ctx.warehouseIds[0] ?? null;
  if (!warehouseId) throw new ApiError("VAL_001", "حدد المستودع");
  await assertWarehouseInScope(ctx, warehouseId);
  const wh = await db.warehouse.findFirst({
    where: { id: warehouseId, companyId, deletedAt: null },
    select: { id: true, branchId: true },
  });
  if (!wh) throw new ApiError("VAL_003", "المستودع غير موجود");

  const productIds = [...new Set(input.lines!.map((l) => Number(l.product_id)))];
  const products = await db.product.findMany({
    where: { id: { in: productIds }, companyId, deletedAt: null },
    select: { id: true, unit: true, packUnit: true, packQty: true },
  });
  const pmap = new Map(products.map((p) => [p.id, p]));

  const computed = input.lines!.map((rl) => {
    const p = pmap.get(Number(rl.product_id));
    if (!p) throw new ApiError("VAL_003", `المنتج #${rl.product_id} غير موجود`);
    const current = qtyR(dec(rl.qty));
    if (!current.isPositive()) throw new ApiError("VAL_001", "كمية التسليم يجب أن تكون أكبر من صفر");
    // المستقل: المطلوب = المسلّم بهذا الإشعار — لا مرساة خارجية
    return {
      productId: p.id,
      orderedQty: current, previouslyDeliveredQty: new Decimal(0), currentDeliveredQty: current,
      note: rl.note ?? null,
      pack: packagingSnapshot(p, current),
    };
  });

  return db.$transaction(async (tx) => {
    const number = await nextDocumentNumber(tx, companyId, "DLV");
    return tx.deliveryNote.create({
      data: {
        companyId,
        branchId: wh.branchId,
        number,
        customerId,
        warehouseId: wh.id,
        status: "PENDING",
        driver: input.driver ?? null,
        driverPhone: input.driverPhone ?? null,
        address: input.address ?? null,
        notes: input.notes ?? null,
        createdById: ctx.userId,
        lines: {
          create: computed.map((l) => ({
            productId: l.productId,
            orderedQty: l.orderedQty,
            previouslyDeliveredQty: l.previouslyDeliveredQty,
            currentDeliveredQty: l.currentDeliveredQty,
            packageQty: l.pack.packageQty,
            looseQty: l.pack.looseQty,
            packageType: l.pack.packageType,
            packageConversion: l.pack.packageConversion,
            note: l.note,
          })),
        },
      },
      include: { lines: true },
    });
  });
}

// ---------------------------------------------------------------------
// Deliver — تسجيل التسليم الفعلي (جزئي أو كامل) — بلا أي أثر مخزني
// ---------------------------------------------------------------------

export async function deliverDeliveryNote(
  ctx: Ctx,
  id: number,
  opts?: DeliverInput | null
) {
  const note = await db.deliveryNote.findFirst({
    where: { id, companyId: ctx.companyId, deletedAt: null },
    include: { lines: true },
  });
  if (!note) throw new ApiError("VAL_003", "إشعار التسليم غير موجود");
  if (note.status === "DELIVERED" || note.status === "PARTIAL") {
    throw new ApiError("DLV_001", "الإشعار مسلَّم مسبقاً");
  }
  if (note.status === "CANCELLED") throw new ApiError("DLV_002", "الإشعار ملغى — لا يمكن تسليمه");
  await assertWarehouseInScope(ctx, note.warehouseId);

  // الكميات الفعلية: المخطط افتراضاً، مع تجاوزات صريحة (0 = تخطي البند)
  const actualMap = new Map<number, Decimal>();
  for (const l of note.lines) actualMap.set(l.id, dec(l.currentDeliveredQty));
  if (opts?.lines?.length) {
    const lineMap = new Map(note.lines.map((l) => [l.id, l]));
    for (const rl of opts.lines) {
      const line = lineMap.get(Number(rl.line_id));
      if (!line) throw new ApiError("VAL_001", `بند التسليم #${rl.line_id} لا يعود لهذا الإشعار`);
      const actual = qtyR(dec(rl.qty));
      if (actual.lt(0)) throw new ApiError("VAL_001", "كمية التسليم لا يمكن أن تكون سالبة");
      if (actual.gt(dec(line.currentDeliveredQty))) {
        throw new ApiError("DLV_004", `الكمية الفعلية (${num(actual)}) تتجاوز المخططة (${num(line.currentDeliveredQty)}) — أنشئ إشعاراً آخر للباقي`);
      }
      actualMap.set(line.id, actual);
    }
  }
  const totalActual = sumOf([...actualMap.values()], (v) => v);
  if (!totalActual.isPositive()) throw new ApiError("DLV_004", "لا كميات فعلية للتسليم");

  const result = await db.$transaction(async (tx) => {
    const noteLines = await tx.deliveryNoteLine.findMany({ where: { deliveryNoteId: note.id } });
    let anyRemaining = false;

    for (const line of noteLines) {
      const actual = actualMap.get(line.id) ?? new Decimal(0);

      // §4 — منع over-delivery ضد المجموع المسلّم الحي من الإشعارات الأخرى
      // (الحالات DELIVERED/PARTIAL فقط — PENDING لا تحجز و CANCELLED مستبعد)
      let previously = new Decimal(0);
      if (line.salesOrderLineId) {
        const agg = await tx.deliveryNoteLine.aggregate({
          where: {
            salesOrderLineId: line.salesOrderLineId,
            deliveryNoteId: { not: note.id },
            deliveryNote: { status: { in: DELIVERED_LIKE }, deletedAt: null },
          },
          _sum: { currentDeliveredQty: true },
        });
        previously = dec(agg._sum.currentDeliveredQty ?? 0);
      } else if (line.invoiceLineId) {
        const agg = await tx.deliveryNoteLine.aggregate({
          where: {
            invoiceLineId: line.invoiceLineId,
            deliveryNoteId: { not: note.id },
            deliveryNote: { status: { in: DELIVERED_LIKE }, deletedAt: null },
          },
          _sum: { currentDeliveredQty: true },
        });
        previously = dec(agg._sum.currentDeliveredQty ?? 0);
      } else {
        previously = dec(line.previouslyDeliveredQty);
      }

      const remaining = qtyR(dec(line.orderedQty).minus(previously).minus(actual));
      if (remaining.isNegative()) {
        throw new ApiError(
          "DLV_003",
          `over-delivery ممنوع — المطلوب ${num(line.orderedQty)} والمسلّم سابقاً ${num(previously)} ولا يمكن تسليم ${num(actual)}`
        );
      }
      if (remaining.isPositive()) anyRemaining = true;

      await tx.deliveryNoteLine.update({
        where: { id: line.id },
        data: { currentDeliveredQty: actual, remainingQty: remaining, previouslyDeliveredQty: previously },
      });

      // عدّاد التسليم على سطر أمر البيع (إسقاط للقراءة السريعة)
      if (line.salesOrderLineId && actual.isPositive()) {
        await tx.salesOrderLine.update({
          where: { id: line.salesOrderLineId },
          data: { deliveredQty: { increment: actual } },
        });
      }
    }

    const status: DeliveryStatus = anyRemaining ? "PARTIAL" : "DELIVERED";
    return tx.deliveryNote.update({
      where: { id: note.id },
      data: {
        status,
        deliveredAt: new Date(),
        deliveredById: ctx.userId,
        receivedBy: opts?.receivedBy ?? note.receivedBy ?? null,
      },
      include: { lines: true },
    });
  });

  await writeAudit(
    { userId: ctx.userId, companyId: ctx.companyId },
    {
      action: "DELIVER",
      module: "sales",
      entityType: "delivery_note",
      entityId: note.id,
      newValues: { number: note.number, status: result.status, received_by: opts?.receivedBy ?? null },
    }
  );

  return result;
}

// ---------------------------------------------------------------------
// Cancel — من PENDING فقط؛ الكميات المخططة تعود للمجpool تلقائياً
// (لأن الملغى مستبعد من كل حسابات المسلَّم)
// ---------------------------------------------------------------------

export async function cancelDeliveryNote(ctx: Ctx, id: number) {
  const note = await db.deliveryNote.findFirst({
    where: { id, companyId: ctx.companyId, deletedAt: null },
  });
  if (!note) throw new ApiError("VAL_003", "إشعار التسليم غير موجود");
  if (note.status === "DELIVERED" || note.status === "PARTIAL") {
    throw new ApiError("DLV_001", "الإشعار المسلَّم غير قابل للإلغاء");
  }
  if (note.status === "CANCELLED") throw new ApiError("DLV_002", "الإشعار ملغى مسبقاً");
  await assertWarehouseInScope(ctx, note.warehouseId);

  const updated = await db.deliveryNote.update({
    where: { id: note.id },
    data: { status: "CANCELLED", cancelledAt: new Date(), cancelledById: ctx.userId },
  });

  await writeAudit(
    { userId: ctx.userId, companyId: ctx.companyId },
    {
      action: "CANCEL",
      module: "sales",
      entityType: "delivery_note",
      entityId: note.id,
      newValues: { number: note.number, status: "CANCELLED" },
    }
  );
  return updated;
}

// ---------------------------------------------------------------------
// Convert — إشعار تسليم مسلَّم (على أمر) → فاتورة بالكميات المسلَّمة فعلاً
// عبر المحرك المعتمد createSalesInvoice (خصم مخزون مرة واحدة + COGS)
// ---------------------------------------------------------------------

export interface ConvertDeliveryInput {
  type: "CASH" | "CREDIT";
  paidAmount?: number | null;
  notes?: string | null;
}

export async function convertDeliveryNoteToInvoice(actor: DeliveryActor, id: number, input: ConvertDeliveryInput) {
  const companyId = actor.companyId;

  const note = await db.deliveryNote.findFirst({
    where: { id, companyId, deletedAt: null },
    include: { lines: { include: { salesOrderLine: true } } },
  });
  if (!note) throw new ApiError("VAL_003", "إشعار التسليم غير موجود");
  if (!note.salesOrderId) throw new ApiError("DLV_004", "التحويل إلى فاتورة يتطلب إشعاراً مرتبطاً بأمر بيع");
  if (note.invoiceId) throw new ApiError("DLV_004", "الإشعار محوّل مسبقاً إلى فاتورة");
  if (note.status !== "DELIVERED" && note.status !== "PARTIAL") {
    throw new ApiError("DLV_004", `التحويل يتطلب إشعاراً مسلَّماً — الحالة الحالية: ${note.status}`);
  }
  const deliveredLines = note.lines.filter((l) => dec(l.currentDeliveredQty).isPositive());
  if (!deliveredLines.length) throw new ApiError("DLV_004", "لا كميات مسلَّمة على الإشعار لتحويلها");

  const order = await db.salesOrder.findFirst({
    where: { id: note.salesOrderId, companyId, deletedAt: null },
    include: { lines: true },
  });
  if (!order) throw new ApiError("VAL_003", "أمر البيع المرجعي غير موجود");
  if (order.status === "INVOICED" && order.invoiceId) {
    throw new ApiError("VAL_004", `الأمر محوّل مسبقاً إلى فاتورة`);
  }
  if (order.status !== "CONFIRMED") {
    throw new ApiError("VAL_004", `التحويل يتطلب أمراً مؤكداً — الحالة الحالية: ${order.status}`);
  }

  // 1) حجز الصف — حارس ذري ضد التحويل المزدوج (نمط convertOrderToInvoice)
  const claimed = await db.salesOrder.updateMany({
    where: { id: order.id, status: "CONFIRMED" },
    data: { status: "INVOICING" },
  });
  if (claimed.count === 0) {
    throw new ApiError("VAL_004", "الأمر قيد التحويل حالياً من جلسة أخرى");
  }

  try {
    // 2) الفاتورة بالكميات المسلَّمة فعلاً — أسعار أمر البيع — عبر المحرك المعتمد
    const orderLineMap = new Map(order.lines.map((l) => [l.id, l]));
    const invoice = await createSalesInvoice(actor, {
      customerId: note.customerId,
      warehouseId: note.warehouseId,
      type: input.type,
      paidAmount: input.paidAmount ?? null,
      notes: input.notes ?? `تحويل من إشعار التسليم ${note.number} — أمر البيع ${order.number}`,
      lines: deliveredLines.map((l) => {
        const ol = l.salesOrderLineId ? orderLineMap.get(l.salesOrderLineId) : undefined;
        return {
          productId: l.productId,
          qty: num(l.currentDeliveredQty), // R10 — الوحدة الأساسية (حبات)
          unit_price: ol ? num(ol.unitPrice) : null,
          discount_pct: ol ? num(ol.discountPct) : null,
        };
      }),
    });

    // 3) الربط + الحسم: الأمر يُختم INVOICED فقط إذا اكتمل تسليم كل بنوده
    const freshLines = await db.salesOrderLine.findMany({ where: { orderId: order.id } });
    const fullyDelivered = freshLines.every((l) => dec(l.deliveredQty).gte(dec(l.qty)));
    await db.deliveryNote.update({ where: { id: note.id }, data: { invoiceId: invoice.id } });
    if (fullyDelivered) {
      await db.salesOrder.update({
        where: { id: order.id },
        data: { status: "INVOICED", invoiceId: invoice.id },
      });
    } else {
      // تسليم جزئي مُفوتر — الأمر يبقى مؤكداً لبقية التسليمات
      await db.salesOrder.updateMany({
        where: { id: order.id, status: "INVOICING" },
        data: { status: "CONFIRMED" },
      });
    }

    await writeAudit(
      { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
      {
        action: "CONVERT",
        module: "sales",
        entityType: "delivery_note",
        entityId: note.id,
        newValues: { number: note.number, invoice: invoice.number, fully_delivered: fullyDelivered },
      }
    );

    return {
      delivery_note_id: note.id,
      order_id: order.id,
      order_number: order.number,
      order_status: fullyDelivered ? "INVOICED" : "CONFIRMED",
      invoice_id: invoice.id,
      invoice_number: invoice.number,
      grand_total: invoice.grand_total,
    };
  } catch (e) {
    // فشل الترحيل → إعادة الأمر لمكانته
    await db.salesOrder.updateMany({
      where: { id: order.id, status: "INVOICING" },
      data: { status: "CONFIRMED" },
    });
    throw e;
  }
}

// ---------------------------------------------------------------------
// Reads — تقدم التسليم على أمر البيع + تفصيل الإشعار
// ---------------------------------------------------------------------

export async function orderDeliveryProgress(actor: DeliveryActor, orderId: number) {
  const { orderWhereForActor } = await import("./sales-order-service");
  const order = await db.salesOrder.findFirst({
    where: { ...(await orderWhereForActor(actor)), id: orderId },
    include: {
      lines: { include: { product: { select: { id: true, code: true, name: true, unit: true } } }, orderBy: { id: "asc" } },
      deliveryNotes: {
        where: { deletedAt: null },
        select: { id: true, number: true, status: true, deliveredAt: true },
        orderBy: { id: "asc" },
      },
    },
  });
  if (!order) throw new ApiError("VAL_003", "أمر البيع غير موجود أو خارج نطاقك");

  const notesByLine = await db.deliveryNoteLine.groupBy({
    by: ["salesOrderLineId", "deliveryNoteId"],
    where: { salesOrderLineId: { in: order.lines.map((l) => l.id) } },
    _sum: { currentDeliveredQty: true },
  });
  const noteStatusById = new Map(order.deliveryNotes.map((n) => [n.id, n.status]));
  const deliveredByLine = new Map<number, Decimal>();
  const pendingByLine = new Map<number, Decimal>();
  for (const g of notesByLine) {
    if (!g.salesOrderLineId) continue;
    const st = noteStatusById.get(g.deliveryNoteId);
    const q = dec(g._sum.currentDeliveredQty ?? 0);
    if (st && DELIVERED_LIKE.includes(st)) {
      deliveredByLine.set(g.salesOrderLineId, (deliveredByLine.get(g.salesOrderLineId) ?? new Decimal(0)).plus(q));
    } else if (st === "PENDING") {
      pendingByLine.set(g.salesOrderLineId, (pendingByLine.get(g.salesOrderLineId) ?? new Decimal(0)).plus(q));
    }
  }

  const lines = order.lines.map((l) => {
    const ordered = dec(l.qty);
    const delivered = qtyR(deliveredByLine.get(l.id) ?? new Decimal(0));
    const pending = qtyR(pendingByLine.get(l.id) ?? new Decimal(0));
    return {
      line_id: l.id,
      product: l.product,
      ordered_qty: num(ordered),
      delivered_qty: num(delivered),
      pending_qty: num(pending),
      remaining_qty: num(qtyR(ordered.minus(delivered))),
    };
  });

  const allDelivered = lines.every((l) => l.remaining_qty === 0);
  const anyDelivered = lines.some((l) => l.delivered_qty > 0);
  const deliveryStatus: "PENDING" | "PARTIAL" | "DELIVERED" = allDelivered
    ? "DELIVERED"
    : anyDelivered || lines.some((l) => l.pending_qty > 0)
      ? "PARTIAL"
      : "PENDING";

  return {
    order: { id: order.id, number: order.number, status: order.status },
    delivery_status: deliveryStatus,
    lines,
    notes: order.deliveryNotes,
  };
}
