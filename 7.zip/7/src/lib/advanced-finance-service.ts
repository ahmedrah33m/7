// =====================================================================
// Advanced finance service — outstanding invoices, FIFO quick receipt,
// charged expenses, bank deposits/withdrawals, check management.
// All operations are thin wrappers around cashbox-service to keep one
// atomic money-flow path. Read-only helpers (outstanding invoices,
// customer payment summary) live here too.
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { nextDocumentNumber } from "./document-number";
import { writeAudit, auditData } from "./audit";
import { Decimal, dec, moneyR, num, sumOf } from "./decimal";
import type { Prisma } from "@prisma/client";
import {
  createReceiptVoucher,
  createPaymentVoucher,
  createCashTransfer,
  assertCashboxAccessible,
  type CashActor,
  type ReceiptAllocationInput,
} from "./cashbox-service";

// ---------------------------------------------------------------------
// Outstanding invoices — list unpaid sales invoices for a customer.
// Used by the quick-receipt form to render the FIFO allocation list.
// ---------------------------------------------------------------------
export interface OutstandingInvoice {
  id: number;
  number: string;
  invoice_date: string;
  grand_total: number;
  paid_amount: number;
  due_amount: number;
  age_days: number;
  currency?: string | null;
}

export async function getOutstandingInvoices(
  companyId: number,
  customerId: number,
  opts: { includePartial?: boolean; limit?: number } = {}
): Promise<{ rows: OutstandingInvoice[]; total_due: number }> {
  const limit = opts.limit ?? 200;
  const rows = await db.salesInvoice.findMany({
    where: { companyId, customerId, deletedAt: null, status: "POSTED" },
    select: { id: true, number: true, invoiceDate: true, grandTotal: true, paidAmount: true, currencyCode: true },
    orderBy: { invoiceDate: "asc" }, // FIFO — oldest first
    take: limit,
  });
  const today = new Date();
  const out: OutstandingInvoice[] = [];
  let totalDue = new Decimal(0);
  for (const r of rows) {
    const due = moneyR(dec(r.grandTotal).minus(r.paidAmount));
    if (!due.isPositive()) continue;
    if (!opts.includePartial && !due.eq(dec(r.grandTotal))) continue;
    const age = Math.floor((today.getTime() - r.invoiceDate.getTime()) / (24 * 3600 * 1000));
    out.push({
      id: r.id, number: r.number,
      invoice_date: r.invoiceDate.toISOString().slice(0, 10),
      grand_total: num(dec(r.grandTotal)),
      paid_amount: num(dec(r.paidAmount)),
      due_amount: num(due),
      age_days: age,
      currency: r.currencyCode,
    });
    totalDue = totalDue.plus(due);
  }
  return { rows: out, total_due: num(moneyR(totalDue)) };
}

// ---------------------------------------------------------------------
// quickReceiptFromCustomer — FIFO auto-allocate amount to oldest unpaid
// invoices; the remainder (if any) becomes an unallocated advance on
// the customer's account (still reduces customer.balance).
// ---------------------------------------------------------------------
export interface QuickReceiptInput {
  customerId: number;
  cashboxId: number;
  branchId: number;
  amount: number;
  paymentMethod?: string;
  currency?: string;
  exchangeRate?: number | null;
  referenceNumber?: string | null;
  bankName?: string | null;
  receivedBy?: string | null;
  notes?: string | null;
  idempotencyKey?: string | null;
  presetInvoiceId?: number | null; // pay specific invoice first, then FIFO
}

export async function quickReceiptFromCustomer(actor: CashActor, input: QuickReceiptInput) {
  const companyId = actor.companyId;
  const amount = moneyR(dec(input.amount));
  if (!amount.isPositive()) throw new ApiError("RECEIPT_001");

  const { rows: outstanding } = await getOutstandingInvoices(companyId, input.customerId, { includePartial: true });
  // Reorder: preset invoice first if provided
  const ordered = input.presetInvoiceId
    ? [...outstanding.filter(r => r.id === input.presetInvoiceId), ...outstanding.filter(r => r.id !== input.presetInvoiceId)]
    : outstanding;

  const allocations: ReceiptAllocationInput[] = [];
  let remaining = amount;
  for (const inv of ordered) {
    if (!remaining.isPositive()) break;
    const alloc = remaining.gte(dec(inv.due_amount)) ? dec(inv.due_amount) : remaining;
    allocations.push({
      invoiceId: inv.id, invoiceType: "SALES", amount: num(moneyR(alloc)),
    });
    remaining = remaining.minus(alloc);
  }
  // Remainder (if any) is an unallocated advance — customer.balance still
  // goes down by the FULL receipt amount in createReceiptVoucher (no
  // allocations = no invoice paidAmount increment, which is the correct
  // treatment for an advance payment on account).

  const result = await createReceiptVoucher(actor, {
    customerId: input.customerId,
    cashboxId: input.cashboxId,
    branchId: input.branchId,
    amount: num(amount),
    paymentMethod: input.paymentMethod ?? "CASH",
    currency: input.currency,
    exchangeRate: input.exchangeRate ?? null,
    referenceNumber: input.referenceNumber,
    bankName: input.bankName,
    receivedBy: input.receivedBy,
    notes: input.notes,
    idempotencyKey: input.idempotencyKey,
    allocations,
  });

  return {
    ...result,
    allocated_count: allocations.length,
    advance_amount: num(moneyR(remaining)), // unallocated amount on account
  };
}

// ---------------------------------------------------------------------
// createChargedExpense — charge expense to customer account.
// customer.balance ↑ (the customer owes more); NO cash outflow.
// Uses createPaymentVoucher with cashboxId=null + chargeToCustomerId set.
// ---------------------------------------------------------------------
export interface ChargedExpenseInput {
  customerId: number;
  branchId: number;
  amount: number;
  reason: string;
  expenseCategory?: string | null;
  expenseCategoryId?: number | null;
  description?: string | null;
  notes?: string | null;
  referenceNumber?: string | null;
  idempotencyKey?: string | null;
}

export async function createChargedExpense(actor: CashActor, input: ChargedExpenseInput) {
  return createPaymentVoucher(actor, {
    chargeToCustomerId: input.customerId,
    branchId: input.branchId,
    amount: input.amount,
    reason: input.reason,
    expenseCategory: input.expenseCategory,
    expenseCategoryId: input.expenseCategoryId,
    description: input.description,
    notes: input.notes,
    referenceNumber: input.referenceNumber,
    idempotencyKey: input.idempotencyKey,
    // cashboxId intentionally null — no cash outflow
    paymentMethod: "ON_ACCOUNT",
  });
}

// ---------------------------------------------------------------------
// Bank deposit — deposit cash from a branch cashbox into a bank account.
// Internally: creates a BANK-type cashbox for the bank account (if needed),
// then transfers between the two cashboxes.
// ---------------------------------------------------------------------
export interface BankDepositInput {
  fromCashboxId: number; // branch cashbox
  bankAccountId: number;
  branchId: number;
  amount: number;
  referenceNumber?: string | null;
  bankDepositRef?: string | null;
  description?: string | null;
  notes?: string | null;
  idempotencyKey?: string | null;
}

export async function createBankDeposit(actor: CashActor, input: BankDepositInput) {
  const companyId = actor.companyId;
  const bankAccount = await db.bankAccount.findFirst({
    where: { id: input.bankAccountId, companyId, deletedAt: null },
  });
  if (!bankAccount) throw new ApiError("VAL_003", "الحساب البنكي غير موجود");

  // Find or create a BANK-type cashbox for this bank account.
  const bankCashboxCode = `BANK-${bankAccount.code}`;
  let bankCashbox = await db.cashbox.findFirst({
    where: { companyId, code: bankCashboxCode, deletedAt: null },
  });
  if (!bankCashbox) {
    bankCashbox = await db.cashbox.create({
      data: {
        companyId,
        branchId: input.branchId,
        code: bankCashboxCode,
        name: `حساب ${bankAccount.bankName} - ${bankAccount.accountNumber}`,
        type: "BANK",
        currency: bankAccount.currency,
        status: "ACTIVE",
        isActive: true,
        openingBalance: 0,
        description: `صندوق مرتبط بالحساب البنكي ${bankAccount.name}`,
        createdBy: actor.userId,
      },
    });
  }

  // Transfer cash → bank
  const transfer = await createCashTransfer(actor, {
    fromCashboxId: input.fromCashboxId,
    toCashboxId: bankCashbox.id,
    branchId: input.branchId,
    amount: input.amount,
    currency: bankAccount.currency,
    isBankDeposit: true,
    bankDepositRef: input.bankDepositRef,
    referenceNumber: input.referenceNumber,
    description: input.description ?? `إيداع بنكي على ${bankAccount.name}`,
    notes: input.notes,
    idempotencyKey: input.idempotencyKey,
  });

  // Update bank account balance
  await db.bankAccount.update({
    where: { id: bankAccount.id },
    data: { balance: { increment: moneyR(dec(input.amount)) } },
  });

  return transfer;
}

// ---------------------------------------------------------------------
// Bank withdrawal — withdraw cash from a bank account into a branch cashbox.
// Reverses the deposit flow.
// ---------------------------------------------------------------------
export interface BankWithdrawalInput {
  toCashboxId: number;
  bankAccountId: number;
  branchId: number;
  amount: number;
  referenceNumber?: string | null;
  bankWithdrawalRef?: string | null;
  description?: string | null;
  notes?: string | null;
  idempotencyKey?: string | null;
}

export async function createBankWithdrawal(actor: CashActor, input: BankWithdrawalInput) {
  const companyId = actor.companyId;
  const bankAccount = await db.bankAccount.findFirst({
    where: { id: input.bankAccountId, companyId, deletedAt: null },
  });
  if (!bankAccount) throw new ApiError("VAL_003", "الحساب البنكي غير موجود");
  if (dec(bankAccount.balance).lt(dec(input.amount))) {
    throw new ApiError("CASHBOX_004", "رصيد الحساب البنكي لا يكفي");
  }

  const bankCashboxCode = `BANK-${bankAccount.code}`;
  let bankCashbox = await db.cashbox.findFirst({
    where: { companyId, code: bankCashboxCode, deletedAt: null },
  });
  if (!bankCashbox) {
    bankCashbox = await db.cashbox.create({
      data: {
        companyId,
        branchId: input.branchId,
        code: bankCashboxCode,
        name: `حساب ${bankAccount.bankName} - ${bankAccount.accountNumber}`,
        type: "BANK",
        currency: bankAccount.currency,
        status: "ACTIVE",
        isActive: true,
        openingBalance: 0,
        description: `صندوق مرتبط بالحساب البنكي ${bankAccount.name}`,
        createdBy: actor.userId,
      },
    });
  }

  const transfer = await createCashTransfer(actor, {
    fromCashboxId: bankCashbox.id,
    toCashboxId: input.toCashboxId,
    branchId: input.branchId,
    amount: input.amount,
    currency: bankAccount.currency,
    isBankWithdrawal: true,
    bankWithdrawalRef: input.bankWithdrawalRef,
    referenceNumber: input.referenceNumber,
    description: input.description ?? `سحب بنكي من ${bankAccount.name}`,
    notes: input.notes,
    idempotencyKey: input.idempotencyKey,
  });

  await db.bankAccount.update({
    where: { id: bankAccount.id },
    data: { balance: { decrement: moneyR(dec(input.amount)) } },
  });

  return transfer;
}

// ---------------------------------------------------------------------
// Checks — RECEIVED (from customer) or ISSUED (to supplier).
// ---------------------------------------------------------------------
export interface CreateCheckInput {
  checkType: "RECEIVED" | "ISSUED";
  checkNumber: string;
  issuingBankId?: number | null;
  receivingBankId?: number | null;
  customerId?: number | null;
  supplierId?: number | null;
  beneficiaryName?: string | null;
  amount: number;
  currency?: string;
  issueDate: Date;
  dueDate: Date;
  bankName?: string | null;
  bankAccount?: string | null;
  referenceNumber?: string | null;
  notes?: string | null;
}

export async function createCheck(actor: CashActor, input: CreateCheckInput) {
  const companyId = actor.companyId;
  const direction = input.checkType === "RECEIVED" ? "INBOUND" : "OUTBOUND";

  const check = await db.check.create({
    data: {
      companyId,
      checkType: input.checkType,
      direction,
      checkNumber: input.checkNumber,
      issuingBankId: input.issuingBankId ?? null,
      receivingBankId: input.receivingBankId ?? null,
      customerId: input.customerId ?? null,
      supplierId: input.supplierId ?? null,
      beneficiaryName: input.beneficiaryName ?? null,
      amount: moneyR(dec(input.amount)),
      currency: input.currency ?? "IQD",
      issueDate: input.issueDate,
      dueDate: input.dueDate,
      status: "PENDING",
      bankName: input.bankName ?? null,
      bankAccount: input.bankAccount ?? null,
      referenceNumber: input.referenceNumber ?? null,
      issuedById: input.checkType === "ISSUED" ? actor.userId : null,
      receivedById: input.checkType === "RECEIVED" ? actor.userId : null,
      notes: input.notes,
    },
  });

  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CREATE",
      module: "finance",
      entityType: "check",
      entityId: check.id,
      newValues: {
        checkNumber: check.checkNumber, type: check.checkType,
        amount: num(check.amount), dueDate: check.dueDate.toISOString().slice(0, 10),
      },
    }
  );

  return { id: check.id, check_number: check.checkNumber, status: check.status };
}

// ---------------------------------------------------------------------
// clearCheck — mark as cleared; for RECEIVED → auto receipt voucher,
// for ISSUED → auto payment voucher (the cash actually moves now).
// ---------------------------------------------------------------------
export interface ClearCheckInput {
  cashboxId: number; // cashbox to deposit into / withdraw from
  branchId: number;
  clearedAt?: Date | null;
  notes?: string | null;
}

export async function clearCheck(actor: CashActor, checkId: number, input: ClearCheckInput) {
  const companyId = actor.companyId;
  const check = await db.check.findFirst({ where: { id: checkId, companyId, deletedAt: null } });
  if (!check) throw new ApiError("VAL_003", "الشيك غير موجود");
  if (check.status !== "PENDING" && check.status !== "DEPOSITED") {
    throw new ApiError("VAL_004", "لا يمكن تسوية شيك بهذه الحالة");
  }

  await db.$transaction(async (tx) => {
    await tx.check.update({
      where: { id: check.id },
      data: {
        status: "CLEARED",
        clearedAt: input.clearedAt ?? new Date(),
        clearedById: actor.userId,
      },
    });
  });

  // RECEIVED → customer receipt (cash IN)
  if (check.checkType === "RECEIVED" && check.customerId) {
    const r = await createReceiptVoucher(actor, {
      customerId: check.customerId,
      cashboxId: input.cashboxId,
      branchId: input.branchId,
      amount: num(dec(check.amount)),
      paymentMethod: "CHEQUE",
      currency: check.currency,
      referenceNumber: check.checkNumber,
      bankName: check.bankName,
      bankAccount: check.bankAccount,
      receivedBy: `شيك ${check.checkNumber}`,
      notes: input.notes ?? `تسوية شيك ${check.checkNumber}`,
      idempotencyKey: `check:${check.id}:clear`,
    });
    await db.check.update({ where: { id: check.id }, data: { receiptVoucherId: r.id } });
    return { id: check.id, status: "CLEARED", receipt_id: r.id };
  }

  // ISSUED → supplier payment (cash OUT)
  if (check.checkType === "ISSUED" && check.supplierId) {
    const v = await createPaymentVoucher(actor, {
      supplierId: check.supplierId,
      cashboxId: input.cashboxId,
      branchId: input.branchId,
      amount: num(dec(check.amount)),
      paymentMethod: "CHEQUE",
      currency: check.currency,
      reason: `سداد بشيك ${check.checkNumber}`,
      beneficiaryName: check.beneficiaryName ?? undefined,
      referenceNumber: check.checkNumber,
      bankName: check.bankName,
      bankAccount: check.bankAccount,
      notes: input.notes,
      idempotencyKey: `check:${check.id}:clear`,
    });
    await db.check.update({ where: { id: check.id }, data: { paymentVoucherId: v.id } });
    return { id: check.id, status: "CLEARED", voucher_id: v.id };
  }

  return { id: check.id, status: "CLEARED" };
}

// ---------------------------------------------------------------------
// bounceCheck — mark as bounced (no cash movement; status flag only).
// ---------------------------------------------------------------------
export async function bounceCheck(actor: CashActor, checkId: number, reason: string) {
  const companyId = actor.companyId;
  const check = await db.check.findFirst({ where: { id: checkId, companyId, deletedAt: null } });
  if (!check) throw new ApiError("VAL_003", "الشيك غير موجود");
  if (check.status === "CLEARED" || check.status === "CANCELLED") {
    throw new ApiError("VAL_004", "لا يمكن ارتداد شيك مسوى أو ملغى");
  }

  await db.$transaction(async (tx) => {
    await tx.check.update({
      where: { id: check.id },
      data: {
        status: "BOUNCED",
        cancelledAt: new Date(),
        cancelledById: actor.userId,
        cancelReason: reason,
        bouncedById: actor.userId,
      },
    });
    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "POST",
          module: "finance",
          entityType: "check_bounce",
          entityId: check.id,
          newValues: { reason },
        }
      ),
    });
  });

  return { id: check.id, status: "BOUNCED" };
}

// ---------------------------------------------------------------------
// Customer payment summary — totals + last payment + is_advance flag.
// ---------------------------------------------------------------------
export interface CustomerPaymentSummary {
  customer_id: number;
  total_paid: number;
  payment_count: number;
  last_payment: { amount: number; date: string; reference: string | null } | null;
  is_advance: boolean; // has unallocated payment balance
}

export async function getCustomerPaymentSummary(companyId: number, customerId: number): Promise<CustomerPaymentSummary> {
  const payments = await db.payment.findMany({
    where: { companyId, customerId, paymentType: "RECEIPT", status: "POSTED", deletedAt: null },
    select: { id: true, totalAmount: true, paymentDate: true, referenceNumber: true, allocations: { select: { allocatedAmount: true } } },
    orderBy: { paymentDate: "desc" },
  });

  const totalPaid = sumOf(payments, p => dec(p.totalAmount));
  const allocatedTotal = sumOf(payments, p => sumOf(p.allocations, a => dec(a.allocatedAmount)));
  const advance = moneyR(totalPaid.minus(allocatedTotal));
  const lastPayment = payments[0]
    ? { amount: num(dec(payments[0].totalAmount)), date: payments[0].paymentDate.toISOString().slice(0, 10), reference: payments[0].referenceNumber ?? null }
    : null;

  return {
    customer_id: customerId,
    total_paid: num(moneyR(totalPaid)),
    payment_count: payments.length,
    last_payment: lastPayment,
    is_advance: advance.isPositive(),
  };
}

// re-exports for convenience
export { assertCashboxAccessible };
