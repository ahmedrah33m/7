// =====================================================================
// B2B portal service (Phase 8 — MASTER PROMPT §6 Phase 8):
//   · Customer login (code + argon2id-hashed PIN) → customer-scoped JWT.
//     A B2B token can NEVER be exchanged for a staff session (typ:"b2b",
//     separate verify function, separate routes).
//   · Catalog with OWN prices only — product.salePrice × (1 − customer
//     discount%); other customers' pricing is never exposed.
//   · Orders: SUBMITTED → CONFIRMED (→ real invoice via sales-service,
//     credit guard + stock inside) | REJECTED.
//   · Statement: own invoices + balance.
// =====================================================================

import { argon2id, argon2Verify } from "hash-wasm";
import { db } from "./db";
import { ApiError } from "./api";
import { nextDocumentNumber } from "./document-number";
import { writeAudit } from "./audit";
import { Decimal, dec, moneyR, num, sumOf } from "./decimal";
import { createSalesInvoice, type InvoiceActor } from "./sales-service";
// RP1 §5 — أسعار البوابة من الطبقة المهيكلة (ProductPrice) ثم Legacy موثّق
import { getEffectivePrices, defaultPricesFromRows, legacyFallbackWarn } from "./product-pricing";
import { getCompanyUsdRate } from "./currency";

function salt(): Uint8Array {
  const s = new Uint8Array(16);
  crypto.getRandomValues(s);
  return s;
}

/** Hash a portal PIN (argon2id, same params as user passwords). */
export async function hashPortalPin(pin: string): Promise<string> {
  return argon2id({
    password: pin,
    salt: salt(),
    parallelism: 1,
    iterations: 3,
    memorySize: 19456,
    hashLength: 32,
    outputType: "encoded" as const,
  });
}

/** Issue or rotate a customer's portal PIN. */
export async function setPortalPin(actor: { userId: number; companyId: number }, customerId: number, pin: string) {
  if (!/^\d{4,8}$/.test(pin)) {
    throw new ApiError("VAL_001", "رقم البوابة يجب أن يكون من 4 إلى 8 أرقام");
  }
  const customer = await db.customer.findFirst({
    where: { id: customerId, companyId: actor.companyId, deletedAt: null },
  });
  if (!customer) throw new ApiError("VAL_003", "العميل غير موجود");
  const pinHash = await hashPortalPin(pin);
  await db.customer.update({ where: { id: customerId }, data: { portalPinHash: pinHash } });
  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId },
    { action: "UPDATE", module: "b2b", entityType: "customer_portal_pin", entityId: customerId, newValues: { customer: customer.name } }
  );
  return { customerId, portal_enabled: true };
}

export async function b2bLogin(companyId: number, code: string, pin: string) {
  const customer = await db.customer.findFirst({
    where: { companyId, code, deletedAt: null },
  });
  // Uniform AUTH_003 — never reveal whether the code or the PIN failed.
  if (!customer || !customer.portalPinHash || !customer.isActive) throw new ApiError("AUTH_003");
  const okPin = await argon2Verify({ password: pin, hash: customer.portalPinHash });
  if (!okPin) throw new ApiError("AUTH_003");
  return customer;
}

/** Price for ONE customer — the only pricing the portal ever sees. */
export function customerPrice(salePrice: Decimal | number, discountPct: Decimal | number): number {
  // salePrice × (1 − clamp(discountPct, 0, 100) ÷ 100) — Decimal كاملاً ثم num() عند الحد
  const pct = Decimal.min(Decimal.max(dec(discountPct), new Decimal(0)), new Decimal(100));
  return num(moneyR(dec(salePrice).mul(new Decimal(1).minus(pct.div(100)))));
}

export async function b2bCatalog(customerId: number) {
  const customer = await db.customer.findUnique({ where: { id: customerId } });
  if (!customer) throw new ApiError("AUTH_002");
  const products = await db.product.findMany({
    where: { companyId: customer.companyId, deletedAt: null, isActive: true },
    include: { category: { select: { name: true } } },
    orderBy: { name: "asc" },
  });
  const effMap = await getEffectivePrices(customer.companyId, products.map((p) => p.id));
  const companyRate = [...effMap.values()].flat().some((r) => r.currency === "USD")
    ? await getCompanyUsdRate(customer.companyId)
    : null;
  const basePriceOf = (p: (typeof products)[number]): number => {
    try {
      return defaultPricesFromRows("b2b-catalog", customer.companyId, effMap.get(p.id) ?? [], { id: p.id, name: p.name }, num(p.salePrice), null, null, companyRate).pieceIqd;
    } catch {
      // سعر USD بلا سعر صرف معروف — لا نُعطّل الكتالوج: سقوط موثّق للإسقاط IQD القديم
      legacyFallbackWarn("b2b-catalog", customer.companyId, p.id, p.name);
      return num(p.salePrice);
    }
  };
  return {
    customer: { id: customer.id, code: customer.code, name: customer.name, discount_pct: num(customer.discountPct), balance: num(customer.balance), credit_limit: num(customer.creditLimit) },
    products: products.map((p) => ({
      id: p.id,
      code: p.code,
      name: p.name,
      category: p.category?.name ?? null,
      unit: p.unit,
      list_price: basePriceOf(p), // reference only
      discount_pct: num(customer.discountPct),
      your_price: customerPrice(basePriceOf(p), customer.discountPct), // OWN price
    })),
  };
}

export interface B2BOrderInput {
  lines: { product_id: number; qty: number }[];
  notes?: string | null;
}

export async function b2bCreateOrder(customerId: number, input: B2BOrderInput) {
  const customer = await db.customer.findUnique({ where: { id: customerId } });
  if (!customer) throw new ApiError("AUTH_002");
  if (!input.lines.length) {
    throw new ApiError("VAL_001", "الطلب بدون بنود", [{ field: "lines", message: "أضف بندًا واحدًا على الأقل" }]);
  }

  const productIds = [...new Set(input.lines.map((l) => l.product_id))];
  const products = await db.product.findMany({
    where: { id: { in: productIds }, companyId: customer.companyId, deletedAt: null, isActive: true },
  });
  const pmap = new Map(products.map((p) => [p.id, p]));
  const effMap = await getEffectivePrices(customer.companyId, productIds);
  const companyRate = [...effMap.values()].flat().some((r) => r.currency === "USD")
    ? await getCompanyUsdRate(customer.companyId)
    : null;

  const computed = input.lines.map((l) => {
    const p = pmap.get(l.product_id);
    if (!p) throw new ApiError("VAL_003", `المنتج #${l.product_id} غير متاح`);
    if (l.qty <= 0) throw new ApiError("VAL_001", `كمية «${p.name}» يجب أن تكون أكبر من صفر`);
    const base = (() => {
      try {
        return defaultPricesFromRows("b2b-order", customer.companyId, effMap.get(p.id) ?? [], { id: p.id, name: p.name }, num(p.salePrice), null, null, companyRate).pieceIqd;
      } catch {
        legacyFallbackWarn("b2b-order", customer.companyId, p.id, p.name);
        return num(p.salePrice);
      }
    })();
    const unitPrice = customerPrice(base, customer.discountPct);
    return { product: p, qty: l.qty, unitPrice, lineTotal: moneyR(dec(l.qty).mul(unitPrice)) };
  });

  // R4 — المجموع = Σ قيم مدورة مسبقاً (Decimal مضبوط)
  const subtotal = moneyR(sumOf(computed, (l) => dec(l.qty).mul(l.unitPrice)));
  const grandTotal = subtotal; // B2B price already net of discount

  const order = await db.$transaction(async (tx) => {
    const number = await nextDocumentNumber(tx, customer.companyId, "B2B");
    return tx.b2BOrder.create({
      data: {
        companyId: customer.companyId,
        customerId: customer.id,
        number,
        status: "SUBMITTED",
        subtotal,
        grandTotal,
        notes: input.notes ?? null,
        lines: {
          create: computed.map((l) => ({
            productId: l.product.id,
            qty: l.qty,
            unitPrice: l.unitPrice,
            lineTotal: l.lineTotal,
          })),
        },
      },
    });
  });

  await writeAudit(
    { userId: null, companyId: customer.companyId },
    {
      action: "CREATE",
      module: "b2b",
      entityType: "b2b_order",
      entityId: order.id,
      newValues: { number: order.number, customer: customer.name, grandTotal: num(grandTotal), lines: computed.length },
    }
  );

  return {
    id: order.id,
    number: order.number,
    status: order.status,
    grand_total: num(grandTotal),
    lines: computed.map((l) => ({ product: l.product.name, qty: l.qty, unit_price: l.unitPrice, line_total: num(l.lineTotal) })),
  };
}

export async function b2bStatement(customerId: number) {
  const customer = await db.customer.findUnique({ where: { id: customerId } });
  if (!customer) throw new ApiError("AUTH_002");
  const [invoices, orders] = await Promise.all([
    db.salesInvoice.findMany({
      where: { companyId: customer.companyId, customerId, deletedAt: null },
      orderBy: { id: "desc" },
      take: 30,
      select: { id: true, number: true, invoiceDate: true, type: true, grandTotal: true, paidAmount: true, status: true },
    }),
    db.b2BOrder.findMany({
      where: { companyId: customer.companyId, customerId, deletedAt: null },
      orderBy: { id: "desc" },
      take: 30,
      select: { id: true, number: true, status: true, grandTotal: true, createdAt: true },
    }),
  ]);
  return {
    customer: { code: customer.code, name: customer.name, balance: num(customer.balance), credit_limit: num(customer.creditLimit) },
    invoices: invoices.map((i) => ({ ...i, grandTotal: num(i.grandTotal), paidAmount: num(i.paidAmount), due_amount: num(moneyR(dec(i.grandTotal).minus(i.paidAmount))) })),
    orders: orders.map((o) => ({ ...o, grandTotal: num(o.grandTotal) })),
  };
}

// ---------------------------------------------------------------------
// Back-office side (staff, RBAC-protected)
// ---------------------------------------------------------------------

export async function listB2BOrders(companyId: number, status?: string) {
  return db.b2BOrder.findMany({
    where: { companyId, deletedAt: null, ...(status ? { status } : {}) },
    include: {
      customer: { select: { id: true, code: true, name: true } },
      lines: { include: { product: { select: { code: true, name: true, unit: true } } } },
      confirmedInvoice: { select: { number: true } },
    },
    orderBy: { id: "desc" },
    take: 100,
  });
}

export async function confirmB2BOrder(
  actor: InvoiceActor & { ip?: string; userAgent?: string },
  orderId: number,
  opts: { warehouseId: number; type: "CASH" | "CREDIT"; notes?: string | null }
) {
  const order = await db.b2BOrder.findFirst({
    where: { id: orderId, companyId: actor.companyId, deletedAt: null },
    include: { lines: true, customer: true },
  });
  if (!order) throw new ApiError("VAL_003", "طلب B2B غير موجود");
  if (order.status !== "SUBMITTED") {
    throw new ApiError("VAL_004", `الاعتماد متاح للطلبات «مقدّمة» فقط — الحالة الحالية: ${order.status}`);
  }

  // Real invoice — the same posting engine: atomic stock + credit guard.
  const invoice = await createSalesInvoice(actor, {
    customerId: order.customerId,
    warehouseId: opts.warehouseId,
    type: opts.type,
    notes: opts.notes ?? `اعتماد طلب بوابة ${order.number}`,
    lines: order.lines.map((l) => ({ productId: l.productId, qty: num(l.qty), unit_price: num(l.unitPrice) })),
  });

  await db.b2BOrder.update({
    where: { id: order.id },
    data: { status: "CONFIRMED", confirmedInvoiceId: invoice.id },
  });
  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "APPROVE",
      module: "b2b",
      entityType: "b2b_order",
      entityId: order.id,
      newValues: { status: "CONFIRMED", invoice: invoice.number, grandTotal: invoice.grand_total },
    }
  );
  return { order_id: order.id, order_number: order.number, status: "CONFIRMED", invoice };
}

export async function rejectB2BOrder(
  actor: { userId: number; companyId: number; ip?: string; userAgent?: string },
  orderId: number,
  reason?: string | null
) {
  const order = await db.b2BOrder.findFirst({
    where: { id: orderId, companyId: actor.companyId, deletedAt: null },
  });
  if (!order) throw new ApiError("VAL_003", "طلب B2B غير موجود");
  if (order.status !== "SUBMITTED") throw new ApiError("VAL_004", "الرفض متاح للطلبات «مقدّمة» فقط");
  await db.b2BOrder.update({ where: { id: order.id }, data: { status: "REJECTED", notes: reason ?? order.notes } });
  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    { action: "REJECT", module: "b2b", entityType: "b2b_order", entityId: order.id, newValues: { status: "REJECTED", reason } }
  );
  return { id: order.id, status: "REJECTED" };
}
