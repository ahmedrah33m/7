// =====================================================================
// Stocktake service (الجرد) — completion phase.
// create: snapshot current system balances → DRAFT sheet (editable counts).
// post:   one-shot — every diff line becomes an ADJUSTMENT movement via
//         applyStockMovement() so the ledger remains the single source of
//         truth; balance_after column keeps full auditability.
// cancel: DRAFT-only soft cancel (posted sheets are immutable).
// =====================================================================

import { ApiError } from "./api";
import { db } from "./db";
import { applyStockMovement } from "./inventory";
import { receiveCostLayer, consumeCost, getCompanyCostMethod } from "./cost-engine";
import { nextDocumentNumber } from "./document-number";
// Phase 3: كل الحساب المالي هنا Decimal — سياسة R1-R10 في ./decimal.ts
import { Decimal, dec, moneyR, qtyR, sumOf, num } from "./decimal";

interface Ctx {
  userId: number;
  companyId: number;
  warehouseIds: number[];
  ip?: string;
  userAgent?: string;
}

export async function createStocktake(
  ctx: Ctx,
  input: { warehouseId: number; notes?: string | null }
) {
  const companyId = ctx.companyId;
  const warehouseId = input.warehouseId;

  if (!ctx.warehouseIds.includes(warehouseId)) {
    throw new ApiError("AUTH_004", "ليس لديك صلاحية على هذا المستودع");
  }

  const warehouse = await db.warehouse.findFirst({
    where: { id: warehouseId, companyId, deletedAt: null },
    select: { id: true, branchId: true, code: true, name: true },
  });
  if (!warehouse) throw new ApiError("VAL_003", "المستودع غير موجود");

  const balances = await db.stockBalance.findMany({
    where: { companyId, warehouseId, qty: { not: 0 } },
    select: { productId: true, qty: true },
  });

  const productIds = balances.map((b) => b.productId);
  const products = await db.product.findMany({
    where: { id: { in: productIds }, deletedAt: null },
    select: { id: true, costPrice: true },
  });
  const costOf = new Map(products.map((p) => [p.id, p.costPrice]));

  const result = await db.$transaction(async (tx) => {
    const number = await nextDocumentNumber(tx, companyId, "STOCKTAKING");

    const st = await tx.stocktake.create({
      data: {
        companyId,
        branchId: warehouse.branchId,
        warehouseId,
        number,
        status: "DRAFT",
        notes: input.notes ?? null,
        createdById: ctx.userId,
        linesCount: 0,
      },
    });

    // create lines in chunks to stay within SQLite variable limits
    const CHUNK = 200;
    let linesCount = 0;
    for (let i = 0; i < balances.length; i += CHUNK) {
      const slice = balances.slice(i, i + CHUNK);
      await tx.stocktakeLine.createMany({
        data: slice.map((b) => ({
          stocktakeId: st.id,
          productId: b.productId,
          systemQty: dec(b.qty),
          countedQty: dec(b.qty), // pre-filled with system value; operator edits
          diffQty: new Decimal(0),
          unitCost: dec(costOf.get(b.productId)),
        })),
      });
      linesCount += slice.length;
    }

    await tx.stocktake.update({ where: { id: st.id }, data: { linesCount } });
    return tx.stocktake.findUnique({ where: { id: st.id }, include: { lines: true } });
  });

  // R10 — حدود الاستجابة: أرقام للواجهة كما كانت (المفاتيح نفسها)
  return result && {
    ...result,
    diffValue: num(result.diffValue),
    lines: result.lines.map((l) => ({
      ...l,
      systemQty: num(l.systemQty),
      countedQty: num(l.countedQty),
      diffQty: num(l.diffQty),
      unitCost: num(l.unitCost),
    })),
  };
}

export async function saveCounts(
  ctx: Ctx,
  id: number,
  counts: { product_id: number; counted_qty: number }[]
) {
  const st = await db.stocktake.findFirst({
    where: { id, companyId: ctx.companyId, deletedAt: null },
    include: { lines: true },
  });
  if (!st) throw new ApiError("VAL_003", "أمر الجرد غير موجود");
  if (st.status !== "DRAFT") throw new ApiError("STK_002", "لا يمكن تعديل عدّ جرد مُرحّل أو ملغى");
  if (!ctx.warehouseIds.includes(st.warehouseId)) throw new ApiError("AUTH_004", "ليس لديك صلاحية على هذا المستودع");

  const countMap = new Map(counts.map((c) => [c.product_id, c.counted_qty]));

  await db.$transaction(async (tx) => {
    for (const line of st.lines) {
      if (!countMap.has(line.productId)) continue;
      const counted = countMap.get(line.productId)!;
      if (dec(counted).isNegative()) throw new ApiError("VAL_001", `الكمية المعدودة لا يمكن أن تكون سالبة (${line.productId})`);
      await tx.stocktakeLine.update({
        where: { stocktakeId_productId: { stocktakeId: st.id, productId: line.productId } },
        data: { countedQty: qtyR(dec(counted)), diffQty: qtyR(dec(counted).minus(dec(line.systemQty))) },
      });
    }
    const lines = await tx.stocktakeLine.findMany({ where: { stocktakeId: st.id } });
    const diffCount = lines.filter((l) => dec(l.diffQty).abs().gt(0.0001)).length;
    const diffValue = moneyR(sumOf(lines, (l) => dec(l.diffQty).mul(dec(l.unitCost))));
    await tx.stocktake.update({ where: { id: st.id }, data: { diffCount, diffValue } });
  });

  const result = await db.stocktake.findUnique({ where: { id: st.id }, include: { lines: { include: { product: { select: { code: true, name: true, unit: true } } } } } });

  // R10 — حدود الاستجابة: أرقام للواجهة كما كانت (المفاتيح نفسها)
  return result && {
    ...result,
    diffValue: num(result.diffValue),
    lines: result.lines.map((l) => ({
      ...l,
      systemQty: num(l.systemQty),
      countedQty: num(l.countedQty),
      diffQty: num(l.diffQty),
      unitCost: num(l.unitCost),
    })),
  };
}

export async function postStocktake(ctx: Ctx, id: number) {
  const st = await db.stocktake.findFirst({
    where: { id, companyId: ctx.companyId, deletedAt: null },
    include: { lines: true },
  });
  if (!st) throw new ApiError("VAL_003", "أمر الجرد غير موجود");
  if (st.status === "POSTED") throw new ApiError("STK_001", "أمر الجرد مُرحّل مسبقًا");
  if (st.status === "CANCELLED") throw new ApiError("STK_002", "أمر الجرد ملغى — لا يمكن ترحيله");
  if (!ctx.warehouseIds.includes(st.warehouseId)) throw new ApiError("AUTH_004", "ليس لديك صلاحية على هذا المستودع");

  const diffLines = st.lines.filter((l) => dec(l.diffQty).abs().gt(0.0001));
  // Phase 4: طريقة التكلفة لصرف عجز الجرد بالتكلفة الفعلية
  const costMethod = await getCompanyCostMethod(st.companyId);

  await db.$transaction(async (tx) => {
    for (const line of diffLines) {
      const positive = dec(line.diffQty).isPositive();
      const direction = positive ? "IN" : "OUT";
      const qty = qtyR(dec(line.diffQty).abs());
      // ---- Phase 4 §1/§2/§3: الزيادة = طبقة تكلفة جديدة (STOCK_ADJUSTMENT)
      // العجز = صرف من الطبقات بالتكلفة الفعلية حسب طريقة الشركة
      let effectiveCost: Decimal = dec(line.unitCost);
      if (positive) {
        await receiveCostLayer({
          tx,
          companyId: st.companyId,
          warehouseId: st.warehouseId,
          productId: line.productId,
          sourceType: "STOCK_ADJUSTMENT",
          sourceId: st.id,
          sourceLineId: line.id,
          quantity: qty,
          unitCost: line.unitCost,
          createdBy: ctx.userId,
        });
      } else {
        const cogs = await consumeCost({
          tx,
          companyId: st.companyId,
          warehouseId: st.warehouseId,
          productId: line.productId,
          qty,
          method: costMethod,
          fallbackCost: line.unitCost,
          refType: "ADJUSTMENT",
          refId: st.id,
          refLineId: line.id,
          userId: ctx.userId,
        });
        effectiveCost = cogs.unitCost;
      }
      await applyStockMovement({
        companyId: st.companyId,
        warehouseId: st.warehouseId,
        productId: line.productId,
        direction,
        qty,
        unitCost: effectiveCost,
        refType: "ADJUSTMENT",
        refId: st.id,
        note: `جرد ${st.number} — فرق ${positive ? "زيادة" : "عجز"}`,
        userId: ctx.userId,
        tx: tx as unknown as Parameters<typeof applyStockMovement>[0]["tx"],
      });
    }

    await tx.stocktake.update({
      where: { id: st.id },
      data: { status: "POSTED", postedAt: new Date(), postedById: ctx.userId, diffCount: diffLines.length },
    });
  });

  const result = await db.stocktake.findUnique({
    where: { id: st.id },
    include: { lines: { include: { product: { select: { code: true, name: true, unit: true } } } } },
  });

  // R10 — حدود الاستجابة: أرقام للواجهة كما كانت (المفاتيح نفسها)
  return result && {
    ...result,
    diffValue: num(result.diffValue),
    lines: result.lines.map((l) => ({
      ...l,
      systemQty: num(l.systemQty),
      countedQty: num(l.countedQty),
      diffQty: num(l.diffQty),
      unitCost: num(l.unitCost),
    })),
  };
}

export async function cancelStocktake(ctx: Ctx, id: number) {
  const st = await db.stocktake.findFirst({ where: { id, companyId: ctx.companyId, deletedAt: null } });
  if (!st) throw new ApiError("VAL_003", "أمر الجرد غير موجود");
  if (st.status === "POSTED") throw new ApiError("STK_001", "الجرد المُرحّل غير قابل للإلغاء — صحّح بتسوية جديدة");
  await db.stocktake.update({ where: { id: st.id }, data: { status: "CANCELLED" } });
  return { id: st.id, status: "CANCELLED" };
}
