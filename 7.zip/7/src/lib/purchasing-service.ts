// =====================================================================
// Purchasing service — supplier invoice posting (Phase 5):
//   ONE transaction = numbering + stock IN per line (at cost) + WAVG
//   cost update + invoice + lines + supplier balance (credit part) +
//   optional immediate cash payment + audit.
//
// Business rules (MASTER PROMPT §5 purchasing):
//   · posting a supplier invoice is the ONLY way stock increases
//     (besides manual intake/adjustments/returns)
//   · cost updated with weighted average: newCost =
//       (oldQty*oldCost + boughtQty*boughtCost) / (oldQty + boughtQty)
//   · CASH  → full amount paid now via cash ledger OUT
//   · CREDIT → due increases supplier payable balance
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { nextDocumentNumber } from "./document-number";
import { applyStockMovement } from "./inventory";
import { receiveCostLayer, voidLayersForSource } from "./cost-engine";
import { writeAudit } from "./audit";
// Phase 3: كل الحساب المالي هنا Decimal — سياسة R1-R10 في ./decimal.ts
import { Decimal, dec, moneyR, qtyR, sumOf, num } from "./decimal";

export interface PurchaseLineInput {
  productId: number;
  qty: number;
  unitCost?: number; // defaults to product cost
  wholesaleSalePrice?: number | null; // سعر البيع جمله (للكرتونة) — يحدّث Product.packSalePrice
  retailSalePrice?: number | null; // سعر البيع مفرد (للحبة) — يحدّث Product.salePrice
}

export interface PurchaseActor {
  userId: number;
  companyId: number;
  warehouseIds: number[];
  ip?: string;
  userAgent?: string;
}

function fmt(n: Decimal | number): string {
  return new Intl.NumberFormat("ar-IQ", { maximumFractionDigits: 2 }).format(dec(n).toNumber());
}

export async function createPurchaseInvoice(
  actor: PurchaseActor,
  input: {
    supplierId: number;
    warehouseId: number;
    type: "CASH" | "CREDIT";
    notes?: string | null;
    paidAmount?: number | null;
    currencyCode?: "IQD" | "USD";
    exchangeRate?: number | null;
    lines: PurchaseLineInput[];
  }
) {
  const companyId = actor.companyId;

  // v15 — Currency validation: USD requires exchange rate
  const currencyCode = input.currencyCode ?? "IQD";
  const exchangeRate = currencyCode === "USD"
    ? (input.exchangeRate && input.exchangeRate > 0 ? dec(input.exchangeRate) : null)
    : null;
  if (currencyCode === "USD" && !exchangeRate) {
    throw new ApiError("VAL_001", "سعر الصرف مطلوب عند اختيار الدولار", [
      { field: "exchange_rate", message: "أدخل سعر صرف الدولار مقابل الدينار (مثلاً 1310)" },
    ]);
  }

  if (!input.lines.length) {
    throw new ApiError("VAL_001", "فاتورة الشراء بدون بنود", [
      { field: "lines", message: "أضف بندًا واحدًا على الأقل" },
    ]);
  }

  const supplier = await db.supplier.findFirst({
    where: { id: input.supplierId, companyId, deletedAt: null },
  });
  if (!supplier) throw new ApiError("VAL_003", "المورد غير موجود");
  if (!supplier.isActive) throw new ApiError("VAL_001", "المورد معطل");

  if (!actor.warehouseIds.includes(input.warehouseId)) throw new ApiError("SCOPE_002");
  const wh = await db.warehouse.findFirst({
    where: { id: input.warehouseId, companyId, deletedAt: null, isActive: true },
    include: { branch: { select: { id: true } } },
  });
  if (!wh) throw new ApiError("VAL_003", "المستودع غير موجود");

  const productIds = [...new Set(input.lines.map((l) => l.productId))];
  const products = await db.product.findMany({
    where: { id: { in: productIds }, companyId, deletedAt: null },
  });
  const pmap = new Map(products.map((p) => [p.id, p]));

  const computed = input.lines.map((l) => {
    const p = pmap.get(l.productId);
    if (!p) throw new ApiError("VAL_003", `المنتج #${l.productId} غير موجود`);
    const qty = qtyR(dec(l.qty));
    if (!qty.isPositive()) throw new ApiError("VAL_001", `كمية الشراء للمنتج «${p.name}» يجب أن تكون أكبر من صفر`);
    const unitCost = l.unitCost != null ? moneyR(dec(l.unitCost)) : moneyR(dec(p.costPrice));
    if (unitCost.isNegative()) throw new ApiError("VAL_001", `تكلفة سالبة للمنتج «${p.name}»`);
    const lineTotal = moneyR(qty.mul(unitCost)); // COGS بند = moneyR(qty × unitCost)
    return {
      product: p,
      qty,
      unitCost,
      lineTotal,
      retailSalePrice: l.retailSalePrice ?? null, // سعر البيع مفرد
      wholesaleSalePrice: l.wholesaleSalePrice ?? null, // سعر البيع جمله
    };
  });

  const grandTotal = moneyR(sumOf(computed, (l) => l.lineTotal));

  const paid =
    input.type === "CASH"
      ? grandTotal
      : moneyR(Decimal.min(Decimal.max(dec(input.paidAmount ?? 0), 0), grandTotal));
  const due = moneyR(grandTotal.minus(paid));

  const invoice = await db.$transaction(async (tx) => {
    const number = await nextDocumentNumber(tx, companyId, "PURCHASE");

    const created = await tx.purchaseInvoice.create({
      data: {
        companyId,
        branchId: wh.branch.id,
        warehouseId: wh.id,
        number,
        supplierId: supplier.id,
        status: "POSTED",
        invoiceDate: new Date(),
        subtotal: grandTotal,
        grandTotal,
        paidAmount: paid,
        // v15 — Currency support (IQD base + USD purchases)
        currencyCode,
        exchangeRate,
        notes: input.notes ?? null,
        createdById: actor.userId,
      },
    });

    for (const l of computed) {
      const lineRow = await tx.purchaseInvoiceLine.create({
        data: {
          invoiceId: created.id,
          productId: l.product.id,
          qty: l.qty,
          unitCost: l.unitCost,
          lineTotal: l.lineTotal,
        },
      });

      // stock IN — same tx (the only normal stock increase path)
      await applyStockMovement({
        tx,
        companyId,
        warehouseId: wh.id,
        productId: l.product.id,
        direction: "IN",
        qty: l.qty,
        unitCost: l.unitCost,
        refType: "INTAKE",
        refId: created.id,
        note: `استلام شراء ${number} من ${supplier.name}`,
        userId: actor.userId,
      });

      // ---- Phase 4 §1/§2: طبقة تكلفة الشراء (مصدر PURCHASE) -------------
      await receiveCostLayer({
        tx,
        companyId,
        warehouseId: wh.id,
        productId: l.product.id,
        sourceType: "PURCHASE",
        sourceId: created.id,
        sourceLineId: lineRow.id,
        quantity: l.qty,
        unitCost: l.unitCost,
        createdBy: actor.userId,
      });

      // Weighted-average cost update — based on on-hand BEFORE this intake
      const beforeRow = await tx.stockBalance.findUnique({
        where: { warehouseId_productId: { warehouseId: wh.id, productId: l.product.id } },
      });
      const current = qtyR(dec(beforeRow?.qty));
      const before = current.minus(l.qty); // balance already includes intake
      const oldCost = dec(l.product.costPrice);
      const wavg =
        current.isPositive()
          ? moneyR(Decimal.max(before, 0).mul(oldCost).plus(l.qty.mul(l.unitCost)).div(Decimal.max(before, 0).plus(l.qty)))
          : l.unitCost;
      await tx.product.update({
        where: { id: l.product.id },
        data: {
          costPrice: wavg,
          lastCost: l.unitCost, // Phase 4: lastCost = آخر تكلفة شراء فعلية
          // v15 — تحديث أسعار البيع عند الشراء إن أُدخلت
          ...(l.retailSalePrice != null
            ? { salePrice: moneyR(dec(l.retailSalePrice)) } // سعر البيع مفرد (للحبة)
            : {}),
          ...(l.wholesaleSalePrice != null
            ? { packSalePrice: moneyR(dec(l.wholesaleSalePrice)) } // سعر البيع جمله (للكرتونة)
            : {}),
        },
      });
    }

    if (due.isPositive()) {
      await tx.supplier.update({
        where: { id: supplier.id },
        data: { balance: { increment: due } },
      });
    }

    // immediate payment (CASH or partial) → cash OUT through the ledger
    if (paid.isPositive()) {
      const box = await tx.cashbox.findFirst({
        where: { companyId, deletedAt: null, isActive: true },
        orderBy: { id: "asc" },
      });
      if (box) {
        const after = moneyR(dec(box.balance).minus(paid));
        if (!after.isNegative()) {
          const number2 = await nextDocumentNumber(tx, companyId, "PAYMENT");
          await tx.cashTransaction.create({
            data: {
              companyId,
              cashboxId: box.id,
              direction: "OUT",
              category: "SUPPLIER_PAYMENT",
              amount: paid,
              balanceAfter: after,
              partyType: "SUPPLIER",
              supplierId: supplier.id,
              refType: "PURCHASE_INVOICE",
              refId: created.id,
              note: `سداد فاتورة شراء ${number}`,
              createdBy: actor.userId,
            },
          });
          await tx.cashbox.update({ where: { id: box.id }, data: { balance: after } });
          if (due.isZero()) {
            await tx.supplier.update({
              where: { id: supplier.id },
              data: { balance: { decrement: 0 } },
            });
          }
        } else if (input.type === "CASH") {
          throw new ApiError(
            "VAL_001",
            `رصيد الصندوق لا يكفي لسداد فاتورة نقدية — المتاح: ${fmt(box.balance)}`,
            [{ field: "type", message: "حوّل الفاتورة إلى آجل أو اشحن الصندوق أولًا" }]
          );
        }
        // If partial & insufficient cash → keep it all on credit instead
        else {
          await tx.purchaseInvoice.update({ where: { id: created.id }, data: { paidAmount: new Decimal(0) } });
          await tx.supplier.update({
            where: { id: supplier.id },
            data: { balance: { increment: paid } },
          });
          return { created, effectivePaid: new Decimal(0) };
        }
      }
    }

    return { created, effectivePaid: paid };
  });

  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CREATE",
      module: "purchasing",
      entityType: "purchase_invoice",
      entityId: invoice.created.id,
      newValues: {
        number: invoice.created.number,
        supplier: supplier.name,
        type: input.type,
        grandTotal,
        lines: computed.length,
      },
    }
  );

  // R10 — حدود الاستجابة: أرقام للواجهة كما كانت
  return {
    id: invoice.created.id,
    uuid: invoice.created.uuid,
    number: invoice.created.number,
    type: input.type,
    grand_total: num(grandTotal),
    paid_amount: num(invoice.effectivePaid),
    due_amount: num(moneyR(grandTotal.minus(invoice.effectivePaid))),
    supplier: { id: supplier.id, name: supplier.name, balance_after: num(moneyR(dec(supplier.balance).plus(due))) },
    cost_updates: computed.map((l) => ({ product: l.product.name, unit_cost: num(l.unitCost) })),
  };
}

// =====================================================================
// deletePurchaseInvoice — حذف (عكس كامل) فاتورة شراء مُرحّلة:
//   ONE transaction = مخزون OUT لكل بند (PURCHASE_VOID) + خصم ذمة
//   المورد + إرجاع المبلغ المسدد للصندوق (قيد قلب IN) + soft delete
//   للفاتورة + audit.
//
// Business rules:
//   · إذا بيعت البضاعة بالفعل (الرصيد لا يكفي للعكس) يُرفض الحذف
//     برسالة واضحة (STOCK_001 من applyStockMovement) — لا سالب مخزون.
//   · المبلغ المسدد يُعاد للصندوق عبر قيد IN معاكس (دفتر نقدي غير قابل
//     للتلف — لا نحذف القيد الأصلي بل نضيف قيدًا معاكسًا).
//   · متوسط التكلفة المرجّح لا يُعاد حسابه (ممارسة معيارية) — يبقى
//     آخر متوسط ساريًا.
// =====================================================================
export async function deletePurchaseInvoice(actor: PurchaseActor, invoiceId: number) {
  const companyId = actor.companyId;

  const invoice = await db.purchaseInvoice.findFirst({
    where: { id: invoiceId, companyId, deletedAt: null },
    include: {
      lines: { select: { id: true, productId: true, qty: true, unitCost: true } },
      supplier: { select: { id: true, name: true } },
    },
  });
  if (!invoice) throw new ApiError("VAL_003", "فاتورة الشراء غير موجودة");
  if (!actor.warehouseIds.includes(invoice.warehouseId)) throw new ApiError("SCOPE_002");

  const paid = moneyR(dec(invoice.paidAmount));
  const due = moneyR(dec(invoice.grandTotal).minus(dec(invoice.paidAmount)));

  await db.$transaction(async (tx) => {
    // 1) عكس المخزون — OUT لكل بند (يرفض تلقائيًا إذا الرصيد لا يكفي)
    for (const l of invoice.lines) {
      await applyStockMovement({
        tx,
        companyId,
        warehouseId: invoice.warehouseId,
        productId: l.productId,
        direction: "OUT",
        qty: l.qty,
        unitCost: l.unitCost,
        refType: "PURCHASE_VOID",
        refId: invoice.id,
        note: `عكس استلام شراء ${invoice.number} (حذف الفاتورة)`,
        userId: actor.userId,
      });
    }

    // 1b) Phase 4: إبطال طبقات التكلفة المتبقية لهذه الفاتورة —
    // الكميات المستهلكة تاريخها محفوظ في cost_consumptions (§6 لا يتغير)
    await voidLayersForSource(tx, { companyId, sourceType: "PURCHASE", sourceId: invoice.id });

    // 2) خصم ذمة المورد (الجزء الآجل)
    if (due.isPositive()) {
      await tx.supplier.update({
        where: { id: invoice.supplierId },
        data: { balance: { decrement: due } },
      });
    }

    // 3) إرجاع المبلغ المسدد للصندوق — قيد قلب IN (الدفتر غير قابل للتلف)
    if (paid.isPositive()) {
      const cashTx = await tx.cashTransaction.findFirst({
        where: { companyId, refType: "PURCHASE_INVOICE", refId: invoice.id, direction: "OUT" },
        orderBy: { id: "desc" },
      });
      if (cashTx) {
        const box = await tx.cashbox.findUnique({ where: { id: cashTx.cashboxId } });
        if (box) {
          const after = moneyR(dec(box.balance).plus(paid));
          const number2 = await nextDocumentNumber(tx, companyId, "PAYMENT");
          await tx.cashTransaction.create({
            data: {
              companyId,
              cashboxId: box.id,
              direction: "IN",
              category: "SUPPLIER_PAYMENT",
              amount: paid,
              balanceAfter: after,
              partyType: "SUPPLIER",
              supplierId: invoice.supplierId,
              refType: "PURCHASE_INVOICE",
              refId: invoice.id,
              note: `ردّ مبلغ سداد فاتورة الشراء ${invoice.number} المُلغاة`,
              createdBy: actor.userId,
            },
          });
          await tx.cashbox.update({ where: { id: box.id }, data: { balance: after } });
        }
      }
    }

    // 4) soft delete للفاتورة
    await tx.purchaseInvoice.update({
      where: { id: invoice.id },
      data: { deletedAt: new Date(), status: "VOID" },
    });
  });

  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "DELETE",
      module: "purchasing",
      entityType: "purchase_invoice",
      entityId: invoice.id,
      oldValues: {
        number: invoice.number,
        supplier: invoice.supplier.name,
        grand_total: invoice.grandTotal,
        paid_amount: paid,
        due_amount: due,
        lines: invoice.lines.length,
      },
      newValues: { voided: true, stock_reversed: invoice.lines.length },
    }
  );

  // R10 — حدود الاستجابة: أرقام للواجهة كما كانت
  return {
    id: invoice.id,
    number: invoice.number,
    supplier: invoice.supplier.name,
    stock_lines_reversed: invoice.lines.length,
    supplier_due_reversed: num(due),
    cash_returned: num(paid),
  };
}
