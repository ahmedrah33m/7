// =====================================================================
// Offline sync service (Phase 8 — MASTER PROMPT §6 Phase 8):
//   PUSH: mobile client posts queued operations with a client-generated
//   op_uuid. The sync_logs table has UNIQUE(op_uuid) → replaying the
//   same push returns the ORIGINAL result flagged SYNC_001 (duplicate),
//   never re-applies (exit criterion: duplicate push = original result).
//
//   PULL: cursor-delta download — rows with updated_at > cursor per
//   entity (products, customers, stock_balances). next_cursor is the
//   max updated_at seen; client stores it and sends it back next time.
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { writeAudit } from "./audit";
import { num, qtyR } from "./decimal";
import { createSalesInvoice, type InvoiceActor } from "./sales-service";
import { collectFromCustomer, type CashActor as FinanceActor } from "./finance-service";

export type SyncEntity = "sales_invoice" | "collection";

export interface SyncOp {
  op_uuid: string;
  entity: SyncEntity;
  action: "create";
  payload: Record<string, unknown>;
  client_ref?: string | null;
}

export interface SyncOpResult {
  op_uuid: string;
  status: "APPLIED" | "DUPLICATE" | "REJECTED";
  code: string;
  result?: unknown;
  error?: { code: string; message: string };
}

/**
 * Apply ONE queued operation. Idempotent by op_uuid:
 * first run → APPLIED with the live result; any replay → DUPLICATE
 * with the SAME original result payload (SYNC_001 semantics).
 */
async function applyOperation(actor: InvoiceActor & FinanceActor, deviceId: string | null, op: SyncOp): Promise<SyncOpResult> {
  const existing = await db.syncLog.findUnique({ where: { opUuid: op.op_uuid } });
  if (existing) {
    return {
      op_uuid: op.op_uuid,
      status: "DUPLICATE",
      code: "SYNC_001",
      result: existing.result ? safeJson(existing.result) : undefined,
    };
  }

  try {
    let result: unknown;
    if (op.entity === "sales_invoice" && op.action === "create") {
      // Offline clients queue snake_case payloads (same shapes as the REST API)
      // → map to the service's camelCase input here.
      const p = op.payload as Record<string, any>;
      result = await createSalesInvoice(actor, {
        customerId: Number(p.customer_id),
        warehouseId: Number(p.warehouse_id),
        type: p.type === "CREDIT" ? "CREDIT" : "CASH",
        notes: p.notes ?? null,
        paidAmount: p.paid_amount ?? null,
        lines: Array.isArray(p.lines)
          ? p.lines.map((l: Record<string, any>) => ({
              productId: Number(l.product_id),
              qty: Number(l.qty),
              unit_price: l.unit_price != null ? Number(l.unit_price) : undefined,
              discount_pct: l.discount_pct != null ? Number(l.discount_pct) : undefined,
            }))
          : [],
      });
    } else if (op.entity === "collection" && op.action === "create") {
      const p = op.payload as Record<string, any>;
      result = await collectFromCustomer(actor, {
        customerId: Number(p.customer_id),
        cashboxId: Number(p.cashbox_id),
        amount: Number(p.amount),
        invoiceId: p.invoice_id != null ? Number(p.invoice_id) : null,
        note: p.note ?? null,
      });
    } else {
      const rejected: SyncOpResult = {
        op_uuid: op.op_uuid,
        status: "REJECTED",
        code: "VAL_001",
        error: { code: "VAL_001", message: `كيان غير مدعوم في المزامنة: ${op.entity}` },
      };
      await db.syncLog.create({
        data: {
          companyId: actor.companyId,
          userId: actor.userId,
          deviceId,
          opUuid: op.op_uuid,
          entity: String(op.entity),
          action: String(op.action),
          payload: JSON.stringify(op.payload ?? {}),
          status: "REJECTED",
          result: JSON.stringify({ error: rejected.error }),
        },
      });
      return rejected;
    }

    await db.syncLog.create({
      data: {
        companyId: actor.companyId,
        userId: actor.userId,
        deviceId,
        opUuid: op.op_uuid,
        entity: op.entity,
        action: op.action,
        payload: JSON.stringify(op.payload ?? {}),
        status: "APPLIED",
        result: JSON.stringify(result),
      },
    });
    return { op_uuid: op.op_uuid, status: "APPLIED", code: "OK", result };
  } catch (err) {
    // Business-rule rejection (STOCK_001, CREDIT_001 …) — persisted so the
    // client never re-pushes a poisoned op; the same op replay still
    // returns this error deterministically.
    if (err instanceof ApiError) {
      await db.syncLog.create({
        data: {
          companyId: actor.companyId,
          userId: actor.userId,
          deviceId,
          opUuid: op.op_uuid,
          entity: String(op.entity),
          action: String(op.action),
          payload: JSON.stringify(op.payload ?? {}),
          status: "REJECTED",
          result: JSON.stringify({ error: { code: err.code, message: err.message } }),
        },
      });
      return { op_uuid: op.op_uuid, status: "REJECTED", code: err.code, error: { code: err.code, message: err.message } };
    }
    throw err;
  }
}

export async function pushOperations(
  actor: InvoiceActor & FinanceActor,
  input: { device_id?: string | null; operations: SyncOp[] }
) {
  const deviceId = input.device_id ?? null;
  const results: SyncOpResult[] = [];
  for (const op of input.operations) {
    if (!op.op_uuid || !op.entity) {
      results.push({ op_uuid: op.op_uuid ?? "?", status: "REJECTED", code: "VAL_001", error: { code: "VAL_001", message: "op_uuid و entity مطلوبان" } });
      continue;
    }
    results.push(await applyOperation(actor, deviceId, op));
  }

  const applied = results.filter((r) => r.status === "APPLIED").length;
  const duplicates = results.filter((r) => r.status === "DUPLICATE").length;
  const rejected = results.filter((r) => r.status === "REJECTED").length;

  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId },
    {
      action: "SYNC",
      module: "sync",
      entityType: "sync_push",
      entityId: null,
      newValues: { device: deviceId, total: results.length, applied, duplicates, rejected },
    }
  );

  return { results, summary: { total: results.length, applied, duplicates, rejected } };
}

const PULL_ENTITIES = ["products", "customers", "stock_balances"] as const;
export type PullEntity = (typeof PULL_ENTITIES)[number];

export async function pullDelta(
  companyId: number,
  warehouseIds: number[],
  opts: { cursor?: string | null; entities?: string[]; limit?: number }
) {
  let since: Date;
  if (opts.cursor) {
    const d = new Date(opts.cursor);
    if (Number.isNaN(d.getTime())) throw new ApiError("VAL_001", "cursor غير صالح — أرسل تاريخ ISO");
    since = d;
  } else {
    since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000); // default: last 7 days
  }
  const limit = Math.min(500, Math.max(1, opts.limit ?? 200));
  const wanted = (opts.entities?.length ? opts.entities : [...PULL_ENTITIES]).filter((e) =>
    (PULL_ENTITIES as readonly string[]).includes(e)
  ) as PullEntity[];

  const data: Record<string, unknown[]> = {};
  let maxUpdated = since;

  const track = (rows: { updatedAt: Date }[]) => {
    for (const r of rows) if (r.updatedAt > maxUpdated) maxUpdated = r.updatedAt;
  };

  for (const entity of wanted) {
    if (entity === "products") {
      const rows = await db.product.findMany({
        where: { companyId, deletedAt: null, updatedAt: { gt: since } },
        select: { id: true, code: true, name: true, unit: true, salePrice: true, costPrice: true, minStock: true, isActive: true, updatedAt: true },
        orderBy: { updatedAt: "asc" },
        take: limit,
      });
      track(rows);
      // R10 — الحدود: الحقول المالية/الكمية أرقام كما كان عقد العملاء
      data.products = rows.map((r) => ({ ...r, salePrice: num(r.salePrice), costPrice: num(r.costPrice), minStock: num(r.minStock) }));
    } else if (entity === "customers") {
      const rows = await db.customer.findMany({
        where: { companyId, deletedAt: null, updatedAt: { gt: since } },
        select: { id: true, code: true, name: true, phone: true, creditLimit: true, balance: true, isActive: true, updatedAt: true },
        orderBy: { updatedAt: "asc" },
        take: limit,
      });
      track(rows);
      data.customers = rows.map((r) => ({ ...r, creditLimit: num(r.creditLimit), balance: num(r.balance) }));
    } else if (entity === "stock_balances") {
      const rows = await db.stockBalance.findMany({
        where: { companyId, warehouseId: { in: warehouseIds }, updatedAt: { gt: since } },
        select: { warehouseId: true, productId: true, qty: true, updatedAt: true },
        orderBy: { updatedAt: "asc" },
        take: limit,
      });
      track(rows);
      data.stock_balances = rows.map((r) => ({ ...r, qty: num(qtyR(r.qty)) }));
    }
  }

  return {
    cursor_used: since.toISOString(),
    next_cursor: maxUpdated.toISOString(),
    has_more: false, // single-page slice; cursor walks forward on next call
    counts: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, v.length])),
    data,
  };
}

function safeJson(s: string): unknown {
  try {
    return JSON.parse(s);
  } catch {
    return null;
  }
}
