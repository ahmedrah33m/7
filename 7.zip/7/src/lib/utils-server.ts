// Server-side numeric helpers — DEPRECATED since Phase 3.
// كل الحساب المالي انتقل إلى src/lib/decimal.ts (سياسة R1-R10).
// round2 تُركت للحسابات غير المالية القديمة فقط — لا تستخدمها في مال جديد.

/** Round to 2 decimals, avoiding float drift (0.1+0.2 cases). */
export function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}
