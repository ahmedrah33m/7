// =====================================================================
// ScopeService — الخدمة المركزية للتسلسل الهرمي (وثيقة Hierarchical
// Visibility & Scope Architecture §15/§17/§20).
//
// لا تسمح لأي API باختراع منطق نطاق خاص بها — كل بوابات التسلسل الهرمي
// تمر من هنا:
//   canGrantScope      — من يملك منح نطاق؟ (الرتبة أعلى صرامةً)
//   validateRoleScopeCombo — أدوار ↔ نطاق (مصفوفة §14)
//   canManageUser      — من يدير من؟ (الرؤية تنزل ولا تصعد §9)
//   assertGrantScope / assertManageUser — نسخ رميات مع تدقيق محاولات التجاوز
//   ownRowsWhere       — تصفية صفوف SELF/SALES_REP (بياناتي فقط §6/§7)
//   canAccessCompany/Branch/Warehouse/Record — فحوص الموارد §16
//
// القاعدة النهائية §20:
//   Visibility flows downward. Authority does not flow upward.
//   Cross-company access is forbidden. Granting requires a higher rank.
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { writeAudit } from "./audit";
import { adminLevelOf, normalizeScopeType, scopeRank, type AdminLevel, type ScopeType } from "./scope";

// ---------------------------------------------------------------------
// أنواع الجلسة الدنيا التي تعمل بها الخدمة (Session من auth.ts تكفي)
// ---------------------------------------------------------------------
export interface ScopeSessionLike {
  userId: number;
  companyId: number;
  scopeType: string;
  companyIds: number[];
  branchIds: number[];
  warehouseIds: number[];
  activeBranchId?: number | null;
}

export interface ManageTargetLike {
  id: number;
  companyId: number;
  scopeType: string;
  roles?: { role: { code: string } }[];
}

/** المستوى الإداري لجلسة أو مستخدم (واجهة موحدة للقوائم و/me). */
export function levelOf(scopeType: string): AdminLevel {
  return adminLevelOf(scopeType);
}

// ---------------------------------------------------------------------
// §17 — منح النطاق: رتبة المانح يجب أن تكون أعلى من رتبة النطاق.
//   GLOBAL (40)   → يمنح أي شيء (مالك المنصة فقط)
//   COMPANY (30)  → يمنح BRANCH/WAREHOUSE/SALES_REP/SELF داخل شركته
//   BRANCH (20)   → يمنح WAREHOUSE/SALES_REP/SELF داخل فرعه
//   EMPLOYEE (≤10) → لا يمنح شيئًا (لا إدارة مستخدمين من الأسفل)
// ---------------------------------------------------------------------
export function canGrantScope(session: ScopeSessionLike, requestedScopeType: string): boolean {
  return scopeRank(session.scopeType) > scopeRank(requestedScopeType);
}

export function grantableScopeTypes(session: ScopeSessionLike): ScopeType[] {
  const all: ScopeType[] = ["GLOBAL", "COMPANY", "BRANCH", "WAREHOUSE", "SALES_REP", "SELF"];
  return all.filter((s) => canGrantScope(session, s));
}

/**
 * §14 — مصفوفة الدور ↔ النطاق: كل دور له سقف نطاق مسموح.
 * منع الحالات غير المنطقية مثل BRANCH_MANAGER + scopeType=COMPANY
 * أو دور مندوب بنطاق GLOBAL.
 */
const ROLE_MAX_SCOPE_RANK: Record<string, number> = {
  OWNER: 40,            // مالك المنصة — نطاق GLOBAL حصراً
  SUPER_ADMIN: 30,      // مدير نظام شركة — حتى COMPANY
  SALES_MANAGER: 30,    // مدير مبيعات على مستوى الشركة
  ACCOUNTANT: 30,       // محاسب الشركة
  PURCHASING_OFFICER: 30,
  AUDITOR: 30,
  VIEWER: 30,
  BRANCH_MANAGER: 20,   // مدير فرع — نطاقه سقفه BRANCH
  CASHIER: 20,          // كاشير فرع
  WAREHOUSE_MANAGER: 10, // أمين مستودع — WAREHOUSE
  SALES_REP: 8,         // مندوب — SALES_REP/SELF
};

export function validateRoleScopeCombo(roleCode: string, scopeType: string): { ok: boolean; reason?: string } {
  const max = ROLE_MAX_SCOPE_RANK[roleCode];
  if (max === undefined) return { ok: true }; // دور مخصص خارج الكتالوج — لا قيد إضافي
  const r = scopeRank(scopeType);
  if (r > max) {
    return {
      ok: false,
      reason: `الدور "${roleCode}" لا يُمنح بنطاق أعلى من سقفه (المسموح حتى رتبة ${max}) — requested=${scopeType}`,
    };
  }
  // GLOBAL نطاق منصة — يُمنح فقط لدور OWNER
  if (normalizeScopeType(scopeType) === "GLOBAL" && roleCode !== "OWNER") {
    return { ok: false, reason: "نطاق GLOBAL (مالك المنصة) يُمنح فقط مع دور OWNER" };
  }
  // دور OWNER بنطاق أقل من GLOBAL غير منطقي (مالك شركة ≠ مالك منصة)
  if (roleCode === "OWNER" && normalizeScopeType(scopeType) !== "GLOBAL") {
    return { ok: false, reason: "دور OWNER يُستخدم حصراً مع نطاق GLOBAL — لملكية شركة استخدم دوراً إدارياً آخر" };
  }
  return { ok: true };
}

// ---------------------------------------------------------------------
// §9/§17 — إدارة المستخدمين: الرؤية تنزل ولا تصعد.
// ---------------------------------------------------------------------
export function canManageUser(session: ScopeSessionLike, target: ManageTargetLike): { ok: boolean; reason?: string } {
  // 1) المالك (GLOBAL) يدير كل من ضمن شركات نطاقه — بما في ذلك نظراءه GLOBAL
  if (normalizeScopeType(session.scopeType) === "GLOBAL") {
    if (session.companyIds.includes(target.companyId) || target.companyId === session.companyId) {
      return { ok: true };
    }
    return { ok: false, reason: "المستخدم خارج شركات نطاقك" };
  }
  // 2) مستوى أدنى لا يرى/لا يلمس مستخدمي المنصة (GLOBAL) إطلاقاً
  if (normalizeScopeType(target.scopeType) === "GLOBAL") {
    return { ok: false, reason: "مستخدمو المنصة (مالك المنصة) خارج نطاق رؤيتك وإدارتك" };
  }
  // 3) نفس الشركة فقط + رتبة الهدف أقل من رتبة المدير (لا نظراء ولا رؤساء)
  if (target.companyId !== session.companyId) {
    return { ok: false, reason: "المستخدم ينتمي إلى شركة أخرى" };
  }
  if (scopeRank(target.scopeType) >= scopeRank(session.scopeType)) {
    return { ok: false, reason: "لا يمكنك إدارة مستخدم بمستوى مساوٍ أو أعلى من مستواك" };
  }
  return { ok: true };
}

// ---------------------------------------------------------------------
// نسخ التأكيد (Assert) — رمي أخطاء موحدة + تدقيق كل محاولة تجاوز §18/§20
// ---------------------------------------------------------------------
async function auditBlocked(
  session: ScopeSessionLike,
  action: string,
  details: Record<string, unknown>
): Promise<void> {
  await writeAudit(
    { userId: session.userId, companyId: session.companyId, ipAddress: null, userAgent: null },
    { action, module: "system", entityType: "scope", entityId: session.userId, newValues: details }
  ).catch(() => {}); // التدقيق لا يعطل الرفض الأمني
}

export async function assertGrantScope(
  session: ScopeSessionLike,
  requestedScopeType: string,
  targetHint?: Record<string, unknown>
): Promise<void> {
  if (canGrantScope(session, requestedScopeType)) return;
  await auditBlocked(session, "SCOPE_ESCALATION_BLOCKED", {
    attempted: requestedScopeType,
    actor_scope: session.scopeType,
    actor_level: levelOf(session.scopeType),
    ...targetHint,
  });
  throw new ApiError(
    "SCOPE_003",
    `مستواك الإداري (${levelOf(session.scopeType)}) لا يسمح بمنح نطاق "${requestedScopeType}" — الرؤية والسلطة تنزل للأسفل فقط`
  );
}

export async function assertManageUser(
  session: ScopeSessionLike,
  target: ManageTargetLike,
  actionHint?: string
): Promise<void> {
  const verdict = canManageUser(session, target);
  if (verdict.ok) return;
  await auditBlocked(session, "SCOPE_ESCALATION_BLOCKED", {
    attempted: actionHint ?? "manage_user",
    target_user: target.id,
    target_scope: target.scopeType,
    actor_scope: session.scopeType,
    actor_level: levelOf(session.scopeType),
    reason: verdict.reason,
  });
  throw new ApiError("SCOPE_003", verdict.reason ?? "خارج نطاقك الإداري");
}

// ---------------------------------------------------------------------
// §16 — فحوص الموارد (Resource check)
// ---------------------------------------------------------------------
export function canAccessCompany(session: ScopeSessionLike, companyId: number): boolean {
  return session.companyIds.includes(companyId);
}

export function canAccessBranch(session: ScopeSessionLike, branchId: number): boolean {
  const eff = session.activeBranchId ? [session.activeBranchId] : session.branchIds;
  return eff.includes(branchId);
}

export function canAccessWarehouse(session: ScopeSessionLike, warehouseId: number): boolean {
  return session.warehouseIds.includes(warehouseId);
}

/**
 * فحص ملكية سجل بيانات (فاتورة/طلب/عميل...) — companyId إلزامي،
 * والفرع يفحص عند توفره، وصفوف الموظف (SELF/SALES_REP) تُقارن بمنشئها.
 */
export function canAccessRecord(
  session: ScopeSessionLike,
  record: { companyId: number; branchId?: number | null; createdById?: number | null; repId?: number | null }
): boolean {
  if (record.companyId !== session.companyId) return false;
  if (record.branchId != null && !canAccessBranch(session, record.branchId)) return false;
  if (isSelfScoped(session)) return ownRecordMatches(session, record);
  return true;
}

/** هل هذه الجلسة من نطاق "بياناتي فقط"؟ (SELF أو SALES_REP — موظفون) */
export function isSelfScoped(session: ScopeSessionLike): boolean {
  const t = normalizeScopeType(session.scopeType);
  return t === "SELF" || t === "SALES_REP";
}

function ownRecordMatches(session: ScopeSessionLike, record: { createdById?: number | null; repId?: number | null }): boolean {
  return record.createdById === session.userId || record.repId === session.userId;
}

/**
 * Prisma where fragment — يضيّق صفوف القوائم إلى "بياناتي فقط" لجلسات
 * الموظفين (SELF/SALES_REP): ما أنشأته أنا. للنماذج ذات حقل createdById
 * (الطلبات، عروض الأسعار، المرتجعات، إشعارات التسليم).
 * (يُنشر داخل where القائمة — لا يلغي فلاتر الشركة/الفرع الموجودة)
 */
export function ownRowsWhere(session: ScopeSessionLike): Record<string, unknown> {
  if (!isSelfScoped(session)) return {};
  return { createdById: session.userId };
}

/**
 * لفواتير البيع تحديدًا: بياناتي = ما أنشأته أو أُسند إليّ كمندوب مسؤول
 * (SalesInvoice لديه repId بجانب createdById).
 */
export function invoiceOwnRowsWhere(session: ScopeSessionLike): Record<string, unknown> {
  if (!isSelfScoped(session)) return {};
  return {
    OR: [
      { createdById: session.userId },
      { repId: session.userId },
    ],
  };
}

/**
 * where لقائمة المستخدمين وفق التسلسل الهرمي (§5/§6/§17):
 *   GLOBAL   → شركات نطاقه (بما فيها مستخدمو المنصة)
 *   COMPANY  → مستخدمو شركته بلا مستخدمي المنصة (المالك غير مرئي)
 *   BRANCH/WAREHOUSE → مستخدمو فروعه فقط
 *   SELF/SALES_REP   → نفسه حصراً (الموظف لا يرى مستخدمين آخرين)
 */
export function usersListWhere(
  session: ScopeSessionLike,
  visibleCompanyIds: number[],
  companyFilter: number | null
): Record<string, unknown> {
  const t = normalizeScopeType(session.scopeType);
  if (t === "SELF" || t === "SALES_REP") {
    return { id: session.userId, deletedAt: null };
  }
  const base: Record<string, unknown> = {
    companyId: companyFilter ?? { in: visibleCompanyIds },
    deletedAt: null,
  };
  if (t === "BRANCH" || t === "WAREHOUSE") {
    // مدير الفرع يرى مستخدمي فروعه الممنوحة — بسياق نشط أو بلا سياق (سد التسريب)
    base.branchId = session.activeBranchId ? session.activeBranchId : { in: session.branchIds.length ? session.branchIds : [-1] };
    // مستخدمو المنصة غير مرئيين للمستويات الدنيا (§17)
    base.scopeType = { not: "GLOBAL" };
  } else if (t === "COMPANY") {
    base.scopeType = { not: "GLOBAL" };
  }
  return base;
}
