// =====================================================================
// Inventory engine — every quantity change in the system flows through
// applyStockMovement() (ERD rule: stock_movements is the immutable
// source of truth; stock_balances is a derived projection).
//
// Phase 3: qty/unitCost/balanceAfter are Decimal(18,6)/(18,4) — كل
// الحساب الكمي هنا عبر decimal.js (سياسة R1-R10 في ./decimal.ts).
//
// MUST be called inside the caller's transaction. Enforces:
//   · company negative-stock policy (allow_negative_stock, default OFF)
//   · balanceAfter ledger column for full auditability
// =====================================================================

import { ApiError } from "./api";
import { db } from "./db";
import { Decimal, dec, qtyR } from "./decimal";

export type StockDirection = "IN" | "OUT";
export type StockRefType =
  | "INTAKE"              // إدخال افتتاحي / استلام مشتريات مبسط
  | "SALES_INVOICE"       // بيع
  | "SALES_INVOICE_VOID"  // عكس مخزون فاتورة مُلغاة
  | "ADJUSTMENT"          // تسوية جرد
  | "RETURN_IN"           // مرتجع وارد من عميل
  | "TRANSFER_IN"
  | "TRANSFER_OUT"
  | "PURCHASE_VOID";      // عكس مخزون فاتورة شراء محذوفة

export interface MovementInput {
  companyId: number;
  warehouseId: number;
  productId: number;
  direction: StockDirection;
  qty: Decimal | number;
  unitCost?: Decimal | number | null;
  refType: StockRefType;
  refId?: number | null;
  note?: string | null;
  /** تجاوز صريح لفحص STOCK_001 لهذه الحركة فقط (فاتورة سُمح بالصرف رغم النقص) */
  allowNegativeOverride?: boolean;
  userId?: number | null;
  tx: PrismaLike;
}

/** Minimal structural type so the engine works with any transaction client. */
interface PrismaLike {
  company: { findUnique(args: { where: { id: number }; select: { allowNegativeStock: boolean } }): Promise<{ allowNegativeStock: boolean } | null> };
  stockBalance: {
    findUnique(args: { where: { warehouseId_productId: { warehouseId: number; productId: number } } }): Promise<{ id: number; qty: Decimal } | null>;
    upsert(args: unknown): Promise<unknown>;
  };
  stockMovement: { create(args: { data: Record<string, unknown> }): Promise<unknown> };
}

export async function applyStockMovement(input: MovementInput): Promise<{ balanceAfter: Decimal }> {
  const { companyId, warehouseId, productId, direction, tx } = input;
  const qty = qtyR(dec(input.qty));
  if (!qty.isPositive() || qty.isZero()) {
    throw new ApiError("VAL_001", "الكمية يجب أن تكون أكبر من صفر", [
      { field: "qty", message: "qty > 0 مطلوب" },
    ]);
  }

  const company = await tx.company.findUnique({
    where: { id: companyId },
    select: { allowNegativeStock: true },
  });

  const balance = await tx.stockBalance.findUnique({
    where: { warehouseId_productId: { warehouseId, productId } },
  });
  const current = qtyR(dec(balance?.qty));
  const after = direction === "IN" ? current.plus(qty) : current.minus(qty);

  if (after.isNegative() && !(company?.allowNegativeStock ?? false) && !input.allowNegativeOverride) {
    throw new ApiError("STOCK_001", `الكمية المتوفرة غير كافية — المتاح: ${fmt(current)}`, [
      { field: "qty", message: `المتاح في المستودع ${fmt(current)} فقط والمطلوب ${fmt(qty)}` },
    ]);
  }

  await tx.stockBalance.upsert({
    where: { warehouseId_productId: { warehouseId, productId } },
    create: { companyId, warehouseId, productId, qty: after },
    update: { qty: after },
  });

  await tx.stockMovement.create({
    data: {
      companyId,
      warehouseId,
      productId,
      direction,
      qty,
      unitCost: input.unitCost == null ? null : qtyR(dec(input.unitCost)),
      refType: input.refType,
      refId: input.refId ?? null,
      balanceAfter: after,
      note: input.note ?? null,
      createdBy: input.userId ?? null,
    },
  });

  return { balanceAfter: after };
}

function fmt(v: Decimal): string {
  return v.isInteger() ? v.toString() : v.toDecimalPlaces(3, Decimal.ROUND_HALF_UP).toString();
}

/** Total on-hand for a product across the given warehouses (or all). */
export async function totalOnHand(companyId: number, productId: number, warehouseIds?: number[]): Promise<Decimal> {
  const rows = await db.stockBalance.aggregate({
    where: {
      companyId,
      productId,
      ...(warehouseIds?.length ? { warehouseId: { in: warehouseIds } } : {}),
    },
    _sum: { qty: true },
  });
  return qtyR(dec(rows._sum.qty));
}
