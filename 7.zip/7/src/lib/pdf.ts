// @ts-nocheck
// =====================================================================
// Server-side PDF engine (§57 — PDF خادمي gap closure).
// Renders a print-ready RTL Arabic invoice through headless Chromium
// (playwright — already available in this environment) into real PDF
// bytes. The Arabic Naskh font is embedded as a base64 data-URI so the
// output is self-contained and portable to any viewer/printer.
//
// Fallback contract: if no Chromium engine is reachable the caller gets
// SRV_002 (503) with a clear Arabic hint to use browser printing — the
// A4/thermal print styles remain the always-available path.
// =====================================================================

import { readFileSync } from "fs";
import path from "path";

let fontB64: string | null = null;
function naskhFontB64(): string | null {
  if (fontB64 !== null) return fontB64;
  try {
    fontB64 = readFileSync(path.join(process.cwd(), "assets", "fonts", "naskh.b64"), "utf8").trim();
  } catch {
    fontB64 = "";
  }
  return fontB64 || null;
}

type PlaywrightModule = {
  chromium: {
    launch(opts?: Record<string, unknown>): Promise<{
      newPage(): Promise<{
        setContent(html: string, opts?: Record<string, unknown>): Promise<void>;
        pdf(opts?: Record<string, unknown>): Promise<Buffer>;
      }>;
      close(): Promise<void>;
    }>;
  };
};

let cachedModule: PlaywrightModule | null = null;

// Runtime-only module resolution — specifiers are built dynamically so
// the bundler never tries to statically resolve them (playwright lives
// in the global npm root, outside the project's node_modules; also
// declared in serverExternalPackages).
async function loadPlaywright(): Promise<PlaywrightModule> {
  if (cachedModule) return cachedModule;
  const { createRequire } = await import("module");
  const spec = ["play", "wright"].join(""); // opaque to the bundler
  const globalIndex = "/home/z/.npm-global/lib/node_modules/playwright/index.js";
  const projectBase = path.join(process.cwd(), "package.json");
  const candidates: (() => PlaywrightModule)[] = [
    () => createRequire(projectBase)(spec) as PlaywrightModule,
    () => createRequire(projectBase)(globalIndex) as PlaywrightModule,
  ];
  for (const tryLoad of candidates) {
    try {
      cachedModule = tryLoad();
      return cachedModule;
    } catch {
      /* next candidate */
    }
  }
  throw new Error("playwright-not-available");
}

export async function htmlToPdf(html: string): Promise<Buffer> {
  const pw = await loadPlaywright();
  const browser = await pw.chromium.launch({ headless: true, args: ["--no-sandbox", "--disable-dev-shm-usage"] });
  try {
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: "load" });
    const pdf = await page.pdf({
      format: "A4",
      printBackground: true,
      margin: { top: "10mm", bottom: "10mm", left: "8mm", right: "8mm" },
    });
    return Buffer.from(pdf);
  } finally {
    await browser.close().catch(() => {});
  }
}

export function isPdfEngineAvailable(): boolean {
  return naskhFontB64() !== null;
}

// ---------------------------------------------------------------------
// Invoice HTML — RTL, A4, company header, lines table, ZATCA-style QR.
// ---------------------------------------------------------------------
export interface InvoicePdfLine {
  product: string;
  unit: string | null;
  qtyUnits: number | null;
  qty: number;
  unitPrice: number;
  discountPct: number;
  lineTotal: number;
}

export interface InvoicePdfData {
  companyName: string;
  companyPhone?: string | null;
  companyAddress?: string | null;
  companyTaxNumber?: string | null;
  branchName: string;
  warehouseName: string;
  number: string;
  invoiceDate: string;
  dueDate?: string | null;
  type: string;
  customerName: string;
  customerCode: string;
  customerPhone?: string | null;
  salesRep?: string | null;
  subtotal: number;
  discountTotal: number;
  taxTotal: number;
  grandTotal: number;
  paidAmount: number;
  lines: InvoicePdfLine[];
  qrSvg: string;
}

const fmt = (n: number) => new Intl.NumberFormat("ar-IQ", { maximumFractionDigits: 2 }).format(n);

export function buildInvoiceHtml(d: InvoicePdfData): string {
  const font = naskhFontB64();
  const fontFace = font
    ? `@font-face{font-family:'NaskhAR';src:url(data:font/ttf;base64,${font}) format('truetype');font-weight:400 700;}`
    : "";
  const bodyFont = font ? "'NaskhAR'" : "'DejaVu Sans','FreeSerif',sans-serif";
  const rows = d.lines
    .map(
      (l, i) => `<tr>
      <td class="c">${i + 1}</td>
      <td>${l.product}</td>
      <td class="c">${l.qtyUnits != null ? `${fmt(l.qtyUnits)} ${l.unit ?? ""}` : fmt(l.qty)}</td>
      <td class="c">${fmt(l.unitPrice)}</td>
      <td class="c">${l.discountPct ? `${l.discountPct}%` : "—"}</td>
      <td class="c b">${fmt(l.lineTotal)}</td>
    </tr>`
    )
    .join("");

  return `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><style>
  ${fontFace}
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:${bodyFont},sans-serif;font-size:13px;color:#1e293b;padding:8px}
  .head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #ea580c;padding-bottom:10px;margin-bottom:14px}
  .brand{font-size:20px;font-weight:700;color:#1e293b}
  .meta{font-size:11px;color:#64748b;margin-top:3px;line-height:1.7}
  .doc{border:2px solid #ea580c;border-radius:10px;padding:8px 14px;text-align:center;background:#fff7ed}
  .doc h2{font-size:15px;color:#ea580c;margin-bottom:2px}
  .doc .num{font-size:13px;font-weight:700;direction:ltr}
  .info{display:flex;gap:10px;margin-bottom:12px}
  .box{flex:1;border:1px solid #e2e8f0;border-radius:8px;padding:8px 10px;background:#f8fafc}
  .box h3{font-size:11px;color:#ea580c;margin-bottom:4px}
  .box p{font-size:12px;line-height:1.8}
  table{width:100%;border-collapse:collapse;margin-bottom:10px}
  th{background:#1e293b;color:#fff;font-size:11px;padding:6px 4px}
  td{border:1px solid #e2e8f0;padding:5px 6px;font-size:12px}
  .c{text-align:center}
  .b{font-weight:700}
  .totals{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}
  .qrbox{text-align:center;border:1px solid #e2e8f0;border-radius:8px;padding:8px}
  .qrbox .cap{font-size:9px;color:#64748b;margin-top:3px}
  .sum{width:46%;border:1px solid #e2e8f0;border-radius:8px;overflow:hidden}
  .sum div{display:flex;justify-content:space-between;padding:6px 10px;font-size:12px;border-bottom:1px solid #eef2f7}
  .sum .g{background:#fff7ed;font-weight:700;font-size:14px;color:#ea580c}
  .foot{margin-top:14px;border-top:1px dashed #cbd5e1;padding-top:6px;display:flex;justify-content:space-between;font-size:10px;color:#94a3b8}
  </style></head><body>
  <div class="head">
    <div>
      <div class="brand">${d.companyName}</div>
      <div class="meta">${d.companyPhone ? `هاتف: ${d.companyPhone} · ` : ""}${d.companyAddress ?? ""}${d.companyTaxNumber ? ` · الرقم الضريبي: ${d.companyTaxNumber}` : ""}</div>
    </div>
    <div class="doc">
      <h2>${d.type === "CASH" ? "فاتورة نقدية" : "فاتورة آجلة"}</h2>
      <div class="num">${d.number}</div>
    </div>
  </div>
  <div class="info">
    <div class="box"><h3>بيانات العميل</h3><p><b>${d.customerName}</b> (${d.customerCode})${d.customerPhone ? `<br/>هاتف: ${d.customerPhone}` : ""}</p></div>
    <div class="box"><h3>تفاصيل الإصدار</h3><p>التاريخ: ${d.invoiceDate}<br/>الفرع: ${d.branchName} · المستودع: ${d.warehouseName}${d.salesRep ? `<br/>المندوب: ${d.salesRep}` : ""}${d.dueDate ? `<br/>الاستحقاق: ${d.dueDate}` : ""}</p></div>
    <div class="qrbox">${d.qrSvg.replace("<svg", '<svg width="92" height="92"').replace('width="160"', 'width="92"').replace('height="160"', 'height="92"')}<div class="cap">رمز الفوترة الإلكترونية TLV</div></div>
  </div>
  <table>
    <thead><tr><th style="width:30px">#</th><th>المنتج</th><th style="width:90px">الكمية</th><th style="width:90px">سعر الوحدة</th><th style="width:60px">خصم</th><th style="width:110px">الإجمالي</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="totals">
    <div class="sum">
      <div><span>المجموع قبل الخصم</span><span>${fmt(d.subtotal)} د.ع</span></div>
      <div><span>الخصم</span><span>${fmt(d.discountTotal)} د.ع</span></div>
      <div><span>الضريبة</span><span>${fmt(d.taxTotal)} د.ع</span></div>
      <div class="g"><span>الإجمالي النهائي</span><span>${fmt(d.grandTotal)} د.ع</span></div>
      <div><span>المدفوع</span><span>${fmt(d.paidAmount)} د.ع</span></div>
      <div><span>المتبقي</span><span>${fmt(Math.max(0, d.grandTotal - d.paidAmount))} د.ع</span></div>
    </div>
  </div>
  <div class="foot"><span>أُنشئت إلكترونيًا بواسطة نظام ميدان لمبيعات والتوزيع — ${new Date().toLocaleString("ar-IQ")}</span><span>التوقيع: ______________</span></div>
  </body></html>`;
}

// ---------------------------------------------------------------------
// Receipt Voucher HTML (وصل القبض) — RTL, A4, with QR
// ---------------------------------------------------------------------
export interface ReceiptVoucherPdfData {
  companyName: string;
  companyPhone?: string | null;
  companyAddress?: string | null;
  companyTaxNumber?: string | null;
  branchName?: string | null;
  number: string;
  receiptDate: string;
  cashboxName: string;
  recipientName: string;
  customerCode?: string | null;
  customerPhone?: string | null;
  amount: number;
  amountInWords: string;
  currency: string;
  paymentMethod: string;
  referenceNumber?: string | null;
  bankName?: string | null;
  bankAccount?: string | null;
  description?: string | null;
  receivedBy?: string | null;
  notes?: string | null;
  // Invoice snapshot
  invoiceNumber?: string | null;
  grandTotal?: number | null;
  previouslyPaid?: number | null;
  currentPayment?: number | null;
  remaining?: number | null;
  // Customer balance snapshot
  previousBalance?: number | null;
  newBalance?: number | null;
  qrSvg: string;
  qrVerifyUrl: string;
}

export function buildReceiptVoucherHtml(d: ReceiptVoucherPdfData): string {
  const font = naskhFontB64();
  const fontFace = font ? `@font-face{font-family:'NaskhAR';src:url(data:font/ttf;base64,${font}) format('truetype');font-weight:400 700;}` : "";
  const bodyFont = font ? "'NaskhAR'" : "'DejaVu Sans','FreeSerif',sans-serif";
  const pm = { CASH: "نقدي", CARD: "بطاقة", BANK_TRANSFER: "تحويل بنكي", ELECTRONIC: "إلكتروني" } as Record<string, string>;

  return `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><style>
  ${fontFace}
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:${bodyFont},sans-serif;font-size:13px;color:#1e293b;padding:8px}
  .head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #059669;padding-bottom:10px;margin-bottom:14px}
  .brand{font-size:20px;font-weight:700;color:#1e293b}
  .meta{font-size:11px;color:#64748b;margin-top:3px;line-height:1.7}
  .doc{border:2px solid #059669;border-radius:10px;padding:8px 14px;text-align:center;background:#ecfdf5}
  .doc h2{font-size:15px;color:#059669;margin-bottom:2px}
  .doc .num{font-size:13px;font-weight:700;direction:ltr}
  .info{display:flex;gap:10px;margin-bottom:12px}
  .box{flex:1;border:1px solid #e2e8f0;border-radius:8px;padding:8px 10px;background:#f8fafc}
  .box h3{font-size:11px;color:#059669;margin-bottom:4px}
  .box p{font-size:12px;line-height:1.8}
  .amount-box{border:2px solid #059669;border-radius:10px;padding:14px;text-align:center;background:#ecfdf5;margin-bottom:12px}
  .amount-box .amt{font-size:28px;font-weight:700;color:#059669;direction:ltr}
  .amount-box .words{font-size:12px;color:#64748b;margin-top:4px}
  .table{width:100%;border-collapse:collapse;margin-bottom:10px}
  th{background:#1e293b;color:#fff;font-size:11px;padding:6px}
  td{border:1px solid #e2e8f0;padding:5px 8px;font-size:12px}
  .totals{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}
  .qrbox{text-align:center;border:1px solid #e2e8f0;border-radius:8px;padding:8px}
  .qrbox .cap{font-size:9px;color:#64748b;margin-top:3px}
  .sum{width:60%;border:1px solid #e2e8f0;border-radius:8px;overflow:hidden}
  .sum div{display:flex;justify-content:space-between;padding:6px 10px;font-size:12px;border-bottom:1px solid #eef2f7}
  .sum .g{background:#ecfdf5;font-weight:700;font-size:14px;color:#059669}
  .signatures{display:flex;justify-content:space-between;margin-top:20px}
  .sig{text-align:center;font-size:11px;color:#64748b}
  .sig .line{border-top:1px solid #94a3b8;width:150px;margin:30px auto 5px}
  .foot{margin-top:14px;border-top:1px dashed #cbd5e1;padding-top:6px;display:flex;justify-content:space-between;font-size:10px;color:#94a3b8}
  </style></head><body>
  <div class="head">
    <div>
      <div class="brand">${d.companyName}</div>
      <div class="meta">${d.companyPhone ? `هاتف: ${d.companyPhone} · ` : ""}${d.companyAddress ?? ""}${d.companyTaxNumber ? ` · الرقم الضريبي: ${d.companyTaxNumber}` : ""}${d.branchName ? ` · فرع: ${d.branchName}` : ""}</div>
    </div>
    <div class="doc">
      <h2>وصل قبض</h2>
      <div class="num">${d.number}</div>
    </div>
  </div>
  <div class="info">
    <div class="box"><h3>استلمنا من</h3><p><b>${d.recipientName}</b>${d.customerCode ? ` (${d.customerCode})` : ""}${d.customerPhone ? `<br/>هاتف: ${d.customerPhone}` : ""}</p></div>
    <div class="box"><h3>التفاصيل</h3><p>التاريخ: ${d.receiptDate}<br/>الصندوق: ${d.cashboxName}<br/>الطريقة: ${pm[d.paymentMethod] ?? d.paymentMethod}${d.referenceNumber ? `<br/>مرجع: ${d.referenceNumber}` : ""}${d.bankName ? `<br/>بنك: ${d.bankName}` : ""}${d.receivedBy ? `<br/>المستلم: ${d.receivedBy}` : ""}</p></div>
    <div class="qrbox">${d.qrSvg.replace('width="160"','width="80"').replace('height="160"','height="80"')}<div class="cap">تحقق: ${d.qrVerifyUrl}</div></div>
  </div>
  <div class="amount-box">
    <div class="amt">${fmt(d.amount)} ${d.currency === "USD" ? "$" : "د.ع"}</div>
    <div class="words">${d.amountInWords}</div>
  </div>
  ${d.invoiceNumber ? `<table class="table">
    <thead><tr><th>الفاتورة</th><th>الإجمالي</th><th>المدفوع سابقًا</th><th>الدفعة الحالية</th><th>المتبقي</th></tr></thead>
    <tbody><tr>
      <td class="c">${d.invoiceNumber}</td>
      <td class="c b">${fmt(d.grandTotal ?? 0)}</td>
      <td class="c">${fmt(d.previouslyPaid ?? 0)}</td>
      <td class="c b" style="color:#059669">${fmt(d.currentPayment ?? 0)}</td>
      <td class="c b" style="color:#dc2626">${fmt(d.remaining ?? 0)}</td>
    </tr></tbody>
  </table>` : ""}
  ${d.previousBalance !== null && d.previousBalance !== undefined ? `<div class="sum" style="margin-bottom:10px">
    <div><span>الرصيد السابق</span><span>${fmt(d.previousBalance)} د.ع</span></div>
    <div><span>الدفعة الحالية</span><span style="color:#059669;font-weight:700">− ${fmt(d.amount)} د.ع</span></div>
    <div class="g"><span>الرصيد الجديد</span><span>${fmt(d.newBalance ?? 0)} د.ع</span></div>
  </div>` : ""}
  ${d.description ? `<div style="font-size:11px;color:#64748b;margin-bottom:8px;padding:6px 10px;background:#f8fafc;border-radius:6px">الوصف: ${d.description}</div>` : ""}
  ${d.notes ? `<div style="font-size:11px;color:#64748b;margin-bottom:8px;padding:6px 10px;background:#fef3c7;border-radius:6px">ملاحظات: ${d.notes}</div>` : ""}
  <div class="signatures">
    <div class="sig"><div class="line"></div>المستلم</div>
    <div class="sig"><div class="line"></div>الكاشير</div>
    <div class="sig"><div class="line"></div>المراجع</div>
  </div>
  <div class="foot"><span>وصل إلكتروني — نظام ميدان ERP — ${new Date().toLocaleString("ar-IQ")}</span><span>${d.verifyToken ? `Token: ${d.verifyToken.slice(0, 12)}...` : ""}</span></div>
  </body></html>`;
}

// ---------------------------------------------------------------------
// Payment Voucher HTML (وصل الصرف) — RTL, A4, with QR
// ---------------------------------------------------------------------
export interface PaymentVoucherPdfData {
  companyName: string;
  companyPhone?: string | null;
  companyAddress?: string | null;
  companyTaxNumber?: string | null;
  branchName?: string | null;
  number: string;
  voucherDate: string;
  cashboxName: string;
  beneficiaryName: string;
  supplierCode?: string | null;
  amount: number;
  amountInWords: string;
  currency: string;
  paymentMethod: string;
  referenceNumber?: string | null;
  bankName?: string | null;
  bankAccount?: string | null;
  reason: string;
  expenseCategory?: string | null;
  description?: string | null;
  notes?: string | null;
  paidTo?: string | null;
  qrSvg: string;
  qrVerifyUrl: string;
}

export function buildPaymentVoucherHtml(d: PaymentVoucherPdfData): string {
  const font = naskhFontB64();
  const fontFace = font ? `@font-face{font-family:'NaskhAR';src:url(data:font/ttf;base64,${font}) format('truetype');font-weight:400 700;}` : "";
  const bodyFont = font ? "'NaskhAR'" : "'DejaVu Sans','FreeSerif',sans-serif";
  const pm = { CASH: "نقدي", CARD: "بطاقة", BANK_TRANSFER: "تحويل بنكي", ELECTRONIC: "إلكتروني", ON_ACCOUNT: "على الحساب" } as Record<string, string>;
  const reasonAr: Record<string, string> = { PAYMENT_TO_SUPPLIER: "دفع لمورد", EXPENSE: "مصروف", ADVANCE: "سلفة", DIRECT_PURCHASE: "شراء مباشر", REFUND: "رد مبلغ", OPERATING_EXPENSE: "مصاريف تشغيل", BANK_TRANSFER: "تحويل بنكي", OTHER: "أخرى" };

  return `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><style>
  ${fontFace}
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:${bodyFont},sans-serif;font-size:13px;color:#1e293b;padding:8px}
  .head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #dc2626;padding-bottom:10px;margin-bottom:14px}
  .brand{font-size:20px;font-weight:700;color:#1e293b}
  .meta{font-size:11px;color:#64748b;margin-top:3px;line-height:1.7}
  .doc{border:2px solid #dc2626;border-radius:10px;padding:8px 14px;text-align:center;background:#fef2f2}
  .doc h2{font-size:15px;color:#dc2626;margin-bottom:2px}
  .doc .num{font-size:13px;font-weight:700;direction:ltr}
  .info{display:flex;gap:10px;margin-bottom:12px}
  .box{flex:1;border:1px solid #e2e8f0;border-radius:8px;padding:8px 10px;background:#f8fafc}
  .box h3{font-size:11px;color:#dc2626;margin-bottom:4px}
  .box p{font-size:12px;line-height:1.8}
  .amount-box{border:2px solid #dc2626;border-radius:10px;padding:14px;text-align:center;background:#fef2f2;margin-bottom:12px}
  .amount-box .amt{font-size:28px;font-weight:700;color:#dc2626;direction:ltr}
  .amount-box .words{font-size:12px;color:#64748b;margin-top:4px}
  .qrbox{text-align:center;border:1px solid #e2e8f0;border-radius:8px;padding:8px;flex-shrink:0}
  .qrbox .cap{font-size:9px;color:#64748b;margin-top:3px}
  .signatures{display:flex;justify-content:space-between;margin-top:20px}
  .sig{text-align:center;font-size:11px;color:#64748b}
  .sig .line{border-top:1px solid #94a3b8;width:150px;margin:30px auto 5px}
  .foot{margin-top:14px;border-top:1px dashed #cbd5e1;padding-top:6px;display:flex;justify-content:space-between;font-size:10px;color:#94a3b8}
  </style></head><body>
  <div class="head">
    <div>
      <div class="brand">${d.companyName}</div>
      <div class="meta">${d.companyPhone ? `هاتف: ${d.companyPhone} · ` : ""}${d.companyAddress ?? ""}${d.companyTaxNumber ? ` · الرقم الضريبي: ${d.companyTaxNumber}` : ""}${d.branchName ? ` · فرع: ${d.branchName}` : ""}</div>
    </div>
    <div class="doc">
      <h2>وصل صرف</h2>
      <div class="num">${d.number}</div>
    </div>
  </div>
  <div class="info">
    <div class="box"><h3>المستفيد</h3><p><b>${d.beneficiaryName}</b>${d.supplierCode ? ` (${d.supplierCode})` : ""}${d.paidTo ? `<br/>استلم: ${d.paidTo}` : ""}</p></div>
    <div class="box"><h3>التفاصيل</h3><p>التاريخ: ${d.voucherDate}<br/>الصندوق: ${d.cashboxName}<br/>السبب: ${reasonAr[d.reason] ?? d.reason}${d.expenseCategory ? `<br/>البند: ${d.expenseCategory}` : ""}<br/>الطريقة: ${pm[d.paymentMethod] ?? d.paymentMethod}${d.referenceNumber ? `<br/>مرجع: ${d.referenceNumber}` : ""}${d.bankName ? `<br/>بنك: ${d.bankName}` : ""}</p></div>
    <div class="qrbox">${d.qrSvg.replace('width="160"','width="80"').replace('height="160"','height="80"')}<div class="cap">تحقق: ${d.qrVerifyUrl}</div></div>
  </div>
  <div class="amount-box">
    <div class="amt">${fmt(d.amount)} ${d.currency === "USD" ? "$" : "د.ع"}</div>
    <div class="words">${d.amountInWords}</div>
  </div>
  ${d.description ? `<div style="font-size:11px;color:#64748b;margin-bottom:8px;padding:6px 10px;background:#f8fafc;border-radius:6px">الوصف: ${d.description}</div>` : ""}
  ${d.notes ? `<div style="font-size:11px;color:#64748b;margin-bottom:8px;padding:6px 10px;background:#fef3c7;border-radius:6px">ملاحظات: ${d.notes}</div>` : ""}
  <div class="signatures">
    <div class="sig"><div class="line"></div>المستفيد</div>
    <div class="sig"><div class="line"></div>الكاشير</div>
    <div class="sig"><div class="line"></div>المراجع</div>
  </div>
  <div class="foot"><span>وصل إلكتروني — نظام ميدان ERP — ${new Date().toLocaleString("ar-IQ")}</span><span>${d.qrVerifyUrl ? `Token: ${d.qrVerifyUrl.slice(0, 12)}...` : ""}</span></div>
  </body></html>`;
}

// ---------------------------------------------------------------------
// Amount in words (Arabic) — يحول الرقم إلى نص عربي
// ---------------------------------------------------------------------
export function amountInWords(amount: number, currency: string = "IQD"): string {
  if (amount === 0) return "صفر";
  const ones = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة", "عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"];
  const tens = ["", "عشرة", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"];
  const hundreds = ["", "مائة", "مئتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسعمائة"];
  const scales = ["", "ألف", "مليون", "مليار"];

  function threeDigits(n: number): string {
    let result = "";
    const h = Math.floor(n / 100);
    const rem = n % 100;
    if (h > 0) result += hundreds[h];
    if (rem > 0) {
      if (result) result += " و";
      if (rem < 20) result += ones[rem];
      else {
        const t = Math.floor(rem / 10);
        const o = rem % 10;
        if (o > 0) result += ones[o] + " و" + tens[t];
        else result += tens[t];
      }
    }
    return result;
  }

  let num = Math.floor(amount);
  let result = "";
  let scaleIdx = 0;
  while (num > 0) {
    const chunk = num % 1000;
    if (chunk > 0) {
      const chunkStr = threeDigits(chunk);
      if (scaleIdx > 0) {
        if (scaleIdx === 1 && chunk <= 2) {
          result = chunk === 1 ? "ألف" : "ألفان" + (result ? " و" + result : "");
        } else if (scaleIdx === 1 && chunk <= 10) {
          result = ones[chunk] + " آلاف" + (result ? " و" + result : "");
        } else {
          result = chunkStr + " " + scales[scaleIdx] + (result ? " و" + result : "");
        }
      } else {
        result = chunkStr;
      }
    }
    num = Math.floor(num / 1000);
    scaleIdx++;
  }

  const cur = currency === "USD" ? "دولار أمريكي" : "دينار عراقي";
  const fraction = Math.round((amount - Math.floor(amount)) * 100);
  let fracStr = "";
  if (fraction > 0) {
    fracStr = " و" + threeDigits(fraction) + (currency === "USD" ? " سنت" : " فلس");
  }
  return result + " " + cur + fracStr + " فقط لا غير";
}

// ---------------------------------------------------------------------
// Thermal 80mm Receipt HTML (وصل حراري للطابعات الحرارية)
// ---------------------------------------------------------------------
export function buildReceiptThermalHtml(d: ReceiptVoucherPdfData): string {
  const pm = { CASH: "نقدي", CARD: "بطاقة", BANK_TRANSFER: "تحويل", ELECTRONIC: "إلكتروني" } as Record<string, string>;
  return `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Courier New',monospace;font-size:11px;color:#000;width:76mm;padding:2mm}
  .center{text-align:center}
  .right{text-align:right}
  .bold{font-weight:bold}
  .divider{border-top:1px dashed #000;margin:3px 0}
  .double{border-top:2px solid #000;margin:3px 0}
  .row{display:flex;justify-content:space-between;margin:1px 0}
  .big{font-size:16px;font-weight:bold}
  .red{color:#dc2626}
  .qr{text-align:center;margin:3px 0}
  .qr svg{width:50px;height:50px}
  .stamp{text-align:center;font-size:20px;font-weight:bold;color:#dc2626;border:2px solid #dc2626;border-radius:50%;width:60px;height:60px;line-height:60px;margin:5px auto;transform:rotate(-15deg)}
  </style></head><body>
  ${d.status === "CANCELLED" ? '<div class="stamp">ملغى</div>' : ''}
  <div class="center bold big">${d.companyName}</div>
  <div class="center">${d.companyPhone ?? ""}</div>
  <div class="center">${d.companyAddress ?? ""}</div>
  <div class="divider"></div>
  <div class="center bold">وصل قبض</div>
  <div class="center bold">${d.number}</div>
  <div class="divider"></div>
  <div class="row"><span>التاريخ:</span><span>${d.receiptDate}</span></div>
  <div class="row"><span>الصندوق:</span><span>${d.cashboxName}</span></div>
  <div class="row"><span>الطريقة:</span><span>${pm[d.paymentMethod] ?? d.paymentMethod}</span></div>
  ${d.referenceNumber ? `<div class="row"><span>المرجع:</span><span>${d.referenceNumber}</span></div>` : ""}
  <div class="divider"></div>
  <div class="row bold"><span>استلمنا من:</span></div>
  <div class="bold">${d.recipientName}</div>
  ${d.customerCode ? `<div class="row"><span>الكود:</span><span>${d.customerCode}</span></div>` : ""}
  <div class="divider"></div>
  <div class="center big">${fmt(d.amount)} ${d.currency === "USD" ? "$" : "د.ع"}</div>
  <div class="center" style="font-size:9px">${d.amountInWords}</div>
  <div class="divider"></div>
  ${d.invoiceNumber ? `
  <div class="row"><span>الفاتورة:</span><span>${d.invoiceNumber}</span></div>
  <div class="row"><span>الإجمالي:</span><span>${fmt(d.grandTotal ?? 0)}</span></div>
  <div class="row"><span>المدفوع سابقًا:</span><span>${fmt(d.previouslyPaid ?? 0)}</span></div>
  <div class="row bold"><span>الدفعة الحالية:</span><span>${fmt(d.currentPayment ?? 0)}</span></div>
  <div class="row bold red"><span>المتبقي:</span><span>${fmt(d.remaining ?? 0)}</span></div>
  <div class="divider"></div>` : ""}
  ${d.previousBalance !== null && d.previousBalance !== undefined ? `
  <div class="row"><span>الرصيد السابق:</span><span>${fmt(d.previousBalance)}</span></div>
  <div class="row bold"><span>الرصيد الجديد:</span><span>${fmt(d.newBalance ?? 0)}</span></div>
  <div class="divider"></div>` : ""}
  <div class="qr">${d.qrSvg.replace('width="160"','width="50"').replace('height="160"','height="50"')}</div>
  <div class="center" style="font-size:8px">${d.qrVerifyUrl}</div>
  <div class="double"></div>
  <div class="center">المستلم: ____________</div>
  <div class="center">الكاشير: ____________</div>
  <div class="center" style="font-size:8px;margin-top:3px">نظام ميدان ERP — ${new Date().toLocaleString("ar-IQ")}</div>
  </body></html>`;
}

// ---------------------------------------------------------------------
// Payment Voucher Thermal 80mm
// ---------------------------------------------------------------------
export function buildPaymentVoucherThermalHtml(d: PaymentVoucherPdfData): string {
  const pm = { CASH: "نقدي", CARD: "بطاقة", BANK_TRANSFER: "تحويل", ELECTRONIC: "إلكتروني", ON_ACCOUNT: "على الحساب" } as Record<string, string>;
  const reasonAr: Record<string, string> = { PAYMENT_TO_SUPPLIER: "دفع لمورد", EXPENSE: "مصروف", ADVANCE: "سلفة", OTHER: "أخرى" };
  return `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Courier New',monospace;font-size:11px;color:#000;width:76mm;padding:2mm}
  .center{text-align:center}
  .right{text-align:right}
  .bold{font-weight:bold}
  .divider{border-top:1px dashed #000;margin:3px 0}
  .double{border-top:2px solid #000;margin:3px 0}
  .row{display:flex;justify-content:space-between;margin:1px 0}
  .big{font-size:16px;font-weight:bold}
  .qr{text-align:center;margin:3px 0}
  .qr svg{width:50px;height:50px}
  </style></head><body>
  <div class="center bold big">${d.companyName}</div>
  <div class="center">${d.companyPhone ?? ""}</div>
  <div class="divider"></div>
  <div class="center bold">وصل صرف</div>
  <div class="center bold">${d.number}</div>
  <div class="divider"></div>
  <div class="row"><span>التاريخ:</span><span>${d.voucherDate}</span></div>
  <div class="row"><span>الصندوق:</span><span>${d.cashboxName}</span></div>
  <div class="row"><span>السبب:</span><span>${reasonAr[d.reason] ?? d.reason}</span></div>
  ${d.expenseCategory ? `<div class="row"><span>البند:</span><span>${d.expenseCategory}</span></div>` : ""}
  <div class="row"><span>الطريقة:</span><span>${pm[d.paymentMethod] ?? d.paymentMethod}</span></div>
  <div class="divider"></div>
  <div class="row bold"><span>المستفيد:</span></div>
  <div class="bold">${d.beneficiaryName}</div>
  ${d.paidTo ? `<div class="row"><span>استلم:</span><span>${d.paidTo}</span></div>` : ""}
  <div class="divider"></div>
  <div class="center big">${fmt(d.amount)} ${d.currency === "USD" ? "$" : "د.ع"}</div>
  <div class="center" style="font-size:9px">${d.amountInWords}</div>
  <div class="divider"></div>
  ${d.description ? `<div style="font-size:9px">${d.description}</div><div class="divider"></div>` : ""}
  <div class="qr">${d.qrSvg.replace('width="160"','width="50"').replace('height="160"','height="50"')}</div>
  <div class="center" style="font-size:8px">${d.qrVerifyUrl}</div>
  <div class="double"></div>
  <div class="center">المستفيد: ____________</div>
  <div class="center">الكاشير: ____________</div>
  <div class="center" style="font-size:8px;margin-top:3px">نظام ميدان ERP — ${new Date().toLocaleString("ar-IQ")}</div>
  </body></html>`;
}

// ---------------------------------------------------------------------
// Batch Daily Receipts PDF (طباعة دفعة وصولات في PDF واحد)
// ---------------------------------------------------------------------
export function buildBatchReceiptsHtml(receipts: ReceiptVoucherPdfData[]): string {
  const pages = receipts.map((d, i) => {
    return `<div style="page-break-after:always">${buildReceiptVoucherHtml(d)}</div>`;
  }).join('');
  return `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><style>
  @page{size:A4;margin:8mm}
  </style></head><body>${pages}</body></html>`;
}

// ---------------------------------------------------------------------
// Watermark "ملغى" overlay for cancelled receipts
// ---------------------------------------------------------------------
export function addWatermark(html: string, text: string = "ملغى"): string {
  return html.replace('<body>', `<body>
  <div style="position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-30deg);
  font-size:80px;font-weight:bold;color:rgba(220,38,38,0.15);z-index:9999;
  pointer-events:none;text-align:center;width:100%">${text}</div>`);
}

// =====================================================================
// AGING STATEMENT PDF — per-customer or per-supplier aging report
// Shows: header, current balance, 5 buckets table, mini-statement rows,
// totals, QR for verification.
// =====================================================================
export interface AgingStatementPdfData {
  companyName: string;
  companyPhone?: string | null;
  companyAddress?: string | null;
  branchName?: string | null;
  actorType: "customer" | "supplier";
  actorCode: string;
  actorName: string;
  actorPhone?: string | null;
  actorAddress?: string | null;
  asOfDate: string;
  totalBalance: number;
  buckets: { current: number; d1_30: number; d31_60: number; d61_90: number; d90_plus: number };
  invoices: {
    number: string;
    date: string;
    grandTotal: number;
    paidAmount: number;
    dueAmount: number;
    ageDays: number;
    bucket: string;
  }[];
  qrSvg: string;
  qrVerifyUrl: string;
}

const fmt2 = (n: number) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(n);

export function buildAgingStatementHtml(d: AgingStatementPdfData): string {
  const font = naskhFontB64();
  const fontFace = font ? `@font-face{font-family:'NaskhAR';src:url(data:font/ttf;base64,${font}) format('truetype');font-weight:400 700;}` : "";
  const bodyFont = font ? "'NaskhAR'" : "'DejaVu Sans','FreeSerif',sans-serif";
  const actorLabel = d.actorType === "customer" ? "العميل" : "المورد";
  const accentColor = d.actorType === "customer" ? "#1d4ed8" : "#7c3aed";

  const bucketRows = [
    { label: "حالي (غير مستحق)", value: d.buckets.current, color: "#16a34a" },
    { label: "1-30 يوم", value: d.buckets.d1_30, color: "#65a30d" },
    { label: "31-60 يوم", value: d.buckets.d31_60, color: "#ca8a04" },
    { label: "61-90 يوم", value: d.buckets.d61_90, color: "#ea580c" },
    { label: "أكثر من 90 يوم", value: d.buckets.d90_plus, color: "#dc2626" },
  ];

  const bucketHtml = bucketRows.map((b) => `
    <tr>
      <td style="padding:8px 12px;border-bottom:1px solid #e2e8f0;font-size:12px">${b.label}</td>
      <td style="padding:8px 12px;border-bottom:1px solid #e2e8f0;text-align:left;direction:ltr;font-weight:700;color:${b.color}">${fmt2(b.value)} د.ع</td>
    </tr>`).join("");

  const invoicesHtml = d.invoices.length === 0
    ? `<div style="text-align:center;padding:20px;color:#94a3b8;font-size:12px">لا توجد فواتير مستحقة</div>`
    : `<table style="width:100%;border-collapse:collapse;font-size:11px">
        <thead>
          <tr style="background:${accentColor};color:#fff">
            <th style="padding:6px 8px;text-align:right">رقم الفاتورة</th>
            <th style="padding:6px 8px;text-align:right">التاريخ</th>
            <th style="padding:6px 8px;text-align:left">الإجمالي</th>
            <th style="padding:6px 8px;text-align:left">المدفوع</th>
            <th style="padding:6px 8px;text-align:left">المتبقي</th>
            <th style="padding:6px 8px;text-align:center">العمر</th>
            <th style="padding:6px 8px;text-align:center">الفئة</th>
          </tr>
        </thead>
        <tbody>
          ${d.invoices.map((inv) => `
            <tr style="border-bottom:1px solid #e2e8f0">
              <td style="padding:6px 8px;direction:ltr;font-family:monospace;text-align:right">${inv.number}</td>
              <td style="padding:6px 8px">${inv.date}</td>
              <td style="padding:6px 8px;text-align:left;direction:ltr">${fmt2(inv.grandTotal)}</td>
              <td style="padding:6px 8px;text-align:left;direction:ltr">${fmt2(inv.paidAmount)}</td>
              <td style="padding:6px 8px;text-align:left;direction:ltr;font-weight:700;color:${accentColor}">${fmt2(inv.dueAmount)}</td>
              <td style="padding:6px 8px;text-align:center">${inv.ageDays} يوم</td>
              <td style="padding:6px 8px;text-align:center;font-size:10px">${inv.bucket}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>`;

  return `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><style>
  ${fontFace}
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:${bodyFont},sans-serif;font-size:13px;color:#1e293b;padding:8px}
  @page{size:A4;margin:8mm}
  .head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid ${accentColor};padding-bottom:10px;margin-bottom:14px}
  .brand{font-size:20px;font-weight:700;color:#1e293b}
  .meta{font-size:11px;color:#64748b;margin-top:3px;line-height:1.7}
  .doc{border:2px solid ${accentColor};border-radius:10px;padding:8px 14px;text-align:center;background:${d.actorType === "customer" ? "#eff6ff" : "#faf5ff"}}
  .doc h2{font-size:15px;color:${accentColor};margin-bottom:2px}
  .doc .num{font-size:11px;color:#64748b}
  .info{display:flex;gap:10px;margin-bottom:12px}
  .box{flex:1;border:1px solid #e2e8f0;border-radius:8px;padding:8px 10px;background:#f8fafc}
  .box h3{font-size:11px;color:${accentColor};margin-bottom:4px}
  .box p{font-size:12px;line-height:1.8}
  .amount-box{border:2px solid ${accentColor};border-radius:10px;padding:14px;text-align:center;background:${d.actorType === "customer" ? "#eff6ff" : "#faf5ff"};margin-bottom:12px}
  .amount-box .label{font-size:12px;color:#64748b}
  .amount-box .amt{font-size:28px;font-weight:700;color:${accentColor};direction:ltr;margin-top:4px}
  .buckets{margin-bottom:14px}
  .buckets table{width:100%;border-collapse:collapse;border:1px solid #e2e8f0;border-radius:6px;overflow:hidden}
  .buckets th{background:#f1f5f9;padding:8px 12px;text-align:right;font-size:11px;color:#475569;border-bottom:2px solid #e2e8f0}
  .qrbox{text-align:center;border:1px solid #e2e8f0;border-radius:8px;padding:8px;flex-shrink:0}
  .qrbox .cap{font-size:9px;color:#64748b;margin-top:3px}
  .invoices{margin-bottom:14px}
  .invoices h3{font-size:12px;color:${accentColor};margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid #e2e8f0}
  .signatures{display:flex;justify-content:space-between;margin-top:24px}
  .sig{text-align:center;font-size:11px;color:#64748b}
  .sig .line{border-top:1px solid #94a3b8;width:150px;margin:30px auto 5px}
  .foot{margin-top:14px;border-top:1px dashed #cbd5e1;padding-top:6px;display:flex;justify-content:space-between;font-size:10px;color:#94a3b8}
  </style></head><body>
  <div class="head">
    <div>
      <div class="brand">${d.companyName}</div>
      <div class="meta">${d.companyPhone ? `هاتف: ${d.companyPhone} · ` : ""}${d.companyAddress ?? ""}${d.branchName ? ` · فرع: ${d.branchName}` : ""}</div>
    </div>
    <div class="doc">
      <h2>تقرير أعمار الديون</h2>
      <div class="num">${actorLabel}: ${d.actorCode} — ${d.asOfDate}</div>
    </div>
  </div>
  <div class="info">
    <div class="box"><h3>${actorLabel}</h3><p><b>${d.actorName}</b> (${d.actorCode})${d.actorPhone ? `<br/>هاتف: ${d.actorPhone}` : ""}${d.actorAddress ? `<br/>العنوان: ${d.actorAddress}` : ""}</p></div>
    <div class="qrbox">${d.qrSvg.replace('width="160"','width="80"').replace('height="160"','height="80"')}<div class="cap">رمز التحقق: ${d.qrVerifyUrl.slice(-12)}</div></div>
  </div>
  <div class="amount-box">
    <div class="label">إجمالي الرصيد المستحق (إلى تاريخ ${d.asOfDate})</div>
    <div class="amt">${fmt2(d.totalBalance)} د.ع</div>
  </div>
  <div class="buckets">
    <h3 style="font-size:12px;color:${accentColor};margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid #e2e8f0">توزيع الأعمار</h3>
    <table>
      <thead><tr><th>الفئة</th><th style="text-align:left">المبلغ</th></tr></thead>
      <tbody>${bucketHtml}</tbody>
    </table>
  </div>
  <div class="invoices">
    <h3>تفصيل الفواتير المستحقة (${d.invoices.length})</h3>
    ${invoicesHtml}
  </div>
  <div class="signatures">
    <div class="sig"><div class="line"></div>المحاسب</div>
    <div class="sig"><div class="line"></div>${actorLabel}</div>
    <div class="sig"><div class="line"></div>المدير المالي</div>
  </div>
  <div class="foot"><span>تقرير أعمار ديون — نظام ميدان ERP — ${new Date().toLocaleString("ar-IQ")}</span><span>Token: ${d.qrVerifyUrl.slice(0, 12)}...</span></div>
  </body></html>`;
}

// =====================================================================
// Phase 18-20 — Daily Receipts Report (المرحلة 42 من MASTER PROMPT)
// تقرير المقبوضات اليومية لصندوق محدد + فترة زمنية
// =====================================================================

export interface DailyReceiptsReportData {
  companyName: string;
  companyPhone: string | null;
  companyAddress: string | null;
  cashboxId: number;
  cashboxName: string;
  cashboxCode: string;
  cashboxCurrency: string;
  dateFrom: string;
  dateTo: string;
  generatedAt: string;
  receipts: Array<{
    number: string;
    receiptDate: string;
    recipientName: string;
    customerName: string | null;
    amount: number;
    paymentMethod: string;
    referenceNumber: string | null;
    status: string;
  }>;
  totals: {
    count: number;
    totalAmount: number;
    byMethod: Record<string, { count: number; total: number }>;
  };
}

export function buildDailyReceiptsReportHtml(d: DailyReceiptsReportData): string {
  const fmtIQD = (n: number) => new Intl.NumberFormat("ar-IQ", { maximumFractionDigits: 2 }).format(n);

  const methodAr: Record<string, string> = {
    CASH: "نقد",
    CARD: "بطاقة",
    BANK_TRANSFER: "تحويل بنكي",
    ELECTRONIC: "إلكتروني",
    MIXED: "مختلط",
    ON_ACCOUNT: "آجل",
  };

  const rowsHtml = d.receipts.length
    ? d.receipts.map((r) => `
      <tr>
        <td style="font-family: monospace; font-size: 9px;">${r.number}</td>
        <td>${r.receiptDate}</td>
        <td>${r.recipientName}</td>
        <td>${r.customerName ?? "—"}</td>
        <td style="text-align: center;">${methodAr[r.paymentMethod] ?? r.paymentMethod}</td>
        <td style="text-align: left; font-family: monospace; direction: ltr;">${fmtIQD(r.amount)} ${d.cashboxCurrency}</td>
        <td style="text-align: center;">${r.status === "POSTED" ? "مرحّل" : "ملغى"}</td>
      </tr>`).join("")
    : `<tr><td colspan="7" style="text-align: center; padding: 20px;">لا وصلات في هذه الفترة</td></tr>`;

  const methodsHtml = Object.entries(d.totals.byMethod)
    .map(([m, info]) => `<tr><td>${methodAr[m] ?? m}</td><td style="text-align: center;">${info.count}</td><td style="text-align: left; font-family: monospace; direction: ltr;">${fmtIQD(info.total)} ${d.cashboxCurrency}</td></tr>`)
    .join("");

  return `<!DOCTYPE html>
<html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>تقرير المقبوضات اليومية — ${d.cashboxName}</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: 'Noto Sans Arabic', 'Cairo', sans-serif; margin: 16px; color: #1f2937; font-size: 11px; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; padding-bottom: 10px; border-bottom: 2px solid #1e40af; margin-bottom: 16px; }
  .header .company { font-size: 16px; font-weight: bold; color: #1e40af; }
  .header .meta { text-align: left; font-size: 10px; color: #6b7280; }
  h1 { font-size: 14px; margin: 0 0 4px 0; }
  .filters { background: #f3f4f6; padding: 8px 12px; border-radius: 4px; margin-bottom: 12px; font-size: 10px; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
  th, td { padding: 6px 8px; border: 1px solid #d1d5db; font-size: 10px; }
  th { background: #1e40af; color: white; font-weight: 600; text-align: right; }
  tr:nth-child(even) td { background: #f9fafb; }
  .totals { background: #fef3c7; padding: 12px; border-radius: 4px; margin-bottom: 12px; border-right: 4px solid #f59e0b; }
  .totals .big { font-size: 16px; font-weight: bold; color: #1f2937; font-family: monospace; direction: ltr; }
  .signature { display: flex; justify-content: space-between; margin-top: 30px; }
  .sig { text-align: center; font-size: 10px; }
  .sig .line { border-top: 1px solid #6b7280; width: 150px; margin: 30px auto 5px; }
  .footer { text-align: center; margin-top: 24px; font-size: 9px; color: #6b7280; border-top: 1px solid #d1d5db; padding-top: 8px; }
</style></head><body>
  <div class="header">
    <div>
      <div class="company">${d.companyName}</div>
      ${d.companyPhone ? `<div style="font-size: 10px;">هاتف: ${d.companyPhone}</div>` : ""}
      ${d.companyAddress ? `<div style="font-size: 10px;">${d.companyAddress}</div>` : ""}
    </div>
    <div class="meta">
      <div style="font-weight: bold; font-size: 12px;">تقرير المقبوضات اليومية</div>
      <div>الصندوق: ${d.cashboxName} (${d.cashboxCode})</div>
      <div>العملة: ${d.cashboxCurrency}</div>
      <div>الفترة: ${d.dateFrom} ← ${d.dateTo}</div>
      <div>أُنشئ: ${d.generatedAt}</div>
    </div>
  </div>

  <div class="totals">
    <div style="display: flex; justify-content: space-between;">
      <div>عدد الوصولات: <strong>${d.totals.count}</strong></div>
      <div>إجمالي المقبوضات: <span class="big">${fmtIQD(d.totals.totalAmount)} ${d.cashboxCurrency}</span></div>
    </div>
  </div>

  <table>
    <thead><tr>
      <th>رقم الوصل</th><th>التاريخ</th><th>المستلم منه</th><th>العميل</th>
      <th style="text-align: center;">الطريقة</th><th style="text-align: left;">المبلغ</th><th style="text-align: center;">الحالة</th>
    </tr></thead>
    <tbody>${rowsHtml}</tbody>
  </table>

  ${methodsHtml ? `
  <h3 style="margin: 16px 0 6px; font-size: 11px;">تفصيل حسب طريقة الدفع</h3>
  <table>
    <thead><tr><th>الطريقة</th><th style="text-align: center;">العدد</th><th style="text-align: left;">الإجمالي</th></tr></thead>
    <tbody>${methodsHtml}</tbody>
  </table>` : ""}

  <div class="signature">
    <div class="sig"><div class="line"></div>الكاشير</div>
    <div class="sig"><div class="line"></div>المدير المالي</div>
  </div>

  <div class="footer">
    تقرير مقبوضات يومية — نظام ميدان ERP — أُنشئ ${d.generatedAt}
  </div>
</body></html>`;
}
