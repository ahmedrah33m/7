// =====================================================================
// Company provisioning — Multi-Company onboarding engine.
//
// Creating a NEW company provisions a complete, ready-to-operate tenant:
//   1. Company row (+ legal/brand data)
//   2. Default home branch + MAIN warehouse
//   3. The 11 system roles with code-defined permission grants
//   4. Document sequences for the current year (INVOICE/ORDER/…)
//   5. Baseline settings (invoice footer, customer-type labels)
//   6. Shared walk-in customer (CASH-001 زبون نقدي/متردد)
//   7. UserCompanyAccess grant for the creating user → company switcher
//
// The active company name flows automatically to:
//   - sidebar (under the system name)  → scope.companies via /me
//   - printed invoices                 → /api/v1/auth/me company payload
// =====================================================================

import { db } from "./db";
import { SYSTEM_ROLES, rolePermissionCodes } from "./seed";
import { ensureWalkInCustomer } from "./walkin";

export interface ProvisionInput {
  code: string;
  name: string;
  nameEn?: string | null;
  legalName?: string | null;
  taxNumber?: string | null;
  phone?: string | null;
  email?: string | null;
  address?: string | null;
  currencyCode?: string;
  createdBy: number;
}

export interface ProvisionResult {
  companyId: number;
  name: string;
  code: string;
  branchId: number;
  warehouseId: number;
  rolesCreated: number;
}

/** Provision a fully-operational company tenant. Idempotent-safe on codes. */
export async function provisionCompany(input: ProvisionInput): Promise<ProvisionResult> {
  // 1) Company row ----------------------------------------------------------------
  const company = await db.company.create({
    data: {
      code: input.code,
      name: input.name,
      nameEn: input.nameEn ?? null,
      legalName: input.legalName ?? null,
      taxNumber: input.taxNumber ?? null,
      phone: input.phone ?? null,
      email: input.email ?? null,
      address: input.address ?? null,
      currencyCode: input.currencyCode ?? "IQD",
      settingsJson: JSON.stringify({ negative_stock: false, credit_guard: "BLOCK" }),
      createdBy: input.createdBy,
    },
  });

  // 2) Home branch + MAIN warehouse ------------------------------------------------
  const branch = await db.branch.create({
    data: {
      companyId: company.id,
      code: "MAIN",
      name: "الفرع الرئيسي",
      phone: input.phone ?? null,
      address: input.address ?? null,
      createdBy: input.createdBy,
    },
  });
  const warehouse = await db.warehouse.create({
    data: {
      companyId: company.id,
      branchId: branch.id,
      code: "WH-MAIN",
      name: "المستودع الرئيسي",
      type: "MAIN",
      createdBy: input.createdBy,
    },
  });

  // 3) System roles + grants --------------------------------------------------------
  let rolesCreated = 0;
  for (const def of SYSTEM_ROLES) {
    const role = await db.role.create({
      data: {
        companyId: company.id,
        code: def.code,
        name: def.name,
        description: def.description,
        isSystem: true,
        createdBy: input.createdBy,
      },
    });
    const codes = rolePermissionCodes(def.code);
    const perms = await db.permission.findMany({ where: { code: { in: codes } }, select: { id: true } });
    if (perms.length) {
      await db.rolePermission.createMany({
        data: perms.map((p) => ({ companyId: company.id, roleId: role.id, permissionId: p.id })),
      });
    }
    rolesCreated++;
  }

  // 4) Document sequences (current year) -------------------------------------------
  const year = new Date().getFullYear();
  const seq = [
    ["INVOICE", "INV"], ["ORDER", "ORD"], ["PAYMENT", "PAY"], ["TRANSFER", "TRF"], ["PO", "PO"],
  ] as const;
  for (const [docType, prefix] of seq) {
    await db.documentSequence.create({
      data: { companyId: company.id, docType, prefix, year },
    });
  }

  // 5) Baseline settings -------------------------------------------------------------
  const settings: [string, unknown, string, string][] = [
    ["invoice.numbering.format", "{PREFIX}-{YEAR}-{SEQ:6}", "numbering", "صيغة ترقيم الفواتير"],
    ["finance.currency", input.currencyCode ?? "IQD", "general", "عملة النظام الأساسية"],
    ["invoice.footer_text", "البضاعة المباعة لا تستبدل إلا حسب سياسة الشركة.\nشكراً لتعاملكم معنا.", "invoice", "نص تذييل الفاتورة (قابل للتعديل)"],
    ["invoice.show_mini_statement", true, "invoice", "إظهار كشف الحساب المختصر داخل الفاتورة"],
    ["customers.labels", { REGISTERED: "عميل مسجل", WALK_IN: "زبون نقدي / متردد", CASH_CUSTOMER: "زبون كاشي", GUEST: "زبون غير معروف" }, "customers", "مسميات أنواع العملاء القابلة للتعديل (§19)"],
    ["walkin.strategy", "SHARED", "customers", "استراتيجية الزبون المتردد: سجل افتراضي مشترك واحد (§52)"],
  ];
  for (const [key, value, group, description] of settings) {
    await db.setting.create({
      data: { companyId: company.id, key, value: JSON.stringify(value), groupName: group, description },
    });
  }

  // 6) Shared walk-in customer (زبون نقدي / متردد) -----------------------------------
  await ensureWalkInCustomer(company.id);

  // 7) Grant the creator company access → appears in their company switcher ---------
  const existingAccess = await db.userCompanyAccess.findFirst({
    where: { userId: input.createdBy, companyId: company.id },
  });
  if (!existingAccess) {
    await db.userCompanyAccess.create({
      data: { userId: input.createdBy, companyId: company.id, isPrimary: false },
    });
  }

  return {
    companyId: company.id,
    name: company.name,
    code: company.code ?? input.code,
    branchId: branch.id,
    warehouseId: warehouse.id,
    rolesCreated,
  };
}
