// =====================================================================
// argon2id password hashing (MASTER PROMPT §2 — Auth).
// hash-wasm implements argon2id in pure WASM: no native build needed,
// identical parameters in the Docker production image.
// =====================================================================

import { argon2id, argon2Verify } from "hash-wasm";

const ARGON2_PARAMS = {
  parallelism: 1,
  iterations: 3,
  memorySize: 19456, // 19 MiB — OWASP recommended minimum
  hashLength: 32,
  outputType: "encoded" as const,
};

function randomSalt(bytes = 16): Uint8Array {
  const s = new Uint8Array(bytes);
  crypto.getRandomValues(s);
  return s;
}

/** Hash a plaintext password with argon2id (encoded PHC string). */
export async function hashPassword(plain: string): Promise<string> {
  return argon2id({ password: plain, salt: randomSalt(), ...ARGON2_PARAMS });
}

/** Verify a plaintext password against an encoded argon2id hash. */
export async function verifyPassword(plain: string, encoded: string): Promise<boolean> {
  try {
    return await argon2Verify({ password: plain, hash: encoded });
  } catch {
    return false;
  }
}
