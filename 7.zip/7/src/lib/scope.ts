// =====================================================================
// Scope engine — Multi-Company / Multi-Branch access control
// (MASTER PROMPT Phases 1, 4-13 + Hierarchical Visibility 2026-09).
//
// scopeType → effective sets:
//   GLOBAL     companies = user_company_access (or [own] if none)
//              branches  = all branches of allowed companies
//              warehouses= all warehouses of allowed companies
//   COMPANY    companies = [own]
//              branches  = all branches of own company
//              warehouses= all warehouses of own company
//   BRANCH     companies = [own]
//              branches  = user_branch_access ∪ {user.branch_id}
//              warehouses= warehouses inside those branches
//   WAREHOUSE  companies = [own]
//              branches  = branches of granted warehouses
//              warehouses= user_warehouse_access
//   SALES_REP  like BRANCH (rep-level row filters stay in the routes)
//   SELF       like BRANCH structurally, but DATA rows narrow to OWN
//              records only (own sales, own customers, own visits) —
//              الموظف يشغّل النظام ولا يرى إلا بياناته (§6/§7 الوثيقة)
//
// Session context adds `activeBranchId` (JWT claim `brn`):
//   effectiveBranches = activeBranchId ? [activeBranchId] : branchIds
// Writes MUST target the effective set; reads return only the effective set.
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";

export type ScopeType = "GLOBAL" | "COMPANY" | "BRANCH" | "WAREHOUSE" | "SALES_REP" | "SELF";

/**
 * المستويات الإدارية (وثيقة Hierarchical Visibility §2):
 *   PLATFORM_OWNER  = مالك المنصة (scope GLOBAL)
 *   COMPANY_MANAGER = مدير شركة (scope COMPANY)
 *   BRANCH_MANAGER  = مدير فرع (scope BRANCH)
 *   EMPLOYEE        = موظف تشغيلي (WAREHOUSE / SALES_REP / SELF)
 * الصلاحية تحدد "ماذا أفعل" والمستوى/النطاق يحدد "ماذا أرى وعلى أي بيانات".
 */
export type AdminLevel = "PLATFORM_OWNER" | "COMPANY_MANAGER" | "BRANCH_MANAGER" | "EMPLOYEE";

export const ADMIN_LEVEL_LABELS: Record<AdminLevel, string> = {
  PLATFORM_OWNER: "مالك المنصة",
  COMPANY_MANAGER: "مدير شركة",
  BRANCH_MANAGER: "مدير فرع",
  EMPLOYEE: "موظف",
};

/** المستوى الإداري المشتق من نوع النطاق. */
export function adminLevelOf(scopeType: string): AdminLevel {
  switch (normalizeScopeType(scopeType)) {
    case "GLOBAL": return "PLATFORM_OWNER";
    case "COMPANY": return "COMPANY_MANAGER";
    case "BRANCH": return "BRANCH_MANAGER";
    default: return "EMPLOYEE";
  }
}

/**
 * رتبة النطاق (التسلسل الهرمي الصارم §9/§17):
 * الرؤية والسلطة تنزل للأسفل فقط — لمنح نطاقًا يجب أن تكون رتبة المانح
 * أعلى من رتبة النطاق الممنوح (Authority does not flow upward).
 */
export const SCOPE_RANK: Record<ScopeType, number> = {
  GLOBAL: 40,
  COMPANY: 30,
  BRANCH: 20,
  WAREHOUSE: 10,
  SALES_REP: 8,
  SELF: 5,
};

export function scopeRank(scopeType: string): number {
  return SCOPE_RANK[normalizeScopeType(scopeType)];
}

export interface ResolvedScope {
  scopeType: ScopeType;
  companyId: number; // home company (current active after company switch)
  companyIds: number[]; // companies the user may switch to
  branchIds: number[];
  warehouseIds: number[];
}

export function normalizeScopeType(raw: string | null | undefined): ScopeType {
  const v = (raw ?? "").toUpperCase();
  if (v === "GLOBAL" || v === "COMPANY" || v === "WAREHOUSE" || v === "SALES_REP" || v === "SELF") return v;
  return "BRANCH";
}

/** Resolve the user's scope sets from the access tables (Phase 1/8/9 rules). */
export async function resolveScope(user: {
  id: number;
  companyId: number;
  branchId: number | null;
  scopeType: string;
}): Promise<ResolvedScope> {
  const scopeType = normalizeScopeType(user.scopeType);

  // ---- companies --------------------------------------------------------
  let companyIds: number[] = [];
  if (scopeType === "GLOBAL") {
    // الشركات المحذوفة (soft delete) لا يدخلها النطاق إطلاقًا — تختفي من
    // المبدّل وشاشة اختيار الشركة فور حذفها.
    const granted = await db.userCompanyAccess.findMany({
      where: { userId: user.id, company: { deletedAt: null } },
    });
    companyIds = granted.length ? granted.map((g) => g.companyId) : [user.companyId];
  } else {
    companyIds = [user.companyId];
  }

  // ---- branches ---------------------------------------------------------
  let branchIds: number[] = [];
  if (scopeType === "GLOBAL" || scopeType === "COMPANY") {
    const rows = await db.branch.findMany({
      where: { companyId: { in: companyIds }, isActive: true, deletedAt: null },
      select: { id: true },
    });
    branchIds = rows.map((r) => r.id);
  } else if (scopeType === "WAREHOUSE") {
    const whs = await db.userWarehouseAccess.findMany({ where: { userId: user.id } });
    const whRows = await db.warehouse.findMany({
      where: { id: { in: whs.map((w) => w.warehouseId) }, deletedAt: null },
      select: { branchId: true },
    });
    branchIds = [...new Set(whRows.map((w) => w.branchId))];
  } else {
    // BRANCH / SALES_REP / SELF — الهيكل التشغيلي واحد: فرعه (ومستودعاته)
    // كي يستطيع الموظف العمل (بيع/جرد) داخل سياقه، بينما رؤية البيانات
    // (الصفوف) تُضيّق في النقاط نفسها حسب SELF (§7: Scope يحدد ماذا أرى).
    const granted = await db.userBranchAccess.findMany({ where: { userId: user.id } });
    branchIds = [...new Set([...granted.map((g) => g.branchId), ...(user.branchId ? [user.branchId] : [])])];
  }

  // ---- warehouses -------------------------------------------------------
  let warehouseIds: number[] = [];
  if (scopeType === "GLOBAL" || scopeType === "COMPANY") {
    const rows = await db.warehouse.findMany({
      where: { companyId: { in: companyIds }, isActive: true, deletedAt: null },
      select: { id: true },
    });
    warehouseIds = rows.map((r) => r.id);
  } else if (scopeType === "WAREHOUSE") {
    const rows = await db.userWarehouseAccess.findMany({ where: { userId: user.id } });
    warehouseIds = rows.map((r) => r.warehouseId);
  } else {
    const rows = await db.warehouse.findMany({
      where: { branchId: { in: branchIds }, isActive: true, deletedAt: null },
      select: { id: true },
    });
    warehouseIds = rows.map((r) => r.id);
  }

  return { scopeType, companyId: user.companyId, companyIds, branchIds, warehouseIds };
}

// ---------------------------------------------------------------------
// Session-side helpers (work off the resolved Session — no DB hits)
// ---------------------------------------------------------------------
export interface ScopeSessionLike {
  scopeType: ScopeType;
  companyIds: number[];
  branchIds: number[];
  warehouseIds: number[];
  activeBranchId: number | null;
}

/** The branch set the session is currently operating on. */
export function effectiveBranchIds(session: ScopeSessionLike): number[] {
  return session.activeBranchId ? [session.activeBranchId] : session.branchIds;
}

/** Prisma where fragment limiting a branchId column to the effective set. */
export function branchWhere(session: ScopeSessionLike): Record<string, unknown> {
  const ids = effectiveBranchIds(session);
  if (ids.length === 1) return { branchId: ids[0] };
  return { branchId: { in: ids } };
}

/** Prisma where fragment limiting a warehouseId column to the effective set. */
export function warehouseWhere(session: ScopeSessionLike): Record<string, unknown> {
  return { warehouseId: { in: session.warehouseIds } };
}

/**
 * Cashbox visibility where fragment — Phase 3 / 38 / 57 security rule.
 * Combines:
 *   · companyId isolation (Multi-Tenant, §38 chain)
 *   · branch scope (branchWhere) — same branch set as everything else
 *   · ownerUserId restriction when session is SALES_REP or SELF:
 *     a REP/CUSTOM cashbox is private to its owner; MAIN and BRANCH
 *     cashboxes remain visible (they're shared branch resources).
 *
 * Usage: prisma.cashbox.findMany({ where: { deletedAt: null, ...cashboxWhere(session) } })
 */
export function cashboxWhere(session: ScopeSessionLike & { userId?: number; scopeType: string }): Record<string, unknown> {
  const ids = effectiveBranchIds(session);
  const branchFilter = ids.length === 1 ? { branchId: ids[0] } : { branchId: { in: ids } };

  // SALES_REP / SELF: hide other employees' private cashboxes (REP/CUSTOM)
  // but keep shared MAIN/BRANCH/BANK visible for branch operations.
  // Phase 3 rule: «الصندوق/الصناديق المخصصة له فقط»
  if (session.scopeType === "SALES_REP" || session.scopeType === "SELF") {
    return {
      ...branchFilter,
      OR: [
        { type: { in: ["MAIN", "BRANCH", "BANK"] } },
        { ownerUserId: session.userId ?? -1 },
      ],
    };
  }

  return branchFilter;
}

/**
 * Write-gate: the target branch must be inside the CURRENT context
 * (active branch if selected, else the whole granted set). Throws
 * SCOPE_003 (403) — the explicit "Branch Scope Violation" denial.
 */
export function assertBranchInScope(session: ScopeSessionLike, branchId: number): void {
  const allowed = effectiveBranchIds(session);
  if (!allowed.includes(branchId)) {
    throw new ApiError("SCOPE_003");
  }
}

/** Warehouse write-gate: warehouse granted AND inside the branch context. */
export function assertWarehouseInScope(
  session: ScopeSessionLike,
  warehouseId: number,
  warehouseBranchId: number | null | undefined
): void {
  if (!session.warehouseIds.includes(warehouseId)) throw new ApiError("SCOPE_002");
  if (warehouseBranchId != null) assertBranchInScope(session, warehouseBranchId);
}

/** Which branch a new branch-scoped record belongs to (create flows). */
export function resolveCreateBranch(session: ScopeSessionLike, requested?: number | null): number {
  const eff = effectiveBranchIds(session);
  if (requested != null) {
    if (!eff.includes(requested)) throw new ApiError("SCOPE_003");
    return requested;
  }
  if (eff.length === 1) return eff[0];
  if (session.activeBranchId) return session.activeBranchId;
  // multi-branch user with no explicit selection: default to home branch
  return session.branchIds[0];
}

// ---------------------------------------------------------------------
// Cross-company reference detection (MASTER PROMPT §48/§71).
// Distinguishes "does not exist" (keep 404 — no existence leak, §25)
// from "exists in ANOTHER company" (explicit SCOPE_006 rejection).
// ---------------------------------------------------------------------
export type CrossCompanyModel = "customer" | "warehouse" | "user" | "product" | "supplier";

export async function entityExistsOutsideCompany(
  model: CrossCompanyModel,
  id: number
): Promise<boolean> {
  const where = { id, deletedAt: null };
  switch (model) {
    case "customer":  return !!(await db.customer.findFirst({ where, select: { id: true } }));
    case "warehouse": return !!(await db.warehouse.findFirst({ where, select: { id: true } }));
    case "user":      return !!(await db.user.findFirst({ where, select: { id: true } }));
    case "product":   return !!(await db.product.findFirst({ where, select: { id: true } }));
    case "supplier":  return !!(await db.supplier.findFirst({ where, select: { id: true } }));
  }
}
