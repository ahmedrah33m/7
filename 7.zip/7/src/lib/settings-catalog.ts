// =====================================================================
// Settings catalog (§62) — مخزن الإعدادات المعرفي بمفاتيح قسيمة
// 14 منطقة إعداد قابلة للإدارة؛ قيمة JSON سكالار لكل مفتاح.
// المسار: GET /api/v1/settings (system.settings.view)
//         PUT /api/v1/settings (system.settings.edit)
// =====================================================================

export interface SettingGroup {
  key: string; // بادئة المفاتيح، مثل "sales."
  nameAr: string;
  keys: { key: string; value: unknown; descAr: string }[];
}

export const SETTING_GROUPS: SettingGroup[] = [
  {
    key: "company.",
    nameAr: "معلومات الشركة",
    keys: [
      { key: "company.name", value: "شركة المبيعات والتوزيع", descAr: "الاسم التجاري الظاهر في الطباعة" },
      { key: "company.phone", value: "", descAr: "هاتف الشركة" },
      { key: "company.address", value: "", descAr: "عنوان الشركة" },
    ],
  },
  {
    key: "numbering.",
    nameAr: "الترقيم المستندي",
    keys: [
      { key: "numbering.reset_policy", value: "NEVER", descAr: "إعادة ضبط التسلسل: NEVER | YEARLY | MONTHLY" },
    ],
  },
  {
    key: "tax.",
    nameAr: "الضرائب",
    keys: [
      { key: "tax.default_rate", value: 0, descAr: "نسبة الضريبة الافتراضية للمنتجات الجديدة %" },
    ],
  },
  {
    key: "credit.",
    nameAr: "قواعد الائتمان",
    keys: [
      { key: "credit.block_over_limit", value: true, descAr: "حجب البيع الآجل عند تجاوز سقف الائتمان (بدون قاعدة موافقة)" },
    ],
  },
  {
    key: "commissions.",
    nameAr: "العمولات",
    keys: [
      { key: "commissions.auto_approve_pct", value: 0, descAr: "اعتماد آلي للعمولات تحت نسبة %" },
    ],
  },
  {
    key: "printing.",
    nameAr: "الطباعة",
    keys: [
      { key: "printing.thermal_width", value: 80, descAr: "عرض الطباعة الحرارية mm: 80 | 58" },
      { key: "printing.show_logo", value: true, descAr: "إظهار شعار الشركة في المطبوعات" },
    ],
  },
  {
    key: "security.",
    nameAr: "الأمان",
    keys: [
      { key: "security.password_min_length", value: 8, descAr: "الحد الأدنى لطول كلمة المرور" },
    ],
  },
  {
    key: "sales.",
    nameAr: "المبيعات",
    keys: [
      { key: "sales.tax_mode", value: "EXCLUSIVE", descAr: "وضع الضريبة: EXCLUSIVE تُضاف فوق السعر | INCLUSIVE داخل السعر" },
      { key: "sales.enforce_min_price", value: false, descAr: "حجب البيع تحت سعر المنتج الأدنى (min_sale_price)" },
    ],
  },
  {
    key: "inventory.",
    nameAr: "المخازن",
    keys: [
      { key: "inventory.allow_negative", value: false, descAr: "السماح برصيد سالب (معطّل افتراضيًا — سياسة الحظر الصارم)" },
      { key: "inventory.cost_method", value: "WEIGHTED_AVERAGE", descAr: "طريقة احتساب التكلفة (§66.7): WEIGHTED_AVERAGE | FIFO | STANDARD — لا يُخلط بين الطرق" },
      { key: "inventory.dead_stock_days", value: 90, descAr: "تعريف المخزون الراكد (§66.23): لا حركة خارجة خلال هذا العدد من الأيام (30/60/90/180)" },
    ],
  },
  // v14 — أُزيلت مجموعة «الولاء» من الإعدادات: نظام نقاط الولاء أُلغي بالكامل
  {
    key: "notifications.",
    nameAr: "الإشعارات والتنبيهات",
    keys: [
      { key: "notifications.low_stock_enabled", value: true, descAr: "تنبيه انخفاض المخزون تحت الحد الأدنى" },
      { key: "notifications.overdue_enabled", value: true, descAr: "تنبيه الفواتير المتأخرة عن الاستحقاق" },
    ],
  },
  {
    key: "approvals.",
    nameAr: "الموافقات",
    keys: [
      { key: "approvals.enabled", value: true, descAr: "تفعيل محرك الموافقات (§41) — القواعد الرقمية في جدولها" },
    ],
  },
  {
    key: "branches.",
    nameAr: "الفروع",
    keys: [
      { key: "branches.transfers_require_approval", value: false, descAr: "إلزام مسار طلب→اعتماد للتحويلات بين المستودعات" },
    ],
  },
  {
    key: "system.",
    nameAr: "النظام",
    keys: [
      { key: "system.maintenance_note", value: "", descAr: "ملاحظة تُعرض أعلى اللوحة عند ضبطها" },
    ],
  },
];

export const SETTING_KEY_INDEX: Map<string, { group: SettingGroup; def: SettingGroup["keys"][number] }> =
  new Map(
    SETTING_GROUPS.flatMap((g) => g.keys.map((k) => [k.key, { group: g, def: k }] as const))
  );
