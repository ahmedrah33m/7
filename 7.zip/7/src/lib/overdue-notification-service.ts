// =====================================================================
// OverdueNotification service — Phase 8-11 (المرحلة 19+41 من MASTER PROMPT)
//
// يحفّز إشعارات WhatsApp للعملاء عن الفواتير المتأخرة:
//   1. يجمع كل الفواتير المعلقة (status IN [UNPAID, PARTIALLY_PAID])
//   2. يحسب أعمار الديون (current/1-30/31-60/61-90/90+)
//   3. ينشئ سجل OverdueNotification مرة واحدة لكل (invoice, bucket)
//   4. يولّد WhatsApp URL (wa.me) جاهز للنقر أو الإرسال
//
// الإعداد: Setting.overdue_notify_buckets = "D1_30,D31_60,D61_90,D90_PLUS"
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { nextDocumentNumber } from "./document-number";
import { writeAudit, auditData } from "./audit";
import { Decimal, dec, moneyR, num, sumOf } from "./decimal";
import type { Prisma } from "@prisma/client";

export interface OverdueNotificationActor {
  userId: number;
  companyId: number;
  ip?: string;
  userAgent?: string;
}

interface InvoiceWithCustomer {
  id: number;
  number: string;
  customerId: number;
  invoiceDate: Date;
  grandTotal: Decimal;
  paidAmount: Decimal;
  customer: { id: number; name: string; whatsapp: string | null; phone: string | null };
}

/**
 * Compute age bucket for an invoice based on invoiceDate.
 * Returns: CURRENT | D1_30 | D31_60 | D61_90 | D90_PLUS
 */
export function computeBucket(invoiceDate: Date, now: Date = new Date()): string {
  const ageDays = Math.floor((now.getTime() - invoiceDate.getTime()) / (1000 * 60 * 60 * 24));
  if (ageDays <= 0) return "CURRENT";
  if (ageDays <= 30) return "D1_30";
  if (ageDays <= 60) return "D31_60";
  if (ageDays <= 90) return "D61_90";
  return "D90_PLUS";
}

/**
 * Build the WhatsApp message URL for an overdue invoice.
 * Uses wa.me/?text= format with full Arabic message body.
 */
export function buildOverdueWhatsAppUrl(
  invoice: { number: string; customerName: string; ageDays: number; dueAmount: number; bucket: string; customerWhatsapp: string | null; customerPhone: string | null }
): { url: string; messageBody: string; phone: string | null } {
  const bucketAr: Record<string, string> = {
    CURRENT: "حالي",
    D1_30: "متأخر 1-30 يوم",
    D31_60: "متأخر 31-60 يوم",
    D61_90: "متأخر 61-90 يوم",
    D90_PLUS: "متأخر أكثر من 90 يوم",
  };

  const msg = [
    `مرحباً ${invoice.customerName}،`,
    ``,
    `نذكّركم بوجود فاتورة متأخرة السداد:`,
    `• رقم الفاتورة: ${invoice.number}`,
    `• المبلغ المتبقي: ${new Intl.NumberFormat("ar-IQ").format(invoice.dueAmount)} د.ع`,
    `• حالة التأخير: ${bucketAr[invoice.bucket] ?? invoice.bucket} (${invoice.ageDays} يوم)`,
    ``,
    `يرجى السداد في أقرب وقت لتجنب إيقف الخدمة.`,
    `للاستفسار: تواصل معنا`,
    ``,
    `— إشعار آلي من نظام كيان ERP`,
  ].join("\n");

  // Normalize phone to wa.me format (remove + and spaces)
  let phone = invoice.customerWhatsapp ?? invoice.customerPhone ?? null;
  if (phone) {
    phone = phone.replace(/[\s+\-()]/g, "");
    if (!phone.startsWith("964") && phone.startsWith("07")) {
      phone = "964" + phone.slice(1);
    }
  }

  const url = phone
    ? `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`
    : `https://wa.me/?text=${encodeURIComponent(msg)}`;

  return { url, messageBody: msg, phone };
}

/**
 * Scan all outstanding invoices and generate OverdueNotification records
 * for each (invoice, bucket) that hasn't been notified yet.
 *
 * Returns summary of created notifications.
 */
export async function scanAndGenerateOverdueNotifications(
  actor: OverdueNotificationActor,
  options: { buckets?: string[]; dryRun?: boolean } = {}
): Promise<{ scanned: number; created: number; skipped: number; byBucket: Record<string, number> }> {
  const companyId = actor.companyId;
  const buckets = options.buckets ?? ["D1_30", "D31_60", "D61_90", "D90_PLUS"];
  const dryRun = options.dryRun ?? false;

  // Get all outstanding (UNPAID or PARTIALLY_PAID) invoices for this company
  const invoices = await db.salesInvoice.findMany({
    where: {
      companyId,
      deletedAt: null,
      status: { in: ["UNPAID", "PARTIALLY_PAID"] },
    },
    include: {
      customer: { select: { id: true, name: true, whatsapp: true, phone: true } },
    },
  }) as unknown as InvoiceWithCustomer[];

  // Filter out invoices without a customer (defensive)
  const validInvoices = invoices.filter((inv) => inv.customer != null);

  let scanned = 0;
  let created = 0;
  let skipped = 0;
  const byBucket: Record<string, number> = { CURRENT: 0, D1_30: 0, D31_60: 0, D61_90: 0, D90_PLUS: 0 };

  if (dryRun) {
    for (const inv of validInvoices) {
      scanned++;
      const bucket = computeBucket(inv.invoiceDate);
      byBucket[bucket]++;
      if (!buckets.includes(bucket)) continue;
      const existing = await db.overdueNotification.findUnique({
        where: { salesInvoiceId_bucket: { salesInvoiceId: inv.id, bucket } },
      });
      if (existing) skipped++;
      else created++;
    }
    return { scanned, created, skipped, byBucket };
  }

  for (const inv of validInvoices) {
    scanned++;
    const bucket = computeBucket(inv.invoiceDate);
    byBucket[bucket]++;
    if (!buckets.includes(bucket)) continue;

    // Idempotent: skip if already notified for this (invoice, bucket)
    const existing = await db.overdueNotification.findUnique({
      where: { salesInvoiceId_bucket: { salesInvoiceId: inv.id, bucket } },
    });
    if (existing) {
      skipped++;
      continue;
    }

    const dueAmount = moneyR(dec(inv.grandTotal).minus(dec(inv.paidAmount)));
    const ageDays = Math.floor((Date.now() - inv.invoiceDate.getTime()) / (1000 * 60 * 60 * 24));

    const wa = buildOverdueWhatsAppUrl({
      number: inv.number,
      customerName: inv.customer.name,
      ageDays,
      dueAmount: num(dueAmount),
      bucket,
      customerWhatsapp: inv.customer.whatsapp,
      customerPhone: inv.customer.phone,
    });

    await db.overdueNotification.create({
      data: {
        companyId,
        customerId: inv.customerId,
        salesInvoiceId: inv.id,
        bucket,
        ageDays,
        amountDue: dueAmount,
        channel: "WHATSAPP",
        status: "PENDING",
        whatsappUrl: wa.url,
        messageBody: wa.messageBody,
        createdById: actor.userId,
      },
    });

    created++;
  }

  // Audit the scan run
  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CREATE",
      module: "finance",
      entityType: "overdue_notification_scan",
      entityId: 0,
      newValues: { scanned, created, skipped, byBucket, dryRun },
    }
  );

  return { scanned, created, skipped, byBucket };
}

/**
 * Mark a notification as SENT (after the user clicks send on WhatsApp).
 */
export async function markOverdueNotificationSent(
  actor: OverdueNotificationActor,
  notificationId: number
) {
  const companyId = actor.companyId;
  const n = await db.overdueNotification.findFirst({
    where: { id: notificationId, companyId },
  });
  if (!n) throw new ApiError("VAL_003", "الإشعار غير موجود");

  await db.overdueNotification.update({
    where: { id: n.id },
    data: { status: "SENT", sentAt: new Date() },
  });

  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "POST",
      module: "finance",
      entityType: "overdue_notification",
      entityId: n.id,
      newValues: { status: "SENT", invoiceId: n.salesInvoiceId, bucket: n.bucket },
    }
  );

  return { id: n.id, status: "SENT" };
}

/**
 * Get all pending notifications for display in the UI panel.
 */
export async function listPendingOverdueNotifications(
  companyId: number,
  options: { bucket?: string; customerId?: number; status?: string; limit?: number } = {}
) {
  const where: Prisma.OverdueNotificationWhereInput = {
    companyId,
    ...(options.bucket ? { bucket: options.bucket } : {}),
    ...(options.customerId ? { customerId: Number(options.customerId) } : {}),
    ...(options.status ? { status: options.status } : { status: "PENDING" }),
  };

  return db.overdueNotification.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: Math.min(options.limit ?? 100, 500),
    include: {
      customer: { select: { id: true, name: true, code: true, whatsapp: true, phone: true } },
      invoice: { select: { id: true, number: true, invoiceDate: true, grandTotal: true, paidAmount: true } },
    },
  });
}
