// =====================================================================
// Packaging engine — نظام العبوات والتعبئة الذكي (spec §7-§14, §29-§31)
//
// Golden rule (§45): NEVER show "9.25 Carton" to a user. The physical
// state lives in `packages` (sealed cartons + ONE open carton with its
// remaining pieces) and every issue/restock/open is journaled to the
// immutable `packaging_ledger` (§13) for audit (§44).
//
// Consumption policy (§12, company setting `credit_guard`-style JSON):
//   OPEN_FIRST (default) → drain open package(s) first, only then open
//   a sealed carton — and only as deep as needed.
//
// All functions MUST run inside the caller's transaction. Stock balance
// stays the master quantity projection; packages mirror its physical
// split for packaged products (sum(remaining) == stock_balance.qty).
// =====================================================================

import { ApiError } from "./api";
import { Decimal, dec, qtyR, sumOf, num } from "./decimal";

export const PACKAGE_TYPE_LABEL: Record<string, string> = {
  CARTON: "كرتونة",
  BOX: "صندوق",
  PACK: "باكيت",
};

export const PACKAGE_TYPE_PREFIX: Record<string, string> = {
  CARTON: "CARTON",
  BOX: "BOX",
  PACK: "PACK",
};

export type PackagePolicy = "OPEN_FIRST" | "SEALED_FIRST";

export interface PackInfo {
  hasPack: boolean;
  packQty: number; // pieces per package (1 = no packaging) — عدّاد تكويني (عدد صحيح/6dp، نقل دقيق)
  packUnit: string; // كرتونة
  packageType: string; // CARTON
}

/** Read packaging config off a product row (spec §7). */
export function packInfoOf(p: {
  packUnit?: string | null;
  packQty?: Decimal | number | null;
  unit?: string;
}): PackInfo {
  const q = dec(p.packQty);
  const has = !!p.packUnit && q.isPositive() && !q.equals(1);
  return {
    hasPack: has,
    packQty: has ? q.toNumber() : 1,
    packUnit: has ? String(p.packUnit) : p.unit ?? "قطعة",
    packageType: has ? typeOfUnitLabel(String(p.packUnit)) : "CARTON",
  };
}

/** كرتونة → CARTON · صندوق → BOX · باكيت/باقة → PACK · else CARTON */
export function typeOfUnitLabel(label: string): string {
  const s = label.trim();
  if (s === "صندوق" || s.toLowerCase() === "box") return "BOX";
  if (s === "باكيت" || s === "باقة" || s.toLowerCase() === "pack") return "PACK";
  return "CARTON";
}

/** Split base pieces → { packages, loose } (§16: 29 → 2+5) — حساب كمية Decimal. */
export function packSplit(totalPieces: Decimal | number, packQty: number): { packages: number; loose: number } {
  const total = dec(totalPieces);
  if (packQty <= 1) return { packages: 0, loose: num(qtyR(total)) };
  const packages = total.div(packQty).floor().toNumber(); // عدد عبوات صحيح
  const loose = qtyR(total.minus(packages * packQty));
  return { packages, loose: num(loose) };
}

/**
 * Human text for a piece count (§45): "9 كراتين كاملة + 3 حبات".
 * With pack state available, prefer describePackageState().
 */
export function fmtPackText(totalPieces: number, info: PackInfo): string {
  if (!info.hasPack) return `${trimNum(totalPieces)} ${info.packUnit === "قطعة" ? "حبة" : info.packUnit}`;
  const { packages, loose } = packSplit(totalPieces, info.packQty);
  const plural = pluralOf(info.packUnit);
  const parts: string[] = [];
  if (packages > 0) parts.push(`${trimNum(packages)} ${packages === 1 ? info.packUnit : plural} ${packages === 1 ? "كاملة" : "كاملة"}`);
  if (loose > 0 || packages === 0) parts.push(`${trimNum(loose)} حبة`);
  return parts.join(" + ");
}

export function pluralOf(unit: string): string {
  if (unit === "كرتونة" || unit === "كارتون") return "كراتين";
  if (unit === "صندوق") return "صناديق";
  if (unit === "باكيت") return "باكيتات";
  if (unit === "علبة") return "علب";
  if (unit === "حبة") return "حبات";
  return unit + "ات";
}

function trimNum(n: number): string {
  return Number.isInteger(n) ? String(n) : String(Math.round(n * 1000) / 1000);
}

// ---------------------------------------------------------------------
// Tx client structural type (works with any prisma transaction)
// ---------------------------------------------------------------------
/* eslint-disable @typescript-eslint/no-explicit-any */
interface TxLike {
  package: {
    findMany(args?: any): Promise<PackageRow[]>;
    findFirst(args?: any): Promise<PackageRow | null>;
    create(args: any): Promise<PackageRow>;
    update(args: any): Promise<PackageRow>;
    aggregate(args?: any): Promise<{ _max: { id: number | null } }>;
  };
  packagingLedger: { create(args: any): Promise<unknown> };
  stockBalance: {
    findUnique(args: any): Promise<{ qty: Decimal } | null>;
  };
}

/** Adapt a real Prisma transaction client to the structural TxLike. */
export function txOf(tx: unknown): TxLike {
  return tx as TxLike;
}

export interface PackageRow {
  id: number;
  code: string;
  packageType: string;
  originalQty: Decimal;
  remainingQty: Decimal;
  status: string;
  openedAt: Date | null;
}

/** Next human package code (§14): CARTON-000458 — unique per company. */
export async function nextPackageCode(tx: TxLike, companyId: number, packageType: string): Promise<string> {
  const prefix = PACKAGE_TYPE_PREFIX[packageType] ?? "CARTON";
  const agg = await tx.package.aggregate({ where: { companyId }, _max: { id: true } });
  let n = (agg._max.id ?? 0) + 1;
  // Collision-safe loop (unique companyId+code)
  for (;;) {
    const code = `${prefix}-${String(n).padStart(6, "0")}`;
    const exists = await tx.package.findFirst({ where: { companyId, code }, select: { id: true } });
    if (!exists) return code;
    n += 1;
  }
}

async function ledger(tx: TxLike, data: Record<string, unknown>) {
  await tx.packagingLedger.create({ data });
}

/**
 * Lazily sync package rows to the stock balance for a packaged product
 * (legacy stock that predates package tracking buys §31 parity):
 * stock 120 @ 12 → 10 sealed · stock 117 → 9 sealed + 1 open(9).
 * After this runs: sum(package.remaining) == stock_balance.qty.
 */
export async function ensurePackageCoverage(
  tx: TxLike,
  args: { companyId: number; warehouseId: number; productId: number; info: PackInfo; userId?: number | null }
): Promise<void> {
  const { companyId, warehouseId, productId, info } = args;
  if (!info.hasPack) return;

  const balance = await tx.stockBalance.findUnique({
    where: { warehouseId_productId: { warehouseId, productId } },
  });
  const total = dec(balance?.qty);
  if (!total.isPositive()) return;

  const rows = await tx.package.findMany({
    where: { companyId, warehouseId, productId, status: { not: "EMPTY" } },
    select: { remainingQty: true },
  });
  const covered = sumOf(rows, (r) => r.remainingQty);
  const missing = qtyR(total.minus(covered));
  if (!missing.isPositive()) return;

  const { packages, loose } = packSplit(missing, info.packQty);
  for (let i = 0; i < packages; i++) {
    const code = await nextPackageCode(tx, companyId, info.packageType);
    const pkg = await tx.package.create({
      data: {
        companyId, warehouseId, productId,
        packageType: info.packageType, code,
        originalQty: dec(info.packQty), remainingQty: dec(info.packQty),
        status: "SEALED", sourceRefType: "AUTO",
      },
    });
    await ledger(tx, {
      companyId, warehouseId, productId, packageId: pkg.id,
      packageCode: pkg.code, packageType: pkg.packageType,
      direction: "RESTOCK", openingQty: 0, issuedQty: dec(info.packQty), remainingQty: dec(info.packQty),
      refType: "ADJUSTMENT", note: "تغطية تلقائية للمخزون السابق بالعبوات",
      createdBy: args.userId ?? null,
    });
  }
  if (loose > 0) {
    const code = await nextPackageCode(tx, companyId, info.packageType);
    const pkg = await tx.package.create({
      data: {
        companyId, warehouseId, productId,
        packageType: info.packageType, code,
        originalQty: dec(info.packQty), remainingQty: dec(loose),
        status: "OPEN", openedAt: new Date(), openedBy: args.userId ?? null,
        openedReason: "تغطية تلقائية — كمية غير مكتملة بالمخزون",
        sourceRefType: "AUTO",
      },
    });
    await ledger(tx, {
      companyId, warehouseId, productId, packageId: pkg.id,
      packageCode: pkg.code, packageType: pkg.packageType,
      direction: "RESTOCK", openingQty: 0, issuedQty: dec(loose), remainingQty: dec(loose),
      refType: "ADJUSTMENT", note: "تغطية تلقائية للمخزون السابق (عبوة مفتوحة)",
      createdBy: args.userId ?? null,
    });
  }
}

export interface PackageEvent {
  packageId: number;
  code: string;
  packageType: string;
  openingQty: Decimal;
  issuedQty: Decimal;
  remainingQty: Decimal;
  action: "FROM_OPEN" | "OPENED_NEW" | "FROM_SEALED";
}

export interface ConsumeResult {
  events: PackageEvent[];
  openedCount: number; // كم عبوة مغلقة فُتحت
  fromOpenQty: Decimal;
  note: string | null; // package_note for the invoice line (§11)
}

/**
 * Consume `pieces` from physical packages (§12): policy drains open
 * package(s) first, then opens sealed ones only as needed. Writes an
 * ISSUE ledger row per package touched + an OPEN row per newly opened.
 * Assumes ensurePackageCoverage already ran in the same tx.
 */
export async function consumeFromPackages(
  tx: TxLike,
  args: {
    companyId: number;
    warehouseId: number;
    productId: number;
    pieces: Decimal | number;
    info: PackInfo;
    policy?: PackagePolicy;
    userId?: number | null;
    refType: string; // SALES_INVOICE | ADJUSTMENT | TRANSFER_OUT
    refId?: number | null;
    refNumber?: string | null;
    /** Phase 2 §10 — عدد الكراتين الكاملة المباعة (سُحبت من المغلقات كوحدات) */
    fullPackages?: number;
    /** الحبات المفردة حين يُمرَّر fullPackages (افتراضي: pieces نفسه) */
    loosePieces?: Decimal | number;
  }
): Promise<ConsumeResult> {
  const { companyId, warehouseId, productId, info } = args;
  const policy: PackagePolicy = args.policy ?? "OPEN_FIRST";
  const fulls = Math.max(0, Math.floor(args.fullPackages ?? 0));
  if (!info.hasPack || (dec(args.pieces).lte(0) && fulls <= 0)) {
    return { events: [], openedCount: 0, fromOpenQty: new Decimal(0), note: null };
  }

  let need = qtyR(dec(args.loosePieces ?? args.pieces));
  const events: PackageEvent[] = [];
  let openedCount = 0;
  let fromOpenQty = new Decimal(0);
  let wholeConsumed = 0;

  const grab = async (pkg: PackageRow, action: PackageEvent["action"]) => {
    const take = Decimal.min(dec(pkg.remainingQty), need);
    if (!take.isPositive()) return;
    const remaining = qtyR(dec(pkg.remainingQty).minus(take));
    await tx.package.update({
      where: { id: pkg.id },
      data: { remainingQty: remaining, status: remaining.lte(0) ? "EMPTY" : "OPEN" },
    });
    await ledger(tx, {
      companyId, warehouseId, productId, packageId: pkg.id,
      packageCode: pkg.code, packageType: pkg.packageType,
      direction: "ISSUE", openingQty: dec(pkg.remainingQty), issuedQty: take, remainingQty: remaining,
      refType: args.refType, refId: args.refId ?? null, refNumber: args.refNumber ?? null,
      note: action === "OPENED_NEW" ? "سحب من كرتونة فُتحت حديثًا" : action === "FROM_OPEN" ? "سحب من كرتونة مفتوحة" : "سحب من كرتونة مغلقة",
      createdBy: args.userId ?? null,
    });
    events.push({
      packageId: pkg.id, code: pkg.code, packageType: pkg.packageType,
      openingQty: dec(pkg.remainingQty), issuedQty: take, remainingQty: remaining, action,
    });
    need = qtyR(need.minus(take));
    if (action === "FROM_OPEN") fromOpenQty = fromOpenQty.plus(take);
  };

  // ---- §10: الكراتين الكاملة تُسحب من المغلقات كوحدات صحيحة (بلا فتح) ----
  // «1 كرتون + 3 حبات» → كرتونة مغلقة سُحبت كاملة + كرتونة فُتحت وبقيت 8.
  // ⚠️ يجب أن يسبق استعلامي openFirst/sealed — وإلا تُستخدم لقطة قديمة
  // فتُعاد الكرتونة المستهلكة إلى الحياة من السجل القديم (خلق 9 حبات وهمية).
  if (fulls > 0) {
    let left = fulls;
    const sealedWhole = await tx.package.findMany({
      where: { companyId, warehouseId, productId, status: "SEALED", remainingQty: { gt: 0 } },
      orderBy: { id: "asc" },
    });
    for (const pkg of sealedWhole) {
      if (left <= 0) break;
      if (!dec(pkg.remainingQty).equals(info.packQty)) continue; // ليست كاملة
      await tx.package.update({
        where: { id: pkg.id },
        data: { remainingQty: 0, status: "EMPTY" },
      });
      await ledger(tx, {
        companyId, warehouseId, productId, packageId: pkg.id,
        packageCode: pkg.code, packageType: pkg.packageType,
        direction: "ISSUE", openingQty: dec(pkg.remainingQty), issuedQty: dec(pkg.remainingQty), remainingQty: new Decimal(0),
        refType: args.refType, refId: args.refId ?? null, refNumber: args.refNumber ?? null,
        note: "سحب كرتونة مغلقة كاملة (كرتون مشطور — §10)",
        createdBy: args.userId ?? null,
      });
      events.push({
        packageId: pkg.id, code: pkg.code, packageType: pkg.packageType,
        openingQty: dec(pkg.remainingQty), issuedQty: dec(pkg.remainingQty), remainingQty: new Decimal(0), action: "FROM_SEALED",
      });
      wholeConsumed += 1;
      left -= 1;
    }
    // نقص مغلقات كاملة → الحبات الناقصة تُسحب حبة-حبة من الفتح أدناه
    need = qtyR(need.plus(left * info.packQty));
  }

  // اللقطات بعد السحب الكامل — تعكس الحالة الفعلية للعبوات
  const openFirst = await tx.package.findMany({
    where: { companyId, warehouseId, productId, status: "OPEN", remainingQty: { gt: 0 } },
    orderBy: [{ openedAt: "asc" }, { id: "asc" }],
  });
  const sealed = await tx.package.findMany({
    where: { companyId, warehouseId, productId, status: "SEALED", remainingQty: { gt: 0 } },
    orderBy: { id: "asc" },
  });

  if (policy === "OPEN_FIRST") {
    for (const pkg of openFirst) {
      if (!need.isPositive()) break;
      await grab(pkg, "FROM_OPEN");
    }
    for (const pkg of sealed) {
      if (!need.isPositive()) break;
      await tx.package.update({
        where: { id: pkg.id },
        data: {
          status: "OPEN", openedAt: new Date(), openedBy: args.userId ?? null,
          openedReason: args.refNumber ? `فتح تلقائي للبيع — ${args.refNumber}` : "فتح تلقائي للبيع",
        },
      });
      await ledger(tx, {
        companyId, warehouseId, productId, packageId: pkg.id,
        packageCode: pkg.code, packageType: pkg.packageType,
        direction: "OPEN", openingQty: dec(pkg.remainingQty), issuedQty: 0, remainingQty: dec(pkg.remainingQty),
        refType: args.refType, refId: args.refId ?? null, refNumber: args.refNumber ?? null,
        note: "فتح عبوة مغلقة للبيع",
        createdBy: args.userId ?? null,
      });
      openedCount += 1;
      await grab(pkg, "OPENED_NEW");
    }
  } else {
    for (const pkg of sealed) {
      if (!need.isPositive()) break;
      await tx.package.update({
        where: { id: pkg.id },
        data: { status: "OPEN", openedAt: new Date(), openedBy: args.userId ?? null, openedReason: "فتح للبيع (سياسة المغلق أولاً)" },
      });
      await ledger(tx, {
        companyId, warehouseId, productId, packageId: pkg.id,
        packageCode: pkg.code, packageType: pkg.packageType,
        direction: "OPEN", openingQty: dec(pkg.remainingQty), issuedQty: 0, remainingQty: dec(pkg.remainingQty),
        refType: args.refType, refId: args.refId ?? null, refNumber: args.refNumber ?? null,
        note: "فتح عبوة مغلقة للبيع", createdBy: args.userId ?? null,
      });
      openedCount += 1;
      await grab(pkg, "OPENED_NEW");
    }
    for (const pkg of openFirst) {
      if (!need.isPositive()) break;
      await grab(pkg, "FROM_OPEN");
    }
  }

  if (need.gt("1e-9")) {
    // Should not happen after ensurePackageCoverage — keep a hard guard.
    throw new ApiError("STOCK_001", `تعذر تلبية الكمية من العبوات — الناقص ${trimNum(num(need))} حبة`);
  }

  const wholeTxt = wholeConsumed > 0 ? (wholeConsumed === 1 ? "سُحبت كرتونة مغلقة كاملة" : `سُحبت ${wholeConsumed} كراتين مغلقة كاملة`) : "";
  const openedTxt = openedCount > 0 ? (openedCount === 1 ? "تم فتح كرتونة" : `تم فتح ${openedCount} كراتين`) : "";
  const fromOpen = fromOpenQty.isPositive() ? `سحب ${trimNum(num(fromOpenQty))} حبة من كرتونة مفتوحة` : "";
  const note = [wholeTxt, fromOpen, openedTxt].filter(Boolean).join(" + ") || "سحب من كرتونة مفتوحة";
  return { events, openedCount, fromOpenQty, note };
}

/**
 * Restock returned goods into packages (§29-§30):
 *  · SEALED  → qty must be whole packages → back as SEALED cartons
 *  · OPENED  → pieces go into an open package with room, else a new OPEN one
 *  · DAMAGED → stock returns (balance) but flagged in the ledger note
 */
export async function restockToPackages(
  tx: TxLike,
  args: {
    companyId: number;
    warehouseId: number;
    productId: number;
    pieces: Decimal | number;
    info: PackInfo;
    condition?: "SEALED" | "OPENED" | "DAMAGED";
    userId?: number | null;
    refType: string; // SALES_RETURN
    refId?: number | null;
    refNumber?: string | null;
  }
): Promise<{ events: PackageEvent[]; note: string }> {
  const { companyId, warehouseId, productId, info } = args;
  const condition = args.condition ?? "OPENED";
  const pieces = dec(args.pieces);
  if (!info.hasPack || !pieces.isPositive()) return { events: [], note: "" };

  const events: PackageEvent[] = [];

  if (condition === "SEALED") {
    const { packages } = packSplit(pieces, info.packQty);
    if (!qtyR(pieces.mod(info.packQty)).isZero()) {
      throw new ApiError("VAL_001", `الإرجاع مغلق يجب أن يكون بعدد كراتين كاملة (${info.packQty} حبة للكرتونة)`);
    }
    let left = packages;
    // top up existing sealed? none exist by definition (sealed untouched) → create
    while (left > 0) {
      const code = await nextPackageCode(tx, companyId, info.packageType);
      const pkg = await tx.package.create({
        data: {
          companyId, warehouseId, productId,
          packageType: info.packageType, code,
          originalQty: dec(info.packQty), remainingQty: dec(info.packQty),
          status: "SEALED", sourceRefType: "RETURN_IN", sourceRefId: args.refId ?? null,
        },
      });
      await ledger(tx, {
        companyId, warehouseId, productId, packageId: pkg.id,
        packageCode: pkg.code, packageType: pkg.packageType,
        direction: "RESTOCK", openingQty: 0, issuedQty: dec(info.packQty), remainingQty: dec(info.packQty),
        refType: args.refType, refId: args.refId ?? null, refNumber: args.refNumber ?? null,
        note: "إرجاع كرتونة مغلقة (غير مفتوحة)", createdBy: args.userId ?? null,
      });
      events.push({ packageId: pkg.id, code: pkg.code, packageType: pkg.packageType, openingQty: new Decimal(0), issuedQty: dec(info.packQty), remainingQty: dec(info.packQty), action: "FROM_SEALED" });
      left -= 1;
    }
    return { events, note: `أُرجعت ${packages} ${packages === 1 ? info.packUnit : pluralOf(info.packUnit)} مغلقة` };
  }

  // OPENED / DAMAGED → find an open package with room first (§29: no wrong new cartons)
  let remaining = qtyR(pieces);
  const openPkgs = await tx.package.findMany({
    where: { companyId, warehouseId, productId, status: "OPEN" },
    orderBy: { openedAt: "asc" },
  });
  for (const pkg of openPkgs) {
    if (!remaining.isPositive()) break;
    const room = qtyR(dec(info.packQty).minus(pkg.remainingQty));
    if (!room.isPositive()) continue;
    const take = Decimal.min(room, remaining);
    const after = qtyR(dec(pkg.remainingQty).plus(take));
    await tx.package.update({ where: { id: pkg.id }, data: { remainingQty: after, status: "OPEN" } });
    await ledger(tx, {
      companyId, warehouseId, productId, packageId: pkg.id,
      packageCode: pkg.code, packageType: pkg.packageType,
      direction: "RESTOCK", openingQty: dec(pkg.remainingQty), issuedQty: take, remainingQty: after,
      refType: args.refType, refId: args.refId ?? null, refNumber: args.refNumber ?? null,
      note: condition === "DAMAGED" ? "إرجاع حبات (بضاعة تالفة)" : "إرجاع حبات إلى كرتونة مفتوحة",
      createdBy: args.userId ?? null,
    });
    events.push({ packageId: pkg.id, code: pkg.code, packageType: pkg.packageType, openingQty: dec(pkg.remainingQty), issuedQty: take, remainingQty: after, action: "FROM_OPEN" });
    remaining = qtyR(remaining.minus(take));
  }
  if (remaining.isPositive()) {
    const code = await nextPackageCode(tx, companyId, info.packageType);
    const pkg = await tx.package.create({
      data: {
        companyId, warehouseId, productId,
        packageType: info.packageType, code,
        originalQty: dec(info.packQty), remainingQty: remaining,
        status: "OPEN", openedAt: new Date(), openedBy: args.userId ?? null,
        openedReason: "إرجاع حبات — عبوة مفتوحة جديدة",
        sourceRefType: "RETURN_IN", sourceRefId: args.refId ?? null,
      },
    });
    await ledger(tx, {
      companyId, warehouseId, productId, packageId: pkg.id,
      packageCode: pkg.code, packageType: pkg.packageType,
      direction: "RESTOCK", openingQty: 0, issuedQty: remaining, remainingQty: remaining,
      refType: args.refType, refId: args.refId ?? null, refNumber: args.refNumber ?? null,
      note: condition === "DAMAGED" ? "إرجاع حبات تالفة (عبوة معزولة)" : "إرجاع حبات — عبوة مفتوحة جديدة",
      createdBy: args.userId ?? null,
    });
    events.push({ packageId: pkg.id, code: pkg.code, packageType: pkg.packageType, openingQty: new Decimal(0), issuedQty: remaining, remainingQty: remaining, action: "FROM_OPEN" });
    remaining = new Decimal(0);
  }
  const note = condition === "DAMAGED"
    ? `أُرجعت ${trimNum(num(pieces))} حبة (تالفة — مسجلة للتدقيق)`
    : `أُرجعت ${trimNum(num(pieces))} حبة إلى كرتونة مفتوحة`;
  return { events, note };
}

/** Warehouse/product package state (§10): closed cartons, open cartons, pieces inside open, total. */
export function summarizePackages(rows: PackageRow[], info: PackInfo) {
  const closed = rows.filter((r) => r.status === "SEALED").length;
  const openRows = rows.filter((r) => r.status === "OPEN" && dec(r.remainingQty).isPositive());
  const openQty = sumOf(openRows, (r) => r.remainingQty);
  const total = openQty.plus(closed * info.packQty);
  return {
    closed_packages: closed,
    open_packages: openRows.length,
    open_qty: num(qtyR(openQty)),
    total_pieces: num(qtyR(total)),
    text: fmtPackText(num(total), info),
    open_detail: openRows.map((r) => ({ code: r.code, remaining: num(qtyR(r.remainingQty)) })),
  };
}
