// =====================================================================
// Quotation service (عروض الأسعار) — completion phase.
// Pre-sales document: DRAFT → SENT → ACCEPTED | REJECTED | CANCELLED,
// ACCEPTED → convert() creates a real sales invoice in one atomic
// transaction (stock moves, loyalty earns, numbering — same engine as
// manual invoicing via sales-order-service conversion path).
// =====================================================================

import { ApiError } from "./api";
import { db } from "./db";
import { nextDocumentNumber } from "./document-number";
// Phase 3: كل الحساب المالي هنا Decimal — سياسة R1-R10 في ./decimal.ts
import { Decimal, dec, moneyR, qtyR, pctR, sumOf, num } from "./decimal";
import { applyStockMovement } from "./inventory";
// v14 — إلغاء نظام نقاط الولاء: حُذف استيراد محرك الكسب
import { packInfoOf, ensurePackageCoverage, consumeFromPackages, txOf } from "./packaging";
// RP1 §5 — الأسعار الافتراضية من الطبقة المهيكلة (ProductPrice) ثم Legacy موثّق
import { getEffectivePrices, defaultPricesFromRows } from "./product-pricing";
import { getCompanyUsdRate } from "./currency";

interface Ctx {
  userId: number;
  companyId: number;
  warehouseIds: number[];
}

export async function createQuotation(
  ctx: Ctx,
  input: {
    customerId: number;
    warehouseId?: number;
    validUntil?: Date | null;
    notes?: string | null;
    lines: { productId: number; qty: number; unitPrice?: number; discountPct?: number }[];
  }
) {
  const branchId = await resolveBranch(ctx.companyId, input.warehouseId ?? null);

  // resolve prices: explicit override wins, else product sale price
  const ids = input.lines.map((l) => l.productId);
  const products = await db.product.findMany({
    where: { id: { in: ids }, companyId: ctx.companyId, deletedAt: null, isActive: true },
    select: { id: true, salePrice: true, taxRatePct: true, name: true },
  });
  if (products.length !== new Set(ids).size) {
    throw new ApiError("VAL_003", "أحد المنتجات غير موجود أو غير نشط");
  }
  const priceOf = new Map(products.map((p) => [p.id, p]));
  const effMap = await getEffectivePrices(ctx.companyId, ids);
  const companyRate = [...effMap.values()].flat().some((r) => r.currency === "USD")
    ? await getCompanyUsdRate(ctx.companyId)
    : null;

  const calcLines = input.lines.map((l) => {
    const p = priceOf.get(l.productId)!;
    const qty = qtyR(dec(l.qty));
    const unitPrice =
      l.unitPrice != null
        ? moneyR(dec(l.unitPrice))
        : defaultPricesFromRows("quotation", ctx.companyId, effMap.get(l.productId) ?? [], { id: p.id, name: p.name }, num(moneyR(dec(p.salePrice))), null, null, companyRate).pieceIqd;
    const disc = pctR(Decimal.min(Decimal.max(dec(l.discountPct ?? 0), 0), 100));
    const gross = moneyR(qty.mul(unitPrice));
    const lineDiscount = moneyR(gross.mul(disc).div(100));
    const net = moneyR(gross.minus(lineDiscount));
    const tax = moneyR(net.mul(dec(p.taxRatePct)).div(100));
    return {
      productId: l.productId,
      qty,
      unitPrice,
      discountPct: disc,
      lineTotal: net,
      _gross: gross,
      _lineDiscount: lineDiscount,
      _tax: tax,
    };
  });
  const subtotal = moneyR(sumOf(calcLines, (l) => l._gross));
  const discountTotal = moneyR(sumOf(calcLines, (l) => l._lineDiscount));
  const taxTotal = moneyR(sumOf(calcLines, (l) => l._tax));
  const grandTotal = moneyR(subtotal.minus(discountTotal).plus(taxTotal));

  return db.$transaction(async (tx) => {
    const number = await nextDocumentNumber(tx, ctx.companyId, "QUOTATION");
    const q = await tx.quotation.create({
      data: {
        companyId: ctx.companyId,
        branchId,
        number,
        customerId: input.customerId,
        status: "DRAFT",
        validUntil: input.validUntil ?? null,
        notes: input.notes ?? null,
        subtotal,
        discountTotal,
        taxTotal,
        grandTotal,
        createdById: ctx.userId,
        lines: {
          create: calcLines.map((l) => ({
            productId: l.productId,
            qty: l.qty,
            unitPrice: l.unitPrice,
            discountPct: l.discountPct,
            lineTotal: l.lineTotal,
          })),
        },
      },
      include: { lines: { include: { product: { select: { code: true, name: true, unit: true } } } } },
    });
    // R10 — حدود الاستجابة: أرقام للواجهة كما كانت (المفاتيح نفسها)
    return {
      ...q,
      subtotal: num(q.subtotal),
      discountTotal: num(q.discountTotal),
      taxTotal: num(q.taxTotal),
      grandTotal: num(q.grandTotal),
      lines: q.lines.map((l) => ({
        ...l,
        qty: num(l.qty),
        unitPrice: num(l.unitPrice),
        discountPct: num(l.discountPct),
        lineTotal: num(l.lineTotal),
      })),
    };
  });
}

export async function setQuotationStatus(
  ctx: Ctx,
  id: number,
  status: "SENT" | "ACCEPTED" | "REJECTED" | "CANCELLED"
) {
  const q = await db.quotation.findFirst({ where: { id, companyId: ctx.companyId, deletedAt: null } });
  if (!q) throw new ApiError("VAL_003", "عرض السعر غير موجود");
  if (q.status === "CONVERTED") throw new ApiError("QTN_001", "عرض السعر محوَّل لفاتورة — لا يمكن تغيير حالته");
  if (q.status === status) return q;

  const allowed: Record<string, string[]> = {
    DRAFT: ["SENT", "ACCEPTED", "REJECTED", "CANCELLED"],
    SENT: ["ACCEPTED", "REJECTED", "CANCELLED"],
    ACCEPTED: ["CANCELLED"],
    REJECTED: [],
    CANCELLED: [],
  };
  if (!allowed[q.status]?.includes(status)) {
    throw new ApiError("QTN_002", `انتقال حالة غير مسموح: ${q.status} → ${status}`);
  }
  return db.quotation.update({ where: { id: q.id }, data: { status } });
}

export async function convertQuotation(ctx: Ctx, id: number, payMode: "CASH" | "CREDIT", paidAmount = 0) {
  const q = await db.quotation.findFirst({
    where: { id, companyId: ctx.companyId, deletedAt: null },
    include: { lines: { include: { product: true } }, customer: true },
  });
  if (!q) throw new ApiError("VAL_003", "عرض السعر غير موجود");
  if (q.status === "CONVERTED") throw new ApiError("QTN_001", "عرض السعر محوَّل مسبقًا");
  if (q.status === "CANCELLED" || q.status === "REJECTED") throw new ApiError("QTN_002", "عرض ملغى/مرفوض — لا يمكن تحويله");
  if (q.lines.length === 0) throw new ApiError("QTN_003", "عرض بلا بنود");
  if (!ctx.warehouseIds.length) throw new ApiError("AUTH_004", "لا مستودع ضمن نطاقك");
  if (!q.customer.isActive) throw new ApiError("VAL_001", "العميل معطل — لا يمكن البيع له");

  const warehouseId = ctx.warehouseIds[0];
  const wh = await db.warehouse.findFirst({
    where: { id: warehouseId, companyId: ctx.companyId, deletedAt: null, isActive: true },
    select: { id: true, branchId: true },
  });
  if (!wh) throw new ApiError("VAL_003", "المستودع غير متاح");

  const customer = q.customer;
  const paid =
    payMode === "CASH"
      ? moneyR(dec(q.grandTotal))
      : moneyR(Decimal.min(Decimal.max(dec(paidAmount), 0), dec(q.grandTotal)));
  const due = moneyR(dec(q.grandTotal).minus(paid));
  const previousBalance = moneyR(dec(customer.balance));
  const projectedBalance = moneyR(previousBalance.plus(due));

  // credit guard (R2) — same as manual invoicing
  if (payMode === "CREDIT" && dec(customer.creditLimit).isPositive()) {
    const projected = moneyR(dec(customer.balance).plus(due));
    if (projected.gt(dec(customer.creditLimit))) {
      throw new ApiError("CREDIT_001", `تجاوز حد الائتمان — الحد: ${num(dec(customer.creditLimit))}، الرصيد الحالي: ${num(dec(customer.balance))}، بعد الفاتورة: ${num(projected)}`);
    }
  }

  const invoice = await db.$transaction(async (tx) => {
    const number = await nextDocumentNumber(tx, ctx.companyId, "INVOICE");

    const inv = await tx.salesInvoice.create({
      data: {
        companyId: ctx.companyId,
        branchId: wh.branchId,
        warehouseId: wh.id,
        customerId: q.customerId,
        number,
        type: payMode,
        saleType: payMode === "CREDIT" ? ((paid.isPositive() && paid.lt(dec(q.grandTotal))) ? "PARTIAL" : "CREDIT") : "CASH",
        status: "POSTED",
        invoiceDate: new Date(),
        subtotal: q.subtotal,
        discountTotal: q.discountTotal,
        taxTotal: q.taxTotal,
        grandTotal: q.grandTotal,
        paidAmount: paid,
        previousBalance,
        newBalance: projectedBalance,
        creditLimitSnap: customer.creditLimit,
        repId: ctx.userId,
        notes: `من عرض السعر ${q.number}`,
        createdById: ctx.userId,
      },
    });

    const ptx = txOf(tx);
    for (const line of q.lines) {
      const info = packInfoOf(line.product);
      await ensurePackageCoverage(ptx, {
        companyId: ctx.companyId, warehouseId: wh.id, productId: line.productId, info, userId: ctx.userId,
      });
      const beforeRow = await tx.stockBalance.findUnique({
        where: { warehouseId_productId: { warehouseId: wh.id, productId: line.productId } },
      });
      const stockBefore = qtyR(dec(beforeRow?.qty));

      await tx.salesInvoiceLine.create({
        data: {
          invoiceId: inv.id,
          productId: line.productId,
          qty: line.qty,
          orderedQty: line.qty,
          unitPrice: line.unitPrice,
          discountPct: line.discountPct,
          lineTotal: line.lineTotal,
          unitCost: dec(line.product.costPrice),
          stockBefore,
          stockAfter: qtyR(stockBefore.minus(line.qty)),
        },
      });

      // stock OUT — same engine as manual invoicing
      await applyStockMovement({
        tx,
        companyId: ctx.companyId,
        warehouseId: wh.id,
        productId: line.productId,
        direction: "OUT",
        qty: line.qty,
        unitCost: line.product.costPrice,
        refType: "SALES_INVOICE",
        refId: inv.id,
        note: `تحويل عرض ${q.number}`,
        userId: ctx.userId,
      });

      // packaging consumption — same engine as manual invoicing
      if (info.hasPack) {
        await consumeFromPackages(ptx, {
          companyId: ctx.companyId, warehouseId: wh.id, productId: line.productId,
          pieces: line.qty, info, userId: ctx.userId,
          refType: "SALES_INVOICE", refId: inv.id, refNumber: number,
        });
      }
    }

    // receivable — same as manual invoicing
    if (due.isPositive()) {
      await tx.customer.update({ where: { id: q.customerId }, data: { balance: { increment: due } } });
    }

    // v14 — إلغاء نقاط الولاء: لا كسب نقاط عند تحويل عرض السعر لفاتورة

    await tx.quotation.update({
      where: { id: q.id },
      data: { status: "CONVERTED", convertedInvoiceId: inv.id },
    });

    return inv;
  });

  return { quotation_id: q.id, invoice_id: invoice.id, invoice_number: invoice.number };
}

async function resolveBranch(companyId: number, warehouseId: number | null): Promise<number> {
  if (warehouseId) {
    const wh = await db.warehouse.findFirst({ where: { id: warehouseId, companyId, deletedAt: null }, select: { branchId: true } });
    if (wh) return wh.branchId;
  }
  const branch = await db.branch.findFirst({ where: { companyId, deletedAt: null, isActive: true }, orderBy: { id: "asc" }, select: { id: true } });
  if (!branch) throw new ApiError("VAL_003", "لا يوجد فرع للشركة");
  return branch.id;
}

// ---------------------------------------------------------------------
// مشاركة عامة لعروض الأسعار — رمز uuid الموجود هو التصريح (نمط §37 نفسه).
// عرض عام للعميل عبر /verify/<uuid>: بنود العرض والإجماليات فقط — بلا
// تكاليف ولا بيانات داخلية. CANCELLED يبقى مرئياً بحالته (شفافية).
// ---------------------------------------------------------------------
export async function verifyQuotationByToken(token: string) {
  const q = await db.quotation.findFirst({
    where: { uuid: token, deletedAt: null },
    select: {
      number: true, quoteDate: true, validUntil: true, status: true, notes: true,
      subtotal: true, discountTotal: true, taxTotal: true, grandTotal: true,
      company: { select: { name: true, nameEn: true, phone: true, address: true, logoUrl: true } },
      customer: { select: { name: true, shopName: true } },
      lines: {
        select: {
          id: true, qty: true, unitPrice: true, discountPct: true, lineTotal: true,
          product: { select: { name: true, unit: true } },
        },
        orderBy: { id: "asc" },
      },
    },
  });
  if (!q) return null;
  return {
    valid: true,
    kind: "QUOTATION" as const,
    quotation_number: q.number,
    quote_date: q.quoteDate,
    valid_until: q.validUntil,
    status_ar: q.status === "DRAFT" ? "مسودة" : q.status === "SENT" ? "مُرسل للعميل" : q.status === "ACCEPTED" ? "مقبول" : q.status === "REJECTED" ? "مرفوض" : q.status === "CONVERTED" ? "محوّل لفاتورة" : "ملغى",
    company: {
      name: q.company.name || q.company.nameEn,
      phone: q.company.phone,
      address: q.company.address,
      has_logo: !!q.company.logoUrl,
    },
    customer: { name: q.customer.name, shop_name: q.customer.shopName },
    notes: q.notes,
    totals: {
      subtotal: num(q.subtotal),
      discount_total: num(q.discountTotal),
      tax_total: num(q.taxTotal),
      grand_total: num(q.grandTotal),
    },
    lines: q.lines.map((l) => ({
      id: l.id,
      product: l.product.name,
      unit: l.product.unit,
      qty: num(l.qty),
      unit_price: num(l.unitPrice),
      discount_pct: num(l.discountPct),
      line_total: num(l.lineTotal),
    })),
  };
}
