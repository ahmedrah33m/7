// =====================================================================
// Rotating refresh tokens (API spec /auth/refresh):
//  - Issue: opaque token, sha256 at rest, 7-day expiry, chain root.
//  - Rotate: old token → revoked + replacedBy set; new token chained.
//  - Reuse detection: a token already revoked/expired → revoke the WHOLE
//    chain (security measure) with AUTH_006.
// =====================================================================

import { db } from "@/lib/db";
import { generateRefreshToken, sha256Hex, REFRESH_TOKEN_TTL_SEC } from "@/lib/jwt";

export async function issueRefreshToken(
  userId: number,
  parentUuid: string | null,
  ip: string,
  userAgent: string,
  activeBranchId?: number | null
): Promise<{ token: string; uuid: string; expiresAt: Date }> {
  const token = generateRefreshToken();
  const tokenHash = await sha256Hex(token);
  const expiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL_SEC * 1000);

  const row = await db.refreshToken.create({
    data: {
      userId,
      tokenHash,
      parentUuid,
      expiresAt,
      ipAddress: ip,
      userAgent,
      ...(activeBranchId != null ? { activeBranchId } : {}),
    },
  });

  return { token, uuid: row.uuid, expiresAt: expiresAt };
}

export type RefreshCheck =
  | { ok: true; row: { id: number; uuid: string; userId: number; activeBranchId: number | null } }
  | { ok: false; reason: "INVALID" }
  | { ok: false; reason: "EXPIRED" | "REUSED"; userId: number; companyId: number | null; uuid: string };

/** Validate a presented refresh token; detects reuse of rotated tokens. */
export async function checkRefreshToken(presented: string): Promise<RefreshCheck> {
  const tokenHash = await sha256Hex(presented);
  const row = await db.refreshToken.findUnique({ where: { tokenHash } });
  if (!row) return { ok: false, reason: "INVALID" };

  if (row.revokedAt) {
    // Reuse of an already-rotated token → kill the whole chain.
    await revokeChain(row.uuid, row.userId);
    return { ok: false, reason: "REUSED", userId: row.userId, companyId: null, uuid: row.uuid };
  }
  if (row.expiresAt <= new Date()) {
    await db.refreshToken.update({ where: { id: row.id }, data: { revokedAt: new Date() } });
    return { ok: false, reason: "EXPIRED", userId: row.userId, companyId: null, uuid: row.uuid };
  }
  return { ok: true, row: { id: row.id, uuid: row.uuid, userId: row.userId, activeBranchId: row.activeBranchId } };
}

/** Mark the presented token as rotated (revoked + replaced-by). */
export async function markRotated(uuid: string, replacedByUuid: string): Promise<void> {
  await db.refreshToken.update({
    where: { uuid },
    data: { revokedAt: new Date(), replacedByUuid },
  });
}

/** Revoke the whole rotation chain containing tokenUuid (BFS over parentUuid links). */
export async function revokeChain(tokenUuid: string, userId: number): Promise<void> {
  const all = await db.refreshToken.findMany({
    where: { userId, revokedAt: null },
    select: { uuid: true, parentUuid: true },
  });
  const byUuid = new Map(all.map((r) => [r.uuid, r]));

  // Walk down the chain from the reused token (children keep parentUuid links).
  const toRevoke = new Set<string>([tokenUuid]);
  let grew = true;
  while (grew) {
    grew = false;
    for (const r of all) {
      if (r.parentUuid && toRevoke.has(r.parentUuid) && !toRevoke.has(r.uuid)) {
        toRevoke.add(r.uuid);
        grew = true;
      }
    }
  }
  // Also revoke ancestors (tokens this chain descended from).
  let cursor = byUuid.get(tokenUuid);
  while (cursor?.parentUuid) {
    toRevoke.add(cursor.parentUuid);
    cursor = byUuid.get(cursor.parentUuid);
  }

  await db.refreshToken.updateMany({
    where: { uuid: { in: Array.from(toRevoke) } },
    data: { revokedAt: new Date() },
  });
}

/** Revoke every active token of a user (logout-all / account compromise). */
export async function revokeAllForUser(userId: number): Promise<void> {
  await db.refreshToken.updateMany({
    where: { userId, revokedAt: null },
    data: { revokedAt: new Date() },
  });
}
