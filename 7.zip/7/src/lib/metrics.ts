// =====================================================================
// In-process metrics registry (§71 — Monitoring gap closure).
// Every API route goes through handler() in lib/api.ts which calls
// record() — giving request counts, error counts and latency per route
// without any external dependency. snapshot() enriches with process
// (uptime/RSS/heap) and database vitals (tables, file size, key counts)
// so the dashboard shows one coherent operational picture.
//
// Design constraints respected:
//   · Read-only aggregation — never touches balances or documents.
//   · Bounded memory: per-route buckets capped (LRU-ish by maxKeys).
//   · Cheap: snapshot() runs 6 COUNT queries max, safe to poll every 30s.
// =====================================================================

interface RouteBucket {
  path: string;
  count: number;
  errors: number;
  totalMs: number;
  lastStatus: number;
  lastAt: string;
}

const buckets = new Map<string, RouteBucket>();
const MAX_BUCKETS = 200;
const startedAt = Date.now();

/** Normalize a route path: numeric/uuid segments → :id so buckets group by pattern. */
export function normalizeRoutePath(pathname: string): string {
  return pathname
    .replace(/^\/api\/v1/, "")
    .split("/")
    .map((seg) => (/^\d+$/.test(seg) || /^[0-9a-f]{8}-[0-9a-f]{4}/i.test(seg) ? ":id" : seg))
    .join("/");
}

export function recordRequest(path: string, status: number, ms: number): void {
  const key = normalizeRoutePath(path);
  let b = buckets.get(key);
  if (!b) {
    if (buckets.size >= MAX_BUCKETS) {
      // drop the oldest entry to stay bounded
      const oldest = buckets.keys().next().value;
      if (oldest) buckets.delete(oldest);
    }
    b = { path: key, count: 0, errors: 0, totalMs: 0, lastStatus: 0, lastAt: "" };
    buckets.set(key, b);
  }
  b.count += 1;
  b.totalMs += ms;
  b.lastStatus = status;
  b.lastAt = new Date().toISOString();
  if (status >= 400) b.errors += 1;
}

async function dbVitals() {
  const { db } = await import("./db");
  const tables = await db.$queryRawUnsafe<{ name: string }[]>(
    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_prisma%'"
  );
  const pageInfo = await db.$queryRawUnsafe<{ page_count: number; page_size: number }[]>(
    "SELECT page_count, page_size FROM pragma_page_count(), pragma_page_size()"
  );
  const [products, invoices, customers, users, movements, audit] = await Promise.all([
    db.product.count(),
    db.salesInvoice.count(),
    db.customer.count(),
    db.user.count(),
    db.stockMovement.count(),
    db.auditLog.count(),
  ]);
  const sizeBytes = pageInfo[0] ? Number(pageInfo[0].page_count) * Number(pageInfo[0].page_size) : 0;
  return {
    engine: "SQLite (portable → PostgreSQL 16 in deploy)",
    tables: tables.length,
    size_bytes: sizeBytes,
    counts: { products, invoices, customers, users, stock_movements: movements, audit_logs: audit },
  };
}

export async function snapshot() {
  const mem = process.memoryUsage();
  const routes = [...buckets.values()]
    .map((b) => ({
      path: b.path,
      requests: b.count,
      errors: b.errors,
      avg_ms: b.count ? Math.round(b.totalMs / b.count) : 0,
      last_status: b.lastStatus,
      last_at: b.lastAt,
    }))
    .sort((a, b) => b.requests - a.requests);

  const totalRequests = routes.reduce((s, r) => s + r.requests, 0);
  const totalErrors = routes.reduce((s, r) => s + r.errors, 0);

  let database: Awaited<ReturnType<typeof dbVitals>> | { error: string } = { error: "unavailable" };
  try {
    database = await dbVitals();
  } catch (e) {
    database = { error: (e as Error).message.slice(0, 120) };
  }

  return {
    process: {
      pid: process.pid,
      node: process.version,
      platform: process.platform,
      uptime_sec: Math.round((Date.now() - startedAt) / 1000),
      rss_mb: Math.round(mem.rss / 1024 / 1024),
      heap_used_mb: Math.round(mem.heapUsed / 1024 / 1024),
      heap_total_mb: Math.round(mem.heapTotal / 1024 / 1024),
    },
    http: {
      total_requests: totalRequests,
      total_errors: totalErrors,
      error_rate_pct: totalRequests ? Math.round((totalErrors / totalRequests) * 1000) / 10 : 0,
      tracked_routes: routes.length,
      top_routes: routes.slice(0, 15),
    },
    database,
    generated_at: new Date().toISOString(),
  };
}

/** Prometheus-style text rendering (optional format=text consumers). */
export function snapshotPrometheus(snap: Awaited<ReturnType<typeof snapshot>>): string {
  const lines: string[] = [];
  lines.push("# TYPE sds_uptime_seconds gauge");
  lines.push(`sds_uptime_seconds ${snap.process.uptime_sec}`);
  lines.push("# TYPE sds_rss_mb gauge");
  lines.push(`sds_rss_mb ${snap.process.rss_mb}`);
  lines.push("# TYPE sds_http_requests_total counter");
  lines.push(`sds_http_requests_total ${snap.http.total_requests}`);
  lines.push("# TYPE sds_http_errors_total counter");
  lines.push(`sds_http_errors_total ${snap.http.total_errors}`);
  for (const r of snap.http.top_routes) {
    const label = r.path.replace(/"/g, "");
    lines.push(`sds_route_requests_total{path="${label}"} ${r.requests}`);
    lines.push(`sds_route_latency_ms{path="${label}"} ${r.avg_ms}`);
  }
  return lines.join("\n") + "\n";
}
