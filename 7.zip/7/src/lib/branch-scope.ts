// =====================================================================
// Branch scope helpers — multi-branch isolation (SaaS-readiness rule):
//   · session.branchScope built in authenticate() from user_roles.branchId
//     (NULL assignment = كل الفروع، وإلا فالفروع المُسندة فقط)
//   · branchFilter()      → Prisma where fragment for reads
//   · assertBranchAccess()→ write/read guard on a specific entity branch
//   · Entities with branchId = NULL are company-wide (عامة) — visible to
//     every branch; stamped entities are visible only within scope.
// Every business document already carries branch_id via its warehouse
// (sales-service: branchId: wh.branch.id), so writes are self-stamped.
// =====================================================================

import { ApiError } from "./api";
import { db } from "./db";
import type { Session } from "./auth";

export interface BranchWhereFragment {
  branchId?: { in: number[] };
}

/**
 * Session → scope-shape adapter.
 * الجلسة القياسية (auth.ts) تحمل scopeType + branchIds[] — والشكل القديم
 * { all, ids } يُشتق منها: GLOBAL/COMPANY = كل فروع الشركة، وإلا فالفروع
 * المُسندة فقط (مع تفعيل الفرع النشط عبر activeBranchId عند القراءة).
 */
function branchScopeOf(session: Session): { all: boolean; ids: number[] } {
  return {
    all: session.scopeType === "GLOBAL" || session.scopeType === "COMPANY",
    ids: session.branchIds,
  };
}

/**
 * Prisma where-fragment from a raw scope object — usable inside services
 * where only the scope (not the full session) is available.
 * STRICT: restricted users see only their branch's rows (no OR — composes
 * safely with search filters; every entity is branch-stamped by seed).
 */
export function branchWhereFor(scope: { all: boolean; ids: number[] } | undefined | null): BranchWhereFragment {
  if (!scope || scope.all) return {};
  return { branchId: { in: scope.ids } };
}

/**
 * Prisma where-fragment restricting reads to the session's branches.
 * Restricted users ALSO see company-wide rows (branchId NULL).
 * Unrestricted users (all=true) get an empty fragment — no change.
 */
export function branchFilter(session: Session): BranchWhereFragment {
  return branchWhereFor(branchScopeOf(session));
}

/** Strict variant: hides company-wide rows too — for entity listings where
 *  NULL means "غير مصنف" rather than "عام" (used by demo isolation tests). */
export function branchFilterStrict(session: Session): BranchWhereFragment {
  const s = branchScopeOf(session);
  if (s.all) return {};
  return { branchId: { in: s.ids } };
}

/**
 * Guard: entity's branch must be inside the session's scope.
 * NULL branchId = company-wide → allowed for everyone.
 * Throws SCOPE_001 (403) — "هذا الكيان خارج نطاقك (فرع/مستودع)".
 */
export function assertBranchAccess(session: Session, branchId: number | null | undefined): void {
  if (branchId == null) return;
  const s = branchScopeOf(session);
  if (s.all || s.ids.includes(branchId)) return;
  throw new ApiError("SCOPE_001", "هذا الكيان خارج نطاق فرعك");
}

/**
 * Resolve the branch to stamp on a NEW party (customer/supplier):
 *   · explicit requested wins (must be in scope)
 *   · restricted user → their first assigned branch
 *   · unrestricted user → company's first branch (keeps every row
 *     branch-addressable — NULL rows would be invisible to bound users)
 */
export async function resolveStampBranch(
  session: Session,
  requested?: number | null
): Promise<{ branchId: number | null }> {
  if (requested != null) {
    assertBranchAccess(session, requested);
    return { branchId: requested };
  }
  const s = branchScopeOf(session);
  if (!s.all && s.ids.length > 0) return { branchId: s.ids[0] };
  const first = await db.branch.findFirst({
    where: { companyId: session.companyId, deletedAt: null },
    orderBy: { id: "asc" },
    select: { id: true },
  });
  return { branchId: first?.id ?? null };
}
