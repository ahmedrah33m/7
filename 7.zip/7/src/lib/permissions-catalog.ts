// =====================================================================
// Permission catalog generator — module.action codes (API spec §1.4).
// 16 atomic actions; catalog is global; granted to roles only.
// Phase 0 seeds the core modules fully; later phases extend entities
// inside their modules with the same generator.
//
// Phase 37 (MASTER PROMPT — Kayan Finance) adds 4 finance-specific
// actions: close / reopen / reconcile / allocate — required for the
// cashbox lifecycle and payment allocation workflow.
// =====================================================================

export const ACTIONS = [
  "view", "create", "edit", "delete",
  "approve", "reject", "cancel",
  "print", "export", "import",
  "post", "reverse",
] as const;

/**
 * Phase 37 — Finance-specific lifecycle actions that don't apply to other
 * entities (a product or a customer cannot be "closed" or "reopened").
 * These are surfaced ONLY on the cashboxes and payments entities via
 * explicit `actions: [...]` lists.
 */
export const FINANCE_LIFECYCLE_ACTIONS = ["close", "reopen", "reconcile", "allocate"] as const;
export type FinanceLifecycleAction = (typeof FINANCE_LIFECYCLE_ACTIONS)[number];

/** Combined list — used only for typing, not for catalog enumeration. */
export type Action = (typeof ACTIONS)[number] | FinanceLifecycleAction;

/** The full string set of all actions used in the catalog. */
export const ALL_ACTIONS = [...ACTIONS, ...FINANCE_LIFECYCLE_ACTIONS] as const;

export interface EntityDef {
  module: string;
  entity: string;
  actions: readonly Action[];
  descAr: string;
}

// ---- Phase 0 entities (Core & Security) --------------------------------
const CORE_ENTITIES: EntityDef[] = [
  { module: "system", entity: "settings", actions: ["view", "edit"], descAr: "إعدادات النظام" },
  { module: "system", entity: "company", actions: ["view", "edit", "delete"], descAr: "بيانات الشركات (حذف الشركة = صلاحية مستقلة)" },
  { module: "system", entity: "branches", actions: ["view", "create", "edit", "delete"], descAr: "الفروع" },
  { module: "system", entity: "warehouses", actions: ["view", "create", "edit", "delete"], descAr: "المستودعات" },
  { module: "system", entity: "users", actions: ["view", "create", "edit", "delete"], descAr: "المستخدمون" },
  { module: "system", entity: "roles", actions: ["view", "create", "edit", "delete"], descAr: "الأدوار والصلاحيات" },
  { module: "system", entity: "files", actions: ["view", "create"], descAr: "الملفات والصور (RP5 §10)" },
  { module: "audit", entity: "audit_logs", actions: ["view", "export"], descAr: "سجل التدقيق" },
];

// ---- Phase 1+ entities (structure visible now) -------------------------
const FUTURE_ENTITIES: EntityDef[] = [
  { module: "products", entity: "products", actions: ACTIONS, descAr: "المنتجات" },
  { module: "products", entity: "price_lists", actions: ACTIONS, descAr: "قوائم الأسعار" },
  { module: "parties", entity: "customers", actions: ACTIONS, descAr: "العملاء" },
  { module: "parties", entity: "suppliers", actions: ACTIONS, descAr: "الموردون" },
  { module: "inventory", entity: "stock", actions: ["view"], descAr: "أرصدة المخزون" },
  { module: "inventory", entity: "movements", actions: ["view", "create"], descAr: "حركات المخزون (إدخال/تسوية)" },
  { module: "inventory", entity: "transfers", actions: ACTIONS, descAr: "التحويلات المخزنية" },
  { module: "inventory", entity: "adjustments", actions: ACTIONS, descAr: "تسويات المخزون" },
  { module: "sales", entity: "invoices", actions: ACTIONS, descAr: "فواتير البيع" },
  { module: "sales", entity: "orders", actions: ACTIONS, descAr: "أوامر البيع" },
  { module: "sales", entity: "returns", actions: ACTIONS, descAr: "مرتجعات البيع" },
  { module: "purchasing", entity: "purchase_orders", actions: ACTIONS, descAr: "أوامر الشراء" },
  { module: "purchasing", entity: "purchase_invoices", actions: ACTIONS, descAr: "فواتير الشراء والاستلام" },
  { module: "finance", entity: "cashboxes", actions: ["view", "create", "edit", "delete", "close", "reopen", "reconcile"], descAr: "صناديق النقدية (إغلاق/فتح/جرد)" },
  { module: "finance", entity: "payments", actions: ["view", "create", "edit", "delete", "cancel", "allocate"], descAr: "التحصيلات وسدادات الموردين (تخصيص الدفعات)" },
  { module: "finance", entity: "expenses", actions: ACTIONS, descAr: "المصروفات" },
  { module: "reports", entity: "reports", actions: ["view", "export", "print"], descAr: "التقارير" },
  // ---- Phase 4 — Field sales ---------------------------------------------
  { module: "field", entity: "targets", actions: ["view", "create", "edit", "delete"], descAr: "أهداف المندوبين" },
  { module: "field", entity: "visits", actions: ["view", "create", "edit", "cancel"], descAr: "زيارات المندوبين (GPS)" },
  { module: "field", entity: "routes", actions: ["view", "create", "edit", "delete"], descAr: "مسارات التوزيع" },
  { module: "field", entity: "commissions", actions: ["view", "approve"], descAr: "عمولات المندوبين" },
  // ---- Phase 8 — B2B portal ----------------------------------------------
  { module: "b2b", entity: "orders", actions: ["view", "approve", "reject", "cancel"], descAr: "طلبات بوابة العملاء B2B" },
  // ---- Completion phase — quotations / stocktake / delivery ---------------
  { module: "sales", entity: "quotations", actions: ["view", "create", "edit", "delete", "cancel", "post"], descAr: "عروض الأسعار وتحويلها لفواتير" },
  { module: "inventory", entity: "stocktakes", actions: ["view", "create", "edit", "delete", "post", "cancel"], descAr: "الجرد الفعلي وترحيل الفروقات" },
  { module: "sales", entity: "delivery_notes", actions: ["view", "create", "edit", "cancel"], descAr: "إشعارات التسليم" },
  // ---- Advanced finance — vouchers / transfers / closings / statements -
  { module: "finance", entity: "receipts", actions: ["view", "create", "cancel", "print", "export"], descAr: "وصولات القبض" },
  { module: "finance", entity: "payment_vouchers", actions: ["view", "create", "cancel", "print", "export"], descAr: "وصولات الصرف" },
  { module: "finance", entity: "cash_transfers", actions: ["view", "create", "approve", "cancel"], descAr: "تحويلات الصناديق" },
  { module: "finance", entity: "cash_closings", actions: ["view", "create", "edit", "cancel"], descAr: "إغلاق وجرد الصندوق" },
  { module: "finance", entity: "statements", actions: ["view", "export", "print"], descAr: "كشوف الحسابات" },
  { module: "finance", entity: "aging", actions: ["view", "export"], descAr: "أعمار الديون" },
  { module: "finance", entity: "cashier_shifts", actions: ["view", "create", "edit"], descAr: "ورديات الكاشير" },
  { module: "finance", entity: "recurring_expenses", actions: ["view", "create", "edit", "delete"], descAr: "المصروفات المتكررة" },
  { module: "finance", entity: "expense_categories", actions: ["view", "create", "edit"], descAr: "تصنيفات المصروفات" },
  { module: "finance", entity: "bank_accounts", actions: ["view", "create", "edit"], descAr: "الحسابات البنكية" },
  { module: "finance", entity: "checks", actions: ["view", "create", "edit"], descAr: "الشيكات" },
  { module: "finance", entity: "bank_deposits", actions: ["view", "create"], descAr: "إيداعات بنكية" },
  { module: "finance", entity: "bank_withdrawals", actions: ["view", "create"], descAr: "سحوبات بنكية" },
  // ---- v15 — Phase 4/8/38: new finance entities ------------------------
  { module: "finance", entity: "rep_settlements", actions: ["view", "create", "cancel", "print"], descAr: "تسليمات المندوبين (REP-STL-)" },
  { module: "finance", entity: "overdue_notifications", actions: ["view", "create"], descAr: "إشعارات الديون المتأخرة" },
  { module: "finance", entity: "exchange_rates", actions: ["view", "create", "edit"], descAr: "أسعار الصرف التاريخية" },
  { module: "finance", entity: "finance_errors", actions: ["view", "edit"], descAr: "سجل الأخطاء المالية" },
  { module: "system", entity: "backup_logs", actions: ["view"], descAr: "سجل النسخ الاحتياطي" },
  { module: "accounting", entity: "accounts", actions: ["view", "create", "edit"], descAr: "دليل الحسابات" },
  { module: "accounting", entity: "journal_entries", actions: ["view", "create", "post", "reverse"], descAr: "قيود اليومية" },
  { module: "accounting", entity: "budgets", actions: ["view", "create", "edit"], descAr: "الموازنات" },
  { module: "accounting", entity: "financial_periods", actions: ["view", "create", "post", "reverse"], descAr: "الفترات المالية" },
  { module: "accounting", entity: "cost_centers", actions: ["view", "create", "edit"], descAr: "مراكز التكلفة" },
  { module: "reports", entity: "accounting_reports", actions: ["view", "export", "print"], descAr: "التقارير المحاسبية (ميزان، ميزانية، قائمة دخل)" },
];

export const CATALOG: EntityDef[] = [...CORE_ENTITIES, ...FUTURE_ENTITIES];

export function permissionCode(def: EntityDef, action: Action): string {
  return `${def.module}.${def.entity}.${action}`;
}

export function* allPermissions(): Generator<{ code: string; module: string; entity: string; action: string; descriptionAr: string }> {
  for (const def of CATALOG) {
    for (const action of def.actions) {
      yield {
        code: permissionCode(def, action),
        module: def.module,
        entity: def.entity,
        action,
        descriptionAr: `${def.descAr} — ${ACTION_LABEL_AR[action]}`,
      };
    }
  }
}

export const ACTION_LABEL_AR: Record<Action, string> = {
  view: "عرض",
  create: "إنشاء",
  edit: "تعديل",
  delete: "حذف",
  approve: "اعتماد",
  reject: "رفض",
  cancel: "إلغاء",
  print: "طباعة",
  export: "تصدير",
  import: "استيراد",
  post: "ترحيل",
  reverse: "عكس",
  close: "إغلاق",
  reopen: "فتح",
  reconcile: "تسوية/جرد",
  allocate: "تخصيص",
};

/** Wildcard helper: does `set` satisfy any of the codes (exact)? */
export function hasAny(set: Set<string>, codes: string[]): boolean {
  return codes.some((c) => set.has(c));
}
