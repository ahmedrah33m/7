// =====================================================================
// User & branch management core — shared by /admin/users and
// /admin/branches (Task 25). كل مستخدم جديد يحصل على:
//   · argon2id hash لكلمة المرور
//   · أدوار مع ربط اختياري بفرع (user_roles.branch_id → نطاق العزل)
//   · وصول مستودعات (قراءة + تشغيل) — آلي من الفرع أو صريح
//   · مستودع سيارة آلي للمندوب (SALES_REP) حتى يبيع من مخزونه فورًا
// =====================================================================

import { db } from "./db";
import { hashPassword } from "./password";
import { ApiError } from "./api";

export const USERNAME_RE = /^[a-zA-Z0-9._-]{3,30}$/;

/** سياسة كلمة المرور: ≥8 خانات + حرف كبير + صغير + رقم (§2 الأمان). */
export function assertPasswordPolicy(password: string): void {
  if (typeof password !== "string" || password.length < 8)
    throw new ApiError("VAL_001", "كلمة المرور يجب أن تكون 8 خانات على الأقل");
  if (!/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/[0-9]/.test(password))
    throw new ApiError("VAL_001", "كلمة المرور يجب أن تحوي حرفًا كبيرًا وصغيرًا ورقمًا على الأقل");
}

export function assertUsername(username: string): void {
  if (typeof username !== "string" || !USERNAME_RE.test(username))
    throw new ApiError("VAL_001", "اسم المستخدم: 3-30 خانة بحروف إنجليزية وأرقام و . _ - فقط");
}

export interface CreateUserInput {
  companyId: number;
  actorId: number;
  username: string;
  password: string;
  fullName: string;
  email?: string | null;
  phone?: string | null;
  branchId?: number | null;
  roleCodes: string[];
  warehouseIds?: number[];
  /** ربط الأدوار بالفرع → عزل نطاق الفرع (user_roles.branch_id) */
  bindToBranch?: boolean;
}

export interface CreatedUser {
  id: number;
  username: string;
  fullName: string;
  branchId: number | null;
  roleCodes: string[];
  warehouseIds: number[];
  createdWarehouseId: number | null;
}

/**
 * إنشاء مستخدم كامل في لمشة معاملة واحدة: فحص التفرد + hash + أدوار
 * (مربوطة بالفرع عند الطلب) + وصول المستودعات + مستودع مندوب آلي.
 */
export async function createUserTx(input: CreateUserInput): Promise<CreatedUser> {
  const username = input.username.trim().toLowerCase();
  assertUsername(username);
  assertPasswordPolicy(input.password);
  if (!input.fullName?.trim()) throw new ApiError("VAL_001", "الاسم الكامل مطلوب");
  if (!Array.isArray(input.roleCodes) || input.roleCodes.length === 0)
    throw new ApiError("VAL_001", "يجب اختيار دور واحد على الأقل");

  // تفرد اسم المستخدم داخل الشركة (المحذوف ناعمًا لا يحجب الاسم)
  const dupe = await db.user.findFirst({
    where: { companyId: input.companyId, username, deletedAt: null },
    select: { id: true },
  });
  if (dupe) throw new ApiError("VAL_002", `اسم المستخدم «${username}» محجوز مسبقًا`);

  // الفرع يجب أن يعود للشركة
  let branchId = input.branchId ?? null;
  if (branchId != null) {
    const branch = await db.branch.findFirst({
      where: { id: branchId, companyId: input.companyId, deletedAt: null },
      select: { id: true },
    });
    if (!branch) throw new ApiError("VAL_001", "الفرع غير موجود في شركتك");
  }

  // الأدوار موجودة وتعود للشركة
  const roles = await db.role.findMany({
    where: { companyId: input.companyId, code: { in: input.roleCodes }, deletedAt: null },
    select: { id: true, code: true },
  });
  if (roles.length !== new Set(input.roleCodes).size)
    throw new ApiError("VAL_001", "أحد الأدوار المطلوبة غير موجود");

  const createdWarehouseId = { value: null as number | null };

  const user = await db.$transaction(async (tx) => {
    // مستودع سيارة آلي للمندوب — يبيع من مخزنه فورًا دون انتظار إعداد
    let repWarehouseId: number | null = null;
    const isRep = roles.some((r) => r.code === "SALES_REP");
    if (isRep && (!input.warehouseIds || input.warehouseIds.length === 0)) {
      const whBranch = branchId ?? (await firstBranchId(input.companyId));
      if (whBranch != null) {
        const code = `REP-${username.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10)}`;
        const existing = await tx.warehouse.findFirst({
          where: { companyId: input.companyId, code, deletedAt: null },
          select: { id: true },
        });
        if (existing) repWarehouseId = existing.id;
        else {
          const wh = await tx.warehouse.create({
            data: {
              companyId: input.companyId,
              branchId: whBranch,
              code,
              name: `مخزن المندوب ${input.fullName.trim()} (سيارة)`,
              type: "REP",
              isMobile: true,
              createdBy: input.actorId,
            },
            select: { id: true },
          });
          repWarehouseId = wh.id;
          createdWarehouseId.value = wh.id;
        }
      }
    }

    // وصول المستودعات: صريح أو آلي من فرع المستخدم
    let warehouseIds = (input.warehouseIds ?? []).filter((n) => Number.isInteger(n));
    if (warehouseIds.length > 0) {
      const owned = await tx.warehouse.findMany({
        where: { id: { in: warehouseIds }, companyId: input.companyId, deletedAt: null },
        select: { id: true },
      });
      if (owned.length !== warehouseIds.length)
        throw new ApiError("VAL_001", "أحد المستودعات غير موجود في شركتك");
    } else if (repWarehouseId != null) {
      warehouseIds = [repWarehouseId];
    } else if (branchId != null) {
      // مدير الفرع/الكاشير: كل مستودعات فرعه تلقائيًا — يعمل دون إعداد يدوي
      const branchWhs = await tx.warehouse.findMany({
        where: { companyId: input.companyId, branchId, deletedAt: null, isActive: true },
        select: { id: true },
      });
      warehouseIds = branchWhs.map((w) => w.id);
    }

    const passwordHash = await hashPassword(input.password);
    const created = await tx.user.create({
      data: {
        companyId: input.companyId,
        branchId,
        username,
        email: input.email?.trim() || null,
        phone: input.phone?.trim() || null,
        fullName: input.fullName.trim(),
        passwordHash,
        createdBy: input.actorId,
      },
      select: { id: true, username: true, fullName: true, branchId: true },
    });

    // الأدوار — الربط بالفرع هو ما يبني نطاق العزل في authenticate()
    const roleBranchId = input.bindToBranch === false ? null : branchId;
    await tx.userRole.createMany({
      data: roles.map((r) => ({
        companyId: input.companyId,
        userId: created.id,
        roleId: r.id,
        branchId: roleBranchId,
      })),
    });

    if (warehouseIds.length > 0) {
      await tx.userWarehouseAccess.createMany({
        data: warehouseIds.map((wid) => ({
          companyId: input.companyId,
          userId: created.id,
          warehouseId: wid,
          canRead: true,
          canOperate: true,
        })),
      });
    }

    return created;
  });

  return {
    id: user.id,
    username: user.username,
    fullName: user.fullName,
    branchId: user.branchId,
    roleCodes: roles.map((r) => r.code),
    warehouseIds: [],
    createdWarehouseId: createdWarehouseId.value,
  };
}

async function firstBranchId(companyId: number): Promise<number | null> {
  const b = await db.branch.findFirst({
    where: { companyId, deletedAt: null, isActive: true },
    orderBy: { id: "asc" },
    select: { id: true },
  });
  return b?.id ?? null;
}
