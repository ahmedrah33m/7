// =====================================================================
// Server-side security chain (MASTER PROMPT rule #5 / API spec §1.3):
//   1. Authentication  → verify JWT, load user + roles + permissions
//   2. Permission      → module.action check
//   3. Company scope   → derived from token, never from body
//   4. Branch/Warehouse scope → scope tables + active branch context
//   (5. Object-level ownership & 6. business rules live in each route)
//
// Multi-Company / Multi-Branch (Phases 1-16): the Session now carries
// the resolved scope sets (companyIds / branchIds / warehouseIds) plus
// the ACTIVE branch of the session (JWT claim `brn`). All queries must
// filter by the effective set — see lib/scope.ts helpers.
// =====================================================================

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { verifyAccessToken, ACCESS_TOKEN_TTL_SEC } from "@/lib/jwt";
import { ApiError } from "@/lib/api";
import { enforceRateLimit } from "@/lib/api";
import { resolveScope, normalizeScopeType, type ScopeType } from "./scope";

export interface Session {
  userId: number;
  companyId: number;
  username: string;
  fullName: string;
  permissions: Set<string>;
  roles: { id: number; code: string; name: string; branchId: number | null }[];
  warehouseIds: number[];
  // ---- Multi-Company / Multi-Branch session scope -----------------------
  scopeType: ScopeType;
  companyIds: number[]; // switchable companies (Company Switcher, Phase 16)
  branchIds: number[]; // granted branches (Branch Switcher, Phase 15)
  activeBranchId: number | null; // JWT `brn` — narrows every query when set
}

/** Step 1 — Authentication. Extracts Bearer token, verifies, loads session. */
export async function authenticate(req: NextRequest): Promise<Session> {
  const header = req.headers.get("authorization") ?? "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  if (!token) throw new ApiError("AUTH_001");

  const claims = await verifyAccessToken(token);
  if (!claims) throw new ApiError("AUTH_002");

  const userId = Number(claims.sub);
  const user = await db.user.findFirst({
    where: { id: userId, deletedAt: null },
    include: {
      roles: { include: { role: { include: { permissions: { include: { permission: true } } } } } },
      warehouseAccess: true,
    },
  });

  if (!user) throw new ApiError("AUTH_002");
  if (!user.isActive) throw new ApiError("AUTH_005");
  if (user.lockedUntil && user.lockedUntil > new Date()) throw new ApiError("AUTH_004");

  // ---- resolve the user's scope sets (company / branch / warehouse) -----
  const scope = await resolveScope({
    id: user.id,
    companyId: user.companyId,
    branchId: user.branchId,
    scopeType: user.scopeType,
  });

  // Active company from the JWT claim (Multi-Company Phase 16):
  // switch-company re-issues the token with the NEW active company id.
  // The claim is honored ONLY when it lies inside the granted set —
  // otherwise (legacy tokens / forged claims) fall back to the home
  // company. Without this, every post-switch query would keep filtering
  // by the OLD company (session.companyId is the tenant filter).
  let companyId = user.companyId;
  const claimCompany = Number(claims.company);
  if (Number.isFinite(claimCompany) && claimCompany > 0 && scope.companyIds.includes(claimCompany)) {
    companyId = claimCompany;
  }

  // حذف الشركات — حاجز فوري: أي جلسة تقع على شركة محذوفة (حذف ناعم) تموت
  // هنا رغم بقاء توكن الوصول حتى دورانه (15 دقيقة). مالك المنصة (GLOBAL)
  // الذي كان يتصفح الشركة المحذوفة يسقط تلقائيًا إلى شركته الرئيسية.
  {
    const activeCompany = await db.company.findFirst({ where: { id: companyId, deletedAt: null }, select: { id: true } });
    if (!activeCompany) throw new ApiError("SCOPE_004", "الشركة غير موجودة أو محذوفة — أعد تسجيل الدخول");
  }

  // ---- Phase 1 §2 — Role Isolation --------------------------------------
  // الجلسة تحمل أدوار الشركة النشطة حصراً. user.roles قد يحتوي أدواراً في
  // شركات أخرى (منح متعدد الشركات) — تسريب أذونات شركة B إلى جلسة شركة A
  // يكسر العزل تماماً. role.companyId هو المرجع (UserRole.companyId منسوخ).
  // استثناء: GLOBAL (مالك المنصة) — أدواره منصية تصلح لكل الشركات الممنوحة،
  // وتصفيتها بالشركة تكسر إدارته للشركات الأخرى.
  // Company scope is derived from the token subject — NEVER from the request.
  const isPlatformGlobal = normalizeScopeType(user.scopeType) === "GLOBAL";
  const permissions = new Set<string>();
  const roles: Session["roles"] = [];
  for (const ur of user.roles) {
    if (!isPlatformGlobal && ur.role.companyId !== companyId) continue;
    roles.push({ id: ur.role.id, code: ur.role.code, name: ur.role.name, branchId: ur.branchId });
    for (const rp of ur.role.permissions) permissions.add(rp.permission.code);
  }

  // Narrow the branch/warehouse sets to the ACTIVE company (tenant
  // isolation — STRICT per-company separation). resolveScope widens
  // GLOBAL/COMPANY scopes across ALL granted companies; regardless of
  // whether the user switched companies or logged in normally, the
  // operating context is ALWAYS a single company: company A must never
  // see company B's branches/warehouses — even with identical names.
  // Company Switching remains available via companyIds + switch-company.
  {
    const [coBranches, coWarehouses] = await Promise.all([
      db.branch.findMany({ where: { companyId, deletedAt: null }, select: { id: true } }),
      db.warehouse.findMany({ where: { companyId, deletedAt: null }, select: { id: true } }),
    ]);
    const branchSet = new Set(coBranches.map((b) => b.id));
    const warehouseSet = new Set(coWarehouses.map((w) => w.id));
    scope.branchIds = scope.branchIds.filter((id) => branchSet.has(id));
    scope.warehouseIds = scope.warehouseIds.filter((id) => warehouseSet.has(id));
  }

  // Active branch from the JWT claim (Multi-Branch session, Phase 14):
  // old tokens (no claim) fall back to: the single granted branch, else null.
  let activeBranchId: number | null = null;
  if (claims.brn != null && scope.branchIds.includes(Number(claims.brn))) {
    activeBranchId = Number(claims.brn);
  } else if (claims.brn === undefined && scope.branchIds.length === 1) {
    activeBranchId = scope.branchIds[0];
  }

  // When a branch context is active, the WAREHOUSE set narrows to that
  // branch's warehouses — every existing warehouse-scope check (SCOPE_002)
  // then automatically enforces the branch context for reads AND writes.
  let effectiveWarehouses = scope.warehouseIds;
  if (activeBranchId != null) {
    const inBranch = await db.warehouse.findMany({
      where: { branchId: activeBranchId, deletedAt: null },
      select: { id: true },
    });
    const allowed = new Set(inBranch.map((w) => w.id));
    effectiveWarehouses = scope.warehouseIds.filter((w) => allowed.has(w));
  }

  return {
    userId,
    companyId, // active company (JWT claim honored — Multi-Company Phase 16)
    username: user.username,
    fullName: user.fullName,
    permissions,
    roles,
    warehouseIds: effectiveWarehouses,
    scopeType: normalizeScopeType(user.scopeType),
    companyIds: scope.companyIds,
    branchIds: scope.branchIds,
    activeBranchId,
  };
}

/** Step 2 — Permission gate (module.action). */
export function requirePermission(session: Session, permission: string): void {
  if (!session.permissions.has(permission)) {
    throw new ApiError("PERM_001", `العملية تتطلب الصلاحية: ${permission}`);
  }
}

/** Step 4 — Warehouse scope gate. */
export function requireWarehouseAccess(session: Session, warehouseId: number, operate = false): void {
  if (!session.warehouseIds.includes(warehouseId)) throw new ApiError("SCOPE_002");
  if (operate) {
    const row = session.warehouseIds; // detailed flags resolved from DB when needed
    void row;
  }
}

/** Convenience: authenticate + permission in one call (steps 1–2). */
export async function guard(req: NextRequest, permission?: string): Promise<Session> {
  enforceRateLimit(`rl:${req.headers.get("x-forwarded-for") ?? "local"}`, 600);
  const session = await authenticate(req);
  enforceRateLimit(`u:${session.userId}`, 120);
  if (permission) requirePermission(session, permission);
  return session;
}

export { ACCESS_TOKEN_TTL_SEC };
