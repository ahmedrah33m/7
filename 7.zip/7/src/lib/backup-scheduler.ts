// =====================================================================
// Scheduled internal backups (§68 — الجدولة gap closure, dev-grade).
// Compresses the SQLite database file into db/backups/auto-<ts>.db.gz
// every BACKUP_INTERVAL_HOURS with retention trimming. Runs inside the
// Next.js instrumentation hook — in the Docker deployment the OS-level
// systemd timer (deploy package) remains the primary scheduled backup;
// this in-app scheduler guarantees a local safety net even without it.
//
// Safety: gzip snapshot only — never writes to the live db file.
// =====================================================================

import { createGzip } from "zlib";
import { pipeline } from "stream/promises";
import { createReadStream, createWriteStream, existsSync, mkdirSync, readdirSync, statSync, unlinkSync } from "fs";
import path from "path";

const BACKUP_DIR = path.join(process.cwd(), "db", "backups");
const RETAIN = 12; // keep last 12 snapshots
const INTERVAL_H = Number(process.env.BACKUP_INTERVAL_HOURS ?? 6);

function dbFilePath(): string {
  const url = process.env.DATABASE_URL ?? "";
  const m = url.match(/file:(.+)/);
  return m ? path.resolve(process.cwd(), m[1].replace(/^file:/, "").trim()) : path.join(process.cwd(), "db", "custom.db");
}

export async function runScheduledBackup(): Promise<{ ok: boolean; file?: string; error?: string }> {
  try {
    const src = dbFilePath();
    if (!existsSync(src)) return { ok: false, error: "db file not found" };
    mkdirSync(BACKUP_DIR, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const dest = path.join(BACKUP_DIR, `auto-${stamp}.db.gz`);
    await pipeline(createReadStream(src), createGzip({ level: 6 }), createWriteStream(dest));

    // retention: newest first, delete beyond RETAIN
    const files = readdirSync(BACKUP_DIR)
      .filter((f) => f.startsWith("auto-") && f.endsWith(".db.gz"))
      .sort()
      .reverse();
    for (const f of files.slice(RETAIN)) {
      try {
        unlinkSync(path.join(BACKUP_DIR, f));
      } catch {
        /* already gone */
      }
    }
    const size = statSync(dest).size;
    console.log(`[backup] scheduled snapshot ok: ${path.basename(dest)} (${Math.round(size / 1024)}KB)`);
    return { ok: true, file: dest };
  } catch (e) {
    return { ok: false, error: (e as Error).message.slice(0, 160) };
  }
}

let started = false;
export function startBackupScheduler(): void {
  if (started) return; // guard dev HMR / multi-register
  started = true;
  const run = () => runScheduledBackup().catch(() => {});
  setTimeout(run, 45_000).unref?.(); // first snapshot shortly after boot
  setInterval(run, INTERVAL_H * 3600_000).unref?.();
  console.log(`[backup] scheduler active — every ${INTERVAL_H}h, retention ${RETAIN}`);
}
