// =====================================================================
// Phase 2 §4-§6 — طبقة التسعير المهيكلة (ProductPrice):
//   · كل سعر: amount + currency + unit (PIECE|PACKAGE) + priceType
//     (SALE|COST|WHOLESALE|RETAIL|SPECIAL|PROMOTIONAL) + صلاحية زمنية.
//   · القيمة تُخزَّن كما دخلت: 26 USD / PACKAGE تبقى 26 ولا تُحوَّل إلى
//     IQD عند الحفظ ثم تُعامل لاحقاً كأنها USD (منع جذر مشكلة الشامبو).
//   · الأعمدة المسطحة على products (sale_price/cost_price/pack_sale_price)
//     هي إسقاط IQD للتوافق مع المخزون/الأرباح/التقييم — يُحدَّث دائماً
//     عبر هذه الوحدة داخل نفس المعاملة، ولا يُقرأ كمصدر حقيقة عملوي.
//   · تغيير سعر يُغلق الصف السابق (effectiveTo=now) ويفتح صفّاً جديداً —
//     تاريخ أسعار قابل للتدقيق، والفواتير القديمة لا تتأثر (§8).
// =====================================================================

import { ApiError } from "./api";
import { db } from "./db";
import { dec, num } from "./decimal";
import {
  Currency, toIqd, round6, roundMoney,
  getCompanyUsdRate, assertExchangeRate,
} from "./currency";

export const PRICE_TYPES = ["SALE", "COST", "WHOLESALE", "RETAIL", "SPECIAL", "PROMOTIONAL"] as const;
export const PRICE_UNITS = ["PIECE", "PACKAGE"] as const;
export type PriceType = (typeof PRICE_TYPES)[number];
export type PriceUnit = (typeof PRICE_UNITS)[number];

/* eslint-disable @typescript-eslint/no-explicit-any */
interface PriceTx {
  productPrice: {
    findMany(args?: any): Promise<any[]>;
    findFirst(args?: any): Promise<any | null>;
    create(args: any): Promise<any>;
    update(args: any): Promise<any>;
    updateMany(args: any): Promise<any>;
  };
  product: { update(args: any): Promise<any> };
}

/** عميل Prisma كامل أو معاملة — كلاهما يملك productPrice/product. */
type DbLike = PriceTx;

// ---------------------------------------------------------------------
// Input shape (API)
// ---------------------------------------------------------------------
export interface PriceInput {
  amount: number;
  currency: Currency;
  /** وحدة السعر: PIECE (حبة/علبة أساس) أو PACKAGE (كرتون) */
  unit: PriceUnit;
  priceType?: PriceType;
}

/** حقول الأسعار كما تصل من POST/PATCH المنتج (snake_case متوافق مع النظام). */
export interface ProductPricingInput {
  cost_price: number;
  sale_price: number;
  pack_sale_price?: number | null;
  cost_currency?: Currency;
  sale_currency?: Currency;
  pack_sale_currency?: Currency;
  /** سعر الصرف المستخدم لتحديث الإسقاط بالدينار — إلزامي مع أي سعر USD */
  exchange_rate?: number | null;
}

/** ناتج التزامن: الأسعار المهيكلة + الإسقاط بالدينار لأعمدة المنتج. */
export interface PricingSyncResult {
  rows: { priceType: PriceType; unit: PriceUnit; currency: Currency; amount: number }[];
  projection: {
    costPriceIqd: number;
    salePriceIqd: number;
    packSalePriceIqd: number | null;
    exchangeRateUsed: number | null;
  };
}

/**
 * اشتقاق سعر الحبة من سعر الكرتونة — §9: 26 USD / 11 = 2.363636.
 * يعيد null حين لا يمكن الاشتقاق (لا كمية تعبئة).
 */
export function derivePieceFromPackage(packageAmount: number, packQty: number | null | undefined): number | null {
  if (!packageAmount || !packQty || packQty <= 1) return null;
  return round6(packageAmount / packQty);
}

/**
 * §6 — يحفظ أسعار المنتج بعملتها كما دخلت ويحدّث الإسقاط بالدينار.
 * يُستدعى داخل معاملة POST/PATCH المنتج. إلزامي: exchange_rate مع أي سعر USD.
 */
export async function syncProductPrices(
  tx: DbLike,
  args: {
    companyId: number;
    productId: number;
    input: ProductPricingInput;
    packQty: number | null; // بعد validatePackaging
    userId?: number | null;
  }
): Promise<PricingSyncResult> {
  const { companyId, productId, input, packQty, userId } = args;

  const costCurrency = input.cost_currency ?? "IQD";
  const saleCurrency = input.sale_currency ?? "IQD";
  const packCurrency = input.pack_sale_currency ?? "IQD";
  const hasPack = !!packQty && packQty > 1;

  // ---- أي سعر بالدولار يتطلب سعر صرف صريحًا (لا تخمين — §7/DoD)
  const needsRate =
    (costCurrency === "USD" && dec(input.cost_price).isPositive()) ||
    (saleCurrency === "USD" && dec(input.sale_price).isPositive()) ||
    (packCurrency === "USD" && dec(input.pack_sale_price ?? 0).isPositive());
  let rate: number | null = null;
  if (needsRate) {
    rate = input.exchange_rate != null ? assertExchangeRate(input.exchange_rate) : await getCompanyUsdRate(companyId);
    if (rate == null) {
      throw new ApiError("PRD_006", "سعر الصرف مطلوب للأسعار بالدولار — حدد سعر الصرف (د.ع لكل $1) أولًا", [
        { field: "exchange_rate", message: "أدخل سعر الصرف الحالي أو اضبطه في إعدادات الشركة" },
      ]);
    }
  }

  // ---- الصفوف المهيكلة كما دخلت (لا تحويل عند الحفظ — §6)
  const wanted: { priceType: PriceType; unit: PriceUnit; currency: Currency; amount: number }[] = [];
  if (input.cost_price > 0 || input.cost_currency === "USD") {
    wanted.push({ priceType: "COST", unit: "PIECE", currency: costCurrency, amount: input.cost_price });
  }
  wanted.push({ priceType: "SALE", unit: "PIECE", currency: saleCurrency, amount: input.sale_price });
  // إصلاح «كراتين بلا سعر»: بلا سعر كرتونة موجب لا يُنشأ صف PACKAGE إطلاقًا —
  // صف صفر يظلّل الاشتقاق من سعر الحبة في الفواتير (0 ?? البديل يبقى 0)
  if (hasPack && (input.pack_sale_price ?? 0) > 0) {
    wanted.push({ priceType: "SALE", unit: "PACKAGE", currency: packCurrency, amount: input.pack_sale_price! });
  }

  const now = new Date();
  const existingRows = await tx.productPrice.findMany({
    where: { companyId, productId, isActive: true, priceType: { in: ["SALE", "COST"] } },
  });

  for (const w of wanted) {
    const match = existingRows.find(
      (r) => r.priceType === w.priceType && r.unit === w.unit && r.isActive && r.currency === w.currency
    );
    const sameValue = match && dec(match.amount).minus(w.amount).abs().lt("1e-9");
    if (match && sameValue) continue; // لم يتغير — لا دورة تاريخ

    if (match) {
      // إغلاق الصف القديم + صف جديد = تاريخ أسعار (§4 effectiveFrom/To)
      await tx.productPrice.update({
        where: { id: match.id },
        data: { isActive: false, effectiveTo: now, updatedBy: userId ?? null },
      });
    }
    // صف بنفس النوع/الوحدة لكن عملة مختلفة؟ يُغلق أيضاً (العملة جزء من الهوية الفعالة)
    await tx.productPrice.updateMany({
      where: { companyId, productId, priceType: w.priceType, unit: w.unit, isActive: true },
      data: { isActive: false, effectiveTo: now },
    });
    await tx.productPrice.create({
      data: {
        companyId,
        productId,
        priceType: w.priceType,
        unit: w.unit,
        currency: w.currency,
        amount: w.amount,
        effectiveFrom: now,
        createdBy: userId ?? null,
        updatedBy: userId ?? null,
      },
    });
  }

  // ---- إزالة أسعار العبوة المهيكلة عند حذف التعبئة (PATCH أزال pack)
  if (!hasPack) {
    await tx.productPrice.updateMany({
      where: { companyId, productId, unit: "PACKAGE", isActive: true },
      data: { isActive: false, effectiveTo: now },
    });
  }

  // ---- الإسقاط بالدينار (عملة الأساس) — للمخزون والأرباح والتقارير
  const costIqd = roundMoney(toIqd(input.cost_price, costCurrency, rate ?? 1));
  const saleIqd = roundMoney(toIqd(input.sale_price, saleCurrency, rate ?? 1));
  const packIqd =
    hasPack && input.pack_sale_price != null
      ? roundMoney(toIqd(input.pack_sale_price, packCurrency, rate ?? 1))
      : null;

  await tx.product.update({
    where: { id: productId },
    data: { costPrice: costIqd, salePrice: saleIqd, ...(hasPack ? { packSalePrice: packIqd } : {}) },
  });

  return {
    rows: wanted,
    projection: { costPriceIqd: costIqd, salePriceIqd: saleIqd, packSalePriceIqd: packIqd, exchangeRateUsed: rate },
  };
}

// ---------------------------------------------------------------------
// Effective prices — قراءة الأسعار السارية لحساب الفواتير (§5)
// ---------------------------------------------------------------------
export interface EffectivePrice {
  priceType: PriceType;
  unit: PriceUnit;
  currency: Currency;
  amount: number;
}

/** الأسعار السارية لمنتجات الشركة (isActive + نافذة الصلاحية). */
export async function getEffectivePrices(companyId: number, productIds: number[]): Promise<Map<number, EffectivePrice[]>> {
  const map = new Map<number, EffectivePrice[]>();
  if (!productIds.length) return map;
  const now = new Date();
  const rows = await db.productPrice.findMany({
    where: {
      companyId,
      productId: { in: productIds },
      isActive: true,
      effectiveFrom: { lte: now },
      OR: [{ effectiveTo: null }, { effectiveTo: { gt: now } }],
    },
    orderBy: { effectiveFrom: "desc" },
  });
  for (const r of rows) {
    const list = map.get(r.productId) ?? [];
    // أول صف لكل (نوع، وحدة) = الأحدث بفضل الترتيب
    if (!list.some((p) => p.priceType === r.priceType && p.unit === r.unit)) {
      list.push({
        priceType: r.priceType as PriceType,
        unit: r.unit as PriceUnit,
        currency: asCurrency(r.currency),
        amount: num(dec(r.amount)),
      });
    }
    map.set(r.productId, list);
  }
  return map;
}

function asCurrency(v: string): Currency {
  return v === "USD" ? "USD" : "IQD";
}

// ---------------------------------------------------------------------
// RP1 §5 — مصدر الحقيقة: ProductPrice أولًا، ثم سقوط Legacy موثّق ومحذّر
// ---------------------------------------------------------------------

/** RP1 §5 — تحذير تطويري عند استخدام عمود products القديم بدل ProductPrice (لا يظهر في الإنتاج). */
export function legacyFallbackWarn(scope: string, companyId: number, productId: number, name?: string): void {
  if (process.env.NODE_ENV !== "production") {
    console.warn(
      `[RP1][legacy-price-fallback] ${scope} company=${companyId} product=${productId}${name ? ` «${name}»` : ""} — لا صف SALE نشط في ProductPrice؛ استُخدم العمود القديم (إسقاط IQD)`
    );
  }
}

export interface DefaultPricesResult {
  pieceIqd: number;
  packageIqd: number | null;
  sourceCurrency: Currency;
  rateUsed: number | null;
  usedLegacyFallback: boolean;
}

/**
 * RP1 §5 — الأسعار الافتراضية من صفوف ProductPrice (بعملتها كما خُزّنت) مع
 * سقوط Legacy موثّق: عمود products.salePrice/packSalePrice (إسقاط IQD).
 * أي صف USD يتطلب سعر صرف معروفًا — وإلا رفض صريح PRD_006 (لا تخمين).
 */
export function defaultPricesFromRows(
  scope: string,
  companyId: number,
  rows: EffectivePrice[],
  product: { id: number; name?: string },
  legacySaleIqd: number,
  legacyPackIqd: number | null,
  packQty: number | null,
  rate: number | null
): DefaultPricesResult {
  const salePiece = rows.find((r) => r.priceType === "SALE" && r.unit === "PIECE");
  const salePack = rows.find((r) => r.priceType === "SALE" && r.unit === "PACKAGE");

  const usdRows = [salePiece, salePack].filter((r) => r && r.currency === "USD");
  let rateUsed: number | null = null;
  if (usdRows.length) {
    if (rate == null || rate <= 0) {
      throw new ApiError(
        "PRD_006",
        "سعر هذا المنتج مخزّن بالدولار — حدد سعر الصرف (د.ع لكل $1) في الفاتورة أو إعدادات الشركة قبل البيع",
        [{ field: "exchange_rate", message: "سعر الصرف مطلوب لتحويل أسعار الدولار" }]
      );
    }
    rateUsed = rate;
  }

  let pieceIqd: number;
  let usedLegacy = false;
  if (salePiece) {
    pieceIqd = roundMoney(toIqd(salePiece.amount, salePiece.currency, rateUsed ?? 1));
  } else {
    usedLegacy = true;
    legacyFallbackWarn(scope, companyId, product.id, product.name);
    pieceIqd = roundMoney(legacySaleIqd);
  }

  let packageIqd: number | null = null;
  if (packQty && packQty > 1) {
    if (salePack) {
      packageIqd = roundMoney(toIqd(salePack.amount, salePack.currency, rateUsed ?? 1));
    } else if (legacyPackIqd != null) {
      legacyFallbackWarn(`${scope}:package`, companyId, product.id, product.name);
      packageIqd = roundMoney(legacyPackIqd);
    } else {
      packageIqd = roundMoney(pieceIqd * packQty);
    }
  }

  const sourceCurrency = salePiece?.currency ?? salePack?.currency ?? "IQD";
  return { pieceIqd, packageIqd, sourceCurrency, rateUsed, usedLegacyFallback: usedLegacy };
}

export interface ResolvedSalePrices {
  /** سعر الحبة بالدينار — جاهز لحساب الفاتورة */
  pieceIqd: number;
  /** سعر الكرتونة بالدينار (null للمنتج غير المعبأ) */
  packageIqd: number | null;
  /** عملة السعر المصدر التي جاء منها السعر (لقطة §8) */
  sourceCurrency: Currency;
  /** سعر الصرف المستخدم في التحويل إن كان المصدر USD (لقطة §8) */
  rateUsed: number | null;
}

/**
 * حل أسعار البيع الافتراضية لفاتورة — يقرأ الطبقة المهيكلة أولًا ثم يسقط
 * إلى أعمدة المنتج القديمة (IQD) مع تحذير تطويري (RP1 §5). أي سعر USD
 * يُحوَّل بالسعر الممرر، وإلا بسعر صرف الشركة، وإلا يُرفض الطلب (لا تخمين).
 */
export async function resolveDefaultSalePrices(
  companyId: number,
  product: { id: number; salePrice: number; packSalePrice: number | null },
  packQty: number | null,
  preferredRate?: number | null
): Promise<ResolvedSalePrices> {
  const eff = await getEffectivePrices(companyId, [product.id]);
  const rows = eff.get(product.id) ?? [];
  const hasUsd = rows.some((r) => r.priceType === "SALE" && r.currency === "USD");
  const rate = hasUsd
    ? preferredRate && preferredRate > 0
      ? preferredRate
      : await getCompanyUsdRate(companyId)
    : (preferredRate ?? null);
  const r = defaultPricesFromRows(
    "invoice-default",
    companyId,
    rows,
    { id: product.id },
    Number(product.salePrice) || 0,
    product.packSalePrice != null ? Number(product.packSalePrice) : null,
    packQty,
    rate
  );
  return { pieceIqd: r.pieceIqd, packageIqd: r.packageIqd, sourceCurrency: r.sourceCurrency, rateUsed: r.rateUsed };
}
