// =====================================================================
// Subscription engine — لوحة المالك: تحديد مدة كل شركة (اشتراك) +
// تعليق يدوي + فرض الحالة على الدخول/التجديد + إنهاء جلسات شركة كاملة.
//
// Model (Company):
//   subscriptionEndsAt  DateTime?  — null = مفتوح بلا حد؛ تاريخ ماضٍ = منتهٍ
//   isSuspended         Boolean    — تعليق يدوي فوري (أقوى من الانتهاء)
//   subscriptionNote    String?    — ملاحظة المالك (باقة/جهة دفع...)
//
// Enforcement:
//   · login  → non-GLOBAL users of an expired/suspended company blocked
//     (GLOBAL = مالكو المنصة يديرون حتى الشركات المنتهية — bypass)
//   · refresh → same check: الجلسات الطويلة تموت عند الانتهاء حتى بدون
//     إعادة دخول (access token 15m + refresh 7d — الفحص هنا يقطع الأخير)
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";

export type SubscriptionStatus =
  | "OPEN"            // بلا حد زمني
  | "ACTIVE"          // ساري (> 14 يوم)
  | "EXPIRING_SOON"   // ساري لكن ≤ 14 يوم (تحذير)
  | "EXPIRED"         // منتهٍ — دخول الشركة ممنوع
  | "SUSPENDED";      // معلّقة يدويًا — دخول الشركة ممنوع

export const EXPIRING_SOON_DAYS = 14;

export interface SubscriptionInfo {
  ends_at: string | null;
  days_left: number | null;
  is_suspended: boolean;
  status: SubscriptionStatus;
  note: string | null;
}

export function subscriptionInfo(
  endsAt: Date | null,
  isSuspended: boolean,
  note: string | null = null
): SubscriptionInfo {
  const now = new Date();
  if (isSuspended) {
    return { ends_at: endsAt?.toISOString() ?? null, days_left: null, is_suspended: true, status: "SUSPENDED", note };
  }
  if (!endsAt) {
    return { ends_at: null, days_left: null, is_suspended: false, status: "OPEN", note };
  }
  const msLeft = endsAt.getTime() - now.getTime();
  const daysLeft = Math.ceil(msLeft / 86_400_000);
  const status: SubscriptionStatus = daysLeft <= 0 ? "EXPIRED" : daysLeft <= EXPIRING_SOON_DAYS ? "EXPIRING_SOON" : "ACTIVE";
  return { ends_at: endsAt.toISOString(), days_left: daysLeft, is_suspended: false, status, note };
}

/** يمنع الدخول/التجديد لشركة محذوفة أو منتهية أو معلّقة (غير GLOBAL). */
export async function assertCompanyActive(companyId: number): Promise<void> {
  const company = await db.company.findFirst({
    where: { id: companyId, deletedAt: null },
    select: { id: true, name: true, subscriptionEndsAt: true, isSuspended: true },
  });
  if (!company) {
    // الشركة محذوفة (حذف ناعم) — رفض دخول موحد بلا كشف تفاصيل
    throw new ApiError("AUTH_003", "تعذر تسجيل الدخول — تحقق من البيانات أو راجع مالك النظام");
  }
  const info = subscriptionInfo(company.subscriptionEndsAt, company.isSuspended);
  if (info.status === "SUSPENDED") {
    throw new ApiError("SUB_002", `الشركة «${company.name}» معلّقة مؤقتًا — راجع مالك النظام`);
  }
  if (info.status === "EXPIRED") {
    const ended = info.ends_at ? new Intl.DateTimeFormat("ar-IQ", { dateStyle: "medium" }).format(new Date(info.ends_at)) : "";
    throw new ApiError("SUB_001", `انتهت مدة اشتراك الشركة «${company.name}»${ended ? ` بتاريخ ${ended}` : ""} — راجع مالك النظام للتجديد`);
  }
}

/** إنهاء كل جلسات شركة (كل refresh tokens لمستخدميها غير المستهلكة). */
export async function revokeCompanySessions(companyId: number): Promise<number> {
  const users = await db.user.findMany({
    where: { companyId, deletedAt: null },
    select: { id: true },
  });
  if (!users.length) return 0;
  const res = await db.refreshToken.updateMany({
    where: { userId: { in: users.map((u) => u.id) }, revokedAt: null },
    data: { revokedAt: new Date() },
  });
  return res.count;
}
