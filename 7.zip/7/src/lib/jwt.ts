// =====================================================================
// JWT access tokens (15 min) — jose HS256.
// Refresh tokens are opaque random strings, sha256-hashed at rest and
// rotated on every use (see lib/refresh.ts).
// =====================================================================

import { SignJWT, jwtVerify, type JWTPayload } from "jose";

export const ACCESS_TOKEN_TTL_SEC = 15 * 60; // 15 minutes
export const REFRESH_TOKEN_TTL_SEC = 7 * 24 * 60 * 60; // 7 days

const ACCESS_SECRET = new TextEncoder().encode(
  process.env.JWT_ACCESS_SECRET ?? "dev-access-secret-change-me"
);

export interface AccessClaims extends JWTPayload {
  sub: string; // user id (decimal string)
  company: number;
  username: string;
  brn?: number | null; // active branch (Multi-Branch session scope)
  scope?: string; // scope_type snapshot for observability
  typ: "access";
  jti: string;
}

/** Sign a 15-minute access token (with optional active-branch context). */
export async function signAccessToken(user: {
  id: number;
  companyId: number;
  username: string;
  activeBranchId?: number | null;
  scopeType?: string;
}): Promise<{ token: string; expiresIn: number }> {
  const token = await new SignJWT({
    company: user.companyId,
    username: user.username,
    brn: user.activeBranchId ?? null,
    scope: user.scopeType ?? "BRANCH",
    typ: "access",
  })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(String(user.id))
    .setJti(crypto.randomUUID())
    .setIssuedAt()
    .setExpirationTime(`${ACCESS_TOKEN_TTL_SEC}s`)
    .sign(ACCESS_SECRET);

  return { token, expiresIn: ACCESS_TOKEN_TTL_SEC };
}

/** Verify an access token; returns claims or null. */
export async function verifyAccessToken(token: string): Promise<AccessClaims | null> {
  try {
    const { payload } = await jwtVerify(token, ACCESS_SECRET, { algorithms: ["HS256"] });
    if (payload.typ !== "access") return null;
    return payload as AccessClaims;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------
// B2B portal tokens (Phase 8) — customer-scoped, 12h, typ:"b2b".
// Claims carry the CUSTOMER id (not a user id) — the portal can never
// be escalated into a staff session.
// ---------------------------------------------------------------------
export const B2B_TOKEN_TTL_SEC = 12 * 60 * 60; // 12 hours

export interface B2BClaims extends JWTPayload {
  cid: number; // customer id
  company: number;
  code: string;
  typ: "b2b";
  jti: string;
}

export async function signB2BToken(customer: {
  id: number;
  companyId: number;
  code: string;
}): Promise<{ token: string; expiresIn: number }> {
  const token = await new SignJWT({ cid: customer.id, company: customer.companyId, code: customer.code, typ: "b2b" })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(String(customer.id))
    .setJti(crypto.randomUUID())
    .setIssuedAt()
    .setExpirationTime(`${B2B_TOKEN_TTL_SEC}s`)
    .sign(ACCESS_SECRET);
  return { token, expiresIn: B2B_TOKEN_TTL_SEC };
}

export async function verifyB2BToken(token: string): Promise<B2BClaims | null> {
  try {
    const { payload } = await jwtVerify(token, ACCESS_SECRET, { algorithms: ["HS256"] });
    if (payload.typ !== "b2b") return null;
    return payload as B2BClaims;
  } catch {
    return null;
  }
}

/** sha256-hex of an opaque refresh token (stored at rest — never the raw token). */
export async function sha256Hex(input: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** Cryptographically-strong opaque refresh token. */
export function generateRefreshToken(): string {
  const bytes = new Uint8Array(48);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}
