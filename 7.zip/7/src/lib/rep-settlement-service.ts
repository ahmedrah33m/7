// =====================================================================
// RepSettlement service — Phase 4-7 (المرحلة 39 من MASTER PROMPT)
//
// RepSettlement = تسليم المندوب (rep cash → branch cash):
//   المندوب يحصّل من العملاء (ReceiptVoucher → صندوق المندوب REP)
//   ثم يسلم النقد لصندوق الفرع بتسليم مستقل REP-STL-2026-000001
//
// التدفق الذري داخل معاملة واحدة:
//   1. التحقق من المندوب + الصندوقين (REP source, MAIN/BRANCH target)
//   2. قراءة collectedAmount من صندوق المندوب منذ آخر تسليم
//      (لو لم يُمرر يدويًا — يحسب تلقائيًا من CashTransaction.category=COLLECTION)
//   3. إنشاء RepSettlement record
//   4. إنشاء CashTransfer موازٍ (حوالة بين الصندوقين) — cashbox OUT من REP، IN إلى BRANCH
//   5. تسجيل تدقيق
//
// Idempotency: @@unique([companyId, idempotencyKey])
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { nextDocumentNumber } from "./document-number";
import { writeAudit, auditData } from "./audit";
import { Decimal, dec, moneyR, num, sumOf } from "./decimal";
import type { Prisma } from "@prisma/client";

export interface RepSettlementActor {
  userId: number;
  companyId: number;
  branchId?: number | null;
  ip?: string;
  userAgent?: string;
}

export interface CreateRepSettlementInput {
  repUserId: number;
  fromCashboxId: number; // REP cashbox
  toCashboxId: number; // BRANCH/MAIN cashbox
  branchId: number;
  collectedAmount?: number | null; // if null/undefined — auto-compute from cashbox txs since last settlement
  deliveredAmount?: number | null; // if null — equals collectedAmount (perfect delivery)
  differenceReason?: string | null;
  receivedBy?: string | null;
  receivedById?: number | null;
  signatureData?: string | null;
  description?: string | null;
  notes?: string | null;
  idempotencyKey?: string | null;
  settlementDate?: Date | null;
}

/**
 * Create a rep settlement — atomic flow:
 *   RepSettlement + CashTransfer (linked) + audit
 *
 * Returns the settlement record with linked transfer number.
 */
export async function createRepSettlement(
  actor: RepSettlementActor,
  input: CreateRepSettlementInput
) {
  const companyId = actor.companyId;
  const settlementDate = input.settlementDate ?? new Date();

  // ---- 1. Idempotency check -----------------------------------------------
  if (input.idempotencyKey) {
    const existing = await db.repSettlement.findUnique({
      where: { companyId_idempotencyKey: { companyId, idempotencyKey: input.idempotencyKey } },
    });
    if (existing) return { id: existing.id, number: existing.number, duplicate: true };
  }

  // ---- 2. Validate rep + cashboxes ----------------------------------------
  const rep = await db.user.findFirst({
    where: { id: input.repUserId, companyId, deletedAt: null },
    select: { id: true, fullName: true },
  });
  if (!rep) throw new ApiError("VAL_003", "المندوب غير موجود");

  const fromBox = await db.cashbox.findFirst({
    where: {
      id: input.fromCashboxId,
      companyId,
      deletedAt: null,
      type: { in: ["REP", "CUSTOM"] },
    },
    include: { branch: { select: { id: true, name: true } } },
  });
  if (!fromBox) throw new ApiError("CASHBOX_001", "صندوق المندوب غير موجود أو ليس نوع REP/CUSTOM");

  const toBox = await db.cashbox.findFirst({
    where: {
      id: input.toCashboxId,
      companyId,
      deletedAt: null,
      type: { in: ["MAIN", "BRANCH"] },
    },
    include: { branch: { select: { id: true, name: true } } },
  });
  if (!toBox) throw new ApiError("CASHBOX_001", "صندوق الفرع غير موجود أو ليس نوع MAIN/BRANCH");

  if (fromBox.id === toBox.id) {
    throw new ApiError("VAL_001", "لا يمكن التسليم لنفس الصندوق");
  }

  // ---- 3. Resolve collectedAmount (auto or manual) ------------------------
  let collectedAmount: Decimal;
  if (input.collectedAmount != null && input.collectedAmount > 0) {
    collectedAmount = moneyR(dec(input.collectedAmount));
  } else {
    // Auto-compute: Σ COLLECTION cash transactions since last settlement (or cashbox creation)
    const lastSettlement = await db.repSettlement.findFirst({
      where: { fromCashboxId: fromBox.id, status: "POSTED" },
      orderBy: { settlementDate: "desc" },
    });
    const txs = await db.cashTransaction.findMany({
      where: {
        cashboxId: fromBox.id,
        direction: "IN",
        category: "COLLECTION",
        isReversed: false,
        createdAt: { gt: lastSettlement?.settlementDate ?? new Date(0) },
      },
      select: { amount: true },
    });
    collectedAmount = moneyR(sumOf(txs, (t) => dec(t.amount)));
    if (!collectedAmount.isPositive()) {
      throw new ApiError("VAL_001", "لا يوجد مبلغ محصّل لتسليمه منذ آخر تسوية");
    }
  }

  const deliveredAmount = moneyR(dec(input.deliveredAmount ?? collectedAmount));
  const difference = moneyR(collectedAmount.minus(deliveredAmount));

  // Validate source cashbox has enough balance to deliver
  if (dec(fromBox.balance).lt(deliveredAmount)) {
    throw new ApiError(
      "CASHBOX_003",
      `رصيد صندوق المندوب (${num(fromBox.balance)}) لا يكفي للتسليم (${num(deliveredAmount)})`
    );
  }

  // ---- 4. Atomic transaction: settlement + cash transfer ------------------
  const result = await db.$transaction(async (tx) => {
    const settlementNumber = await nextDocumentNumber(tx, companyId, "REP_SETTLEMENT");

    // Create the RepSettlement record first
    const settlement = await tx.repSettlement.create({
      data: {
        companyId,
        branchId: input.branchId,
        number: settlementNumber,
        settlementDate,
        repUserId: rep.id,
        fromCashboxId: fromBox.id,
        toCashboxId: toBox.id,
        cashTransferId: null, // will link after creating transfer
        collectedAmount,
        deliveredAmount,
        difference,
        differenceReason: input.differenceReason ?? (difference.isZero() ? null : "غير مُبرر"),
        receivedBy: input.receivedBy ?? null,
        receivedById: input.receivedById ?? null,
        signatureData: input.signatureData ?? null,
        status: "POSTED",
        idempotencyKey: input.idempotencyKey ?? null,
        description: input.description,
        notes: input.notes,
        createdById: actor.userId,
      },
    });

    // Create the linked CashTransfer (REP cashbox → BRANCH cashbox)
    // This invokes the existing createCashTransfer logic at a low level
    // to avoid circular imports — we replicate the essential parts here.
    const transferNumber = await nextDocumentNumber(tx, companyId, "CASH_TRANSFER");
    const transfer = await tx.cashTransfer.create({
      data: {
        companyId,
        branchId: input.branchId,
        number: transferNumber,
        transferDate: settlementDate,
        fromCashboxId: fromBox.id,
        toCashboxId: toBox.id,
        amount: deliveredAmount,
        currency: fromBox.currency ?? "IQD",
        fromCurrency: fromBox.currency ?? null,
        toCurrency: toBox.currency ?? null,
        status: "POSTED",
        referenceNumber: settlementNumber,
        description: `تسليم مندوب ${rep.fullName} — ${settlementNumber}`,
        idempotencyKey: input.idempotencyKey ? `${input.idempotencyKey}-TRF` : null,
        createdById: actor.userId,
      },
    });

    // Link settlement → transfer
    await tx.repSettlement.update({
      where: { id: settlement.id },
      data: { cashTransferId: transfer.id },
    });

    // Post the two cash transactions (OUT from REP, IN to BRANCH)
    const repBalanceAfter = moneyR(dec(fromBox.balance).minus(deliveredAmount));
    const branchBalanceAfter = moneyR(dec(toBox.balance).plus(deliveredAmount));

    await tx.cashTransaction.create({
      data: {
        companyId,
        cashboxId: fromBox.id,
        direction: "OUT",
        category: "OTHER",
        amount: deliveredAmount,
        balanceAfter: repBalanceAfter,
        balanceBefore: fromBox.balance,
        transactionType: "TRANSFER",
        transactionNumber: transferNumber,
        partyType: null,
        cashTransferId: transfer.id,
        referenceNumber: settlementNumber,
        note: `تسليم مندوب ${rep.fullName} إلى ${toBox.name} — ${settlementNumber}`,
        createdBy: actor.userId,
        idempotencyKey: input.idempotencyKey ? `${input.idempotencyKey}-OUT` : null,
      },
    });

    await tx.cashTransaction.create({
      data: {
        companyId,
        cashboxId: toBox.id,
        direction: "IN",
        category: "OTHER",
        amount: deliveredAmount,
        balanceAfter: branchBalanceAfter,
        balanceBefore: toBox.balance,
        transactionType: "TRANSFER",
        transactionNumber: transferNumber,
        partyType: null,
        cashTransferId: transfer.id,
        referenceNumber: settlementNumber,
        note: `استلام تسليم مندوب ${rep.fullName} — ${settlementNumber}`,
        createdBy: actor.userId,
        idempotencyKey: input.idempotencyKey ? `${input.idempotencyKey}-IN` : null,
      },
    });

    // Update both cashbox balances
    await tx.cashbox.update({
      where: { id: fromBox.id },
      data: { balance: repBalanceAfter },
    });
    await tx.cashbox.update({
      where: { id: toBox.id },
      data: { balance: branchBalanceAfter },
    });

    // Audit log
    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "CREATE",
          module: "finance",
          entityType: "rep_settlement",
          entityId: settlement.id,
          newValues: {
            number: settlementNumber,
            transfer: transferNumber,
            rep: rep.fullName,
            fromCashbox: fromBox.name,
            toCashbox: toBox.name,
            collected: num(collectedAmount),
            delivered: num(deliveredAmount),
            difference: num(difference),
          },
        }
      ),
    });

    return { settlement, transfer, repBalanceAfter, branchBalanceAfter };
  });

  return {
    id: result.settlement.id,
    number: result.settlement.number,
    transfer_number: result.transfer.number,
    rep_user: rep.fullName,
    from_cashbox: fromBox.name,
    to_cashbox: toBox.name,
    collected_amount: num(collectedAmount),
    delivered_amount: num(deliveredAmount),
    difference: num(difference),
    rep_balance_after: num(result.repBalanceAfter),
    branch_balance_after: num(result.branchBalanceAfter),
  };
}

/**
 * Cancel a rep settlement — reverse the cash transfer + restore balances.
 * Keeps the audit chain: marks settlement CANCELLED + linked transfer CANCELLED
 * + reversal CashTransaction rows.
 */
export async function cancelRepSettlement(
  actor: RepSettlementActor,
  settlementId: number,
  reason: string
) {
  const companyId = actor.companyId;

  const settlement = await db.repSettlement.findFirst({
    where: { id: settlementId, companyId, deletedAt: null },
  });
  if (!settlement) throw new ApiError("VAL_003", "التسليم غير موجود");
  if (settlement.status === "CANCELLED") throw new ApiError("VAL_001", "التسليم ملغى مسبقًا");

  const deliveredAmount = moneyR(dec(settlement.deliveredAmount));

  await db.$transaction(async (tx) => {
    // Mark settlement CANCELLED
    await tx.repSettlement.update({
      where: { id: settlement.id },
      data: {
        status: "CANCELLED",
        cancelReason: reason,
        cancelledAt: new Date(),
        cancelledById: actor.userId,
      },
    });

    // Mark linked transfer CANCELLED (if exists)
    if (settlement.cashTransferId) {
      await tx.cashTransfer.update({
        where: { id: settlement.cashTransferId },
        data: {
          status: "CANCELLED",
          cancelReason: `عكس تسليم مندوب ${settlement.number}: ${reason}`,
          cancelledAt: new Date(),
          cancelledById: actor.userId,
        },
      });
    }

    // Reversal cash transactions: IN back to REP cashbox, OUT from BRANCH cashbox
    const fromBox = await tx.cashbox.findUnique({ where: { id: settlement.fromCashboxId } });
    const toBox = await tx.cashbox.findUnique({ where: { id: settlement.toCashboxId } });
    if (!fromBox || !toBox) throw new ApiError("CASHBOX_001", "صندوق مفقود");

    const repBalanceAfter = moneyR(dec(fromBox.balance).plus(deliveredAmount));
    const branchBalanceAfter = moneyR(dec(toBox.balance).minus(deliveredAmount));

    await tx.cashTransaction.create({
      data: {
        companyId,
        cashboxId: fromBox.id,
        direction: "IN",
        category: "OTHER",
        amount: deliveredAmount,
        balanceAfter: repBalanceAfter,
        balanceBefore: fromBox.balance,
        transactionType: "REVERSAL",
        transactionNumber: settlement.number,
        cashTransferId: settlement.cashTransferId ?? null,
        referenceNumber: settlement.number,
        isReversed: true,
        note: `عكس تسليم مندوب ${settlement.number} — إعادة المبلغ لصندوق المندوب`,
        createdBy: actor.userId,
      },
    });

    await tx.cashTransaction.create({
      data: {
        companyId,
        cashboxId: toBox.id,
        direction: "OUT",
        category: "OTHER",
        amount: deliveredAmount,
        balanceAfter: branchBalanceAfter,
        balanceBefore: toBox.balance,
        transactionType: "REVERSAL",
        transactionNumber: settlement.number,
        cashTransferId: settlement.cashTransferId ?? null,
        referenceNumber: settlement.number,
        isReversed: true,
        note: `عكس تسليم مندوب ${settlement.number} — خصم المبلغ من صندوق الفرع`,
        createdBy: actor.userId,
      },
    });

    await tx.cashbox.update({ where: { id: fromBox.id }, data: { balance: repBalanceAfter } });
    await tx.cashbox.update({ where: { id: toBox.id }, data: { balance: branchBalanceAfter } });

    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "CANCEL",
          module: "finance",
          entityType: "rep_settlement",
          entityId: settlement.id,
          oldValues: { status: "POSTED" },
          newValues: { status: "CANCELLED", reason, amount: num(deliveredAmount) },
        }
      ),
    });
  });

  return { id: settlement.id, number: settlement.number, status: "CANCELLED" };
}

/**
 * Compute outstanding rep balance: collected but not yet settled.
 * Returns the sum of COLLECTION cash transactions since the last settlement
 * that haven't been delivered via RepSettlement.
 */
export async function getRepOutstandingBalance(
  companyId: number,
  repUserId: number,
  fromCashboxId: number
): Promise<{ outstanding: number; lastSettlementAt: Date | null; lastSettlementNumber: string | null }> {
  const lastSettlement = await db.repSettlement.findFirst({
    where: { companyId, repUserId, fromCashboxId, status: "POSTED" },
    orderBy: { settlementDate: "desc" },
  });

  const txs = await db.cashTransaction.findMany({
    where: {
      cashboxId: fromCashboxId,
      direction: "IN",
      category: "COLLECTION",
      isReversed: false,
      createdAt: { gt: lastSettlement?.settlementDate ?? new Date(0) },
    },
    select: { amount: true },
  });

  const outstanding = moneyR(sumOf(txs, (t) => dec(t.amount)));

  return {
    outstanding: num(outstanding),
    lastSettlementAt: lastSettlement?.settlementDate ?? null,
    lastSettlementNumber: lastSettlement?.number ?? null,
  };
}
