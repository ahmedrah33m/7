// =====================================================================
// Cashbox service — advanced cash ledger (Phase: Advanced Finance).
//
// Every atomic money flow in this module is wrapped in ONE Prisma
// transaction:
//   createReceiptVoucher   → Payment + PaymentAllocation[] + ReceiptVoucher
//                            + CashTransaction (balanceBefore/After)
//                            + customer.balance ↓ + invoice.paidAmount ↑
//   cancelReceiptVoucher   → reversal CashTransaction + customer.balance ↑
//                            + invoice.paidAmount ↓ + status=CANCELLED
//   createPaymentVoucher    → mirror for supplier payment (supplier.balance ↓)
//   cancelPaymentVoucher   → reversal + supplier.balance ↑
//   createCashTransfer     → 2 CashTransactions (OUT from / IN to) sharing
//                            one CASH-TRF number; cross-currency supported
//   cancelCashTransfer     → 2 reversals
//   closeCashbox          → daily closing record (bookBalance vs actualCash
//                            + denomination counts), status DRAFT→CLOSED
//   reopenCashbox         → CLOSED → REOPENED (audit-only; books untouched)
//
// Idempotency: every create* honors optional idempotencyKey —
// @@unique([companyId, idempotencyKey]) on Payment/ReceiptVoucher/PaymentVoucher
// /CashTransfer + the matching CashTransaction.idempotencyKey deduplicates.
//
// All money math flows through Decimal (decimal.js) — no floating point.
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { nextDocumentNumber, DOC_TYPES } from "./document-number";
import { writeAudit, auditData } from "./audit";
import { Decimal, dec, moneyR, num, sumOf } from "./decimal";
import type { Prisma } from "@prisma/client";

export interface CashActor {
  userId: number;
  companyId: number;
  branchId?: number | null;
  ip?: string;
  userAgent?: string;
}

// ---------------------------------------------------------------------
// Cashbox accessibility guard — used at the head of every posting tx.
// Throws CASHBOX_001 (not found) / CASHBOX_002 (CLOSED) / CASHBOX_003 (SUSPENDED).
// ---------------------------------------------------------------------
export async function assertCashboxAccessible(
  tx: Prisma.TransactionClient,
  cashboxId: number,
  companyId: number,
  opts: { allowClosed?: boolean } = {}
) {
  const box = await tx.cashbox.findFirst({
    where: { id: cashboxId, companyId, deletedAt: null },
  });
  if (!box) throw new ApiError("CASHBOX_001");
  if (!opts.allowClosed && box.status === "CLOSED") throw new ApiError("CASHBOX_002");
  if (box.status === "SUSPENDED") throw new ApiError("CASHBOX_003");
  if (!box.isActive && !opts.allowClosed) throw new ApiError("CASHBOX_003", "الصندوق معطل");
  return box;
}

// ---------------------------------------------------------------------
// Internal: write a CashTransaction row + balance update. Returns the row
// and the new balance so callers can chain reversals.
// ---------------------------------------------------------------------
type CashDirection = "IN" | "OUT";

interface PostTxInput {
  companyId: number;
  cashboxId: number;
  direction: CashDirection;
  category: string; // COLLECTION | SUPPLIER_PAYMENT | EXPENSE | OPENING | REFUND | OTHER
  transactionType: string; // RECEIPT | PAYMENT | TRANSFER | EXPENSE | CLOSING | BANK_DEPOSIT | REVERSAL
  transactionNumber: string;
  amount: Decimal;
  balanceBefore: Decimal;
  partyType?: "CUSTOMER" | "SUPPLIER" | null;
  customerId?: number | null;
  supplierId?: number | null;
  refType?: string | null;
  refId?: number | null;
  invoiceId?: number | null;
  purchaseInvoiceId?: number | null;
  paymentId?: number | null;
  receiptId?: number | null;
  paymentVoucherId?: number | null;
  cashTransferId?: number | null;
  referenceNumber?: string | null;
  currency?: string | null;
  exchangeRate?: Decimal | null;
  sourceCurrency?: string | null;
  targetCurrency?: string | null;
  idempotencyKey?: string | null;
  reversalOfId?: number | null;
  note?: string | null;
  userId: number;
}

async function postCashTransaction(
  tx: Prisma.TransactionClient,
  input: PostTxInput
) {
  const amount = moneyR(input.amount);
  if (!amount.isPositive() && input.category !== "OPENING") {
    throw new ApiError("VAL_001", "المبلغ يجب أن يكون أكبر من صفر");
  }
  const balanceBefore = moneyR(input.balanceBefore);
  const balanceAfter =
    input.direction === "IN"
      ? moneyR(balanceBefore.plus(amount))
      : moneyR(balanceBefore.minus(amount));
  if (input.direction === "OUT" && balanceAfter.isNegative()) {
    throw new ApiError(
      "CASHBOX_004",
      `رصيد الصندوق لا يكفي — المتاح: ${num(balanceBefore)}، المطلوب: ${num(amount)}`
    );
  }

  // Idempotency: if a row with this key exists, return it (no double-post).
  if (input.idempotencyKey) {
    const existing = await tx.cashTransaction.findUnique({
      where: { companyId_idempotencyKey: { companyId: input.companyId, idempotencyKey: input.idempotencyKey } },
    });
    if (existing) return { row: existing, balanceBefore, balanceAfter, duplicate: true as const };
  }

  const row = await tx.cashTransaction.create({
    data: {
      companyId: input.companyId,
      cashboxId: input.cashboxId,
      direction: input.direction,
      category: input.category,
      amount,
      balanceAfter,
      partyType: input.partyType ?? null,
      customerId: input.customerId ?? null,
      supplierId: input.supplierId ?? null,
      refType: input.refType ?? null,
      refId: input.refId ?? null,
      note: input.note ?? null,
      createdBy: input.userId,
      transactionType: input.transactionType,
      transactionNumber: input.transactionNumber,
      referenceNumber: input.referenceNumber ?? null,
      balanceBefore,
      invoiceId: input.invoiceId ?? null,
      purchaseInvoiceId: input.purchaseInvoiceId ?? null,
      paymentId: input.paymentId ?? null,
      receiptId: input.receiptId ?? null,
      paymentVoucherId: input.paymentVoucherId ?? null,
      cashTransferId: input.cashTransferId ?? null,
      idempotencyKey: input.idempotencyKey ?? null,
      currency: input.currency ?? null,
      exchangeRate: input.exchangeRate ?? null,
      sourceCurrency: input.sourceCurrency ?? null,
      targetCurrency: input.targetCurrency ?? null,
      isReversed: false,
      reversalOfId: input.reversalOfId ?? null,
    },
  });

  await tx.cashbox.update({
    where: { id: input.cashboxId },
    data: { balance: balanceAfter },
  });

  return { row, balanceBefore, balanceAfter, duplicate: false as const };
}

// ---------------------------------------------------------------------
// Helpers for invoice lookup + allocation validation
// ---------------------------------------------------------------------
interface InvoiceAllocationInput {
  invoiceType: "SALES" | "PURCHASE";
  invoiceId: number;
  amount: number; // IQD amount to allocate
}

interface InvoiceSnapshot {
  invoiceId: number;
  invoiceType: "SALES" | "PURCHASE";
  invoiceNumber: string;
  invoiceTotal: number;
  previouslyPaid: number;
  currentPayment: number;
  remainingAfter: number;
}

async function loadInvoice(
  companyId: number,
  a: InvoiceAllocationInput
): Promise<{
  id: number; number: string; grandTotal: Decimal; paidAmount: Decimal;
  due: Decimal; customerId: number | null; supplierId: number | null;
}> {
  if (a.invoiceType === "SALES") {
    const inv = await db.salesInvoice.findFirst({
      where: { id: a.invoiceId, companyId, deletedAt: null },
    });
    if (!inv) throw new ApiError("VAL_003", "فاتورة البيع غير موجودة");
    const due = moneyR(dec(inv.grandTotal).minus(inv.paidAmount));
    return {
      id: inv.id, number: inv.number,
      grandTotal: dec(inv.grandTotal), paidAmount: dec(inv.paidAmount), due,
      customerId: inv.customerId, supplierId: null,
    };
  }
  const inv = await db.purchaseInvoice.findFirst({
    where: { id: a.invoiceId, companyId, deletedAt: null },
  });
  if (!inv) throw new ApiError("VAL_003", "فاتورة الشراء غير موجودة");
  const due = moneyR(dec(inv.grandTotal).minus(inv.paidAmount));
  return {
    id: inv.id, number: inv.number,
    grandTotal: dec(inv.grandTotal), paidAmount: dec(inv.paidAmount), due,
    customerId: null, supplierId: inv.supplierId,
  };
}

// =====================================================================
// 1) createReceiptVoucher — customer receipt (RCPT-2026-000001)
// =====================================================================
export interface ReceiptAllocationInput {
  invoiceId: number;
  invoiceType: "SALES" | "PURCHASE";
  amount: number;
}

export interface CreateReceiptInput {
  customerId?: number | null;
  supplierId?: number | null;
  cashboxId: number;
  branchId: number;
  amount: number;
  currency?: string;
  exchangeRate?: number | null;
  paymentMethod?: string;
  referenceNumber?: string | null;
  bankName?: string | null;
  bankAccount?: string | null;
  recipientName?: string | null;
  receivedBy?: string | null;
  description?: string | null;
  notes?: string | null;
  idempotencyKey?: string | null;
  allocations?: ReceiptAllocationInput[];
  invoiceId?: number | null; // single-invoice shortcut
  // ---- Phase 15 — Mixed payment split (MIXED PAYMENT) -----------------
  // When paymentMethod = MIXED, the four split amounts below MUST sum to
  // `amount`. The cashbox ledger only credits cashAmount (the rest are
  // bank/card/on-account). All splits are snapshotted on the Payment row
  // for reconciliation and audit (Phase 14: card/transfer with bank ref).
  cashAmount?: number | null;
  cardAmount?: number | null;
  bankAmount?: number | null;
  onAccountAmount?: number | null;
  cardLast4?: string | null;
}

export async function createReceiptVoucher(actor: CashActor, input: CreateReceiptInput) {
  const companyId = actor.companyId;
  const amount = moneyR(dec(input.amount));
  if (!amount.isPositive()) throw new ApiError("RECEIPT_001");

  // Party validation — customer (default) or supplier (refund → receivable relief)
  let customerId: number | null = input.customerId ?? null;
  let supplierId: number | null = input.supplierId ?? null;
  let partyType: "CUSTOMER" | "SUPPLIER" | null = null;
  let recipientName = input.recipientName ?? "";

  if (customerId) {
    const c = await db.customer.findFirst({ where: { id: customerId, companyId, deletedAt: null } });
    if (!c) throw new ApiError("VAL_003", "العميل غير موجود");
    partyType = "CUSTOMER";
    if (!recipientName) recipientName = c.name;
  } else if (supplierId) {
    const s = await db.supplier.findFirst({ where: { id: supplierId, companyId, deletedAt: null } });
    if (!s) throw new ApiError("VAL_003", "المورد غير موجود");
    partyType = "SUPPLIER";
    if (!recipientName) recipientName = s.name;
  } else {
    throw new ApiError("VAL_001", "يلزم تحديد العميل أو المورد");
  }

  // Build allocations list (single-invoice shortcut → one allocation)
  const allocations = input.allocations && input.allocations.length
    ? input.allocations
    : input.invoiceId
      ? [{ invoiceId: input.invoiceId, invoiceType: "SALES" as const, amount: num(amount) }]
      : [];

  // Validate allocations against invoice due amounts
  const invoiceSnapshots: InvoiceSnapshot[] = [];
  let allocatedTotal = new Decimal(0);
  for (const a of allocations) {
    const inv = await loadInvoice(companyId, a);
    const allocAmt = moneyR(a.amount);
    if (allocAmt.gt(inv.due.plus("0.01"))) {
      throw new ApiError(
        "PAYMENT_001",
        `تخصيص ${num(allocAmt)} يتجاوز المتبقي على الفاتورة ${inv.number} (${num(inv.due)})`
      );
    }
    allocatedTotal = allocatedTotal.plus(allocAmt);
    invoiceSnapshots.push({
      invoiceId: inv.id, invoiceType: a.invoiceType, invoiceNumber: inv.number,
      invoiceTotal: num(inv.grandTotal), previouslyPaid: num(inv.paidAmount),
      currentPayment: num(allocAmt),
      remainingAfter: num(moneyR(inv.due.minus(allocAmt))),
    });
  }

  // Allocated total must not exceed receipt amount (advance = remainder unallocated)
  if (allocatedTotal.gt(amount.plus("0.01"))) {
    throw new ApiError(
      "PAYMENT_001",
      `إجمالي التخصيص ${num(allocatedTotal)} يتجاوز مبلغ القبض ${num(amount)}`
    );
  }

  // Idempotency check at the head
  if (input.idempotencyKey) {
    const existing = await db.receiptVoucher.findUnique({
      where: { companyId_idempotencyKey: { companyId, idempotencyKey: input.idempotencyKey } },
    });
    if (existing) return { id: existing.id, number: existing.number, duplicate: true };
  }

  const result = await db.$transaction(async (tx) => {
    const box = await assertCashboxAccessible(tx, input.cashboxId, companyId);

    // ---- Phase 15 — Mixed payment split computation --------------------
    // cashPostedToBox = only the cash portion flows into the cashbox ledger.
    // For non-MIXED payments the full amount is cash (default behavior).
    const isMixed = (input.paymentMethod ?? "CASH") === "MIXED";
    let cashPosted: Decimal;
    let cardSplit: Decimal | null = null;
    let bankSplit: Decimal | null = null;
    let onAccountSplit: Decimal | null = null;
    if (isMixed) {
      const c = input.cashAmount != null ? moneyR(dec(input.cashAmount)) : new Decimal(0);
      const d = input.cardAmount != null ? moneyR(dec(input.cardAmount)) : new Decimal(0);
      const b = input.bankAmount != null ? moneyR(dec(input.bankAmount)) : new Decimal(0);
      const o = input.onAccountAmount != null ? moneyR(dec(input.onAccountAmount)) : new Decimal(0);
      const splitSum = moneyR(c.plus(d).plus(b).plus(o));
      if (!splitSum.eq(amount)) {
        throw new ApiError(
          "PAYMENT_001",
          `الدفع المختلط يتطلب مساواة مجموع الأقسام (${num(splitSum)}) للمبلغ الكلي (${num(amount)})`
        );
      }
      cashPosted = c;
      if (d.isPositive()) cardSplit = d;
      if (b.isPositive()) bankSplit = b;
      if (o.isPositive()) onAccountSplit = o;
    } else {
      cashPosted = amount;
    }

    // 1) Unified Payment row (UPAY-2026-...)
    const paymentNumber = await nextDocumentNumber(tx, companyId, "UNIFIED_PAYMENT");
    const payment = await tx.payment.create({
      data: {
        companyId,
        branchId: input.branchId,
        number: paymentNumber,
        paymentType: "RECEIPT",
        partyType: partyType ?? "OTHER",
        customerId, supplierId,
        cashboxId: box.id,
        totalAmount: amount,
        currency: input.currency ?? "IQD",
        exchangeRate: input.exchangeRate ? dec(input.exchangeRate) : null,
        paymentMethod: input.paymentMethod ?? "CASH",
        paymentDate: new Date(),
        status: "POSTED",
        idempotencyKey: input.idempotencyKey ?? null,
        referenceNumber: input.referenceNumber ?? null,
        bankName: input.bankName ?? null,
        bankAccount: input.bankAccount ?? null,
        cardLast4: input.cardLast4 ?? null,
        // Phase 15 — split amounts snapshotted for reconciliation
        cashAmount: cashPosted,
        cardAmount: cardSplit,
        bankAmount: bankSplit,
        onAccountAmount: onAccountSplit,
        description: input.description,
        notes: input.notes,
        createdById: actor.userId,
      },
    });

    // 2) Payment allocations + invoice paidAmount increments
    for (const snap of invoiceSnapshots) {
      await tx.paymentAllocation.create({
        data: {
          companyId,
          paymentId: payment.id,
          invoiceType: snap.invoiceType,
          salesInvoiceId: snap.invoiceType === "SALES" ? snap.invoiceId : null,
          purchaseInvoiceId: snap.invoiceType === "PURCHASE" ? snap.invoiceId : null,
          allocatedAmount: snap.currentPayment,
          invoiceNumber: snap.invoiceNumber,
          invoiceTotal: snap.invoiceTotal,
          previouslyPaid: snap.previouslyPaid,
          remainingAfter: snap.remainingAfter,
        },
      });
      if (snap.invoiceType === "SALES") {
        await tx.salesInvoice.update({
          where: { id: snap.invoiceId },
          data: { paidAmount: { increment: snap.currentPayment } },
        });
      } else {
        await tx.purchaseInvoice.update({
          where: { id: snap.invoiceId },
          data: { paidAmount: { increment: snap.currentPayment } },
        });
      }
    }

    // 3) ReceiptVoucher (RCPT-2026-...) — formal customer-facing voucher
    const rcptNumber = await nextDocumentNumber(tx, companyId, "RCPT");
    const verifyToken = crypto.randomUUID();
    const grandTotalSnap = invoiceSnapshots.length
      ? sumOf(invoiceSnapshots, (s) => s.invoiceTotal)
      : new Decimal(0);
    const currentPaySnap = sumOf(invoiceSnapshots, (s) => s.currentPayment);
    const prevPaidSnap = sumOf(invoiceSnapshots, (s) => s.previouslyPaid);
    const remainingSnap = sumOf(invoiceSnapshots, (s) => s.remainingAfter);
    const qrData = JSON.stringify({
      voucher: rcptNumber, payment: paymentNumber, amount: num(amount),
      party: recipientName, date: new Date().toISOString(),
      verifyToken,
    });
    const receipt = await tx.receiptVoucher.create({
      data: {
        companyId,
        branchId: input.branchId,
        number: rcptNumber,
        receiptDate: new Date(),
        cashboxId: box.id,
        recipientName,
        customerId, supplierId,
        amount,
        currency: input.currency ?? "IQD",
        exchangeRate: input.exchangeRate ? dec(input.exchangeRate) : null,
        amountInCashbox: amount,
        paymentMethod: input.paymentMethod ?? "CASH",
        paymentId: payment.id,
        referenceNumber: input.referenceNumber ?? null,
        bankName: input.bankName ?? null,
        bankAccount: input.bankAccount ?? null,
        invoiceSnapshot: JSON.stringify(invoiceSnapshots),
        grandTotalSnapshot: invoiceSnapshots.length ? grandTotalSnap : null,
        previouslyPaidSnapshot: invoiceSnapshots.length ? prevPaidSnap : null,
        currentPaymentSnapshot: invoiceSnapshots.length ? currentPaySnap : null,
        remainingSnapshot: invoiceSnapshots.length ? remainingSnap : null,
        status: "POSTED",
        verifyToken,
        qrData,
        idempotencyKey: input.idempotencyKey ?? null,
        description: input.description,
        notes: input.notes,
        receivedBy: input.receivedBy ?? null,
        createdById: actor.userId,
      },
    });

    // 4) CashTransaction (RECEIPT) — IN into cashbox (cash portion only for MIXED)
    // Phase 15 — only the cash split flows into the cash ledger. Card/bank/on-account
    // splits are tracked on the Payment row but do NOT move cashbox balance.
    const cashTx = await postCashTransaction(tx, {
      companyId,
      cashboxId: box.id,
      direction: "IN",
      category: customerId ? "COLLECTION" : "REFUND",
      transactionType: "RECEIPT",
      transactionNumber: rcptNumber,
      amount: cashPosted,
      balanceBefore: dec(box.balance),
      partyType,
      customerId, supplierId,
      refType: invoiceSnapshots[0]?.invoiceType === "SALES" ? "SALES_INVOICE" : null,
      refId: invoiceSnapshots[0]?.invoiceId ?? null,
      paymentId: payment.id,
      receiptId: receipt.id,
      referenceNumber: input.referenceNumber ?? null,
      currency: input.currency ?? null,
      exchangeRate: input.exchangeRate ? dec(input.exchangeRate) : null,
      idempotencyKey: input.idempotencyKey ?? null,
      note: isMixed
        ? `قبض مختلط ${rcptNumber} — ${recipientName} (نقد ${num(cashPosted)} من ${num(amount)})`
        : `قبض ${rcptNumber} — ${recipientName}`,
      userId: actor.userId,
    });
    void cashTx; // balanceAfter applied inside postCashTransaction

    // 5) Party balance update — customer.balance ↓ (receivable relief) or supplier.balance ↓ (payable relief)
    if (customerId) {
      await tx.customer.update({
        where: { id: customerId },
        data: { balance: { decrement: amount } },
      });
    } else if (supplierId) {
      await tx.supplier.update({
        where: { id: supplierId },
        data: { balance: { decrement: amount } },
      });
    }

    // 6) Audit row (fire-and-forget inside tx)
    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "CREATE",
          module: "finance",
          entityType: "receipt_voucher",
          entityId: receipt.id,
          newValues: {
            number: rcptNumber, payment: paymentNumber,
            recipient: recipientName, amount: num(amount),
            allocations: invoiceSnapshots.length,
          },
        }
      ),
    });

    return { receipt, payment, invoiceSnapshots };
  });

  return {
    id: result.receipt.id,
    number: result.receipt.number,
    payment_number: result.payment.number,
    amount: num(amount),
    customer_id: customerId,
    supplier_id: supplierId,
    allocations: result.invoiceSnapshots,
  };
}

// =====================================================================
// 2) cancelReceiptVoucher — reverse the receipt (REVERSAL + balance ↑)
// =====================================================================
export async function cancelReceiptVoucher(actor: CashActor, receiptId: number, reason: string) {
  if (!reason?.trim()) throw new ApiError("RECEIPT_003");
  const companyId = actor.companyId;

  const receipt = await db.receiptVoucher.findFirst({
    where: { id: receiptId, companyId, deletedAt: null },
    include: { payment: { include: { allocations: true } } },
  });
  if (!receipt) throw new ApiError("VAL_003", "وصل القبض غير موجود");
  if (receipt.status === "CANCELLED") throw new ApiError("RECEIPT_002");

  await db.$transaction(async (tx) => {
    const box = await assertCashboxAccessible(tx, receipt.cashboxId, companyId, { allowClosed: true });

    // 1) Mark receipt + payment cancelled
    await tx.receiptVoucher.update({
      where: { id: receipt.id },
      data: {
        status: "CANCELLED",
        cancelReason: reason,
        cancelledById: actor.userId,
        cancelledAt: new Date(),
      },
    });
    if (receipt.payment) {
      await tx.payment.update({
        where: { id: receipt.payment.id },
        data: {
          status: "CANCELLED",
          cancelReason: reason,
          cancelledById: actor.userId,
          cancelledAt: new Date(),
        },
      });
    }

    // 2) Reverse invoice paidAmount + customer/supplier balance
    const amount = dec(receipt.amount);
    if (receipt.customerId) {
      await tx.customer.update({
        where: { id: receipt.customerId },
        data: { balance: { increment: moneyR(amount) } },
      });
    } else if (receipt.supplierId) {
      await tx.supplier.update({
        where: { id: receipt.supplierId },
        data: { balance: { increment: moneyR(amount) } },
      });
    }

    if (receipt.payment?.allocations) {
      for (const a of receipt.payment.allocations) {
        if (a.salesInvoiceId) {
          await tx.salesInvoice.update({
            where: { id: a.salesInvoiceId },
            data: { paidAmount: { decrement: dec(a.allocatedAmount) } },
          });
        }
        if (a.purchaseInvoiceId) {
          await tx.purchaseInvoice.update({
            where: { id: a.purchaseInvoiceId },
            data: { paidAmount: { decrement: dec(a.allocatedAmount) } },
          });
        }
      }
    }

    // 3) Reversal CashTransaction (OUT — cash leaves the box)
    await postCashTransaction(tx, {
      companyId,
      cashboxId: box.id,
      direction: "OUT",
      category: "REFUND",
      transactionType: "REVERSAL",
      transactionNumber: `REV-${receipt.number}`,
      amount: moneyR(amount),
      balanceBefore: dec(box.balance),
      partyType: receipt.customerId ? "CUSTOMER" : receipt.supplierId ? "SUPPLIER" : null,
      customerId: receipt.customerId,
      supplierId: receipt.supplierId,
      receiptId: receipt.id,
      paymentId: receipt.paymentId,
      idempotencyKey: `cancel:${receipt.id}`,
      note: `إلغاء ${receipt.number} — ${reason}`,
      userId: actor.userId,
    });

    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "CANCEL",
          module: "finance",
          entityType: "receipt_voucher",
          entityId: receipt.id,
          newValues: { reason, amount: num(amount) },
        }
      ),
    });
  });

  return { id: receipt.id, number: receipt.number, status: "CANCELLED" };
}

// =====================================================================
// 3) createPaymentVoucher — supplier payment (PAY-2026-000001)
// =====================================================================
export interface CreatePaymentVoucherInput {
  supplierId?: number | null;
  customerId?: number | null;
  cashboxId?: number | null; // null = charged expense (no cash outflow)
  branchId: number;
  amount: number;
  currency?: string;
  exchangeRate?: number | null;
  paymentMethod?: string;
  reason: string;
  beneficiaryName?: string | null;
  paidTo?: string | null;
  referenceNumber?: string | null;
  bankName?: string | null;
  bankAccount?: string | null;
  expenseCategory?: string | null;
  expenseCategoryId?: number | null;
  purchaseInvoiceId?: number | null;
  chargeToCustomerId?: number | null;
  description?: string | null;
  notes?: string | null;
  idempotencyKey?: string | null;
  allocations?: ReceiptAllocationInput[];
  // ---- Phase 15 — Mixed payment split (MIXED PAYMENT) -----------------
  cashAmount?: number | null;
  cardAmount?: number | null;
  bankAmount?: number | null;
  onAccountAmount?: number | null;
  cardLast4?: string | null;
}

export async function createPaymentVoucher(actor: CashActor, input: CreatePaymentVoucherInput) {
  const companyId = actor.companyId;
  const amount = moneyR(dec(input.amount));
  if (!amount.isPositive()) throw new ApiError("PV_001");
  if (!input.reason?.trim()) throw new ApiError("PV_003", "بيان الصرف مطلوب");

  const isCharged = !!input.chargeToCustomerId && !input.cashboxId;

  // Party validation
  let supplierId: number | null = input.supplierId ?? null;
  let customerId: number | null = input.customerId ?? null;
  let chargeToCustomerId: number | null = input.chargeToCustomerId ?? null;
  let beneficiaryName = input.beneficiaryName ?? "";

  if (supplierId) {
    const s = await db.supplier.findFirst({ where: { id: supplierId, companyId, deletedAt: null } });
    if (!s) throw new ApiError("VAL_003", "المورد غير موجود");
    if (!beneficiaryName) beneficiaryName = s.name;
  } else if (customerId) {
    const c = await db.customer.findFirst({ where: { id: customerId, companyId, deletedAt: null } });
    if (!c) throw new ApiError("VAL_003", "العميل غير موجود");
    if (!beneficiaryName) beneficiaryName = c.name;
  } else if (chargeToCustomerId) {
    const c = await db.customer.findFirst({ where: { id: chargeToCustomerId, companyId, deletedAt: null } });
    if (!c) throw new ApiError("VAL_003", "عميل التحميل غير موجود");
    if (!beneficiaryName) beneficiaryName = c.name;
  } else {
    // Generic expense with beneficiary name required
    if (!beneficiaryName) throw new ApiError("PV_003", "اسم المستفيد مطلوب للمصروف العام");
  }

  // Build allocations if invoice link provided
  const allocations = input.allocations && input.allocations.length
    ? input.allocations
    : input.purchaseInvoiceId
      ? [{ invoiceId: input.purchaseInvoiceId, invoiceType: "PURCHASE" as const, amount: num(amount) }]
      : [];

  const invoiceSnapshots: InvoiceSnapshot[] = [];
  let allocatedTotal = new Decimal(0);
  for (const a of allocations) {
    const inv = await loadInvoice(companyId, a);
    const allocAmt = moneyR(a.amount);
    if (allocAmt.gt(inv.due.plus("0.01"))) {
      throw new ApiError(
        "PAYMENT_001",
        `تخصيص ${num(allocAmt)} يتجاوز المتبقي على فاتورة الشراء ${inv.number} (${num(inv.due)})`
      );
    }
    allocatedTotal = allocatedTotal.plus(allocAmt);
    invoiceSnapshots.push({
      invoiceId: inv.id, invoiceType: a.invoiceType, invoiceNumber: inv.number,
      invoiceTotal: num(inv.grandTotal), previouslyPaid: num(inv.paidAmount),
      currentPayment: num(allocAmt),
      remainingAfter: num(moneyR(inv.due.minus(allocAmt))),
    });
  }
  if (allocatedTotal.gt(amount.plus("0.01"))) {
    throw new ApiError("PAYMENT_001", `إجمالي التخصيص يتجاوز مبلغ الصرف`);
  }

  // Idempotency check
  if (input.idempotencyKey) {
    const existing = await db.paymentVoucher.findUnique({
      where: { companyId_idempotencyKey: { companyId, idempotencyKey: input.idempotencyKey } },
    });
    if (existing) return { id: existing.id, number: existing.number, duplicate: true };
  }

  const result = await db.$transaction(async (tx) => {
    let box: { id: number; balance: Decimal; status: string; isActive: boolean } | null = null;
    if (input.cashboxId) {
      box = await assertCashboxAccessible(tx, input.cashboxId, companyId);
    } else if (!isCharged) {
      throw new ApiError("CASHBOX_001", "يلزم تحديد الصندوق للمصروف النقدي");
    }

    // 1) Unified Payment row (UPAY-...)
    // ---- Phase 15 — Mixed payment split (voucher side) ------------------
    const isMixedOut = (input.paymentMethod ?? "CASH") === "MIXED";
    let cashPostedOut: Decimal;
    let cardSplitOut: Decimal | null = null;
    let bankSplitOut: Decimal | null = null;
    let onAccountSplitOut: Decimal | null = null;
    if (isMixedOut && box) {
      const c = input.cashAmount != null ? moneyR(dec(input.cashAmount)) : new Decimal(0);
      const d = input.cardAmount != null ? moneyR(dec(input.cardAmount)) : new Decimal(0);
      const b = input.bankAmount != null ? moneyR(dec(input.bankAmount)) : new Decimal(0);
      const o = input.onAccountAmount != null ? moneyR(dec(input.onAccountAmount)) : new Decimal(0);
      const splitSum = moneyR(c.plus(d).plus(b).plus(o));
      if (!splitSum.eq(amount)) {
        throw new ApiError(
          "PAYMENT_001",
          `الدفع المختلط يتطلب مساواة مجموع الأقسام (${num(splitSum)}) للمبلغ الكلي (${num(amount)})`
        );
      }
      cashPostedOut = c;
      if (d.isPositive()) cardSplitOut = d;
      if (b.isPositive()) bankSplitOut = b;
      if (o.isPositive()) onAccountSplitOut = o;
    } else if (isCharged) {
      // Charged expense — no cash moves; everything is on_account
      cashPostedOut = new Decimal(0);
      onAccountSplitOut = amount;
    } else {
      cashPostedOut = amount;
    }

    const paymentNumber = await nextDocumentNumber(tx, companyId, "UNIFIED_PAYMENT");
    const payment = await tx.payment.create({
      data: {
        companyId,
        branchId: input.branchId,
        number: paymentNumber,
        paymentType: "PAYMENT",
        partyType: supplierId ? "SUPPLIER" : customerId ? "CUSTOMER" : "OTHER",
        customerId, supplierId,
        cashboxId: box?.id ?? null,
        totalAmount: amount,
        currency: input.currency ?? "IQD",
        exchangeRate: input.exchangeRate ? dec(input.exchangeRate) : null,
        paymentMethod: input.paymentMethod ?? "CASH",
        paymentDate: new Date(),
        status: "POSTED",
        idempotencyKey: input.idempotencyKey ?? null,
        referenceNumber: input.referenceNumber ?? null,
        bankName: input.bankName ?? null,
        bankAccount: input.bankAccount ?? null,
        cardLast4: input.cardLast4 ?? null,
        // Phase 15 — split snapshotted; only cash moves the cashbox
        cashAmount: box ? cashPostedOut : null,
        cardAmount: cardSplitOut,
        bankAmount: bankSplitOut,
        onAccountAmount: isCharged ? amount : onAccountSplitOut,
        description: input.description,
        notes: input.notes,
        createdById: actor.userId,
      },
    });

    // 2) Allocations + invoice paidAmount increments
    for (const snap of invoiceSnapshots) {
      await tx.paymentAllocation.create({
        data: {
          companyId,
          paymentId: payment.id,
          invoiceType: snap.invoiceType,
          salesInvoiceId: snap.invoiceType === "SALES" ? snap.invoiceId : null,
          purchaseInvoiceId: snap.invoiceType === "PURCHASE" ? snap.invoiceId : null,
          allocatedAmount: snap.currentPayment,
          invoiceNumber: snap.invoiceNumber,
          invoiceTotal: snap.invoiceTotal,
          previouslyPaid: snap.previouslyPaid,
          remainingAfter: snap.remainingAfter,
        },
      });
      if (snap.invoiceType === "PURCHASE") {
        await tx.purchaseInvoice.update({
          where: { id: snap.invoiceId },
          data: { paidAmount: { increment: snap.currentPayment } },
        });
      } else {
        await tx.salesInvoice.update({
          where: { id: snap.invoiceId },
          data: { paidAmount: { increment: snap.currentPayment } },
        });
      }
    }

    // 3) PaymentVoucher (PAY-2026-...)
    const payNumber = await nextDocumentNumber(tx, companyId, "PAYMENT_VOUCHER");
    const verifyToken = crypto.randomUUID();
    const grandTotalSnap = invoiceSnapshots.length
      ? sumOf(invoiceSnapshots, (s) => s.invoiceTotal)
      : new Decimal(0);
    const currentPaySnap = sumOf(invoiceSnapshots, (s) => s.currentPayment);
    const prevPaidSnap = sumOf(invoiceSnapshots, (s) => s.previouslyPaid);
    const remainingSnap = sumOf(invoiceSnapshots, (s) => s.remainingAfter);
    const voucher = await tx.paymentVoucher.create({
      data: {
        companyId,
        branchId: input.branchId,
        number: payNumber,
        paymentDate: new Date(),
        cashboxId: box?.id ?? null,
        beneficiaryName,
        customerId, supplierId,
        reason: input.reason,
        amount,
        currency: input.currency ?? "IQD",
        exchangeRate: input.exchangeRate ? dec(input.exchangeRate) : null,
        amountInCashbox: box ? amount : null,
        paymentMethod: input.paymentMethod ?? "CASH",
        paymentId: payment.id,
        referenceNumber: input.referenceNumber ?? null,
        bankName: input.bankName ?? null,
        bankAccount: input.bankAccount ?? null,
        expenseCategory: input.expenseCategory ?? null,
        expenseCategoryId: input.expenseCategoryId ?? null,
        purchaseInvoiceId: input.purchaseInvoiceId ?? null,
        chargeToCustomerId: input.chargeToCustomerId ?? null,
        paidTo: input.paidTo ?? null,
        invoiceSnapshot: invoiceSnapshots.length ? JSON.stringify(invoiceSnapshots) : null,
        grandTotalSnapshot: invoiceSnapshots.length ? grandTotalSnap : null,
        previouslyPaidSnapshot: invoiceSnapshots.length ? prevPaidSnap : null,
        currentPaymentSnapshot: invoiceSnapshots.length ? currentPaySnap : null,
        remainingSnapshot: invoiceSnapshots.length ? remainingSnap : null,
        status: "POSTED",
        verifyToken,
        idempotencyKey: input.idempotencyKey ?? null,
        description: input.description,
        notes: input.notes,
        createdById: actor.userId,
      },
    });

    // 4) CashTransaction (PAYMENT) — OUT of cashbox (only cash portion for MIXED)
    if (box && cashPostedOut.isPositive()) {
      await postCashTransaction(tx, {
        companyId,
        cashboxId: box.id,
        direction: "OUT",
        category: supplierId ? "SUPPLIER_PAYMENT" : "EXPENSE",
        transactionType: "PAYMENT",
        transactionNumber: payNumber,
        amount: cashPostedOut,
        balanceBefore: dec(box.balance),
        partyType: supplierId ? "SUPPLIER" : customerId ? "CUSTOMER" : null,
        customerId, supplierId,
        refType: invoiceSnapshots[0]?.invoiceType === "PURCHASE" ? "PURCHASE_INVOICE" : null,
        refId: invoiceSnapshots[0]?.invoiceId ?? null,
        paymentId: payment.id,
        paymentVoucherId: voucher.id,
        purchaseInvoiceId: input.purchaseInvoiceId ?? null,
        referenceNumber: input.referenceNumber ?? null,
        currency: input.currency ?? null,
        exchangeRate: input.exchangeRate ? dec(input.exchangeRate) : null,
        idempotencyKey: input.idempotencyKey ?? null,
        note: `صرف ${payNumber} — ${input.reason}`,
        userId: actor.userId,
      });
    }

    // 5) Party balance updates
    if (supplierId) {
      await tx.supplier.update({
        where: { id: supplierId },
        data: { balance: { decrement: amount } },
      });
    } else if (chargeToCustomerId) {
      // Charged expense — customer.balance ↑ (the customer owes the company more)
      await tx.customer.update({
        where: { id: chargeToCustomerId },
        data: { balance: { increment: amount } },
      });
    }

    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "CREATE",
          module: "finance",
          entityType: "payment_voucher",
          entityId: voucher.id,
          newValues: {
            number: payNumber, payment: paymentNumber,
            beneficiary: beneficiaryName, reason: input.reason, amount: num(amount),
            charged: isCharged, allocations: invoiceSnapshots.length,
          },
        }
      ),
    });

    return { voucher, payment, invoiceSnapshots };
  });

  return {
    id: result.voucher.id,
    number: result.voucher.number,
    payment_number: result.payment.number,
    amount: num(amount),
    supplier_id: supplierId,
    customer_id: customerId,
    charged_to_customer: isCharged,
    allocations: result.invoiceSnapshots,
  };
}

// =====================================================================
// 4) cancelPaymentVoucher — reverse supplier payment
// =====================================================================
export async function cancelPaymentVoucher(actor: CashActor, voucherId: number, reason: string) {
  if (!reason?.trim()) throw new ApiError("PV_003", "سبب الإلغاء مطلوب");
  const companyId = actor.companyId;

  const voucher = await db.paymentVoucher.findFirst({
    where: { id: voucherId, companyId, deletedAt: null },
    include: { payment: { include: { allocations: true } } },
  });
  if (!voucher) throw new ApiError("VAL_003", "وصل الصرف غير موجود");
  if (voucher.status === "CANCELLED") throw new ApiError("PV_002");

  await db.$transaction(async (tx) => {
    let box: { id: number; balance: Decimal; status: string; isActive: boolean } | null = null;
    if (voucher.cashboxId) {
      box = await assertCashboxAccessible(tx, voucher.cashboxId, companyId, { allowClosed: true });
    }

    await tx.paymentVoucher.update({
      where: { id: voucher.id },
      data: {
        status: "CANCELLED",
        cancelReason: reason,
        cancelledById: actor.userId,
        cancelledAt: new Date(),
      },
    });
    if (voucher.payment) {
      await tx.payment.update({
        where: { id: voucher.payment.id },
        data: {
          status: "CANCELLED",
          cancelReason: reason,
          cancelledById: actor.userId,
          cancelledAt: new Date(),
        },
      });
    }

    const amount = dec(voucher.amount);

    // Reverse supplier/customer balance + invoice paidAmount
    if (voucher.supplierId) {
      await tx.supplier.update({
        where: { id: voucher.supplierId },
        data: { balance: { increment: moneyR(amount) } },
      });
    } else if (voucher.chargeToCustomerId) {
      await tx.customer.update({
        where: { id: voucher.chargeToCustomerId },
        data: { balance: { decrement: moneyR(amount) } },
      });
    }

    if (voucher.payment?.allocations) {
      for (const a of voucher.payment.allocations) {
        if (a.purchaseInvoiceId) {
          await tx.purchaseInvoice.update({
            where: { id: a.purchaseInvoiceId },
            data: { paidAmount: { decrement: dec(a.allocatedAmount) } },
          });
        }
        if (a.salesInvoiceId) {
          await tx.salesInvoice.update({
            where: { id: a.salesInvoiceId },
            data: { paidAmount: { decrement: dec(a.allocatedAmount) } },
          });
        }
      }
    }

    if (box) {
      // Reversal CashTransaction (IN — cash back into the box)
      await postCashTransaction(tx, {
        companyId,
        cashboxId: box.id,
        direction: "IN",
        category: "REFUND",
        transactionType: "REVERSAL",
        transactionNumber: `REV-${voucher.number}`,
        amount: moneyR(amount),
        balanceBefore: dec(box.balance),
        partyType: voucher.supplierId ? "SUPPLIER" : voucher.customerId ? "CUSTOMER" : null,
        customerId: voucher.customerId,
        supplierId: voucher.supplierId,
        paymentVoucherId: voucher.id,
        paymentId: voucher.paymentId,
        idempotencyKey: `cancel:${voucher.id}`,
        note: `إلغاء ${voucher.number} — ${reason}`,
        userId: actor.userId,
      });
    }

    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "CANCEL",
          module: "finance",
          entityType: "payment_voucher",
          entityId: voucher.id,
          newValues: { reason, amount: num(amount) },
        }
      ),
    });
  });

  return { id: voucher.id, number: voucher.number, status: "CANCELLED" };
}

// =====================================================================
// 5) createCashTransfer — between two cashboxes (same or cross currency)
// =====================================================================
export interface CreateCashTransferInput {
  fromCashboxId: number;
  toCashboxId: number;
  branchId: number;
  amount: number;
  currency?: string;
  fromCurrency?: string | null;
  toCurrency?: string | null;
  exchangeRate?: number | null;
  sourceAmount?: number | null;
  targetAmount?: number | null;
  isBankDeposit?: boolean;
  isBankWithdrawal?: boolean;
  bankDepositRef?: string | null;
  bankWithdrawalRef?: string | null;
  referenceNumber?: string | null;
  description?: string | null;
  notes?: string | null;
  idempotencyKey?: string | null;
}

export async function createCashTransfer(actor: CashActor, input: CreateCashTransferInput) {
  const companyId = actor.companyId;
  if (input.fromCashboxId === input.toCashboxId) throw new ApiError("CASHBOX_005");
  const amount = moneyR(dec(input.amount));
  if (!amount.isPositive()) throw new ApiError("CASH_TRF_001");

  if (input.idempotencyKey) {
    const existing = await db.cashTransfer.findUnique({
      where: { companyId_idempotencyKey: { companyId, idempotencyKey: input.idempotencyKey } },
    });
    if (existing) return { id: existing.id, number: existing.number, duplicate: true };
  }

  const result = await db.$transaction(async (tx) => {
    const fromBox = await assertCashboxAccessible(tx, input.fromCashboxId, companyId);
    const toBox = await assertCashboxAccessible(tx, input.toCashboxId, companyId);

    const trfNumber = await nextDocumentNumber(tx, companyId, "CASH_TRANSFER");

    const transfer = await tx.cashTransfer.create({
      data: {
        companyId,
        branchId: input.branchId,
        number: trfNumber,
        transferDate: new Date(),
        fromCashboxId: fromBox.id,
        toCashboxId: toBox.id,
        amount,
        currency: input.currency ?? "IQD",
        fromCurrency: input.fromCurrency ?? fromBox.currency,
        toCurrency: input.toCurrency ?? toBox.currency,
        exchangeRate: input.exchangeRate ? dec(input.exchangeRate) : null,
        sourceAmount: input.sourceAmount ? dec(input.sourceAmount) : null,
        targetAmount: input.targetAmount ? dec(input.targetAmount) : amount,
        isBankDeposit: input.isBankDeposit ?? false,
        isBankWithdrawal: input.isBankWithdrawal ?? false,
        bankDepositRef: input.bankDepositRef ?? null,
        bankWithdrawalRef: input.bankWithdrawalRef ?? null,
        referenceNumber: input.referenceNumber ?? null,
        status: "POSTED",
        idempotencyKey: input.idempotencyKey ?? null,
        description: input.description,
        notes: input.notes,
        createdById: actor.userId,
      },
    });

    // OUT from source
    await postCashTransaction(tx, {
      companyId,
      cashboxId: fromBox.id,
      direction: "OUT",
      category: "OTHER",
      transactionType: "TRANSFER",
      transactionNumber: trfNumber,
      amount,
      balanceBefore: dec(fromBox.balance),
      cashTransferId: transfer.id,
      referenceNumber: input.referenceNumber ?? null,
      currency: input.fromCurrency ?? fromBox.currency,
      exchangeRate: input.exchangeRate ? dec(input.exchangeRate) : null,
      sourceCurrency: input.fromCurrency ?? fromBox.currency,
      targetCurrency: input.toCurrency ?? toBox.currency,
      idempotencyKey: `${input.idempotencyKey ?? trfNumber}:OUT`,
      note: `تحويل ${trfNumber} → ${toBox.name}`,
      userId: actor.userId,
    });

    // IN to destination (use targetAmount if cross-currency, else same amount)
    const inAmount = input.targetAmount ? moneyR(dec(input.targetAmount)) : amount;
    await postCashTransaction(tx, {
      companyId,
      cashboxId: toBox.id,
      direction: "IN",
      category: "OTHER",
      transactionType: "TRANSFER",
      transactionNumber: trfNumber,
      amount: inAmount,
      balanceBefore: dec(toBox.balance),
      cashTransferId: transfer.id,
      referenceNumber: input.referenceNumber ?? null,
      currency: input.toCurrency ?? toBox.currency,
      exchangeRate: input.exchangeRate ? dec(input.exchangeRate) : null,
      sourceCurrency: input.fromCurrency ?? fromBox.currency,
      targetCurrency: input.toCurrency ?? toBox.currency,
      idempotencyKey: `${input.idempotencyKey ?? trfNumber}:IN`,
      note: `استلام تحويل ${trfNumber} ← ${fromBox.name}`,
      userId: actor.userId,
    });

    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "CREATE",
          module: "finance",
          entityType: "cash_transfer",
          entityId: transfer.id,
          newValues: {
            number: trfNumber, from: fromBox.name, to: toBox.name,
            amount: num(amount), bankDeposit: input.isBankDeposit, bankWithdrawal: input.isBankWithdrawal,
          },
        }
      ),
    });

    return transfer;
  });

  return { id: result.id, number: result.number, amount: num(amount) };
}

// =====================================================================
// 6) cancelCashTransfer — reverse both legs
// =====================================================================
export async function cancelCashTransfer(actor: CashActor, transferId: number, reason: string) {
  if (!reason?.trim()) throw new ApiError("CASH_TRF_002", "سبب الإلغاء مطلوب");
  const companyId = actor.companyId;

  const transfer = await db.cashTransfer.findFirst({
    where: { id: transferId, companyId, deletedAt: null },
  });
  if (!transfer) throw new ApiError("VAL_003", "التحويل غير موجود");
  if (transfer.status === "CANCELLED") throw new ApiError("CASH_TRF_002");

  await db.$transaction(async (tx) => {
    const fromBox = await assertCashboxAccessible(tx, transfer.fromCashboxId, companyId, { allowClosed: true });
    const toBox = await assertCashboxAccessible(tx, transfer.toCashboxId, companyId, { allowClosed: true });

    await tx.cashTransfer.update({
      where: { id: transfer.id },
      data: {
        status: "CANCELLED",
        cancelReason: reason,
        cancelledById: actor.userId,
        cancelledAt: new Date(),
      },
    });

    const amount = dec(transfer.amount);
    // IN back to source (reverse the OUT leg)
    await postCashTransaction(tx, {
      companyId,
      cashboxId: fromBox.id,
      direction: "IN",
      category: "OTHER",
      transactionType: "REVERSAL",
      transactionNumber: `REV-${transfer.number}:FROM`,
      amount: moneyR(amount),
      balanceBefore: dec(fromBox.balance),
      cashTransferId: transfer.id,
      idempotencyKey: `cancel:${transfer.id}:FROM`,
      note: `إلغاء تحويل ${transfer.number} — ${reason}`,
      userId: actor.userId,
    });
    // OUT from destination (reverse the IN leg)
    const outAmount = transfer.targetAmount ? dec(transfer.targetAmount) : amount;
    await postCashTransaction(tx, {
      companyId,
      cashboxId: toBox.id,
      direction: "OUT",
      category: "OTHER",
      transactionType: "REVERSAL",
      transactionNumber: `REV-${transfer.number}:TO`,
      amount: moneyR(outAmount),
      balanceBefore: dec(toBox.balance),
      cashTransferId: transfer.id,
      idempotencyKey: `cancel:${transfer.id}:TO`,
      note: `إلغاء تحويل ${transfer.number} — ${reason}`,
      userId: actor.userId,
    });

    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "CANCEL",
          module: "finance",
          entityType: "cash_transfer",
          entityId: transfer.id,
          newValues: { reason, amount: num(amount) },
        }
      ),
    });
  });

  return { id: transfer.id, number: transfer.number, status: "CANCELLED" };
}

// =====================================================================
// 7) closeCashbox — daily closing with denomination counts
// =====================================================================
export interface DenominationInput {
  denomination: number; // face value (25000, 10000, 5000, 1000, 500, 250)
  count: number;
}

export interface CloseCashboxInput {
  cashboxId: number;
  branchId: number;
  closingDate?: Date | null;
  actualCash?: number | null; // if denominations provided, derived
  differenceReason?: string | null;
  denominations?: DenominationInput[];
  notes?: string | null;
  idempotencyKey?: string | null;
}

export async function closeCashbox(actor: CashActor, input: CloseCashboxInput) {
  const companyId = actor.companyId;
  const closingDate = input.closingDate ?? new Date();

  // Compute actual cash from denominations (or use direct actualCash)
  let actualCash = new Decimal(0);
  if (input.denominations && input.denominations.length) {
    for (const d of input.denominations) {
      actualCash = actualCash.plus(moneyR(dec(d.denomination).mul(d.count)));
    }
  } else if (input.actualCash != null) {
    actualCash = moneyR(dec(input.actualCash));
  } else {
    throw new ApiError("VAL_001", "يلزم تحديد الكمية الفعلية للنقد أو تفصيل الفئات");
  }

  const result = await db.$transaction(async (tx) => {
    const box = await assertCashboxAccessible(tx, input.cashboxId, companyId, { allowClosed: true });

    // Compute book balance since last closing (or opening)
    const lastClosing = await tx.cashboxClosing.findFirst({
      where: { cashboxId: box.id, status: "CLOSED" },
      orderBy: { closingDate: "desc" },
    });
    const openingBalance = lastClosing
      ? dec(lastClosing.bookBalance)
      : dec(box.openingBalance);

    const txs = await tx.cashTransaction.findMany({
      where: {
        cashboxId: box.id,
        createdAt: { gt: lastClosing?.closingDate ?? new Date(0) },
        isReversed: false,
      },
    });
    let totalReceipts = new Decimal(0);
    let totalPayments = new Decimal(0);
    let transfersIn = new Decimal(0);
    let transfersOut = new Decimal(0);
    for (const t of txs) {
      if (t.direction === "IN") {
        if (t.transactionType === "TRANSFER") transfersIn = transfersIn.plus(dec(t.amount));
        else totalReceipts = totalReceipts.plus(dec(t.amount));
      } else {
        if (t.transactionType === "TRANSFER") transfersOut = transfersOut.plus(dec(t.amount));
        else totalPayments = totalPayments.plus(dec(t.amount));
      }
    }
    const bookBalance = moneyR(
      openingBalance.plus(totalReceipts).minus(totalPayments).plus(transfersIn).minus(transfersOut)
    );
    const difference = moneyR(actualCash.minus(bookBalance));

    const closNumber = await nextDocumentNumber(tx, companyId, "CLOSING");
    const closing = await tx.cashboxClosing.create({
      data: {
        companyId,
        branchId: input.branchId,
        cashboxId: box.id,
        number: closNumber,
        closingDate,
        openingBalance: moneyR(openingBalance),
        totalReceipts: moneyR(totalReceipts),
        totalPayments: moneyR(totalPayments),
        transfersIn: moneyR(transfersIn),
        transfersOut: moneyR(transfersOut),
        bookBalance,
        actualCash,
        difference,
        differenceReason: input.differenceReason ?? null,
        denominationTotal: input.denominations?.length ? actualCash : null,
        status: "CLOSED",
        closedAt: new Date(),
        closedById: actor.userId,
        notes: input.notes,
      },
    });

    if (input.denominations?.length) {
      for (const d of input.denominations) {
        await tx.cashboxDenominationCount.create({
          data: {
            companyId,
            closingId: closing.id,
            cashboxId: box.id,
            denomination: moneyR(d.denomination),
            count: d.count,
            total: moneyR(dec(d.denomination).mul(d.count)),
            countedById: actor.userId,
          },
        });
      }
    }

    // Optional: suspend the cashbox (CLOSED) when closing — reopening reactivates
    await tx.cashbox.update({
      where: { id: box.id },
      data: { status: "CLOSED" },
    });

    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "POST",
          module: "finance",
          entityType: "cashbox_closing",
          entityId: closing.id,
          newValues: {
            number: closNumber, book: num(bookBalance), actual: num(actualCash),
            difference: num(difference),
          },
        }
      ),
    });

    return closing;
  });

  return {
    id: result.id, number: result.number,
    book_balance: num(result.bookBalance), actual_cash: num(result.actualCash),
    difference: num(result.difference), status: result.status,
  };
}

// =====================================================================
// 8) reopenCashbox — CLOSED → REOPENED (books untouched)
// =====================================================================
export async function reopenCashbox(actor: CashActor, closingId: number, reason: string) {
  const companyId = actor.companyId;
  const closing = await db.cashboxClosing.findFirst({
    where: { id: closingId, companyId, deletedAt: null },
  });
  if (!closing) throw new ApiError("VAL_003", "الإغلاق غير موجود");
  if (closing.status !== "CLOSED") throw new ApiError("CLOSING_001");

  await db.$transaction(async (tx) => {
    await tx.cashboxClosing.update({
      where: { id: closing.id },
      data: {
        status: "REOPENED",
        reopenedAt: new Date(),
        reopenedById: actor.userId,
        reopenReason: reason,
      },
    });
    await tx.cashbox.update({
      where: { id: closing.cashboxId },
      data: { status: "ACTIVE" },
    });
    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "POST",
          module: "finance",
          entityType: "cashbox_closing_reopen",
          entityId: closing.id,
          newValues: { reason },
        }
      ),
    });
  });

  return { id: closing.id, number: closing.number, status: "REOPENED" };
}

// =====================================================================
// 9) customerStatement / supplierStatement — ledger with running balance
// =====================================================================
export interface StatementOptions {
  fromDate?: Date | null;
  toDate?: Date | null;
  toTime?: Date | null; // alias for toDate (kept for compatibility)
  limit?: number;
}

interface StatementRow {
  date: string;
  kind: "INVOICE" | "RETURN" | "COLLECTION" | "PAYMENT";
  ref: string;
  description: string;
  debit: number; // owed by customer (invoice / charged expense)
  credit: number; // paid by customer (collection / refund reversal)
  running: number; // running balance after row
}

function buildRunning(rows: { date: string; kind: StatementRow["kind"]; ref: string; description: string; amount: Decimal; isDebit: boolean }[], opening: Decimal): StatementRow[] {
  let bal = opening;
  return rows.map((r) => {
    bal = r.isDebit ? bal.plus(r.amount) : bal.minus(r.amount);
    return {
      date: r.date, kind: r.kind, ref: r.ref, description: r.description,
      debit: r.isDebit ? num(moneyR(r.amount)) : 0,
      credit: r.isDebit ? 0 : num(moneyR(r.amount)),
      running: num(moneyR(bal)),
    };
  });
}

export async function customerStatement(
  companyId: number,
  customerId: number,
  opts: StatementOptions = {}
) {
  const from = opts.fromDate ?? new Date(0);
  const to = opts.toTime ?? opts.toDate ?? new Date();
  const limit = opts.limit ?? 1000;

  const [customer, invoices, collections, returns] = await Promise.all([
    db.customer.findFirst({ where: { id: customerId, companyId, deletedAt: null } }),
    db.salesInvoice.findMany({
      where: { customerId, companyId, deletedAt: null, invoiceDate: { gte: from, lte: to } },
      select: { number: true, invoiceDate: true, grandTotal: true },
      take: limit,
    }),
    db.cashTransaction.findMany({
      where: { customerId, companyId, direction: "IN", category: "COLLECTION", createdAt: { gte: from, lte: to }, isReversed: false },
      select: { transactionNumber: true, createdAt: true, amount: true, note: true },
      take: limit,
    }),
    db.salesReturn.findMany({
      where: { customerId, companyId, deletedAt: null, returnDate: { gte: from, lte: to } },
      select: { number: true, returnDate: true, totalAmount: true },
      take: limit,
    }),
  ]);
  if (!customer) throw new ApiError("VAL_003", "العميل غير موجود");

  const events: { date: string; kind: StatementRow["kind"]; ref: string; description: string; amount: Decimal; isDebit: boolean }[] = [];
  for (const i of invoices) events.push({
    date: i.invoiceDate.toISOString().slice(0, 10),
    kind: "INVOICE", ref: i.number, description: "فاتورة مبيعات",
    amount: dec(i.grandTotal), isDebit: true,
  });
  for (const c of collections) events.push({
    date: c.createdAt.toISOString().slice(0, 10),
    kind: "COLLECTION", ref: c.transactionNumber ?? "", description: c.note ?? "تحصيل",
    amount: dec(c.amount), isDebit: false,
  });
  for (const r of returns) events.push({
    date: r.returnDate.toISOString().slice(0, 10),
    kind: "RETURN", ref: r.number, description: "مرتجع مبيعات",
    amount: dec(r.totalAmount), isDebit: false,
  });
  events.sort((a, b) => a.date.localeCompare(b.date));

  const rows = buildRunning(events, dec(customer.balance).minus(sumOf(events.filter(e => !e.isDebit), e => e.amount)).plus(sumOf(events.filter(e => e.isDebit), e => e.amount)));
  const totals = {
    debit: num(moneyR(sumOf(rows, r => r.debit))),
    credit: num(moneyR(sumOf(rows, r => r.credit))),
  };

  return {
    customer: { id: customer.id, code: customer.code, name: customer.name, phone: customer.phone, balance: num(dec(customer.balance)), creditLimit: num(dec(customer.creditLimit)), creditDays: customer.creditDays },
    rows,
    totals,
    opening_balance: rows.length ? num(moneyR(dec(rows[0].running).minus(rows[0].debit).plus(rows[0].credit))) : num(dec(customer.balance)),
    closing_balance: rows.length ? rows[rows.length - 1].running : num(dec(customer.balance)),
  };
}

export async function supplierStatement(
  companyId: number,
  supplierId: number,
  opts: StatementOptions = {}
) {
  const from = opts.fromDate ?? new Date(0);
  const to = opts.toTime ?? opts.toDate ?? new Date();
  const limit = opts.limit ?? 1000;

  const [supplier, invoices, payments] = await Promise.all([
    db.supplier.findFirst({ where: { id: supplierId, companyId, deletedAt: null } }),
    db.purchaseInvoice.findMany({
      where: { supplierId, companyId, deletedAt: null, invoiceDate: { gte: from, lte: to } },
      select: { number: true, invoiceDate: true, grandTotal: true },
      take: limit,
    }),
    db.cashTransaction.findMany({
      where: { supplierId, companyId, direction: "OUT", category: "SUPPLIER_PAYMENT", createdAt: { gte: from, lte: to }, isReversed: false },
      select: { transactionNumber: true, createdAt: true, amount: true, note: true },
      take: limit,
    }),
  ]);
  if (!supplier) throw new ApiError("VAL_003", "المورد غير موجود");

  const events: { date: string; kind: StatementRow["kind"]; ref: string; description: string; amount: Decimal; isDebit: boolean }[] = [];
  for (const i of invoices) events.push({
    date: i.invoiceDate.toISOString().slice(0, 10),
    kind: "INVOICE", ref: i.number, description: "فاتورة شراء",
    amount: dec(i.grandTotal), isDebit: true,
  });
  for (const p of payments) events.push({
    date: p.createdAt.toISOString().slice(0, 10),
    kind: "PAYMENT", ref: p.transactionNumber ?? "", description: p.note ?? "سداد",
    amount: dec(p.amount), isDebit: false,
  });
  events.sort((a, b) => a.date.localeCompare(b.date));

  const rows = buildRunning(events, dec(supplier.balance).minus(sumOf(events.filter(e => !e.isDebit), e => e.amount)).plus(sumOf(events.filter(e => e.isDebit), e => e.amount)));
  const totals = {
    debit: num(moneyR(sumOf(rows, r => r.debit))),
    credit: num(moneyR(sumOf(rows, r => r.credit))),
  };

  return {
    supplier: { id: supplier.id, code: supplier.code, name: supplier.name, phone: supplier.phone, balance: num(dec(supplier.balance)) },
    rows,
    totals,
    opening_balance: rows.length ? num(moneyR(dec(rows[0].running).minus(rows[0].debit).plus(rows[0].credit))) : num(dec(supplier.balance)),
    closing_balance: rows.length ? rows[rows.length - 1].running : num(dec(supplier.balance)),
  };
}

// =====================================================================
// 10) aging — 5 buckets (current, 1-30, 31-60, 61-90, 90+)
// =====================================================================
export interface AgingBucket {
  current: number;
  d1_30: number;
  d31_60: number;
  d61_90: number;
  d90_plus: number;
}
export interface CustomerAgingRow {
  customer_id: number;
  code: string;
  name: string;
  balance: number;
  buckets: AgingBucket;
}

export async function customerAging(companyId: number): Promise<{ rows: CustomerAgingRow[]; totals: AgingBucket }> {
  const today = new Date();
  const customers = await db.customer.findMany({
    where: { companyId, deletedAt: null, balance: { gt: 0 } },
    select: { id: true, code: true, name: true, balance: true },
  });
  const customerIds = customers.map((c) => c.id);
  const invoices = await db.salesInvoice.findMany({
    where: { companyId, deletedAt: null, customerId: { in: customerIds }, type: { not: "CASH" } },
    select: { id: true, customerId: true, number: true, grandTotal: true, paidAmount: true, invoiceDate: true },
  });

  const byCustomer = new Map<number, AgingBucket & { balance: Decimal }>();
  for (const c of customers) byCustomer.set(c.id, { balance: dec(c.balance), current: 0, d1_30: 0, d31_60: 0, d61_90: 0, d90_plus: 0 });

  for (const inv of invoices) {
    const due = moneyR(dec(inv.grandTotal).minus(inv.paidAmount));
    if (!due.isPositive()) continue;
    const age = Math.floor((today.getTime() - inv.invoiceDate.getTime()) / (24 * 3600 * 1000));
    const bucket = byCustomer.get(inv.customerId);
    if (!bucket) continue;
    if (age <= 0) bucket.current = num(moneyR(dec(bucket.current).plus(due)));
    else if (age <= 30) bucket.d1_30 = num(moneyR(dec(bucket.d1_30).plus(due)));
    else if (age <= 60) bucket.d31_60 = num(moneyR(dec(bucket.d31_60).plus(due)));
    else if (age <= 90) bucket.d61_90 = num(moneyR(dec(bucket.d61_90).plus(due)));
    else bucket.d90_plus = num(moneyR(dec(bucket.d90_plus).plus(due)));
  }

  const rows: CustomerAgingRow[] = [];
  const totals: AgingBucket = { current: 0, d1_30: 0, d31_60: 0, d61_90: 0, d90_plus: 0 };
  for (const c of customers) {
    const b = byCustomer.get(c.id)!;
    rows.push({
      customer_id: c.id, code: c.code, name: c.name,
      balance: num(moneyR(b.balance)),
      buckets: { current: b.current, d1_30: b.d1_30, d31_60: b.d31_60, d61_90: b.d61_90, d90_plus: b.d90_plus },
    });
    totals.current += b.current;
    totals.d1_30 += b.d1_30;
    totals.d31_60 += b.d31_60;
    totals.d61_90 += b.d61_90;
    totals.d90_plus += b.d90_plus;
  }
  return { rows, totals };
}

export interface SupplierAgingRow {
  supplier_id: number;
  code: string;
  name: string;
  balance: number;
  buckets: AgingBucket;
}

export async function supplierAging(companyId: number): Promise<{ rows: SupplierAgingRow[]; totals: AgingBucket }> {
  const today = new Date();
  const suppliers = await db.supplier.findMany({
    where: { companyId, deletedAt: null, balance: { gt: 0 } },
    select: { id: true, code: true, name: true, balance: true },
  });
  const supplierIds = suppliers.map((s) => s.id);
  const invoices = await db.purchaseInvoice.findMany({
    where: { companyId, deletedAt: null, supplierId: { in: supplierIds } },
    select: { id: true, supplierId: true, number: true, grandTotal: true, paidAmount: true, invoiceDate: true },
  });

  const bySupplier = new Map<number, AgingBucket & { balance: Decimal }>();
  for (const s of suppliers) bySupplier.set(s.id, { balance: dec(s.balance), current: 0, d1_30: 0, d31_60: 0, d61_90: 0, d90_plus: 0 });

  for (const inv of invoices) {
    const due = moneyR(dec(inv.grandTotal).minus(inv.paidAmount));
    if (!due.isPositive()) continue;
    const age = Math.floor((today.getTime() - inv.invoiceDate.getTime()) / (24 * 3600 * 1000));
    const bucket = bySupplier.get(inv.supplierId);
    if (!bucket) continue;
    if (age <= 0) bucket.current = num(moneyR(dec(bucket.current).plus(due)));
    else if (age <= 30) bucket.d1_30 = num(moneyR(dec(bucket.d1_30).plus(due)));
    else if (age <= 60) bucket.d31_60 = num(moneyR(dec(bucket.d31_60).plus(due)));
    else if (age <= 90) bucket.d61_90 = num(moneyR(dec(bucket.d61_90).plus(due)));
    else bucket.d90_plus = num(moneyR(dec(bucket.d90_plus).plus(due)));
  }

  const rows: SupplierAgingRow[] = [];
  const totals: AgingBucket = { current: 0, d1_30: 0, d31_60: 0, d61_90: 0, d90_plus: 0 };
  for (const s of suppliers) {
    const b = bySupplier.get(s.id)!;
    rows.push({
      supplier_id: s.id, code: s.code, name: s.name,
      balance: num(moneyR(b.balance)),
      buckets: { current: b.current, d1_30: b.d1_30, d31_60: b.d31_60, d61_90: b.d61_90, d90_plus: b.d90_plus },
    });
    totals.current += b.current;
    totals.d1_30 += b.d1_30;
    totals.d31_60 += b.d31_60;
    totals.d61_90 += b.d61_90;
    totals.d90_plus += b.d90_plus;
  }
  return { rows, totals };
}

// =====================================================================
// 11) allocatePayment — allocate unallocated payment amount to invoices
// =====================================================================
export async function allocatePayment(
  actor: CashActor,
  paymentId: number,
  allocations: ReceiptAllocationInput[]
) {
  const companyId = actor.companyId;
  const payment = await db.payment.findFirst({
    where: { id: paymentId, companyId, deletedAt: null },
    include: { allocations: true },
  });
  if (!payment) throw new ApiError("PAYMENT_003");
  if (payment.status === "CANCELLED") throw new ApiError("PAYMENT_002");

  const alreadyAllocated = sumOf(payment.allocations, (a) => dec(a.allocatedAmount));
  const remaining = moneyR(dec(payment.totalAmount).minus(alreadyAllocated));
  const newAllocTotal = sumOf(allocations, (a) => dec(a.amount));
  if (newAllocTotal.gt(remaining.plus("0.01"))) {
    throw new ApiError("PAYMENT_001", "إجمالي التخصيص الجديد يتجاوز المبلغ المتبقي من الدفعة");
  }

  await db.$transaction(async (tx) => {
    for (const a of allocations) {
      const inv = await loadInvoice(companyId, a);
      const allocAmt = moneyR(a.amount);
      if (allocAmt.gt(inv.due.plus("0.01"))) {
        throw new ApiError("PAYMENT_001", `تخصيص يتجاوز المتبقي على الفاتورة ${inv.number}`);
      }
      await tx.paymentAllocation.create({
        data: {
          companyId,
          paymentId,
          invoiceType: a.invoiceType,
          salesInvoiceId: a.invoiceType === "SALES" ? a.invoiceId : null,
          purchaseInvoiceId: a.invoiceType === "PURCHASE" ? a.invoiceId : null,
          allocatedAmount: allocAmt,
          invoiceNumber: inv.number,
          invoiceTotal: num(inv.grandTotal),
          previouslyPaid: num(inv.paidAmount),
          remainingAfter: num(moneyR(inv.due.minus(allocAmt))),
        },
      });
      if (a.invoiceType === "SALES") {
        await tx.salesInvoice.update({
          where: { id: a.invoiceId },
          data: { paidAmount: { increment: allocAmt } },
        });
      } else {
        await tx.purchaseInvoice.update({
          where: { id: a.invoiceId },
          data: { paidAmount: { increment: allocAmt } },
        });
      }
    }
    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "POST",
          module: "finance",
          entityType: "payment_allocation",
          entityId: paymentId,
          newValues: { allocations: allocations.length, total: num(newAllocTotal) },
        }
      ),
    });
  });

  return { payment_id: paymentId, allocated_count: allocations.length, allocated_total: num(moneyR(newAllocTotal)) };
}

// helper used in customerStatement/supplierStatement: noop re-export kept
// for callers that already import from this module path.
export { DOC_TYPES };

// =====================================================================
// 10) editCashbox — PATCH cashbox metadata (Phase 67 / Phase 71 #2)
//     Only editable fields: name, code, currency, description, type,
//     ownerUserId, warehouseId, status (ACTIVE/SUSPENDED). balance is
//     NEVER directly editable — it's derived from CashTransaction rows.
// =====================================================================
export interface EditCashboxInput {
  name?: string;
  code?: string;
  type?: "MAIN" | "BRANCH" | "REP" | "CUSTOM" | "BANK";
  currency?: "IQD" | "USD";
  description?: string | null;
  ownerUserId?: number | null;
  warehouseId?: number | null;
  status?: "ACTIVE" | "SUSPENDED";
  isActive?: boolean;
}

export async function editCashbox(
  actor: CashActor,
  cashboxId: number,
  patch: EditCashboxInput
) {
  const companyId = actor.companyId;

  // Sanity: at least one field is being updated
  const touched = Object.keys(patch).filter((k) => patch[k as keyof EditCashboxInput] !== undefined);
  if (!touched.length) throw new ApiError("VAL_001", "لا حقول للتعديل");

  const updated = await db.$transaction(async (tx) => {
    const box = await assertCashboxAccessible(tx, cashboxId, companyId, { allowClosed: true });
    const before = {
      name: box.name,
      code: box.code,
      type: box.type,
      currency: box.currency,
      description: box.description,
      ownerUserId: box.ownerUserId,
      warehouseId: box.warehouseId,
      status: box.status,
      isActive: box.isActive,
    };

    const data: Prisma.CashboxUpdateInput = {};
    if (patch.name !== undefined) data.name = patch.name;
    if (patch.code !== undefined) data.code = patch.code;
    if (patch.type !== undefined) data.type = patch.type;
    if (patch.currency !== undefined) data.currency = patch.currency;
    if (patch.description !== undefined) data.description = patch.description;
    if (patch.isActive !== undefined) data.isActive = patch.isActive;
    if (patch.status !== undefined) data.status = patch.status;
    if (patch.ownerUserId !== undefined) {
      data.owner = patch.ownerUserId == null
        ? { disconnect: true }
        : { connect: { id: patch.ownerUserId } };
    }
    if (patch.warehouseId !== undefined) {
      data.warehouse = patch.warehouseId == null
        ? { disconnect: true }
        : { connect: { id: patch.warehouseId } };
    }
    data.updatedBy = actor.userId;

    const row = await tx.cashbox.update({ where: { id: box.id }, data });

    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "UPDATE",
          module: "finance",
          entityType: "cashbox",
          entityId: box.id,
          oldValues: before,
          newValues: {
            name: row.name, code: row.code, type: row.type, currency: row.currency,
            description: row.description, ownerUserId: row.ownerUserId,
            warehouseId: row.warehouseId, status: row.status, isActive: row.isActive,
          },
        }
      ),
    });

    return row;
  });

  return {
    id: updated.id,
    code: updated.code,
    name: updated.name,
    type: updated.type,
    currency: updated.currency,
    status: updated.status,
    is_active: updated.isActive,
  };
}

// =====================================================================
// 11) reconcileCashbox — compute book balance vs actual cash WITHOUT
//     closing. Pure read for inspection (Phase 67 /cash-reconciliation).
//     Returns the same shape closeCashbox computes, persisted as a
//     DRAFT closing record (status DRAFT, not CLOSED).
// =====================================================================
export interface ReconcileInput {
  cashboxId: number;
  closingDate?: Date | null;
  actualCash?: number | null;
  denominations?: DenominationInput[];
  notes?: string | null;
}

export async function reconcileCashbox(actor: CashActor, input: ReconcileInput) {
  const companyId = actor.companyId;
  const closingDate = input.closingDate ?? new Date();

  let actualCash = new Decimal(0);
  if (input.denominations && input.denominations.length) {
    for (const d of input.denominations) {
      actualCash = actualCash.plus(moneyR(dec(d.denomination).mul(d.count)));
    }
  } else if (input.actualCash != null) {
    actualCash = moneyR(dec(input.actualCash));
  } else {
    throw new ApiError("VAL_001", "يلزم تحديد الكمية الفعلية للنقد أو تفصيل الفئات");
  }

  return db.$transaction(async (tx) => {
    const box = await assertCashboxAccessible(tx, input.cashboxId, companyId, { allowClosed: true });

    const lastClosing = await tx.cashboxClosing.findFirst({
      where: { cashboxId: box.id, status: "CLOSED" },
      orderBy: { closingDate: "desc" },
    });
    const openingBalance = lastClosing
      ? dec(lastClosing.bookBalance)
      : dec(box.openingBalance);

    const txs = await tx.cashTransaction.findMany({
      where: {
        cashboxId: box.id,
        createdAt: { gt: lastClosing?.closingDate ?? new Date(0) },
        isReversed: false,
      },
    });
    let totalReceipts = new Decimal(0);
    let totalPayments = new Decimal(0);
    let transfersIn = new Decimal(0);
    let transfersOut = new Decimal(0);
    for (const t of txs) {
      if (t.direction === "IN") {
        if (t.transactionType === "TRANSFER") transfersIn = transfersIn.plus(dec(t.amount));
        else totalReceipts = totalReceipts.plus(dec(t.amount));
      } else {
        if (t.transactionType === "TRANSFER") transfersOut = transfersOut.plus(dec(t.amount));
        else totalPayments = totalPayments.plus(dec(t.amount));
      }
    }
    const bookBalance = moneyR(
      openingBalance.plus(totalReceipts).minus(totalPayments).plus(transfersIn).minus(transfersOut)
    );
    const difference = moneyR(actualCash.minus(bookBalance));

    const closNumber = await nextDocumentNumber(tx, companyId, "CLOSING");
    const closing = await tx.cashboxClosing.create({
      data: {
        companyId,
        branchId: actor.branchId ?? box.branchId,
        cashboxId: box.id,
        number: closNumber,
        closingDate,
        openingBalance: moneyR(openingBalance),
        totalReceipts: moneyR(totalReceipts),
        totalPayments: moneyR(totalPayments),
        transfersIn: moneyR(transfersIn),
        transfersOut: moneyR(transfersOut),
        bookBalance,
        actualCash,
        difference,
        denominationTotal: input.denominations?.length ? actualCash : null,
        status: "DRAFT", // Reconciliation is DRAFT — close moves it to CLOSED
        notes: input.notes,
      },
    });

    if (input.denominations?.length) {
      for (const d of input.denominations) {
        await tx.cashboxDenominationCount.create({
          data: {
            companyId,
            closingId: closing.id,
            cashboxId: box.id,
            denomination: moneyR(d.denomination),
            count: d.count,
            total: moneyR(dec(d.denomination).mul(d.count)),
            countedById: actor.userId,
          },
        });
      }
    }

    return {
      id: closing.id,
      number: closing.number,
      cashbox_id: box.id,
      cashbox_name: box.name,
      opening_balance: num(openingBalance),
      total_receipts: num(totalReceipts),
      total_payments: num(totalPayments),
      transfers_in: num(transfersIn),
      transfers_out: num(transfersOut),
      book_balance: num(bookBalance),
      actual_cash: num(actualCash),
      difference: num(difference),
      status: "DRAFT",
    };
  });
}

// =====================================================================
// 12) listCashboxTransactions — ledger scoped to ONE cashbox (Phase 67
//     /cashboxes/[id]/transactions). Returns latest N (default 100)
//     CashTransaction rows with party + reference resolution.
// =====================================================================
export async function listCashboxTransactions(
  actor: CashActor,
  cashboxId: number,
  opts: { limit?: number; offset?: number; fromDate?: Date | null; toDate?: Date | null } = {}
) {
  const companyId = actor.companyId;
  const limit = Math.min(opts.limit ?? 100, 500);
  const offset = Math.max(0, opts.offset ?? 0);

  const where: Prisma.CashTransactionWhereInput = {
    companyId,
    cashboxId,
    ...(opts.fromDate || opts.toDate
      ? { createdAt: { ...(opts.fromDate ? { gte: opts.fromDate } : {}), ...(opts.toDate ? { lte: opts.toDate } : {}) } }
      : {}),
  };

  const [rows, total] = await Promise.all([
    db.cashTransaction.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: limit,
      skip: offset,
      include: {
        customer: { select: { id: true, name: true, code: true } },
        supplier: { select: { id: true, name: true, code: true } },
      },
    }),
    db.cashTransaction.count({ where }),
  ]);

  return {
    total,
    limit,
    offset,
    rows: rows.map((t) => ({
      id: t.id,
      direction: t.direction,
      category: t.category,
      transaction_type: t.transactionType,
      transaction_number: t.transactionNumber,
      amount: num(t.amount),
      balance_before: t.balanceBefore ? num(t.balanceBefore) : null,
      balance_after: num(t.balanceAfter),
      currency: t.currency,
      exchange_rate: t.exchangeRate ? num(t.exchangeRate) : null,
      reference_number: t.referenceNumber,
      party_type: t.partyType,
      customer: t.customer,
      supplier: t.supplier,
      note: t.note,
      is_reversed: t.isReversed,
      created_at: t.createdAt.toISOString(),
    })),
  };
}
