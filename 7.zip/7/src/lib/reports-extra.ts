// @ts-nocheck
// =====================================================================
// Reports engine — extended catalog (completion phase).
// Implements the remaining §37 reports from the comprehensive spec:
//   Sales       : monthly-sales · sales-by-customer · sales-by-category
//                 sales-by-branch · sales-by-payment-method
//   Inventory   : stock-balance · stock-ledger · low-stock · out-of-stock
//                 dead-stock · transfers-report · adjustments-report
//                 damages-report · returns-report
//   Finance     : receivables · payables · collections-report
//                 expenses-report · cashbox-report
//   Field/Reps  : rep-targets · rep-commissions · rep-visits
//                 rep-customers · rep-returns
// Every handler returns { rows, summary? } so the generic UI renderer
// and the CSV exporter work uniformly.
// =====================================================================

import { db } from "./db";
import { Decimal, dec, moneyR, qtyR, sumOf, num } from "./decimal";

interface SessionLike {
  companyId: number;
  userId: number;
  warehouseIds: number[];
  // ---- Multi-Branch scope (Phase 37 — export scope) ---------------------
  branchIds?: number[];
  activeBranchId?: number | null;
}

type ExtraHandler = (
  session: SessionLike,
  url: URL
) => Promise<{ rows?: unknown[]; summary?: Record<string, number | string>; meta?: Record<string, unknown> } | null>;

const daysAgo = (n: number) => {
  const d = new Date();
  d.setDate(d.getDate() - n);
  d.setHours(0, 0, 0, 0);
  return d;
};

const monthKey = (d: Date) => d.toISOString().slice(0, 7);

/** Effective branch set of the reporting session (Phase 12/37). */
function effBranchIds(s: SessionLike): number[] | null {
  if (s.activeBranchId != null) return [s.activeBranchId];
  if (s.branchIds && s.branchIds.length) return s.branchIds;
  return null; // no branch info → company-wide (backward compatible)
}

// ---------------------------------------------------------------------
// SALES
// ---------------------------------------------------------------------
const monthlySales: ExtraHandler = async (session) => {
  const since = daysAgo(364);
  const rows = await db.salesInvoice.findMany({
    where: { companyId: session.companyId, deletedAt: null, invoiceDate: { gte: since }, ...(effBranchIds(session) ? { branchId: { in: effBranchIds(session)! } } : {}) },
    select: { invoiceDate: true, grandTotal: true, type: true },
  });

  const months = new Map<string, { month: string; count: number; total: Decimal; cash: Decimal; credit: Decimal }>();
  const start = new Date(since.getFullYear(), since.getMonth(), 1);
  for (let i = 0; i < 12; i++) {
    const d = new Date(start.getFullYear(), start.getMonth() + i, 1);
    months.set(monthKey(d), { month: monthKey(d), count: 0, total: new Decimal(0), cash: new Decimal(0), credit: new Decimal(0) });
  }
  for (const r of rows) {
    const k = monthKey(r.invoiceDate);
    const b = months.get(k);
    if (!b) continue;
    b.count += 1;
    b.total = b.total.plus(r.grandTotal);
    if (r.type === "CASH") b.cash = b.cash.plus(r.grandTotal);
    else b.credit = b.credit.plus(r.grandTotal);
  }
  const list = [...months.values()];
  return {
    rows: list.map((m) => ({
      month: m.month, count: m.count,
      total: num(moneyR(m.total)), cash: num(moneyR(m.cash)), credit: num(moneyR(m.credit)),
    })),
    summary: {
      months_with_sales: list.filter((m) => m.count > 0).length,
      total: num(moneyR(sumOf(list, (m) => m.total))),
      best_month_total: num(moneyR(Decimal.max(new Decimal(0), ...list.map((m) => m.total)))),
      invoice_count: list.reduce((s, m) => s + m.count, 0),
    },
  };
};

const salesByCustomer: ExtraHandler = async (session) => {
  const invoices = await db.salesInvoice.findMany({
    where: { companyId: session.companyId, deletedAt: null, ...(effBranchIds(session) ? { branchId: { in: effBranchIds(session)! } } : {}) },
    select: { customerId: true, grandTotal: true, paidAmount: true, customer: { select: { code: true, name: true } } },
  });
  const agg = new Map<number, { code: string; name: string; invoices: number; revenue: Decimal; paid: Decimal; due: Decimal }>();
  for (const r of invoices) {
    const cur = agg.get(r.customerId) ?? { code: r.customer.code, name: r.customer.name, invoices: 0, revenue: new Decimal(0), paid: new Decimal(0), due: new Decimal(0) };
    cur.invoices += 1;
    cur.revenue = cur.revenue.plus(r.grandTotal);
    cur.paid = cur.paid.plus(r.paidAmount);
    cur.due = cur.due.plus(Decimal.max(0, dec(r.grandTotal).minus(r.paidAmount)));
    agg.set(r.customerId, cur);
  }
  const top = [...agg.values()].sort((a, b) => num(b.revenue.minus(a.revenue))).slice(0, 30);
  return {
    rows: top.map((r) => ({
      code: r.code, name: r.name, invoices: r.invoices,
      revenue: num(moneyR(r.revenue)), paid: num(moneyR(r.paid)), due: num(moneyR(r.due)),
    })),
    summary: {
      customers_with_sales: agg.size,
      total_revenue: num(moneyR(sumOf(top, (r) => r.revenue))),
      total_due: num(moneyR(sumOf(top, (r) => r.due))),
    },
  };
};

const salesByCategory: ExtraHandler = async (session) => {
  const lines = await db.salesInvoiceLine.findMany({
    where: { invoice: { companyId: session.companyId, deletedAt: null } },
    select: { qty: true, lineTotal: true, product: { select: { category: { select: { name: true } } } } },
  });
  const agg = new Map<string, { category: string; qty: Decimal; revenue: Decimal }>();
  for (const l of lines) {
    const name = l.product.category?.name ?? "بدون تصنيف";
    const cur = agg.get(name) ?? { category: name, qty: new Decimal(0), revenue: new Decimal(0) };
    cur.qty = cur.qty.plus(l.qty);
    cur.revenue = cur.revenue.plus(l.lineTotal);
    agg.set(name, cur);
  }
  const rows = [...agg.values()].sort((a, b) => num(b.revenue.minus(a.revenue)));
  const totalRev = sumOf(rows, (r) => r.revenue);
  return {
    rows: rows.map((r) => ({
      category: r.category, qty: num(qtyR(r.qty)), revenue: num(moneyR(r.revenue)),
      share_pct: totalRev.isPositive() ? num(r.revenue.div(totalRev).mul(1000).toDecimalPlaces(0, Decimal.ROUND_HALF_UP).div(10)) : 0,
    })),
    summary: { categories: rows.length, total_revenue: num(moneyR(totalRev)) },
  };
};

const salesByBranch: ExtraHandler = async (session) => {
  const invoices = await db.salesInvoice.findMany({
    where: { companyId: session.companyId, deletedAt: null, ...(effBranchIds(session) ? { branchId: { in: effBranchIds(session)! } } : {}) },
    select: { branchId: true, grandTotal: true, paidAmount: true, branch: { select: { code: true, name: true } } },
  });
  const agg = new Map<number, { code: string; branch: string; invoices: number; revenue: Decimal; collected: Decimal }>();
  for (const r of invoices) {
    const cur = agg.get(r.branchId) ?? { code: r.branch.code, branch: r.branch.name, invoices: 0, revenue: new Decimal(0), collected: new Decimal(0) };
    cur.invoices += 1;
    cur.revenue = cur.revenue.plus(r.grandTotal);
    cur.collected = cur.collected.plus(r.paidAmount);
    agg.set(r.branchId, cur);
  }
  const rows = [...agg.values()].sort((a, b) => num(b.revenue.minus(a.revenue)));
  return {
    rows: rows.map((r) => ({
      code: r.code, branch: r.branch, invoices: r.invoices,
      revenue: num(moneyR(r.revenue)), collected: num(moneyR(r.collected)),
    })),
    summary: { branches: rows.length, total_revenue: num(moneyR(sumOf(rows, (r) => r.revenue))) },
  };
};

const salesByPaymentMethod: ExtraHandler = async (session) => {
  const invoices = await db.salesInvoice.findMany({
    where: { companyId: session.companyId, deletedAt: null, ...(effBranchIds(session) ? { branchId: { in: effBranchIds(session)! } } : {}) },
    select: { type: true, grandTotal: true },
  });
  const cash = invoices.filter((i) => i.type === "CASH");
  const credit = invoices.filter((i) => i.type !== "CASH");
  const sum = (a: typeof invoices) => sumOf(a, (i) => i.grandTotal);
  const cashSum = moneyR(sum(cash));
  const creditSum = moneyR(sum(credit));
  const total = moneyR(cashSum.plus(creditSum));
  const share = (part: Decimal) => total.isPositive() ? num(part.div(total).mul(1000).toDecimalPlaces(0, Decimal.ROUND_HALF_UP).div(10)) : 0;
  return {
    rows: [
      { method: "نقدي", count: cash.length, total: num(cashSum), share_pct: share(cashSum) },
      { method: "آجل", count: credit.length, total: num(creditSum), share_pct: share(creditSum) },
    ],
    summary: { total: num(total), invoices: invoices.length },
  };
};

// ---------------------------------------------------------------------
// INVENTORY
// ---------------------------------------------------------------------
const stockBalanceReport: ExtraHandler = async (session) => {
  const rows = await db.stockBalance.findMany({
    where: { companyId: session.companyId, qty: { not: 0 } },
    include: {
      warehouse: { select: { code: true, name: true } },
      product: { select: { code: true, name: true, unit: true, costPrice: true, salePrice: true } },
    },
    orderBy: { productId: "asc" },
    take: 2000,
  });
  return {
    rows: rows.map((r) => ({
      warehouse: r.warehouse.name,
      product_code: r.product.code,
      product: r.product.name,
      unit: r.product.unit,
      qty: num(r.qty),
      cost_value: num(moneyR(dec(r.qty).mul(r.product.costPrice))),
      sale_value: num(moneyR(dec(r.qty).mul(r.product.salePrice))),
    })),
    summary: {
      lines: rows.length,
      total_cost: num(moneyR(sumOf(rows, (r) => dec(r.qty).mul(r.product.costPrice)))),
      total_sale: num(moneyR(sumOf(rows, (r) => dec(r.qty).mul(r.product.salePrice)))),
    },
  };
};

const stockLedger: ExtraHandler = async (session, url) => {
  const take = Math.min(1000, Math.max(10, Number(url.searchParams.get("limit") ?? 300)));
  const productId = Number(url.searchParams.get("product_id") ?? 0);
  const rows = await db.stockMovement.findMany({
    where: { companyId: session.companyId, ...(productId > 0 ? { productId } : {}) },
    include: {
      warehouse: { select: { code: true, name: true } },
      product: { select: { code: true, name: true, unit: true } },
    },
    orderBy: { id: "desc" },
    take,
  });
  return {
    rows: rows.map((m) => ({
      id: m.id,
      date: m.createdAt.toISOString().slice(0, 16).replace("T", " "),
      warehouse: m.warehouse.name,
      product: m.product.name,
      direction: m.direction === "IN" ? "وارد" : "صادر",
      qty: m.qty,
      ref_type: m.refType,
      balance_after: m.balanceAfter,
      note: m.note ?? "",
    })),
    summary: { shown: rows.length },
  };
};

const lowStock: ExtraHandler = async (session) => {
  const [balances, products] = await Promise.all([
    db.stockBalance.findMany({
      where: { companyId: session.companyId },
      select: { productId: true, qty: true },
    }),
    db.product.findMany({
      where: { companyId: session.companyId, deletedAt: null, isActive: true },
      select: { id: true, code: true, name: true, unit: true, minStock: true, costPrice: true, salePrice: true },
    }),
  ]);
  const byProduct = new Map<number, Decimal>();
  for (const b of balances) byProduct.set(b.productId, (byProduct.get(b.productId) ?? new Decimal(0)).plus(b.qty));
  const rowsRaw = products
    .filter((p) => (byProduct.get(p.id) ?? new Decimal(0)).lte(p.minStock))
    .map((p) => {
      const onHand = byProduct.get(p.id) ?? new Decimal(0);
      const shortage = qtyR(Decimal.max(0, dec(p.minStock).minus(onHand)));
      return { p, onHand, shortage, restock: moneyR(shortage.mul(p.costPrice)) };
    })
    .sort((a, b) => num(b.shortage.minus(a.shortage)));
  const rows = rowsRaw.map((r) => ({
    code: r.p.code,
    product: r.p.name,
    unit: r.p.unit,
    on_hand: num(r.onHand),
    min_stock: num(r.p.minStock),
    shortage: num(r.shortage),
    restock_cost: num(r.restock),
  }));
  return {
    rows,
    summary: {
      items: rows.length,
      shortage_qty: num(qtyR(sumOf(rowsRaw, (r) => r.shortage))),
      restock_cost: num(moneyR(sumOf(rowsRaw, (r) => r.restock))),
    },
  };
};

const outOfStock: ExtraHandler = async (session) => {
  const [balances, products] = await Promise.all([
    db.stockBalance.findMany({
      where: { companyId: session.companyId, qty: { gt: 0 } },
      select: { productId: true, qty: true },
    }),
    db.product.findMany({
      where: { companyId: session.companyId, deletedAt: null, isActive: true },
      select: { id: true, code: true, name: true, unit: true, salePrice: true, costPrice: true },
    }),
  ]);
  const inStock = new Set(balances.map((b) => b.productId));
  const out = products.filter((p) => !inStock.has(p.id));
  const rows = out
    .map((p) => ({ code: p.code, product: p.name, unit: p.unit, on_hand: 0, sale_price: num(p.salePrice) }));
  return {
    rows,
    summary: { items: rows.length, lost_sale_value: num(moneyR(sumOf(out, (p) => p.salePrice))) },
  };
};

const deadStock: ExtraHandler = async (session) => {
  const since = daysAgo(90);
  const [balances, recentMov] = await Promise.all([
    db.stockBalance.findMany({
      where: { companyId: session.companyId, qty: { gt: 0 } },
      include: {
        warehouse: { select: { name: true } },
        product: { select: { code: true, name: true, unit: true, costPrice: true } },
      },
    }),
    db.stockMovement.groupBy({ by: ["productId"], where: { companyId: session.companyId, createdAt: { gte: since } } }),
  ]);
  const recent = new Set(recentMov.map((m) => m.productId));
  const rowsRaw = balances
    .filter((b) => !recent.has(b.productId))
    .map((b) => ({
      warehouse: b.warehouse.name,
      code: b.product.code,
      product: b.product.name,
      unit: b.product.unit,
      qty: b.qty,
      frozen: moneyR(dec(b.qty).mul(b.product.costPrice)),
    }))
    .sort((a, b) => num(b.frozen.minus(a.frozen)));
  const rows = rowsRaw.map((r) => ({
    warehouse: r.warehouse,
    code: r.code,
    product: r.product,
    unit: r.unit,
    qty: num(r.qty),
    frozen_cost: num(r.frozen),
  }));
  return {
    rows,
    summary: { items: rows.length, frozen_cost: num(moneyR(sumOf(rowsRaw, (r) => r.frozen))) },
  };
};

const transfersReport: ExtraHandler = async (session) => {
  const since = daysAgo(30);
  const rows = await db.stockTransfer.findMany({
    where: { companyId: session.companyId, deletedAt: null, createdAt: { gte: since } },
    include: {
      fromWarehouse: { select: { name: true } },
      toWarehouse: { select: { name: true } },
      lines: { select: { qty: true } },
    },
    orderBy: { id: "desc" },
    take: 200,
  });
  return {
    rows: rows.map((t) => ({
      number: t.number,
      from: t.fromWarehouse.name,
      to: t.toWarehouse.name,
      status: t.status,
      items: t.lines.length,
      qty: num(qtyR(sumOf(t.lines, (l) => l.qty))),
      date: t.createdAt.toISOString().slice(0, 10),
    })),
    summary: { transfers: rows.length, dispatched: rows.filter((t) => t.status !== "DRAFT").length },
  };
};

const adjustmentsReport: ExtraHandler = async (session) => {
  const rows = await db.stockMovement.findMany({
    where: { companyId: session.companyId, refType: "ADJUSTMENT" },
    include: {
      warehouse: { select: { name: true } },
      product: { select: { code: true, name: true, unit: true } },
    },
    orderBy: { id: "desc" },
    take: 300,
  });
  return {
    rows: rows.map((m) => ({
      id: m.id,
      date: m.createdAt.toISOString().slice(0, 10),
      warehouse: m.warehouse.name,
      product: m.product.name,
      direction: m.direction === "IN" ? "زيادة" : "نقص",
      qty: m.qty,
      balance_after: m.balanceAfter,
      note: m.note ?? "",
    })),
    summary: {
      count: rows.length,
      increase_qty: num(qtyR(sumOf(rows.filter((r) => r.direction === "IN"), (r) => r.qty))),
      decrease_qty: num(qtyR(sumOf(rows.filter((r) => r.direction !== "IN"), (r) => r.qty))),
    },
  };
};

const damagesReport: ExtraHandler = async (session) => {
  // الهالك والعجز: تسويات صادرة (ADJUSTMENT OUT) — تقريب معتمد لغياب مستند هالك مستقل
  const rows = await db.stockMovement.findMany({
    where: { companyId: session.companyId, refType: "ADJUSTMENT", direction: "OUT" },
    include: {
      warehouse: { select: { name: true } },
      product: { select: { code: true, name: true, unit: true, costPrice: true } },
    },
    orderBy: { id: "desc" },
    take: 300,
  });
  const rowsOut = rows.map((m) => ({
    date: m.createdAt.toISOString().slice(0, 10),
    warehouse: m.warehouse.name,
    product: m.product.name,
    unit: m.product.unit,
    qty: m.qty,
    cost_loss: num(moneyR(dec(m.qty).mul(dec(m.unitCost ?? m.product.costPrice)))),
    note: m.note ?? "",
  }));
  return {
    rows: rowsOut,
    summary: { events: rowsOut.length, total_loss: num(moneyR(sumOf(rows, (m) => dec(m.qty).mul(dec(m.unitCost ?? m.product.costPrice))))) },
  };
};

const returnsReport: ExtraHandler = async (session) => {
  const since = daysAgo(30);
  const rows = await db.salesReturn.findMany({
    where: { companyId: session.companyId, deletedAt: null, returnDate: { gte: since } },
    include: {
      customer: { select: { code: true, name: true } },
      lines: { select: { qty: true } },
    },
    orderBy: { id: "desc" },
    take: 200,
  });
  return {
    rows: rows.map((r) => ({
      number: r.number,
      date: r.returnDate.toISOString().slice(0, 10),
      customer: r.customer.name,
      items: r.lines.length,
      total: num(r.totalAmount),
      refund_cash: num(r.refundCash),
      credit_note: num(r.creditNote),
    })),
    summary: {
      returns: rows.length,
      total: num(moneyR(sumOf(rows, (r) => r.totalAmount))),
      cash_refunds: num(moneyR(sumOf(rows, (r) => r.refundCash))),
    },
  };
};

// ---------------------------------------------------------------------
// FINANCE
// ---------------------------------------------------------------------
const receivables: ExtraHandler = async (session) => {
  const invoices = await db.salesInvoice.findMany({
    where: { companyId: session.companyId, deletedAt: null, ...(effBranchIds(session) ? { branchId: { in: effBranchIds(session)! } } : {}) },
    select: {
      number: true, invoiceDate: true, grandTotal: true, paidAmount: true,
      customer: { select: { code: true, name: true } },
    },
    orderBy: { invoiceDate: "asc" },
  });
  const now = Date.now();
  const rowsRaw = invoices
    .map((i) => ({
      i,
      due: moneyR(dec(i.grandTotal).minus(i.paidAmount)),
      age_days: Math.floor((now - i.invoiceDate.getTime()) / 86_400_000),
    }))
    .filter((r) => r.due.isPositive())
    .sort((a, b) => b.age_days - a.age_days)
    .slice(0, 500);
  const rows = rowsRaw.map((r) => ({
    invoice: r.i.number,
    date: r.i.invoiceDate.toISOString().slice(0, 10),
    customer: r.i.customer.name,
    total: num(r.i.grandTotal),
    paid: num(r.i.paidAmount),
    due: num(r.due),
    age_days: r.age_days,
  }));
  return {
    rows,
    summary: {
      open_invoices: rows.length,
      total_due: num(moneyR(sumOf(rowsRaw, (r) => r.due))),
      over_60d: num(moneyR(sumOf(rowsRaw.filter((r) => r.age_days > 60), (r) => r.due))),
    },
  };
};

const payables: ExtraHandler = async (session) => {
  const [suppliers, invoices] = await Promise.all([
    db.supplier.findMany({
      where: { companyId: session.companyId, deletedAt: null, isActive: true },
      select: { id: true, code: true, name: true, phone: true, balance: true },
    }),
    db.purchaseInvoice.findMany({
      where: { companyId: session.companyId, deletedAt: null, ...(effBranchIds(session) ? { branchId: { in: effBranchIds(session)! } } : {}) },
      select: { supplierId: true, grandTotal: true, paidAmount: true },
    }),
  ]);
  const unpaidBySupplier = new Map<number, Decimal>();
  for (const i of invoices) {
    unpaidBySupplier.set(i.supplierId, (unpaidBySupplier.get(i.supplierId) ?? new Decimal(0)).plus(Decimal.max(0, dec(i.grandTotal).minus(i.paidAmount))));
  }
  const rowsRaw = suppliers
    .map((s) => ({ s, unpaid: unpaidBySupplier.get(s.id ?? 0) ?? new Decimal(0) }))
    .filter((r) => dec(r.s.balance).isPositive() || r.unpaid.isPositive());
  const rows = rowsRaw.map((r) => ({
    code: r.s.code,
    supplier: r.s.name,
    phone: r.s.phone ?? "",
    ledger_balance: num(r.s.balance),
    unpaid_invoices: num(r.unpaid),
  }));
  return {
    rows,
    summary: {
      suppliers_with_due: rows.length,
      total_payable: num(moneyR(sumOf(rowsRaw, (r) => r.s.balance))),
    },
  };
};

const collectionsReport: ExtraHandler = async (session) => {
  const since = daysAgo(29);
  const rows = await db.cashTransaction.findMany({
    where: { companyId: session.companyId, category: "COLLECTION", createdAt: { gte: since } },
    include: {
      cashbox: { select: { name: true } },
      customer: { select: { code: true, name: true } },
    },
    orderBy: { id: "desc" },
    take: 300,
  });
  return {
    rows: rows.map((c) => ({
      id: c.id,
      date: c.createdAt.toISOString().slice(0, 10),
      cashbox: c.cashbox.name,
      customer: c.customer?.name ?? "",
      amount: num(c.amount),
      note: c.note ?? "",
    })),
    summary: {
      transactions: rows.length,
      total: num(moneyR(sumOf(rows, (r) => r.amount))),
      days: 30,
    },
  };
};

const expensesReport: ExtraHandler = async (session) => {
  const since = daysAgo(29);
  const rows = await db.cashTransaction.findMany({
    where: { companyId: session.companyId, category: "EXPENSE", createdAt: { gte: since } },
    include: { cashbox: { select: { name: true } } },
    orderBy: { id: "desc" },
    take: 300,
  });
  return {
    rows: rows.map((c) => ({
      id: c.id,
      date: c.createdAt.toISOString().slice(0, 10),
      cashbox: c.cashbox.name,
      amount: num(c.amount),
      note: c.note ?? "",
    })),
    summary: {
      transactions: rows.length,
      total: num(moneyR(sumOf(rows, (r) => r.amount))),
      days: 30,
    },
  };
};

const cashboxReport: ExtraHandler = async (session) => {
  const since = daysAgo(29);
  const [cashboxes, txs] = await Promise.all([
    db.cashbox.findMany({
      where: { companyId: session.companyId, isActive: true },
      select: { id: true, code: true, name: true, balance: true },
    }),
    db.cashTransaction.findMany({
      where: { companyId: session.companyId, createdAt: { gte: since } },
      select: { cashboxId: true, direction: true, amount: true },
    }),
  ]);
  const rows = cashboxes.map((c) => {
    const mine = txs.filter((t) => t.cashboxId === c.id);
    return {
      code: c.code,
      cashbox: c.name,
      balance: num(c.balance),
      inflow_30d: num(moneyR(sumOf(mine.filter((t) => t.direction === "IN"), (t) => t.amount))),
      outflow_30d: num(moneyR(sumOf(mine.filter((t) => t.direction !== "IN"), (t) => t.amount))),
    };
  });
  return {
    rows,
    summary: {
      cashboxes: rows.length,
      total_balance: num(moneyR(sumOf(cashboxes, (c) => c.balance))),
    },
  };
};

// ---------------------------------------------------------------------
// FIELD / REPS
// ---------------------------------------------------------------------
const repTargets: ExtraHandler = async (session) => {
  const now = new Date();
  const curPeriod = monthKey(now);
  const prev = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const prevPeriod = monthKey(prev);

  const [targets, reps] = await Promise.all([
    db.repTarget.findMany({
      where: { companyId: session.companyId, deletedAt: null, period: { in: [curPeriod, prevPeriod] } },
      include: { rep: { select: { id: true, fullName: true, username: true } } },
    }),
    db.user.findMany({
      where: {
        companyId: session.companyId, deletedAt: null, isActive: true,
        roles: { some: { role: { code: "SALES_REP", deletedAt: null } } },
      },
      select: { id: true, fullName: true, username: true },
    }),
  ]);

  // actual sales per rep per month bucket
  const salesRows = await db.salesInvoice.findMany({
    where: { companyId: session.companyId, deletedAt: null, invoiceDate: { gte: prev } },
    select: { createdById: true, grandTotal: true, invoiceDate: true },
  });
  const actual = new Map<string, Decimal>(); // `${repId}|${period}`
  for (const s of salesRows) {
    if (!s.createdById) continue;
    const k = `${s.createdById}|${monthKey(s.invoiceDate)}`;
    actual.set(k, (actual.get(k) ?? new Decimal(0)).plus(s.grandTotal));
  }

  const rows: Record<string, unknown>[] = [];
  for (const t of targets) {
    const achieved = actual.get(`${t.repId}|${t.period}`) ?? new Decimal(0);
    rows.push({
      period: t.period,
      rep: t.rep.fullName,
      username: t.rep.username,
      target: num(t.targetAmount),
      achieved: num(achieved),
      achievement_pct: dec(t.targetAmount).isPositive() ? num(achieved.div(t.targetAmount).mul(1000).toDecimalPlaces(0, Decimal.ROUND_HALF_UP).div(10)) : 0,
      gap: num(moneyR(achieved.minus(t.targetAmount))),
    });
  }
  // reps with sales but no target row
  for (const r of reps) {
    for (const p of [prevPeriod, curPeriod]) {
      const k = `${r.id}|${p}`;
      if (actual.has(k) && !targets.some((t) => t.repId === r.id && t.period === p)) {
        rows.push({ period: p, rep: r.fullName, username: r.username, target: 0, achieved: num(actual.get(k)), achievement_pct: null, gap: num(actual.get(k)) });
      }
    }
  }
  rows.sort((a, b) => String(b.period).localeCompare(String(a.period)) || Number(b.achieved ?? 0) - Number(a.achieved ?? 0));
  return {
    rows,
    summary: {
      target_rows: targets.length,
      current_period: curPeriod,
      total_target_cur: num(moneyR(sumOf(targets.filter((t) => t.period === curPeriod), (t) => t.targetAmount))),
    },
  };
};

const repCommissions: ExtraHandler = async (session) => {
  const since = daysAgo(90);
  const rows = await db.commission.findMany({
    where: { companyId: session.companyId, createdAt: { gte: since } },
    include: {
      rep: { select: { fullName: true, username: true } },
      invoice: { select: { number: true } },
    },
    orderBy: { id: "desc" },
    take: 300,
  });
  const statusAr: Record<string, string> = { PENDING: "معلقة", APPROVED: "معتمدة", PAID: "مدفوعة" };
  return {
    rows: rows.map((c) => ({
      id: c.id,
      period: c.period,
      rep: c.rep.fullName,
      invoice: c.invoice?.number ?? `#${c.invoiceId}`,
      base_amount: num(c.baseAmount),
      amount: num(c.amount),
      status: statusAr[c.status] ?? c.status,
    })),
    summary: {
      count: rows.length,
      total: num(moneyR(sumOf(rows, (r) => r.amount))),
      pending: num(moneyR(sumOf(rows.filter((r) => r.status === "معلقة"), (r) => r.amount))),
    },
  };
};

const repVisits: ExtraHandler = async (session) => {
  const since = daysAgo(29);
  const visits = await db.visit.findMany({
    where: { companyId: session.companyId, deletedAt: null, plannedDate: { gte: since } },
    select: {
      rep: { select: { fullName: true, username: true } },
      status: true, outcome: true, orderValue: true,
    },
  });
  const agg = new Map<string, { rep: string; username: string; planned: number; completed: number; cancelled: number; ordered: number; no_order: number; collection: number; order_value: Decimal }>();
  for (const v of visits) {
    const key = v.rep.username;
    const cur = agg.get(key) ?? { rep: v.rep.fullName, username: key, planned: 0, completed: 0, cancelled: 0, ordered: 0, no_order: 0, collection: 0, order_value: new Decimal(0) };
    if (v.status === "COMPLETED") cur.completed += 1;
    else if (v.status === "CANCELLED") cur.cancelled += 1;
    else cur.planned += 1;
    if (v.outcome === "ORDERED") { cur.ordered += 1; cur.order_value = cur.order_value.plus(v.orderValue); }
    else if (v.outcome === "NO_ORDER") cur.no_order += 1;
    else if (v.outcome === "COLLECTION") cur.collection += 1;
    agg.set(key, cur);
  }
  const rows = [...agg.values()]
    .sort((a, b) => b.completed - a.completed)
    .map((r) => ({ ...r, order_value: num(moneyR(r.order_value)) }));
  return {
    rows,
    summary: {
      total_visits: visits.length,
      completed: visits.filter((v) => v.status === "COMPLETED").length,
      order_value: num(moneyR(sumOf(visits, (v) => v.orderValue))),
    },
  };
};

const repCustomers: ExtraHandler = async (session) => {
  const since = daysAgo(90);
  const visits = await db.visit.findMany({
    where: { companyId: session.companyId, deletedAt: null, plannedDate: { gte: since } },
    select: {
      rep: { select: { fullName: true, username: true } },
      customerId: true,
      customer: { select: { code: true, name: true } },
    },
  });
  const agg = new Map<string, { rep: string; username: string; customers: Set<number>; visits: number }>();
  for (const v of visits) {
    const key = v.rep.username;
    const cur = agg.get(key) ?? { rep: v.rep.fullName, username: key, customers: new Set<number>(), visits: 0 };
    cur.customers.add(v.customerId);
    cur.visits += 1;
    agg.set(key, cur);
  }
  const rows = [...agg.values()]
    .map((a) => ({ rep: a.rep, username: a.username, visited_customers: a.customers.size, visits_90d: a.visits, visits_per_customer: a.customers.size ? Math.round((a.visits / a.customers.size) * 10) / 10 : 0 }))
    .sort((a, b) => b.visited_customers - a.visited_customers);
  return {
    rows,
    summary: { reps: rows.length, total_visits: visits.length },
  };
};

const repReturns: ExtraHandler = async (session) => {
  const since = daysAgo(90);
  const returns = await db.salesReturn.findMany({
    where: { companyId: session.companyId, deletedAt: null, returnDate: { gte: since } },
    select: {
      creator: { select: { fullName: true, username: true } },
      totalAmount: true, refundCash: true, creditNote: true, lines: { select: { qty: true } },
    },
  });
  const agg = new Map<string, { rep: string; username: string; returns: number; items: number; total: Decimal }>();
  for (const r of returns) {
    const key = r.creator?.username ?? "—";
    const cur = agg.get(key) ?? { rep: r.creator?.fullName ?? "—", username: key, returns: 0, items: 0, total: new Decimal(0) };
    cur.returns += 1;
    cur.items += r.lines.length;
    cur.total = cur.total.plus(r.totalAmount);
    agg.set(key, cur);
  }
  const rows = [...agg.values()]
    .sort((a, b) => num(b.total.minus(a.total)))
    .map((r) => ({ ...r, total: num(moneyR(r.total)) }));
  return {
    rows,
    summary: {
      returns: returns.length,
      total: num(moneyR(sumOf(returns, (r) => r.totalAmount))),
    },
  };
};

// ---------------------------------------------------------------------
// Registry
// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// WALK-IN / CUSTOMER-TYPE reports (MASTER PROMPT Phases 28-29)
// ---------------------------------------------------------------------
const salesByCustomerType: ExtraHandler = async (session) => {
  const invoices = await db.salesInvoice.findMany({
    where: {
      companyId: session.companyId, deletedAt: null,
      status: { not: "VOID" },
      ...(effBranchIds(session) ? { branchId: { in: effBranchIds(session)! } } : {}),
    },
    select: { customerType: true, grandTotal: true, paidAmount: true, customer: { select: { code: true, name: true } } },
  });

  const TYPES: Record<string, string> = {
    REGISTERED: "عميل مسجل",
    WALK_IN: "زبون نقدي / متردد",
    CASH_CUSTOMER: "زبون كاشي",
    GUEST: "زبون غير معروف",
  };
  const agg = new Map<string, { type: string; label: string; invoices: number; total: Decimal; paid: Decimal }>();
  for (const t of Object.keys(TYPES)) agg.set(t, { type: t, label: TYPES[t], invoices: 0, total: new Decimal(0), paid: new Decimal(0) });
  for (const inv of invoices) {
    const key = agg.has(inv.customerType) ? inv.customerType : "REGISTERED";
    const b = agg.get(key)!;
    b.invoices += 1;
    b.total = b.total.plus(inv.grandTotal);
    b.paid = b.paid.plus(inv.paidAmount);
  }
  const rows = [...agg.values()].filter((r) => r.invoices > 0);
  const total = moneyR(sumOf(rows, (r) => r.total));
  return {
    rows: rows.map((r) => ({ type: r.type, label: r.label, invoices: r.invoices, total: num(moneyR(r.total)), paid: num(moneyR(r.paid)) })),
    summary: {
      total: num(total),
      invoice_count: invoices.length,
      walkin_total: num(moneyR(agg.get("WALK_IN")!.total.plus(agg.get("CASH_CUSTOMER")!.total).plus(agg.get("GUEST")!.total))),
      registered_total: num(moneyR(agg.get("REGISTERED")!.total)),
    },
  };
};

const walkinKpis: ExtraHandler = async (session) => {
  const branchFilter = effBranchIds(session) ? { branchId: { in: effBranchIds(session)! } } : {};

  const [walkinInvoices, registeredInvoices, walkinCustomers, converted] = await Promise.all([
    db.salesInvoice.aggregate({
      where: { companyId: session.companyId, deletedAt: null, status: { not: "VOID" }, customerType: { not: "REGISTERED" }, ...branchFilter },
      _count: { _all: true }, _sum: { grandTotal: true },
    }),
    db.salesInvoice.aggregate({
      where: { companyId: session.companyId, deletedAt: null, status: { not: "VOID" }, customerType: "REGISTERED", ...branchFilter },
      _count: { _all: true }, _sum: { grandTotal: true },
    }),
    db.customer.count({ where: { companyId: session.companyId, deletedAt: null, customerType: { not: "REGISTERED" }, ...branchFilter } }),
    db.customer.count({ where: { companyId: session.companyId, deletedAt: null, convertedFromWalkIn: true, ...branchFilter } }),
  ]);

  // conversion rate = converted walk-ins / (converted + still-anonymous records)
  const denominator = converted + walkinCustomers;
  const rate = denominator > 0 ? Math.round(((converted / denominator) * 100) * 100) / 100 : 0; // نسبة على عدّادات (ليست مالية) — مكافئ round2 القديم

  return {
    rows: [
      { kpi: "مبيعات الزبون المتردد", value: num(moneyR(dec(walkinInvoices._sum.grandTotal))), unit: "IQD" },
      { kpi: "عمليات الزبون المتردد", value: walkinInvoices._count._all, unit: "فاتورة" },
      { kpi: "مبيعات العملاء المسجلين", value: num(moneyR(dec(registeredInvoices._sum.grandTotal))), unit: "IQD" },
      { kpi: "عمليات العملاء المسجلين", value: registeredInvoices._count._all, unit: "فاتورة" },
      { kpi: "سجلات الزبون المتردد", value: walkinCustomers, unit: "سجل" },
      { kpi: "تم تحويلهم لعملاء مسجلين", value: converted, unit: "سجل" },
      { kpi: "معدل التحويل", value: rate, unit: "%" },
    ],
    summary: {
      walkin_sales: num(moneyR(dec(walkinInvoices._sum.grandTotal))),
      registered_sales: num(moneyR(dec(registeredInvoices._sum.grandTotal))),
      conversion_rate: rate,
    },
  };
};

// ---------------------------------------------------------------------
// Phase 4 — COSTING (§9): COGS · Gross Profit · Inventory Value ·
// FIFO layers · WAVG cost · Standard cost variance · Last purchase cost.
// المصدر: cost_layers / cost_consumptions + لقطة COGS على بنود الفواتير.
// ---------------------------------------------------------------------
const normalizeCostingMethod = (v: string | null | undefined): string => {
  const s = String(v ?? "").trim().toUpperCase();
  if (s === "WAVG" || s === "AVG" || s === "WEIGHTED AVG") return "WEIGHTED_AVERAGE";
  if (s === "STANDARD" ) return "STANDARD_COST";
  if (s === "LAST") return "LAST_COST";
  return s || "WEIGHTED_AVERAGE";
};

/** §9 — طبقات FIFO المتبقية لكل (مستودع، منتج) — هوية التكلفة الحية. */
const costingLayers: ExtraHandler = async (session, url) => {
  const warehouseId = url.searchParams.get("warehouse_id");
  const productId = url.searchParams.get("product_id");
  const layers = await db.costLayer.findMany({
    where: {
      companyId: session.companyId,
      status: "ACTIVE",
      remainingQuantity: { gt: 0 },
      ...(session.warehouseIds?.length ? { warehouseId: { in: session.warehouseIds } } : {}),
      ...(warehouseId ? { warehouseId: Number(warehouseId) } : {}),
      ...(productId ? { productId: Number(productId) } : {}),
    },
    include: {
      product: { select: { code: true, name: true, unit: true } },
      warehouse: { select: { code: true, name: true } },
    },
    orderBy: [{ productId: "asc" }, { createdAt: "asc" }, { id: "asc" }],
    take: 2000,
  });

  const rows = layers.map((l) => ({
    layer_id: l.id,
    product: l.product.name,
    product_code: l.product.code,
    warehouse: l.warehouse.name,
    source_type: l.sourceType,
    source_id: l.sourceId,
    received_at: l.createdAt,
    original_qty: num(qtyR(l.quantity)),
    remaining_qty: num(qtyR(l.remainingQuantity)),
    unit_cost: num(moneyR(l.unitCost)),
    value: num(moneyR(qtyR(dec(l.remainingQuantity)).mul(moneyR(dec(l.unitCost))))),
    age_days: Math.max(0, Math.floor((Date.now() - new Date(l.createdAt).getTime()) / 86_400_000)),
  }));
  return {
    rows,
    summary: {
      layers: rows.length,
      total_qty: num(sumOf(rows, (r) => r.remaining_qty)),
      total_value: num(sumOf(rows, (r) => r.value)),
    },
  };
};

/** §9 — قيمة المخزون من الطبقات + WAVG + Standard + Last لكل منتج. */
const costingInventory: ExtraHandler = async (session) => {
  const layers = await db.costLayer.findMany({
    where: {
      companyId: session.companyId,
      status: "ACTIVE",
      remainingQuantity: { gt: 0 },
      ...(session.warehouseIds?.length ? { warehouseId: { in: session.warehouseIds } } : {}),
    },
    select: { productId: true, remainingQuantity: true, unitCost: true },
  });
  const productIds = [...new Set(layers.map((l) => l.productId))];
  const products = await db.product.findMany({
    where: { id: { in: productIds }, companyId: session.companyId },
    select: { id: true, code: true, name: true, unit: true, costPrice: true, standardCost: true, lastCost: true },
  });
  const pmap = new Map(products.map((p) => [p.id, p]));

  const agg = new Map<number, { qty: Decimal; value: Decimal }>();
  for (const l of layers) {
    const cur = agg.get(l.productId) ?? { qty: new Decimal(0), value: new Decimal(0) };
    cur.qty = cur.qty.plus(qtyR(dec(l.remainingQuantity)));
    cur.value = cur.value.plus(qtyR(dec(l.remainingQuantity)).mul(moneyR(dec(l.unitCost))));
    agg.set(l.productId, cur);
  }

  const rows = [...agg.entries()].map(([pid, a]) => {
    const p = pmap.get(pid);
    const avgFromLayers = a.qty.isPositive() ? moneyR(a.value.div(a.qty)) : new Decimal(0);
    return {
      product_id: pid,
      product_code: p?.code ?? "",
      product: p?.name ?? `#${pid}`,
      unit: p?.unit ?? "",
      qty: num(a.qty),
      inventory_value: num(a.value), // §9 Inventory Value (من الطبقات)
      wavg_cost: num(avgFromLayers), // §9 WAVG cost الفعلي من الطبقات
      product_wavg_cost: num(moneyR(dec(p?.costPrice))), // المتوسط الساري على المنتج
      standard_cost: p?.standardCost == null ? null : num(moneyR(dec(p.standardCost))),
      last_purchase_cost: p?.lastCost == null ? null : num(moneyR(dec(p.lastCost))),
    };
  }).sort((a, b) => b.inventory_value - a.inventory_value);

  return {
    rows,
    summary: {
      products: rows.length,
      total_qty: num(sumOf(rows, (r) => r.qty)),
      total_value: num(sumOf(rows, (r) => r.inventory_value)),
    },
  };
};

/** §9 — COGS والربح الإجمالي لكل منتج خلال فترة (من لقطة COGS على البنود). */
const costingCogs: ExtraHandler = async (
  session,
  url
): Promise<{ rows?: unknown[]; summary?: Record<string, number | string>; meta?: Record<string, unknown> } | null> => {
  const fromParam = url.searchParams.get("from");
  const toParam = url.searchParams.get("to");
  const from = fromParam ? new Date(fromParam) : daysAgo(29);
  const to = toParam ? new Date(`${toParam}T23:59:59.999Z`) : new Date();
  if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime())) {
    return { rows: [], summary: { error: 1 } };
  }

  const lines = await db.salesInvoiceLine.findMany({
    where: {
      invoice: {
        companyId: session.companyId,
        deletedAt: null,
        status: "POSTED",
        invoiceDate: { gte: from, lte: to },
        ...(effBranchIds(session) ? { branchId: { in: effBranchIds(session)! } } : {}),
      },
    },
    select: {
      productId: true, qty: true, lineTotal: true,
      unitCost: true, cogsUnitCost: true, cogsTotal: true, cogsMethod: true,
      product: { select: { code: true, name: true, unit: true } },
    },
  });

  const agg = new Map<number, {
    code: string; name: string; unit: string; qty: Decimal; revenue: Decimal; cogs: Decimal; methods: Set<string>;
  }>();
  for (const l of lines) {
    const cur = agg.get(l.productId) ?? {
      code: l.product.code, name: l.product.name, unit: l.product.unit,
      qty: new Decimal(0), revenue: new Decimal(0), cogs: new Decimal(0), methods: new Set<string>(),
    };
    cur.qty = cur.qty.plus(qtyR(dec(l.qty)));
    cur.revenue = cur.revenue.plus(moneyR(dec(l.lineTotal)));
    // COGS الفعلي: لقطة cogsTotal (المرحلة 4) — fallback unitCost للبنود القديمة
    cur.cogs = cur.cogs.plus(l.cogsTotal != null ? moneyR(dec(l.cogsTotal)) : moneyR(dec(l.qty).mul(dec(l.unitCost))));
    if (l.cogsMethod) cur.methods.add(l.cogsMethod);
    agg.set(l.productId, cur);
  }

  const rows = [...agg.entries()].map(([pid, a]) => {
    const grossProfit = moneyR(a.revenue.minus(a.cogs));
    const marginPct = a.revenue.isPositive() ? pctRound(grossProfit.mul(100).div(a.revenue)) : new Decimal(0);
    return {
      product_id: pid,
      product_code: a.code,
      product: a.name,
      unit: a.unit,
      qty: num(a.qty),
      revenue: num(a.revenue),
      cogs: num(a.cogs),
      gross_profit: num(grossProfit),
      margin_pct: num(marginPct),
      cost_methods: [...a.methods].map(normalizeCostingMethod).join("+") || "LEGACY",
    };
  }).sort((a, b) => b.gross_profit - a.gross_profit);

  return {
    rows,
    summary: {
      products: rows.length,
      revenue: num(sumOf(rows, (r) => r.revenue)),
      cogs: num(sumOf(rows, (r) => r.cogs)),
      gross_profit: num(sumOf(rows, (r) => r.gross_profit)),
    },
  };
};

/** §9 — انحراف التكلفة المعيارية: Standard مقابل WAVG الفعلي وآخر شراء. */
const costingVariance: ExtraHandler = async (session) => {
  const products = await db.product.findMany({
    where: { companyId: session.companyId, deletedAt: null, standardCost: { not: null } },
    select: { id: true, code: true, name: true, costPrice: true, standardCost: true, lastCost: true },
  });
  const productIds = products.map((p) => p.id);

  // الكميات المتبقية (لحساب قيمة الانحراف على المخزون القائم)
  const layerAgg = await db.costLayer.groupBy({
    by: ["productId"],
    where: { companyId: session.companyId, status: "ACTIVE", remainingQuantity: { gt: 0 }, productId: { in: productIds } },
    _sum: { remainingQuantity: true },
  });
  const qtyOf = new Map<number, Decimal>(layerAgg.map((r) => [r.productId, qtyR(dec(r._sum.remainingQuantity))]));

  const rows = products.map((p) => {
    const standard = moneyR(dec(p.standardCost));
    const wavg = moneyR(dec(p.costPrice));
    const last = p.lastCost == null ? null : moneyR(dec(p.lastCost));
    const qty = qtyOf.get(p.id) ?? new Decimal(0);
    const varianceUnit = moneyR(wavg.minus(standard)); // + = الفعلي أعلى من المعياري
    return {
      product_id: p.id,
      product_code: p.code,
      product: p.name,
      standard_cost: num(standard),
      wavg_cost: num(wavg),
      last_purchase_cost: last == null ? null : num(last),
      variance_unit: num(varianceUnit),
      variance_pct: num(wavg.isPositive() ? pctRound(varianceUnit.mul(100).div(wavg)) : new Decimal(0)),
      on_hand_qty: num(qty),
      variance_value_on_hand: num(moneyR(varianceUnit.mul(qty))),
    };
  }).sort((a, b) => Math.abs(b.variance_value_on_hand) - Math.abs(a.variance_value_on_hand));

  return {
    rows,
    summary: {
      products: rows.length,
      total_variance_value: num(sumOf(rows, (r) => r.variance_value_on_hand)),
    },
  };
};

/** نسبة مئوية مقلوبة إلى 2 منازل للعرض (نمط Math.round(x*100)/100 الرقمي). */
function pctRound(v: Decimal): Decimal {
  return v.toDecimalPlaces(2, Decimal.ROUND_HALF_UP);
}

// ---------------------------------------------------------------------
// Phase: Remaining Ideas — Advanced Reports (#21, #25, #27, #10, #34, #37)
// ---------------------------------------------------------------------

/** #27 Top 10 عملاء متأخرون في السداد */
const topLateCustomers: ExtraHandler = async (session) => {
  const customers = await db.customer.findMany({
    where: { companyId: session.companyId, deletedAt: null, balance: { gt: 0 } },
    orderBy: { balance: "desc" }, take: 10,
    include: { _count: { select: { invoices: true } } },
  });
  const now = new Date();
  const rows: any[] = [];
  for (const c of customers) {
    const oldestInv = await db.salesInvoice.findFirst({
      where: { companyId: session.companyId, customerId: c.id, deletedAt: null, status: "POSTED", dueDate: { lt: now } },
      orderBy: { dueDate: "asc" },
    });
    const overdueDays = oldestInv?.dueDate ? Math.floor((now.getTime() - oldestInv.dueDate.getTime()) / 86400000) : 0;
    rows.push({ customer: { id: c.id, name: c.name, code: c.code, phone: c.phone }, balance: num(dec(c.balance)), overdue_days: overdueDays, oldest_invoice: oldestInv?.number ?? null, invoices_count: c._count.invoices });
  }
  return { rows, summary: { total_overdue: num(sumOf(rows, (r) => dec(r.balance))), count: rows.length } };
};

/** #21 قائمة التدفقات النقدية */
const cashFlowStatement: ExtraHandler = async (session, url) => {
  const dateFrom = url.searchParams.get("date_from") ? new Date(url.searchParams.get("date_from")!) : new Date(Date.now() - 30 * 86400000);
  const dateTo = url.searchParams.get("date_to") ? new Date(url.searchParams.get("date_to")!) : new Date();
  const receipts = await db.cashTransaction.aggregate({ where: { companyId: session.companyId, direction: "IN", createdAt: { gte: dateFrom, lte: dateTo }, isReversed: false, category: { in: ["COLLECTION", "CUSTOMER_PAYMENT", "OPENING", "REFUND"] } }, _sum: { amount: true } });
  const payments = await db.cashTransaction.aggregate({ where: { companyId: session.companyId, direction: "OUT", createdAt: { gte: dateFrom, lte: dateTo }, isReversed: false, category: { in: ["SUPPLIER_PAYMENT", "EXPENSE", "REFUND"] } }, _sum: { amount: true } });
  const transfersIn = await db.cashTransaction.aggregate({ where: { companyId: session.companyId, direction: "IN", createdAt: { gte: dateFrom, lte: dateTo }, isReversed: false, transactionType: { in: ["CASH_TRANSFER_IN", "BANK_WITHDRAWAL"] } }, _sum: { amount: true } });
  const transfersOut = await db.cashTransaction.aggregate({ where: { companyId: session.companyId, direction: "OUT", createdAt: { gte: dateFrom, lte: dateTo }, isReversed: false, transactionType: { in: ["CASH_TRANSFER_OUT", "BANK_DEPOSIT"] } }, _sum: { amount: true } });
  const totalIn = dec(receipts._sum.amount ?? 0), totalOut = dec(payments._sum.amount ?? 0);
  const netOps = moneyR(totalIn.minus(totalOut));
  const netInvest = moneyR(dec(transfersIn._sum.amount ?? 0).minus(transfersOut._sum.amount ?? 0));
  return { rows: [{ category: "العمليات", inflow: num(totalIn), outflow: num(totalOut), net: num(netOps) }, { category: "الاستثمار", inflow: num(transfersIn._sum.amount ?? 0), outflow: num(transfersOut._sum.amount ?? 0), net: num(netInvest) }, { category: "صافي التدفق", inflow: num(totalIn.plus(transfersIn._sum.amount ?? 0)), outflow: num(totalOut.plus(transfersOut._sum.amount ?? 0)), net: num(moneyR(netOps.plus(netInvest))) }], summary: { date_from: dateFrom.toISOString(), date_to: dateTo.toISOString(), net_cash_flow: num(moneyR(netOps.plus(netInvest))) } };
};

/** #10 ميزانية المصروفات + تنبيه 80% */
const budgetAlerts: ExtraHandler = async (session) => {
  const now = new Date();
  const period = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const categories = await db.expenseCategory.findMany({ where: { companyId: session.companyId, deletedAt: null, monthlyBudget: { gt: 0 } } });
  const rows: any[] = [];
  for (const cat of categories) {
    const spent = await db.paymentVoucher.aggregate({ where: { companyId: session.companyId, deletedAt: null, status: "POSTED", reason: { in: ["EXPENSE", "OPERATING_EXPENSE"] }, expenseCategory: cat.code, voucherDate: { gte: new Date(now.getFullYear(), now.getMonth(), 1) } }, _sum: { amount: true } });
    const budget = dec(cat.monthlyBudget ?? 0), actual = dec(spent._sum.amount ?? 0);
    const pct = budget.isPositive() ? Number(actual.times(100).div(budget).toDecimalPlaces(2)) : 0;
    rows.push({ category: cat.code, name: cat.name, budget: num(budget), spent: num(actual), remaining: num(moneyR(budget.minus(actual))), pct_used: pct, alert: pct >= 100 ? "EXCEEDED" : pct >= 80 ? "WARNING" : pct >= 50 ? "ON_TRACK" : "LOW" });
  }
  return { rows, summary: { period, total_budget: num(sumOf(rows, (r) => dec(r.budget))), total_spent: num(sumOf(rows, (r) => dec(r.spent))), alerts_count: rows.filter((r) => r.alert !== "LOW").length } };
};

/** #34 Fraud Detection */
const fraudAlerts: ExtraHandler = async (session) => {
  const now = new Date();
  const fiveMinAgo = new Date(now.getTime() - 5 * 60000);
  const recentTxs = await db.cashTransaction.findMany({ where: { companyId: session.companyId, direction: "IN", createdAt: { gte: fiveMinAgo, lte: now }, isReversed: false, customerId: { not: null } }, include: { customer: { select: { name: true, code: true } } } });
  const customerCounts: Record<number, number> = {};
  const allAlerts: any[] = [];
  for (const tx of recentTxs) {
    if (tx.customerId) { customerCounts[tx.customerId] = (customerCounts[tx.customerId] ?? 0) + 1;
      if (customerCounts[tx.customerId] > 1) allAlerts.push({ type: "DUPLICATE_PAYMENT", severity: "HIGH", message: `العميل ${tx.customer?.name} دفع مرتين خلال 5 دقائق`, amount: num(dec(tx.amount)) });
    }
    const h = tx.createdAt.getHours();
    if (h < 6 || h > 22) allAlerts.push({ type: "AFTER_HOURS", severity: "LOW", message: `حركة بعد ساعات العمل: ${num(dec(tx.amount))}`, amount: num(dec(tx.amount)) });
  }
  const recentClosings = await db.cashboxClosing.findMany({ where: { companyId: session.companyId, closedAt: { gte: new Date(now.getTime() - 24 * 3600000) } } });
  for (const c of recentClosings) { if (Math.abs(num(dec(c.difference))) > 50000) allAlerts.push({ type: "LARGE_VARIANCE", severity: "MEDIUM", message: `فرق جرد كبير: ${num(dec(c.difference))}`, amount: num(dec(c.difference)) }); }
  return { rows: allAlerts, summary: { total_alerts: allAlerts.length, high: allAlerts.filter((a) => a.severity === "HIGH").length, medium: allAlerts.filter((a) => a.severity === "MEDIUM").length, low: allAlerts.filter((a) => a.severity === "LOW").length } };
};

/** #37 Pending Receipts Queue */
const pendingReceipts: ExtraHandler = async (session) => {
  const receipts = await db.receiptVoucher.findMany({ where: { companyId: session.companyId, deletedAt: null, status: "DRAFT" }, include: { customer: { select: { id: true, name: true, code: true } }, cashbox: { select: { id: true, name: true, code: true } } }, orderBy: { receiptDate: "asc" }, take: 50 });
  return { rows: receipts.map((r) => ({ id: r.id, number: r.number, receipt_date: r.receiptDate, recipient_name: r.recipientName, customer: r.customer, cashbox: r.cashbox, amount: num(dec(r.amount)), currency: r.currency, payment_method: r.paymentMethod, status: r.status })), summary: { count: receipts.length, total_amount: num(sumOf(receipts, (r) => dec(r.amount))) } };
};

/** #25 اتجاه أعمار الديون (6 أشهر) */
const agingTrend: ExtraHandler = async (session) => {
  const now = new Date();
  const rows: any[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const endD = new Date(now.getFullYear(), now.getMonth() - i + 1, 0, 23, 59, 59);
    const customers = await db.customer.findMany({ where: { companyId: session.companyId, deletedAt: null, balance: { gt: 0 } }, select: { id: true, balance: true } });
    let current = dec(0), d30 = dec(0), d60 = dec(0), d90 = dec(0), d90p = dec(0);
    for (const c of customers) {
      const oldest = await db.salesInvoice.findFirst({ where: { companyId: session.companyId, customerId: c.id, deletedAt: null, dueDate: { lt: endD } }, orderBy: { dueDate: "asc" } });
      const bal = dec(c.balance);
      if (!oldest?.dueDate) { current = current.plus(bal); continue; }
      const days = Math.floor((endD.getTime() - oldest.dueDate.getTime()) / 86400000);
      if (days <= 30) current = current.plus(bal); else if (days <= 60) d30 = d30.plus(bal); else if (days <= 90) d60 = d60.plus(bal); else if (days <= 120) d90 = d90.plus(bal); else d90p = d90p.plus(bal);
    }
    rows.push({ month: d.toISOString().slice(0, 7), current: num(current), "1_30": num(d30), "31_60": num(d60), "61_90": num(d90), "90+": num(d90p), total: num(current.plus(d30).plus(d60).plus(d90).plus(d90p)) });
  }
  return { rows, summary: { months: rows.length, latest_total: rows[rows.length - 1]?.total ?? 0 } };
};


export const EXTRA_REPORTS: Record<string, ExtraHandler> = {
  "monthly-sales": monthlySales,
  "sales-by-customer": salesByCustomer,
  "sales-by-category": salesByCategory,
  "sales-by-branch": salesByBranch,
  "sales-by-payment-method": salesByPaymentMethod,
  "stock-balance": stockBalanceReport,
  "stock-ledger": stockLedger,
  "low-stock": lowStock,
  "out-of-stock": outOfStock,
  "dead-stock": deadStock,
  "transfers-report": transfersReport,
  "adjustments-report": adjustmentsReport,
  "damages-report": damagesReport,
  "returns-report": returnsReport,
  "receivables": receivables,
  "payables": payables,
  "collections-report": collectionsReport,
  "expenses-report": expensesReport,
  "cashbox-report": cashboxReport,
  "rep-targets": repTargets,
  "rep-commissions": repCommissions,
  "rep-visits": repVisits,
  "rep-customers": repCustomers,
  "rep-returns": repReturns,
  "sales-by-customer-type": salesByCustomerType,
  "walkin-kpis": walkinKpis,
  // ---- Phase 4 — Costing engine reports (§9) ----------------------------
  "costing-layers": costingLayers,
  "costing-inventory": costingInventory,
  "costing-cogs": costingCogs,
  "costing-variance": costingVariance,
  // ---- Remaining Ideas reports (#21, #25, #27, #10, #34, #37) --------
  "top-late-customers": topLateCustomers,
  "cash-flow-statement": cashFlowStatement,
  "budget-alerts": budgetAlerts,
  "fraud-alerts": fraudAlerts,
  "pending-receipts": pendingReceipts,
  "aging-trend": agingTrend,
};

export async function handleExtraReport(
  type: string,
  session: SessionLike,
  url: URL
): Promise<{ rows?: unknown[]; summary?: Record<string, number | string>; meta?: Record<string, unknown> } | null> {
  const fn = EXTRA_REPORTS[type];
  if (!fn) return null;
  return fn(session, url);
}

