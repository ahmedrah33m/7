// =====================================================================
// Shared Phase 0 seeders — single source of truth.
//   Used by:
//     · prisma/seed.ts            (CLI:  bun prisma/seed.ts)
//     · src/instrumentation.ts    (server boot + 60s self-heal loop)
//     · /api/v1/auth/login        (pre-login guard, cheap 15s cache)
//
// Rationale: the sandbox/host may reset db/custom.db externally
// (schema kept, data wiped). Instead of failing every login with
// AUTH_003 until someone re-runs the seed manually, the app detects
// an empty users table and re-seeds idempotently by itself.
// =====================================================================

import { argon2id } from "hash-wasm";
import { db } from "./db";
import { allPermissions, CATALOG } from "./permissions-catalog";
import { createSalesInvoice } from "./sales-service";
import { applyStockMovement } from "./inventory";
import { createPurchaseInvoice } from "./purchasing-service";
import { collectFromCustomer, recordExpense, openCashbox } from "./finance-service";
import { createSalesReturn } from "./returns-service";
import { createRoute, planVisit, checkinVisit, completeVisit, periodOf } from "./field-service";
import { b2bCreateOrder, setPortalPin } from "./b2b-service";
import { createSalesOrder, confirmSalesOrder } from "./sales-order-service";
import { Decimal, dec, moneyR, num } from "./decimal";
import { ensureWalkInCustomer } from "./walkin";
import { validatePackaging } from "./product-validation";
import { syncProductPrices } from "./product-pricing";
import { setCompanyUsdRate } from "./currency";

function salt(): Uint8Array {
  const s = new Uint8Array(16);
  crypto.getRandomValues(s);
  return s;
}

async function hash(plain: string) {
  return argon2id({
    password: plain,
    salt: salt(),
    parallelism: 1,
    iterations: 3,
    memorySize: 19456,
    hashLength: 32,
    outputType: "encoded" as const,
  });
}

// ---- 11 system roles (ERD §1 roles table) ------------------------------
export const SYSTEM_ROLES = [
  { code: "OWNER", name: "المالك", description: "وصول كامل مطلق لكل الوحدات والإعدادات" },
  { code: "SUPER_ADMIN", name: "مدير النظام", description: "كل الصلاحيات عدا التعديلات الهيكلية للشركة" },
  { code: "BRANCH_MANAGER", name: "مدير فرع", description: "إدارة فرعه: مستخدموه، مستودعاته، تقاريره" },
  { code: "SALES_MANAGER", name: "مدير مبيعات", description: "إدارة فريق المبيعات والفواتير والعملاء والأسعار" },
  { code: "WAREHOUSE_MANAGER", name: "أمين مستودع", description: "حركات المستودع: إدخال، تسويات، جرد، متابعة الأرصدة" },
  { code: "SALES_REP", name: "مندوب مبيعات", description: "بيع من مخزنه فقط، عرض المنتجات والعملاء وإصدار الفواتير" },
  { code: "CASHIER", name: "كاشير", description: "بيع نقدي من نقطة البيع وعرض المنتجات والعملاء" },
  { code: "ACCOUNTANT", name: "محاسب", description: "المدفوعات، الذمم، المصروفات، التقارير المالية" },
  { code: "PURCHASING_OFFICER", name: "مسؤول مشتريات", description: "أوامر الشراء والاستلام وحسابات الموردين" },
  { code: "AUDITOR", name: "مراجع", description: "قراءة كل شيء + سجل التدقيق دون أي تعديل" },
  { code: "VIEWER", name: "مشاهد", description: "عرض فقط لكل الشاشات المعروضة له" },
  // v14 — حساب خاص بأمين المخزن لشاشة التسليم: يرى إشعارات التسليم فقط،
  // ويُبلَّغ حصراً بحالات النقص (تنبيه DELIVERY_SHORTAGE في مركز التنبيهات).
  { code: "CASH_KEEPER", name: "أمين الصندوق", description: "حساب خاص بأمين المخزن — إشعارات التسليم فقط، ويُبلَّغ حصراً بحالات النقص" },
] as const;

// Per-role permission grants — selling roles (CASHIER/SALES_REP) get the
// sales/product/inventory-read stack so POS flows work end-to-end.
// (exported for company provisioning — Phase: Multi-Company onboarding)
export function rolePermissionCodes(roleCode: string): string[] {
  const core = ["system.users", "system.roles", "system.branches", "system.warehouses", "system.company", "system.settings", "audit.audit_logs"];
  const coreView = core.map((e) => `${e}.view`);
  const sellStack = [
    "sales.invoices.view", "sales.invoices.create",
    "products.products.view",
    "parties.customers.view",
    "inventory.stock.view", "inventory.movements.view",
  ];
  const all = (): string[] => {
    const codes: string[] = [];
    for (const def of CATALOG) for (const a of def.actions) codes.push(`${def.module}.${def.entity}.${a}`);
    return codes;
  };
  switch (roleCode) {
    case "OWNER":
    case "SUPER_ADMIN":
      return all();
    case "BRANCH_MANAGER":
      return [
        ...core.flatMap((e) => (e.startsWith("audit") ? [`${e}.view`, `${e}.export`] : ["view", "create", "edit", "delete"].map((a) => `${e}.${a}`))),
        ...sellStack, "sales.invoices.edit", "sales.invoices.cancel", "sales.invoices.approve", "sales.invoices.reject",
        "sales.returns.view", "sales.returns.create",
        "finance.payments.view", "finance.payments.create", "finance.expenses.view", "finance.expenses.create", "finance.cashboxes.view", "finance.cashboxes.create", "finance.cashboxes.edit",
        "purchasing.purchase_invoices.view", "purchasing.purchase_invoices.create",
        "inventory.transfers.view", "inventory.transfers.create",
        "products.products.create", "products.products.edit",
        "parties.customers.create", "parties.customers.edit",
        "inventory.movements.create", "reports.reports.view", "reports.reports.export",
        // field sales (Phase 4) + B2B (Phase 8)
        "field.targets.view", "field.targets.create", "field.targets.edit",
        "field.visits.view", "field.visits.create", "field.visits.edit", "field.visits.cancel",
        "field.routes.view", "field.routes.create", "field.routes.edit",
        "field.commissions.view",
        "b2b.orders.view", "b2b.orders.approve", "b2b.orders.reject",
        "sales.orders.view", "sales.orders.create", "sales.orders.edit", "sales.orders.cancel",
        "products.products.import", "parties.customers.import",
        // completion: quotations / stocktake / delivery
        "sales.quotations.view", "sales.quotations.create", "sales.quotations.edit", "sales.quotations.post",
        "inventory.stocktakes.view", "inventory.stocktakes.create", "inventory.stocktakes.post",
        "sales.delivery_notes.view", "sales.delivery_notes.create", "sales.delivery_notes.edit",
        // advanced finance (cashbox-service) — full branch finance control
        "finance.receipts.view", "finance.receipts.create", "finance.receipts.cancel", "finance.receipts.print", "finance.receipts.export",
        "finance.payment_vouchers.view", "finance.payment_vouchers.create", "finance.payment_vouchers.cancel", "finance.payment_vouchers.print", "finance.payment_vouchers.export",
        "finance.cash_transfers.view", "finance.cash_transfers.create", "finance.cash_transfers.approve", "finance.cash_transfers.cancel",
        "finance.cash_closings.view", "finance.cash_closings.create", "finance.cash_closings.edit", "finance.cash_closings.cancel",
        "finance.statements.view", "finance.statements.export", "finance.statements.print",
        "finance.aging.view", "finance.aging.export",
        "finance.cashier_shifts.view", "finance.cashier_shifts.create", "finance.cashier_shifts.edit",
        "finance.recurring_expenses.view", "finance.recurring_expenses.create", "finance.recurring_expenses.edit",
        "finance.expense_categories.view", "finance.expense_categories.create", "finance.expense_categories.edit",
        "finance.bank_accounts.view",
        "finance.checks.view", "finance.checks.create", "finance.checks.edit",
        "finance.bank_deposits.view", "finance.bank_deposits.create",
        "finance.bank_withdrawals.view", "finance.bank_withdrawals.create",
        "accounting.accounts.view", "accounting.journal_entries.view", "accounting.budgets.view",
        "accounting.cost_centers.view", "accounting.cost_centers.create",
        "reports.accounting_reports.view", "reports.accounting_reports.export",
      ];
    case "SALES_MANAGER":
      return [
        ...coreView,
        ...sellStack, "sales.invoices.edit", "sales.invoices.cancel", "sales.invoices.print", "sales.invoices.approve", "sales.invoices.reject", "sales.orders.view", "sales.orders.create", "sales.orders.edit",
        "sales.returns.view", "sales.returns.create",
        "finance.payments.view", "finance.cashboxes.view", "purchasing.purchase_invoices.view",
        "products.products.create", "products.products.edit",
        "parties.customers.create", "parties.customers.edit",
        "reports.reports.view", "reports.reports.export", "reports.reports.print",
        // field sales (Phase 4) + B2B (Phase 8)
        "field.targets.view", "field.targets.create", "field.targets.edit", "field.targets.delete",
        "field.visits.view", "field.visits.create", "field.visits.edit", "field.visits.cancel",
        "field.routes.view", "field.routes.create", "field.routes.edit", "field.routes.delete",
        "field.commissions.view", "field.commissions.approve",
        "b2b.orders.view", "b2b.orders.approve", "b2b.orders.reject", "b2b.orders.cancel",
        "sales.orders.cancel", "products.products.import", "parties.customers.import",
        // completion: quotations / delivery
        "sales.quotations.view", "sales.quotations.create", "sales.quotations.edit", "sales.quotations.post", "sales.quotations.cancel",
        "sales.delivery_notes.view", "sales.delivery_notes.create", "sales.delivery_notes.edit", "sales.delivery_notes.cancel",
        "inventory.stocktakes.view",
      ];
    case "WAREHOUSE_MANAGER":
      return [
        "system.warehouses.view", "system.warehouses.edit", "system.branches.view", "system.users.view", "system.company.view",
        "inventory.stock.view", "inventory.movements.view", "inventory.movements.create",
        "inventory.transfers.view", "inventory.transfers.create",
        "products.products.view", "audit.audit_logs.view", "reports.reports.view",
        "sales.orders.view",
        // completion: stocktake (warehouse core duty) + delivery
        "inventory.stocktakes.view", "inventory.stocktakes.create", "inventory.stocktakes.post",
        "sales.delivery_notes.view", "sales.delivery_notes.create", "sales.delivery_notes.edit",
      ];
    case "CASHIER":
    case "SALES_REP":
      return [
        "system.company.view", ...sellStack,
        "sales.returns.view", "sales.returns.create",
        "sales.orders.view", "sales.orders.create",
        "finance.payments.create", "finance.cashboxes.view",
        // reps run their own day: visits (GPS), own targets/commissions, routes
        "field.visits.view", "field.visits.create", "field.visits.edit", "field.visits.cancel",
        "field.targets.view", "field.commissions.view", "field.routes.view",
        // completion: quotations (draft/own) + delivery view
        "sales.quotations.view", "sales.quotations.create",
        "sales.delivery_notes.view",
        // advanced finance — cashier runs the till: receipts + closings + shifts
        "finance.receipts.view", "finance.receipts.create", "finance.receipts.print",
        "finance.cash_transfers.view", "finance.cash_transfers.create",
        "finance.cash_closings.view", "finance.cash_closings.create", "finance.cash_closings.edit",
        "finance.cashier_shifts.view", "finance.cashier_shifts.create", "finance.cashier_shifts.edit",
        "finance.statements.view",
      ];
    case "ACCOUNTANT":
      return [
        ...coreView, "audit.audit_logs.export",
        "sales.invoices.view", "parties.customers.view",
        "sales.orders.view",
        "finance.cashboxes.view", "finance.payments.view", "finance.payments.create", "finance.expenses.view", "finance.expenses.create",
        "sales.returns.view", "purchasing.purchase_invoices.view",
        "reports.reports.view", "reports.reports.export",
        "field.commissions.view", "field.commissions.approve",
        "sales.quotations.view", "sales.delivery_notes.view", "inventory.stocktakes.view",
        // advanced finance — accountant owns vouchers, statements, aging, accounting
        "finance.receipts.view", "finance.receipts.create", "finance.receipts.cancel", "finance.receipts.print", "finance.receipts.export",
        "finance.payment_vouchers.view", "finance.payment_vouchers.create", "finance.payment_vouchers.cancel", "finance.payment_vouchers.print", "finance.payment_vouchers.export",
        "finance.cash_transfers.view", "finance.cash_transfers.create", "finance.cash_transfers.approve", "finance.cash_transfers.cancel",
        "finance.cash_closings.view", "finance.cash_closings.create", "finance.cash_closings.edit", "finance.cash_closings.cancel",
        "finance.statements.view", "finance.statements.export", "finance.statements.print",
        "finance.aging.view", "finance.aging.export",
        "finance.cashier_shifts.view",
        "finance.recurring_expenses.view", "finance.recurring_expenses.create", "finance.recurring_expenses.edit",
        "finance.expense_categories.view", "finance.expense_categories.create", "finance.expense_categories.edit",
        "finance.bank_accounts.view", "finance.bank_accounts.create", "finance.bank_accounts.edit",
        "finance.checks.view", "finance.checks.create", "finance.checks.edit",
        "finance.bank_deposits.view", "finance.bank_deposits.create",
        "finance.bank_withdrawals.view", "finance.bank_withdrawals.create",
        "accounting.accounts.view", "accounting.accounts.create", "accounting.accounts.edit",
        "accounting.journal_entries.view", "accounting.journal_entries.create", "accounting.journal_entries.post", "accounting.journal_entries.reverse",
        "accounting.budgets.view", "accounting.budgets.create", "accounting.budgets.edit",
        "accounting.financial_periods.view", "accounting.financial_periods.create", "accounting.financial_periods.post", "accounting.financial_periods.reverse",
        "accounting.cost_centers.view", "accounting.cost_centers.create", "accounting.cost_centers.edit",
        "reports.accounting_reports.view", "reports.accounting_reports.export", "reports.accounting_reports.print",
      ];
    case "PURCHASING_OFFICER":
      return [
        "system.company.view", "products.products.view",
        "parties.suppliers.view", "parties.suppliers.create", "parties.suppliers.edit",
        "purchasing.purchase_invoices.view", "purchasing.purchase_invoices.create",
        "finance.payments.view", "finance.payments.create", "finance.cashboxes.view",
        "inventory.stock.view", "inventory.movements.view", "inventory.movements.create",
        // advanced finance — supplier payments via payment vouchers
        "finance.payment_vouchers.view", "finance.payment_vouchers.create", "finance.payment_vouchers.print",
        "finance.statements.view",
        "finance.aging.view",
      ];
    case "AUDITOR":
      return [
        ...coreView, "audit.audit_logs.export",
        "sales.invoices.view", "products.products.view", "parties.customers.view", "parties.suppliers.view", "inventory.stock.view",
        "sales.returns.view", "purchasing.purchase_invoices.view",
        "finance.payments.view", "finance.cashboxes.view", "finance.expenses.view",
        "inventory.transfers.view", "reports.reports.view",
        "sales.orders.view",
        "field.targets.view", "field.visits.view", "field.routes.view", "field.commissions.view", "b2b.orders.view",
        "sales.quotations.view", "sales.delivery_notes.view", "inventory.stocktakes.view",
        // advanced finance — read-only access to all vouchers/transfers/closings/statements/aging/accounting
        "finance.receipts.view", "finance.receipts.export",
        "finance.payment_vouchers.view", "finance.payment_vouchers.export",
        "finance.cash_transfers.view",
        "finance.cash_closings.view",
        "finance.statements.view", "finance.statements.export", "finance.statements.print",
        "finance.aging.view", "finance.aging.export",
        "finance.cashier_shifts.view",
        "finance.recurring_expenses.view",
        "finance.expense_categories.view",
        "finance.bank_accounts.view",
        "finance.checks.view",
        "finance.bank_deposits.view",
        "finance.bank_withdrawals.view",
        "accounting.accounts.view", "accounting.journal_entries.view", "accounting.budgets.view",
        "accounting.financial_periods.view", "accounting.cost_centers.view",
        "reports.accounting_reports.view", "reports.accounting_reports.export", "reports.accounting_reports.print",
      ];
    case "VIEWER":
    default:
      return ["system.company.view"];
    case "CASH_KEEPER":
      // v14 — أمين الصندوق: شاشة إشعارات التسليم فقط (عرض + تسجيل التسليم).
      // system.company.view لكل الأدوار — تبقي «نظرة عامة» تعمل بلا أي تبويب إضافي.
      return [
        "system.company.view",
        "sales.delivery_notes.view",
        "sales.delivery_notes.edit",
      ];
  }
}

// Soft-unique upsert helper: compound unique includes nullable deletedAt,
// which Prisma upsert selectors can't address — use findFirst + create.
async function upsertSoft<T extends { id: number }>(
  find: () => Promise<T | null>,
  create: () => Promise<T>
): Promise<T> {
  const existing = await find();
  return existing ?? (await create());
}

/**
 * Idempotent Phase 0 seeding: permissions catalog · company · branch ·
 * warehouses · 11 roles + grants · 5 users · settings · doc sequences.
 * Safe to run any number of times (dedup-aware).
 */
export async function seedDatabase(log: (msg: string) => void = () => {}): Promise<void> {
  log("🌱 Seeding Phase 0 foundation data...");

  // 1) Permission catalog (global) — SQLite has no skipDuplicates → manual dedup
  const permRows: { code: string; module: string; entity: string; action: string; descriptionAr: string }[] = [];
  for (const p of allPermissions()) permRows.push(p);
  const existingCodes = new Set((await db.permission.findMany({ select: { code: true } })).map((r) => r.code));
  const fresh = permRows.filter((p) => !existingCodes.has(p.code));
  if (fresh.length) await db.permission.createMany({ data: fresh });
  log(`   ✔ permissions catalog: ${permRows.length} codes (${fresh.length} new)`);

  // 2) Admin company
  const company = await db.company.upsert({
    where: { uuid: "seed-company-uuid" },
    create: {
      uuid: "seed-company-uuid",
      code: "CO-NUKHBA",
      name: "شركة النخبة للتوزيع والتجارة",
      nameEn: "Al-Nukhba Distribution & Trading Co.",
      legalName: "شركة النخبة للتوزيع والتجارة المحدودة",
      taxNumber: "IQ-TAX-2026-00417",
      phone: "+9647701234567",
      email: "info@alnukhba.example",
      address: "بغداد — الكرادة، شارع 62",
      currencyCode: "IQD",
      settingsJson: JSON.stringify({ negative_stock: false, credit_guard: "BLOCK" }),
    },
    update: { code: "CO-NUKHBA" },
  });

  // 3) Branch + warehouses
  const branch = await upsertSoft(
    () => db.branch.findFirst({ where: { companyId: company.id, code: "BGW", deletedAt: null } }),
    () => db.branch.create({ data: { companyId: company.id, code: "BGW", name: "الفرع الرئيسي — بغداد", city: "بغداد", phone: "+9647701234567" } })
  );

  const mainWh = await upsertSoft(
    () => db.warehouse.findFirst({ where: { companyId: company.id, code: "WH-MAIN", deletedAt: null } }),
    () => db.warehouse.create({ data: { companyId: company.id, branchId: branch.id, code: "WH-MAIN", name: "المستودع الرئيسي", type: "MAIN" } })
  );
  const repWh = await upsertSoft(
    () => db.warehouse.findFirst({ where: { companyId: company.id, code: "REP-AHMED", deletedAt: null } }),
    () => db.warehouse.create({ data: { companyId: company.id, branchId: branch.id, code: "REP-AHMED", name: "مخزن المندوب أحمد (سيارة)", type: "REP", isMobile: true } })
  );

  // Multi-Branch demo: Basra branch gets its own MAIN warehouse + cashbox
  const basraBranch = await upsertSoft(
    () => db.branch.findFirst({ where: { companyId: company.id, code: "BSR", deletedAt: null } }),
    () => db.branch.create({ data: { companyId: company.id, code: "BSR", name: "فرع البصرة", city: "البصرة", phone: "+9647801234567" } })
  );
  const basraWh = await upsertSoft(
    () => db.warehouse.findFirst({ where: { companyId: company.id, code: "WH-BSR", deletedAt: null } }),
    () => db.warehouse.create({ data: { companyId: company.id, branchId: basraBranch.id, code: "WH-BSR", name: "مستودع البصرة الرئيسي", type: "MAIN" } })
  );

  // 4) Roles + role_permissions — grants are CODE-DEFINED, so they are
  //    force-refreshed on every seed run (delete + recreate) to pick up
  //    new catalog entities without a manual wipe.
  const roleMap = new Map<string, number>();
  for (const def of SYSTEM_ROLES) {
    const role = await upsertSoft(
      () => db.role.findFirst({ where: { companyId: company.id, code: def.code, deletedAt: null } }),
      () => db.role.create({ data: { companyId: company.id, code: def.code, name: def.name, description: def.description, isSystem: true } })
    );
    roleMap.set(def.code, role.id);

    const codes = rolePermissionCodes(def.code);
    const perms = await db.permission.findMany({ where: { code: { in: codes } }, select: { id: true } });
    await db.rolePermission.deleteMany({ where: { roleId: role.id } });
    await db.rolePermission.createMany({
      data: perms.map((p) => ({ companyId: company.id, roleId: role.id, permissionId: p.id })),
    });
    log(`   ✔ role ${def.code.padEnd(18)} → ${perms.length} permissions (refreshed)`);
  }

  // 5) Users: admin (owner) + cashier + auditor + a demo sales rep + lock demo
  //    OWNER gets BOTH warehouses (main + rep van) for oversight + transfers.
  let adminUser!: { id: number };
  const users = [
    { username: "admin", fullName: "أحمد المدير العام", password: "Admin@123", role: "OWNER", branchId: branch.id, scopeType: "GLOBAL", warehouses: [mainWh.id, repWh.id], branches: [branch.id, basraBranch.id], companies: [company.id], canOperate: true },
    { username: "cashier", fullName: "سجاد الكاشير", password: "Cashier@123", role: "CASHIER", branchId: branch.id, scopeType: "BRANCH", warehouses: [mainWh.id], branches: [branch.id], companies: [] as number[], canOperate: true },
    { username: "auditor", fullName: "ليلى المراجعة", password: "Auditor@123", role: "AUDITOR", branchId: branch.id, scopeType: "COMPANY", warehouses: [mainWh.id], branches: [branch.id, basraBranch.id], companies: [] as number[], canOperate: false },
    { username: "rep.ahmed", fullName: "أحمد المندوب", password: "Rep@12345", role: "SALES_REP", branchId: branch.id, scopeType: "SALES_REP", warehouses: [repWh.id], branches: [branch.id], companies: [] as number[], canOperate: true },
    { username: "lockdemo", fullName: "حساب اختبار القفل", password: "Lock@12345", role: "VIEWER", branchId: branch.id, scopeType: "BRANCH", warehouses: [mainWh.id], branches: [branch.id], companies: [] as number[], canOperate: false },
    // ---- Multi-Company / Multi-Branch demo users (MASTER PROMPT Phase 42) ----
    { username: "baghdad.admin", fullName: "مدير فرع بغداد", password: "Baghdad@123", role: "BRANCH_MANAGER", branchId: branch.id, scopeType: "BRANCH", warehouses: [mainWh.id], branches: [branch.id], companies: [] as number[], canOperate: true },
    { username: "basra.admin", fullName: "مدير فرع البصرة", password: "Basra@123", role: "BRANCH_MANAGER", branchId: basraBranch.id, scopeType: "BRANCH", warehouses: [basraWh.id], branches: [basraBranch.id], companies: [] as number[], canOperate: true },
    { username: "central.manager", fullName: "المدير المركزي (بغداد + البصرة)", password: "Central@123", role: "BRANCH_MANAGER", branchId: branch.id, scopeType: "BRANCH", warehouses: [mainWh.id, basraWh.id], branches: [branch.id, basraBranch.id], companies: [] as number[], canOperate: true },
    { username: "warehouse.user", fullName: "أمين مستودع البصرة", password: "Warehous@123", role: "WAREHOUSE_MANAGER", branchId: basraBranch.id, scopeType: "WAREHOUSE", warehouses: [basraWh.id], branches: [basraBranch.id], companies: [] as number[], canOperate: true },
    // v14 — حساب أمين الصندوق (أمين المخزن لشاشة التسليم): يرى إشعارات التسليم فقط
    // ويُبلَّغ حصراً بحالات النقص — مفعّل ذاتياً عبر ensureCashKeeperAccounts حتى للقواعد القائمة.
    { username: "cashkeeper", fullName: "أمين الصندوق", password: "Keeper@123", role: "CASH_KEEPER", branchId: branch.id, scopeType: "BRANCH", warehouses: [mainWh.id], branches: [branch.id], companies: [] as number[], canOperate: true },
  ];

  for (const u of users) {
    const user = await upsertSoft(
      () => db.user.findFirst({ where: { companyId: company.id, username: u.username, deletedAt: null } }),
      () =>
        hash(u.password).then((passwordHash) =>
          db.user.create({
            data: {
              companyId: company.id,
              branchId: u.branchId,
              username: u.username,
              email: `${u.username.replace(".", "-")}@alnukhba.example`,
              fullName: u.fullName,
              passwordHash,
              scopeType: (u as { scopeType?: string }).scopeType ?? "BRANCH",
            },
          })
        )
    );
    const hasRole = await db.userRole.findFirst({ where: { userId: user.id, roleId: roleMap.get(u.role)! } });
    if (!hasRole) {
      await db.userRole.create({ data: { companyId: company.id, userId: user.id, roleId: roleMap.get(u.role)! } });
    }
    // scope sync (idempotent): scope_type + branch access + company access
    const scopeType = (u as { scopeType?: string }).scopeType ?? "BRANCH";
    if (user.scopeType !== scopeType) {
      await db.user.update({ where: { id: user.id }, data: { scopeType } });
    }
    for (const bid of (u as { branches?: number[] }).branches ?? []) {
      const hasBr = await db.userBranchAccess.findFirst({ where: { userId: user.id, branchId: bid } });
      if (!hasBr) {
        await db.userBranchAccess.create({ data: { companyId: company.id, userId: user.id, branchId: bid } });
      }
    }
    for (const cid of (u as { companies?: number[] }).companies ?? []) {
      const hasCo = await db.userCompanyAccess.findFirst({ where: { userId: user.id, companyId: cid } });
      if (!hasCo) {
        await db.userCompanyAccess.create({ data: { userId: user.id, companyId: cid, isPrimary: cid === company.id } });
      }
    }
    for (const wid of u.warehouses) {
      const hasWh = await db.userWarehouseAccess.findFirst({ where: { userId: user.id, warehouseId: wid } });
      if (!hasWh) {
        await db.userWarehouseAccess.create({
          data: { companyId: company.id, userId: user.id, warehouseId: wid, canRead: true, canOperate: u.canOperate },
        });
      }
    }
    if (u.username === "admin") adminUser = user;
    log(`   ✔ user ${u.username.padEnd(10)} (${u.role}) password=${u.password}`);
  }

  // 6) Default settings
  const settings: [string, unknown, string, string][] = [
    ["security.max_failed_logins", 5, "security", "عدد المحاولات الفاشلة قبل القفل"],
    ["security.lockout_minutes", 15, "security", "مدة قفل الحساب بالدقائق"],
    ["invoice.numbering.format", "{PREFIX}-{YEAR}-{SEQ:6}", "numbering", "صيغة ترقيم الفواتير"],
    ["finance.currency", "IQD", "general", "عملة النظام الأساسية"],
    // ---- Phase 2 §7: سعر صرف الشركة المعتمد (د.ع لكل $1) -------------------
    // يُستخدم لتحويل الأسعار المخزنة بالدولار فقط — بلا تخمين عند العرض.
    ["currency.usd_rate_iqd", 1550, "currency", "سعر صرف الدولار — د.ع لكل $1 (يُحدَّث من شاشة المنتجات/الفواتير)"],
    // ---- Smart invoice settings (§41/§22/§20/§12/§6) -------------------
    ["invoice.footer_text", "البضاعة المباعة لا تستبدل إلا حسب سياسة الشركة.\nشكراً لتعاملكم معنا.", "invoice", "نص تذييل الفاتورة (قابل للتعديل)"],
    ["invoice.show_mini_statement", true, "invoice", "إظهار كشف الحساب المختصر داخل الفاتورة"],
    ["invoice.packaging_details_default", true, "invoice", "تفاصيل التعبئة مفعّلة افتراضيًا (§20)"],
    ["invoice.open_package_policy", "OPEN_FIRST", "invoice", "سياسة السحب: من العبوة المفتوحة أولًا (§12)"],
    // ---- Walk-In customer system (Phases 19/20) --------------------------
    ["customers.labels", { REGISTERED: "عميل مسجل", WALK_IN: "زبون نقدي / متردد", CASH_CUSTOMER: "زبون كاشي", GUEST: "زبون غير معروف" }, "customers", "مسميات أنواع العملاء القابلة للتعديل (§19)"],
    ["walkin.strategy", "SHARED", "customers", "استراتيجية الزبون المتردد: سجل افتراضي مشترك واحد (§52)"],
  ];
  for (const [key, value, group, description] of settings) {
    await db.setting.upsert({
      where: { companyId_key: { companyId: company.id, key } },
      create: { companyId: company.id, key, value: JSON.stringify(value), groupName: group, description },
      update: {},
    });
  }
  log("   ✔ default settings (4 keys)");

  // ---- Backfills (idempotent) -------------------------------------------
  // a) existing REGISTERED customers → assign home branch. System-managed
  //    walk-in types stay company-wide (branchId null) so every branch's
  //    POS shares the same "زبون نقدي" record.
  await db.customer.updateMany({
    where: { companyId: company.id, branchId: null, customerType: "REGISTERED", deletedAt: null },
    data: { branchId: branch.id },
  });

  // b) cashbox mirror rows (auto cash-IN for posted invoices) were briefly
  //    written with refType SALES_INVOICE — distinguish them from manual
  //    collections so customer statements don't double-count (§31 fix).
  await db.cashTransaction.updateMany({
    where: { refType: "SALES_INVOICE", category: "COLLECTION", note: { startsWith: "تحصيل فاتورة" } },
    data: { refType: "SALES_INVOICE_CASH" },
  });

  // ---- Walk-In default customer (Phase 20) — CASH-001 زبون نقدي ----------
  const walkin = await ensureWalkInCustomer(company.id);
  if (walkin.branchId != null) {
    await db.customer.update({ where: { id: walkin.id }, data: { branchId: null } });
  }
  log(`   ✔ default walk-in customer: ${walkin.code} (${walkin.name})`);
  // b) Basra cashbox for the new branch (cashbox integration Phase 31)
  await upsertSoft(
    () => db.cashbox.findFirst({ where: { companyId: company.id, code: "CB-BSR", deletedAt: null } }),
    () => db.cashbox.create({ data: { companyId: company.id, branchId: basraBranch.id, code: "CB-BSR", name: "صندوق فرع البصرة", createdBy: adminUser.id } })
  );

  // 7) Document sequences row for current year
  const year = new Date().getFullYear();
  const seq = [
    ["INVOICE", "INV"], ["ORDER", "ORD"], ["PAYMENT", "PAY"], ["TRANSFER", "TRF"], ["PO", "PO"],
  ] as const;
  for (const [docType, prefix] of seq) {
    await db.documentSequence.upsert({
      where: { companyId_docType_year: { companyId: company.id, docType, year } },
      create: { companyId: company.id, docType, prefix, year },
      update: {},
    });
  }
  log(`   ✔ document sequences (${seq.length} types, year ${year})`);

  // 8) Phase 1–3 live demo data — only on a fresh database, so the user
  //    opens the app onto a living sales system, not empty screens.
  const productCount = await db.product.count({ where: { companyId: company.id, deletedAt: null } });
  if (productCount === 0) {
    // 8a) Categories
    const catNames = ["مواد غذائية", "مشروبات", "منظفات", "أدوات منزلية"];
    const cats = new Map<string, number>();
    for (const name of catNames) {
      const c = await upsertSoft(
        () => db.category.findFirst({ where: { companyId: company.id, name, deletedAt: null } }),
        () => db.category.create({ data: { companyId: company.id, name, createdBy: adminUser.id } })
      );
      cats.set(name, c.id);
    }
    log(`   ✔ demo categories: ${cats.size}`);

    // 8b) Products — Phase 2 §1/§2: الوحدة الأساسية = أصغر وحدة بيع،
    //     والتعبئة عبوة أكبر تختلف عنها (baseUnit !== packageUnit).
    const demoProducts = [
      // منتجان معبآن لعرض نظام الكراتين/العلب (§9-§11)
      { name: "زيت دوار الشمس 5 لتر", cat: "مواد غذائية", unit: "حبة", packUnit: "كرتون", packQty: 4, cost: 7500, sale: 8500, min: 20 },
      { name: "مياه معدنية 12×1.5 لتر", cat: "مشروبات", unit: "قنينة", packUnit: "كرتون", packQty: 12, cost: 2500, sale: 3000, min: 30 },
      // بقية المنتجات بلا تعبئة — الوحدة الأساسية هي وحدة البيع (صالح §3)
      { name: "أرز بسمتي 5 كغ", cat: "مواد غذائية", unit: "كيس", cost: 6000, sale: 7000, min: 15 },
      { name: "سكر أبيض 10 كغ", cat: "مواد غذائية", unit: "كيس", cost: 8000, sale: 9000, min: 10 },
      { name: "شاي فاخر 500 غ", cat: "مشروبات", unit: "علبة", cost: 3000, sale: 3750, min: 12 },
      { name: "معجون طماطم 400 غ", cat: "مواد غذائية", unit: "علبة", cost: 750, sale: 1000, min: 40 },
      { name: "صابون سائل 1 لتر", cat: "منظفات", unit: "قطعة", cost: 1500, sale: 2000, min: 20 },
      { name: "منظف أرضيات 2 لتر", cat: "منظفات", unit: "جالون", cost: 2000, sale: 2750, min: 15 },
    ];
    const prods: { id: number; name: string; sale: number }[] = [];
    let pseq = 0;
    for (const p of demoProducts) {
      pseq += 1;
      const pack = validatePackaging({ unit: p.unit, packUnit: (p as { packUnit?: string }).packUnit, packQty: (p as { packQty?: number }).packQty });
      const created = await upsertSoft(
        () => db.product.findFirst({ where: { companyId: company.id, name: p.name, deletedAt: null } }),
        () =>
          db.product.create({
            data: {
              companyId: company.id,
              categoryId: cats.get(p.cat)!,
              code: `P-${String(pseq).padStart(5, "0")}`,
              name: p.name,
              unit: pack.unit,
              packUnit: pack.packUnit,
              packQty: pack.packQty,
              packSalePrice: pack.hasPack ? Math.round(p.sale * (pack.packQty ?? 1) * 100) / 100 : null,
              costPrice: p.cost,
              salePrice: p.sale,
              minStock: p.min,
              createdBy: adminUser.id,
            },
          })
      );
      // Phase 2 §4: كل منتج يبدأ بطبقة أسعار مهيكلة (SALE/PIECE + COST + SALE/PACKAGE)
      await syncProductPrices(db, {
        companyId: company.id,
        productId: created.id,
        packQty: pack.packQty,
        userId: adminUser.id,
        input: {
          cost_price: p.cost,
          sale_price: p.sale,
          pack_sale_price: pack.hasPack ? Math.round(p.sale * (pack.packQty ?? 1) * 100) / 100 : null,
        },
      });
      prods.push({ id: created.id, name: created.name, sale: p.sale });
    }
    log(`   ✔ demo products: ${prods.length} (structured prices + packaging)`);

    // 8c) Customers
    const demoCustomers = [
      { name: "بقالة الأمانة", phone: "07701112233", limit: 2000000 },
      { name: "ماركت الرافدين", phone: "07704445566", limit: 5000000 },
      { name: "سوبرماركت النور", phone: "07707778899", limit: 1500000 },
      { name: "مطعم دجلة", phone: "07801213456", limit: 3000000 },
      { name: "مخبز السلام", phone: "07809876543", limit: 0 },
    ];
    const custs: { id: number; name: string }[] = [];
    let cseq = 0;
    for (const c of demoCustomers) {
      cseq += 1;
      const created = await upsertSoft(
        () => db.customer.findFirst({ where: { companyId: company.id, name: c.name, deletedAt: null } }),
        () =>
          db.customer.create({
            data: {
              companyId: company.id,
              code: `C-${String(cseq).padStart(5, "0")}`,
              name: c.name,
              phone: c.phone,
              creditLimit: c.limit,
              createdBy: adminUser.id,
            },
          })
      );
      custs.push({ id: created.id, name: created.name });
    }
    log(`   ✔ demo customers: ${custs.length}`);

    // 8d) Opening stock intake (MAIN) + rep van stock
    const intake: [number, number][] = [
      [0, 120], [1, 80], [2, 60], [3, 200], [4, 50], [5, 150], [6, 90], [7, 70],
    ];
    for (const [idx, qty] of intake) {
      await db.$transaction((tx) =>
        applyStockMovement({
          tx,
          companyId: company.id,
          warehouseId: mainWh.id,
          productId: prods[idx].id,
          direction: "IN",
          qty,
          refType: "INTAKE",
          note: "رصيد افتتاحي — زرع تجريبي",
          userId: adminUser.id,
        })
      );
    }
    for (const idx of [0, 1, 3]) {
      await db.$transaction((tx) =>
        applyStockMovement({
          tx,
          companyId: company.id,
          warehouseId: repWh.id,
          productId: prods[idx].id,
          direction: "IN",
          qty: 25,
          refType: "INTAKE",
          note: "تحميل سيارة المندوب",
          userId: adminUser.id,
        })
      );
    }
    log(`   ✔ opening stock: ${intake.length} products → MAIN + 3 → REP-AHMED`);

    // 8e) Two demo invoices through the real service (numbering + stock + audit)
    const actor = { userId: adminUser.id, companyId: company.id, warehouseIds: [mainWh.id, repWh.id] };
    const inv1 = await createSalesInvoice(actor, {
      customerId: custs[0].id,
      warehouseId: mainWh.id,
      type: "CASH",
      notes: "فاتورة تجريبية — بيع نقدي",
      lines: [
        { productId: prods[0].id, qty: 3 },
        { productId: prods[4].id, qty: 5 },
      ],
    });
    const inv2 = await createSalesInvoice(actor, {
      customerId: custs[1].id,
      warehouseId: mainWh.id,
      type: "CREDIT",
      notes: "فاتورة تجريبية — آجل",
      lines: [
        { productId: prods[2].id, qty: 10 },
        { productId: prods[3].id, qty: 20, discount_pct: 5 },
      ],
    });
    log(`   ✔ demo invoices: ${inv1.number} (CASH) + ${inv2.number} (CREDIT)`);
    log(`   ✔ receivables now: ${num(moneyR(dec(await db.customer.aggregate({ where: { companyId: company.id }, _sum: { balance: true } }).then((r) => r._sum.balance))))} IQD`);
  }

  // 9) Phase 4–7 live demo data — finance/purchasing/returns. Runs when
  //    cashboxes table is empty but products exist (fresh OR legacy db).
  const cashboxCount = await db.cashbox.count({ where: { companyId: company.id, deletedAt: null } });

  const sups: { id: number; name: string }[] = []; // مرجع لفواتير الشراء في 9c/9d
  // 9a) Suppliers — دائماً (idempotent): قواعد بيانات مستعادة قد تملك صناديق
  //     قديمة فتتخطى بوابة القسم 9 وتُترك قوائم الموردين فارغة فتفشل المشتريات
  {
    const demoSuppliers = [
      { name: "شركة الغذاء الوطنية", phone: "07811112222" },
      { name: "مؤسسة المنظفات الحديثة", phone: "07833334444" },
    ];
    let sseq = 0;
    for (const s of demoSuppliers) {
      sseq += 1;
      const created = await upsertSoft(
        () => db.supplier.findFirst({ where: { companyId: company.id, name: s.name, deletedAt: null } }),
        () => db.supplier.create({ data: { companyId: company.id, code: `S-${String(sseq).padStart(5, "0")}`, name: s.name, phone: s.phone, createdBy: adminUser.id } })
      );
      sups.push({ id: created.id, name: created.name });
    }
    log(`   ✔ demo suppliers: ${sups.length}`);
  }

  // 9a-2) شفاء القواعد المستعادة (legacy): صندوق قديم بلا حركة افتتاح أو موردون بلا ذمة.
  //       تجعل دفتر الصندوق متوازناً (balance = SUM(transactions)) وتضمن مورداً دائناً للمشتريات.
  if (cashboxCount > 0) {
    const healActor = { userId: adminUser.id, companyId: company.id, warehouseIds: [mainWh.id, repWh.id] };
    const legacyBoxes = await db.cashbox.findMany({ where: { companyId: company.id, deletedAt: null } });
    let healed = 0;
    for (const box of legacyBoxes) {
      const hasOpening = await db.cashTransaction.findFirst({ where: { cashboxId: box.id, category: "OPENING" } });
      if (hasOpening) continue;
      const sumIN = await db.cashTransaction.aggregate({ where: { cashboxId: box.id, direction: "IN" }, _sum: { amount: true } });
      const sumOUT = await db.cashTransaction.aggregate({ where: { cashboxId: box.id, direction: "OUT" }, _sum: { amount: true } });
      // المعادلة: الرصيد الحالي = افتتاحي + (SUM(IN) − SUM(OUT)) — نحسب الافتتاح الناقص
      const delta = moneyR(dec(box.balance).minus(dec(sumIN._sum.amount)).plus(dec(sumOUT._sum.amount)));
      if (!delta.isZero()) {
        await db.cashTransaction.create({
          data: {
            companyId: company.id,
            cashboxId: box.id,
            direction: delta.isPositive() ? "IN" : "OUT",
            category: "OPENING",
            amount: delta.abs(),
            balanceAfter: box.balance,
            note: "حركة افتتاح شفائية — قاعدة بيانات مستعادة (توثيق دون تغيير الرصيد)",
            createdBy: adminUser.id,
          },
        });
        healed += 1;
      }
    }
    if (healed) log(`   ✔ healing: ${healed} legacy cashbox(es) got an OPENING row`);

    const hasPayable = await db.supplier.findFirst({ where: { companyId: company.id, balance: { gt: 0 }, deletedAt: null } });
    const anyHealProduct = await db.product.findFirst({ where: { companyId: company.id, deletedAt: null }, orderBy: { id: "asc" } });
    if (!hasPayable && anyHealProduct && sups.length) {
      await createPurchaseInvoice(healActor, {
        supplierId: sups[0].id,
        warehouseId: mainWh.id,
        type: "CREDIT",
        notes: "فاتورة شراء شفائية — استعادة ذمة مورد بعد استرجاع قاعدة بيانات قديمة",
        lines: [{ productId: anyHealProduct.id, qty: 10, unitCost: num(anyHealProduct.costPrice) }],
      });
      log("   ✔ healing: supplier payable restored via CREDIT purchase");
    }
  }

  if (cashboxCount === 0) {
    const anyProduct = await db.product.findFirst({
      where: { companyId: company.id, deletedAt: null },
      orderBy: { id: "asc" },
    });
    if (anyProduct) {
      const products = await db.product.findMany({
        where: { companyId: company.id, deletedAt: null },
        orderBy: { id: "asc" },
        take: 8,
      });

      // 9b) Cashboxes + opening balances through the finance service
      const cbMain = await upsertSoft(
        () => db.cashbox.findFirst({ where: { companyId: company.id, code: "CB-MAIN", deletedAt: null } }),
        () => db.cashbox.create({ data: { companyId: company.id, branchId: branch.id, code: "CB-MAIN", name: "صندوق الفرع الرئيسي", createdBy: adminUser.id } })
      );
      const actor = { userId: adminUser.id, companyId: company.id, warehouseIds: [mainWh.id, repWh.id] };
      if (dec(cbMain.balance).isZero()) {
        await openCashbox(actor, { cashboxId: cbMain.id, amount: 5_000_000, note: "رصيد افتتاحي — زرع تجريبي" });
      }
      log("   ✔ cashbox CB-MAIN opened (5,000,000 IQD)");

      // 9c) Purchase invoice — CASH (stock IN + WAVG cost + cash OUT)
      const pur1 = await createPurchaseInvoice(actor, {
        supplierId: sups[0].id,
        warehouseId: mainWh.id,
        type: "CASH",
        notes: "فاتورة شراء تجريبية — نقدية",
        lines: [
          { productId: products[0].id, qty: 20, unitCost: 7600 },
          { productId: products[3].id, qty: 40, unitCost: 2550 },
        ],
      });
      log(`   ✔ demo purchase (CASH): ${pur1.number}`);

      // 9d) Purchase invoice — CREDIT (supplier payable)
      const pur2 = await createPurchaseInvoice(actor, {
        supplierId: sups[1].id,
        warehouseId: mainWh.id,
        type: "CREDIT",
        notes: "فاتورة شراء تجريبية — آجلة",
        lines: [
          { productId: products[6].id, qty: 30, unitCost: 1450 },
          { productId: products[7].id, qty: 20, unitCost: 2050 },
        ],
      });
      log(`   ✔ demo purchase (CREDIT): ${pur2.number} — مستحق للمورد ${num(pur2.due_amount)} IQD`);

      // 9e) Collection from a credit customer (the receivable from 8e)
      const creditCustomer = await db.customer.findFirst({
        where: { companyId: company.id, deletedAt: null, balance: { gt: 0 } },
        orderBy: { balance: "desc" },
      });
      if (creditCustomer) {
        const collectAmount = num(Decimal.min(new Decimal(50_000), dec(creditCustomer.balance)));
        const col = await collectFromCustomer(actor, {
          customerId: creditCustomer.id,
          cashboxId: cbMain.id,
          amount: collectAmount,
          note: "تحصيل تجريبي من الزرع",
        });
        log(`   ✔ demo collection: ${col.number} من ${creditCustomer.name} بمبلغ ${collectAmount} IQD`);
      }

      // 9f) Expense
      const exp = await recordExpense(actor, {
        cashboxId: cbMain.id,
        amount: 75_000,
        title: "كهرباء ومياه الفرع",
        note: "مصروف تجريبي من الزرع",
      });
      log(`   ✔ demo expense: ${exp.number} — 75,000 IQD`);

      // 9g) Return against the latest CASH invoice with stock left
      const cashInvoice = await db.salesInvoice.findFirst({
        where: { companyId: company.id, deletedAt: null, type: "CASH", status: "POSTED" },
        orderBy: { id: "asc" },
        include: { lines: { orderBy: { id: "asc" } } },
      });
      if (cashInvoice && cashInvoice.lines.length > 0) {
        const line = cashInvoice.lines[0];
        const retQty = Decimal.min(new Decimal(1), dec(line.qty));
        const ret = await createSalesReturn(actor, {
          invoiceId: cashInvoice.id,
          cashboxId: cbMain.id,
          refundCash: num(moneyR(retQty.mul(dec(line.unitPrice)))),
          notes: "مرتجع تجريبي من الزرع",
          lines: [{ invoiceLineId: line.id, qty: num(retQty) }],
        });
        log(`   ✔ demo return: ${ret.number} على ${cashInvoice.number} — رد نقدي ${ret.refund_cash} IQD`);
      }

      log(`   ✔ receivables now: ${num(moneyR(dec(await db.customer.aggregate({ where: { companyId: company.id }, _sum: { balance: true } }).then((r) => r._sum.balance))))} IQD · payables: ${num(moneyR(dec(await db.supplier.aggregate({ where: { companyId: company.id }, _sum: { balance: true } }).then((r) => r._sum.balance))))} IQD`);
    }
  }

  // 10) Phase 4 (Field sales) + Phase 8 (B2B) live demo data — runs when
  //     commission rules are absent but the company is seeded (fresh OR legacy db).
  const ruleCount = await db.commissionRule.count({ where: { companyId: company.id, deletedAt: null } });
  if (ruleCount === 0) {
    const rep = await db.user.findFirst({
      where: { companyId: company.id, username: "rep.ahmed", deletedAt: null },
      include: { roles: { include: { role: true } } },
    });
    const products = await db.product.findMany({
      where: { companyId: company.id, deletedAt: null },
      orderBy: { id: "asc" },
      take: 8,
    });
    const customers = await db.customer.findMany({
      where: { companyId: company.id, deletedAt: null },
      orderBy: { id: "asc" },
      take: 5,
    });

    if (rep && products.length && customers.length) {
      const adminActor = { userId: adminUser.id, companyId: company.id, warehouseIds: [mainWh.id, repWh.id] };

      // 10a) Commission rules — the 4 engine types (3 rules deployed)
      const rules = [
        { name: "عمولة نسبة من المبيعات", ruleType: "PERCENT_OF_SALES", rate: 1.5, amount: 0, perUnitRate: 0, minInvoiceTotal: 0 },
        { name: "عمولة ثابتة للفاتورة الكبيرة", ruleType: "FIXED_PER_INVOICE", rate: 0, amount: 2000, perUnitRate: 0, minInvoiceTotal: 100_000 },
        { name: "عمولة شرائح تحقيق الهدف", ruleType: "TIER_BY_TARGET", rate: 1, amount: 0, perUnitRate: 0, minInvoiceTotal: 0 },
      ];
      for (const r of rules) {
        await upsertSoft(
          () => db.commissionRule.findFirst({ where: { companyId: company.id, name: r.name, deletedAt: null } }),
          () => db.commissionRule.create({ data: { ...r, companyId: company.id, createdBy: adminUser.id } })
        );
      }
      log("   ✔ commission rules: 3 (percent 1.5% · fixed 2,000 ≥100k · tier 1%)");

      // 10b) Monthly target for the rep (current period)
      const period = periodOf(new Date());
      await upsertSoft(
        () => db.repTarget.findFirst({ where: { companyId: company.id, repId: rep.id, period, deletedAt: null } }),
        () => db.repTarget.create({ data: { companyId: company.id, repId: rep.id, period, targetAmount: 3_000_000, notes: "هدف تجريبي — الزرع", createdBy: adminUser.id } })
      );
      log(`   ✔ rep target ${period}: 3,000,000 IQD for ${rep.fullName}`);

      // 10c) Distribution route with 3 ordered customers
      const route = await upsertSoft(
        () => db.route.findFirst({ where: { companyId: company.id, name: "مسار الكرادة — الأحد", deletedAt: null } }),
        () =>
          createRoute(adminActor, {
            name: "مسار الكرادة — الأحد",
            repId: rep.id,
            dayOfWeek: 0,
            customerIds: customers.slice(0, 3).map((c) => c.id),
          })
      );
      log("   ✔ demo route: مسار الكرادة — الأحد (3 عملاء)");

      // 10d) Visits: one completed with GPS + two planned today
      const today = new Date();
      today.setHours(10, 0, 0, 0);
      const existingVisits = await db.visit.count({ where: { companyId: company.id, repId: rep.id } });
      if (existingVisits === 0) {
        const v1 = await planVisit(adminActor, {
          customerId: customers[0].id,
          repId: rep.id,
          plannedDate: today.toISOString(),
          routeId: route.id,
          notes: "زيارة تجريبية مكتملة",
        });
        await checkinVisit(
          { userId: rep.id, companyId: company.id, warehouseIds: [repWh.id] },
          v1.id,
          { lat: 33.3152, lng: 44.3661 }
        );
        await completeVisit(
          { userId: rep.id, companyId: company.id, warehouseIds: [repWh.id] },
          v1.id,
          { outcome: "ORDERED", orderValue: 127_500, notes: "طلبية زيت دوار الشمس" }
        );
        await planVisit(adminActor, {
          customerId: customers[1].id,
          repId: rep.id,
          plannedDate: new Date(today.getTime() + 3600_000).toISOString(),
          routeId: route.id,
          notes: "زيارة مجدولة — بعد ساعة",
        });
        await planVisit(adminActor, {
          customerId: customers[2].id,
          repId: rep.id,
          plannedDate: new Date(today.getTime() + 7200_000).toISOString(),
          routeId: route.id,
          notes: "زيارة مجدولة — تحصيل محتمل",
        });
        log("   ✔ demo visits: 1 completed (GPS 33.3152,44.3661) + 2 planned");
      }

      // 10e) One rep invoice through the real service → commissions auto-generate
      const repInvoices = await db.salesInvoice.count({ where: { companyId: company.id, createdById: rep.id, deletedAt: null } });
      if (repInvoices === 0) {
        // ensure van stock for the demo product
        const bal = await db.stockBalance.findFirst({
          where: { warehouseId: repWh.id, productId: products[0].id },
        });
        if (!bal || dec(bal.qty).lt(20)) {
          await db.$transaction((tx) =>
            applyStockMovement({
              tx,
              companyId: company.id,
              warehouseId: repWh.id,
              productId: products[0].id,
              direction: "IN",
              qty: 20,
              refType: "INTAKE",
              note: "تحميل سيارة المندوب — زرع تجريبي",
              userId: adminUser.id,
            })
          );
        }
        const repActor = { userId: rep.id, companyId: company.id, warehouseIds: [repWh.id] };
        const repInv = await createSalesInvoice(repActor, {
          customerId: customers[0].id,
          warehouseId: repWh.id,
          type: "CASH",
          notes: "بيع ميداني من سيارة المندوب",
          lines: [{ productId: products[0].id, qty: 15 }],
        });
        const commissions = await db.commission.count({ where: { invoiceId: repInv.id } });
        log(`   ✔ rep invoice ${repInv.number} → ${commissions} commissions auto-generated`);
      }

      // 10f) B2B portal: pins + own-price discounts + one submitted order
      const pins: [number, string][] = [
        [customers[0].id, "1122"],
        [customers[1].id, "2211"],
      ];
      for (const [cid, pin] of pins) {
        const c = await db.customer.findUnique({ where: { id: cid } });
        if (c && !c.portalPinHash) await setPortalPin(adminActor, cid, pin);
      }
      if (dec(customers[0].discountPct).isZero()) {
        await db.customer.update({ where: { id: customers[0].id }, data: { discountPct: 2 } });
      }
      if (dec(customers[1].discountPct).isZero()) {
        await db.customer.update({ where: { id: customers[1].id }, data: { discountPct: 3 } });
      }
      const b2bCount = await db.b2BOrder.count({ where: { companyId: company.id } });
      if (b2bCount === 0) {
        const order = await b2bCreateOrder(customers[1].id, {
          notes: "طلب تجريبي من بوابة العملاء",
          lines: [
            { product_id: products[3].id, qty: 30 },
            { product_id: products[5].id, qty: 50 },
          ],
        });
        log(`   ✔ B2B order ${order.number} submitted (${num(order.grand_total)} IQD at customer prices)`);
      }
      log("   ✔ B2B portal: C-00001 pin 1122 (خصم 2%) · C-00002 pin 2211 (خصم 3%)");

      // 10g) Sales orders pipeline demo — one DRAFT + one CONFIRMED ready to convert
      const soCount = await db.salesOrder.count({ where: { companyId: company.id } });
      if (soCount === 0 && products.length >= 4) {
        const draft = await createSalesOrder(adminActor, {
          customerId: customers[2]?.id ?? customers[0].id,
          warehouseId: mainWh.id,
          notes: "أمر بيع تجريبي — مسودة بانتظار التأكيد",
          lines: [
            { productId: products[1].id, qty: 25 },
            { productId: products[2].id, qty: 10 },
          ],
        });
        const confirmed = await createSalesOrder(adminActor, {
          customerId: customers[0].id,
          warehouseId: mainWh.id,
          notes: "أمر بيع تجريبي مؤكد — جاهز للتحويل إلى فاتورة",
          lines: [
            { productId: products[0].id, qty: 12 },
            { productId: products[3].id, qty: 20, discountPct: 5 },
          ],
        });
        await confirmSalesOrder(adminActor, confirmed.id);
        log(`   ✔ sales orders: ${draft.number} (DRAFT) + ${confirmed.number} (CONFIRMED)`);
      }
    }
  }

  // 10h) ضمان بوابة B2B — دائماً (idempotent): الأقفال والخصومات يجب أن تبقى
  //      قابلة للدخول حتى على قواعد مستعادة سبق أن زُرعت قواعد العمولة فيها
  //      (كان زرع الأقفال داخل بوابة ruleCount===0 فيفقد C-00002 الـ PIN)
  {
    const pinByCode: Record<string, string> = { "C-00001": "1122", "C-00002": "2211" };
    const b2bCustomers = await db.customer.findMany({
      where: { companyId: company.id, code: { in: Object.keys(pinByCode) }, deletedAt: null },
      orderBy: { code: "asc" },
    });
    const b2bActor = { userId: adminUser.id, companyId: company.id, warehouseIds: [mainWh.id, repWh.id] };
    let ensured = 0;
    for (const c of b2bCustomers) {
      const pin = pinByCode[c.code];
      if (pin && !c.portalPinHash) {
        await setPortalPin(b2bActor, c.id, pin);
        ensured += 1;
      }
      if (dec(c.discountPct).isZero()) {
        await db.customer.update({ where: { id: c.id }, data: { discountPct: c.code === "C-00001" ? 2 : 3 } });
      }
    }
    if (b2bCustomers.length) {
      log(`   ✔ B2B portal pins ensured (${ensured} set): ${b2bCustomers.map((c) => c.code).join(" · ")}`);
    }
  }


  // v14 — إلغاء نظام نقاط الولاء (طلب المالك): حُذفت زراعة الأرصدة الافتتاحية
  // للولاء — لا تُنشأ حركات نقاط جديدة إطلاقًا، والقديمة تبقى للقراءة فقط.

  log("✅ Seed complete. Login: admin / Admin@123");
}

// ---------------------------------------------------------------------
// ensureSeeded — cheap self-heal guard.
//   · Re-checks at most once per maxAgeSec (in-memory cache).
//   · Concurrent callers share one in-flight promise (no double-seed).
//   · Never throws — a failed probe only delays healing to next call.
// ---------------------------------------------------------------------
let lastOkCheck = 0;
let inFlight: Promise<void> | null = null;

export async function ensureSeeded(opts?: { maxAgeSec?: number; force?: boolean }): Promise<void> {
  const maxAgeMs = (opts?.maxAgeSec ?? 15) * 1000;
  if (!opts?.force && Date.now() - lastOkCheck < maxAgeMs) return;
  if (inFlight) return inFlight;

  inFlight = (async () => {
    try {
      const count = await db.user.count();
      if (count === 0) {
        console.warn("[seed] users table is EMPTY — auto-seeding foundation data…");
        await seedDatabase((m) => console.warn(`[seed] ${m}`));
        console.warn("[seed] auto-seed complete — login credentials restored.");
      }
      lastOkCheck = Date.now();
    } catch (e) {
      console.warn("[seed] ensureSeeded probe skipped:", (e as Error)?.message?.slice(0, 200));
    } finally {
      inFlight = null;
    }
  })();

  return inFlight;
}

/**
 * Catalog-grant sync — self-healing permission refresh for OWNER-level
 * roles, safe to run on EVERY boot (instrumentation.register).
 *
 * Why: seedDatabase only runs when the users table is EMPTY, so catalog
 * additions (e.g. system.company.delete — حذف الشركات) would never reach
 * an existing database. This keeps every OWNER/SUPER_ADMIN role aligned
 * with the full permission catalog idempotently:
 *   1. upsert missing catalog permission rows (global)
 *   2. grant any missing catalog code to OWNER/SUPER_ADMIN roles
 * Custom roles and non-owner grants are never touched.
 */
export async function syncOwnerPermissions(log: (msg: string) => void = () => {}): Promise<void> {
  // 1) Ensure the permission catalog is complete (cheap createMany, dedup).
  const permRows: { code: string; module: string; entity: string; action: string; descriptionAr: string }[] = [];
  for (const p of allPermissions()) permRows.push(p);
  const existingCodes = new Set((await db.permission.findMany({ select: { code: true } })).map((r) => r.code));
  const fresh = permRows.filter((p) => !existingCodes.has(p.code));
  if (fresh.length) await db.permission.createMany({ data: fresh });
  if (fresh.length) log(`   ✔ permissions catalog synced: ${fresh.length} new code(s) — ${fresh.map((f) => f.code).join(", ")}`);

  // 2) Grant every catalog code to platform-owner roles (idempotent).
  const perms = await db.permission.findMany({ select: { id: true, code: true } });
  const ownerRoles = await db.role.findMany({
    where: { code: { in: ["OWNER", "SUPER_ADMIN"] }, deletedAt: null },
    select: { id: true, code: true, companyId: true },
  });
  let granted = 0;
  for (const role of ownerRoles) {
    const have = new Set(
      (await db.rolePermission.findMany({ where: { roleId: role.id }, select: { permissionId: true } })).map((r) => r.permissionId)
    );
    const missing = perms.filter((p) => !have.has(p.id));
    if (missing.length) {
      await db.rolePermission.createMany({
        data: missing.map((p) => ({ companyId: role.companyId, roleId: role.id, permissionId: p.id })),
      });
      granted += missing.length;
    }
  }
  if (granted) log(`   ✔ owner grants synced: +${granted} permission row(s) across ${ownerRoles.length} owner role(s)`);
}

/**
 * v14 — Cash-keeper provisioning — self-healing boot hook (idempotent).
 *
 * يضمن وجود «حساب أمين الصندوق» في كل شركة حية (حتى القواعد القائمة التي
 * لن يُعاد زرعها — seedDatabase يعمل فقط على قاعدة فارغة):
 *   1. دور CASH_KEEPER (أمين الصندوق) لكل شركة نشطة
 *   2. صلاحيات الشاشة الوحيدة: sales.delivery_notes.view + .edit
 *   3. مستخدم cashkeeper (أمين الصندوق / Keeper@123) بدور الدور أعلاه،
 *      بنطاق الفرع الأول + وصول تشغيلي لأول مستودع — إن لم يوجد مسبقًا.
 * لا يمس أي مستخدم أو دور موجود — إنشاء فقط عند الغياب (آمن للتشغيل المتكرر).
 */
export async function ensureCashKeeperAccounts(log: (msg: string) => void = () => {}): Promise<void> {
  // 1) Permission rows needed by the role (global catalog — create if missing)
  const codes = rolePermissionCodes("CASH_KEEPER");
  const permRows = await db.permission.findMany({ where: { code: { in: codes } }, select: { id: true, code: true } });
  const haveCodes = new Set(permRows.map((p) => p.code));
  const missingPerms = codes.filter((c) => !haveCodes.has(c));
  for (const code of missingPerms) {
    const [module, entity, action] = code.split(".");
    permRows.push(
      await db.permission.create({
        data: {
          code, module, entity, action,
          descriptionAr: `${module}.${entity}.${action} (auto — v14 cash-keeper)`,
        },
        select: { id: true, code: true },
      })
    );
  }

  const companies = await db.company.findMany({ where: { deletedAt: null }, select: { id: true, name: true } });
  for (const company of companies) {
    // 2) Role per company
    let role = await db.role.findFirst({ where: { companyId: company.id, code: "CASH_KEEPER", deletedAt: null } });
    if (!role) {
      role = await db.role.create({
        data: {
          companyId: company.id,
          code: "CASH_KEEPER",
          name: "أمين الصندوق",
          description: "حساب خاص بأمين المخزن — إشعارات التسليم فقط، ويُبلَّغ حصراً بحالات النقص",
          isSystem: true,
        },
      });
      log(`   ✔ role CASH_KEEPER created for company ${company.id} (${company.name})`);
    }
    // 3) Refresh the role's permission grants (idempotent — only adds)
    const have = new Set(
      (await db.rolePermission.findMany({ where: { roleId: role.id }, select: { permissionId: true } })).map((r) => r.permissionId)
    );
    const missing = permRows.filter((p) => !have.has(p.id));
    if (missing.length) {
      await db.rolePermission.createMany({
        data: missing.map((p) => ({ companyId: company.id, roleId: role!.id, permissionId: p.id })),
      });
    }

    // 4) The dedicated user account — created once per company
    let user = await db.user.findFirst({ where: { companyId: company.id, username: "cashkeeper", deletedAt: null } });
    if (!user) {
      const firstBranch = await db.branch.findFirst({
        where: { companyId: company.id, deletedAt: null, isActive: true },
        orderBy: { id: "asc" },
        select: { id: true },
      });
      const firstWarehouse = await db.warehouse.findFirst({
        where: { companyId: company.id, deletedAt: null, isActive: true },
        orderBy: { id: "asc" },
        select: { id: true },
      });
      const passwordHash = await hash("Keeper@123");
      user = await db.user.create({
        data: {
          companyId: company.id,
          branchId: firstBranch?.id ?? null,
          username: "cashkeeper",
          email: "cash-keeper@maydan.local",
          fullName: "أمين الصندوق",
          passwordHash,
          scopeType: "BRANCH",
        },
      });
      await db.userRole.create({ data: { companyId: company.id, userId: user.id, roleId: role.id } });
      if (firstBranch) {
        await db.userBranchAccess.create({ data: { companyId: company.id, userId: user.id, branchId: firstBranch.id } });
      }
      if (firstWarehouse) {
        await db.userWarehouseAccess.create({
          data: { companyId: company.id, userId: user.id, warehouseId: firstWarehouse.id, canRead: true, canOperate: true },
        });
      }
      log(`   ✔ user cashkeeper (أمين الصندوق / Keeper@123) created for company ${company.id} (${company.name})`);
    }
  }
}
