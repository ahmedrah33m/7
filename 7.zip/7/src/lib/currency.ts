// =====================================================================
// Phase 2 §6-§7 — وحدة العملة الموحدة (المرحلة 3: مُرقّاة إلى Decimal):
//   · عملات مدعومة: IQD (الأساس) | USD
//   · التحويل: USD→IQD = amount × exchangeRate ، IQD→USD = amount ÷ exchangeRate
//     — كل العمليات عبر decimal.js (R1-R10 في ./decimal.ts)، ممنوع float.
//   · سعر صرف الشركة يُخزَّن في الإعدادات (currency.usd_rate_iqd) — لا
//     يخمّن النظام أي رقم افتراضي (يمنع فئة أخطاء «26/1300 = $0.02»).
//   · الأسعار تُخزَّن بعملتها كما دخلت (26 USD تبقى 26) — التحويل يحدث
//     فقط كإسقاط عرض/ترحيل وكل تحويل يوثَّق بجانب الرقم.
//   · R5: IQD = moneyR(USD × rate) للترحيل؛ USD للعرض = rateDP 6 منازل.
// =====================================================================

import { ApiError } from "./api";
import { db } from "./db";
import { Decimal, dec, moneyR, qtyR, rateR, num } from "./decimal";

export type Currency = "IQD" | "USD";
export const BASE_CURRENCY: Currency = "IQD";
export const SUPPORTED_CURRENCIES: Currency[] = ["IQD", "USD"];

/** مفتاح إعداد سعر صرف الشركة (د.ع لكل $1). */
export const USD_RATE_SETTING_KEY = "currency.usd_rate_iqd";

export function isCurrency(v: unknown): v is Currency {
  return v === "IQD" || v === "USD";
}

export function asCurrency(v: unknown, fallback: Currency = "IQD"): Currency {
  return isCurrency(v) ? v : fallback;
}

/** تحقق من صلاحية سعر الصرف — يجب رقم موجب محدود. يعيده معدّلًا إلى 6dp. */
export function assertExchangeRate(rate: unknown): number {
  const r = dec(rate);
  if (!r.isFinite() || !r.isPositive() || r.isZero()) {
    throw new ApiError("PRD_006", "سعر الصرف مطلوب ويجب أن يكون رقمًا موجبًا (د.ع لكل $1)");
  }
  return rateR(r).toNumber();
}

/** سعر صرف معدّل (Decimal 6dp) — مدخل الحسابات دائمًا. */
export function rateOf(rate: unknown): Decimal {
  const r = dec(rate);
  if (!r.isFinite() || !r.isPositive() || r.isZero()) {
    throw new ApiError("PRD_006", "سعر الصرف مطلوب ويجب أن يكون رقمًا موجبًا (د.ع لكل $1)");
  }
  return rateR(r);
}

/**
 * USD → IQD (أو تمرير مباشر للدينار) — القاعدة §7 + R5:
 * amount × exchangeRate بتقريب المال 4dp عند الترحيل للتخزين.
 */
export function toIqd(amount: unknown, currency: Currency, exchangeRate: unknown): Decimal {
  const a = dec(amount);
  if (currency === "IQD") return moneyR(a);
  return moneyR(a.mul(rateOf(exchangeRate)));
}

/**
 * IQD → USD (أو تمرير مباشر) — القاعدة §7: amount ÷ exchangeRate —
 * نتيجة عرض بحساب Decimal (بلا أثر float) بدقة 12 منزلة قبل أي تقريب لاحق.
 */
export function fromIqd(amountIqd: unknown, currency: Currency, exchangeRate: unknown): Decimal {
  const a = dec(amountIqd);
  if (currency === "IQD") return a;
  return a.div(rateOf(exchangeRate));
}

/** تقريب الكمية/المعدل إلى 6 منازل — توافق قديم مع وحدات التعبئة (R2). */
export function round6(v: unknown): number {
  return num(qtyR(v));
}

/** تقريب المال إلى منزلتين — العرض النهائي فقط (التخزين 4dp). */
export function roundMoney(v: unknown): number {
  return num(moneyR(v));
}

/** تقريب المال إلى 4dp كـ Decimal — مدخل التخزين القياسي. */
export function moneyOf(v: unknown): Decimal {
  return moneyR(v);
}

/** تحويل عرَض USD من دينار — بلا تخمين: يتطلب سعرًا صالحًا. */
export function displayUsd(amountIqd: unknown, exchangeRate: unknown): Decimal {
  return rateR(dec(amountIqd).div(rateOf(exchangeRate)));
}

/**
 * سعر صرف الشركة المحفوظ (د.ع/$1) — من الإعدادات فقط.
 * يعيد null حين لا يوجد إعداد: المتصل يطلب من المستخدم تحديده صراحةً
 * بدل تخمين رقم قديم (كان 1300 افتراضيًا — مصدر عرض $0.02 الخاطئ).
 * القيمة تُقرأ من نص الإعداد مباشرة (بلا مسار float).
 */
export async function getCompanyUsdRate(companyId: number): Promise<number | null> {
  const row = await db.setting.findFirst({
    where: { companyId, key: USD_RATE_SETTING_KEY },
  });
  if (!row) return null;
  let raw: unknown;
  try {
    raw = JSON.parse(row.value);
  } catch {
    return null;
  }
  const r = dec(raw);
  if (!r.isFinite() || !r.isPositive() || r.isZero()) return null;
  return r.toNumber();
}

/** حفظ/تحديث سعر صرف الشركة (د.ع لكل $1) — يُخزَّن بنص 6dp الرصين. */
export async function setCompanyUsdRate(companyId: number, rate: number, userId?: number | null): Promise<number> {
  assertExchangeRate(rate);
  const value = JSON.stringify(rateR(rate).toNumber());
  const existing = await db.setting.findFirst({
    where: { companyId, key: USD_RATE_SETTING_KEY },
    select: { id: true },
  });
  if (existing) {
    await db.setting.update({ where: { id: existing.id }, data: { value, updatedBy: userId ?? null } });
  } else {
    await db.setting.create({
      data: {
        companyId, key: USD_RATE_SETTING_KEY, value,
        groupName: "currency",
        description: "سعر صرف الدولار المعتمد للشركة — د.ع لكل $1",
        updatedBy: userId ?? null,
      },
    });
  }
  return rateR(rate).toNumber();
}
