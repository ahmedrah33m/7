"use client";

// =====================================================================
// Client API helper — Bearer token management + single-flight refresh.
// Access token lives in memory; refresh token in sessionStorage
// (demo-appropriate; production mobile app uses secure storage).
// =====================================================================

export interface ScopeBranch { id: number; code: string; name: string; company_id: number }

// حالة اشتراك الشركة — تظهر كمّلحظة حالة في مبدّل الشركات (نشطة/منتهية/معلّقة...)
export interface ScopeCompanySubscription {
  status: "OPEN" | "ACTIVE" | "EXPIRING_SOON" | "EXPIRED" | "SUSPENDED";
  days_left: number | null;
  is_suspended: boolean;
  ends_at: string | null;
}
export interface ScopeCompany {
  id: number;
  code: string | null;
  name: string;
  logo_url?: string | null; // شعار الشركة (الهيدر/القائمة الجانبية)
  subscription?: ScopeCompanySubscription;
}

export interface SessionScope {
  scope_type: string;
  // المستوى الإداري (تسلسل هرمي): PLATFORM_OWNER | COMPANY_MANAGER | BRANCH_MANAGER | EMPLOYEE
  admin_level?: "PLATFORM_OWNER" | "COMPANY_MANAGER" | "BRANCH_MANAGER" | "EMPLOYEE";
  active_branch_id: number | null;
  active_company_id: number;
  companies: ScopeCompany[];
  branches: ScopeBranch[];
  warehouses: { id: number; code: string; name: string; type: string }[];
  customer_type_labels: Record<string, string>;
  // حالة اشتراك الشركة النشطة (لوحة المالك — مدة كل شركة)
  subscription?: {
    ends_at: string | null;
    days_left: number | null;
    is_suspended: boolean;
    status: "OPEN" | "ACTIVE" | "EXPIRING_SOON" | "EXPIRED" | "SUSPENDED";
    note: string | null;
  };
}

export interface LoginPayload {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  user: {
    id: number;
    uuid: string;
    username: string;
    full_name: string;
    company_id: number;
    branch_id: number | null;
    scope_type?: string;
    admin_level?: string;
    language: string;
    theme: string;
  };
  permissions: string[];
  roles: { id: number; code: string; name: string }[];
  scope?: SessionScope;
}

export interface ApiEnvelope<T = unknown> {
  success: boolean;
  code?: string;
  message?: string;
  errors?: { field: string; message: string }[];
  data?: T;
  meta?: Record<string, unknown>;
}

let accessToken: string | null = null;
let refreshToken: string | null = null;
let refreshPromise: Promise<boolean> | null = null;

const REFRESH_KEY = "sds_refresh_token";

export function setTokens(access: string, refresh: string) {
  accessToken = access;
  refreshToken = refresh;
  try {
    sessionStorage.setItem(REFRESH_KEY, refresh);
  } catch {}
}

export function getAccessToken() {
  return accessToken;
}

/** Apply a switch-branch / switch-company response (new access token + scope). */
export function applyScopeSwitch(data: { access_token: string; scope?: SessionScope; active_branch_id?: number | null; active_company_id?: number }, current: LoginPayload): LoginPayload {
  accessToken = data.access_token;
  return {
    ...current,
    access_token: data.access_token,
    user: {
      ...current.user,
      branch_id: data.active_branch_id ?? current.user.branch_id,
      company_id: data.active_company_id ?? current.user.company_id,
    },
    scope: data.scope ?? current.scope,
  };
}

export function clearTokens() {
  accessToken = null;
  refreshToken = null;
  try {
    sessionStorage.removeItem(REFRESH_KEY);
  } catch {}
}

/** Restore refresh token from sessionStorage after a page reload. */
export function loadStoredRefresh(): string | null {
  if (refreshToken) return refreshToken;
  try {
    refreshToken = sessionStorage.getItem(REFRESH_KEY);
  } catch {}
  return refreshToken;
}

async function tryRefresh(): Promise<boolean> {
  const token = refreshToken ?? loadStoredRefresh();
  if (!token) return false;
  const res = await fetch("/api/v1/auth/refresh", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: token }),
  });
  const body = (await res.json()) as ApiEnvelope<{
    access_token: string;
    refresh_token: string;
  }>;
  if (!res.ok || !body.success || !body.data) {
    clearTokens();
    return false;
  }
  setTokens(body.data.access_token, body.data.refresh_token);
  return true;
}

/** Authenticated fetch with one automatic refresh attempt on 401. */
export async function api<T = unknown>(
  path: string,
  init: RequestInit = {},
  { skipAuth = false }: { skipAuth?: boolean } = {}
): Promise<{ res: Response; body: ApiEnvelope<T> }> {
  const headers = new Headers(init.headers);
  if (!headers.has("Content-Type") && init.body) headers.set("Content-Type", "application/json");
  if (!skipAuth && accessToken) headers.set("Authorization", `Bearer ${accessToken}`);

  let res = await fetch(path, { ...init, headers });
  let body = (await res.json().catch(() => ({ success: false, message: "رد غير صالح" }))) as ApiEnvelope<T>;

  if (res.status === 401 && !skipAuth && accessToken) {
    if (!refreshPromise) {
      refreshPromise = tryRefresh().finally(() => (refreshPromise = null));
    }
    const refreshed = await refreshPromise;
    if (refreshed) {
      headers.set("Authorization", `Bearer ${accessToken}`);
      res = await fetch(path, { ...init, headers });
      body = (await res.json().catch(() => ({ success: false }))) as ApiEnvelope<T>;
    }
  }
  return { res, body };
}

/** Loosely-typed API body for the security test panel (reads code/message). */
export interface RawApiBody {
  code?: string;
  message?: string;
  success?: boolean;
  data?: unknown;
  errors?: { field: string; message: string }[];
  [k: string]: unknown;
}

/** Raw fetch without auth helpers — used by the security test panel. */
export async function rawFetch(path: string, init: RequestInit = {}): Promise<{ status: number; body: RawApiBody }> {
  const res = await fetch(path, init);
  const body = (await res.json().catch(() => ({}))) as RawApiBody;
  return { status: res.status, body };
}
