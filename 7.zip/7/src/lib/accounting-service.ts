// =====================================================================
// Accounting service — double-entry bookkeeping on top of the cashbox
// ledger. Auto journal entries from Receipt/Payment Voucher/Cash Sale
// keep the accounting books in lockstep with the cash ledger; manual
// balanced entries are supported via postJournalEntry. Reports: trial
// balance, balance sheet, income statement, budget vs actual.
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { nextDocumentNumber } from "./document-number";
import { writeAudit, auditData } from "./audit";
import { Decimal, dec, moneyR, num, sumOf } from "./decimal";
import type { Prisma } from "@prisma/client";

// ---------------------------------------------------------------------
// Standard chart of accounts (28 accounts). Codes are 4-digit to keep
// sorting stable across siblings (1010, 1020, ..., 5990).
// ---------------------------------------------------------------------
export const STD_ACCOUNTS = [
  // ASSETS (1000s)
  { code: "1010", name: "النقدية والصناديق", nameEn: "Cash & Cash Equivalents", type: "ASSET", subtype: "CURRENT_ASSET", isCashAccount: true },
  { code: "1020", name: "البنوك", nameEn: "Bank Accounts", type: "ASSET", subtype: "CURRENT_ASSET", isCashAccount: true },
  { code: "1100", name: "ذمم العملاء", nameEn: "Accounts Receivable", type: "ASSET", subtype: "CURRENT_ASSET", isReceivable: true },
  { code: "1200", name: "المخزون", nameEn: "Inventory", type: "ASSET", subtype: "CURRENT_ASSET" },
  { code: "1300", name: "ضريبة القيمة المضافة (مدين)", nameEn: "VAT Receivable", type: "ASSET", subtype: "CURRENT_ASSET" },
  { code: "1410", name: "الأصول الثابتة", nameEn: "Fixed Assets", type: "ASSET", subtype: "FIXED_ASSET" },
  { code: "1420", name: "الإهلاك التراكمي", nameEn: "Accumulated Depreciation", type: "ASSET", subtype: "CONTRA_ASSET" },
  { code: "1500", name: "مصروفات مدفوعة مسبقًا", nameEn: "Prepaid Expenses", type: "ASSET", subtype: "CURRENT_ASSET" },
  // LIABILITIES (2000s)
  { code: "2100", name: "ذمم الموردين", nameEn: "Accounts Payable", type: "LIABILITY", subtype: "CURRENT_LIABILITY", isPayable: true },
  { code: "2200", name: "ضريبة القيمة المضافة (دائن)", nameEn: "VAT Payable", type: "LIABILITY", subtype: "CURRENT_LIABILITY" },
  { code: "2300", name: "رواتب مستحقة", nameEn: "Accrued Salaries", type: "LIABILITY", subtype: "CURRENT_LIABILITY" },
  { code: "2400", name: "مصروفات مستحقة", nameEn: "Accrued Expenses", type: "LIABILITY", subtype: "CURRENT_LIABILITY" },
  { code: "2500", name: "قروض قصيرة الأجل", nameEn: "Short-Term Loans", type: "LIABILITY", subtype: "CURRENT_LIABILITY" },
  { code: "2600", name: "قروض طويلة الأجل", nameEn: "Long-Term Loans", type: "LIABILITY", subtype: "LONG_TERM_LIABILITY" },
  // EQUITY (3000s)
  { code: "3100", name: "رأس المال", nameEn: "Owner's Equity", type: "EQUITY" },
  { code: "3200", name: "الأرباح المحتجزة", nameEn: "Retained Earnings", type: "EQUITY" },
  { code: "3300", name: "صافي ربح الفترة", nameEn: "Current Period Net Income", type: "EQUITY" },
  // REVENUE (4000s)
  { code: "4000", name: "إيرادات المبيعات", nameEn: "Sales Revenue", type: "REVENUE" },
  { code: "4100", name: "إيرادات مبيعات نقدية", nameEn: "Cash Sales Revenue", type: "REVENUE" },
  { code: "4200", name: "إيرادات مبيعات آجلة", nameEn: "Credit Sales Revenue", type: "REVENUE" },
  { code: "4300", name: "إيرادات الخصم المكتسب", nameEn: "Sales Discounts Earned", type: "REVENUE" },
  { code: "4900", name: "إيرادات أخرى", nameEn: "Other Income", type: "REVENUE" },
  // EXPENSES (5000s) — COGS + operating
  { code: "5000", name: "تكلفة البضاعة المباعة", nameEn: "Cost of Goods Sold", type: "EXPENSE" },
  { code: "5100", name: "مصاريف شراء", nameEn: "Purchasing Expenses", type: "EXPENSE" },
  { code: "5200", name: "رواتب وأجور", nameEn: "Salaries & Wages", type: "EXPENSE" },
  { code: "5300", name: "إيجار", nameEn: "Rent Expense", type: "EXPENSE" },
  { code: "5400", name: "مياه وكهرباء", nameEn: "Utilities", type: "EXPENSE" },
  { code: "5500", name: "مصاريف نقل وتوزيع", nameEn: "Transport & Delivery", type: "EXPENSE" },
  { code: "5900", name: "مصاريف عمومية وإدارية", nameEn: "General & Administrative", type: "EXPENSE" },
] as const;

// Common shortcuts
export const STD_ACCOUNT_CODES = {
  CASH: "1010",
  BANK: "1020",
  ACCOUNTS_RECEIVABLE: "1100",
  INVENTORY: "1200",
  ACCOUNTS_PAYABLE: "2100",
  VAT_PAYABLE: "2200",
  OWNER_EQUITY: "3100",
  RETAINED_EARNINGS: "3200",
  CURRENT_NET_INCOME: "3300",
  SALES_REVENUE: "4000",
  CASH_SALES: "4100",
  CREDIT_SALES: "4200",
  OTHER_INCOME: "4900",
  COGS: "5000",
  PURCHASING_EXPENSE: "5100",
  SALARIES: "5200",
  RENT: "5300",
  UTILITIES: "5400",
  TRANSPORT: "5500",
  G_AND_A: "5900",
} as const;

// ---------------------------------------------------------------------
// getOrCreateStandardAccounts — idempotent: ensures the 28 std accounts
// exist for a company. Returns the full list (existing + created).
// ---------------------------------------------------------------------
export async function getOrCreateStandardAccounts(companyId: number) {
  const existing = await db.account.findMany({
    where: { companyId, deletedAt: null },
    select: { id: true, code: true, name: true, type: true },
  });
  const byCode = new Map(existing.map((a) => [a.code, a]));
  const created: { id: number; code: string; name: string }[] = [];
  for (const def of STD_ACCOUNTS) {
    if (byCode.has(def.code)) continue;
    const acc = await db.account.create({
      data: {
        companyId,
        code: def.code,
        name: def.name,
        nameEn: def.nameEn,
        type: def.type,
        subtype: "subtype" in def ? def.subtype : null,
        isCashAccount: "isCashAccount" in def ? def.isCashAccount : false,
        isReceivable: "isReceivable" in def ? def.isReceivable : false,
        isPayable: "isPayable" in def ? def.isPayable : false,
        isOpen: true,
        openingBalance: 0,
        currentBalance: 0,
      },
    });
    byCode.set(def.code, { id: acc.id, code: acc.code, name: acc.name, type: acc.type });
    created.push({ id: acc.id, code: acc.code, name: acc.name });
  }
  return [...byCode.values()].map((a) => ({ id: a.id, code: a.code, name: a.name, type: a.type }));
}

// ---------------------------------------------------------------------
// Internal: account lookup helper (cached on demand).
// ---------------------------------------------------------------------
async function accountByCode(companyId: number, code: string) {
  const acc = await db.account.findFirst({ where: { companyId, code, deletedAt: null } });
  if (!acc) throw new ApiError("VAL_003", `الحساب ${code} غير معرَّف — شغّل تهيئة دليل الحسابات`);
  return acc;
}

// ---------------------------------------------------------------------
// postJournalEntry — manual balanced double-entry (Σ debit = Σ credit).
// ---------------------------------------------------------------------
export interface JournalLineInput {
  accountCode: string;
  debit?: number | null;
  credit?: number | null;
  customerId?: number | null;
  supplierId?: number | null;
  cashboxId?: number | null;
  costCenterId?: number | null;
  description?: string | null;
}

export interface PostJournalEntryInput {
  entryDate?: Date | null;
  description?: string | null;
  source?: string;
  sourceType?: string | null;
  sourceId?: number | null;
  costCenterId?: number | null;
  periodId?: number | null;
  notes?: string | null;
  lines: JournalLineInput[];
}

export async function postJournalEntry(actor: { userId: number; companyId: number; ip?: string; userAgent?: string }, input: PostJournalEntryInput) {
  const companyId = actor.companyId;
  if (!input.lines.length) throw new ApiError("VAL_001", "القيد بلا بنود");
  // Ensure all referenced accounts exist
  const accountCodes = [...new Set(input.lines.map((l) => l.accountCode))];
  const accounts = await db.account.findMany({
    where: { companyId, code: { in: accountCodes }, deletedAt: null },
    select: { id: true, code: true, name: true, type: true, currentBalance: true },
  });
  const accountMap = new Map(accounts.map((a) => [a.code, a]));
  for (const code of accountCodes) {
    if (!accountMap.has(code)) throw new ApiError("VAL_003", `الحساب ${code} غير معرَّف`);
  }

  let totalDebit = new Decimal(0);
  let totalCredit = new Decimal(0);
  for (const l of input.lines) {
    totalDebit = totalDebit.plus(dec(l.debit ?? 0));
    totalCredit = totalCredit.plus(dec(l.credit ?? 0));
  }
  if (!totalDebit.eq(totalCredit)) {
    throw new ApiError("FINANCE_001", `القيد غير متوازن — مدين: ${num(totalDebit)}، دائن: ${num(totalCredit)}`);
  }
  if (totalDebit.isZero()) throw new ApiError("VAL_001", "القيد صفري");

  const result = await db.$transaction(async (tx) => {
    const number = await nextDocumentNumber(tx, companyId, "JOURNAL_ENTRY");
    const entry = await tx.journalEntry.create({
      data: {
        companyId,
        number,
        entryDate: input.entryDate ?? new Date(),
        description: input.description,
        source: input.source ?? "MANUAL",
        sourceType: input.sourceType ?? null,
        sourceId: input.sourceId ?? null,
        status: "POSTED",
        isReversed: false,
        periodId: input.periodId ?? null,
        totalDebit: moneyR(totalDebit),
        totalCredit: moneyR(totalCredit),
        costCenterId: input.costCenterId ?? null,
        notes: input.notes,
        createdById: actor.userId,
      },
    });

    for (const l of input.lines) {
      const acc = accountMap.get(l.accountCode)!;
      const debit = moneyR(dec(l.debit ?? 0));
      const credit = moneyR(dec(l.credit ?? 0));
      await tx.journalLine.create({
        data: {
          companyId,
          entryId: entry.id,
          accountId: acc.id,
          debit,
          credit,
          accountCode: acc.code,
          accountName: acc.name,
          customerId: l.customerId ?? null,
          supplierId: l.supplierId ?? null,
          cashboxId: l.cashboxId ?? null,
          costCenterId: l.costCenterId ?? null,
          description: l.description,
        },
      });
      // Update account current balance (Debit increases ASSET/EXPENSE, Credit increases LIABILITY/EQUITY/REVENUE)
      const isDebitSide = acc.type === "ASSET" || acc.type === "EXPENSE";
      const delta = isDebitSide ? debit.minus(credit) : credit.minus(debit);
      await tx.account.update({
        where: { id: acc.id },
        data: { currentBalance: moneyR(dec(acc.currentBalance).plus(delta)) },
      });
    }

    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "POST",
          module: "accounting",
          entityType: "journal_entry",
          entityId: entry.id,
          newValues: { number, total: num(moneyR(totalDebit)) },
        }
      ),
    });

    return entry;
  });

  return { id: result.id, number: result.number, total_debit: num(moneyR(totalDebit)), total_credit: num(moneyR(totalCredit)) };
}

// ---------------------------------------------------------------------
// Auto entries from existing cashbox operations. Called inside the
// same transaction as the originating operation.
// ---------------------------------------------------------------------
export async function autoEntryFromReceipt(
  tx: Prisma.TransactionClient,
  actor: { userId: number; companyId: number },
  receipt: { id: number; number: string; amount: Decimal | number; currency?: string | null; customerId?: number | null; cashboxId?: number | null }
) {
  const companyId = actor.companyId;
  const cashAcc = await tx.account.findFirst({ where: { companyId, code: STD_ACCOUNT_CODES.CASH, deletedAt: null } });
  const arAcc = await tx.account.findFirst({ where: { companyId, code: STD_ACCOUNT_CODES.ACCOUNTS_RECEIVABLE, deletedAt: null } });
  if (!cashAcc || !arAcc) return null; // accounts not initialized

  const amount = moneyR(dec(receipt.amount));
  const number = await nextDocumentNumber(tx, companyId, "JOURNAL_ENTRY");
  const entry = await tx.journalEntry.create({
    data: {
      companyId,
      number,
      entryDate: new Date(),
      description: `قبض ${receipt.number}`,
      source: "AUTO_RECEIPT",
      sourceType: "ReceiptVoucher",
      sourceId: receipt.id,
      status: "POSTED",
      totalDebit: amount, totalCredit: amount,
      createdById: actor.userId,
    },
  });
  await tx.journalLine.create({
    data: {
      companyId, entryId: entry.id, accountId: cashAcc.id,
      debit: amount, credit: 0, accountCode: cashAcc.code, accountName: cashAcc.name,
      customerId: receipt.customerId ?? null,
      cashboxId: receipt.cashboxId ?? null,
    },
  });
  await tx.journalLine.create({
    data: {
      companyId, entryId: entry.id, accountId: arAcc.id,
      debit: 0, credit: amount, accountCode: arAcc.code, accountName: arAcc.name,
      customerId: receipt.customerId ?? null,
    },
  });
  await tx.account.update({ where: { id: cashAcc.id }, data: { currentBalance: moneyR(dec(cashAcc.currentBalance).plus(amount)) } });
  await tx.account.update({ where: { id: arAcc.id }, data: { currentBalance: moneyR(dec(arAcc.currentBalance).minus(amount)) } });
  return { entry_id: entry.id, entry_number: number };
}

export async function autoEntryFromPaymentVoucher(
  tx: Prisma.TransactionClient,
  actor: { userId: number; companyId: number },
  voucher: { id: number; number: string; amount: Decimal | number; supplierId?: number | null; customerId?: number | null; chargeToCustomerId?: number | null; cashboxId?: number | null; isCharged?: boolean }
) {
  const companyId = actor.companyId;
  const cashAcc = await tx.account.findFirst({ where: { companyId, code: STD_ACCOUNT_CODES.CASH, deletedAt: null } });
  const apAcc = await tx.account.findFirst({ where: { companyId, code: STD_ACCOUNT_CODES.ACCOUNTS_PAYABLE, deletedAt: null } });
  const arAcc = await tx.account.findFirst({ where: { companyId, code: STD_ACCOUNT_CODES.ACCOUNTS_RECEIVABLE, deletedAt: null } });
  const salesAcc = await tx.account.findFirst({ where: { companyId, code: STD_ACCOUNT_CODES.CASH_SALES, deletedAt: null } });
  if (!cashAcc) return null;

  const amount = moneyR(dec(voucher.amount));
  const isCharged = !!voucher.isCharged || !!voucher.chargeToCustomerId;

  const number = await nextDocumentNumber(tx, companyId, "JOURNAL_ENTRY");
  // Charged expense: Dr AR, Cr Sales Revenue (no cash moves).
  // Standard supplier payment: Dr AP, Cr Cash.
  if (isCharged) {
    if (!arAcc || !salesAcc) return null;
    const entry = await tx.journalEntry.create({
      data: {
        companyId, number, entryDate: new Date(),
        description: `صرف محمَّل ${voucher.number}`,
        source: "AUTO_PAYMENT_VOUCHER", sourceType: "PaymentVoucher", sourceId: voucher.id,
        status: "POSTED", totalDebit: amount, totalCredit: amount,
        createdById: actor.userId,
      },
    });
    await tx.journalLine.create({
      data: {
        companyId, entryId: entry.id, accountId: arAcc.id,
        debit: amount, credit: 0, accountCode: arAcc.code, accountName: arAcc.name,
        customerId: voucher.chargeToCustomerId ?? voucher.customerId ?? null,
      },
    });
    await tx.journalLine.create({
      data: {
        companyId, entryId: entry.id, accountId: salesAcc.id,
        debit: 0, credit: amount, accountCode: salesAcc.code, accountName: salesAcc.name,
      },
    });
    await tx.account.update({ where: { id: arAcc.id }, data: { currentBalance: moneyR(dec(arAcc.currentBalance).plus(amount)) } });
    await tx.account.update({ where: { id: salesAcc.id }, data: { currentBalance: moneyR(dec(salesAcc.currentBalance).plus(amount)) } });
    return { entry_id: entry.id, entry_number: number };
  }

  if (!apAcc) return null;
  const entry = await tx.journalEntry.create({
    data: {
      companyId, number, entryDate: new Date(),
      description: `سداد ${voucher.number}`,
      source: "AUTO_PAYMENT_VOUCHER", sourceType: "PaymentVoucher", sourceId: voucher.id,
      status: "POSTED", totalDebit: amount, totalCredit: amount,
      createdById: actor.userId,
    },
  });
  await tx.journalLine.create({
    data: {
      companyId, entryId: entry.id, accountId: apAcc.id,
      debit: amount, credit: 0, accountCode: apAcc.code, accountName: apAcc.name,
      supplierId: voucher.supplierId ?? null,
    },
  });
  await tx.journalLine.create({
    data: {
      companyId, entryId: entry.id, accountId: cashAcc.id,
      debit: 0, credit: amount, accountCode: cashAcc.code, accountName: cashAcc.name,
      cashboxId: voucher.cashboxId ?? null,
    },
  });
  await tx.account.update({ where: { id: apAcc.id }, data: { currentBalance: moneyR(dec(apAcc.currentBalance).minus(amount)) } });
  await tx.account.update({ where: { id: cashAcc.id }, data: { currentBalance: moneyR(dec(cashAcc.currentBalance).minus(amount)) } });
  return { entry_id: entry.id, entry_number: number };
}

export async function autoEntryFromCashSale(
  tx: Prisma.TransactionClient,
  actor: { userId: number; companyId: number },
  invoice: { id: number; number: string; grandTotal: Decimal | number; customerId?: number | null; cashboxId?: number | null }
) {
  const companyId = actor.companyId;
  const cashAcc = await tx.account.findFirst({ where: { companyId, code: STD_ACCOUNT_CODES.CASH, deletedAt: null } });
  const salesAcc = await tx.account.findFirst({ where: { companyId, code: STD_ACCOUNT_CODES.SALES_REVENUE, deletedAt: null } });
  if (!cashAcc || !salesAcc) return null;

  const amount = moneyR(dec(invoice.grandTotal));
  const number = await nextDocumentNumber(tx, companyId, "JOURNAL_ENTRY");
  const entry = await tx.journalEntry.create({
    data: {
      companyId, number, entryDate: new Date(),
      description: `بيع نقدي ${invoice.number}`,
      source: "AUTO_CASH_SALE", sourceType: "SalesInvoice", sourceId: invoice.id,
      status: "POSTED", totalDebit: amount, totalCredit: amount,
      createdById: actor.userId,
    },
  });
  await tx.journalLine.create({
    data: {
      companyId, entryId: entry.id, accountId: cashAcc.id,
      debit: amount, credit: 0, accountCode: cashAcc.code, accountName: cashAcc.name,
      customerId: invoice.customerId ?? null,
      cashboxId: invoice.cashboxId ?? null,
    },
  });
  await tx.journalLine.create({
    data: {
      companyId, entryId: entry.id, accountId: salesAcc.id,
      debit: 0, credit: amount, accountCode: salesAcc.code, accountName: salesAcc.name,
    },
  });
  await tx.account.update({ where: { id: cashAcc.id }, data: { currentBalance: moneyR(dec(cashAcc.currentBalance).plus(amount)) } });
  await tx.account.update({ where: { id: salesAcc.id }, data: { currentBalance: moneyR(dec(salesAcc.currentBalance).plus(amount)) } });
  return { entry_id: entry.id, entry_number: number };
}

// ---------------------------------------------------------------------
// Reports — trial balance, balance sheet, income statement.
// ---------------------------------------------------------------------
export async function getTrialBalance(companyId: number) {
  const accounts = await db.account.findMany({
    where: { companyId, deletedAt: null, isOpen: true },
    select: { id: true, code: true, name: true, type: true, currentBalance: true, openingBalance: true },
    orderBy: { code: "asc" },
  });
  let totalDebit = new Decimal(0);
  let totalCredit = new Decimal(0);
  const rows = accounts.map((a) => {
    const bal = dec(a.currentBalance).plus(dec(a.openingBalance));
    const isDebit = a.type === "ASSET" || a.type === "EXPENSE";
    const debit = isDebit ? (bal.isPositive() ? bal : new Decimal(0)) : (bal.isNegative() ? bal.abs() : new Decimal(0));
    const credit = isDebit ? (bal.isNegative() ? bal.abs() : new Decimal(0)) : (bal.isPositive() ? bal : new Decimal(0));
    totalDebit = totalDebit.plus(debit);
    totalCredit = totalCredit.plus(credit);
    return {
      account_id: a.id, code: a.code, name: a.name, type: a.type,
      debit: num(moneyR(debit)), credit: num(moneyR(credit)),
    };
  });
  return {
    rows,
    totals: { debit: num(moneyR(totalDebit)), credit: num(moneyR(totalCredit)) },
    is_balanced: totalDebit.eq(totalCredit),
  };
}

export async function getBalanceSheet(companyId: number) {
  const accounts = await db.account.findMany({
    where: { companyId, deletedAt: null, isOpen: true },
    select: { code: true, name: true, type: true, currentBalance: true, openingBalance: true },
  });
  let assets = new Decimal(0);
  let liabilities = new Decimal(0);
  let equity = new Decimal(0);
  const rows = accounts.map((a) => {
    const bal = dec(a.currentBalance).plus(dec(a.openingBalance));
    if (a.type === "ASSET") assets = assets.plus(bal);
    else if (a.type === "LIABILITY") liabilities = liabilities.plus(bal);
    else if (a.type === "EQUITY") equity = equity.plus(bal);
    return { code: a.code, name: a.name, type: a.type, balance: num(moneyR(bal)) };
  });
  return {
    rows,
    summary: {
      assets: num(moneyR(assets)),
      liabilities: num(moneyR(liabilities)),
      equity: num(moneyR(equity)),
      total_liabilities_equity: num(moneyR(liabilities.plus(equity))),
      is_balanced: assets.eq(liabilities.plus(equity)),
    },
  };
}

export async function getIncomeStatement(companyId: number, opts: { fromDate?: Date | null; toDate?: Date | null } = {}) {
  const from = opts.fromDate ?? new Date(new Date().getFullYear(), 0, 1);
  const to = opts.toDate ?? new Date();

  const entries = await db.journalEntry.findMany({
    where: { companyId, deletedAt: null, entryDate: { gte: from, lte: to }, status: "POSTED", isReversed: false },
    include: { lines: { include: { account: { select: { type: true, code: true, name: true } } } } },
  });
  const revenueMap = new Map<string, Decimal>();
  const expenseMap = new Map<string, Decimal>();
  let totalRevenue = new Decimal(0);
  let totalExpense = new Decimal(0);
  for (const e of entries) {
    for (const l of e.lines) {
      if (!l.account) continue;
      if (l.account.type === "REVENUE") {
        const amt = dec(l.credit).minus(dec(l.debit));
        revenueMap.set(l.account.code, dec(revenueMap.get(l.account.code) ?? 0).plus(amt));
        totalRevenue = totalRevenue.plus(amt);
      } else if (l.account.type === "EXPENSE") {
        const amt = dec(l.debit).minus(dec(l.credit));
        expenseMap.set(l.account.code, dec(expenseMap.get(l.account.code) ?? 0).plus(amt));
        totalExpense = totalExpense.plus(amt);
      }
    }
  }
  const rows = [
    ...[...revenueMap.entries()].map(([code, amt]) => ({ code, name: code, type: "REVENUE", amount: num(moneyR(amt)) })),
    ...[...expenseMap.entries()].map(([code, amt]) => ({ code, name: code, type: "EXPENSE", amount: num(moneyR(amt)) })),
  ];
  return {
    rows,
    summary: {
      total_revenue: num(moneyR(totalRevenue)),
      total_expense: num(moneyR(totalExpense)),
      net_income: num(moneyR(totalRevenue.minus(totalExpense))),
    },
  };
}

export async function getBudgetVsActual(companyId: number, period: string) {
  const budgets = await db.budget.findMany({
    where: { companyId, period },
    include: { account: { select: { code: true, name: true, type: true } } },
  });
  const rows = budgets.map((b) => {
    const variance = dec(b.actualAmount).minus(dec(b.budgetedAmount));
    return {
      account_code: b.account.code,
      account_name: b.account.name,
      account_type: b.account.type,
      budgeted: num(moneyR(b.budgetedAmount)),
      actual: num(moneyR(b.actualAmount)),
      variance: num(moneyR(variance)),
    };
  });
  return { period, rows };
}

// ---------------------------------------------------------------------
// Financial periods — open/close/reopen + auto-create current month.
// ---------------------------------------------------------------------
export async function ensureCurrentMonthPeriod(companyId: number) {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const name = `${year}-${String(month).padStart(2, "0")}`;
  const existing = await db.financialPeriod.findFirst({ where: { companyId, name } });
  if (existing) return existing;
  return db.financialPeriod.create({
    data: {
      companyId,
      name,
      periodType: "MONTH",
      startDate: new Date(year, now.getMonth(), 1),
      endDate: new Date(year, now.getMonth() + 1, 0, 23, 59, 59),
      status: "OPEN",
    },
  });
}

export async function closeFinancialPeriod(actor: { userId: number; companyId: number; ip?: string; userAgent?: string }, periodId: number, note?: string) {
  const period = await db.financialPeriod.findFirst({ where: { id: periodId, companyId: actor.companyId } });
  if (!period) throw new ApiError("VAL_003", "الفترة المالية غير موجودة");
  if (period.status === "CLOSED" || period.status === "LOCKED") throw new ApiError("VAL_004", "الفترة مغلقة مسبقًا");

  await db.$transaction(async (tx) => {
    await tx.financialPeriod.update({
      where: { id: period.id },
      data: {
        status: "CLOSED",
        closedById: actor.userId,
        closedAt: new Date(),
        closeNote: note ?? null,
      },
    });
    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "POST",
          module: "accounting",
          entityType: "financial_period_close",
          entityId: period.id,
          newValues: { note: note ?? "" },
        }
      ),
    });
  });
  return { id: period.id, status: "CLOSED" };
}

export async function reopenFinancialPeriod(actor: { userId: number; companyId: number; ip?: string; userAgent?: string }, periodId: number, reason: string) {
  const period = await db.financialPeriod.findFirst({ where: { id: periodId, companyId: actor.companyId } });
  if (!period) throw new ApiError("VAL_003", "الفترة المالية غير موجودة");
  if (period.status === "OPEN") throw new ApiError("VAL_004", "الفترة مفتوحة أصلًا");
  if (period.status === "LOCKED") throw new ApiError("PERM_001", "الفترة مقفلة — لا يمكن إعادة فتحها");

  await db.$transaction(async (tx) => {
    await tx.financialPeriod.update({
      where: { id: period.id },
      data: { status: "OPEN", closedAt: null, closedById: null, closeNote: reason },
    });
    await tx.auditLog.create({
      data: auditData(
        { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        {
          action: "POST",
          module: "accounting",
          entityType: "financial_period_reopen",
          entityId: period.id,
          newValues: { reason },
        }
      ),
    });
  });
  return { id: period.id, status: "OPEN" };
}
