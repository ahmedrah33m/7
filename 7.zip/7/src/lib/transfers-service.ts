// =====================================================================
// Warehouse transfers service (Phase 2b) — full state machine:
//
//   DRAFT ──dispatch──▶ IN_TRANSIT ──receive──▶ RECEIVED
//     │                     │ double-receive → VAL_004 (blocked)
//     └──cancel──▶ CANCELLED└──cancel (only DRAFT)
//
//   dispatch: stock OUT (TRANSFER_OUT) from source, exactly once
//   receive:  stock IN  (TRANSFER_IN)  to destination, exactly once
//   Scope: user must access BOTH warehouses to create; receiver needs
//   access to destination warehouse.
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { entityExistsOutsideCompany } from "./scope";
import { nextDocumentNumber } from "./document-number";
import { applyStockMovement } from "./inventory";
import { transferConsumeLayers, transferReceiveLayers } from "./cost-engine";
import { writeAudit } from "./audit";
import { Decimal, dec } from "./decimal";

export interface TransferActor {
  userId: number;
  companyId: number;
  warehouseIds: number[];
  ip?: string;
  userAgent?: string;
}

export async function createTransfer(
  actor: TransferActor,
  input: {
    fromWarehouseId: number;
    toWarehouseId: number;
    notes?: string | null;
    autoDispatch?: boolean;
    lines: { productId: number; qty: number }[];
  }
) {
  const companyId = actor.companyId;

  if (input.fromWarehouseId === input.toWarehouseId) {
    throw new ApiError("VAL_001", "لا يمكن التحويل من المستودع إلى نفسه", [
      { field: "to_warehouse_id", message: "اختر مستودعًا مختلفًا" },
    ]);
  }
  if (!input.lines.length) {
    throw new ApiError("VAL_001", "التحويل بدون بنود", [
      { field: "lines", message: "أضف بندًا واحدًا على الأقل" },
    ]);
  }

  // §41/§71 — resolve both warehouses GLOBALLY first to distinguish:
  //   a) exists but belongs to ANOTHER company → CROSS_COMPANY_TRANSFER (SCOPE_006)
  //   b) belongs to this company but outside the session warehouse scope → SCOPE_002
  //   c) truly missing → VAL_003 (no existence leak)
  const [fromGlobal, toGlobal] = await Promise.all([
    db.warehouse.findFirst({ where: { id: input.fromWarehouseId, deletedAt: null }, select: { id: true, companyId: true } }),
    db.warehouse.findFirst({ where: { id: input.toWarehouseId, deletedAt: null }, select: { id: true, companyId: true } }),
  ]);

  for (const [side, gw, wid] of [
    ["from", fromGlobal, input.fromWarehouseId],
    ["to", toGlobal, input.toWarehouseId],
  ] as const) {
    if (!gw) {
      if (await entityExistsOutsideCompany("warehouse", wid)) {
        await writeAudit(
          { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
          { action: "ACCESS_DENIED", module: "inventory", entityType: "warehouse", entityId: wid,
            newValues: { reason: "CROSS_COMPANY_TRANSFER", side } }
        );
        throw new ApiError("SCOPE_006", side === "from"
          ? "مستودع المصدر يتبع شركة أخرى — التحويل بين الشركات ممنوع"
          : "مستودع الوجهة يتبع شركة أخرى — التحويل بين الشركات ممنوع");
      }
      throw new ApiError("VAL_003", side === "from" ? "مستودع المصدر غير موجود" : "مستودع الوجهة غير موجود");
    }
    if (gw.companyId !== companyId) {
      await writeAudit(
        { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
        { action: "ACCESS_DENIED", module: "inventory", entityType: "warehouse", entityId: wid,
          newValues: { reason: "CROSS_COMPANY_TRANSFER", side, warehouse_company_id: gw.companyId } }
      );
      throw new ApiError("SCOPE_006", side === "from"
        ? "مستودع المصدر يتبع شركة أخرى — التحويل بين الشركات ممنوع"
        : "مستودع الوجهة يتبع شركة أخرى — التحويل بين الشركات ممنوع");
    }
    if (!actor.warehouseIds.includes(wid)) throw new ApiError("SCOPE_002");
  }

  const [fromWh, toWh] = await Promise.all([
    db.warehouse.findFirst({ where: { id: input.fromWarehouseId, companyId, deletedAt: null, isActive: true } }),
    db.warehouse.findFirst({ where: { id: input.toWarehouseId, companyId, deletedAt: null, isActive: true } }),
  ]);
  if (!fromWh) throw new ApiError("VAL_003", "مستودع المصدر غير موجود");
  if (!toWh) throw new ApiError("VAL_003", "مستودع الوجهة غير موجود");

  const productIds = [...new Set(input.lines.map((l) => l.productId))];
  const products = await db.product.findMany({
    where: { id: { in: productIds }, companyId, deletedAt: null },
    select: { id: true, name: true, isActive: true, costPrice: true },
  });
  const pmap = new Map(products.map((p) => [p.id, p]));
  for (const l of input.lines) {
    const p = pmap.get(l.productId);
    if (!p) throw new ApiError("VAL_003", `المنتج #${l.productId} غير موجود`);
    if (!p.isActive) throw new ApiError("VAL_001", `المنتج «${p.name}» معطّل`);
    if (l.qty <= 0) throw new ApiError("VAL_001", `كمية التحويل للمنتج «${p.name}» يجب أن تكون أكبر من صفر`);
  }

  const created = await db.$transaction(async (tx) => {
    const number = await nextDocumentNumber(tx, companyId, "TRANSFER");

    const head = await tx.stockTransfer.create({
      data: {
        companyId,
        number,
        fromWarehouseId: fromWh.id,
        toWarehouseId: toWh.id,
        status: "DRAFT",
        notes: input.notes ?? null,
        createdById: actor.userId,
      },
    });

    const lineIds = new Map<number, number>();
    for (const l of input.lines) {
      const row = await tx.stockTransferLine.create({
        data: { transferId: head.id, productId: l.productId, qty: l.qty },
      });
      lineIds.set(l.productId, row.id);
    }

    if (input.autoDispatch !== false) {
      for (const l of input.lines) {
        // ---- Phase 4 §8: الإرسال يستهلك الطبقات الفيزيائية بتكلفتها
        // الفعلية (FIFO-order دائماً — هوية التكلفة تحفظ في سجل الصرف)
        const moved = await transferConsumeLayers(tx, {
          companyId,
          warehouseId: fromWh.id,
          productId: l.productId,
          qty: l.qty,
          transferId: head.id,
          transferLineId: lineIds.get(l.productId) ?? null,
          fallbackCost: dec(pmap.get(l.productId)?.costPrice),
          userId: actor.userId,
        });
        await applyStockMovement({
          tx,
          companyId,
          warehouseId: fromWh.id,
          productId: l.productId,
          direction: "OUT",
          qty: l.qty,
          unitCost: moved.unitCost,
          refType: "TRANSFER_OUT",
          refId: head.id,
          note: `تحويل ${number} إلى ${toWh.name}`,
          userId: actor.userId,
        });
      }
      await tx.stockTransfer.update({
        where: { id: head.id },
        data: { status: "IN_TRANSIT", dispatchedAt: new Date() },
      });
      head.status = "IN_TRANSIT";
      head.dispatchedAt = new Date();
    }

    return head;
  });

  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CREATE",
      module: "inventory",
      entityType: "stock_transfer",
      entityId: created.id,
      newValues: {
        number: created.number,
        from: fromWh.name,
        to: toWh.name,
        lines: input.lines.length,
        status: created.status,
      },
    }
  );

  return { id: created.id, number: created.number, status: created.status, from: fromWh.name, to: toWh.name };
}

export async function receiveTransfer(
  actor: TransferActor,
  transferId: number,
  opts?: { lines?: { productId: number; qty: number }[] | null }
) {
  const companyId = actor.companyId;

  const trf = await db.stockTransfer.findFirst({
    where: { id: transferId, companyId, deletedAt: null },
    include: { lines: true, fromWarehouse: true, toWarehouse: true },
  });
  if (!trf) throw new ApiError("VAL_003", "التحويل غير موجود");

  // double-receive blocked (VAL_004)
  if (trf.status === "RECEIVED") throw new ApiError("VAL_004", "التحويل مستلم مسبقًا — الاستلام مرة واحدة فقط");
  if (trf.status === "CANCELLED") throw new ApiError("VAL_004", "التحويل ملغى");
  if (trf.status === "DRAFT") throw new ApiError("VAL_004", "التحويل لم يُرسل بعد — أرسله أولًا");

  if (!actor.warehouseIds.includes(trf.toWarehouseId)) throw new ApiError("SCOPE_002");

  // تكلفة بديلة للتحويلات القديمة (قبل المرحلة 4) — من المنتجات نفسها
  const productIds = [...new Set(trf.lines.map((l) => l.productId))];
  const products = await db.product.findMany({
    where: { id: { in: productIds }, companyId, deletedAt: null },
    select: { id: true, costPrice: true },
  });
  const costOf = new Map(products.map((p) => [p.id, dec(p.costPrice)]));

  // default: receive full quantities (can receive partial per line)
  const plan = trf.lines.map((l) => {
    const requested = opts?.lines?.find((x) => x.productId === l.productId)?.qty ?? l.qty;
    if (!dec(requested).isPositive()) throw new ApiError("VAL_001", "كمية الاستلام يجب أن تكون أكبر من صفر");
    if (dec(requested).gt(dec(l.qty))) {
      throw new ApiError("VAL_001", `كمية الاستلام تتجاوز المرسل (${fmt(l.qty)})`);
    }
    return { productId: l.productId, qty: requested, lineId: l.id };
  });

  await db.$transaction(async (tx) => {
    for (const p of plan) {
      // ---- Phase 4 §8: الاستلام ينشئ طبقات الوجهة بتكاليف الإرسال نفسها
      // — لا تكلفة جديدة عشوائية (هوية الطبقات تنقل كما هي)
      const received = await transferReceiveLayers(tx, {
        companyId,
        toWarehouseId: trf.toWarehouseId,
        productId: p.productId,
        qty: p.qty,
        transferId: trf.id,
        transferLineId: p.lineId,
        fallbackCost: costOf.get(p.productId) ?? new Decimal(0),
        createdBy: actor.userId,
      });
      await applyStockMovement({
        tx,
        companyId,
        warehouseId: trf.toWarehouseId,
        productId: p.productId,
        direction: "IN",
        qty: p.qty,
        unitCost: received.pieces.length ? received.unitCost : null,
        refType: "TRANSFER_IN",
        refId: trf.id,
        note: `استلام تحويل ${trf.number} من ${trf.fromWarehouse.name}`,
        userId: actor.userId,
      });
    }
    await tx.stockTransfer.update({
      where: { id: trf.id },
      data: { status: "RECEIVED", receivedAt: new Date() },
    });
  });

  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "POST",
      module: "inventory",
      entityType: "stock_transfer",
      entityId: trf.id,
      newValues: { number: trf.number, status: "RECEIVED", to: trf.toWarehouse.name },
    }
  );

  return { id: trf.id, number: trf.number, status: "RECEIVED" as const, to: trf.toWarehouse.name };
}

export async function cancelTransfer(actor: TransferActor, transferId: number) {
  const companyId = actor.companyId;
  const trf = await db.stockTransfer.findFirst({
    where: { id: transferId, companyId, deletedAt: null },
  });
  if (!trf) throw new ApiError("VAL_003", "التحويل غير موجود");
  if (trf.status !== "DRAFT") {
    // IN_TRANSIT already deducted → cancellation must reverse, blocked in slice
    throw new ApiError(
      "VAL_004",
      trf.status === "IN_TRANSIT"
        ? "التحويل في الطريق — لا يُلغى، استلمه ثم أنشئ تحويلًا عكسيًا"
        : "لا يمكن إلغاء تحويل مستلم"
    );
  }

  await db.stockTransfer.update({ where: { id: trf.id }, data: { status: "CANCELLED" } });

  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CANCEL",
      module: "inventory",
      entityType: "stock_transfer",
      entityId: trf.id,
      newValues: { number: trf.number, status: "CANCELLED" },
    }
  );

  return { id: trf.id, number: trf.number, status: "CANCELLED" as const };
}

function fmt(n: Decimal | number): string {
  const d = dec(n);
  return d.isInteger() ? String(d) : String(d.toDecimalPlaces(3, Decimal.ROUND_HALF_UP));
}
