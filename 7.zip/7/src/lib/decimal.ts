// =====================================================================
// Phase 3 — Financial Decimal Migration (المرحلة 3 — الترقية المالية)
//
// سياسة الحساب المالي المركزية — النقطة الوحيدة للحساب المالي في النظام:
//   · ممنوع نهائياً استخدام JS floating point (+ - * /) في أي حساب مالي.
//   · كل الجمع/الطرح/الضرب/القسمة المالية تمر عبر Decimal (decimal.js).
//   · Prisma يعيد حقول Decimal ككائنات — لا تجمعها بـ + مباشرة أبدًا؛
//     مرّرها عبر dec() أولًا.
//
// الدقات المعتمدة (مطابقة للمخطط):
//   Money   → Decimal(18,4)  د.ع/USD  — تقريب HALF_UP إلى 4 منازل عند التخزين
//   Qty     → Decimal(18,6)  كميات    — 6 منازل (كسور الحبات المحتوبة فقط)
//   Rate    → Decimal(18,6)  أسعار الصرف — 6 منازل
//   Percent → Decimal(9,4)   نِسَب (خصم/ضريبة/عمولة) — 4 منازل
//
// سياسة التقريب (§5 من وثيقة المرحلة — مرة واحدة وعلى مستوى النظام):
//   R1 وضع التقريب: HALF_UP (التقريب التجاري القياسي) — بلا bankers.
//   R2 التقريب عند حدود التخزين فقط: كل قيمة مالية تُقرَّب إلى دقة عمودها
//      (money 4dp / qty 6dp / rate 6dp / pct 4dp) قبل الحفظ.
//   R3 حساب البند: lineTotal = round4(كمية × سعر الوحدة − الخصم)؛
//      الخصم المطلق = round4(الإجمالي قبل الخصم × النسبة ÷ 100)؛
//      الضريبة = round4(lineTotal × نسبة الضريبة ÷ 100).
//   R4 إجماليات الفاتورة = مجموع قيم مدورة مسبقًا (جمع Decimal مضبوط —
//      لا انحراف)؛ grandTotal = subtotal − discountTotal + taxTotal.
//   R5 تحويل العملة: IQD = round4(USD × rate) عند الترحيل للتخزين؛
//      USD للعرض = round6(IQD ÷ rate) — العرض لا يُخزَّن.
//   R6 COGS: تكلفة البند = round4(كمية × تكلفة الوحدة) — لقطة 4dp.
//   R7 العمولة: PERCENT_OF_SALES = round4(الأساس × النسبة ÷ 100)؛
//      PER_UNIT = round4(Σ الكميات × سعر الوحدة).
//   R8 تقييم المخزون: القيمة = Σ round4(الكمية × التكلفة) لكل صنف.
//   R9 الدقة الداخلية 40 خانة معنوية (أعلى من أي حاصل ضرب 18,4×18,6) —
//      لا فقدان أثناء السلسلة الحسابية؛ التقريب فقط عند R2-R8.
//   R10 نحو الحدود (JSON/UI): num(d) → number للنقل والعرض فقط —
//      النقل لا يُعد حسابًا، وإعادة الدخول للحساب تمر عبر dec() مجددًا.
// =====================================================================

import Decimal from "decimal.js";

// R9 — دقة داخلية عالية + وضع التقريب التجاري
Decimal.set({ precision: 40, rounding: Decimal.ROUND_HALF_UP, toExpNeg: -18, toExpPos: 48 });

// ⚠️ تصحيح دلالي جوهري (اكتشاف مرحلة 3 — انحدار التعبئة):
// في decimal.js القيمة صفر «موجبة الإشارة» — new Decimal(0).isPositive() === true —
// بينما العقد الأصلي للنظام (حساب JS عددي) كان isPositive ≡ (x > 0) بدقة.
// التحويل الآلي (x > 0) → x.isPositive() غيّر السلوك عند الصفر تحديدًا
// (مثال: grab() في packaging.ts كانت تسحب 0 حبة و«تنجح»).
// الترقيع هنا — النقطة الوحيدة للحساب المالي — يعيد المعنى الصحيح لكل
// مواضع النظام دفعة واحدة دون تغيير أي موقع استدعاء.
(Decimal.prototype as unknown as { isPositive: () => boolean }).isPositive = function isPositive(): boolean {
  // @ts-expect-error — this داخل النموذج هو Decimal
  return this.gt(0);
};

export { Decimal };
export type Dec = Decimal;

/** دقة المال (Decimal(18,4)) — عدد المنازل العشرية. */
export const MONEY_DP = 4;
/** دقة الكمية (Decimal(18,6)). */
export const QTY_DP = 6;
/** دقة سعر الصرف (Decimal(18,6)). */
export const RATE_DP = 6;
/** دقة النسبة (Decimal(9,4)). */
export const PCT_DP = 4;

const MONITOR_RE = /^-?\d{1,14}(\.\d{1,6})?$/;

/**
 * تحويل آمن من أي مصدر (Prisma.Decimal | decimal.js | number | string | null)
 * إلى Decimal بوحدتنا — القاعدة الوحيدة لدخول قيمة مالية للحساب.
 * قيم Prisma Decimal تُقرأ عبر toString() لضمان نقل الأرقام بالنص الدقيق
 * (تجنب مسار Number() وأي أثر float).
 */
export function dec(v: unknown): Decimal {
  if (v == null || v === "") return new Decimal(0);
  if (v instanceof Decimal) return v;
  try {
    if (typeof v === "object" && typeof (v as { toString?: unknown }).toString === "function") {
      const d = new Decimal((v as { toString(): string }).toString());
      return d.isFinite() ? d : new Decimal(0);
    }
    const d = new Decimal(v as Decimal.Value);
    return d.isFinite() ? d : new Decimal(0);
  } catch {
    return new Decimal(0);
  }
}

/** R2 — تقريب المال إلى 4dp (HALF_UP) قبل التخزين. */
export function moneyR(v: unknown): Decimal {
  return dec(v).toDecimalPlaces(MONEY_DP, Decimal.ROUND_HALF_UP);
}

/** R2 — تقريب الكمية إلى 6dp (HALF_UP). */
export function qtyR(v: unknown): Decimal {
  return dec(v).toDecimalPlaces(QTY_DP, Decimal.ROUND_HALF_UP);
}

/** R2 — تقريب سعر الصرف إلى 6dp (HALF_UP). */
export function rateR(v: unknown): Decimal {
  return dec(v).toDecimalPlaces(RATE_DP, Decimal.ROUND_HALF_UP);
}

/** R2 — تقريب النسبة إلى 4dp (HALF_UP). */
export function pctR(v: unknown): Decimal {
  return dec(v).toDecimalPlaces(PCT_DP, Decimal.ROUND_HALF_UP);
}

/** R10 — مجموع Decimal مضبوط على قائمة بمنتقي اختياري (بديل reduce بـ +). */
export function sumOf<T>(items: readonly T[], pick?: (item: T, index: number) => unknown): Decimal {
  let acc = new Decimal(0);
  for (let i = 0; i < items.length; i++) {
    acc = acc.plus(pick ? dec(pick(items[i], i)) : dec(items[i]));
  }
  return acc;
}

/** R10 — عدد للنقل/العرض فقط (JSON/UI) — لا يُعاد استخدامه في حساب مالي. */
export function num(v: unknown): number {
  return dec(v).toNumber();
}

/**
 * R10 — مثل num() لكن تحافظ على null: للحقول المالية القابلة للإفراغ
 * (packQty / packSalePrice / exchangeRate / creditLimitSnap...).
 * num(null) = 0 يغيّر العقد (null ⇔ بلا قيمة) ويُطلق تحققات زوراً —
 * استخدم nOrNull في حدود الاستجابة ودمج الحقول القابلة للإفراغ.
 */
export function nOrNull(v: unknown): number | null {
  return v == null ? null : dec(v).toNumber();
}

/** نص منسق بدون أصفار زائدة (للرسائل والتدقيق). */
export function decStr(v: unknown): string {
  return dec(v).toString();
}

/** التحقق من أن القيمة رقم مالي معقول (حارس إدخال — ≤14 رقمًا صحيحًا و6 عشري). */
export function isSaneFinancial(v: unknown): boolean {
  if (typeof v !== "number" && typeof v !== "string") return false;
  const s = String(v).trim();
  if (!s) return false;
  return MONITOR_RE.test(s);
}
