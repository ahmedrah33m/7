// =====================================================================
// Document numbering service (MASTER PROMPT rule #11).
// Format: INV-2026-000001 — consumed via row-locked counter inside the
// posting transaction. SQLite lacks SELECT..FOR UPDATE; Prisma's serializable
// transaction + the UNIQUE(company_id, doc_type, year) constraint give the
// equivalent guarantee here; production PostgreSQL uses the row lock
// (implemented in the deploy package init.sql notes).
// =====================================================================

import type { Prisma, PrismaClient } from "@prisma/client";

export const DOC_TYPES = {
  INVOICE: { prefix: "INV" },
  ORDER: { prefix: "ORD" },
  QUOTATION: { prefix: "QTN" },
  PAYMENT: { prefix: "PAY" },
  TRANSFER: { prefix: "TRF" },
  ADJUSTMENT: { prefix: "ADJ" },
  STOCKTAKING: { prefix: "STK" },
  DAMAGE: { prefix: "DMG" },
  RET: { prefix: "RET" },
  PO: { prefix: "PO" },
  RCPT: { prefix: "RCPT" },
  PURCHASE: { prefix: "PUR" },
  SIN: { prefix: "SIN" },
  PRET: { prefix: "PRET" },
  EXP: { prefix: "EXP" },
  CRN: { prefix: "CRN" },
  DLV: { prefix: "DLV" },
  B2B: { prefix: "B2B" },
  SALES_ORDER: { prefix: "SO" },
  // ---- Advanced finance doc types --------------------------------------
  CASH_TRANSFER: { prefix: "CASH-TRF" },
  CLOSING: { prefix: "CLOS" },
  UNIFIED_PAYMENT: { prefix: "UPAY" },
  PAYMENT_VOUCHER: { prefix: "PAY" },
  JOURNAL_ENTRY: { prefix: "JEV" },
  SHIFT: { prefix: "SHIFT" },
  CHECK: { prefix: "CHK" },
  // ---- v15 — Advanced finance completion --------------------------------
  REP_SETTLEMENT: { prefix: "REP-STL" },
  OVERDUE_NOTIF: { prefix: "ODN" },
} as const;

export type DocType = keyof typeof DOC_TYPES;

/**
 * Consume the next document number for (company, docType, year).
 * MUST be called inside the posting transaction.
 */
export async function nextDocumentNumber(
  tx: Prisma.TransactionClient | PrismaClient,
  companyId: number,
  docType: DocType,
  year = new Date().getFullYear()
): Promise<string> {
  const def = DOC_TYPES[docType];

  // Upsert with atomic increment; unique constraint guards concurrency.
  const row = await tx.documentSequence.upsert({
    where: {
      companyId_docType_year: { companyId, docType, year },
    },
    create: {
      companyId,
      docType,
      prefix: def.prefix,
      year,
      currentNumber: 1,
      padding: 6,
    },
    update: { currentNumber: { increment: 1 } },
  });

  return `${row.prefix}-${year}-${String(row.currentNumber).padStart(row.padding, "0")}`;
}
