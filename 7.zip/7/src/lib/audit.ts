// =====================================================================
// Audit-log service (MASTER PROMPT rule #13).
// Every sensitive action lands here with old/new values, ip, user-agent.
// Nothing in the app ever updates or deletes audit rows.
// =====================================================================

import { db } from "@/lib/db";
import type { Prisma } from "@prisma/client";

export type AuditActor = {
  userId?: number | null;
  companyId?: number | null;
  ipAddress?: string | null;
  userAgent?: string | null;
};

export type AuditInput = {
  action: string; // CREATE | UPDATE | LOGIN | LOGIN_FAILED | LOCKOUT | LOGOUT | APPROVE | CANCEL | POST | SYNC ...
  module: string; // auth | users | roles | sales | inventory ...
  entityType: string;
  entityId?: number | null;
  oldValues?: unknown;
  newValues?: unknown;
};

/** Fire-and-forget safe audit write — never throws into the caller flow. */
export async function writeAudit(actor: AuditActor, input: AuditInput): Promise<void> {
  try {
    await db.auditLog.create({
      data: {
        companyId: actor.companyId ?? null,
        userId: actor.userId ?? null,
        action: input.action,
        module: input.module,
        entityType: input.entityType,
        entityId: input.entityId ?? null,
        oldValues: input.oldValues !== undefined ? jsonOrNull(input.oldValues) : null,
        newValues: input.newValues !== undefined ? jsonOrNull(input.newValues) : null,
        ipAddress: actor.ipAddress ?? null,
        userAgent: actor.userAgent ?? null,
      },
    });
  } catch (err) {
    console.error("[audit] failed to write audit row:", err);
  }
}

/** Variant usable inside an active Prisma transaction ($transaction client). */
export function auditData(actor: AuditActor, input: AuditInput): Prisma.AuditLogCreateInput {
  return {
    action: input.action,
    module: input.module,
    entityType: input.entityType,
    entityId: input.entityId ?? null,
    oldValues: input.oldValues !== undefined ? (jsonOrNull(input.oldValues) as string) : null,
    newValues: input.newValues !== undefined ? (jsonOrNull(input.newValues) as string) : null,
    ipAddress: actor.ipAddress ?? null,
    userAgent: actor.userAgent ?? null,
    ...(actor.companyId != null ? { company: { connect: { id: actor.companyId } } } : {}),
    ...(actor.userId != null ? { user: { connect: { id: actor.userId } } } : {}),
  };
}

function jsonOrNull(value: unknown): string | null {
  if (value === undefined || value === null) return null;
  try {
    return JSON.stringify(value);
  } catch {
    return null;
  }
}
