// =====================================================================
// Phase 2 §1-§3 — التحقق المركزي من التعبئة والوحدات:
//   قاعدة واحدة تُفرض في الخادم (POST / PATCH / IMPORT / seed) وليس في
//   الواجهة فقط. القاعدة القياسية:
//     baseUnit !== packageUnit   عندما packQty > 1
//   والرفض الإلزامي:
//     · packQty <= 1               → PRD_002
//     · packUnit == unit           → PRD_003
//     · packPrice بدون packUnit    → PRD_004
//     · packUnit بدون packQty      → PRD_005
//   أي منتج بلا تعبئة (packUnit فارغ) صالح — الوحدة الأساسية هي وحدة البيع.
// =====================================================================

import { ApiError } from "./api";

/** توحيد شكل اسم الوحدة للمقارنة (مسافات/همزات/تاء مربوطة/مفرد-جمع شائع). */
export function normalizeUnitLabel(label: string): string {
  return String(label ?? "")
    .trim()
    .replace(/\s+/g, " ")
    .replace(/[أإآ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .toLowerCase();
}

/** عائلات وحدات متكافئة لغوياً (كرتون/كرتونة/كراتين...) — تُعدّ وحدة واحدة عند المقارنة. */
const UNIT_FAMILIES: string[][] = [
  ["كرتون", "كرتونه", "كراتين", "كارتون", "كارتونه", "carton", "cartons", "ctn"],
  ["صندوق", "صناديق", "box", "boxes"],
  ["باكيت", "باقه", "باقات", "pack", "packet", "باكج"],
  ["علبه", "علب", "حابه", "حبات", "piece", "pieces", "pc", "pcs", "قطعه", "قطع"],
  ["حبه", "حبات", "grain", "unit", "وحيده"],
  ["كيس", "اكياس", "bag", "bags", "sack"],
  ["جالون", "جالونات", "gallon", "gallons"],
  ["لتر", "لترات", "liter", "litre", "l"],
];

/** هل الوحدتان تمثلان نفس الوحدة فعلياً؟ (مطابقة مباشرة أو نفس العائلة) */
export function sameUnit(a: string, b: string): boolean {
  const na = normalizeUnitLabel(a);
  const nb = normalizeUnitLabel(b);
  if (!na || !nb) return false;
  if (na === nb) return true;
  const fa = UNIT_FAMILIES.findIndex((f) => f.includes(na));
  if (fa === -1) return false;
  return UNIT_FAMILIES[fa].includes(nb);
}

export interface PackagingInput {
  /** الوحدة الأساسية (حبة) — إلزامية دائماً */
  unit: string;
  /** وحدة التعبئة (كرتون) — فارغة = بلا تعبئة */
  packUnit?: string | null;
  /** عدد الوحدات في العبوة (11) */
  packQty?: number | null;
  /** سعر العبوة — مسموح فقط مع وحدة تعبئة */
  packSalePrice?: number | null;
}

export interface ValidatedPackaging {
  unit: string;
  packUnit: string | null;
  packQty: number | null;
  packSalePrice: number | null;
  /** هل المنتج معبأ فعلياً؟ (packUnit + packQty صحيحان) */
  hasPack: boolean;
}

/**
 * التحقق المركزي §3 — يُستدعى من POST/PATCH/import/seed.
 * يعيد التعبئة المُطبَّعة أو يرمي ApiError بكود محدد.
 */
export function validatePackaging(input: PackagingInput): ValidatedPackaging {
  const unit = String(input.unit ?? "").trim();
  if (!unit) {
    throw new ApiError("VAL_001", "الوحدة الأساسية للمنتج مطلوبة", [
      { field: "unit", message: "حدد الوحدة الأساسية (مثل: حبة)" },
    ]);
  }

  const rawPackUnit = input.packUnit == null ? "" : String(input.packUnit).trim();
  const packQty = input.packQty == null || input.packQty === ("" as unknown) ? null : Number(input.packQty);
  const packPrice =
    input.packSalePrice == null || input.packSalePrice === ("" as unknown) ? null : Number(input.packSalePrice);

  // ---- حالة بلا تعبئة: لا اسم ولا كمية ولا سعر عبوة
  if (!rawPackUnit && (packQty == null || !Number.isFinite(packQty)) && !packPrice) {
    return { unit, packUnit: null, packQty: null, packSalePrice: null, hasPack: false };
  }

  // ---- packUnit بدون packQty → PRD_005 (§3)
  if (rawPackUnit && (packQty == null || !Number.isFinite(packQty))) {
    throw new ApiError("PRD_005", "وحدة التعبئة تتطلب عدد الوحدات في العبوة", [
      { field: "pack_qty", message: `حدد كم ${unit} في ${rawPackUnit} (مثال: 11)` },
    ]);
  }

  // ---- packQty <= 1 → PRD_002 (§3) — التعبئة بمعنى أصغر من حبتين لا معنى لها
  if (packQty != null && Number.isFinite(packQty) && packQty <= 1) {
    throw new ApiError("PRD_002", "عدد الوحدات في العبوة يجب أن يكون أكبر من 1", [
      { field: "pack_qty", message: "العبوة يجب أن تحتوي حبتين أو أكثر — وإلا اترك وحدة التعبئة فارغة" },
    ]);
  }

  // ---- سعر عبوة بدون وحدة تعبئة → PRD_004 (§3)
  if (!rawPackUnit && packPrice != null && Number.isFinite(packPrice) && packPrice > 0) {
    throw new ApiError("PRD_004", "سعر العبوة يتطلب تحديد وحدة التعبئة أولًا", [
      { field: "pack_unit", message: "حدد اسم وحدة التعبئة (مثل: كرتون) أو احذف سعر العبوة" },
    ]);
  }

  // ---- packUnit == unit → PRD_003 — القاعدة القياسية §2: baseUnit !== packageUnit
  if (rawPackUnit && sameUnit(unit, rawPackUnit)) {
    throw new ApiError(
      "PRD_003",
      `وحدة التعبئة يجب أن تختلف عن الوحدة الأساسية — «${unit}» لا يمكن أن تكون عبوة لنفسها`,
      [
        {
          field: "pack_unit",
          message:
            "القاعدة القياسية: الوحدة الأساسية = أصغر وحدة بيع (حبة/علبة) والتعبئة = العبوة الأكبر (كرتون). مثال صحيح: الوحدة الأساسية «علبة» + التعبئة «كرتون» = 11",
        },
      ]
    );
  }

  return {
    unit,
    packUnit: rawPackUnit || null,
    packQty: packQty != null && Number.isFinite(packQty) ? packQty : null,
    packSalePrice: packPrice != null && Number.isFinite(packPrice) ? packPrice : null,
    hasPack: !!rawPackUnit && !!packQty && packQty > 1,
  };
}
