import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDateTime(d: string | Date | null | undefined): string {
  if (!d) return "—";
  const date = typeof d === "string" ? new Date(d) : d;
  return new Intl.DateTimeFormat("ar-IQ", {
    dateStyle: "short",
    timeStyle: "short",
    numberingSystem: "latn",
  }).format(date);
}

/** IQD money formatting — 1,250,000 د.ع (Latin digits for readability). */
export function formatIQD(n: number | null | undefined): string {
  if (n == null) return "—";
  return `${new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(n)} د.ع`;
}

/** USD money formatting — $1,234.56 (عملة ثانية بجوار الدينار العراقي). */
export function formatUSD(n: number | null | undefined): string {
  if (n == null) return "—";
  return `$${new Intl.NumberFormat("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n)}`;
}

/**
 * تنسيق حسب عملة الفاتورة: المبالغ المخزنة دائمًا بالدينار (عملة الأساس)؛
 * حين تكون العملة دولارًا نعرض المكافئ = المبلغ ÷ سعر الصرف (د.ع لكل $1).
 */
export function fmtMoney(
  n: number | null | undefined,
  currency: "IQD" | "USD",
  exchangeRate?: number | null
): string {
  if (n == null) return "—";
  if (currency === "USD" && exchangeRate && exchangeRate > 0) return formatUSD(n / exchangeRate);
  return formatIQD(n);
}

/** المكافئ الدولاري للعرض المزدوج (أسعار المنتجات مثلًا) — null حين لا يوجد سعر صرف. */
export function usdEquivalent(iqd: number | null | undefined, exchangeRate?: number | null): number | null {
  if (iqd == null || !exchangeRate || exchangeRate <= 0) return null;
  return Math.round((iqd / exchangeRate) * 100) / 100;
}

/** مفتاح localStorage لآخر سعر صرف مستخدم (د.ع لكل $1) — مشترك بين نموذج الفاتورة وكتالوج المنتجات. */
export const USD_RATE_KEY = "usd_rate_iqd";
export function getUsdRate(fallback = 1300): number {
  if (typeof window === "undefined") return fallback;
  const v = Number(window.localStorage.getItem(USD_RATE_KEY));
  return Number.isFinite(v) && v > 0 ? v : fallback;
}
export function setUsdRate(rate: number) {
  if (typeof window === "undefined" || !Number.isFinite(rate) || rate <= 0) return;
  window.localStorage.setItem(USD_RATE_KEY, String(rate));
}
