// =====================================================================
// API route helpers — uniform envelope, client context extraction,
// Zod body parsing with VAL_001 issues, NextError class.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { ZodError, ZodType } from "zod";
import { errorBody, httpStatusFor, type ErrorCode, type FieldIssue } from "@/lib/errors";
import { rateLimit } from "@/lib/rate-limit";
import { dec, num } from "@/lib/decimal";

export class ApiError extends Error {
  code: ErrorCode;
  message: string;
  errors: FieldIssue[];
  constructor(code: ErrorCode, message?: string, errors?: FieldIssue[]) {
    super(message ?? code);
    this.code = code;
    this.message = message ?? code;
    this.errors = errors ?? [];
  }
}

export function clientContext(req: NextRequest) {
  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "127.0.0.1";
  return { ip, userAgent: req.headers.get("user-agent") ?? "unknown" };
}

/**
 * Phase 3 R10 — حد النقل: Prisma.Decimal في كائنات الاستجابة يُسلسل افتراضيًا
 * كنص ("33800.5") مما يكسر الواجهة المتعاملة مع أرقام. هذا المحول العميق
 * يحوّل كل Decimal إلى number (نقل فقط — الحساب داخليًا Decimal عبر
 * src/lib/decimal.ts) + BigInt → number (توافق document_sequences).
 * القيم ≤ 14 خانة معنوية بحد أقصى 4-6 منازل — نقل float64 بلا فقدان.
 */
function serializeFinancial(obj: unknown, depth = 0): unknown {
  if (obj == null || depth > 8) return obj;
  if (typeof obj === "bigint") return Number(obj);
  if (typeof obj === "object") {
    // Decimal (Prisma أو decimal.js): له toString رقمي دقيق
    if (
      typeof (obj as { d?: unknown }).d !== "undefined" &&
      typeof (obj as { e?: unknown }).e === "number" &&
      typeof (obj as { s?: unknown }).s === "number"
    ) {
      try {
        return num(dec(obj));
      } catch {
        return obj;
      }
    }
    if (Array.isArray(obj)) return obj.map((v) => serializeFinancial(v, depth + 1));
    if (obj instanceof Date) return obj;
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
      out[k] = serializeFinancial(v, depth + 1);
    }
    return out;
  }
  return obj;
}

export function ok<T>(data: T, meta?: Record<string, unknown>, http = 200) {
  const payload = serializeFinancial(data) as T;
  return NextResponse.json(
    meta ? { success: true, data: payload, meta } : { success: true, data: payload },
    { status: http }
  );
}

export function fail(code: ErrorCode, message?: string, errors?: FieldIssue[]) {
  return NextResponse.json(errorBody(code, message, errors), {
    status: httpStatusFor(code),
  });
}

/** Parse + validate a JSON body with Zod; strips unknown keys (whitelist). */
export async function parseBody<T>(req: NextRequest, schema: ZodType<T>): Promise<T> {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    throw new ApiError("VAL_001", "الجسم غير صالح — JSON مطلوب");
  }
  const result = schema.safeParse(raw);
  if (!result.success) {
    const issues: FieldIssue[] = result.error.issues.map((i) => ({
      field: i.path.join("."),
      message: i.message,
    }));
    throw new ApiError("VAL_001", undefined, issues);
  }
  return result.data;
}

/** Wrap a route handler: uniform ApiError → envelope, SRV_001 safety net. */
export function handler(
  fn: (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => Promise<NextResponse>
) {
  return async (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => {
    try {
      return await fn(req, ctx);
    } catch (err) {
      if (err instanceof ApiError) {
        return fail(err.code, err.message, err.errors);
      }
      console.error("[api] unhandled error:", err);
      return fail("SRV_001");
    }
  };
}

/** Enforce per-identity rate limit; throws RATE_001 (429). */
export function enforceRateLimit(identity: string, limit = 120) {
  const r = rateLimit(identity, limit);
  if (!r.allowed) {
    throw new ApiError("RATE_001", `أعد المحاولة بعد ${r.retryAfterSec} ثانية`);
  }
}
