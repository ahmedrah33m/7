// =====================================================================
// Sales-order service — the order pipeline ABOVE invoicing:
//   DRAFT → CONFIRMED → (convert) → INVOICED
//   DRAFT | CONFIRMED → CANCELLED
//
// Design rules:
//   · Orders never touch stock or balances — ONLY conversion does,
//     by delegating to createSalesInvoice (the proven atomic engine).
//   · Double-convert is structurally impossible: conversion first
//     CLAIMS the row (CONFIRMED → INVOICING via updateMany where
//     status=CONFIRMED), then posts the invoice, then links it.
//     If posting fails the row reverts to CONFIRMED.
//   · Rep isolation mirrors field-service: a SALES_REP session may
//     only read its own orders and always creates as itself.
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { nextDocumentNumber } from "./document-number";
import { writeAudit } from "./audit";
// Phase 3: كل الحساب المالي هنا Decimal — سياسة R1-R10 في ./decimal.ts
import { Decimal, dec, moneyR, qtyR, pctR, sumOf, num, type Dec } from "./decimal";
import { isSalesRep } from "./field-service";
import { createSalesInvoice, type InvoiceActor } from "./sales-service";
// RP1 §5 — الأسعار الافتراضية من الطبقة المهيكلة (ProductPrice) ثم Legacy موثّق
import { getEffectivePrices, defaultPricesFromRows } from "./product-pricing";
import { getCompanyUsdRate } from "./currency";

export type OrderActor = InvoiceActor;

export const ORDER_STATUSES = ["DRAFT", "CONFIRMED", "INVOICING", "INVOICED", "CANCELLED"] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export interface CreateOrderInput {
  customerId: number;
  warehouseId: number;
  notes?: string | null;
  expectedDate?: string | null; // ISO date
  lines: { productId: number; qty: number; unitPrice?: number; discountPct?: number }[];
}

/** Rep isolation: reps see only their own orders; managers see all. */
export async function orderWhereForActor(actor: OrderActor) {
  if (await isSalesRep(actor.userId)) {
    return { companyId: actor.companyId, deletedAt: null, createdById: actor.userId };
  }
  return { companyId: actor.companyId, deletedAt: null };
}

async function loadOrder(actor: OrderActor, id: number) {
  const order = await db.salesOrder.findFirst({
    where: { ...(await orderWhereForActor(actor)), id },
    include: {
      customer: { select: { id: true, code: true, name: true, balance: true } },
      warehouse: { select: { id: true, code: true, name: true } },
      creator: { select: { id: true, fullName: true, username: true } },
      invoice: { select: { id: true, number: true } },
      lines: { include: { product: { select: { id: true, code: true, name: true, unit: true } } } },
    },
  });
  if (!order) throw new ApiError("VAL_003", "أمر البيع غير موجود أو خارج نطاقك");
  return order;
}

// ---------------------------------------------------------------------
// Create (DRAFT)
// ---------------------------------------------------------------------

export async function createSalesOrder(actor: OrderActor, input: CreateOrderInput) {
  const companyId = actor.companyId;

  if (!input.lines.length) {
    throw new ApiError("VAL_001", "أمر البيع بدون بنود", [
      { field: "lines", message: "أضف بندًا واحدًا على الأقل" },
    ]);
  }

  const customer = await db.customer.findFirst({
    where: { id: input.customerId, companyId, deletedAt: null },
  });
  if (!customer) throw new ApiError("VAL_003", "العميل غير موجود");
  if (!customer.isActive) throw new ApiError("VAL_001", "العميل معطل");

  if (!input.warehouseId) throw new ApiError("VAL_001", "حدد المستودع");
  if (!actor.warehouseIds.includes(input.warehouseId)) throw new ApiError("SCOPE_002");
  const wh = await db.warehouse.findFirst({
    where: { id: input.warehouseId, companyId, deletedAt: null, isActive: true },
    include: { branch: { select: { id: true } } },
  });
  if (!wh) throw new ApiError("VAL_003", "المستودع غير موجود");

  const productIds = [...new Set(input.lines.map((l) => l.productId))];
  const products = await db.product.findMany({
    where: { id: { in: productIds }, companyId, deletedAt: null },
  });
  const pmap = new Map(products.map((p) => [p.id, p]));
  const effMap = await getEffectivePrices(companyId, productIds);
  const companyRate = [...effMap.values()].flat().some((r) => r.currency === "USD")
    ? await getCompanyUsdRate(companyId)
    : null;

  const computed = input.lines.map((l) => {
    const p = pmap.get(l.productId);
    if (!p) throw new ApiError("VAL_003", `المنتج #${l.productId} غير موجود`);
    if (!p.isActive) throw new ApiError("VAL_001", `المنتج «${p.name}» معطّل`);
    const qty = qtyR(dec(l.qty));
    if (!qty.isPositive()) throw new ApiError("VAL_001", `الكمية يجب أن تكون أكبر من صفر للمنتج «${p.name}»`);
    const unitPrice =
      l.unitPrice != null
        ? moneyR(dec(l.unitPrice))
        : defaultPricesFromRows("sales-order", companyId, effMap.get(l.productId) ?? [], { id: p.id, name: p.name }, num(moneyR(dec(p.salePrice))), p.packSalePrice != null ? num(moneyR(dec(p.packSalePrice))) : null, null, companyRate).pieceIqd;
    const discountPct = pctR(Decimal.min(Decimal.max(dec(l.discountPct ?? 0), 0), 100));
    const gross = moneyR(qty.mul(unitPrice));
    const lineTotal = moneyR(gross.mul(new Decimal(1).minus(discountPct.div(100))));
    return { product: p, qty, unitPrice, discountPct, lineTotal };
  });

  const subtotal = moneyR(sumOf(computed, (l) => l.qty.mul(l.unitPrice)));
  const discountTotal = moneyR(subtotal.minus(sumOf(computed, (l) => l.lineTotal)));
  const grandTotal = moneyR(subtotal.minus(discountTotal));

  const expectedDate = input.expectedDate ? new Date(input.expectedDate) : null;

  const order = await db.$transaction(async (tx) => {
    const number = await nextDocumentNumber(tx, companyId, "SALES_ORDER");
    const created = await tx.salesOrder.create({
      data: {
        companyId,
        branchId: wh.branch.id,
        warehouseId: wh.id,
        number,
        customerId: customer.id,
        status: "DRAFT",
        expectedDate: expectedDate && !isNaN(expectedDate.getTime()) ? expectedDate : null,
        subtotal,
        discountTotal,
        taxTotal: new Decimal(0),
        grandTotal,
        notes: input.notes ?? null,
        createdById: actor.userId,
      },
    });
    for (const l of computed) {
      await tx.salesOrderLine.create({
        data: {
          orderId: created.id,
          productId: l.product.id,
          qty: l.qty,
          unitPrice: l.unitPrice,
          discountPct: l.discountPct,
          lineTotal: l.lineTotal,
        },
      });
    }
    return created;
  });

  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CREATE",
      module: "sales",
      entityType: "sales_order",
      entityId: order.id,
      newValues: { number: order.number, customer: customer.name, grandTotal: order.grandTotal, lines: computed.length },
    }
  );

  // R10 — حدود الاستجابة: أرقام للواجهة كما كانت
  return { id: order.id, number: order.number, status: order.status, grand_total: num(order.grandTotal) };
}

// ---------------------------------------------------------------------
// Confirm: DRAFT → CONFIRMED
// ---------------------------------------------------------------------

export async function confirmSalesOrder(actor: OrderActor, id: number) {
  const order = await loadOrder(actor, id);
  if (order.status !== "DRAFT") {
    throw new ApiError("VAL_004", `لا يمكن تأكيد أمر بحالة ${order.status} — المؤكد فقط من حالة DRAFT`);
  }
  await db.salesOrder.update({ where: { id: order.id }, data: { status: "CONFIRMED" } });
  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    { action: "CONFIRM", module: "sales", entityType: "sales_order", entityId: order.id, newValues: { number: order.number, status: "CONFIRMED" } }
  );
  return { id: order.id, number: order.number, status: "CONFIRMED" as const };
}

// ---------------------------------------------------------------------
// Cancel: DRAFT | CONFIRMED → CANCELLED
// ---------------------------------------------------------------------

export async function cancelSalesOrder(actor: OrderActor, id: number) {
  const order = await loadOrder(actor, id);
  if (order.status !== "DRAFT" && order.status !== "CONFIRMED") {
    throw new ApiError("VAL_004", `لا يمكن إلغاء أمر بحالة ${order.status}`);
  }
  await db.salesOrder.update({ where: { id: order.id }, data: { status: "CANCELLED" } });
  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    { action: "CANCEL", module: "sales", entityType: "sales_order", entityId: order.id, newValues: { number: order.number, status: "CANCELLED" } }
  );
  return { id: order.id, number: order.number, status: "CANCELLED" as const };
}

// ---------------------------------------------------------------------
// Convert: CONFIRMED → INVOICED (via the real invoice engine)
// ---------------------------------------------------------------------

export interface ConvertInput {
  type: "CASH" | "CREDIT";
  paidAmount?: number | null;
}

export async function convertOrderToInvoice(actor: OrderActor, id: number, input: ConvertInput) {
  const order = await loadOrder(actor, id);

  if (order.status === "INVOICED" && order.invoiceId) {
    throw new ApiError("VAL_004", `الأمر محوّل مسبقًا إلى الفاتورة ${order.invoice?.number ?? order.invoiceId}`);
  }
  if (order.status !== "CONFIRMED") {
    throw new ApiError("VAL_004", `التحويل يتطلب أمرًا مؤكدًا — الحالة الحالية: ${order.status}`);
  }

  // 1) Claim the row — atomic guard against double conversion.
  const claimed = await db.salesOrder.updateMany({
    where: { id: order.id, status: "CONFIRMED" },
    data: { status: "INVOICING" },
  });
  if (claimed.count === 0) {
    throw new ApiError("VAL_004", "الأمر قيد التحويل حاليًا من جلسة أخرى");
  }

  try {
    // 2) Post the invoice with the SAME lines through the proven engine
    //    (stock OUT + credit guard + numbering in ONE transaction).
    const invoice = await createSalesInvoice(actor, {
      customerId: order.customerId,
      warehouseId: order.warehouseId,
      type: input.type,
      paidAmount: input.paidAmount ?? null,
      notes: `تحويل من أمر البيع ${order.number}`,
      lines: order.lines.map((l) => ({
        productId: l.productId,
        qty: num(l.qty), // R10 — حدود الوحدة: InvoiceLineInput يستقبل numbers
        unit_price: l.unitPrice != null ? num(l.unitPrice) : null,
        discount_pct: l.discountPct != null ? num(l.discountPct) : null,
      })),
    });

    // 3) Link + finalize.
    await db.salesOrder.update({
      where: { id: order.id },
      data: { status: "INVOICED", invoiceId: invoice.id },
    });

    await writeAudit(
      { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
      {
        action: "CONVERT",
        module: "sales",
        entityType: "sales_order",
        entityId: order.id,
        newValues: { number: order.number, invoice: invoice.number, grand_total: invoice.grand_total },
      }
    );

    return { order_id: order.id, order_number: order.number, invoice_id: invoice.id, invoice_number: invoice.number, grand_total: invoice.grand_total };
  } catch (e) {
    // Posting failed → release the claim, order stays editable.
    await db.salesOrder.updateMany({
      where: { id: order.id, status: "INVOICING" },
      data: { status: "CONFIRMED" },
    });
    throw e;
  }
}

/** Shared list shaping for the API route. */
export function shapeOrderRow(o: {
  id: number; number: string; status: string; orderDate: Date; expectedDate: Date | null;
  grandTotal: Dec | number; subtotal: Dec | number; discountTotal: Dec | number;
  customer: { id: number; code: string; name: string };
  warehouse: { id: number; code: string; name: string };
  creator: { id: number; fullName: string; username: string };
  invoice?: { id: number; number: string } | null;
  _count?: { lines: number };
}) {
  return {
    id: o.id,
    number: o.number,
    status: o.status,
    order_date: o.orderDate,
    expected_date: o.expectedDate,
    grand_total: num(o.grandTotal),
    subtotal: num(o.subtotal),
    discount_total: num(o.discountTotal),
    customer: o.customer,
    warehouse: o.warehouse,
    created_by: o.creator,
    invoice: o.invoice ?? null,
    lines_count: o._count?.lines ?? 0,
  };
}
