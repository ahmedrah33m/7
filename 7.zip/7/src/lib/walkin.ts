// =====================================================================
// Walk-In customer engine (MASTER PROMPT Phases 18-33).
//
// Strategy = SHARED (الاستراتيجية الموحدة §52): ONE system-managed
// walk-in record per company (code CASH-001, type WALK_IN) used by POS
// for fast cash sales. No per-invoice walk-in records are ever created.
//
// Rules enforced here + in sales-service:
//   R1  walk-in customers can only buy CASH (no credit, no partial) → WALK_001
//   R2  no receivable/ledger for walk-in (due is always 0)
//   R3  walk-in records are system-managed — users cannot create them manually
//   R4  converting the shared record to REGISTERED auto-creates a fresh
//       shared walk-in so POS keeps working (history preserved §22/§52)
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { writeAudit } from "./audit";

export const WALK_IN_TYPES = ["WALK_IN", "CASH_CUSTOMER", "GUEST"] as const;
export type WalkInType = (typeof WALK_IN_TYPES)[number];

export function isWalkInType(t: string | null | undefined): boolean {
  return (WALK_IN_TYPES as readonly string[]).includes(t ?? "");
}

/** Find (or create) the shared default walk-in customer of a company. */
export async function ensureWalkInCustomer(companyId: number): Promise<{ id: number; code: string; name: string; branchId: number | null }> {
  const existing = await db.customer.findFirst({
    where: { companyId, customerType: "WALK_IN", deletedAt: null },
    orderBy: { id: "asc" },
  });
  if (existing) {
    // company-wide record — never branch-bound
    if (existing.branchId != null) {
      await db.customer.update({ where: { id: existing.id }, data: { branchId: null } });
    }
    return { id: existing.id, code: existing.code, name: existing.name, branchId: existing.branchId };
  }

  // pick the next free CASH-xxx code
  const rows = await db.customer.findMany({
    where: { companyId, code: { startsWith: "CASH-" }, deletedAt: null },
    select: { code: true },
  });
  const used = new Set(rows.map((r) => r.code));
  let n = 1;
  while (used.has(`CASH-${String(n).padStart(3, "0")}`)) n++;
  const code = `CASH-${String(n).padStart(3, "0")}`;

  const created = await db.customer.create({
    data: {
      companyId,
      code,
      name: "زبون نقدي / زبون متردد",
      customerType: "WALK_IN",
      creditLimit: 0,
      creditDays: 0,
      isActive: true,
    },
  });
  return { id: created.id, code: created.code, name: created.name, branchId: created.branchId };
}

/** Guard used by createSalesInvoice — walk-in types are cash-only (Phase 21). */
export async function assertWalkInPaymentAllowed(
  customerType: string,
  invoiceType: "CASH" | "CREDIT",
  auditCtx?: { userId: number; companyId: number; ip?: string; userAgent?: string; customerId?: number }
): Promise<void> {
  if (isWalkInType(customerType) && invoiceType === "CREDIT") {
    // Audit requirement (Phase 48): Walk-In Credit Attempt
    if (auditCtx) {
      await writeAudit(
        { userId: auditCtx.userId, companyId: auditCtx.companyId, ipAddress: auditCtx.ip, userAgent: auditCtx.userAgent },
        {
          action: "WALKIN_CREDIT_ATTEMPT",
          module: "sales",
          entityType: "customer",
          entityId: auditCtx.customerId,
          newValues: { customer_type: customerType, attempted: "CREDIT", result: "DENIED" },
        }
      );
    }
    throw new ApiError("WALK_001");
  }
}

/** Customers API guard — walk-in types are system-managed (Phase 33/52). */
export function assertManualCustomerTypeAllowed(requestedType?: string | null): void {
  if (requestedType && requestedType !== "REGISTERED") {
    throw new ApiError("WALK_002");
  }
}
