// =====================================================================
// Session payload builder — shared by login / switch-branch /
// switch-company / me / refresh so every entry point returns the SAME
// scope shape (Multi-Company / Multi-Branch MASTER PROMPT, Phases 14-16).
// =====================================================================

import { db } from "./db";
import type { Session } from "./auth";
import { adminLevelOf, type AdminLevel } from "./scope";
import { subscriptionInfo, type SubscriptionInfo, type SubscriptionStatus } from "./subscription";

export interface BranchBrief { id: number; code: string; name: string; company_id: number }

// حالة اشتراك الشركة — مختصرة للمبدّل والقوائم (المشكلة 3: الحالة ظاهرة)
export interface CompanySubscriptionBrief {
  status: SubscriptionStatus;
  days_left: number | null;
  is_suspended: boolean;
  ends_at: string | null;
}
export interface CompanyBrief {
  id: number;
  code: string | null;
  name: string;
  logo_url?: string | null; // شعار الشركة — الهيدر/القائمة الجانبية
  subscription?: CompanySubscriptionBrief;
}

export interface ScopePayload {
  scope_type: string;
  // المستوى الإداري المشتق (وثيقة Hierarchical Visibility §2) —
  // PLATFORM_OWNER | COMPANY_MANAGER | BRANCH_MANAGER | EMPLOYEE
  admin_level: AdminLevel;
  active_branch_id: number | null;
  active_company_id: number;
  companies: CompanyBrief[];
  branches: BranchBrief[];
  warehouses: { id: number; code: string; name: string; type: string }[];
  customer_type_labels: Record<string, string>;
  // حالة اشتراك الشركة النشطة (لافتة التحذير في الداشبورد + لوحة المالك)
  subscription?: SubscriptionInfo;
}

export const DEFAULT_CUSTOMER_TYPE_LABELS: Record<string, string> = {
  REGISTERED: "عميل مسجل",
  WALK_IN: "زبون نقدي / متردد",
  CASH_CUSTOMER: "زبون كاشي",
  GUEST: "زبون غير معروف",
};

/** Read the configurable customer-type labels from settings (Phase 19). */
export async function customerTypeLabels(companyId: number): Promise<Record<string, string>> {
  const row = await db.setting.findFirst({
    where: { companyId, key: "customers.labels" },
  });
  if (!row) return DEFAULT_CUSTOMER_TYPE_LABELS;
  try {
    const parsed = JSON.parse(row.value) as Partial<Record<string, string>>;
    const merged: Record<string, string> = { ...DEFAULT_CUSTOMER_TYPE_LABELS };
    for (const [k, v] of Object.entries(parsed)) if (typeof v === "string") merged[k] = v;
    return merged;
  } catch {
    return DEFAULT_CUSTOMER_TYPE_LABELS;
  }
}

/** Branch + company briefs the session may see/switch between. */
export async function scopeBriefs(session: Session): Promise<{
  branches: BranchBrief[];
  companies: CompanyBrief[];
}> {
  const [branches, companies] = await Promise.all([
    db.branch.findMany({
      where: { id: { in: session.branchIds }, deletedAt: null },
      select: { id: true, code: true, name: true, companyId: true },
      orderBy: { id: "asc" },
    }),
    db.company.findMany({
      where: { id: { in: session.companyIds }, deletedAt: null },
      select: { id: true, code: true, name: true, logoUrl: true, subscriptionEndsAt: true, isSuspended: true },
      orderBy: { id: "asc" },
    }),
  ]);
  return {
    branches: branches.map((b) => ({ id: b.id, code: b.code, name: b.name, company_id: b.companyId })),
    companies: companies.map((c) => ({
      id: c.id,
      code: c.code,
      name: c.name,
      logo_url: c.logoUrl,
      subscription: subBrief(c.subscriptionEndsAt, c.isSuspended),
    })),
  };
}

function subBrief(endsAt: Date | null, isSuspended: boolean): CompanySubscriptionBrief {
  const info = subscriptionInfo(endsAt, isSuspended);
  return { status: info.status, days_left: info.days_left, is_suspended: info.is_suspended, ends_at: info.ends_at };
}

/** Full scope payload for the session — branches/warehouses of the ACTIVE
 *  company ONLY (strict per-company isolation: company A never receives
 *  company B's structure, even with identical branch names). */
export async function buildScopePayload(session: Session): Promise<ScopePayload> {
  const [branches, companies, warehouses, labels, activeCompany] = await Promise.all([
    db.branch.findMany({
      where: { companyId: session.companyId, isActive: true, deletedAt: null },
      select: { id: true, code: true, name: true, companyId: true },
      orderBy: { id: "asc" },
    }),
    db.company.findMany({
      where: { id: { in: session.companyIds }, deletedAt: null },
      select: { id: true, code: true, name: true, logoUrl: true, subscriptionEndsAt: true, isSuspended: true },
      orderBy: { id: "asc" },
    }),
    db.warehouse.findMany({
      where: { id: { in: session.warehouseIds }, deletedAt: null },
      select: { id: true, code: true, name: true, type: true },
      orderBy: { id: "asc" },
    }),
    customerTypeLabels(session.companyId),
    db.company.findFirst({
      where: { id: session.companyId, deletedAt: null },
      select: { subscriptionEndsAt: true, isSuspended: true, subscriptionNote: true },
    }),
  ]);

  // Branches the session may actually operate on (granted set)
  const granted = branches.filter((b) => session.branchIds.includes(b.id));

  return {
    scope_type: session.scopeType,
    admin_level: adminLevelOf(session.scopeType),
    active_branch_id: session.activeBranchId,
    active_company_id: session.companyId,
    companies: companies.map((c) => ({
      id: c.id,
      code: c.code,
      name: c.name,
      logo_url: c.logoUrl,
      subscription: subBrief(c.subscriptionEndsAt, c.isSuspended),
    })),
    branches: granted.map((b) => ({ id: b.id, code: b.code, name: b.name, company_id: b.companyId })),
    warehouses,
    customer_type_labels: labels,
    subscription: activeCompany
      ? subscriptionInfo(activeCompany.subscriptionEndsAt, activeCompany.isSuspended, activeCompany.subscriptionNote)
      : undefined,
  };
}
