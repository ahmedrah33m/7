// =====================================================================
// Finance service — cash ledger operations (Phase 4):
//   · collectFromCustomer  → cash IN  + customer.balance ↓
//   · paySupplier          → cash OUT + supplier.balance ↓
//   · recordExpense        → cash OUT (category EXPENSE)
//   · openCashbox          → cash IN (opening balance)
//
// ONE transaction = cash_transaction (with balanceAfter) + cashbox
// balance projection + party balance + audit. Over-collecting beyond
// the receivable is blocked (VAL_001) unless overpay allowed explicitly
// (negative balances prevented).
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { nextDocumentNumber } from "./document-number";
import { writeAudit } from "./audit";
import { Decimal, dec, moneyR, num } from "./decimal";
import type { Prisma } from "@prisma/client";

export interface CashActor {
  userId: number;
  companyId: number;
  ip?: string;
  userAgent?: string;
}

type CashCategory =
  | "COLLECTION" | "SUPPLIER_PAYMENT" | "EXPENSE" | "OPENING" | "REFUND" | "OTHER";

function fmt(n: Decimal | number | null | undefined): string {
  return new Intl.NumberFormat("ar-IQ", { maximumFractionDigits: 2 }).format(dec(n).toNumber());
}

async function postCashRow(
  tx: Prisma.TransactionClient,
  opts: {
    companyId: number;
    cashboxId: number;
    direction: "IN" | "OUT";
    category: CashCategory;
    amount: Decimal | number;
    partyType?: "CUSTOMER" | "SUPPLIER" | null;
    customerId?: number | null;
    supplierId?: number | null;
    refType?: string | null;
    refId?: number | null;
    note?: string | null;
    userId: number;
    docType: "PAYMENT" | "EXP";
  }
) {
  // Lock-ish read of cashbox inside tx (SQLite serializes writes).
  const box = await tx.cashbox.findFirst({
    where: { id: opts.cashboxId, companyId: opts.companyId, deletedAt: null },
  });
  if (!box) throw new ApiError("VAL_003", "الصندوق غير موجود");
  if (!box.isActive) throw new ApiError("VAL_001", "الصندوق معطل");

  const after =
    opts.direction === "IN" ? moneyR(dec(box.balance).plus(opts.amount)) : moneyR(dec(box.balance).minus(opts.amount));
  if (after.isNegative()) {
    throw new ApiError(
      "VAL_001",
      `رصيد الصندوق لا يكفي — المتاح: ${fmt(box.balance)}، المطلوب: ${fmt(opts.amount)}`,
      [{ field: "amount", message: "المبلغ أكبر من رصيد الصندوق المتاح" }]
    );
  }

  const number = await nextDocumentNumber(tx, opts.companyId, opts.docType);

  const row = await tx.cashTransaction.create({
    data: {
      companyId: opts.companyId,
      cashboxId: box.id,
      direction: opts.direction,
      category: opts.category,
      amount: moneyR(dec(opts.amount)),
      balanceAfter: after,
      partyType: opts.partyType ?? null,
      customerId: opts.customerId ?? null,
      supplierId: opts.supplierId ?? null,
      refType: opts.refType ?? null,
      refId: opts.refId ?? null,
      note: opts.note ?? null,
      createdBy: opts.userId,
    },
  });

  await tx.cashbox.update({ where: { id: box.id }, data: { balance: after } });

  return { row, number, box, balanceAfter: after };
}

// ---------------------------------------------------------------------
// 1) تحصيل من عميل — customer receipt
// ---------------------------------------------------------------------
export async function collectFromCustomer(
  actor: CashActor,
  input: {
    customerId: number;
    cashboxId: number;
    amount: number;
    invoiceId?: number | null;
    note?: string | null;
  }
) {
  const companyId = actor.companyId;
  if (input.amount <= 0) throw new ApiError("VAL_001", "مبلغ التحصيل يجب أن يكون أكبر من صفر");

  const customer = await db.customer.findFirst({
    where: { id: input.customerId, companyId, deletedAt: null },
  });
  if (!customer) throw new ApiError("VAL_003", "العميل غير موجود");

  // Over-collect guard: cannot exceed receivable (balance) — تسامح 0.001 محفوظ كما هو
  if (dec(input.amount).gt(dec(customer.balance).plus("0.001"))) {
    throw new ApiError(
      "VAL_001",
      `المبلغ يتجاوز مديونية العميل — المديونية: ${fmt(customer.balance)}`,
      [{ field: "amount", message: `الحد الأقصى للتحصيل ${fmt(customer.balance)}` }]
    );
  }

  // Optional allocation to a specific invoice
  let invoiceRef: { id: number; number: string } | null = null;
  if (input.invoiceId) {
    const inv = await db.salesInvoice.findFirst({
      where: { id: input.invoiceId, companyId, deletedAt: null, customerId: customer.id },
    });
    if (!inv) throw new ApiError("VAL_003", "الفاتورة غير موجودة لهذا العميل");
    const due = moneyR(dec(inv.grandTotal).minus(inv.paidAmount));
    if (dec(input.amount).gt(due.plus("0.001"))) {
      throw new ApiError("VAL_001", `المبلغ يتجاوز المتقمق على الفاتورة ${inv.number} — المتبقي: ${fmt(due)}`);
    }
    invoiceRef = { id: inv.id, number: inv.number };
  }

  const result = await db.$transaction(async (tx) => {
    const posted = await postCashRow(tx, {
      companyId,
      cashboxId: input.cashboxId,
      direction: "IN",
      category: "COLLECTION",
      amount: moneyR(dec(input.amount)),
      partyType: "CUSTOMER",
      customerId: customer.id,
      refType: invoiceRef ? "SALES_INVOICE" : null,
      refId: invoiceRef?.id ?? null,
      note: input.note ?? (invoiceRef ? `تحصيل على الفاتورة ${invoiceRef.number}` : "تحصيل من عميل"),
      userId: actor.userId,
      docType: "PAYMENT",
    });

    await tx.customer.update({
      where: { id: customer.id },
      data: { balance: { decrement: moneyR(dec(input.amount)) } },
    });

    if (invoiceRef) {
      await tx.salesInvoice.update({
        where: { id: invoiceRef.id },
        data: { paidAmount: { increment: moneyR(dec(input.amount)) } },
      });
    }

    return posted;
  });

  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CREATE",
      module: "finance",
      entityType: "customer_collection",
      entityId: result.row.id,
      newValues: {
        number: result.number,
        customer: customer.name,
        amount: moneyR(dec(input.amount)),
        invoice: invoiceRef?.number ?? null,
      },
    }
  );

  return {
    id: result.row.id,
    number: result.number,
    amount: num(moneyR(dec(input.amount))),
    cashbox: { id: result.box.id, name: result.box.name, balance_after: num(result.balanceAfter) },
    customer: { id: customer.id, name: customer.name, balance_after: num(moneyR(dec(customer.balance).minus(input.amount))) },
    invoice: invoiceRef,
  };
}

// ---------------------------------------------------------------------
// 2) سداد لمورد — supplier payment
// ---------------------------------------------------------------------
export async function paySupplier(
  actor: CashActor,
  input: { supplierId: number; cashboxId: number; amount: number; note?: string | null }
) {
  const companyId = actor.companyId;
  if (input.amount <= 0) throw new ApiError("VAL_001", "مبلغ السداد يجب أن يكون أكبر من صفر");

  const supplier = await db.supplier.findFirst({
    where: { id: input.supplierId, companyId, deletedAt: null },
  });
  if (!supplier) throw new ApiError("VAL_003", "المورد غير موجود");
  if (dec(input.amount).gt(dec(supplier.balance).plus("0.001"))) {
    throw new ApiError(
      "VAL_001",
      `المبلغ يتجاوز المستحق للمورد — المستحق: ${fmt(supplier.balance)}`,
      [{ field: "amount", message: `الحد الأقصى للسداد ${fmt(supplier.balance)}` }]
    );
  }

  const result = await db.$transaction(async (tx) => {
    const posted = await postCashRow(tx, {
      companyId,
      cashboxId: input.cashboxId,
      direction: "OUT",
      category: "SUPPLIER_PAYMENT",
      amount: moneyR(dec(input.amount)),
      partyType: "SUPPLIER",
      supplierId: supplier.id,
      note: input.note ?? "سداد لمورد",
      userId: actor.userId,
      docType: "PAYMENT",
    });
    await tx.supplier.update({
      where: { id: supplier.id },
      data: { balance: { decrement: moneyR(dec(input.amount)) } },
    });
    return posted;
  });

  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CREATE",
      module: "finance",
      entityType: "supplier_payment",
      entityId: result.row.id,
      newValues: { number: result.number, supplier: supplier.name, amount: num(moneyR(dec(input.amount))) },
    }
  );

  return {
    id: result.row.id,
    number: result.number,
    amount: num(moneyR(dec(input.amount))),
    cashbox: { id: result.box.id, name: result.box.name, balance_after: num(result.balanceAfter) },
    supplier: { id: supplier.id, name: supplier.name, balance_after: num(moneyR(dec(supplier.balance).minus(input.amount))) },
  };
}

// ---------------------------------------------------------------------
// 3) مصروف — expense
// ---------------------------------------------------------------------
export async function recordExpense(
  actor: CashActor,
  input: { cashboxId: number; amount: number; title: string; note?: string | null }
) {
  const companyId = actor.companyId;
  if (input.amount <= 0) throw new ApiError("VAL_001", "مبلغ المصروف يجب أن يكون أكبر من صفر");
  if (!input.title?.trim()) throw new ApiError("VAL_001", "بيان المصروف مطلوب");

  const result = await db.$transaction(async (tx) => {
    return postCashRow(tx, {
      companyId,
      cashboxId: input.cashboxId,
      direction: "OUT",
      category: "EXPENSE",
      amount: moneyR(dec(input.amount)),
      note: input.note ? `${input.title} — ${input.note}` : input.title,
      userId: actor.userId,
      docType: "EXP",
    });
  });

  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CREATE",
      module: "finance",
      entityType: "expense",
      entityId: result.row.id,
      newValues: { number: result.number, title: input.title, amount: num(moneyR(dec(input.amount))) },
    }
  );

  return {
    id: result.row.id,
    number: result.number,
    title: input.title,
    amount: moneyR(dec(input.amount)),
    cashbox: { id: result.box.id, name: result.box.name, balance_after: result.balanceAfter },
  };
}

// ---------------------------------------------------------------------
// 4) رصيد افتتاحي للصندوق — opening balance
// ---------------------------------------------------------------------
export async function openCashbox(
  actor: CashActor,
  input: { cashboxId: number; amount: number; note?: string | null }
) {
  const companyId = actor.companyId;
  if (input.amount <= 0) throw new ApiError("VAL_001", "المبلغ يجب أن يكون أكبر من صفر");

  const result = await db.$transaction(async (tx) => {
    return postCashRow(tx, {
      companyId,
      cashboxId: input.cashboxId,
      direction: "IN",
      category: "OPENING",
      amount: moneyR(dec(input.amount)),
      note: input.note ?? "رصيد افتتاحي",
      userId: actor.userId,
      docType: "PAYMENT",
    });
  });

  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CREATE",
      module: "finance",
      entityType: "cash_opening",
      entityId: result.row.id,
      newValues: { number: result.number, amount: num(moneyR(dec(input.amount))) },
    }
  );

  return {
    id: result.row.id,
    number: result.number,
    amount: moneyR(dec(input.amount)),
    cashbox: { id: result.box.id, name: result.box.name, balance_after: result.balanceAfter },
  };
}
