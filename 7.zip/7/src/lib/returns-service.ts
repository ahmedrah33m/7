// =====================================================================
// Sales returns service (Phase 5b):
//   ONE transaction = numbering + stock IN (RETURN_IN) + receivable
//   relief (credit note) and/or cash refund + audit.
//
// Business rules:
//   R1  return qty ≤ (sold qty − previously returned) per invoice line
//   R2  refund split: credit_note (against receivable) + refund_cash
//       must equal total, cash refund flows through the cash ledger OUT
//   R3  invoice returns keep the original line price (no repricing)
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { nextDocumentNumber } from "./document-number";
import { applyStockMovement } from "./inventory";
import { writeAudit } from "./audit";
// Phase 3: كل الحساب المالي هنا Decimal — سياسة R1-R10 في ./decimal.ts
import { Decimal, dec, moneyR, qtyR, sumOf, num } from "./decimal";
import { packInfoOf, restockToPackages, txOf } from "./packaging";
// Phase 4 — استرجاع الطبقات بتكلفة الصرف الفعلية (§7)
import { restoreLayersFromConsumptions } from "./cost-engine";

export interface ReturnActor {
  userId: number;
  companyId: number;
  warehouseIds: number[];
  ip?: string;
  userAgent?: string;
}

function fmt(n: Decimal | number): string {
  return new Intl.NumberFormat("ar-IQ", { maximumFractionDigits: 2 }).format(dec(n).toNumber());
}

export async function createSalesReturn(
  actor: ReturnActor,
  input: {
    invoiceId: number;
    cashboxId?: number | null;
    refundCash: number; // desired cash refund part
    notes?: string | null;
    lines: { invoiceLineId: number; qty: number; package_condition?: "SEALED" | "OPENED" | "DAMAGED" }[];
  }
) {
  const companyId = actor.companyId;
  if (!input.lines.length) {
    throw new ApiError("VAL_001", "المرتجع بدون بنود", [
      { field: "lines", message: "أضف بندًا واحدًا على الأقل" },
    ]);
  }

  const invoice = await db.salesInvoice.findFirst({
    where: { id: input.invoiceId, companyId, deletedAt: null },
    include: {
      customer: true,
      lines: { include: { product: { select: { id: true, name: true, unit: true, packUnit: true, packQty: true } } } },
    },
  });
  if (!invoice) throw new ApiError("VAL_003", "الفاتورة غير موجودة");
  if (invoice.status === "VOID") throw new ApiError("VAL_004", "لا مرتجع على فاتورة ملغاة");

  if (!actor.warehouseIds.includes(invoice.warehouseId)) throw new ApiError("SCOPE_002");
  const wh = await db.warehouse.findFirst({
    where: { id: invoice.warehouseId, companyId, deletedAt: null },
  });
  if (!wh) throw new ApiError("VAL_003", "مستودع الفاتورة غير موجود");

  // Previously returned qty per invoice line (R1)
  const prior = await db.salesReturnLine.findMany({
    where: { invoiceLineId: { in: invoice.lines.map((l) => l.id) }, returnDoc: { deletedAt: null } },
    select: { invoiceLineId: true, qty: true },
  });
  const priorMap = new Map<number, Decimal>();
  for (const p of prior) {
    if (p.invoiceLineId == null) continue;
    priorMap.set(p.invoiceLineId, (priorMap.get(p.invoiceLineId) ?? new Decimal(0)).plus(dec(p.qty)));
  }

  const lineMap = new Map(invoice.lines.map((l) => [l.id, l]));
  const computed = input.lines.map((l) => {
    const src = lineMap.get(l.invoiceLineId);
    if (!src) throw new ApiError("VAL_003", "بند المرتجع لا ينتمي لهذه الفاتورة");
    const already = priorMap.get(src.id) ?? new Decimal(0);
    const remaining = qtyR(dec(src.qty).minus(already));
    const qty = qtyR(dec(l.qty));
    if (!qty.isPositive()) throw new ApiError("VAL_001", "كمية المرتجع يجب أن تكون أكبر من صفر");
    if (qty.gt(remaining.plus(1e-9))) {
      throw new ApiError(
        "VAL_001",
        `كمية المرتجع تتجاوز المتبقي — ${src.product.name ?? `صنف #${src.productId}`}: مباع ${fmt(src.qty)}، مرتجع سابقًا ${fmt(already)}، المتبقي ${fmt(remaining)}`,
        [{ field: "qty", message: `الحد الأقصى ${fmt(remaining)}` }]
      );
    }
    return { src, qty, unitPrice: dec(src.unitPrice), lineTotal: moneyR(qty.mul(dec(src.unitPrice))) };
  });

  const total = moneyR(sumOf(computed, (l) => l.lineTotal));

  // Refund split (R2): cash part ≤ total; remainder = credit note
  const cash = moneyR(Decimal.min(Decimal.max(dec(input.refundCash ?? 0), 0), total));
  const credit = moneyR(total.minus(cash));

  if (cash.isPositive() && !input.cashboxId) {
    throw new ApiError("VAL_001", "اختر الصندوق لرد النقد", [
      { field: "cashbox_id", message: "رد نقدي يتطلب صندوقًا" },
    ]);
  }

  const customer = invoice.customer;

  const result = await db.$transaction(async (tx) => {
    const number = await nextDocumentNumber(tx, companyId, "RET");

    const created = await tx.salesReturn.create({
      data: {
        companyId,
        branchId: invoice.branchId,
        warehouseId: invoice.warehouseId,
        number,
        customerId: invoice.customerId,
        invoiceId: invoice.id,
        status: "POSTED",
        returnDate: new Date(),
        totalAmount: total,
        refundCash: cash,
        creditNote: credit,
        notes: input.notes ?? null,
        createdById: actor.userId,
      },
    });

    for (let i = 0; i < computed.length; i++) {
      const l = computed[i];
      await tx.salesReturnLine.create({
        data: {
          returnId: created.id,
          productId: l.src.productId,
          invoiceLineId: l.src.id,
          qty: l.qty,
          unitPrice: l.unitPrice,
          lineTotal: l.lineTotal,
        },
      });
      // ---- Phase 4 §7: تكلفة الإرجاع المحاسبية الصحيحة — البضاعة تعيد
      // دخول الطبقات بتكلفة صرفها الفعلية (من سجل استهلاك بند الفاتورة)
      const restored = await restoreLayersFromConsumptions({
        tx,
        companyId,
        warehouseId: invoice.warehouseId,
        productId: l.src.productId,
        sourceRefType: "SALES_INVOICE",
        sourceRefId: invoice.id,
        sourceRefLineId: l.src.id,
        qtyToRestore: l.qty,
        newSourceType: "SALES_RETURN",
        newSourceId: created.id,
        fallbackCost: l.src.unitCost,
        createdBy: actor.userId,
      });
      await applyStockMovement({
        tx,
        companyId,
        warehouseId: invoice.warehouseId,
        productId: l.src.productId,
        direction: "IN",
        qty: l.qty,
        unitCost: restored.layers.length ? restored.unitCost : l.src.unitCost,
        refType: "RETURN_IN",
        refId: created.id,
        note: `مرتجع ${number} على فاتورة ${invoice.number}`,
        userId: actor.userId,
      });
      // عودة الكمية إلى عبوة مناسبة (§29/§30): مغلقة كاملة / حبات لعبوة مفتوحة
      const info = packInfoOf(l.src.product);
      if (info.hasPack) {
        await restockToPackages(txOf(tx), {
          companyId,
          warehouseId: invoice.warehouseId,
          productId: l.src.productId,
          pieces: l.qty,
          info,
          condition: input.lines[i]?.package_condition ?? "OPENED",
          userId: actor.userId,
          refType: "SALES_RETURN",
          refId: created.id,
          refNumber: number,
        });
      }
    }

    // credit note → reduce receivable
    if (credit.isPositive()) {
      await tx.customer.update({
        where: { id: customer.id },
        data: { balance: { decrement: credit } },
      });
      // relief also reduces the invoice remaining due
      await tx.salesInvoice.update({
        where: { id: invoice.id },
        data: { paidAmount: { increment: credit } },
      });
    }

    // cash refund → cash ledger OUT
    if (cash.isPositive() && input.cashboxId) {
      const box = await tx.cashbox.findFirst({
        where: { id: input.cashboxId, companyId, deletedAt: null },
      });
      if (!box) throw new ApiError("VAL_003", "الصندوق غير موجود");
      const after = moneyR(dec(box.balance).minus(cash));
      if (after.isNegative()) {
        throw new ApiError(
          "VAL_001",
          `رصيد الصندوق لا يكفي لرد النقد — المتاح: ${fmt(box.balance)}`,
          [{ field: "refund_cash", message: "قلّل مبلغ الرد النقدي أو اشحن الصندوق" }]
        );
      }
      const number2 = await nextDocumentNumber(tx, companyId, "PAYMENT");
      await tx.cashTransaction.create({
        data: {
          companyId,
          cashboxId: box.id,
          direction: "OUT",
          category: "REFUND",
          amount: cash,
          balanceAfter: after,
          partyType: "CUSTOMER",
          customerId: customer.id,
          refType: "SALES_RETURN",
          refId: created.id,
          note: `رد نقدي مرتجع ${number}`,
          createdBy: actor.userId,
        },
      });
      await tx.cashbox.update({ where: { id: box.id }, data: { balance: after } });
    }

    return { created, number };
  });

  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CREATE",
      module: "sales",
      entityType: "sales_return",
      entityId: result.created.id,
      newValues: {
        number: result.number,
        invoice: invoice.number,
        customer: customer.name,
        total,
        credit_note: credit,
        refund_cash: cash,
        lines: computed.length,
      },
    }
  );

  // R10 — حدود الاستجابة: أرقام للواجهة كما كانت
  return {
    id: result.created.id,
    uuid: result.created.uuid,
    number: result.number,
    invoice: { id: invoice.id, number: invoice.number },
    total_amount: num(total),
    credit_note: num(credit),
    refund_cash: num(cash),
    customer: { id: customer.id, name: customer.name, balance_after: num(moneyR(dec(customer.balance).minus(credit))) },
  };
}
