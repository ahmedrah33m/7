// =====================================================================
// Uniform error envelope + the fixed error-code matrix (API spec §2.5).
// Every API response: { success, code, message, errors }
// Success responses:  { success: true, data, meta? }
// =====================================================================

export interface ErrorDef {
  http: number;
  ar: string;
  en: string;
}

/** The unified error-code matrix — shared by every module. */
export const ERROR_CODES = {
  // Auth & session
  AUTH_001: { http: 401, ar: "لم يتم إرسال رمز الدخول", en: "Missing access token" },
  AUTH_002: { http: 401, ar: "رمز الدخول غير صالح أو منتهي الصلاحية", en: "Invalid or expired access token" },
  AUTH_003: { http: 401, ar: "بيانات الدخول غير صحيحة", en: "Invalid credentials" },
  AUTH_004: { http: 423, ar: "الحساب مقفول مؤقتًا بسبب المحاولات الفاشلة المتكررة", en: "Account temporarily locked after failed attempts" },
  AUTH_005: { http: 403, ar: "الحساب معطل — راجع الإدارة", en: "Account disabled" },
  AUTH_006: { http: 401, ar: "رمز التحديث غير صالح أو مستهلك مسبقًا", en: "Invalid or already-used refresh token" },
  AUTH_007: { http: 401, ar: "انتهت صلاحية الجلسة — يلزم إعادة الدخول", en: "Refresh token expired, re-login required" },
  // Permissions & scope
  PERM_001: { http: 403, ar: "ليست لديك الصلاحية اللازمة لهذه العملية", en: "Insufficient permission for this action" },
  PERM_002: { http: 403, ar: "صلاحيات دور المالك (OWNER) محمية ولا يمكن تعديلها — حماية من قفل النظام", en: "The OWNER role permissions are protected and cannot be edited — self-lockout guard" },
  SCOPE_001: { http: 403, ar: "هذا الكيان خارج نطاقك (فرع/مستودع)", en: "Entity outside your branch/warehouse scope" },
  SCOPE_002: { http: 403, ar: "لا تملك نفاذًا لهذا المستودع", en: "No access to this warehouse" },
  SCOPE_003: { http: 403, ar: "خرق نطاق الفرع — هذا السجل خارج الفرع النشط في جلستك", en: "Branch scope violation — record outside your active branch" },
  SCOPE_004: { http: 403, ar: "خرق نطاق الشركة — هذه البيانات تخص شركة أخرى", en: "Company scope violation — data belongs to another company" },
  // Walk-In customer rules (MASTER PROMPT Phase 21)
  WALK_001: { http: 409, ar: "لا يمكن تسجيل بيع آجل لزبون متردد. يرجى اختيار عميل مسجل أو إنشاء حساب عميل.", en: "Credit sale is not allowed for walk-in customers — pick a registered customer or create one" },
  WALK_002: { http: 409, ar: "هذا النوع من العملاء يُنشأ تلقائيًا من النظام — لا يمكن إنشاؤه يدويًا", en: "This customer type is system-managed and cannot be created manually" },
  WALK_003: { http: 409, ar: "التحويل متاح فقط للزبون المتردد/النقدي/غير المعروف", en: "Conversion applies only to walk-in / cash / guest customers" },
  WALK_004: { http: 422, ar: "الاسم إلزامي لتحويل الزبون المتردد إلى عميل مسجل", en: "Name is required to convert a walk-in into a registered customer" },
  SCOPE_005: { http: 403, ar: "لا تملك نفاذًا لهذا الفرع", en: "No access to this branch" },
  AUTH_008: { http: 403, ar: "الفرع أو الشركة المطلوبة خارج نطاق المستخدم", en: "Requested branch/company outside the user's scope" },
  // Multi-Tenant org structure (MASTER PROMPT §48/§71): the referenced
  // entity EXISTS but belongs to a DIFFERENT company — explicit rejection.
  SCOPE_006: { http: 403, ar: "مرجع عابر للشركات — هذا السجل يتبع شركة أخرى ولا يمكن استخدامه هنا", en: "Cross-company reference — the record belongs to another company" },
  // Validation
  VAL_001: { http: 422, ar: "بيانات الطلب غير صالحة", en: "Invalid request payload" },
  VAL_002: { http: 409, ar: "قيمة مكررة — السجل موجود مسبقًا", en: "Duplicate value — record already exists" },
  VAL_003: { http: 404, ar: "السجل غير موجود", en: "Record not found" },
  VAL_004: { http: 409, ar: "لا يمكن تنفيذ العملية على سجل مقفل أو معتمد", en: "Operation not allowed on posted/locked record" },
  // Stock / business (reserved codes for later phases)
  STOCK_001: { http: 409, ar: "الكمية المتوفرة غير كافية", en: "Insufficient stock" },
  CREDIT_001: { http: 409, ar: "تجاوز حد الائتمان — العملية مرفوضة", en: "Credit limit exceeded — blocked" },
  CREDIT_002: { http: 202, ar: "تجاوز حد الائتمان — أُحيلت للموافقة", en: "Credit limit exceeded — routed to approval" },
  // Completion phase — stocktake / quotation / delivery / branches
  STK_001: { http: 409, ar: "أمر الجرد مُرحّل مسبقًا", en: "Stocktake already posted" },
  STK_002: { http: 409, ar: "لا يمكن تعديل أو ترحيل جرد ملغى", en: "Cancelled stocktake cannot be modified" },
  QTN_001: { http: 409, ar: "عرض السعر محوَّل لفاتورة مسبقًا", en: "Quotation already converted" },
  QTN_002: { http: 409, ar: "انتقال حالة غير مسموح لعرض السعر", en: "Invalid quotation status transition" },
  QTN_003: { http: 422, ar: "عرض السعر بدون بنود", en: "Quotation has no lines" },
  DLV_001: { http: 409, ar: "إشعار التسليم مسلَّم مسبقًا", en: "Delivery note already delivered" },
  DLV_002: { http: 409, ar: "إشعار التسليم ملغى", en: "Delivery note cancelled" },
  // Phase 5 — محرك التسليم الجزئي
  DLV_003: { http: 422, ar: "over-delivery ممنوع — الكمية المسلَّمة تتجاوز المطلوبة", en: "Over-delivery forbidden — delivered exceeds ordered" },
  DLV_004: { http: 409, ar: "انتقال حالة غير مسموح لإشعار التسليم", en: "Invalid delivery note status transition" },
  BRN_001: { http: 409, ar: "الفرع مرتبط بسجلات نشطة — لا يمكن الحذف", en: "Branch has active records — cannot delete" },
  // Products
  PRD_001: { http: 409, ar: "لا يمكن حذف المنتج — لديه مخزون أو سجلات نشطة", en: "Product cannot be deleted — has stock or active records" },
  // Phase 2 — packaging & pricing validation (§3): تُفرض في الخادم دائماً
  PRD_002: { http: 422, ar: "عدد الوحدات في العبوة يجب أن يكون أكبر من 1", en: "Units per package must be greater than 1" },
  PRD_003: { http: 422, ar: "وحدة التعبئة يجب أن تختلف عن الوحدة الأساسية للمنتج", en: "Package unit must differ from the base unit" },
  PRD_004: { http: 422, ar: "سعر العبوة يتطلب تحديد وحدة التعبئة أولًا", en: "Package price requires a package unit" },
  PRD_005: { http: 422, ar: "وحدة التعبئة تتطلب عدد الوحدات في العبوة", en: "Package unit requires units per package" },
  PRD_006: { http: 422, ar: "سعر الصرف مطلوب للأسعار بالدولار", en: "Exchange rate is required for USD prices" },
  // Warehouses
  WH_001: { http: 409, ar: "لا يمكن حذف المستودع — رئيسي أو يحتوي مخزونًا", en: "Warehouse cannot be deleted — MAIN type or holds stock" },
  // Company subscription (لوحة المالك — إدارة مدة كل شركة)
  SUB_001: { http: 423, ar: "انتهت مدة اشتراك الشركة — راجع مالك النظام للتجديد", en: "Company subscription expired — contact the system owner to renew" },
  SUB_002: { http: 423, ar: "الشركة معلّقة مؤقتًا — راجع مالك النظام", en: "Company suspended — contact the system owner" },
  // Rate limit & server
  RATE_001: { http: 429, ar: "عدد طلبات كبير جدًا — أعد المحاولة لاحقًا", en: "Too many requests — slow down" },
  SYNC_001: { http: 200, ar: "عملية مكررة — أُعيدت نتيجتها الأصلية", en: "Duplicate operation — original result returned" },
  SRV_001: { http: 500, ar: "خطأ داخلي غير متوقع", en: "Unexpected internal error" },
  SRV_002: { http: 503, ar: "الخدمة غير متاحة مؤقتًا", en: "Service temporarily unavailable" },
  // ---- Advanced finance (cashbox-service) -------------------------------
  CASHBOX_001: { http: 404, ar: "الصندوق غير موجود", en: "Cashbox not found" },
  CASHBOX_002: { http: 409, ar: "الصندوق مغلق — لا يمكن إجراء عمليات عليه", en: "Cashbox is closed — operations are blocked" },
  CASHBOX_003: { http: 409, ar: "الصندوق معطل مؤقتًا", en: "Cashbox is suspended" },
  CASHBOX_004: { http: 422, ar: "رصيد الصندوق لا يكفي لإتمام العملية", en: "Insufficient cashbox balance" },
  CASHBOX_005: { http: 422, ar: "لا يمكن تحويل من صندوق إلى نفسه", en: "Cannot transfer to the same cashbox" },
  CASHBOX_006: { http: 403, ar: "الصندوق خارج نطاق فرعك النشط", en: "Cashbox outside your active branch scope" },
  RECEIPT_001: { http: 422, ar: "مبلغ القبض يجب أن يكون أكبر من صفر", en: "Receipt amount must be positive" },
  RECEIPT_002: { http: 409, ar: "وصل القبض ملغى مسبقًا", en: "Receipt voucher is already cancelled" },
  RECEIPT_003: { http: 422, ar: "سبب الإلغاء مطلوب", en: "Cancel reason is required" },
  PV_001: { http: 422, ar: "مبلغ السداد يجب أن يكون أكبر من صفر", en: "Payment voucher amount must be positive" },
  PV_002: { http: 409, ar: "وصل الصرف ملغى مسبقًا", en: "Payment voucher is already cancelled" },
  PV_003: { http: 422, ar: "بيان الصرف مطلوب", en: "Payment voucher reason is required" },
  CASH_001: { http: 422, ar: "عملية idempotency مكررة — نتيجة العملية الأصلية معادة", en: "Duplicate idempotent operation" },
  CASH_002: { http: 422, ar: "الحركة المراد عكسها ملغاة أو معكوسة مسبقًا", en: "Cash transaction already reversed or cancelled" },
  PAYMENT_001: { http: 422, ar: "تخصيص الدفعة يتجاوز المبلغ الكلي", en: "Allocation exceeds payment total" },
  PAYMENT_002: { http: 409, ar: "الدفعة ملغاة — لا يمكن تخصيصها", en: "Payment is cancelled — cannot allocate" },
  PAYMENT_003: { http: 404, ar: "الدفعة غير موجودة", en: "Payment not found" },
  CASH_TRF_001: { http: 422, ar: "مبلغ التحويل يجب أن يكون أكبر من صفر", en: "Transfer amount must be positive" },
  CASH_TRF_002: { http: 409, ar: "التحويل ملغى مسبقًا", en: "Cash transfer is already cancelled" },
  CLOSING_001: { http: 409, ar: "إغلاق الصندوق مغلق مسبقًا", en: "Cashbox closing is already closed" },
  CLOSING_002: { http: 409, ar: "لا يمكن إعادة فتح إغلاق ما زال DRAFT", en: "Cannot reopen a DRAFT closing" },
  FINANCE_001: { http: 422, ar: "القيد غير متوازن — مجموع المدين يجب أن يساوي الدائن", en: "Unbalanced journal entry — debit must equal credit" },
} as const;

export type ErrorCode = keyof typeof ERROR_CODES;

export interface FieldIssue {
  field: string;
  message: string;
}

/** Build the uniform error response body. */
export function errorBody(code: ErrorCode, message?: string, errors?: FieldIssue[]) {
  const def = ERROR_CODES[code];
  return {
    success: false as const,
    code,
    message: message ?? def.ar,
    errors: errors ?? [],
  };
}

export function httpStatusFor(code: ErrorCode): number {
  return ERROR_CODES[code].http;
}
