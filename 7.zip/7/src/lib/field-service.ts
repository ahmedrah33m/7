// =====================================================================
// Field-sales service (Phase 4 — MASTER PROMPT §6 Phase 4):
//   · Commission engine — 4 rule types, UNIQUE(invoice, rule) makes
//     double commission structurally impossible (exit criterion).
//   · Rep targets (monthly) + achievement tracking (TIER_BY_TARGET).
//   · Visits with GPS capture — state machine PLANNED → CHECKED_IN →
//     COMPLETED | CANCELLED (VAL_004 on illegal transitions).
//   · Distribution routes with ordered customers.
//
// Rep isolation (exit criterion): a session holding the SALES_REP role
// is pinned to repId = self for reads and writes — passing another
// rep's id is ignored, and listVisits returns only own rows.
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { writeAudit } from "./audit";
import { Decimal, dec, moneyR, qtyR, num } from "./decimal";

export type FieldActor = {
  userId: number;
  companyId: number;
  warehouseIds: number[];
  ip?: string;
  userAgent?: string;
};

export const COMMISSION_RULE_TYPES = [
  "PERCENT_OF_SALES",
  "PER_UNIT",
  "FIXED_PER_INVOICE",
  "TIER_BY_TARGET",
] as const;
export type CommissionRuleType = (typeof COMMISSION_RULE_TYPES)[number];

export const VISIT_OUTCOMES = ["ORDERED", "NO_ORDER", "COLLECTION", "POSTPONED"] as const;
export type VisitOutcome = (typeof VISIT_OUTCOMES)[number];

/** Tier multipliers for TIER_BY_TARGET (achievement of the monthly target). */
export const TIERS = [
  { min: 100, mult: 1.5, label: "تجاوز الهدف" },
  { min: 80, mult: 1.0, label: "قرب الهدف" },
  { min: 50, mult: 0.75, label: "نصف الهدف" },
  { min: 0, mult: 0.25, label: "أقل من النصف" },
] as const;

export function periodOf(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

/** Does this user hold the SALES_REP role? (rep isolation trigger) */
export async function isSalesRep(userId: number): Promise<boolean> {
  const count = await db.userRole.count({
    where: { userId, role: { code: "SALES_REP", deletedAt: null } },
  });
  return count > 0;
}

/** Resolve the effective rep id for an actor (rep → self, manager → chosen). */
export async function resolveRepId(actor: FieldActor, requestedRepId?: number | null): Promise<number> {
  if (await isSalesRep(actor.userId)) return actor.userId; // isolation: force self
  if (requestedRepId) {
    const rep = await db.user.findFirst({
      where: { id: requestedRepId, companyId: actor.companyId, deletedAt: null },
      select: { id: true },
    });
    if (!rep) throw new ApiError("VAL_003", "المندوب غير موجود");
    return rep.id;
  }
  throw new ApiError("VAL_001", "حدد المندوب المطلوب");
}

// ---------------------------------------------------------------------
// Commission engine
// ---------------------------------------------------------------------

export interface CommissionContext {
  invoiceId: number;
  repId: number;
  grandTotal: Decimal | number;
  totalQty: Decimal | number;
  invoiceDate: Date;
}

/**
 * Generate commission rows for a posted invoice — called by
 * sales-service AFTER the posting transaction commits. Idempotent:
 * UNIQUE(company_id, invoice_id, rule_id) + pre-check ⇒ re-running
 * the same invoice never duplicates a commission.
 */
export async function generateCommissionsForInvoice(ctx: CommissionContext): Promise<number> {
  try {
    // Commissions belong to field reps only — invoices posted by
    // managers/cashiers never generate a commission row.
    if (!(await isSalesRep(ctx.repId))) return 0;

    // RP6 — العدل عبر الشركات: قواعد العمولة تُقرأ من شركة المندوب فقط.
    // (سابقاً: بلا فلتر company_id — فتتولد عمولات بقواعد شركات أخرى — علة موثقة)
    const repCompanyId = (await db.user.findUnique({ where: { id: ctx.repId }, select: { companyId: true } }))!.companyId;
    const rules = await db.commissionRule.findMany({
      where: { companyId: repCompanyId, deletedAt: null, isActive: true },
      orderBy: { id: "asc" },
    });

    const period = periodOf(ctx.invoiceDate);
    const target = await db.repTarget.findFirst({
      where: { repId: ctx.repId, period, deletedAt: null },
    });

    // Month-to-date sales of this rep (for tier achievement)
    const monthStart = new Date(ctx.invoiceDate.getFullYear(), ctx.invoiceDate.getMonth(), 1);
    const agg = await db.salesInvoice.aggregate({
      where: {
        companyId: repCompanyId,
        createdById: ctx.repId,
        status: "POSTED",
        deletedAt: null,
        invoiceDate: { gte: monthStart, lte: ctx.invoiceDate },
      },
      _sum: { grandTotal: true },
    });
    const monthSales = moneyR(dec(agg._sum.grandTotal));

    let created = 0;
    // Phase 3 — سياسة العمولة R7 (./decimal.ts):
    //   PERCENT_OF_SALES = moneyR(الأساس × النسبة ÷ 100) · PER_UNIT = moneyR(Σكمية × سعر الوحدة)
    //   TIER_BY_TARGET = moneyR(الأساس × النسبة × مضاعف الفئة ÷ 100)
    for (const rule of rules) {
      if (dec(ctx.grandTotal).lt(rule.minInvoiceTotal)) continue;

      let amount = new Decimal(0);
      switch (rule.ruleType) {
        case "PERCENT_OF_SALES":
          amount = moneyR(dec(ctx.grandTotal).mul(rule.rate).div(100));
          break;
        case "PER_UNIT":
          amount = moneyR(dec(ctx.totalQty).mul(rule.perUnitRate));
          break;
        case "FIXED_PER_INVOICE":
          amount = moneyR(dec(rule.amount));
          break;
        case "TIER_BY_TARGET": {
          if (!target || !dec(target.targetAmount).isPositive()) continue; // no target → no tier
          const achievement = monthSales.div(target.targetAmount).mul(100);
          const tier = TIERS.find((t) => achievement.gte(t.min)) ?? TIERS[TIERS.length - 1];
          amount = moneyR(dec(ctx.grandTotal).mul(rule.rate).mul(tier.mult).div(100));
          break;
        }
        default:
          continue;
      }
      if (!amount.isPositive()) continue;

      const exists = await db.commission.findFirst({
        where: { invoiceId: ctx.invoiceId, ruleId: rule.id },
        select: { id: true },
      });
      if (exists) continue; // uniqueness guard (belt over the DB constraint)
      await db.commission.create({
        data: {
          companyId: rule.companyId,
          ruleId: rule.id,
          ruleType: rule.ruleType,
          repId: ctx.repId,
          invoiceId: ctx.invoiceId,
          period,
          baseAmount: moneyR(dec(ctx.grandTotal)),
          totalQty: qtyR(dec(ctx.totalQty)),
          amount,
        },
      });
      created += 1;
    }
    return created;
  } catch (err) {
    // Never break the invoice flow because of commission generation —
    // missing rows can be back-filled; a broken invoice cannot.
    console.error("[commission] generation failed:", err);
    return 0;
  }
}

export async function listCommissions(companyId: number, opts: { repId?: number; status?: string; period?: string }) {
  return db.commission.findMany({
    where: {
      companyId,
      ...(opts.repId ? { repId: opts.repId } : {}),
      ...(opts.status ? { status: opts.status } : {}),
      ...(opts.period ? { period: opts.period } : {}),
    },
    include: {
      rep: { select: { id: true, fullName: true, username: true } },
      rule: { select: { name: true, ruleType: true } },
      invoice: { select: { id: true, number: true, grandTotal: true, invoiceDate: true } },
    },
    orderBy: { id: "desc" },
    take: 100,
  });
}

export async function decideCommission(
  actor: FieldActor,
  id: number,
  decision: "approve" | "pay"
) {
  const row = await db.commission.findFirst({
    where: { id, companyId: actor.companyId },
  });
  if (!row) throw new ApiError("VAL_003", "العمولة غير موجودة");
  if (decision === "approve") {
    if (row.status !== "PENDING") throw new ApiError("VAL_004", "تُعتمد العمولة من حالة «معلّقة» فقط");
  } else {
    if (row.status !== "APPROVED") throw new ApiError("VAL_004", "الصرف يتطلب اعتمادًا مسبقًا");
  }
  const updated = await db.commission.update({
    where: { id: row.id },
    data:
      decision === "approve"
        ? { status: "APPROVED", approvedById: actor.userId, approvedAt: new Date() }
        : { status: "PAID", paidAt: new Date() },
  });
  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: decision === "approve" ? "APPROVE" : "POST",
      module: "field",
      entityType: "commission",
      entityId: row.id,
      newValues: { status: updated.status, amount: row.amount, repId: row.repId },
    }
  );
  return updated;
}

// ---------------------------------------------------------------------
// Targets
// ---------------------------------------------------------------------

export async function setTarget(
  actor: FieldActor,
  input: { repId: number; period: string; targetAmount: number; notes?: string | null; warehouseId?: number | null }
) {
  const repId = await resolveRepId(actor, input.repId);
  if (!/^\d{4}-\d{2}$/.test(input.period)) throw new ApiError("VAL_001", "صيغة الفترة YYYY-MM");
  if (input.targetAmount <= 0) throw new ApiError("VAL_001", "قيمة الهدف يجب أن تكون أكبر من صفر");

  const existing = await db.repTarget.findFirst({
    where: { companyId: actor.companyId, repId, period: input.period, deletedAt: null },
  });
  const row = existing
    ? await db.repTarget.update({
        where: { id: existing.id },
        data: { targetAmount: input.targetAmount, notes: input.notes ?? null },
      })
    : await db.repTarget.create({
        data: {
          companyId: actor.companyId,
          repId,
          period: input.period,
          targetAmount: input.targetAmount,
          notes: input.notes ?? null,
          warehouseId: input.warehouseId ?? null,
          createdBy: actor.userId,
        },
      });
  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: existing ? "UPDATE" : "CREATE",
      module: "field",
      entityType: "rep_target",
      entityId: row.id,
      newValues: { repId, period: input.period, targetAmount: input.targetAmount },
    }
  );
  return row;
}

export interface RepPerformance {
  repId: number;
  repName: string;
  username: string;
  sales: number;
  invoicesCount: number;
  target: number | null;
  achievementPct: number | null;
  commissionsPending: number;
  commissionsApproved: number;
  commissionsPaid: number;
  visitsThisMonth: number;
}

/** Per-rep monthly performance — the field dashboard backbone. */
export async function repPerformance(companyId: number, period: string, repId?: number): Promise<RepPerformance[]> {
  const [year, month] = period.split("-").map(Number);
  const monthStart = new Date(year, month - 1, 1);
  const monthEnd = new Date(year, month, 1);

  const reps = await db.user.findMany({
    where: {
      companyId,
      deletedAt: null,
      isActive: true,
      roles: { some: { role: { code: "SALES_REP", deletedAt: null } } },
      ...(repId ? { id: repId } : {}),
    },
    select: { id: true, fullName: true, username: true },
    orderBy: { id: "asc" },
  });

  const out: RepPerformance[] = [];
  for (const rep of reps) {
    const [invAgg, target, commAgg, visitCount] = await Promise.all([
      db.salesInvoice.aggregate({
        where: { companyId, createdById: rep.id, status: "POSTED", deletedAt: null, invoiceDate: { gte: monthStart, lt: monthEnd } },
        _sum: { grandTotal: true },
        _count: true,
      }),
      db.repTarget.findFirst({ where: { companyId, repId: rep.id, period, deletedAt: null } }),
      db.commission.groupBy({
        by: ["status"],
        where: { companyId, repId: rep.id, period },
        _sum: { amount: true },
      }),
      db.visit.count({
        where: { companyId, repId: rep.id, deletedAt: null, plannedDate: { gte: monthStart, lt: monthEnd } },
      }),
    ]);

    const sales = num(moneyR(dec(invAgg._sum.grandTotal)));
    const targetAmount = target == null ? null : num(dec(target.targetAmount));
    const byStatus = new Map(commAgg.map((c) => [c.status, num(moneyR(dec(c._sum.amount)))]));
    out.push({
      repId: rep.id,
      repName: rep.fullName,
      username: rep.username,
      sales,
      invoicesCount: invAgg._count,
      target: targetAmount,
      achievementPct: targetAmount ? num(moneyR(dec(sales).div(targetAmount).mul(100))) : null,
      commissionsPending: byStatus.get("PENDING") ?? 0,
      commissionsApproved: byStatus.get("APPROVED") ?? 0,
      commissionsPaid: byStatus.get("PAID") ?? 0,
      visitsThisMonth: visitCount,
    });
  }
  return out;
}

// ---------------------------------------------------------------------
// Visits (GPS)
// ---------------------------------------------------------------------

export async function planVisit(
  actor: FieldActor,
  input: { customerId: number; plannedDate: string; repId?: number | null; routeId?: number | null; notes?: string | null }
) {
  const repId = await resolveRepId(actor, input.repId);
  const customer = await db.customer.findFirst({
    where: { id: input.customerId, companyId: actor.companyId, deletedAt: null },
  });
  if (!customer) throw new ApiError("VAL_003", "العميل غير موجود");
  const plannedDate = new Date(input.plannedDate);
  if (Number.isNaN(plannedDate.getTime())) throw new ApiError("VAL_001", "تاريخ الزيارة غير صالح");
  if (input.routeId) {
    const route = await db.route.findFirst({ where: { id: input.routeId, companyId: actor.companyId, deletedAt: null } });
    if (!route) throw new ApiError("VAL_003", "المسار غير موجود");
  }

  const visit = await db.visit.create({
    data: {
      companyId: actor.companyId,
      repId,
      customerId: customer.id,
      routeId: input.routeId ?? null,
      plannedDate,
      notes: input.notes ?? null,
      createdById: actor.userId,
    },
    include: { customer: { select: { name: true, code: true } }, rep: { select: { fullName: true } } },
  });
  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CREATE",
      module: "field",
      entityType: "visit",
      entityId: visit.id,
      newValues: { customer: customer.name, plannedDate: input.plannedDate, repId },
    }
  );
  return visit;
}

async function getVisitForActor(actor: FieldActor, id: number) {
  const visit = await db.visit.findFirst({
    where: { id, companyId: actor.companyId, deletedAt: null },
  });
  if (!visit) throw new ApiError("VAL_003", "الزيارة غير موجودة");
  // Rep isolation — a rep may only touch his own visits.
  if (await isSalesRep(actor.userId)) {
    if (visit.repId !== actor.userId) throw new ApiError("SCOPE_001", "هذه الزيارة ليست ضمن زياراتك");
  }
  return visit;
}

export async function checkinVisit(actor: FieldActor, id: number, gps: { lat: number; lng: number }) {
  const visit = await getVisitForActor(actor, id);
  if (visit.status !== "PLANNED") {
    throw new ApiError("VAL_004", `تسجيل الحضور متاح للزيارات «مخططة» فقط — الحالة الحالية: ${visit.status}`);
  }
  const lat = Number(gps.lat);
  const lng = Number(gps.lng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
    throw new ApiError("VAL_001", "إحداثيات GPS غير صالحة", [
      { field: "lat", message: "خط العرض بين -90 و 90" },
      { field: "lng", message: "خط الطول بين -180 و 180" },
    ]);
  }
  const updated = await db.visit.update({
    where: { id: visit.id },
    data: { status: "CHECKED_IN", checkinAt: new Date(), checkinLat: lat, checkinLng: lng },
  });
  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "UPDATE",
      module: "field",
      entityType: "visit",
      entityId: visit.id,
      newValues: { status: "CHECKED_IN", lat, lng },
    }
  );
  return updated;
}

export async function completeVisit(
  actor: FieldActor,
  id: number,
  input: { outcome: VisitOutcome; orderValue?: number; notes?: string | null }
) {
  const visit = await getVisitForActor(actor, id);
  if (visit.status !== "CHECKED_IN") {
    throw new ApiError("VAL_004", "إتمام الزيارة يتطلب تسجيل حضور (CHECKED_IN) أولًا");
  }
  if (!VISIT_OUTCOMES.includes(input.outcome)) throw new ApiError("VAL_001", "نتيجة الزيارة غير صالحة");
  const updated = await db.visit.update({
    where: { id: visit.id },
    data: {
      status: "COMPLETED",
      checkoutAt: new Date(),
      outcome: input.outcome,
      orderValue: num(moneyR(dec(input.orderValue ?? 0))),
      notes: input.notes ?? visit.notes,
    },
  });
  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "UPDATE",
      module: "field",
      entityType: "visit",
      entityId: visit.id,
      newValues: { status: "COMPLETED", outcome: input.outcome, orderValue: updated.orderValue },
    }
  );
  return updated;
}

export async function cancelVisit(actor: FieldActor, id: number, reason?: string | null) {
  const visit = await getVisitForActor(actor, id);
  if (visit.status === "COMPLETED" || visit.status === "CANCELLED") {
    throw new ApiError("VAL_004", `لا يمكن إلغاء زيارة ${visit.status === "COMPLETED" ? "منتهية" : "ملغاة أصلًا"}`);
  }
  const updated = await db.visit.update({
    where: { id: visit.id },
    data: { status: "CANCELLED", notes: reason ?? visit.notes },
  });
  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    { action: "CANCEL", module: "field", entityType: "visit", entityId: visit.id, newValues: { status: "CANCELLED" } }
  );
  return updated;
}

export async function listVisits(
  actor: FieldActor,
  opts: { status?: string; repId?: number; from?: string; to?: string }
) {
  // Rep isolation — rep sees ONLY his own visits.
  const forcedRepId = (await isSalesRep(actor.userId)) ? actor.userId : opts.repId;
  return db.visit.findMany({
    where: {
      companyId: actor.companyId,
      deletedAt: null,
      ...(forcedRepId ? { repId: forcedRepId } : {}),
      ...(opts.status ? { status: opts.status } : {}),
    },
    include: {
      customer: { select: { id: true, name: true, code: true } },
      rep: { select: { id: true, fullName: true } },
      route: { select: { id: true, name: true } },
    },
    orderBy: [{ plannedDate: "desc" }, { id: "desc" }],
    take: 150,
  });
}

// ---------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------

export async function createRoute(
  actor: FieldActor,
  input: { name: string; repId?: number | null; dayOfWeek?: number | null; customerIds?: number[] }
) {
  const repId = input.repId ? (await resolveRepId(actor, input.repId)) : null;
  if (input.dayOfWeek != null && (input.dayOfWeek < 0 || input.dayOfWeek > 6)) {
    throw new ApiError("VAL_001", "يوم الأسبوع بين 0 (الأحد) و 6 (السبت)");
  }
  const count = await db.route.count({ where: { companyId: actor.companyId } });
  const route = await db.route.create({
    data: {
      companyId: actor.companyId,
      code: `RT-${String(count + 1).padStart(4, "0")}`,
      name: input.name,
      repId,
      dayOfWeek: input.dayOfWeek ?? null,
      createdBy: actor.userId,
    },
  });
  const ids = [...new Set(input.customerIds ?? [])];
  if (ids.length) {
    const valid = await db.customer.findMany({
      where: { id: { in: ids }, companyId: actor.companyId, deletedAt: null },
      select: { id: true },
    });
    await db.routeCustomer.createMany({
      data: valid.map((c, i) => ({ routeId: route.id, customerId: c.id, seq: i + 1 })),
    });
  }
  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CREATE",
      module: "field",
      entityType: "route",
      entityId: route.id,
      newValues: { code: route.code, name: route.name, customers: ids.length },
    }
  );
  return route;
}

export async function listRoutes(companyId: number) {
  return db.route.findMany({
    where: { companyId, deletedAt: null },
    include: {
      rep: { select: { id: true, fullName: true } },
      customers: {
        orderBy: { seq: "asc" },
        include: { customer: { select: { id: true, code: true, name: true, balance: true } } },
      },
      _count: { select: { visits: true } },
    },
    orderBy: { id: "asc" },
  });
}
