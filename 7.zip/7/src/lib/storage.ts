// =====================================================================
// Storage service (§69 — الملفات والصور gap closure).
// Local-disk driver under db/uploads/ with a driver interface ready for
// an S3/Object-Storage swap in production (the app never assumes local
// paths outside this module). Files are stored under unguessable UUID
// names, served publicly via /api/v1/files/<name> — same trust model as
// presigned object URLs; writes always go through permissioned routes.
//
// Safety:
//   · MIME whitelist (images + pdf) — no HTML/SVG (XSS via content-type).
//   · Size cap 5MB.
//   · Name pattern enforced on read → no path traversal possible.
//   · Magic-byte sniffing overrides client-declared content type.
// =====================================================================

import { promises as fs } from "fs";
import path from "path";
import crypto from "crypto";

export const UPLOAD_DIR = path.join(process.cwd(), "db", "uploads");
export const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;

export const ALLOWED_MIME: Record<string, string> = {
  "image/png": ".png",
  "image/jpeg": ".jpg",
  "image/webp": ".webp",
  "image/gif": ".gif",
  "application/pdf": ".pdf",
};

export interface StoredFile {
  name: string;
  url: string;
  mime: string;
  size: number;
}

export interface StorageDriver {
  save(data: Buffer, mime: string): Promise<StoredFile>;
  read(name: string): Promise<{ data: Buffer; mime: string } | null>;
}

// ---- magic-byte sniffing (trust the bytes, not the header) -----------
function sniffMime(buf: Buffer): string | null {
  if (buf.length < 12) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return "image/png";
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "image/jpeg";
  if (buf.slice(0, 4).toString("ascii") === "RIFF" && buf.slice(8, 12).toString("ascii") === "WEBP") return "image/webp";
  if (buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46) return "image/gif";
  if (buf.slice(0, 5).toString("ascii") === "%PDF-") return "application/pdf";
  return null;
}

const EXT_TO_MIME: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  webp: "image/webp",
  gif: "image/gif",
  pdf: "application/pdf",
};

const LOCAL: StorageDriver = {
  async save(data, mime) {
    const ext = ALLOWED_MIME[mime];
    if (!ext) throw new Error(`unsupported mime: ${mime}`);
    await fs.mkdir(UPLOAD_DIR, { recursive: true });
    const name = `${crypto.randomUUID()}${ext}`;
    await fs.writeFile(path.join(UPLOAD_DIR, name), data);
    return { name, url: `/api/v1/files/${name}`, mime, size: data.length };
  },
  async read(name) {
    // standard UUID (8-4-4-4-12) + whitelisted extension — blocks traversal
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.(png|jpg|webp|gif|pdf)$/i.test(name)) {
      return null;
    }
    try {
      const data = await fs.readFile(path.join(UPLOAD_DIR, name));
      const mime = EXT_TO_MIME[path.extname(name).slice(1).toLowerCase()] ?? "application/octet-stream";
      return { data, mime };
    } catch {
      return null;
    }
  },
};

/** Active driver — swap for S3Driver in production without touching routes. */
export const storage: StorageDriver = LOCAL;

/** Validate + persist an upload buffer. Throws Error with Arabic message on violation. */
export async function saveUpload(data: Buffer, declaredMime: string): Promise<StoredFile> {
  if (data.length === 0) throw new Error("الملف فارغ");
  if (data.length > MAX_UPLOAD_BYTES) throw new Error("حجم الملف يتجاوز 5 ميجابايت");
  const mime = sniffMime(data) ?? declaredMime;
  if (!ALLOWED_MIME[mime]) throw new Error("نوع الملف غير مسموح — الصور (png/jpg/webp/gif) و PDF فقط");
  return storage.save(data, mime);
}
