// =====================================================================
// Sales service — SMART INVOICE (إضافة متقدمة §1-§47):
//   ONE transaction = numbering + stock OUT per line + package
//   consumption + packaging ledger + invoice + lines (with balance
//   snapshot & packaging split) + customer balance (CREDIT) + credit
//   guard. Nothing is left half-written.
//
// Business rules enforced:
//   R1  negative stock blocked (unless company policy allows)
//   R2  credit guard: previous + invoice − payment = new balance vs
//       credit limit → BLOCK (CREDIT_001) or APPROVAL flow (CREDIT_002)
//       per company policy `credit_guard` in company.settingsJson
//   R3  sequential numbering INV-{YEAR}-{SEQ} via document_sequences
//   R4  every posting writes an audit row (after commit)
//   R5  golden rule §45: packages are whole cartons + pieces, never
//       fractional cartons — physical state from `packages` rows
//   R6  every number on the invoice ties to the ledger (§47):
//       previous/new balance ← customers.balance snapshot,
//       packaging ← packaging_ledger, stock before/after ← line snapshot
// =====================================================================

import { db } from "./db";
import { ApiError } from "./api";
import { nextDocumentNumber, DOC_TYPES } from "./document-number";
import { applyStockMovement } from "./inventory";
import { writeAudit } from "./audit";
import { Decimal, dec, moneyR, qtyR, pctR, sumOf, num } from "./decimal";
import { generateCommissionsForInvoice } from "./field-service";
// v14 — إلغاء نظام نقاط الولاء (طلب المالك): حُذف استيراد محرك الكسب —
// الحركات التاريخية في loyalty_transactions تبقى للقراءة والتدقيق فقط.
// Web Crypto العالمي — متاح في Node 19+ و edge والمتصفح (webpack لا يستطيع تجميع node:crypto في instrumentation)
import {
  packInfoOf, ensurePackageCoverage, consumeFromPackages, restockToPackages, packSplit,
  type PackageEvent, type PackagePolicy, txOf,
} from "./packaging";
import { assertWalkInPaymentAllowed, isWalkInType } from "./walkin";
import { entityExistsOutsideCompany } from "./scope";
// Phase 4 — محرك طبقات التكلفة (FIFO/WAVG/STANDARD/LAST + لقطة COGS §6)
import { consumeCost, restoreLayersFromConsumptions, getCompanyCostMethod, type CostMethod } from "./cost-engine";
// Phase 2 §4-§8 — التسعير المهيكلة + لقطة الفاتورة
import { getEffectivePrices, legacyFallbackWarn, type EffectivePrice } from "./product-pricing";
import { getCompanyUsdRate, toIqd, moneyOf, asCurrency, type Currency } from "./currency";

// ---------------------------------------------------------------------
// Invoice-level settings (footer text editable from settings §41)
// ---------------------------------------------------------------------
export interface InvoiceSettings {
  footerText: string;
  showMiniStatement: boolean;
  packagingDetailsDefault: boolean;
  openPackagePolicy: PackagePolicy;
}

export async function getInvoiceSettings(companyId: number): Promise<InvoiceSettings> {
  const keys = [
    "invoice.footer_text",
    "invoice.show_mini_statement",
    "invoice.packaging_details_default",
    "invoice.open_package_policy",
  ];
  const rows = await db.setting.findMany({ where: { companyId, key: { in: keys } } });
  const map = new Map(rows.map((r) => [r.key, r.value]));
  const parse = <T,>(k: string, dflt: T): T => {
    const raw = map.get(k);
    if (raw == null) return dflt;
    try { return JSON.parse(raw) as T; } catch { return dflt; }
  };
  return {
    footerText: parse<string>(
      "invoice.footer_text",
      "البضاعة المباعة لا تستبدل إلا حسب سياسة الشركة.\nشكراً لتعاملكم معنا."
    ),
    showMiniStatement: parse<boolean>("invoice.show_mini_statement", true),
    packagingDetailsDefault: parse<boolean>("invoice.packaging_details_default", true),
    openPackagePolicy: parse<PackagePolicy>("invoice.open_package_policy", "OPEN_FIRST"),
  };
}

export async function getCreditPolicy(companyId: number): Promise<"BLOCK" | "APPROVAL"> {
  const company = await db.company.findUnique({ where: { id: companyId }, select: { settingsJson: true } });
  try {
    const cfg = JSON.parse(company?.settingsJson ?? "{}") as { credit_guard?: string };
    return cfg.credit_guard === "APPROVAL" ? "APPROVAL" : "BLOCK";
  } catch {
    return "BLOCK";
  }
}

// ---------------------------------------------------------------------
// Cashbox integration (Phase 31): the PAID part of every posted invoice
// flows into the branch cashbox as a PAYMENT document (direction IN,
// refType SALES_INVOICE). Resolve the branch default cashbox (first
// active one in the invoice's branch, else the company's first active).
// ---------------------------------------------------------------------
type TxClient = Parameters<Parameters<typeof db.$transaction>[0]>[0];

export async function postInvoiceCashInTx(
  tx: TxClient,
  args: {
    companyId: number;
    branchId: number;
    amount: Decimal | number;
    invoiceId: number;
    invoiceNumber: string;
    customerId: number;
    customerName: string;
    userId: number;
  }
) {
  const box =
    (await tx.cashbox.findFirst({
      where: { companyId: args.companyId, branchId: args.branchId, isActive: true, deletedAt: null },
      orderBy: { id: "asc" },
    })) ??
    (await tx.cashbox.findFirst({
      where: { companyId: args.companyId, isActive: true, deletedAt: null },
      orderBy: { id: "asc" },
    }));
  if (!box) return null; // no cashbox configured — invoice stays valid, cash tracked on customer

  const amount = moneyR(dec(args.amount));
  const balanceBefore = dec(box.balance);
  const after = moneyR(balanceBefore.plus(amount));

  // ---- Advanced finance integration (cashbox-service) ---------------------
  // Build the unified Payment + PaymentAllocation + ReceiptVoucher + the
  // advanced CashTransaction (with transactionNumber + balanceBefore +
  // receiptId/paymentId/invoiceId links) so the cashbox dashboard sees
  // the same audit trail as a manual receipt. The legacy balance-mirror
  // customer/supplier balance is intentionally NOT touched here (the
  // invoice post itself already moved customer.balance for CREDIT — the
  // CASH paid part is the cashbox intake only).
  const paymentNumber = await nextDocumentNumber(tx, args.companyId, "UNIFIED_PAYMENT");
  const payment = await tx.payment.create({
    data: {
      companyId: args.companyId,
      branchId: args.branchId,
      number: paymentNumber,
      paymentType: "RECEIPT",
      partyType: "CUSTOMER",
      customerId: args.customerId,
      cashboxId: box.id,
      totalAmount: amount,
      currency: "IQD",
      paymentMethod: "CASH",
      paymentDate: new Date(),
      status: "POSTED",
      cashAmount: amount,
      description: `تحصيل فاتورة ${args.invoiceNumber} — ${args.customerName}`,
      createdById: args.userId,
    },
  });

  // Payment allocation for this invoice (single invoice receipt)
  await tx.paymentAllocation.create({
    data: {
      companyId: args.companyId,
      paymentId: payment.id,
      invoiceType: "SALES",
      salesInvoiceId: args.invoiceId,
      allocatedAmount: amount,
      invoiceNumber: args.invoiceNumber,
      createdAt: new Date(),
    },
  });

  // ReceiptVoucher with snapshot
  const rcptNumber = await nextDocumentNumber(tx, args.companyId, "RCPT");
  const verifyToken = crypto.randomUUID();
  const invoiceSnapshot = JSON.stringify([{
    invoiceId: args.invoiceId,
    invoiceType: "SALES",
    invoiceNumber: args.invoiceNumber,
    currentPayment: num(amount),
  }]);
  const qrData = JSON.stringify({
    voucher: rcptNumber, payment: paymentNumber, amount: num(amount),
    party: args.customerName, date: new Date().toISOString(), verifyToken,
  });
  const receipt = await tx.receiptVoucher.create({
    data: {
      companyId: args.companyId,
      branchId: args.branchId,
      number: rcptNumber,
      receiptDate: new Date(),
      cashboxId: box.id,
      recipientName: args.customerName,
      customerId: args.customerId,
      amount,
      currency: "IQD",
      amountInCashbox: amount,
      paymentMethod: "CASH",
      paymentId: payment.id,
      invoiceSnapshot,
      currentPaymentSnapshot: amount,
      status: "POSTED",
      verifyToken,
      qrData,
      receivedBy: args.customerName,
      createdById: args.userId,
    },
  });

  // Advanced CashTransaction (mirrors the legacy row below but carries
  // the full audit metadata: balanceBefore, transactionNumber, links)
  await tx.cashTransaction.create({
    data: {
      companyId: args.companyId,
      cashboxId: box.id,
      direction: "IN",
      category: "COLLECTION",
      amount,
      balanceAfter: after,
      balanceBefore,
      partyType: "CUSTOMER",
      customerId: args.customerId,
      // SALES_INVOICE_CASH = cashbox mirror of the invoice's paid part.
      // NOT a customer-ledger movement (balance untouched) — statements
      // must exclude it to avoid double-counting with the PAYMENT row.
      refType: "SALES_INVOICE_CASH",
      refId: args.invoiceId,
      transactionType: "RECEIPT",
      transactionNumber: rcptNumber,
      invoiceId: args.invoiceId,
      paymentId: payment.id,
      receiptId: receipt.id,
      note: `تحصيل فاتورة ${args.invoiceNumber} — ${args.customerName}`,
      createdBy: args.userId,
    },
  });
  await tx.cashbox.update({ where: { id: box.id }, data: { balance: after } });
  return { cashboxId: box.id, after, paymentId: payment.id, receiptId: receipt.id };
}

/** Cash OUT counterpart used when voiding a posted invoice (refund to customer). */
export async function postInvoiceCashOutTx(
  tx: TxClient,
  args: {
    companyId: number;
    branchId: number;
    amount: Decimal | number;
    invoiceId: number;
    invoiceNumber: string;
    customerId: number;
    userId: number;
  }
) {
  const box =
    (await tx.cashbox.findFirst({
      where: { companyId: args.companyId, branchId: args.branchId, isActive: true, deletedAt: null },
      orderBy: { id: "asc" },
    })) ??
    (await tx.cashbox.findFirst({
      where: { companyId: args.companyId, isActive: true, deletedAt: null },
      orderBy: { id: "asc" },
    }));
  if (!box) return null;

  const after = moneyR(dec(box.balance).minus(args.amount));
  if (after.isNegative()) return null; // empty box — refund recorded as credit note only
  const number = await nextDocumentNumber(tx, args.companyId, "PAYMENT");
  await tx.cashTransaction.create({
    data: {
      companyId: args.companyId,
      cashboxId: box.id,
      direction: "OUT",
      category: "REFUND",
      amount: moneyR(dec(args.amount)),
      balanceAfter: after,
      partyType: "CUSTOMER",
      customerId: args.customerId,
      refType: "SALES_INVOICE_VOID",
      refId: args.invoiceId,
      note: `استرداد نقدي لإلغاء فاتورة ${args.invoiceNumber}`,
      createdBy: args.userId,
    },
  });
  await tx.cashbox.update({ where: { id: box.id }, data: { balance: after } });
  return { cashboxId: box.id, after };
}

// ---------------------------------------------------------------------
// Input & computed types
// ---------------------------------------------------------------------
export interface InvoiceLineInput {
  productId: number;
  qty?: number;            // base pieces (legacy shape — still supported)
  package_qty?: number;    // full packages (1 كرتونة)
  loose_qty?: number;      // loose pieces (3 حبات)
  unit?: "PIECE" | "PACKAGE"; // what qty refers to when the split fields are absent
  unit_price?: number | null;
  price_unit?: "PIECE" | "PACKAGE"; // what unit_price refers to (default PIECE)
  package_price?: number | null; // سعر الكرتونة الصريح — يتجاوز unit_price (§19)
  piece_price?: number | null;   // سعر الحبة الصريح — يتجاوز unit_price
  discount_pct?: number | null;
  discount_amount?: number | null;
}

export interface CreateInvoiceInput {
  customerId: number;
  warehouseId: number;
  type: "CASH" | "CREDIT";
  saleType?: "CASH" | "CREDIT" | "PARTIAL" | "SWAP" | "RETURN";
  paymentMethod?: "CASH" | "CARD" | "TRANSFER" | "CHEQUE";
  dueDate?: string | null;      // ISO
  repId?: number | null;
  packagingDetails?: boolean;
  receiverName?: string | null;
  receiverPhone?: string | null;
  repNotes?: string | null;
  customerNotes?: string | null;
  adminNotes?: string | null;
  notes?: string | null;
  paidAmount?: number | null; // CREDIT partial payment
  // ---- Walk-In optional info (Phase 23 — never blocks the fast cash sale)
  walkin_name?: string | null;
  walkin_phone?: string | null;
  walkin_address?: string | null;
  // ---- Dual currency (IQD base ledger + USD invoices) -------------------
  currencyCode?: "IQD" | "USD"; // عملة إصدار الفاتورة للعميل — المبالغ المخزنة تبقى بالدينار
  exchangeRate?: number | null; // د.ع لكل $1 — إلزامي حين العملة USD
  // ---- إدخال قائمة قديمة بنفس رقمها المطبوع (تجهيز بعد التجربة) ----------
  // رقم مخصص بدل الترقيم التلقائي — يُفحص تعارضه داخل الشركة، ويُقدّم عداد
  // التسلسل تلقائيًا إن كان الرقم بصيغة النظام وأكبر من العداد الحالي.
  customNumber?: string | null;
  /** السماح بالصرف رغم نقص المخزون لهذه الفاتورة (STOCK_001 override — يُدوَّن في التدقيق) */
  allowNegativeStock?: boolean;
  lines: InvoiceLineInput[];
}

export interface InvoiceActor {
  userId: number;
  companyId: number;
  warehouseIds: number[]; // session warehouse scope
  ip?: string;
  userAgent?: string;
}

/** §48 — audit trail for every rejected cross-company reference attempt. */
async function auditCrossCompanyReference(
  actor: InvoiceActor,
  entityType: string,
  entityId: number
): Promise<void> {
  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "ACCESS_DENIED",
      module: "sales",
      entityType,
      entityId,
      newValues: { reason: "CROSS_COMPANY_REFERENCE", attempted_company_id: actor.companyId },
    }
  );
}

interface ComputedLine {
  product: {
    id: number; name: string; unit: string; salePrice: Decimal; costPrice: Decimal;
    taxRatePct: Decimal; packUnit: string | null; packQty: Decimal | null; packSalePrice: Decimal | null;
  };
  info: ReturnType<typeof packInfoOf>;
  baseQty: Decimal;
  orderedQty: Decimal;
  packageQty: Decimal;
  looseQty: Decimal;
  packageType: string | null;
  packageConversion: Decimal;
  packagePrice: Decimal | null;
  piecePrice: Decimal;
  unitCost: Decimal;
  discountPct: Decimal;
  discountAmount: Decimal;
  taxAmount: Decimal;
  lineTotal: Decimal;
  // ---- Phase 2 §8 — لقطة مصدر السعر (عملة السعر كما خُزّنت على المنتج) ----
  priceCurrency: Currency;
  priceExchangeRate: Decimal | number | null;
  costCurrency: Currency;
}

function fmt(n: Decimal | number): string {
  return new Intl.NumberFormat("ar-IQ", { maximumFractionDigits: 2 }).format(dec(n).toNumber());
}

const SALE_TYPE_LABEL: Record<string, string> = {
  CASH: "نقدي", CREDIT: "آجل", PARTIAL: "جزئي", SWAP: "استبدال", RETURN: "مرتجع",
};

// ---------------------------------------------------------------------
// Create invoice
// ---------------------------------------------------------------------
export async function createSalesInvoice(actor: InvoiceActor, input: CreateInvoiceInput) {
  const companyId = actor.companyId; // chain step 3 — never from body

  if (!input.lines.length) {
    throw new ApiError("VAL_001", "الفاتورة بدون بنود", [
      { field: "lines", message: "أضف بندًا واحدًا على الأقل" },
    ]);
  }

  // ---- Dual currency guard: كل المبالغ تُخزّن بالدينار (عملة الأساس)؛
  // فاتورة الدولار تُوثّق سعر الصرف لحظة الإصدار — بلا سعر صرف صحيح لا تُرحّل.
  const currencyCode = input.currencyCode ?? "IQD";
  let exchangeRate: number | null = null;
  if (currencyCode === "USD") {
    const r = Number(input.exchangeRate);
    if (!Number.isFinite(r) || r <= 0) {
      throw new ApiError("VAL_001", "سعر الصرف مطلوب لفاتورة الدولار", [
        { field: "exchange_rate", message: "حدد سعر الصرف (د.ع لكل $1) — مثال: 1300" },
      ]);
    }
    exchangeRate = r;
  }

  const customer = await db.customer.findFirst({
    where: { id: input.customerId, companyId, deletedAt: null },
  });
  if (!customer && (await entityExistsOutsideCompany("customer", input.customerId))) {
    // §48 CROSS_COMPANY_REFERENCE — the customer exists but in another tenant
    await auditCrossCompanyReference(actor, "customer", input.customerId);
    throw new ApiError("SCOPE_006");
  }
  if (!customer) throw new ApiError("VAL_003", "العميل غير موجود");
  if (!customer.isActive) throw new ApiError("VAL_001", "العميل معطل — لا يمكن البيع له");
  // Customer status gate (§2): BLOCKED → no sales · CREDIT_HOLD → cash only
  if (customer.status === "BLOCKED") {
    throw new ApiError("VAL_001", `العميل «${customer.name}» موقوف — لا يمكن البيع له، راجع الإدارة`);
  }
  if (customer.status === "CREDIT_HOLD" && input.type === "CREDIT") {
    throw new ApiError("VAL_001", `العميل «${customer.name}» تحت حجز ائتماني — البيع النقدي فقط`);
  }
  // ---- Walk-In credit restriction (Phase 21) — cash-only customer types --
  await assertWalkInPaymentAllowed(customer.customerType, input.type, {
    userId: actor.userId,
    companyId,
    ip: actor.ip,
    userAgent: actor.userAgent,
    customerId: customer.id,
  });

  if (!input.warehouseId) {
    throw new ApiError("VAL_001", "حدد المستودع المطلوب البيع منه", [
      { field: "warehouse_id", message: "المستودع مطلوب" },
    ]);
  }
  if (!actor.warehouseIds.includes(input.warehouseId)) {
    throw new ApiError("SCOPE_002");
  }
  const wh = await db.warehouse.findFirst({
    where: { id: input.warehouseId, companyId, deletedAt: null, isActive: true },
    include: { branch: { select: { id: true } } },
  });
  if (!wh && (await entityExistsOutsideCompany("warehouse", input.warehouseId))) {
    // §48 — selling from another company's warehouse is explicitly rejected
    await auditCrossCompanyReference(actor, "warehouse", input.warehouseId);
    throw new ApiError("SCOPE_006");
  }
  if (!wh) throw new ApiError("VAL_003", "المستودع غير موجود");

  // Rep (المندوب المسؤول §1/§34) — defaults to the creator
  let repId: number | null = null;
  if (input.repId != null) {
    const rep = await db.user.findFirst({
      where: { id: input.repId, companyId, deletedAt: null, isActive: true },
      select: { id: true, fullName: true },
    });
    if (!rep && (await entityExistsOutsideCompany("user", input.repId))) {
      // §50 — a rep of another company can never appear on this invoice
      await auditCrossCompanyReference(actor, "user", input.repId);
      throw new ApiError("SCOPE_006");
    }
    if (!rep) throw new ApiError("VAL_003", "المندوب المحدد غير موجود");
    repId = rep.id;
  } else {
    repId = actor.userId;
  }

  const productIds = [...new Set(input.lines.map((l) => l.productId))];
  const products = await db.product.findMany({
    where: { id: { in: productIds }, companyId, deletedAt: null },
  });
  const pmap = new Map(products.map((p) => [p.id, p]));
  // §51 — every line product must belong to this company; if an id exists
  // in another company → explicit cross-company rejection (first match).
  for (const pid of productIds) {
    if (!pmap.has(pid) && (await entityExistsOutsideCompany("product", pid))) {
      await auditCrossCompanyReference(actor, "product", pid);
      throw new ApiError("SCOPE_006");
    }
  }

  const policy = await getCreditPolicy(companyId);
  const settings = await getInvoiceSettings(companyId);

  // ---- Phase 2 §5: الأسعار الافتراضية من الطبقة المهيكلة (عملة كل سعر
  // كما خُزّنت) — أسعار الدولار تُحوَّل بالسعر المعروف فقط، ولا تخمين أبداً.
  const effMap = await getEffectivePrices(companyId, productIds);
  const companyRate = await getCompanyUsdRate(companyId);

  // ---- normalize + compute lines (money math outside the tx) ----------
  // Phase 3: كل الحساب المالي هنا Decimal — سياسة R1-R10 في ./decimal.ts
  const computed: ComputedLine[] = input.lines.map((l) => {
    const p = pmap.get(l.productId);
    if (!p) throw new ApiError("VAL_003", `المنتج #${l.productId} غير موجود`);
    if (!p.isActive) throw new ApiError("VAL_001", `المنتج «${p.name}» معطّل`);
    const info = packInfoOf(p);

    // quantity resolution: explicit split (package_qty+loose_qty) > unit-qty > base qty
    let packageQty = new Decimal(0), looseQty = new Decimal(0), baseQty = new Decimal(0), orderedQty = new Decimal(0);
    const hasSplit = l.package_qty != null || l.loose_qty != null;
    if (hasSplit) {
      packageQty = qtyR(dec(l.package_qty ?? 0)).abs();
      looseQty = qtyR(dec(l.loose_qty ?? 0)).abs();
      if (!packageQty.plus(looseQty).isPositive()) {
        throw new ApiError("VAL_001", `كمية البند «${p.name}» يجب أن تكون أكبر من صفر`);
      }
      baseQty = qtyR(packageQty.mul(info.packQty).plus(looseQty));
      orderedQty = baseQty;
    } else {
      const q = dec(l.qty ?? 0);
      if (!q.isPositive()) throw new ApiError("VAL_001", `كمية البند «${p.name}» يجب أن تكون أكبر من صفر`);
      orderedQty = qtyR(q);
      if (l.unit === "PACKAGE") {
        if (!info.hasPack) throw new ApiError("VAL_001", `المنتج «${p.name}» لا يُباع بالعبوة — الوحدة الأساسية ${p.unit}`);
        packageQty = qtyR(q); looseQty = new Decimal(0); baseQty = qtyR(q.mul(info.packQty));
      } else {
        baseQty = qtyR(q);
        const split = info.hasPack
          ? packSplit(q, info.packQty)
          : { packages: 0, loose: num(qtyR(q)) };
        packageQty = new Decimal(split.packages); looseQty = qtyR(split.loose);
      }
    }

    // ---- Phase 2: الافتراضيات من الطبقة المهيكلة (§4-§6) ------------------
    const effRows: EffectivePrice[] = effMap.get(p.id) ?? [];
    const salePiece = effRows.find((r) => r.priceType === "SALE" && r.unit === "PIECE");
    const salePack = effRows.find((r) => r.priceType === "SALE" && r.unit === "PACKAGE");
    const costRow = effRows.find((r) => r.priceType === "COST" && r.unit === "PIECE");
    const productSourceCurrency: Currency = salePiece?.currency ?? salePack?.currency ?? "IQD";

    // سعر التحويل: فاتورة دولار → سعر فاتورتها؛ فاتورة دينار → سعر الشركة.
    // بلا سعر معروف ومنتج مسعّر بالدولار → رفض صريح (PRD_006) بلا تخمين.
    let priceRate: number | null = null;
    if (productSourceCurrency === "USD") {
      priceRate = currencyCode === "USD" ? exchangeRate : companyRate;
      if (!priceRate || priceRate <= 0) {
        throw new ApiError(
          "PRD_006",
          `سعر «${p.name}» مخزّن بالدولار — حدد سعر الصرف (د.ع لكل $1) في إعدادات الشركة قبل البيع بفاتورة دينار`,
          [{ field: "exchange_rate", message: "أضف سعر الصرف أو غيّر عملة الفاتورة إلى USD" }]
        );
      }
    }
    const defPieceIqd = salePiece
      ? toIqd(salePiece.amount, salePiece.currency, priceRate ?? 1)
      : (legacyFallbackWarn("invoice", companyId, p.id, p.name), moneyOf(dec(p.salePrice)));
    const defPackIqd =
      info.hasPack && packageQty.isPositive()
        ? salePack && dec(salePack.amount).gt(0)
          ? toIqd(salePack.amount, salePack.currency, priceRate ?? 1)
          : p.packSalePrice != null && dec(p.packSalePrice).gt(0)
            ? (legacyFallbackWarn("invoice:package", companyId, p.id, p.name), moneyOf(dec(p.packSalePrice)))
            : moneyOf(defPieceIqd.mul(info.packQty)) // سعر الكرتونة غائب/صفر → اشتقاق من سعر الحبة
        : null;

    // لقطة مصدر السعر (§8): سعر يدوي → بعملة الفاتورة؛ افتراضي → عملة المنتج
    let priceCurrency: Currency = "IQD";
    let priceExchangeRate: number | null = null;
    if (l.unit_price != null || l.package_price != null || l.piece_price != null) {
      if (currencyCode === "USD") { priceCurrency = "USD"; priceExchangeRate = exchangeRate; }
    } else if (productSourceCurrency === "USD") {
      priceCurrency = "USD";
      priceExchangeRate = priceRate;
    }

    // price resolution (§18/§19): كرتون وحبات معًا بسعرين مستقلين.
    // الأولوية: package_price/piece_price الصريحان → unit_price حسب أساسه → الافتراضي.
    const priceUnit = l.price_unit ?? (l.unit === "PACKAGE" ? "PACKAGE" : "PIECE");
    let piecePrice: Decimal, packagePrice: Decimal | null = null;
    if (info.hasPack && packageQty.isPositive()) {
      packagePrice = l.package_price != null
        ? moneyOf(dec(l.package_price))
        : priceUnit === "PACKAGE"
          ? moneyOf(l.unit_price ?? defPackIqd ?? moneyOf(moneyOf(info.packQty).mul(defPieceIqd)))
          : moneyOf(defPackIqd ?? moneyOf(moneyOf(info.packQty).mul(l.unit_price ?? defPieceIqd)));
      piecePrice = l.piece_price != null
        ? moneyOf(dec(l.piece_price))
        : priceUnit === "PIECE" && l.unit_price != null
          ? moneyOf(dec(l.unit_price))
          : defPieceIqd;
    } else {
      piecePrice = l.piece_price != null
        ? moneyOf(dec(l.piece_price))
        : moneyOf(l.unit_price ?? defPieceIqd);
    }
    if (piecePrice.isNegative() || (packagePrice?.isNegative() ?? false)) {
      throw new ApiError("VAL_001", `سعر سالب للمنتج «${p.name}»`);
    }

    const gross = moneyR(packageQty.mul(packagePrice ?? 0).plus(looseQty.mul(piecePrice)));
    const discountPct = pctR(Decimal.min(Decimal.max(dec(l.discount_pct ?? 0), 0), 100));
    const discountAmount = moneyR(Decimal.max(dec(l.discount_amount ?? 0), 0));
    let lineTotal = moneyR(gross.mul(new Decimal(1).minus(discountPct.div(100))).minus(discountAmount));
    if (lineTotal.isNegative()) lineTotal = new Decimal(0);
    const taxAmount = moneyR(lineTotal.mul(p.taxRatePct.div(100)));
    // cost snapshot (§8): من الطبقة المهيكلة بعملتها → إسقاط ديناري للربح
    let unitCost = moneyOf(dec(p.costPrice));
    let costCurrency: Currency = "IQD";
    if (costRow && costRow.currency === "USD" && (priceRate ?? companyRate)) {
      unitCost = toIqd(costRow.amount, "USD", (priceRate ?? companyRate) as number);
      costCurrency = "USD";
    }

    return {
      product: {
        id: p.id, name: p.name, unit: p.unit, salePrice: dec(p.salePrice), costPrice: dec(p.costPrice),
        taxRatePct: dec(p.taxRatePct), packUnit: p.packUnit, packQty: p.packQty, packSalePrice: p.packSalePrice,
      },
      info,
      baseQty, orderedQty, packageQty, looseQty,
      packageType: info.hasPack && packageQty.isPositive() ? info.packageType : null,
      packageConversion: qtyR(dec(info.packQty)),
      packagePrice: info.hasPack && packageQty.isPositive() ? packagePrice : null,
      piecePrice, unitCost, discountPct, discountAmount, taxAmount, lineTotal,
      priceCurrency, priceExchangeRate, costCurrency,
    };
  });

  const subtotal = moneyR(sumOf(computed, (l) => l.packageQty.mul(l.packagePrice ?? 0).plus(l.looseQty.mul(l.piecePrice))));
  const discountTotal = moneyR(subtotal.minus(sumOf(computed, (l) => l.lineTotal)));
  const taxTotal = moneyR(sumOf(computed, (l) => l.taxAmount));
  const grandTotal = moneyR(subtotal.minus(discountTotal).plus(taxTotal));

  // sale type (§1): نقدي/آجل/جزئي/استبدال — RETURN lives in the returns module
  let saleType = input.saleType ?? (input.type === "CASH" ? "CASH" : "CREDIT");
  if (saleType === "SWAP") {
    // استبدال: معاملة مالية نقدية بقيمة متفق عليها
    input = { ...input, type: "CASH" };
  }
  if (input.type === "CREDIT" && dec(input.paidAmount).isPositive()) saleType = "PARTIAL";

  const paid =
    input.type === "CASH"
      ? grandTotal
      : moneyR(Decimal.min(Decimal.max(dec(input.paidAmount ?? 0), 0), grandTotal));
  const due = moneyR(grandTotal.minus(paid));

  // ---- balance snapshot BEFORE any write (§3/§4) -----------------------
  const previousBalance = moneyR(dec(customer.balance));
  const projectedBalance = moneyR(previousBalance.plus(due));

  // ---- credit guard (R2/§6) ---------------------------------------------
  let pendingApproval = false;
  const creditTypes = input.type === "CREDIT";
  if (creditTypes && dec(customer.creditLimit).isPositive() && projectedBalance.gt(customer.creditLimit)) {
    if (policy === "BLOCK") {
      throw new ApiError(
        "CREDIT_001",
        `سيؤدي اعتماد هذه الفاتورة إلى تجاوز الحد الائتماني للعميل — الحد: ${fmt(customer.creditLimit)}، الرصيد السابق: ${fmt(previousBalance)}، الرصيد الجديد المتوقع: ${fmt(projectedBalance)}`,
        [{ field: "credit_limit", message: "قلّل المبلغ أو حوّل الفاتورة إلى نقدية أو زد حد العميل أو فعّل سياسة الموافقة" }]
      );
    }
    pendingApproval = true; // APPROVAL policy → حُفظت بانتظار موافقة المدير
  }

  // due date (تاريخ الاستحقاق §1): explicit > customer credit days
  let dueDate: Date | null = null;
  if (input.dueDate) {
    dueDate = new Date(input.dueDate);
    if (Number.isNaN(dueDate.getTime())) dueDate = null;
  } else if (input.type === "CREDIT" && customer.creditDays > 0) {
    dueDate = new Date(Date.now() + customer.creditDays * 86_400_000);
  }

  // ---- ONE atomic transaction -------------------------------------------
  const loyaltyEarned = 0; // v14 — إلغاء نقاط الولاء: لا كسب نقاط
  // Phase 4: طريقة التكلفة المعتمدة للشركة (لقطة على الفاتورة §6)
  const costMethod = await getCompanyCostMethod(companyId);
  const invoice = await db.$transaction(async (tx) => {
    // ---- الترقيم: مخصص (قائمة قديمة بنفس رقمها) أو تلقائي --------------
    let number: string;
    const customNo = input.customNumber?.trim();
    if (customNo) {
      // تعارض مع فاتورة حيّة (POSTED/PENDING) في نفس الشركة؟ المرتجعة/الموحّفة لا تحجب الرقم
      const dup = await tx.salesInvoice.findFirst({
        where: { companyId, number: customNo, deletedAt: null, status: { in: ["POSTED", "PENDING_APPROVAL"] } },
        select: { id: true, status: true },
      });
      if (dup) {
        throw new ApiError("VAL_002", `رقم القائمة «${customNo}» مستخدم مسبقًا في هذه الشركة`, [
          { field: "custom_number", message: "لِمْ (Void) القائمة القديمة أولًا أو اختر رقمًا آخرًا" },
        ]);
      }
      number = customNo;
      // إن طابق الرقم صيغة النظام (INV-2026-000123) نُقدّم العداد حتى لا يتولّد
      // لاحقًا رقم تلقائي مكرر — لا نُنقص العداد أبدًا.
      const m = customNo.match(/^([A-Za-z]+)-(\d{4})-(\d+)$/);
      if (m && m[1].toUpperCase() === DOC_TYPES.INVOICE.prefix) {
        const year = Number(m[2]);
        const seq = BigInt(m[3]);
        const row = await tx.documentSequence.findUnique({
          where: { companyId_docType_year: { companyId, docType: "INVOICE", year } },
        });
        if (!row || row.currentNumber < seq) {
          await tx.documentSequence.upsert({
            where: { companyId_docType_year: { companyId, docType: "INVOICE", year } },
            create: { companyId, docType: "INVOICE", prefix: DOC_TYPES.INVOICE.prefix, year, currentNumber: seq, padding: 6 },
            update: { currentNumber: seq },
          });
        }
      }
    } else {
      number = await nextDocumentNumber(tx, companyId, "INVOICE");
    }

    const created = await tx.salesInvoice.create({
      data: {
        companyId,
        branchId: wh.branch.id,
        warehouseId: wh.id,
        number,
        customerId: customer.id,
        type: input.type,
        saleType,
        status: pendingApproval ? "PENDING_APPROVAL" : "POSTED",
        invoiceDate: new Date(),
        dueDate,
        subtotal,
        discountTotal,
        taxTotal,
        grandTotal,
        paidAmount: paid,
        paymentMethod: input.paymentMethod ?? "CASH",
        previousBalance,
        newBalance: projectedBalance,
        creditLimitSnap: customer.creditLimit,
        creditExceeded: pendingApproval,
        stockApplied: !pendingApproval,
        negativeStockAllowed: input.allowNegativeStock ?? false,
        repId,
        packagingDetails: input.packagingDetails ?? settings.packagingDetailsDefault,
        verifyToken: globalThis.crypto.randomUUID(),
        receiverName: input.receiverName ?? null,
        receiverPhone: input.receiverPhone ?? null,
        repNotes: input.repNotes ?? null,
        customerNotes: input.customerNotes ?? null,
        adminNotes: input.adminNotes ?? null,
        notes: input.notes ?? null,
        customerType: customer.customerType, // لقطة نوع العميل (§24/§25/§30)
        walkinName: input.walkin_name ?? null,
        walkinPhone: input.walkin_phone ?? null,
        walkinAddress: input.walkin_address ?? null,
        currencyCode,
        exchangeRate,
        createdById: actor.userId,
      },
    });

    if (pendingApproval) {
      // PENDING invoices keep their lines (no stock effects yet) so the
      // approver sees exactly what will be deducted on approval.
      for (const l of computed) {
        await tx.salesInvoiceLine.create({
          data: {
            invoiceId: created.id,
            productId: l.product.id,
            qty: l.baseQty,
            orderedQty: l.orderedQty,
            packageQty: l.packageQty,
            looseQty: l.looseQty,
            packageType: l.packageType,
            packageConversion: l.packageConversion,
            packagePrice: l.packagePrice,
            unitPrice: l.piecePrice,
            unitCost: l.unitCost,
            discountPct: l.discountPct,
            discountAmount: l.discountAmount,
            taxAmount: l.taxAmount,
            lineTotal: l.lineTotal,
            // ---- Phase 2 §8: لقطة مصدر السعر والوحدات لحظة البيع ----------
            priceCurrency: l.priceCurrency,
            priceExchangeRate: l.priceExchangeRate,
            costCurrency: l.costCurrency,
            baseUnitLabel: l.product.unit,
            packageUnitLabel: l.info.hasPack ? l.product.packUnit : null,
          },
        });
      }
    }

    if (!pendingApproval) {
      await applyInvoiceEffects(tx, {
        invoice: created,
        computed,
        companyId,
        warehouseId: wh.id,
        number,
        userId: actor.userId,
        policy: settings.openPackagePolicy,
        method: costMethod,
        allowNegativeStock: input.allowNegativeStock ?? false,
      });

      if (due.isPositive()) {
        await tx.customer.update({
          where: { id: customer.id },
          data: { balance: { increment: due } },
        });
      }

      // ---- Cashbox integration (Phase 31): Invoice → Payment → Cashbox ---
      // Every posted invoice's PAID amount must land in the branch cashbox
      // (walk-in cash sales included). No cash-only-sales-without-cashbox.
      if (paid.isPositive()) {
        await postInvoiceCashInTx(tx, {
          companyId,
          branchId: wh.branch.id,
          amount: paid,
          invoiceId: created.id,
          invoiceNumber: number,
          customerId: customer.id,
          customerName: customer.name,
          userId: actor.userId,
        });
      }

      // v14 — تم إلغاء نظام نقاط الولاء بالكامل (طلب المالك):
      // لم تعد الفواتير تُكسب نقاطاً — الحركات التاريخية محفوظة للقراءة فقط.
    }

    return created;
  });

  // ---- audit (non-transactional, after commit) -------------------------
  await writeAudit(
    { userId: actor.userId, companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: pendingApproval ? "SUBMIT" : "CREATE",
      module: "sales",
      entityType: "sales_invoice",
      entityId: invoice.id,
      newValues: {
        number: invoice.number,
        customer: customer.name,
        type: input.type,
        sale_type: saleType,
        sale_type_label: SALE_TYPE_LABEL[saleType] ?? saleType,
        grandTotal: invoice.grandTotal,
        previous_balance: previousBalance,
        new_balance: projectedBalance,
        status: invoice.status,
        lines: computed.length,
        ...(input.allowNegativeStock ? { negative_stock: true } : {}),
        ...(pendingApproval ? { credit_exceeded: true, policy } : {}),
      },
    }
  );

  // ---- Phase 4: commission engine (posted rep-invoices only) -----------
  if (!pendingApproval) {
    await generateCommissionsForInvoice({
      invoiceId: invoice.id,
      repId: repId ?? actor.userId,
      grandTotal: invoice.grandTotal,
      totalQty: sumOf(computed, (l) => l.baseQty),
      invoiceDate: invoice.invoiceDate,
    });
  }

  return {
    id: invoice.id,
    uuid: invoice.uuid,
    number: invoice.number,
    type: invoice.type,
    sale_type: saleType,
    status: invoice.status,
    requires_approval: pendingApproval,
    // ---- Dual currency snapshot ------------------------------------------
    currency_code: currencyCode,
    exchange_rate: exchangeRate,
    subtotal: num(subtotal),
    discount_total: num(discountTotal),
    tax_total: num(taxTotal),
    grand_total: num(grandTotal),
    paid_amount: num(paid),
    due_amount: num(due),
    previous_balance: num(previousBalance),
    new_balance: num(projectedBalance),
    credit_limit: num(dec(customer.creditLimit)),
    available_credit: num(moneyR(Decimal.max(new Decimal(0), dec(customer.creditLimit).minus(projectedBalance)))),
    points_earned: loyaltyEarned,
    points_potential: 0, // v14 — إلغاء نقاط الولاء: الصفر دائمًا (حقل متوافق مع الواجهات القديمة)
    customer: { id: customer.id, name: customer.name, balance_after: num(projectedBalance) },
    due_date: dueDate?.toISOString() ?? null,
    verify_token: invoice.verifyToken,
  };
}

// ---------------------------------------------------------------------
// Shared posting effects — stock OUT + package consumption + line rows.
// Used by direct posting AND by approval of PENDING_APPROVAL invoices.
// ---------------------------------------------------------------------
async function applyInvoiceEffects(
  tx: Parameters<Parameters<typeof db.$transaction>[0]>[0],
  args: {
    invoice: { id: number; number: string; warehouseId: number; companyId: number; packagingDetails: boolean };
    computed: ComputedLine[];
    companyId: number;
    warehouseId: number;
    number: string;
    userId: number;
    policy: PackagePolicy;
    method: CostMethod; // Phase 4 — طريقة التكلفة (لقطة §6)
    existingLineIds?: number[]; // for PENDING invoices — update instead of create
    allowNegativeStock?: boolean; // تجاوز STOCK_001 عند الصرف/الاعتماد
  }
) {
  const { invoice, computed, companyId, warehouseId, number, userId, policy } = args;
  const packageEventsByLine: { lineIdx: number; events: PackageEvent[]; before: Decimal; after: Decimal }[] = [];
  let cogsSum = new Decimal(0); // Phase 4 — إجمالي COGS الفعلي للفاتورة

  for (let i = 0; i < computed.length; i++) {
    const l = computed[i];

    // physical package coverage sync (legacy stock parity)
    const ptx = txOf(tx);
    await ensurePackageCoverage(ptx, {
      companyId, warehouseId, productId: l.product.id, info: l.info, userId,
    });

    const beforeRow = await tx.stockBalance.findUnique({
      where: { warehouseId_productId: { warehouseId, productId: l.product.id } },
    });
    const stockBefore = qtyR(dec(beforeRow?.qty));

    // ---- Phase 4 §6: إنشاء سطر الفاتورة أولاً للحصول على refLineId -------
    let lineId = args.existingLineIds?.[i];
    if (!lineId) {
      const row = await tx.salesInvoiceLine.create({
        data: {
          invoiceId: invoice.id,
          productId: l.product.id,
          qty: l.baseQty,
          orderedQty: l.orderedQty,
          packageQty: l.packageQty,
          looseQty: l.looseQty,
          packageType: l.packageType,
          packageConversion: l.packageConversion,
          packagePrice: l.packagePrice,
          unitPrice: l.piecePrice,
          unitCost: l.unitCost,
          discountPct: l.discountPct,
          discountAmount: l.discountAmount,
          taxAmount: l.taxAmount,
          lineTotal: l.lineTotal,
          // ---- Phase 2 §8: لقطة مصدر السعر والوحدات لحظة البيع ----------
          priceCurrency: l.priceCurrency,
          priceExchangeRate: l.priceExchangeRate,
          costCurrency: l.costCurrency,
          baseUnitLabel: l.product.unit,
          packageUnitLabel: l.info.hasPack ? l.product.packUnit : null,
          stockBefore,
          stockAfter: stockBefore,
        },
      });
      lineId = row.id;
    }

    // ---- Phase 4 §3/§4/§5/§6: الصرف من طبقات التكلفة حسب طريقة الشركة ----
    // التكلفة الفعلية من الطبقات (fallback = التقدير السابق للمخزون القديم)
    const cogs = await consumeCost({
      tx,
      companyId,
      warehouseId,
      productId: l.product.id,
      qty: l.baseQty,
      method: args.method,
      fallbackCost: l.unitCost,
      refType: "SALES_INVOICE",
      refId: invoice.id,
      refLineId: lineId,
      userId,
    });
    cogsSum = cogsSum.plus(cogs.totalCost);

    const { balanceAfter } = await applyStockMovement({
      tx, companyId, warehouseId, productId: l.product.id,
      direction: "OUT", qty: l.baseQty, unitCost: cogs.unitCost,
      refType: "SALES_INVOICE", refId: invoice.id,
      note: `فاتورة ${number}`, userId,
      allowNegativeOverride: args.allowNegativeStock ?? false,
    });

    let events: PackageEvent[] = [];
    let packageNote: string | null = null;
    if (l.info.hasPack && l.baseQty.isPositive()) {
      const res = await consumeFromPackages(ptx, {
        companyId, warehouseId, productId: l.product.id,
        pieces: l.baseQty, info: l.info, policy, userId,
        refType: "SALES_INVOICE", refId: invoice.id, refNumber: number,
        // ---- Phase 2 §10: الكراتين الكاملة تُسحب من المغلقات كوحدات ----
        fullPackages: dec(l.packageQty).floor().toNumber(),
        loosePieces: l.looseQty,
      });
      events = res.events;
      packageNote = res.note;
    }

    packageEventsByLine.push({ lineIdx: i, events, before: stockBefore, after: balanceAfter });

    // ---- Phase 4 §6: لقطة COGS على البند — تكلفة فعلية + مراجع الطبقات ----
    // (تُختم مرة واحدة ولا تتأثر بتغير التكلفة لاحقاً)
    await tx.salesInvoiceLine.update({
      where: { id: lineId },
      data: {
        stockBefore,
        stockAfter: balanceAfter,
        packageNote,
        unitCost: cogs.unitCost,
        cogsUnitCost: cogs.unitCost,
        cogsTotal: cogs.totalCost,
        cogsMethod: cogs.method,
        cogsLayers: JSON.stringify(cogs.pieces.map((p) => ({ layer_id: p.layerId, qty: num(qtyR(p.qty)), unit_cost: num(p.unitCost) }))),
      },
    });
  }

  // ---- Phase 4 §6: لقطة COGS على ترويسة الفاتورة -------------------------
  await tx.salesInvoice.update({
    where: { id: invoice.id },
    data: { costMethod: args.method, cogsTotal: moneyR(cogsSum) },
  });

  return packageEventsByLine;
}

// ---------------------------------------------------------------------
// Credit approval flow (§6): APPROVE applies the deferred effects in ONE
// transaction; REJECT voids the document without any effect.
// ---------------------------------------------------------------------
export async function approveInvoice(
  actor: InvoiceActor,
  invoiceId: number
) {
  const inv = await db.salesInvoice.findFirst({
    where: { id: invoiceId, companyId: actor.companyId, deletedAt: null },
    include: {
      customer: true,
      warehouse: { include: { branch: { select: { id: true } } } },
      lines: { include: { product: true } },
    },
  });
  if (!inv) throw new ApiError("VAL_003", "الفاتورة غير موجودة");
  if (inv.status !== "PENDING_APPROVAL") {
    throw new ApiError("VAL_004", "الفاتورة ليست بانتظار الاعتماد");
  }
  if (!actor.warehouseIds.includes(inv.warehouseId)) throw new ApiError("SCOPE_002");

  const settings = await getInvoiceSettings(actor.companyId);
  // Phase 4: طريقة التكلفة للشركة لحظة اعتماد الفاتورة المعلقة
  const costMethod = await getCompanyCostMethod(actor.companyId);
  const computed: ComputedLine[] = inv.lines.map((ln) => {
    const info = packInfoOf(ln.product);
    return {
      product: {
        id: ln.product.id, name: ln.product.name, unit: ln.product.unit,
        salePrice: dec(ln.product.salePrice), costPrice: dec(ln.product.costPrice),
        taxRatePct: dec(ln.product.taxRatePct), packUnit: ln.product.packUnit,
        packQty: ln.product.packQty, packSalePrice: ln.product.packSalePrice,
      },
      info,
      baseQty: qtyR(dec(ln.qty)), orderedQty: qtyR(dec(ln.orderedQty || ln.qty)),
      packageQty: qtyR(dec(ln.packageQty)), looseQty: qtyR(dec(ln.looseQty)),
      packageType: ln.packageType, packageConversion: qtyR(dec(ln.packageConversion)),
      packagePrice: ln.packagePrice == null ? null : moneyR(dec(ln.packagePrice)),
      piecePrice: moneyR(dec(ln.unitPrice)), unitCost: moneyR(dec(ln.unitCost)),
      discountPct: pctR(dec(ln.discountPct)), discountAmount: moneyR(dec(ln.discountAmount)),
      taxAmount: moneyR(dec(ln.taxAmount)), lineTotal: moneyR(dec(ln.lineTotal)),
      // لقطة §8 محفوظة مع البند — الاعتماد لا يعيد حساب الأسعار
      priceCurrency: asCurrency(ln.priceCurrency),
      priceExchangeRate: ln.priceExchangeRate,
      costCurrency: asCurrency(ln.costCurrency),
    };
  });

  const due = moneyR(dec(inv.grandTotal).minus(inv.paidAmount));
  const invoice = await db.$transaction(async (tx) => {
    await applyInvoiceEffects(tx, {
      invoice: inv,
      computed,
      companyId: actor.companyId,
      warehouseId: inv.warehouseId,
      number: inv.number,
      userId: actor.userId,
      policy: settings.openPackagePolicy,
      method: costMethod,
      existingLineIds: inv.lines.map((ln) => ln.id),
      allowNegativeStock: inv.negativeStockAllowed,
    });
    if (due.isPositive()) {
      await tx.customer.update({
        where: { id: inv.customerId },
        data: { balance: { increment: due } },
      });
    }

    // ---- Cashbox integration on approval (Phase 31): the paid part of a
    // PENDING invoice enters the branch cashbox exactly at POSTED time.
    if (dec(inv.paidAmount).isPositive()) {
      await postInvoiceCashInTx(tx, {
        companyId: actor.companyId,
        branchId: inv.branchId,
        amount: inv.paidAmount,
        invoiceId: inv.id,
        invoiceNumber: inv.number,
        customerId: inv.customerId,
        customerName: inv.customer.name,
        userId: actor.userId,
      });
    }
    const fresh = await tx.customer.findUnique({ where: { id: inv.customerId }, select: { balance: true } });
    const updated = await tx.salesInvoice.update({
      where: { id: inv.id },
      data: {
        status: "POSTED",
        stockApplied: true,
        previousBalance: moneyR(dec(inv.previousBalance)),
        newBalance: moneyR(dec(fresh?.balance ?? inv.newBalance)),
      },
    });
    // v14 — إلغاء نقاط الولاء: لا كسب نقاط عند اعتماد الفاتورة
    return { updated, loyaltyEarned: 0 };
  });

  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "APPROVE",
      module: "sales",
      entityType: "sales_invoice",
      entityId: inv.id,
      oldValues: { status: "PENDING_APPROVAL" },
      newValues: { status: "POSTED", stock_applied: true, number: inv.number },
    }
  );

  await generateCommissionsForInvoice({
    invoiceId: inv.id,
    repId: inv.repId ?? actor.userId,
    grandTotal: inv.grandTotal,
    totalQty: sumOf(computed, (l) => l.baseQty),
    invoiceDate: inv.invoiceDate,
  });

  return {
    id: inv.id, number: inv.number, status: invoice.updated.status,
    new_balance: num(invoice.updated.newBalance), points_earned: invoice.loyaltyEarned,
  };
}

export async function rejectInvoice(actor: InvoiceActor, invoiceId: number, reason?: string | null) {
  const inv = await db.salesInvoice.findFirst({
    where: { id: invoiceId, companyId: actor.companyId, deletedAt: null },
  });
  if (!inv) throw new ApiError("VAL_003", "الفاتورة غير موجودة");
  if (inv.status !== "PENDING_APPROVAL") {
    throw new ApiError("VAL_004", "الفاتورة ليست بانتظار الاعتماد");
  }
  if (!actor.warehouseIds.includes(inv.warehouseId)) throw new ApiError("SCOPE_002");

  const updated = await db.salesInvoice.update({
    where: { id: inv.id },
    data: { status: "REJECTED", adminNotes: reason ?? inv.adminNotes },
  });

  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "REJECT",
      module: "sales",
      entityType: "sales_invoice",
      entityId: inv.id,
      oldValues: { status: "PENDING_APPROVAL" },
      newValues: { status: "REJECTED", number: inv.number, reason: reason ?? null },
    }
  );

  return { id: inv.id, number: inv.number, status: updated.status };
}

/** Public verification payload (§37) — no sensitive data, token-gated. */
export async function verifyByToken(token: string) {
  const inv = await db.salesInvoice.findFirst({
    where: { verifyToken: token, deletedAt: null },
    select: {
      number: true, invoiceDate: true, dueDate: true, status: true, saleType: true,
      subtotal: true, discountTotal: true, taxTotal: true, grandTotal: true, paidAmount: true,
      currencyCode: true, exchangeRate: true,
      receiverName: true, deliveredAt: true, signedAt: true, notes: true,
      walkinName: true, customerType: true,
      company: { select: { name: true, nameEn: true, phone: true, address: true, logoUrl: true } },
      branch: { select: { name: true } },
      customer: { select: { name: true, shopName: true } },
      lines: {
        select: {
          id: true, qty: true, packageQty: true, looseQty: true, packageType: true,
          packageConversion: true, unitPrice: true, discountPct: true, discountAmount: true, lineTotal: true,
          baseUnitLabel: true, packageUnitLabel: true,
          product: { select: { name: true, unit: true } },
        },
        orderBy: { id: "asc" },
      },
    },
  });
  if (!inv) return null;

  // الخصوصية أولاً (صفحة عامة بلا مصادقة): لا تكاليف/أرباح، لا أسماء موظفين،
  // ولا أرصدة ذمة العميل التاريخية — فقط محتوى الفاتورة نفسها.
  const due = Math.max(0, num(inv.grandTotal) - num(inv.paidAmount));
  return {
    valid: true,
    kind: "INVOICE" as const,
    invoice_number: inv.number,
    invoice_date: inv.invoiceDate,
    due_date: inv.dueDate,
    company: {
      name: inv.company.name || inv.company.nameEn,
      phone: inv.company.phone,
      address: inv.company.address,
      has_logo: !!inv.company.logoUrl,
    },
    branch: inv.branch?.name ?? null,
    customer: {
      name: inv.customerType === "WALK_IN" ? (inv.walkinName || "عميل نقدي") : inv.customer.name,
      shop_name: inv.customerType === "WALK_IN" ? null : inv.customer.shopName,
    },
    status: inv.status,
    status_ar: inv.status === "POSTED" ? "معتمدة" : inv.status === "PENDING_APPROVAL" ? "بانتظار الاعتماد" : inv.status === "REJECTED" ? "مرفوضة" : "ملغاة",
    sale_type_ar: inv.saleType === "CASH" ? "نقدي" : inv.saleType === "CREDIT" ? "آجل" : inv.saleType === "PARTIAL" ? "دفع جزئي" : inv.saleType === "SWAP" ? "استبدال" : "مرتجع",
    currency: { code: inv.currencyCode, exchange_rate: inv.exchangeRate ? num(inv.exchangeRate) : null },
    totals: {
      subtotal: num(inv.subtotal),
      discount_total: num(inv.discountTotal),
      tax_total: num(inv.taxTotal),
      grand_total: num(inv.grandTotal),
      paid_amount: num(inv.paidAmount),
      due_amount: due,
    },
    delivery: {
      receiver_name: inv.receiverName,
      delivered_at: inv.deliveredAt,
      signed_at: inv.signedAt,
    },
    notes: inv.notes,
    lines: inv.lines.map((l) => ({
      id: l.id,
      product: l.product.name,
      unit: l.product.unit,
      qty: num(l.qty),
      package_qty: num(l.packageQty),
      loose_qty: num(l.looseQty),
      package_type: l.packageType,
      unit_label: l.baseUnitLabel ?? l.product.unit,
      package_unit_label: l.packageUnitLabel,
      unit_price: num(l.unitPrice),
      discount_pct: num(l.discountPct),
      discount_amount: num(l.discountAmount),
      line_total: num(l.lineTotal),
    })),
  };
}

// ---------------------------------------------------------------------
// VOID — إلغاء فاتورة مع عكس كامل للآثار (تطوير الفاتورة):
//  · PENDING_APPROVAL → إلغاء بسيط (لم تُطبق آثاراً بعد)
//  · POSTED → عكس المخزون (IN) + إرجاع الحبات للعبوات المفتوحة
//             + خصم المتبقي غير المسدد من ذمة العميل
//  · REJECTED/VOID → مرفوض (لا حالة صالحة للإلغاء)
// المبالغ المحصّلة سابقاً تبقى موثقة في الصندوق — الاسترداد يدوي إن لزم.
// ---------------------------------------------------------------------
export async function voidInvoice(
  actor: InvoiceActor,
  invoiceId: number,
  reason?: string | null
) {
  const inv = await db.salesInvoice.findFirst({
    where: { id: invoiceId, companyId: actor.companyId, deletedAt: null },
    include: {
      lines: { include: { product: true } },
      warehouse: true,
    },
  });
  if (!inv) throw new ApiError("VAL_003", "الفاتورة غير موجودة");
  if (inv.status === "VOID") throw new ApiError("VAL_004", "الفاتورة ملغاة مسبقاً");
  if (inv.status === "REJECTED") throw new ApiError("VAL_004", "الفاتورة مرفوضة — لا تحتاج إلغاء");
  if (!actor.warehouseIds.includes(inv.warehouseId)) throw new ApiError("SCOPE_002");

  const wasPosted = inv.status === "POSTED" && inv.stockApplied;

  await db.$transaction(async (tx) => {
    if (wasPosted) {
      // عكس المخزون + إرجاع العبوات لكل بند
      for (const ln of inv.lines) {
        if (!dec(ln.qty).isPositive()) continue;
        const info = packInfoOf(ln.product);

        // ---- Phase 4 §6/§7: استرجاع الطبقات بتكلفة الصرف الفعلية —
        // من سجل cost_consumptions لهذا البند (تكلفة تعود كما خرجت)،
        // وحارس مدمج يمنع ازدواج الاسترجاع عند المرتجعات السابقة.
        const restored = await restoreLayersFromConsumptions({
          tx,
          companyId: actor.companyId,
          warehouseId: inv.warehouseId,
          productId: ln.productId,
          sourceRefType: "SALES_INVOICE",
          sourceRefId: inv.id,
          sourceRefLineId: ln.id,
          qtyToRestore: ln.qty,
          newSourceType: "VOID_RESTORE",
          newSourceId: inv.id,
          fallbackCost: ln.unitCost,
          createdBy: actor.userId,
        });

        const { balanceAfter } = await applyStockMovement({
          tx, companyId: actor.companyId, warehouseId: inv.warehouseId,
          productId: ln.productId, direction: "IN", qty: ln.qty,
          unitCost: restored.layers.length ? restored.unitCost : ln.unitCost,
          refType: "SALES_INVOICE_VOID", refId: inv.id,
          note: `إلغاء فاتورة ${inv.number}`, userId: actor.userId,
        });

        // إرجاع الحبات إلى العبوات المفتوحة (سياسة الوعاء نفسها)
        if (info.hasPack) {
          await restockToPackages(txOf(tx), {
            companyId: actor.companyId, warehouseId: inv.warehouseId,
            productId: ln.productId, pieces: ln.qty, info,
            condition: "OPENED", userId: actor.userId,
            refType: "SALES_INVOICE_VOID", refId: inv.id, refNumber: inv.number,
          });
        }

        await tx.salesInvoiceLine.update({
          where: { id: ln.id },
          data: { stockBefore: ln.stockAfter, stockAfter: balanceAfter },
        });
      }

      // خصم المتبقي غير المسدد من ذمة العميل (ما أُضيف وقت الاعتماد)
      const due = moneyR(dec(inv.grandTotal).minus(inv.paidAmount));
      if (due.isPositive()) {
        await tx.customer.update({
          where: { id: inv.customerId },
          data: { balance: { decrement: due } },
        });
      }

      // ---- Cashbox refund (Phase 32): voiding a paid invoice returns the
      // cash OUT to the branch cashbox (walk-in cash sales included).
      if (dec(inv.paidAmount).isPositive()) {
        await postInvoiceCashOutTx(tx, {
          companyId: actor.companyId,
          branchId: inv.branchId,
          amount: inv.paidAmount,
          invoiceId: inv.id,
          invoiceNumber: inv.number,
          customerId: inv.customerId,
          userId: actor.userId,
        });
      }
    }

    const fresh = await tx.customer.findUnique({
      where: { id: inv.customerId }, select: { balance: true },
    });
    await tx.salesInvoice.update({
      where: { id: inv.id },
      data: {
        status: "VOID",
        stockApplied: false,
        adminNotes: reason
          ? `${inv.adminNotes ? inv.adminNotes + "\n" : ""}إلغاء: ${reason}`.slice(0, 500)
          : inv.adminNotes,
        newBalance: moneyR(dec(fresh?.balance ?? inv.newBalance)),
      },
    });
  });

  await writeAudit(
    { userId: actor.userId, companyId: actor.companyId, ipAddress: actor.ip, userAgent: actor.userAgent },
    {
      action: "CANCEL",
      module: "sales",
      entityType: "sales_invoice",
      entityId: inv.id,
      oldValues: { status: inv.status },
      newValues: { status: "VOID", number: inv.number, reason: reason ?? null, stock_reversed: wasPosted },
    }
  );

  return {
    id: inv.id,
    number: inv.number,
    status: "VOID" as const,
    stock_reversed: wasPosted,
  };
}
