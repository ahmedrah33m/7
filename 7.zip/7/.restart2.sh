#!/bin/bash
for p in $(pgrep -f 'next-server') $(pgrep -f 'next start'); do
  CMDLINE=$(tr '\0' ' ' < /proc/$p/cmdline 2>/dev/null)
  if echo "$CMDLINE" | grep -q ':3000\|next-server'; then
    kill $p 2>/dev/null
  fi
done
sleep 3
ss -tlnp 2>/dev/null | grep :3000 && echo 'PORT_STILL_BUSY' || echo 'PORT_FREE'
cd /home/ahmedr/maydanerp
nohup setsid npx next start -p 3000 >/home/ahmedr/maydanerp/app.log 2>&1 < /dev/null &
sleep 7
ss -tlnp 2>/dev/null | grep :3000
curl -s -o /dev/null -w 'HEALTH HTTP %{http_code}\n' http://localhost:3000/api/v1/health