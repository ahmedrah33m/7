// =====================================================================
// Phase 5 — بطارية الاختبارات الرسمية (Delivery Note & Partial Delivery)
// تشغيل: node scripts/phase5-verify.mjs   (يتطلب dev server على :3000)
//
// تغطية نطاق المرحلة (§8 + DoD):
//   full delivery · partial delivery · multiple deliveries · over-delivery
//   · cancel delivery · invoice after delivery · delivery after invoice
//   · double stock deduction · cross-company delivery
//   + remaining quantity + delivery lines + status transitions + audit §7
//   + قاعدة المخزون الوحيدة: الفاتورة تخصم — الإشعار لا يلمس المخزون
// كل الثوابت تُعاد حسابها من القاعدة بـ Decimal (precision 40).
// =====================================================================
const BASE = "http://localhost:3000/api/v1";
import { PrismaClient } from "@prisma/client";
import Decimal from "decimal.js";

Decimal.set({ precision: 40, rounding: Decimal.ROUND_HALF_UP, toExpNeg: -18, toExpPos: 48 });
const db = new PrismaClient();

let PASS = 0, FAIL = 0;
const failures = [];
function ok(name, cond, detail = "") {
  if (cond) { PASS++; console.log(`  ✓ ${name}`); }
  else { FAIL++; failures.push({ name, detail }); console.log(`  ✗ ${name} — ${detail}`); }
}
const dec = (v) => {
  if (v == null || v === "") return new Decimal(0);
  if (v instanceof Decimal) return v;
  if (typeof v === "object" && typeof v.toString === "function") { const d = new Decimal(v.toString()); return d.isFinite() ? d : new Decimal(0); }
  const d = new Decimal(v);
  return d.isFinite() ? d : new Decimal(0);
};
const qtyR = (v) => dec(v).toDecimalPlaces(6, Decimal.ROUND_HALF_UP);
const eq = (a, b) => dec(a).toString() === dec(b).toString();

async function jfetch(path, init) {
  const res = await fetch(`${BASE}${path}`, init);
  const body = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, body };
}
const post = (path, auth, data) => jfetch(path, { method: "POST", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(data) });
const patch = (path, auth, data) => jfetch(path, { method: "PATCH", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(data) });
const get = (path, auth) => jfetch(path, { headers: auth });

function bail(cond, msg) { if (cond) throw Object.assign(new Error(msg), { bail: true }); }

/** رصيد المخزون الحي لزوج (مستودع، منتج) */
async function stockQty(warehouseId, productId) {
  const b = await db.stockBalance.findFirst({ where: { warehouseId, productId } });
  return qtyR(dec(b?.qty ?? 0));
}

async function main() {
  try { await runTests(); } catch (e) {
    if (e?.bail) console.error(`\n⛔ BAIL: ${e.message}`);
    else console.error(e);
  }
  console.log("=".repeat(70));
  console.log(`RESULT: PASS=${PASS} FAIL=${FAIL}`);
  if (failures.length) {
    console.log("الفشل:");
    for (const fl of failures) console.log(`  ✗ ${fl.name}: ${fl.detail}`);
  }
  console.log("=".repeat(70));
  if (FAIL > 0) process.exitCode = 1;
  await db.$disconnect();
}

async function runTests() {
  console.log("=".repeat(70));
  console.log("PHASE 5 VERIFY — Delivery Note & Partial Delivery Engine");
  console.log("=".repeat(70));
  const sfx = Date.now().toString().slice(-6);

  // ---------- الإعداد: شركة معزولة ----------
  const login = await post("/auth/login", {}, { username: "admin", password: "Admin@123" });
  const t1 = login.body.data?.access_token;
  ok("SETUP login admin", !!t1, JSON.stringify(login.body).slice(0, 100));

  const comp = await post("/admin/companies", { authorization: `Bearer ${t1}` }, {
    code: `P5T${sfx}`, name: `شركة فحص التسليم ${sfx}`,
  });
  const companyId = comp.body.data?.companyId;
  const whId = comp.body.data?.warehouseId;
  const branchId = comp.body.data?.branchId;
  ok("SETUP شركة اختبار P5T + provisioning", comp.status === 201 && !!companyId && !!whId,
    JSON.stringify(comp.body).slice(0, 140));

  const sw = await post("/auth/switch-company", { authorization: `Bearer ${t1}` }, { company_id: companyId });
  const auth = { authorization: `Bearer ${sw.body.data?.access_token ?? ""}` };
  ok("SETUP switch-company", !!sw.body.data?.access_token, JSON.stringify(sw.body).slice(0, 100));

  await db.cashbox.create({ data: { companyId, branchId, code: "MAIN", name: "الصندوق الرئيسي", balance: new Decimal(50000000) } });
  const cust = (await post("/customers", auth, { name: `عميل تسليم ${sfx}`, phone: "07701000000", credit_limit: 99999999 })).body.data;
  ok("SETUP عميل", !!cust?.id, JSON.stringify(cust).slice(0, 100));

  const prodA = (await post("/products", auth, {
    name: `صنف تسليم ${sfx}`, unit: "حبة", cost_price: 1000, sale_price: 1500, min_stock: 0,
  })).body.data;
  ok("SETUP منتج A (حبة صرفة)", !!prodA?.id, JSON.stringify(prodA).slice(0, 100));
  const prodB = (await post("/products", auth, {
    name: `صنف معبأ ${sfx}`, unit: "حبة", pack_unit: "كرتونة", pack_qty: 11,
    cost_price: 1000, sale_price: 1500, min_stock: 0,
  })).body.data;
  ok("SETUP منتج B (كرتونة 1×11)", !!prodB?.id, "none");

  // مخزون افتتاحي 500 حبة A + 110 حبة B (10 كراتين)
  const openA = await post("/inventory/movements", auth, { warehouse_id: whId, product_id: prodA.id, direction: "IN", qty: 500, unit_cost: 1000, note: "افتتاحي A" });
  const openB = await post("/inventory/movements", auth, { warehouse_id: whId, product_id: prodB.id, direction: "IN", qty: 110, unit_cost: 1000, note: "افتتاحي B" });
  ok("SETUP مخزون افتتاحي A=500 و B=110", openA.status === 201 && openB.status === 201,
    `${openA.status}/${openB.status}`);
  const S0_A = await stockQty(whId, prodA.id);
  ok("SETUP رصيد A = 500", eq(S0_A, 500), `got ${S0_A}`);

  /** مساعد: أمر بيع مؤكد */
  async function makeConfirmedOrder(qty, productId = prodA.id) {
    const o = await post("/sales/orders", auth, {
      customer_id: cust.id, warehouse_id: whId,
      lines: [{ product_id: productId, qty }],
    });
    bail(!o.ok, `فشل إنشاء أمر البيع: ${JSON.stringify(o.body).slice(0, 200)}`);
    const conf = await post(`/sales/orders/${o.body.data.id}/confirm`, auth, {});
    bail(!conf.ok, `فشل تأكيد الأمر: ${JSON.stringify(conf.body).slice(0, 200)}`);
    const detail = await get(`/sales/orders/${o.body.data.id}`, auth);
    return { id: o.body.data.id, number: o.body.data.number, lineId: detail.body.data?.lines?.[0]?.id };
  }
  /** مساعد: إنشاء إشعار من أمر بكمية محددة */
  async function makeDN(order, qty) {
    return post("/sales/delivery-notes", auth, {
      order_id: order.id,
      lines: [{ sales_order_line_id: order.lineId, qty }],
    });
  }

  // ================= T1 — Full delivery =================
  console.log("\n■ T1 — Full delivery: أمر 100 → إشعار 100 → DELIVERED");
  const o1 = await makeConfirmedOrder(100);
  const dn1 = await makeDN(o1, 100);
  ok("T1a إنشاء إشعار من الأمر → 201 + PENDING", dn1.status === 201 && dn1.body.data?.status === "PENDING",
    JSON.stringify(dn1.body).slice(0, 160));
  const dn1id = dn1.body.data?.id;
  const dn1line = dn1.body.data?.lines?.[0];
  ok("T1b بند الإشعار: ordered=100 previous=0 current=100",
    dn1line && eq(dn1line.ordered_qty, 100) && eq(dn1line.previously_delivered_qty, 0) && eq(dn1line.current_delivered_qty, 100),
    JSON.stringify(dn1line).slice(0, 200));
  const stockAfterCreate = await stockQty(whId, prodA.id);
  ok("T1c إنشاء الإشعار لا يخصم المخزون (500)", eq(stockAfterCreate, 500), `got ${stockAfterCreate}`);
  const d1 = await patch(`/sales/delivery-notes/${dn1id}`, auth, { action: "deliver", received_by: "أبو أحمد" });
  ok("T1d تسليم كامل → DELIVERED", d1.ok && d1.body.data?.status === "DELIVERED", JSON.stringify(d1.body).slice(0, 160));
  ok("T1e بند ما بعد التسليم: current=100 remaining=0",
    eq(d1.body.data?.lines?.[0]?.current_delivered_qty, 100) && eq(d1.body.data?.lines?.[0]?.remaining_qty, 0),
    JSON.stringify(d1.body.data?.lines?.[0]).slice(0, 160));
  const prog1 = await get(`/sales/orders/${o1.id}/delivery-progress`, auth);
  ok("T1f تقدم الأمر: delivery_status=DELIVERED remaining=0",
    prog1.body.data?.delivery_status === "DELIVERED" && eq(prog1.body.data?.lines?.[0]?.remaining_qty, 0),
    JSON.stringify(prog1.body.data).slice(0, 200));
  const dn1db = await db.deliveryNote.findUnique({ where: { id: dn1id } });
  ok("T1g Audit §7: deliveredById مسجّل + receivedBy",
    !!dn1db?.deliveredById && dn1db?.receivedBy === "أبو أحمد" && !!dn1db?.deliveredAt,
    JSON.stringify({ d: dn1db?.deliveredById, r: dn1db?.receivedBy }));
  const stockAfterD1 = await stockQty(whId, prodA.id);
  ok("T1h التسليم لا يخصم المخزون (500) — قاعدة §5", eq(stockAfterD1, 500), `got ${stockAfterD1}`);
  const reDeliver = await patch(`/sales/delivery-notes/${dn1id}`, auth, { action: "deliver" });
  ok("T1i إعادة تسليم إشعار مسلَّم → مرفوض DLV_001", !reDeliver.ok && reDeliver.body?.code === "DLV_001",
    JSON.stringify(reDeliver.body).slice(0, 120));

  // ================= T2 — Partial + multiple deliveries (مثال النطاق 100=40+30+30) =================
  console.log("\n■ T2 — Partial + multiple: أمر 100 → 40 → 30 → 30");
  const o2 = await makeConfirmedOrder(100);
  const dn2a = await makeDN(o2, 40);
  ok("T2a إشعار 1 (40) → PENDING", dn2a.status === 201, JSON.stringify(dn2a.body).slice(0, 140));
  const dl2a = dn2a.body.data?.lines?.[0];
  ok("T2b كميات الإشعار 1: ordered=100 previous=0 current=40",
    eq(dl2a?.ordered_qty, 100) && eq(dl2a?.previously_delivered_qty, 0) && eq(dl2a?.current_delivered_qty, 40),
    JSON.stringify(dl2a));
  const del2a = await patch(`/sales/delivery-notes/${dn2a.body.data.id}`, auth, { action: "deliver" });
  ok("T2c تسليم 40 → حالة الإشعار PARTIAL", del2a.ok && del2a.body.data?.status === "PARTIAL", JSON.stringify(del2a.body).slice(0, 140));
  ok("T2d المتبقي على البند = 60", eq(del2a.body.data?.lines?.[0]?.remaining_qty, 60), JSON.stringify(del2a.body.data?.lines?.[0]));
  const prog2a = await get(`/sales/orders/${o2.id}/delivery-progress`, auth);
  ok("T2e تقدم الأمر بعد الأول: delivered=40 remaining=60 PARTIAL",
    prog2a.body.data?.delivery_status === "PARTIAL" && eq(prog2a.body.data?.lines?.[0]?.delivered_qty, 40) && eq(prog2a.body.data?.lines?.[0]?.remaining_qty, 60),
    JSON.stringify(prog2a.body.data?.lines?.[0]));

  const dn2b = await makeDN(o2, 30);
  const dl2b = dn2b.body.data?.lines?.[0];
  ok("T2f إشعار 2 (30): previous=40 remaining-at-create=60",
    dn2b.status === 201 && eq(dl2b?.previously_delivered_qty, 40) && eq(dl2b?.current_delivered_qty, 30),
    JSON.stringify(dl2b));
  const del2b = await patch(`/sales/delivery-notes/${dn2b.body.data.id}`, auth, { action: "deliver" });
  ok("T2g تسليم 30 → PARTIAL (بقي 30)", del2b.ok && del2b.body.data?.status === "PARTIAL", JSON.stringify(del2b.body).slice(0, 140));

  const dn2c = await makeDN(o2, 30);
  const del2c = await patch(`/sales/delivery-notes/${dn2c.body.data.id}`, auth, { action: "deliver" });
  ok("T2h تسليم 30 الأخير → الإشعار DELIVERED", del2c.ok && del2c.body.data?.status === "DELIVERED", JSON.stringify(del2c.body).slice(0, 140));
  const prog2c = await get(`/sales/orders/${o2.id}/delivery-progress`, auth);
  ok("T2i تقدم الأمر: DELIVERED delivered=100 remaining=0 + 3 إشعارات",
    prog2c.body.data?.delivery_status === "DELIVERED" && eq(prog2c.body.data?.lines?.[0]?.delivered_qty, 100)
    && prog2c.body.data?.notes?.length === 3,
    JSON.stringify(prog2c.body.data).slice(0, 200));

  // ================= T3 — Over-delivery (§4) =================
  console.log("\n■ T3 — Over-delivery ممنوع (إنشاء وتسليم وتزامن)");
  const odCreate = await makeDN(o2, 10);
  ok("T3a إنشاء إشعار بأكثر من المتبقي (0) → مرفوض DLV_003",
    !odCreate.ok && odCreate.body?.code === "DLV_003", JSON.stringify(odCreate.body).slice(0, 140));
  const o3 = await makeConfirmedOrder(50);
  const dn3a = await makeDN(o3, 50);
  const dn3b = await makeDN(o3, 50); // كلاهما خطط المتبقي كاملاً
  ok("T3b إنشاء إشعارين متزامنين 50+50 على أمر 50 → كلاهما مقبول عند الإنشاء (لا حجز ناعم)",
    dn3a.status === 201 && dn3b.status === 201, "pool = المسلَّم فعلياً فقط");
  const del3a = await patch(`/sales/delivery-notes/${dn3a.body.data.id}`, auth, { action: "deliver" });
  ok("T3c الأول يُسلَّم كاملاً", del3a.ok && del3a.body.data?.status === "DELIVERED", JSON.stringify(del3a.body).slice(0, 120));
  const del3b = await patch(`/sales/delivery-notes/${dn3b.body.data.id}`, auth, { action: "deliver" });
  ok("T3d الثاني يُرفض عند التسليم → DLV_003 over-delivery",
    !del3b.ok && del3b.body?.code === "DLV_003", JSON.stringify(del3b.body).slice(0, 140));
  const o3b = await makeConfirmedOrder(20);
  const dn3c = await makeDN(o3b, 10);
  const delOver = await patch(`/sales/delivery-notes/${dn3c.body.data.id}`, auth, {
    action: "deliver", lines: [{ line_id: dn3c.body.data.lines[0].id, qty: 15 }],
  });
  ok("T3e تسليم فعلي 15 > مخطط 10 → مرفوض DLV_004",
    !delOver.ok && delOver.body?.code === "DLV_004", JSON.stringify(delOver.body).slice(0, 140));

  // ================= T4 — Cancel delivery =================
  console.log("\n■ T4 — Cancel: الكميات تعود للمتبقي");
  const o4 = await makeConfirmedOrder(60);
  const dn4 = await makeDN(o4, 60);
  const can4 = await patch(`/sales/delivery-notes/${dn4.body.data.id}`, auth, { action: "cancel" });
  ok("T4a إلغاء PENDING → CANCELLED", can4.ok && can4.body.data?.status === "CANCELLED", JSON.stringify(can4.body).slice(0, 120));
  const dn4db = await db.deliveryNote.findUnique({ where: { id: dn4.body.data.id } });
  ok("T4b Audit §7: cancelledById + cancelledAt", !!dn4db?.cancelledById && !!dn4db?.cancelledAt,
    JSON.stringify({ c: dn4db?.cancelledById, at: dn4db?.cancelledAt }));
  const prog4 = await get(`/sales/orders/${o4.id}/delivery-progress`, auth);
  ok("T4c الملغى مستبعد: remaining=60 delivered=0", eq(prog4.body.data?.lines?.[0]?.remaining_qty, 60), JSON.stringify(prog4.body.data?.lines?.[0]));
  const reCan = await patch(`/sales/delivery-notes/${dn4.body.data.id}`, auth, { action: "cancel" });
  ok("T4d إعادة إلغاء ملغى → مرفوض", !reCan.ok, JSON.stringify(reCan.body).slice(0, 100));
  // ملغى لا يُسلَّم
  const delCan = await patch(`/sales/delivery-notes/${dn4.body.data.id}`, auth, { action: "deliver" });
  ok("T4e تسليم ملغى → مرفوض DLV_002", !delCan.ok && delCan.body?.code === "DLV_002", JSON.stringify(delCan.body).slice(0, 120));
  // المسلَّم غير قابل للإلغاء
  const canDelivered = await patch(`/sales/delivery-notes/${dn3a.body.data.id}`, auth, { action: "cancel" });
  ok("T4f إلغاء مسلَّم → مرفوض DLV_001", !canDelivered.ok && canDelivered.body?.code === "DLV_001", JSON.stringify(canDelivered.body).slice(0, 120));

  // ================= T5 — Invoice after delivery (السلسلة الكاملة) =================
  console.log("\n■ T5 — invoice after delivery: إشعار مسلَّم → فاتورة (الخصم مرة واحدة)");
  const sBefore5 = await stockQty(whId, prodA.id);
  const o5 = await makeConfirmedOrder(80);
  const dn5 = await makeDN(o5, 80);
  await patch(`/sales/delivery-notes/${dn5.body.data.id}`, auth, { action: "deliver", received_by: "سائق 5" });
  const sMid5 = await stockQty(whId, prodA.id);
  ok("T5a التسليم لم يخصم (قبل الفاتورة)", eq(sBefore5, sMid5), `${sBefore5} → ${sMid5}`);
  const conv5 = await post(`/sales/delivery-notes/${dn5.body.data.id}/convert`, auth, { type: "CASH" });
  ok("T5b تحويل → 201 + فاتورة صادرة", conv5.status === 201 && !!conv5.body.data?.invoice_number, JSON.stringify(conv5.body).slice(0, 180));
  const inv5 = await get(`/sales/invoices/${conv5.body.data.invoice_id}`, auth);
  const inv5line = inv5.body.data?.lines?.[0];
  ok("T5c الفاتورة بكمية مسلَّمة 80 وسعر الأمر 1500",
    eq(inv5line?.qty, 80) && eq(inv5line?.unit_price, 1500), JSON.stringify(inv5line).slice(0, 200));
  const sAfter5 = await stockQty(whId, prodA.id);
  ok("T5d الفاتورة خصمت مرة واحدة: 500→420", eq(sAfter5, dec(sBefore5).minus(80)), `${sBefore5} → ${sAfter5}`);
  const inv5db = await db.salesInvoice.findUnique({ where: { id: conv5.body.data.invoice_id }, include: { lines: true } });
  ok("T5e لقطة COGS موجودة (محرك المرحلة 4 يعمل عبر التحويل)",
    inv5db?.lines?.[0]?.cogsTotal != null && inv5db?.costMethod != null && dec(inv5db?.lines?.[0]?.cogsTotal).isPositive(),
    JSON.stringify({ cogs: inv5db?.lines?.[0]?.cogsTotal?.toString(), m: inv5db?.costMethod }));
  const o5db = await db.salesOrder.findUnique({ where: { id: o5.id } });
  ok("T5f الأمر اكتمل → INVOICED + invoiceId", o5db?.status === "INVOICED" && o5db?.invoiceId === conv5.body.data.invoice_id,
    JSON.stringify({ s: o5db?.status, inv: o5db?.invoiceId }));
  const reConv = await post(`/sales/delivery-notes/${dn5.body.data.id}/convert`, auth, { type: "CASH" });
  ok("T5g إعادة تحويل نفس الإشعار → مرفوض", !reConv.ok, JSON.stringify(reConv.body).slice(0, 120));

  // T5-2: تحويل جزئي → الأمر يبقى CONFIRMED حتى اكتمال البقية
  console.log("\n■ T5-2 — تحويل جزئي: 100 → فاتورة 40 ثم فاتورة 60");
  const o6 = await makeConfirmedOrder(100);
  const dn6a = await makeDN(o6, 40);
  await patch(`/sales/delivery-notes/${dn6a.body.data.id}`, auth, { action: "deliver" });
  const conv6a = await post(`/sales/delivery-notes/${dn6a.body.data.id}/convert`, auth, { type: "CREDIT" });
  ok("T5-2a تحويل جزئي 40 → 201", conv6a.status === 201, JSON.stringify(conv6a.body).slice(0, 140));
  ok("T5-2b الأمر يبقى CONFIRMED بعد التسليم الجزئي", conv6a.body.data?.order_status === "CONFIRMED", JSON.stringify(conv6a.body.data));
  const s6 = await stockQty(whId, prodA.id);
  const dn6b = await makeDN(o6, 60);
  const dl6b = dn6b.body.data?.lines?.[0];
  ok("T5-2c إشعار البقية: previous=40 current=60", eq(dl6b?.previously_delivered_qty, 40) && eq(dl6b?.current_delivered_qty, 60), JSON.stringify(dl6b));
  await patch(`/sales/delivery-notes/${dn6b.body.data.id}`, auth, { action: "deliver" });
  const conv6b = await post(`/sales/delivery-notes/${dn6b.body.data.id}/convert`, auth, { type: "CREDIT" });
  ok("T5-2d تحويل البقية → الأمر INVOICED", conv6b.status === 201 && conv6b.body.data?.order_status === "INVOICED", JSON.stringify(conv6b.body).slice(0, 160));
  const s6f = await stockQty(whId, prodA.id);
  ok("T5-2e خصم مجموع 100 مرة واحدة", eq(dec(s6).minus(s6f), 60), `${s6} → ${s6f}`);

  // ================= T6 — Delivery after invoice + double deduction =================
  console.log("\n■ T6 — delivery after invoice: فاتورة ثم إشعار — لا خصم ثانٍ");
  const sBefore6 = await stockQty(whId, prodA.id);
  const invDirect = await post("/sales/invoices", auth, {
    customer_id: cust.id, warehouse_id: whId, type: "CASH",
    lines: [{ product_id: prodA.id, qty: 20 }],
  });
  ok("T6a فاتورة مباشرة 20 → 201", invDirect.status === 201, JSON.stringify(invDirect.body).slice(0, 140));
  const invId = invDirect.body.data?.id;
  const invDetail = await get(`/sales/invoices/${invId}`, auth);
  const invLineId = invDetail.body.data?.lines?.[0]?.id;
  const sAfterInv = await stockQty(whId, prodA.id);
  ok("T6b الفاتورة خصمت 20", eq(dec(sBefore6).minus(sAfterInv), 20), `${sBefore6} → ${sAfterInv}`);
  const dnFromInv = await post("/sales/delivery-notes", auth, { customer_id: cust.id, invoice_id: invId });
  ok("T6c إشعار من الفاتورة → بنود تلقائية ordered=20",
    dnFromInv.status === 201 && eq(dnFromInv.body.data?.lines?.[0]?.ordered_qty, 20), JSON.stringify(dnFromInv.body).slice(0, 160));
  const delInv = await patch(`/sales/delivery-notes/${dnFromInv.body.data.id}`, auth, { action: "deliver" });
  ok("T6d تسليم إشعار الفاتورة → DELIVERED", delInv.ok && delInv.body.data?.status === "DELIVERED", JSON.stringify(delInv.body).slice(0, 120));
  const sFinal = await stockQty(whId, prodA.id);
  ok("T6e لا double deduction: المخزون كما هو بعد التسليم", eq(sFinal, sAfterInv), `${sAfterInv} → ${sFinal}`);
  const dnFromInv2 = await post("/sales/delivery-notes", auth, { customer_id: cust.id, invoice_id: invId });
  ok("T6f إشعار ثانٍ من نفس الفاتورة → مرفوض (لا متبقي)",
    !dnFromInv2.ok && dnFromInv2.body?.code === "DLV_004", JSON.stringify(dnFromInv2.body).slice(0, 140));
  const convInvDn = await post(`/sales/delivery-notes/${dnFromInv.body.data.id}/convert`, auth, { type: "CASH" });
  ok("T6g تحويل إشعار مرتبط بفاتورة (لا أمر) → مرفوض", !convInvDn.ok, JSON.stringify(convInvDn.body).slice(0, 120));

  // الثابت الذهبي: حركة المخزون الصادرة = مجموع كميات الفواتير فقط
  const movOut = await db.stockMovement.aggregate({
    where: { companyId, warehouseId: whId, productId: prodA.id, direction: "OUT" },
    _sum: { qty: true },
  });
  const expectedOut = dec(S0_A).minus(await stockQty(whId, prodA.id));
  ok("T6h ثابت §6: OUT الحركات = الإجمالي المسحوب بالفواتير بالضبط",
    eq(movOut._sum.qty, expectedOut), `movements=${movOut._sum.qty} expected=${expectedOut}`);

  // ================= T7 — Standalone + packaging display =================
  console.log("\n■ T7 — مستقل + لقطة التعبئة على بنود الإشعار");
  const sBefore7 = await stockQty(whId, prodA.id);
  const dnSt = await post("/sales/delivery-notes", auth, {
    customer_id: cust.id,
    lines: [{ product_id: prodA.id, qty: 7 }],
  });
  ok("T7a إشعار مستقل ببند يدوي → 201", dnSt.status === 201 && eq(dnSt.body.data?.lines?.[0]?.ordered_qty, 7), JSON.stringify(dnSt.body).slice(0, 160));
  const delSt = await patch(`/sales/delivery-notes/${dnSt.body.data.id}`, auth, { action: "deliver" });
  ok("T7b المستقل يُسلَّم → DELIVERED", delSt.ok && delSt.body.data?.status === "DELIVERED", JSON.stringify(delSt.body).slice(0, 120));
  const sAfter7 = await stockQty(whId, prodA.id);
  ok("T7c المستقل لا يخصم المخزون (قاعدة §5 واحدة)", eq(sBefore7, sAfter7), `${sBefore7} → ${sAfter7}`);

  const o7 = await makeConfirmedOrder(25, prodB.id);
  const dn7 = await makeDN(o7, 25);
  const l7 = dn7.body.data?.lines?.[0];
  ok("T7d لقطة تعبئة 25 حبة (كرتونة 11): 2 عبوة + 3 حبات + conversion=11",
    eq(l7?.package_qty, 2) && eq(l7?.loose_qty, 3) && eq(l7?.package_conversion, 11) && l7?.package_type === "CARTON",
    JSON.stringify(l7).slice(0, 220));

  // تسليم فعلي جزئي داخل الإشعار نفسه: خطط 25 سلّم 10 → PARTIAL
  const del7 = await patch(`/sales/delivery-notes/${dn7.body.data.id}`, auth, {
    action: "deliver", lines: [{ line_id: l7.id, qty: 10 }],
  });
  ok("T7e تسليم فعلي 10 من 25 → PARTIAL + المتبقي 15",
    del7.ok && del7.body.data?.status === "PARTIAL" && eq(del7.body.data?.lines?.[0]?.remaining_qty, 15),
    JSON.stringify(del7.body.data).slice(0, 200));

  // ================= T8 — Cross-company (عزل) =================
  console.log("\n■ T8 — Cross-company delivery: كل محاولات العبور تُرفض");
  const compB = await post("/admin/companies", { authorization: `Bearer ${t1}` }, {
    code: `P5B${sfx}`, name: `شركة فحص أخرى ${sfx}`,
  });
  const companyIdB = compB.body.data?.companyId;
  const swB = await post("/auth/switch-company", { authorization: `Bearer ${t1}` }, { company_id: companyIdB });
  const authB = { authorization: `Bearer ${swB.body.data?.access_token ?? ""}` };
  ok("T8a شركة B جاهزة", !!swB.body.data?.access_token, JSON.stringify(compB.body).slice(0, 100));

  const custB = (await post("/customers", authB, { name: `عميل B ${sfx}`, phone: "07702000000" })).body.data;
  // محاولة إنشاء إشعار على أمر شركة A
  const xOrder = await post("/sales/delivery-notes", authB, { order_id: o1.id });
  ok("T8b B → أمر A: مرفوض", !xOrder.ok, JSON.stringify(xOrder.body).slice(0, 120));
  const xInv = await post("/sales/delivery-notes", authB, { customer_id: custB.id, invoice_id: invId });
  ok("T8c B → فاتورة A: مرفوض", !xInv.ok, JSON.stringify(xInv.body).slice(0, 120));
  const xDeliver = await patch(`/sales/delivery-notes/${dn1id}`, authB, { action: "deliver" });
  ok("T8d B → تسليم إشعار A: مرفوض", !xDeliver.ok, JSON.stringify(xDeliver.body).slice(0, 120));
  const xCancel = await patch(`/sales/delivery-notes/${dn5.body.data.id}`, authB, { action: "cancel" });
  ok("T8e B → إلغاء إشعار A: مرفوض", !xCancel.ok, JSON.stringify(xCancel.body).slice(0, 120));
  const xConvert = await post(`/sales/delivery-notes/${dn6b.body.data.id}/convert`, authB, { type: "CASH" });
  ok("T8f B → تحويل إشعار A: مرفوض", !xConvert.ok, JSON.stringify(xConvert.body).slice(0, 120));
  const xGet = await get(`/sales/delivery-notes/${dn1id}`, authB);
  ok("T8g B → قراءة إشعار A: مرفوض/غير موجود", !xGet.ok, JSON.stringify(xGet.body).slice(0, 120));
  const xProg = await get(`/sales/orders/${o1.id}/delivery-progress`, authB);
  ok("T8h B → تقدم أمر A: مرفوض/غير موجود", !xProg.ok, JSON.stringify(xProg.body).slice(0, 120));

  // ================= T9 — عدّادات الأمر و سلامة القاعدة =================
  console.log("\n■ T9 — عدّاد deliveredQty على سطر الأمر (الإسقاط)");
  const line3 = await db.salesOrderLine.findFirst({ where: { orderId: o2.id } });
  ok("T9a سطر الأمر o2: deliveredQty = 100", eq(line3?.deliveredQty, 100), `${line3?.deliveredQty}`);
  const line5 = await db.salesOrderLine.findFirst({ where: { orderId: o5.id } });
  ok("T9b سطر الأمر o5: deliveredQty = 80", eq(line5?.deliveredQty, 80), `${line5?.deliveredQty}`);

  console.log("\n" + "=".repeat(70));
  console.log(`PHASE 5 — النتيجة: PASS=${PASS} FAIL=${FAIL}`);
}

main();
