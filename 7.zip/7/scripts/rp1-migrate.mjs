// =====================================================================
// RP1-Migrate — ترحيل Legacy إلى ProductPrice (MASTER REPAIR PROMPT — PHASE 1 §2-§4)
// القواعد:
//   · الأعمدة المسطحة (salePrice/costPrice/packSalePrice) موثقة في السكيما
//     كإسقاط بالعملة الأساسية IQD — لذا عملة الصفوف المُرحَّلة = IQD (موثّق، ليس تخميناً).
//   · SALE/PIECE من salePrice (دائماً عند غياب صف نشط — حتى 0 لإغلاق التغطية).
//   · COST/PIECE من costPrice فقط عند > 0.
//   · SALE/PACKAGE من packSalePrice عند packQty>1 والقيمة > 0.
//   · §4 Dedupe: أكثر من صف نشط لنفس (company,product,type,unit,currency)
//     → يُبقى الأحدث (effectiveFrom ثم id) ويُغلق البقية (effectiveTo=now).
//   · Idempotent: التشغيل الثاني لا ينشئ شيئاً.
// الناتج: docs/RP1_MIGRATION_REPORT.md + backups/rp1-migration.json
// =====================================================================
import { PrismaClient } from "@prisma/client";
import { writeFileSync } from "node:fs";

const db = new PrismaClient();
const n = (v) => Number(v ?? 0);
const stats = { products: 0, createdSalePiece: 0, createdCostPiece: 0, createdSalePackage: 0, closedDuplicates: 0, exceptions: [] };

const companies = await db.company.findMany({ select: { id: true, name: true } });

for (const c of companies) {
  const products = await db.product.findMany({
    where: { companyId: c.id, deletedAt: null },
    select: { id: true, name: true, salePrice: true, costPrice: true, packSalePrice: true, packQty: true },
  });
  for (const p of products) {
    stats.products++;
    try {
      const act = await db.productPrice.findMany({ where: { companyId: c.id, productId: p.id, isActive: true } });
      const has = (t, u) => act.some((r) => r.priceType === t && r.unit === u);
      const now = new Date();

      // §4 — إغلاق التكرارات (نفس النوع/الوحدة/العملة) — يُبقى الأحدث
      const groups = new Map();
      for (const r of act) {
        const k = `${r.priceType}|${r.unit}|${r.currency}`;
        (groups.get(k) ?? groups.set(k, []).get(k)).push(r);
      }
      for (const arr of groups.values()) {
        if (arr.length > 1) {
          const sorted = [...arr].sort((a, b) => b.effectiveFrom.getTime() - a.effectiveFrom.getTime() || b.id - a.id);
          const keep = sorted[0];
          for (const dup of sorted.slice(1)) {
            await db.productPrice.update({ where: { id: dup.id }, data: { isActive: false, effectiveTo: now } });
            stats.closedDuplicates++;
          }
          void keep;
        }
      }

      // §2 — SALE/PIECE من الإسقاط IQD
      if (!has("SALE", "PIECE")) {
        await db.productPrice.create({
          data: { companyId: c.id, productId: p.id, priceType: "SALE", unit: "PIECE", currency: "IQD", amount: n(p.salePrice), effectiveFrom: now, createdBy: null },
        });
        stats.createdSalePiece++;
      }
      // §2 — COST/PIECE عند > 0
      if (!has("COST", "PIECE") && n(p.costPrice) > 0) {
        await db.productPrice.create({
          data: { companyId: c.id, productId: p.id, priceType: "COST", unit: "PIECE", currency: "IQD", amount: n(p.costPrice), effectiveFrom: now, createdBy: null },
        });
        stats.createdCostPiece++;
      }
      // §2 — SALE/PACKAGE للمعبأ
      if (n(p.packQty) > 1 && p.packSalePrice != null && n(p.packSalePrice) > 0 && !has("SALE", "PACKAGE")) {
        await db.productPrice.create({
          data: { companyId: c.id, productId: p.id, priceType: "SALE", unit: "PACKAGE", currency: "IQD", amount: n(p.packSalePrice), effectiveFrom: now, createdBy: null },
        });
        stats.createdSalePackage++;
      }
    } catch (e) {
      stats.exceptions.push({ companyId: c.id, productId: p.id, name: p.name, error: String(e).slice(0, 200) });
    }
  }
}

const md = `# RP1 — تقرير ترحيل الأسعار Legacy → ProductPrice\n\n_generated: ${new Date().toISOString()}_\n\n| المؤشر | العدد |\n|---|---|\n| منتجات فُحصت | ${stats.products} |\n| صفوف SALE/PIECE أُنشئت | ${stats.createdSalePiece} |\n| صفوف COST/PIECE أُنشئت | ${stats.createdCostPiece} |\n| صفوف SALE/PACKAGE أُنشئت | ${stats.createdSalePackage} |\n| تكرارات مغلقة (§4) | ${stats.closedDuplicates} |\n| استثناءات (بلا تخمين عملة) | ${stats.exceptions.length} |\n\nعملة كل الصفوف المُرحّلة = **IQD** — وفق توثيق السكيما: الأعمدة المسطحة على products إسقاط بالعملة الأساسية IQD (ليس تخميناً).\n${stats.exceptions.length ? "\n## استثناءات\n\n" + stats.exceptions.map((e) => `- company=${e.companyId} product=${e.productId} (${e.name}): ${e.error}`).join("\n") : ""}\n`;
writeFileSync("docs/RP1_MIGRATION_REPORT.md", md);
writeFileSync("backups/rp1-migration.json", JSON.stringify(stats, null, 2));
console.log(JSON.stringify(stats, null, 2));
await db.$disconnect();
