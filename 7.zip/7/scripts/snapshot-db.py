#!/usr/bin/env python3
# لقطة متسقة لقاعدة البيانات الحية عبر SQLite Backup API (آمنة حتى مع الخادم يعمل)
import sqlite3, sys, os

SRC = "/home/z/my-project/db/custom.db"
DST = sys.argv[1] if len(sys.argv) > 1 else "/home/z/my-project/backups/custom-snapshot-latest.db"

if os.path.exists(DST):
    os.remove(DST)

src = sqlite3.connect(f"file:{SRC}?mode=ro", uri=True)
dst = sqlite3.connect(DST)
src.backup(dst)          # صفحة بصفحة — لقطة متسقة transactionally
dst.commit()

src.close()
dst.close()

# تحقق سريع: عدد الجداول + integrity
chk = sqlite3.connect(DST)
tables = chk.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
integ = chk.execute("PRAGMA integrity_check").fetchone()[0]
chk.close()

size = os.path.getsize(DST)
print(f"snapshot={DST}")
print(f"size={size} bytes ({size//1024}KB)")
print(f"tables={tables}")
print(f"integrity={integ}")
assert integ == "ok", "integrity check failed!"
