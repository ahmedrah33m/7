#!/usr/bin/env bash
# =============================================================
# upload-v4-external.sh — رفع أرشيف v4 إلى خدمات ملفات خارجية
# يجرّب عدة مزودين بالترتيب، ويرفع لِـ 2 ناجحين على الأقل إن أمكن،
# ويتحقق من كل رابط بإعادة التنزيل ومطابقة MD5 قبل اعتماده.
# =============================================================
set -uo pipefail

ROOT="/home/z/my-project"
F="$ROOT/download/sds-system-v4.zip"
MD5="b8dda2900a376c325f96f03524f0f655"
UA="Mozilla/5.0 (X11; Linux x86_64) SDS-Uploader/1.0"
VERIFY="$ROOT/backups/verify-download.zip"
mkdir -p "$ROOT/backups"

say()  { echo -e "\n\033[1;36m==> $*\033[0m"; }
ok()   { echo -e "\033[1;32m✔ $*\033[0m"; }
bad()  { echo -e "\033[1;31m✘ $*\033[0m"; }

GOOD_LINKS=()

verify_link() { # $1 = direct URL
  rm -f "$VERIFY"
  curl -sL -m 300 -A "$UA" "$1" -o "$VERIFY" 2>/dev/null || return 1
  [ -s "$VERIFY" ] || return 1
  [ "$(md5sum "$VERIFY" | cut -d' ' -f1)" = "$MD5" ]
}

# ---------- 1) catbox.moe (دائم) ----------
say "1) المحاولة عبر catbox.moe…"
R="$(curl -s -m 300 -A "$UA" -F reqtype=fileupload -F "fileToUpload=@${F}" https://catbox.moe/user/api.php 2>/dev/null || true)"
if [[ "$R" == https://files.catbox.moe/* ]]; then
  if verify_link "$R"; then ok "catbox: $R (تم التحقق بالتنزيل)"; GOOD_LINKS+=("catbox.moe (دائم): $R"); else bad "catbox رفع لكن التنزيل لا يطابق MD5"; fi
else
  bad "catbox فشل: ${R:0:80}"
fi

# ---------- 2) 0x0.st (طويل الأمد) ----------
say "2) المحاولة عبر 0x0.st…"
H="$(mktemp -p "$ROOT/backups" hdr.XXXX 2>/dev/null || echo "$ROOT/backups/hdr.tmp")"
R="$(curl -s -m 300 -A "$UA" -D "$H" -F "file=@${F}" https://0x0.st 2>/dev/null || true)"
if [[ "$R" == https://0x0.st/* ]]; then
  if verify_link "$R"; then
    TOKEN="$(grep -i '^x-token' "$H" 2>/dev/null | tr -d '\r' | awk '{print $2}')"
    ok "0x0.st: $R (تم التحقق بالتنزيل)${TOKEN:+ [رمز الحذف: $TOKEN]}"
    GOOD_LINKS+=("0x0.st (~سنة): $R${TOKEN:+ — رمز الحذف: $TOKEN}")
  else bad "0x0.st رفع لكن التنزيل لا يطابق MD5"; fi
else
  bad "0x0.st فشل: ${R:0:80}"
fi
rm -f "$H"

# ---------- 3) gofile.io ----------
say "3) المحاولة عبر gofile.io…"
SRV="$(curl -s -m 30 https://api.gofile.io/servers 2>/dev/null | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"]["servers"][0]["name"])' 2>/dev/null || true)"
if [ -n "${SRV:-}" ]; then
  R="$(curl -s -m 300 -A "$UA" -F "file=@${F}" "https://${SRV}.gofile.io/contents/uploadfile" 2>/dev/null || true)"
  PAGE="$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"]["downloadPage"])' 2>/dev/null || true)"
  if [ -n "${PAGE:-}" ]; then
    ok "gofile: $PAGE (صفحة تنزيل — لا يمكن مطابقة MD5 مباشرة)"
    GOOD_LINKS+=("gofile.io: $PAGE")
  else bad "gofile فشل: ${R:0:80}"; fi
else
  bad "gofile: تعذر جلب خادم"
fi

# ---------- 4) litterbox (72 ساعة) ----------
say "4) المحاولة عبر litterbox (72 ساعة)…"
R="$(curl -s -m 300 -A "$UA" -F reqtype=fileupload -F time=72h -F "fileToUpload=@${F}" https://litterbox.catbox.moe/resources/internals/api.php 2>/dev/null || true)"
if [[ "$R" == https://litter.catbox.moe/* ]]; then
  if verify_link "$R"; then ok "litterbox: $R (تم التحقق بالتنزيل)"; GOOD_LINKS+=("litterbox (72 ساعة): $R"); else bad "litterbox رفع لكن التحقق فشل"; fi
else
  bad "litterbox فشل: ${R:0:80}"
fi

# ---------- 5) transfer.sh ----------
say "5) المحاولة عبر transfer.sh…"
R="$(curl -s -m 300 -A "$UA" -T "${F}" "https://transfer.sh/sds-system-v4.zip" 2>/dev/null || true)"
if [[ "$R" == https://*transfer.sh/* ]]; then
  if verify_link "$R"; then ok "transfer.sh: $R (تم التحقق بالتنزيل)"; GOOD_LINKS+=("transfer.sh: $R"); else bad "transfer.sh رفع لكن التحقق فشل"; fi
else
  bad "transfer.sh فشل: ${R:0:80}"
fi

# ---------- النتيجة ----------
rm -f "$VERIFY"
echo
echo "================================================="
if [ ${#GOOD_LINKS[@]} -gt 0 ]; then
  echo "روابط جاهزة (${#GOOD_LINKS[@]}):"
  for L in "${GOOD_LINKS[@]}"; do echo "  - $L"; done
  echo "MD5 المتوقع: $MD5"
else
  echo "فشلت كل المحاولات — لا روابط."
fi
