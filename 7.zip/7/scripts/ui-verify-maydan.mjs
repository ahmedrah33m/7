// =====================================================================
// ui-verify-maydan.mjs — تحقق بصري من هوية «ميدان» الجديدة
// (شاشة الدخول الجديدة بلا حسابات تجريبية + الهيدر الجديد بعد الدخول)
// المخرجات: لقطات PNG في download/ + تقرير نصي
// =====================================================================
import { chromium } from "playwright";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const OUT = "/home/z/my-project/download";

const results = [];
function check(name, ok, extra = "") {
  results.push(`${ok ? "✓" : "✗"} ${name}${extra ? " — " + extra : ""}`);
  if (!ok) process.exitCode = 1;
}

const browser = await chromium.launch({ headless: true });

try {
  // ---------- 1) شاشة الدخول (سطح المكتب) ----------
  const page = await browser.newPage({ viewport: { width: 1366, height: 850 } });
  const consoleErrors = [];
  page.on("console", (m) => { if (m.type() === "error") consoleErrors.push(m.text().slice(0, 150)); });
  page.on("pageerror", (e) => consoleErrors.push(String(e).slice(0, 150)));

  await page.goto(BASE, { waitUntil: "networkidle", timeout: 30000 });
  await page.getByLabel("اسم المستخدم").waitFor({ timeout: 20000 });
  check("شاشة الدخول تُعرض (اسم المستخدم مرئي)", true);

  const bodyText = await page.locator("body").innerText();
  check("الاسم الجديد ظاهر: «نظام ميدان لمبيعات والتوزيع»", bodyText.includes("ميدان") && bodyText.includes("لمبيعات والتوزيع"));
  check("لا توجد «حسابات تجريبية»", !bodyText.includes("حسابات تجريبية"));
  check("لا توجد «اضغط لتعبئتها»", !bodyText.includes("اضغط لتعبئتها"));

  await page.screenshot({ path: `${OUT}/معاينة-شاشة-الدخول-الجديدة.png`, fullPage: false });
  check("لقطة شاشة الدخول (سطح المكتب) محفوظة", true, "download/معاينة-شاشة-الدخول-الجديدة.png");

  // ---------- 2) الدخول: admin → اختيار شركة/فرع → اللوحة ----------
  await page.getByLabel("اسم المستخدم").fill("admin");
  await page.locator("input[type='password']").first().fill("Admin@123");
  await page.locator("button[type=submit]").click();

  // اختيار الشركة إن ظهرت — أول زر داخل شبكة القائمة ثم «متابعة»
  const continueBtn = page.getByRole("button", { name: "متابعة" });
  try {
    await continueBtn.waitFor({ state: "visible", timeout: 8000 });
    await page.locator(".grid button").first().click();
    await continueBtn.click();
  } catch { /* شركة واحدة */ }

  // اختيار الفرع إن ظهر — أول زر في القائمة ثم «بدء الجلسة»
  try {
    await page.getByText("اختر الفرع").waitFor({ state: "visible", timeout: 8000 });
    await page.locator(".grid button").first().click();
    await page.getByRole("button", { name: "بدء الجلسة" }).click();
  } catch { /* بلا شاشة فروع */ }

  try {
    await page.getByText("نظرة عامة").first().waitFor({ timeout: 30000 });
    check("الدخول نجح ووصلنا للوحة (نظرة عامة مرئية)", true);
  } catch {
    await page.screenshot({ path: `${OUT}/debug-login-state.png`, fullPage: false });
    const t = await page.locator("body").innerText();
    console.log("[DEBUG] body text at failure:\n" + t.slice(0, 600));
    throw new Error("لم نصل للوحة — راجع download/debug-login-state.png");
  }

  const headerText = await page.locator("header").innerText();
  check("الهيدر الجديد يحمل «ميدان»", headerText.includes("ميدان"));
  check("الهيدر يعرض الشركة النشطة", headerText.includes("الشركة") || headerText.length > 10, headerText.split("\n").slice(0, 4).join(" | "));

  await page.waitForTimeout(1200);
  await page.screenshot({ path: `${OUT}/معاينة-الهيدر-الجديد.png`, fullPage: false });
  check("لقطة الهيدر الجديد محفوظة", true, "download/معاينة-الهيدر-الجديد.png");

  // ---------- 3) شاشة الدخول (موبايل) ----------
  const mp = await browser.newPage({ viewport: { width: 390, height: 844 } });
  await mp.goto(BASE, { waitUntil: "networkidle", timeout: 30000 });
  await mp.getByLabel("اسم المستخدم").waitFor({ timeout: 20000 });
  await mp.screenshot({ path: `${OUT}/معاينة-الدخول-موبايل.png`, fullPage: false });
  check("لقطة الموبايل محفوظة", true, "download/معاينة-الدخول-موبايل.png");
  await mp.close();

  check("لا أخطاء console/pageerror أثناء الجولة", consoleErrors.length === 0, consoleErrors.slice(0, 3).join(" ∥ "));
} finally {
  await browser.close();
}

console.log("==== UI VERIFY (ميدان) ====");
for (const r of results) console.log(r);
