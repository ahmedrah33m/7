import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const companies = await db.company.findMany({ where: { deletedAt: null }, select: { id: true, code: true, name: true } });
console.log("COMPANIES:", JSON.stringify(companies, null, 1));
const users = await db.user.findMany({
  where: { deletedAt: null },
  select: { id: true, username: true, companyId: true, scopeType: true, companyAccess: { select: { companyId: true, isPrimary: true } } },
  take: 12,
});
console.log("USERS:", JSON.stringify(users, null, 1));
await db.$disconnect();
