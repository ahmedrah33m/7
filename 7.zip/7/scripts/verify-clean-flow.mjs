// فحص نظيف: دخول عادي بدون أي تلاعب — هل يظهر AUTH_001؟
import { chromium } from "playwright";
const BASE = "http://localhost:3000";
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: "ar" });
const page = await ctx.newPage();
const errors = [];
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text().slice(0, 150)); });
await page.goto(BASE + "/", { waitUntil: "networkidle" });
await page.locator("input").first().fill("admin");
await page.locator('input[type="password"]').fill("Admin@123");
await page.getByRole("button", { name: /دخول/ }).click();
await page.waitForSelector("aside", { timeout: 20000 });
await page.waitForTimeout(5000); // انتظار أي توستات متأخرة
const toasts = await page.locator('[data-sonner-toast]').allInnerTexts();
console.log("TOASTS:", JSON.stringify(toasts));
console.log("AUTH_001 present:", toasts.some(t => t.includes("AUTH_001")));
console.log("console errors:", errors.length ? errors.join(" | ") : "none");
await page.screenshot({ path: "/home/z/my-project/download/verify3-clean-login-flow.png" });
await browser.close();
