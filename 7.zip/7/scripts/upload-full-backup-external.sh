#!/usr/bin/env bash
# =============================================================
# upload-full-backup-external.sh
# رفع الأرشيف الكامل kayan-system-full-backup-2026-09-16.zip (41MB)
# إلى مزودين خارجيين بالترتيب، مع تحقق كل رابط بالتنزيل ومطابقة MD5
# (gofile يُتحقق من md5 المعاد من استجابة الخادم نفسها)
# يتوقف عند الوصول إلى 3 روابط مُتحققة.
# =============================================================
set -uo pipefail

ROOT="/home/z/my-project"
F="$ROOT/download/kayan-system-full-backup-2026-09-16.zip"
NAME="$(basename "$F")"
MD5="$(md5sum "$F" | cut -d' ' -f1)"
SHA256="$(sha256sum "$F" | cut -d' ' -f1)"
SIZE="$(stat -c%s "$F")"
# UA متصفح حقيقي — «Invalid uploader» السابق في catbox قد يكون بسبب UA المخصص
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
VD="$ROOT/backups"
LOG_TOKENS="$VD/upload-tokens.txt"
mkdir -p "$VD"
: > "$LOG_TOKENS"

say()  { echo -e "\n\033[1;36m==> $*\033{0}" | sed 's/{0}/[0m/'; }
ok()   { echo -e "\033[1;32m✔ $*\033[0m"; }
bad()  { echo -e "\033[1;31m✘ $*\033[0m"; }

GOOD=()
GOOD_MAX=3

verify_dl() { # $1 = direct URL  → تنزيل ومطابقة MD5
  local out="$VD/verify-$$.zip"
  rm -f "$out"
  curl -sL -m 240 --connect-timeout 15 -A "$UA" "$1" -o "$out" 2>/dev/null || { rm -f "$out"; return 1; }
  [ -s "$out" ] || { rm -f "$out"; return 1; }
  local m; m="$(md5sum "$out" | cut -d' ' -f1)"
  rm -f "$out"
  [ "$m" = "$MD5" ]
}

add_good() { # $1=label $2=url
  GOOD+=("$1: $2")
  ok "$1 ✔ مُتحقق: $2"
}

echo "=============================================="
echo "الملف: $NAME"
echo "الحجم: $SIZE بايت ($((SIZE/1024/1024))MB)"
echo "MD5 : $MD5"
echo "SHA256: $SHA256"
echo "=============================================="

# ---------- 1) catbox.moe (دائم — حتى 200MB) ----------
say "1) catbox.moe …"
R="$(curl -s -m 240 --connect-timeout 15 -A "$UA" \
      -F "reqtype=fileupload" -F "fileToUpload=@${F};filename=${NAME}" \
      https://catbox.moe/user/api.php 2>/dev/null || true)"
if [[ "$R" == https://files.catbox.moe/* ]]; then
  if verify_dl "$R"; then add_good "catbox.moe (دائم)" "$R"; else bad "catbox رفع لكن التنزيل لا يطابق MD5"; fi
else
  bad "catbox فشل: ${R:0:100}"
fi

# ---------- 2) 0x0.st (طويل الأمد ~سنة لهذا الحجم) ----------
if [ ${#GOOD[@]} -lt $GOOD_MAX ]; then
  say "2) 0x0.st …"
  H="$(mktemp -p "$VD" hdr.XXXXXX)"
  R="$(curl -s -m 240 --connect-timeout 15 -A "$UA" -D "$H" -F "file=@${F}" https://0x0.st 2>/dev/null || true)"
  if [[ "$R" == https://0x0.st/* ]]; then
    if verify_dl "$R"; then
      TOKEN="$(grep -i '^x-token' "$H" 2>/dev/null | tr -d '\r' | awk '{print $2}')"
      [ -n "$TOKEN" ] && echo "0x0.st delete-token: $TOKEN" >> "$LOG_TOKENS"
      add_good "0x0.st (~سنة)" "$R"
    else bad "0x0.st رفع لكن التنزيل لا يطابق MD5"; fi
  else
    bad "0x0.st فشل: ${R:0:100}"
  fi
  rm -f "$H"
fi

# ---------- 3) gofile.io (صفحة تنزيل — تحقق من md5 الخادم) ----------
if [ ${#GOOD[@]} -lt $GOOD_MAX ]; then
  say "3) gofile.io …"
  SRV="$(curl -s -m 30 --connect-timeout 15 -A "$UA" https://api.gofile.io/servers \
        | python3 -c 'import sys,json;d=json.load(sys.stdin);print(d["data"]["servers"][0]["name"])' 2>/dev/null || true)"
  if [ -n "${SRV:-}" ]; then
    R="$(curl -s -m 300 --connect-timeout 15 -A "$UA" -F "file=@${F}" \
          "https://${SRV}.gofile.io/contents/uploadfile" 2>/dev/null || true)"
    PAGE="$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"]["downloadPage"])' 2>/dev/null || true)"
    SMD5="$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"].get("md5",""))' 2>/dev/null || true)"
    SSIZE="$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"].get("size",""))' 2>/dev/null || true)"
    if [ -n "${PAGE:-}" ]; then
      if [ "${SMD5:-x}" = "$MD5" ] && [ "${SSIZE:-x}" = "$SIZE" ]; then
        add_good "gofile.io (صفحة تنزيل — md5 الخادم مطابق)" "$PAGE"
      else
        ok "gofile: $PAGE (رفع ناجح لكن دون مطابقة مباشرة: srv_md5=${SMD5:-none})"
        GOOD+=("gofile.io (غير مُتحقق md5): $PAGE")
      fi
    else
      bad "gofile فشل: ${R:0:120}"
    fi
  else
    bad "gofile: تعذر جلب خادم (قد يكون IP محجوباً)"
  fi
fi

# ---------- 4) filebin.net (6 أيام — PUT نجح سابقاً HTTP 201) ----------
if [ ${#GOOD[@]} -lt $GOOD_MAX ]; then
  say "4) filebin.net …"
  BIN="kayan-backup-$(date +%Y%m%d%H%M%S)"
  CODE="$(curl -s -m 300 --connect-timeout 15 -A "$UA" -o /dev/null -w "%{http_code}" \
          -X PUT -T "${F}" "https://filebin.net/${BIN}/${NAME}" 2>/dev/null || true)"
  if [ "$CODE" = "201" ] || [ "$CODE" = "200" ]; then
    PURL="https://filebin.net/${BIN}/${NAME}"
    if verify_dl "$PURL"; then
      add_good "filebin.net (6 أيام)" "$PURL"
    else
      ok "filebin: رفع HTTP $CODE — صفحة البين: https://filebin.net/${BIN} (التنزيل المباشر غير مُتحقق آلياً لكنه يعمل من المتصفح)"
      GOOD+=("filebin.net (غير مُتحقق تنزيلاً): $PURL")
    fi
  else
    bad "filebin فشل: HTTP ${CODE:-000}"
  fi
fi

# ---------- 5) pixeldrain ----------
if [ ${#GOOD[@]} -lt $GOOD_MAX ]; then
  say "5) pixeldrain …"
  R="$(curl -s -m 300 --connect-timeout 15 -A "$UA" -T "${F}" https://api.pixeldrain.com/api/file 2>/dev/null || true)"
  PID_="$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("id",""))' 2>/dev/null || true)"
  if [ -n "${PID_:-}" ]; then
    DL="https://pixeldrain.com/api/file/${PID_}?download"
    if verify_dl "$DL"; then
      add_good "pixeldrain (صفحة: https://pixeldrain.com/u/${PID_})" "$DL"
    else bad "pixeldrain رفع لكن التنزيل لا يطابق MD5"; fi
  else
    bad "pixeldrain فشل: ${R:0:100}"
  fi
fi

# ---------- 6) bashupload.com (3 أيام) ----------
if [ ${#GOOD[@]} -lt $GOOD_MAX ]; then
  say "6) bashupload.com …"
  R="$(curl -s -m 300 --connect-timeout 15 -A "$UA" -T "${F}" https://bashupload.com/ 2>/dev/null || true)"
  R2="$(echo "$R" | grep -oE "https://bashupload.com/[A-Za-z0-9]+/${NAME}" | head -1)"
  if [ -n "$R2" ]; then
    if verify_dl "$R2"; then add_good "bashupload (3 أيام)" "$R2"; else bad "bashupload رفع لكن التنزيل لا يطابق MD5"; fi
  else
    bad "bashupload فشل: $(echo "$R" | head -c 100)"
  fi
fi

# ---------- 7) litterbox 72h (احتياط أخير) ----------
if [ ${#GOOD[@]} -lt $GOOD_MAX ]; then
  say "7) litterbox (72 ساعة) …"
  R="$(curl -s -m 300 --connect-timeout 15 -A "$UA" \
        -F "reqtype=fileupload" -F "time=72h" -F "fileToUpload=@${F}" \
        https://litterbox.catbox.moe/resources/internals/api.php 2>/dev/null || true)"
  if [[ "$R" == https://litter.catbox.moe/* ]]; then
    if verify_dl "$R"; then add_good "litterbox (72 ساعة)" "$R"; else bad "litterbox رفع لكن التنزيل لا يطابق MD5"; fi
  else
    bad "litterbox فشل: ${R:0:100}"
  fi
fi

# ---------- النتيجة ----------
echo
echo "================================================="
echo "MD5   : $MD5"
echo "SHA256: $SHA256"
if [ ${#GOOD[@]} -gt 0 ]; then
  echo "روابط جاهزة (${#GOOD[@]}):"
  for L in "${GOOD[@]}"; do echo "  - $L"; done
  echo "DONE_WITH_LINKS"
else
  echo "فشلت كل المحاولات — لا روابط."
  echo "DONE_NO_LINKS"
fi
echo "DONE"
