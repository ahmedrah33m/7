#!/usr/bin/env bash
# =============================================================
# upload-v4-more-hosts.sh — مزودون إضافيون + تحقق رابط gofile الحالي
# =============================================================
set -uo pipefail
ROOT="/home/z/my-project"
F="$ROOT/download/sds-system-v4.zip"
MD5="b8dda2900a376c325f96f03524f0f655"
UA="Mozilla/5.0 (X11; Linux x86_64) SDS-Uploader/1.0"
VERIFY="$ROOT/backups/verify-download.zip"
mkdir -p "$ROOT/backups"
say() { echo -e "\n\033[1;36m==> $*\033[0m"; }
ok()  { echo -e "\033[1;32m✔ $*\033[0m"; }
bad() { echo -e "\033[1;31m✘ $*\033[0m"; }

verify_link() {
  rm -f "$VERIFY"
  curl -sL -m 300 -A "$UA" "$1" -o "$VERIFY" 2>/dev/null || return 1
  [ -s "$VERIFY" ] || return 1
  [ "$(md5sum "$VERIFY" | cut -d' ' -f1)" = "$MD5" ]
}

# ---------- تشخيص 0x0.st سريع ----------
say "تشخيص 0x0.st…"
curl -sS -m 20 -A "$UA" -o /dev/null -w "HTTP:%{http_code} time:%{time_total}s\n" https://0x0.st 2>&1 | tail -2

# ---------- x0.at ----------
say "المحاولة عبر x0.at…"
R="$(curl -s -m 300 -A "$UA" -F "file=@${F}" https://x0.at 2>/dev/null || true)"
if [[ "$R" == https://x0.at/* ]]; then
  if verify_link "$R"; then ok "x0.at: $R (مُتحقق بالتنزيل)"; else bad "x0.at رفع لكن MD5 لا يطابق"; fi
else bad "x0.at فشل: ${R:0:100}"; fi

# ---------- pixeldrain ----------
say "المحاولة عبر pixeldrain…"
R="$(curl -s -m 300 -A "$UA" -T "${F}" https://api.pixeldrain.com/api/file 2>/dev/null || true)"
PID_="$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("id",""))' 2>/dev/null || true)"
if [ -n "${PID_:-}" ]; then
  DL="https://pixeldrain.com/api/file/${PID_}?download"
  if verify_link "$DL"; then ok "pixeldrain: https://pixeldrain.com/u/${PID_} (مُتحقق بالتنزيل)"; else bad "pixeldrain رفع لكن MD5 لا يطابق"; fi
else bad "pixeldrain فشل: ${R:0:100}"; fi

# ---------- temp.sh ----------
say "المحاولة عبر temp.sh…"
R="$(curl -s -m 300 -A "$UA" -T "${F}" https://temp.sh/sds-system-v4.zip 2>/dev/null || true)"
if [[ "$R" == https://temp.sh/* ]]; then
  if verify_link "$R"; then ok "temp.sh: $R (مُتحقق بالتنزيل)"; else bad "temp.sh رفع لكن MD5 لا يطابق"; fi
else bad "temp.sh فشل: ${R:0:100}"; fi

# ---------- uguu.se ----------
say "المحاولة عبر uguu.se…"
R="$(curl -s -m 300 -A "$UA" -F "files[]=@${F}" "https://uguu.se/upload?output=text" 2>/dev/null || true)"
if [[ "$R" == https://*uguu* ]]; then
  if verify_link "$R"; then ok "uguu: $R (مُتحقق بالتنزيل)"; else bad "uguu رفع لكن MD5 لا يطابق"; fi
else bad "uguu فشل: ${R:0:100}"; fi

# ---------- تحقق رابط gofile المرفوع سابقاً عبر API ----------
say "التحقق من رفع gofile الحالي (0u2GDq7J) عبر API…"
J="$(curl -s -m 30 -A "$UA" "https://api.gofile.io/contents/0u2GDq7J?wt=4fd6sg89d7s6" 2>/dev/null || true)"
echo "$J" | head -c 300; echo
DL="$(echo "$J" | python3 -c '
import sys,json
d=json.load(sys.stdin)
def walk(n):
    if isinstance(n,dict):
        if n.get("type")=="file" and n.get("link"): return n["link"]
        for v in n.get("children",{}).values() if isinstance(n.get("children"),dict) else []:
            r=walk(v)
            if r: return r
    return None
print(walk(d.get("data",{})) or "")' 2>/dev/null || true)"
if [ -n "${DL:-}" ]; then
  if verify_link "$DL"; then ok "gofile مُتحقق بالتنزيل المباشر: $DL"; else bad "gofile: الرابط المباشر وجد لكن MD5 لا يطابق"; fi
else
  echo "  (تعذر جلب رابط مباشر من API — صفحة التنزيل تبقى صالحة)"
fi

rm -f "$VERIFY"
echo; echo "انتهى"
