// =====================================================================
// Document-state machines acceptance suite (Task 24):
//   §14.2 transfer 6-state machine (DRAFT→REQUESTED→APPROVED→IN_TRANSIT→RECEIVED,
//        cancel only before issue, double-receive/double-issue blocked)
//   §8.5  invoice financial states (PARTIALLY_PAID → PAID; OVERDUE derived)
//   §8.3/8.4 order partial conversion (qty_fulfilled → PARTIALLY_FULFILLED → INVOICED)
//   §62   settings: 14 manageable groups (GET/PUT + unknown key + cashier 403)
//   §7    product brand + min_sale_price (enforce via sales.enforce_min_price)
// Exit 0 = all pass.
// =====================================================================

import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000/api/v1";
const db = new PrismaClient();

let pass = 0;
let fail = 0;

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  ✅ ${name}`);
  } else {
    fail++;
    console.log(`  ❌ ${name} ${detail ? "— " + detail : ""}`);
  }
}

async function req(method: string, path: string, token?: string, body?: unknown): Promise<{ status: number; body: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json };
}

function errCode(r: { body: any }): string {
  return r.body?.error?.code ?? r.body?.code ?? "";
}

async function main() {
  console.log("═══ Document-state machines verification (Task 24) ═══");

  // 0) logins
  const admin = await req("POST", "/auth/login", undefined, { username: "admin", password: "Admin@123" });
  check("admin login", admin.status < 300 && admin.body.success);
  const T = admin.body.data?.access_token as string;

  const cashier = await req("POST", "/auth/login", undefined, { username: "cashier", password: "Cashier@123" });
  check("cashier login", cashier.status < 300);
  const CT = cashier.body.data?.access_token as string;

  const me = await req("GET", "/auth/me", T);
  const WH_MAIN: number = me.body.data?.warehouses?.[0]?.id ?? 1;

  // warehouses: need two distinct within admin scope (read from db — no
  // public warehouses route; same dynamic-fixture style as the other suites)
  const whRows = await db.warehouse.findMany({ where: { deletedAt: null, isActive: true }, take: 2 });
  const wA: any = whRows[0];
  const wB: any = whRows[1];
  check("two warehouses available", !!wA && !!wB, JSON.stringify(whRows).slice(0, 120));

  // a product with enough stock (≥10) in the source warehouse
  const balAll = await req("GET", `/inventory/balances?warehouse_id=${wA.id}&per_page=50`, T);
  const balRows: any[] = balAll.body.data ?? [];
  const balPick: any = balRows.find((b) => b.qty >= 10) ?? balRows[0];
  check("stocked product fixture", !!balPick, JSON.stringify(balRows.slice(0, 2)).slice(0, 160));
  const PID = balPick.product_id as number;
  const prod: any = { id: PID, name: balPick.product?.name ?? "" };
  const qtyBefore: number = balPick.qty ?? 0;
  const otherPick: any = balRows.find((b) => b.product_id !== PID);
  const otherProd: any = otherPick ? { id: otherPick.product_id, name: otherPick.product?.name } : null;

  // =====================================================================
  console.log("── A. §14.2 transfer 6-state machine ──");

  const mkTransfer = async () =>
    req("POST", "/inventory/transfers", T, {
      from_warehouse_id: wA.id,
      to_warehouse_id: wB.id,
      auto_dispatch: false,
      lines: [{ product_id: PID, qty: 2 }],
    });

  // A1: create as DRAFT (no stock effect)
  const t1 = await mkTransfer();
  check("create auto_dispatch=false → DRAFT", t1.status < 300 && t1.body.data?.status === "DRAFT", JSON.stringify(t1.body).slice(0, 140));
  const tid = t1.body.data?.id as number;
  const balDraft = await req("GET", `/inventory/balances?warehouse_id=${wA.id}&product_id=${PID}`, T);
  check("DRAFT has NO stock effect", (balDraft.body.data?.[0]?.qty ?? qtyBefore) === qtyBefore);

  // A2: receive from DRAFT blocked
  const r0 = await req("POST", `/inventory/transfers/${tid}/receive`, T, {});
  check("receive from DRAFT → VAL_004", r0.status === 409 && errCode(r0) === "VAL_004", JSON.stringify(r0.body).slice(0, 120));

  // A3: cancel from DRAFT allowed
  const c0 = await req("POST", `/inventory/transfers/${tid}/cancel`, T);
  check("cancel from DRAFT → CANCELLED", c0.status < 300 && c0.body.data?.status === "CANCELLED", JSON.stringify(c0.body).slice(0, 120));
  const c0b = await req("POST", `/inventory/transfers/${tid}/cancel`, T);
  check("double cancel → VAL_004", c0b.status === 409 && errCode(c0b) === "VAL_004");

  // A4: full happy path DRAFT→REQUESTED→APPROVED→IN_TRANSIT→RECEIVED
  const t2 = await mkTransfer();
  const tid2 = t2.body.data?.id as number;
  const rq = await req("POST", `/inventory/transfers/${tid2}/request`, T);
  check("request DRAFT → REQUESTED", rq.status < 300 && rq.body.data?.status === "REQUESTED", JSON.stringify(rq.body).slice(0, 120));
  const rq2 = await req("POST", `/inventory/transfers/${tid2}/request`, T);
  check("double request → VAL_004", rq2.status === 409 && errCode(rq2) === "VAL_004");

  // cancel from REQUESTED still allowed (before issue)
  const t3 = await mkTransfer();
  const tid3 = t3.body.data?.id as number;
  await req("POST", `/inventory/transfers/${tid3}/request`, T);
  const c3 = await req("POST", `/inventory/transfers/${tid3}/cancel`, T);
  check("cancel from REQUESTED → CANCELLED", c3.status < 300 && c3.body.data?.status === "CANCELLED");

  const ap = await req("POST", `/inventory/transfers/${tid2}/approve`, T);
  check("approve REQUESTED → APPROVED", ap.status < 300 && ap.body.data?.status === "APPROVED", JSON.stringify(ap.body).slice(0, 120));
  const ap2 = await req("POST", `/inventory/transfers/${tid2}/approve`, T);
  check("double approve → VAL_004", ap2.status === 409 && errCode(ap2) === "VAL_004");

  const balPre = await req("GET", `/inventory/balances?warehouse_id=${wA.id}&product_id=${PID}`, T);
  const qtyPre: number = balPre.body.data?.[0]?.qty ?? qtyBefore;

  const is1 = await req("POST", `/inventory/transfers/${tid2}/issue`, T);
  check("issue APPROVED → IN_TRANSIT", is1.status < 300 && is1.body.data?.status === "IN_TRANSIT", JSON.stringify(is1.body).slice(0, 120));

  const balPost = await req("GET", `/inventory/balances?warehouse_id=${wA.id}&product_id=${PID}`, T);
  check("issue deducted source (OUT)", (balPost.body.data?.[0]?.qty ?? qtyPre) === qtyPre - 2, `before=${qtyPre} after=${balPost.body.data?.[0]?.qty}`);

  const is2 = await req("POST", `/inventory/transfers/${tid2}/issue`, T);
  check("double issue → VAL_004", is2.status === 409 && errCode(is2) === "VAL_004");

  const c4 = await req("POST", `/inventory/transfers/${tid2}/cancel`, T);
  check("cancel after issue → VAL_004", c4.status === 409 && errCode(c4) === "VAL_004");

  const rc1 = await req("POST", `/inventory/transfers/${tid2}/receive`, T, {});
  check("receive IN_TRANSIT → RECEIVED", rc1.status < 300 && rc1.body.data?.status === "RECEIVED", JSON.stringify(rc1.body).slice(0, 120));

  const balDest = await req("GET", `/inventory/balances?warehouse_id=${wB.id}&product_id=${PID}`, T);
  check("receive added destination (IN)", (balDest.body.data?.[0]?.qty ?? 0) >= 2, `dest qty=${balDest.body.data?.[0]?.qty}`);

  const rc2 = await req("POST", `/inventory/transfers/${tid2}/receive`, T, {});
  check("double receive → VAL_004", rc2.status === 409 && errCode(rc2) === "VAL_004");

  // cashier cannot approve (no inventory.transfers.approve grant)
  const t4 = await mkTransfer();
  const tid4 = t4.body.data?.id as number;
  await req("POST", `/inventory/transfers/${tid4}/request`, T);
  const apC = await req("POST", `/inventory/transfers/${tid4}/approve`, CT);
  check("cashier approve → 403 PERM_001", apC.status === 403 && errCode(apC) === "PERM_001", JSON.stringify(apC.body).slice(0, 120));
  // cleanup: cancel the draft
  await req("POST", `/inventory/transfers/${tid4}/cancel`, T);

  // =====================================================================
  console.log("── B. §8.5 invoice financial states ──");

  const custs = await req("GET", "/customers?per_page=10", T);
  const creditCust: any = (custs.body.data ?? []).find((c: any) => (c.credit_limit ?? 0) >= 500000 || c.type === "CREDIT") ?? (custs.body.data ?? [])[0];
  check("customer fixture", !!creditCust?.id);
  const CID = creditCust.id;

  // Test isolation: kill any active approval rules (would divert credit
  // invoices to PENDING_APPROVAL) and raise the credit ceiling for the
  // fixture customer (original restored at cleanup).
  await db.approvalRule.deleteMany({});
  const origLimit = creditCust.credit_limit ?? 0;
  await db.customer.update({ where: { id: CID }, data: { creditLimit: 100_000_000 } });

  // credit invoice with due date far in the future
  const far = new Date(Date.now() + 30 * 86400_000).toISOString().slice(0, 10);
  const inv1 = await req("POST", "/sales/invoices", T, {
    customer_id: CID,
    warehouse_id: WH_MAIN,
    type: "CREDIT",
    due_date: far,
    lines: [{ product_id: PID, qty: 1 }],
  });
  check("credit invoice created", inv1.status < 300 && !!inv1.body.data?.id, JSON.stringify(inv1.body).slice(0, 160));
  const inv1Id = inv1.body.data?.id as number;
  const inv1Get = await req("GET", `/sales/invoices/${inv1Id}`, T);
  const inv1Total: number = inv1Get.body.data?.grand_total ?? inv1.body.data?.grand_total ?? 0;
  check("new credit invoice → POSTED (nothing paid)", inv1Get.status < 300 && inv1Get.body.data?.status === "POSTED", `status=${inv1Get.body.data?.status}`);

  const cashboxes = await req("GET", "/finance/cashboxes", T);
  const cbId = (cashboxes.body.data ?? [])[0]?.id as number;

  // partial collection → PARTIALLY_PAID
  const part = Math.max(1, Math.round(inv1Total / 2));
  const col1 = await req("POST", "/finance/transactions", T, {
    kind: "collection",
    customer_id: CID,
    cashbox_id: cbId,
    amount: part,
    invoice_id: inv1Id,
    method: "CASH",
  });
  check("partial collection 200", col1.status < 300, JSON.stringify(col1.body).slice(0, 160));
  const inv1After1 = await req("GET", `/sales/invoices/${inv1Id}`, T);
  check("after partial → status PARTIALLY_PAID", inv1After1.body.data?.status === "PARTIALLY_PAID", `status=${inv1After1.body.data?.status}`);

  // full remaining → PAID
  const remaining = Math.round((inv1Total - part) * 100) / 100;
  const col2 = await req("POST", "/finance/transactions", T, {
    kind: "collection",
    customer_id: CID,
    cashbox_id: cbId,
    amount: remaining,
    invoice_id: inv1Id,
    method: "CARD",
  });
  check("remaining collection 200", col2.status < 300, JSON.stringify(col2.body).slice(0, 160));
  const inv1After2 = await req("GET", `/sales/invoices/${inv1Id}`, T);
  check("after full → status PAID", inv1After2.body.data?.status === "PAID", `status=${inv1After2.body.data?.status}`);

  // OVERDUE derived: credit invoice with past due date
  const past = new Date(Date.now() - 10 * 86400_000).toISOString().slice(0, 10);
  const inv2 = await req("POST", "/sales/invoices", T, {
    customer_id: CID,
    warehouse_id: WH_MAIN,
    type: "CREDIT",
    due_date: past,
    lines: [{ product_id: PID, qty: 1 }],
  });
  const inv2Id = inv2.body.data?.id as number;
  const list = await req("GET", `/sales/invoices?per_page=50`, T);
  const row = (list.body.data ?? []).find((x: any) => x.id === inv2Id);
  check("past-due credit invoice → financial_status OVERDUE", row?.financial_status === "OVERDUE", JSON.stringify(row).slice(0, 160));

  // =====================================================================
  console.log("── C. §8.3/8.4 order partial conversion ──");

  const ord = await req("POST", "/sales/orders", T, {
    customer_id: CID,
    warehouse_id: WH_MAIN,
    order_date: new Date().toISOString().slice(0, 10),
    lines: [{ product_id: PID, qty: 8 }],
  });
  check("order created", ord.status < 300, JSON.stringify(ord.body).slice(0, 160));
  const ordId = ord.body.data?.id as number;
  const conf = await req("POST", `/sales/orders/${ordId}/confirm`, T);
  check("order confirmed (reserves 8)", conf.status < 300 && conf.body.data?.status === "CONFIRMED", JSON.stringify(conf.body).slice(0, 140));

  // partial convert 3 of 8
  const cv1 = await req("POST", `/sales/orders/${ordId}/convert`, T, {
    type: "CASH",
    partial_lines: [{ product_id: PID, qty: 3 }],
  });
  check("partial convert 200 (3/8)", cv1.status < 300 && cv1.body.data?.partially_fulfilled === true, JSON.stringify(cv1.body).slice(0, 200));
  const ordAfter1 = await req("GET", `/sales/orders/${ordId}`, T);
  check("order → PARTIALLY_FULFILLED", ordAfter1.body.data?.status === "PARTIALLY_FULFILLED", `status=${ordAfter1.body.data?.status}`);
  const ordLineQty: number = ordAfter1.body.data?.lines?.[0]?.qty_fulfilled ?? 0;
  check("qty_fulfilled = 3", ordLineQty === 3, `qty_fulfilled=${ordLineQty}`);

  // remaining 5 → complete
  const cv2 = await req("POST", `/sales/orders/${ordId}/convert`, T, {
    type: "CASH",
    partial_lines: [{ product_id: PID, qty: 5 }],
  });
  check("remaining convert 200 (5/8)", cv2.status < 300 && cv2.body.data?.partially_fulfilled === false, JSON.stringify(cv2.body).slice(0, 200));
  const ordAfter2 = await req("GET", `/sales/orders/${ordId}`, T);
  check("order → INVOICED (complete)", ordAfter2.body.data?.status === "INVOICED", `status=${ordAfter2.body.data?.status}`);

  // over-complete: min() caps at remaining, then order is INVOICED → VAL_004
  const cv3 = await req("POST", `/sales/orders/${ordId}/convert`, T, {
    type: "CASH",
    partial_lines: [{ product_id: PID, qty: 5 }],
  });
  check("convert after complete → VAL_004", cv3.status === 409 && errCode(cv3) === "VAL_004", JSON.stringify(cv3.body).slice(0, 140));

  // product not in order → VAL_003
  if (otherProd) {
    const ordX = await req("POST", "/sales/orders", T, {
      customer_id: CID,
      warehouse_id: WH_MAIN,
      order_date: new Date().toISOString().slice(0, 10),
      lines: [{ product_id: PID, qty: 1 }],
    });
    const ordXId = ordX.body.data?.id as number;
    await req("POST", `/sales/orders/${ordXId}/confirm`, T);
    const cvX = await req("POST", `/sales/orders/${ordXId}/convert`, T, {
      type: "CASH",
      partial_lines: [{ product_id: otherProd.id, qty: 1 }],
    });
    check("partial product not in order → VAL_003", cvX.status === 404 && errCode(cvX) === "VAL_003", JSON.stringify(cvX.body).slice(0, 140));
    await req("POST", `/sales/orders/${ordXId}/cancel`, T);
  }

  // =====================================================================
  console.log("── D. §62 settings: 14 groups ──");

  const s0 = await req("GET", "/settings", T);
  check("GET /settings 200", s0.status < 300, JSON.stringify(s0.body).slice(0, 140));
  const groups: any[] = s0.body.data?.groups ?? [];
  check("14 setting groups", groups.length === 14, `got ${groups.length}`);

  const sCash = await req("GET", "/settings", CT);
  check("cashier GET /settings → 403 PERM_001", sCash.status === 403 && errCode(sCash) === "PERM_001", JSON.stringify(sCash.body).slice(0, 120));

  const sBad = await req("PUT", "/settings", T, { updates: [{ key: "hacker.key", value: "x" }] });
  check("unknown key → VAL_001", sBad.status === 422 && errCode(sBad) === "VAL_001", JSON.stringify(sBad.body).slice(0, 120));

  const sPut = await req("PUT", "/settings", T, { updates: [{ key: "sales.enforce_min_price", value: true }, { key: "printing.thermal_width", value: 58 }] });
  check("PUT two keys 200", sPut.status < 300 && sPut.body.data?.updated === 2, JSON.stringify(sPut.body).slice(0, 140));
  const sRead = await req("GET", "/settings", T);
  const salesGroup = (sRead.body.data?.groups ?? []).find((g: any) => g.prefix === "sales.");
  const printGroup = (sRead.body.data?.groups ?? []).find((g: any) => g.prefix === "printing.");
  check("persisted enforce_min_price=true", salesGroup?.settings?.find((s: any) => s.key === "sales.enforce_min_price")?.value === true);
  check("persisted thermal_width=58", printGroup?.settings?.find((s: any) => s.key === "printing.thermal_width")?.value === 58);

  // =====================================================================
  console.log("── E. §7 brand + min_sale_price enforcement ──");

  const upd = await req("PATCH", `/products/${PID}`, T, { brand: "علامة-اختبار", minSalePrice: 1000000 });
  check("PATCH brand + min_sale_price", upd.status < 300, JSON.stringify(upd.body).slice(0, 140));

  // sale below min while enforce=true → VAL_001
  const blocked = await req("POST", "/sales/invoices", T, {
    customer_id: CID,
    warehouse_id: WH_MAIN,
    type: "CASH",
    lines: [{ product_id: PID, qty: 1, unit_price: 100 }],
  });
  check("sale below min → VAL_001 (enforced)", blocked.status === 422 && errCode(blocked) === "VAL_001", JSON.stringify(blocked.body).slice(0, 160));

  // disable enforcement → same sale passes
  await req("PUT", "/settings", T, { updates: [{ key: "sales.enforce_min_price", value: false }] });
  const allowed = await req("POST", "/sales/invoices", T, {
    customer_id: CID,
    warehouse_id: WH_MAIN,
    type: "CASH",
    lines: [{ product_id: PID, qty: 1, unit_price: 100 }],
  });
  check("sale below min passes when enforcement off", allowed.status < 300, JSON.stringify(allowed.body).slice(0, 160));

  // restore product + settings + customer (test isolation)
  await req("PATCH", `/products/${PID}`, T, { brand: null, minSalePrice: null });
  await req("PUT", "/settings", T, { updates: [{ key: "printing.thermal_width", value: 80 }] });
  await db.customer.update({ where: { id: CID }, data: { creditLimit: origLimit } });
  await db.approvalRule.deleteMany({});
  check("cleanup done", true);

  // =====================================================================
  console.log(`\n═══ Results: ${pass} passed, ${fail} failed ═══`);
  if (fail > 0) process.exit(1);
}

main()
  .catch((e) => {
    console.error("FATAL:", e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
