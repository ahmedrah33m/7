// =====================================================================
// Smart Invoice acceptance suite — نظام الفاتورة الذكية (المواصفة §1-§47)
// Uses the REAL HTTP API with real side effects and verifies DB state
// through Prisma. Exit code 0 = all pass.
// =====================================================================

import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000/api/v1";
const db = new PrismaClient();

let pass = 0;
let fail = 0;
const results: string[] = [];

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    results.push(`  ✅ ${name}`);
  } else {
    fail++;
    results.push(`  ❌ ${name} ${detail ? "— " + detail : ""}`);
  }
}

async function req(
  method: string,
  path: string,
  token?: string,
  body?: unknown
): Promise<{ status: number; body: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json };
}

async function main() {
  console.log("═══ Smart Invoice verification (الفاتورة الذكية) ═══");

  // 0) login
  const admin = await req("POST", "/auth/login", undefined, { username: "admin", password: "Admin@123" });
  check("admin login", admin.status === 200 && admin.body.success);
  const T = admin.body.data?.access_token as string;
  const companyId = admin.body.data?.user?.company_id ?? null;

  const me = await req("GET", "/auth/me", T);
  const scopedWhs = (me.body.data?.warehouses ?? []) as any[];
  const mainWh = scopedWhs.find((w) => w.type === "MAIN") ?? scopedWhs[0];
  check("warehouses in session scope", !!mainWh, `main=${mainWh?.id}`);

  // ------------------------------------------------------------------
  // 1) product with packaging (§7): شامبو طبي — حبة 6,000 · كرتونة 12 = 72,000
  // ------------------------------------------------------------------
  const stamp = Date.now().toString().slice(-6);
  const prodRes = await req("POST", "/products", T, {
    name: `شامبو طبي 250ml ${stamp}`,
    unit: "حبة",
    pack_unit: "كرتونة",
    pack_qty: 12,
    pack_sale_price: 72000,
    sale_price: 6000,
    cost_price: 4000,
  });
  check("create product with packaging (§7)", prodRes.status === 201 && prodRes.body.data?.pack_qty === 12);
  const productId = prodRes.body.data?.id as number;

  const intakeRes = await req("POST", "/inventory/movements", T, {
    warehouse_id: mainWh.id,
    product_id: productId,
    direction: "IN",
    qty: 120,
  });
  check("stock intake 120 حبة = 10 كراتين", intakeRes.status === 200 || intakeRes.status === 201, JSON.stringify(intakeRes.body).slice(0, 120));

  // package coverage sync via packages endpoint (§10)
  const pkgs0 = await req("GET", `/inventory/packages?warehouse_id=${mainWh.id}&product_id=${productId}`, T);
  check("packages synced: 10 sealed / 0 open / 120 pieces (§10)",
    pkgs0.body.data?.closed_packages === 10 && pkgs0.body.data?.open_packages === 0 && pkgs0.body.data?.total_pieces === 120,
    JSON.stringify({ c: pkgs0.body.data?.closed_packages, o: pkgs0.body.data?.open_packages, t: pkgs0.body.data?.total_pieces }));
  check("package code format CARTON-XXXXXX (§14)", /^CARTON-\d{6}$/.test(pkgs0.body.data?.packages?.[0]?.code ?? ""));

  // ------------------------------------------------------------------
  // 2) customer + preview (§2/§3/§22) — no previous debt (§5)
  // ------------------------------------------------------------------
  const custRes = await req("POST", "/customers", T, {
    name: `متجر النور ${stamp}`,
    credit_limit: 2_000_000,
    credit_days: 15,
  });
  check("create customer", custRes.status === 201);
  const customerId = custRes.body.data?.id as number;

  const prev1 = await req("POST", "/sales/invoices/preview", T, {
    customer_id: customerId,
    warehouse_id: mainWh.id,
    product_ids: [productId],
  });
  check("preview: previous balance = 0 with no-debt flag (§5)",
    prev1.body.data?.customer?.previous_balance === 0 && prev1.body.data?.customer?.no_debt === true);
  check("preview: package state for rep (§27)", prev1.body.data?.packages?.[String(productId)]?.closed_packages === 10);

  // ------------------------------------------------------------------
  // 3) invoice #1 — 1 كرتونة + 3 حبات مع خصم 3,000 (§16/§17)
  //    gross = 72,000 + 18,000 = 90,000 − 3,000 = 87,000
  // ------------------------------------------------------------------
  const inv1 = await req("POST", "/sales/invoices", T, {
    customer_id: customerId,
    warehouse_id: mainWh.id,
    type: "CASH",
    payment_method: "CASH",
    lines: [{ product_id: productId, package_qty: 1, loose_qty: 3, unit_price: 6000, price_unit: "PIECE", discount_amount: 3000 }],
  });
  check("invoice#1 posted", inv1.status === 201 && inv1.body.data?.status === "POSTED", JSON.stringify(inv1.body).slice(0, 200));
  const inv1Id = inv1.body.data?.id as number;
  check("invoice#1 total = 87,000 (سعر كرتونة مستقل §19)", inv1.body.data?.grand_total === 87000, `got ${inv1.body.data?.grand_total}`);
  check("invoice#1 previous_balance = 0 + new_balance = 0 (نقدي)", inv1.body.data?.previous_balance === 0 && inv1.body.data?.new_balance === 0);

  const det1 = await req("GET", `/sales/invoices/${inv1Id}`, T);
  const line1 = det1.body.data?.lines?.[0];
  check("line base qty = 15 (1×12+3)", line1?.qty === 15, `got ${line1?.qty}`);
  check("line package split stored (§43)", line1?.package_qty === 1 && line1?.loose_qty === 3 && line1?.package_conversion === 12);
  check("line stock before/after = 120 → 105 (§26)", line1?.stock_before === 120 && line1?.stock_after === 105);
  check("package_note present (§11)", typeof line1?.package_note === "string" && line1.package_note.length > 0);
  check("packaging ledger rows written (§13)", (det1.body.data?.packaging_ledger?.length ?? 0) >= 2);
  const openAfter1 = det1.body.data?.packaging_ledger?.find((e: any) => e.direction === "ISSUE" && e.remainingQty === 9);
  check("opened carton #2 has 9 remaining (§8)", !!openAfter1, JSON.stringify(det1.body.data?.packaging_ledger));

  const pkgs1 = await req("GET", `/inventory/packages?warehouse_id=${mainWh.id}&product_id=${productId}`, T);
  check("stock state: 8 closed + 1 open(9) = 105 (§10/§15)",
    pkgs1.body.data?.closed_packages === 8 && pkgs1.body.data?.open_packages === 1 && pkgs1.body.data?.open_qty === 9 && pkgs1.body.data?.total_pieces === 105,
    JSON.stringify({ c: pkgs1.body.data?.closed_packages, o: pkgs1.body.data?.open_packages, q: pkgs1.body.data?.open_qty, t: pkgs1.body.data?.total_pieces }));

  // ------------------------------------------------------------------
  // 4) invoice #2 — 7 حبات من المفتوح أولًا (§12): 9 → 2
  // ------------------------------------------------------------------
  const inv2 = await req("POST", "/sales/invoices", T, {
    customer_id: customerId,
    warehouse_id: mainWh.id,
    type: "CASH",
    lines: [{ product_id: productId, qty: 7 }],
  });
  check("invoice#2 posted (7 حبات)", inv2.status === 201);
  const pkgs2 = await req("GET", `/inventory/packages?warehouse_id=${mainWh.id}&product_id=${productId}`, T);
  check("OPEN_FIRST policy: open carton 9 → 2, no new carton opened (§12)",
    pkgs2.body.data?.closed_packages === 8 && pkgs2.body.data?.open_qty === 2,
    JSON.stringify({ c: pkgs2.body.data?.closed_packages, q: pkgs2.body.data?.open_qty }));

  // ------------------------------------------------------------------
  // 5) invoice #3 — 7 حبات: المفتوح يفرغ ثم تُفتح كرتونة جديدة 12→7 (§12)
  // ------------------------------------------------------------------
  const inv3 = await req("POST", "/sales/invoices", T, {
    customer_id: customerId,
    warehouse_id: mainWh.id,
    type: "CASH",
    lines: [{ product_id: productId, qty: 7 }],
  });
  check("invoice#3 posted", inv3.status === 201);
  const pkgs3 = await req("GET", `/inventory/packages?warehouse_id=${mainWh.id}&product_id=${productId}`, T);
  check("open emptied + new carton opened 12→7: 7 closed + 1 open(7) = 91",
    pkgs3.body.data?.closed_packages === 7 && pkgs3.body.data?.open_packages === 1 && pkgs3.body.data?.open_qty === 7 && pkgs3.body.data?.total_pieces === 91,
    JSON.stringify({ c: pkgs3.body.data?.closed_packages, o: pkgs3.body.data?.open_packages, q: pkgs3.body.data?.open_qty, t: pkgs3.body.data?.total_pieces }));

  // oversell blocked (§28)
  const oversell = await req("POST", "/sales/invoices", T, {
    customer_id: customerId,
    warehouse_id: mainWh.id,
    type: "CASH",
    lines: [{ product_id: productId, qty: 10000 }],
  });
  check("oversell blocked STOCK_001 (§28)", oversell.status === 409 && oversell.body.code === "STOCK_001");

  // ------------------------------------------------------------------
  // 6) credit guard BLOCK (§6) — customer#2 with small limit
  // ------------------------------------------------------------------
  const cust2 = await req("POST", "/customers", T, { name: `عميل محدود ${stamp}`, credit_limit: 100000, credit_days: 7 });
  const cust2Id = cust2.body.data?.id as number;
  const blocked = await req("POST", "/sales/invoices", T, {
    customer_id: cust2Id,
    warehouse_id: mainWh.id,
    type: "CREDIT",
    lines: [{ product_id: productId, qty: 30 }],
  });
  check("credit exceed + BLOCK policy → CREDIT_001 (§6)", blocked.status === 409 && blocked.body.code === "CREDIT_001", `got ${blocked.status}/${blocked.body.code}`);

  // credit hold customer: cash only
  const custHold = await req("POST", "/customers", T, { name: `عميل محجوز ${stamp}` });
  await db.customer.update({ where: { id: custHold.body.data?.id }, data: { status: "CREDIT_HOLD" } });
  const holdTry = await req("POST", "/sales/invoices", T, {
    customer_id: custHold.body.data?.id,
    warehouse_id: mainWh.id,
    type: "CREDIT",
    lines: [{ product_id: productId, qty: 1 }],
  });
  check("CREDIT_HOLD customer blocked from credit sales (§2)", holdTry.status === 422);

  // ------------------------------------------------------------------
  // 7) approval flow (§6) — flip policy to APPROVAL
  // ------------------------------------------------------------------
  await db.company.updateMany({ data: { settingsJson: JSON.stringify({ negative_stock: false, credit_guard: "APPROVAL" }) } });
  const pending = await req("POST", "/sales/invoices", T, {
    customer_id: cust2Id,
    warehouse_id: mainWh.id,
    type: "CREDIT",
    notes: "آجل فوق الحد — بانتظار الموافقة",
    lines: [{ product_id: productId, package_qty: 2, loose_qty: 6 }],
  });
  check("APPROVAL policy → invoice saved as PENDING_APPROVAL (§6)",
    pending.status === 201 && pending.body.data?.status === "PENDING_APPROVAL" && pending.body.data?.requires_approval === true,
    JSON.stringify(pending.body).slice(0, 150));
  const pendingId = pending.body.data?.id as number;
  const pendingRow = await db.salesInvoice.findUnique({ where: { id: pendingId } });
  check("pending invoice: NO stock effect yet (stockApplied=false)", pendingRow?.stockApplied === false && pendingRow?.creditExceeded === true);
  const balBefore = await db.stockBalance.findUnique({ where: { warehouseId_productId: { warehouseId: mainWh.id, productId } } });
  const cust2Before = await db.customer.findUnique({ where: { id: cust2Id } });
  check("pending invoice: stock balance untouched", Number(balBefore?.qty) === 91, `got ${balBefore?.qty}`);
  check("pending invoice: customer balance untouched", Number(cust2Before?.balance) === 0, `got ${cust2Before?.balance}`);

  const approve = await req("POST", `/sales/invoices/${pendingId}/approve`, T, {});
  check("approve applies effects → POSTED", approve.status === 200 && approve.body.data?.status === "POSTED", JSON.stringify(approve.body).slice(0, 150));
  const balAfter = await db.stockBalance.findUnique({ where: { warehouseId_productId: { warehouseId: mainWh.id, productId } } });
  const cust2After = await db.customer.findUnique({ where: { id: cust2Id } });
  check("after approve: stock deducted 91 → 61", Number(balAfter?.qty) === 61, `got ${balAfter?.qty}`);
  check("after approve: customer balance = 180,000 (2 كرتونتين + 6 حبات آجلة)", Number(cust2After?.balance) === 180000, `got ${cust2After?.balance}`);

  const reApprove = await req("POST", `/sales/invoices/${pendingId}/approve`, T, {});
  check("double approve rejected VAL_004", reApprove.status === 409 && reApprove.body.code === "VAL_004");

  // rejected invoice has no effects
  const pending2 = await req("POST", "/sales/invoices", T, {
    customer_id: cust2Id,
    warehouse_id: mainWh.id,
    type: "CREDIT",
    lines: [{ product_id: productId, qty: 5 }],
  });
  check("second pending invoice created", pending2.status === 201 && pending2.body.data?.status === "PENDING_APPROVAL");
  const reject = await req("POST", `/sales/invoices/${pending2.body.data?.id}/reject`, T, { reason: "اختبار الرفض" });
  check("reject → REJECTED with no effects", reject.status === 200 && reject.body.data?.status === "REJECTED");
  const cust2Rejected = await db.customer.findUnique({ where: { id: cust2Id } });
  check("rejected invoice: balance unchanged (180,000)", Number(cust2Rejected?.balance) === 180000, `got ${cust2Rejected?.balance}`);

  // restore BLOCK policy
  await db.company.updateMany({ data: { settingsJson: JSON.stringify({ negative_stock: false, credit_guard: "BLOCK" }) } });

  // ------------------------------------------------------------------
  // 8) partial credit invoice + balance separation (§4/§25)
  // ------------------------------------------------------------------
  const partial = await req("POST", "/sales/invoices", T, {
    customer_id: customerId,
    warehouse_id: mainWh.id,
    type: "CREDIT",
    paid_amount: 200000,
    lines: [{ product_id: productId, package_qty: 3, loose_qty: 4 }],
  });
  // 3 كراتين + 4 حبات = 40 حبة: 3×72000 + 4×6000 = 240,000 → paid 200,000 → due 40,000
  check("partial invoice: sale_type=PARTIAL (§25)", partial.status === 201 && partial.body.data?.sale_type === "PARTIAL", JSON.stringify(partial.body).slice(0, 150));
  check("partial invoice: paid 200,000 · due 40,000", partial.body.data?.paid_amount === 200000 && partial.body.data?.due_amount === 40000);
  check("partial invoice: previous 0 → new 40,000", partial.body.data?.previous_balance === 0 && partial.body.data?.new_balance === 40000);

  // ------------------------------------------------------------------
  // 9) QR verification token (§37) — PUBLIC endpoint, no auth
  // ------------------------------------------------------------------
  const detail = await req("GET", `/sales/invoices/${inv1Id}`, T);
  const vToken = detail.body.data?.verify_token as string;
  const pub = await fetch(`${BASE}/verify/${vToken}`);
  const pubBody = await pub.json();
  check("public verify endpoint works WITHOUT auth (§37)", pub.status === 200 && pubBody.data?.valid === true && pubBody.data?.invoice_number === detail.body.data?.number, JSON.stringify(pubBody).slice(0, 120));
  const badToken = await fetch(`${BASE}/verify/aaaaaaaa-bbbb-4ccc-addd-eeeeeeeeeeee`);
  const badBody = await badToken.json();
  check("invalid token → valid:false", badBody.data?.valid === false);

  // ------------------------------------------------------------------
  // 10) returns with packages (§29/§30): 3 حبات مفتوحة + 12 مغلقة
  // ------------------------------------------------------------------
  const inv1Lines = detail.body.data?.lines as any[];
  const line1Id = inv1Lines?.[0]?.id as number;
  const ret1 = await req("POST", "/sales/returns", T, {
    invoice_id: inv1Id,
    refund_cash: 0,
    lines: [{ invoice_line_id: line1Id, qty: 3, package_condition: "OPENED" }],
  });
  check("return 3 حبات OPENED posted", ret1.status === 201, JSON.stringify(ret1.body).slice(0, 150));
  const pkgs4 = await req("GET", `/inventory/packages?warehouse_id=${mainWh.id}&product_id=${productId}`, T);
  // قبل المرتجع: 7 مغلقة + مفتوح(4) — من الفاتورة الجزئية 3+4: 3 من مفتوح(7→4) + 1 كرتونة فتحت (12→8) = 7 مغلقة + مفتوح(8)؟
  // نتحقق من الاتساق فقط: total_pieces = closed×12 + open
  const totalCheck = pkgs4.body.data?.closed_packages * 12 + pkgs4.body.data?.open_qty === pkgs4.body.data?.total_pieces;
  check("package/stock consistency after partial sale + return", totalCheck === true,
    JSON.stringify({ c: pkgs4.body.data?.closed_packages, q: pkgs4.body.data?.open_qty, t: pkgs4.body.data?.total_pieces }));
  check("return added pieces back to an OPEN package (§29 — no wrong new carton)", pkgs4.body.data?.open_packages >= 1, JSON.stringify({ o: pkgs4.body.data?.open_packages, q: pkgs4.body.data?.open_qty }));

  // ------------------------------------------------------------------
  // 11) audit (§44) + mini statement (§22) + footer (§41)
  // ------------------------------------------------------------------
  const audits = await db.auditLog.findMany({ where: { entityType: "sales_invoice", entityId: inv1Id } });
  check("audit row written for invoice (§44/§47)", audits.length > 0);
  const pkgAudits = await db.packagingLedger.count({ where: { refType: "SALES_INVOICE", refId: inv1Id } });
  check("packaging ledger immutable rows (§13)", pkgAudits >= 2);

  const prev2 = await req("POST", "/sales/invoices/preview", T, { customer_id: customerId, warehouse_id: mainWh.id });
  check("mini statement shows last invoice (§22)", !!prev2.body.data?.mini_statement?.last_invoice?.number, JSON.stringify(prev2.body.data?.mini_statement));
  check("footer text present from settings (§41)", typeof prev2.body.data?.settings?.footer_text === "string" && prev2.body.data.settings.footer_text.includes("شكراً"));

  // invoice detail exposes print data (thermal/A4 fields)
  check("detail exposes balance snapshot for print (§21)",
    detail.body.data?.previous_balance === 0 && typeof detail.body.data?.new_balance === "number" && typeof detail.body.data?.footer_text === "string");

  // ------------------------------------------------------------------
  console.log(`\n${results.join("\n")}`);
  console.log(`\n═══ Result: ${pass} passed · ${fail} failed ═══`);
  await db.$disconnect();
  if (fail > 0) process.exit(1);
}

main().catch(async (e) => {
  console.error("suite crashed:", e);
  await db.$disconnect();
  process.exit(1);
});
