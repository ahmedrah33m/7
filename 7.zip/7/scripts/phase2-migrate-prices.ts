// =====================================================================
// Phase 2 — ترحيل البيانات الحالية (idempotent):
//   1) كل منتج → صفوف ProductPrice من الأعمدة المسطحة (عملة IQD)
//      SALE/PIECE · COST/PIECE · SALE/PACKAGE (عند وجود تعبئة)
//   2) إعداد سعر صرف الشركة currency.usd_rate_iqd إن لم يوجد (1550 = السعر
//      المعتمد فعلياً لدى المستخدم — استُنتج من جلسة إصلاح تسعير لوميره)
//   آمن لإعادة التشغيل: يتخطى ما تم ترحيله مسبقاً.
// =====================================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const RATE_KEY = "currency.usd_rate_iqd";
const DEFAULT_RATE = 1550;

async function main() {
  const products = await db.product.findMany({
    where: { deletedAt: null },
    select: { id: true, companyId: true, salePrice: true, costPrice: true, packUnit: true, packQty: true, packSalePrice: true },
  });
  console.log(`products to migrate: ${products.length}`);

  let created = 0;
  let skipped = 0;
  for (const p of products) {
    const existing = await db.productPrice.findMany({
      where: { productId: p.id, isActive: true },
      select: { priceType: true, unit: true },
    });
    const has = (t: string, u: string) => existing.some((r) => r.priceType === t && r.unit === u);
    const wanted: { priceType: string; unit: string; amount: number | null }[] = [
      { priceType: "SALE", unit: "PIECE", amount: p.salePrice },
      { priceType: "COST", unit: "PIECE", amount: p.costPrice },
      { priceType: "SALE", unit: "PACKAGE", amount: p.packUnit && p.packQty && p.packQty > 1 ? p.packSalePrice : null },
    ];
    for (const w of wanted) {
      if (w.amount == null || w.amount <= 0) continue;
      if (has(w.priceType, w.unit)) { skipped += 1; continue; }
      await db.productPrice.create({
        data: {
          companyId: p.companyId,
          productId: p.id,
          priceType: w.priceType,
          unit: w.unit,
          currency: "IQD", // الأعمدة القديمة كلها بالدينار (عملة الأساس)
          amount: w.amount,
          createdBy: null,
        },
      });
      created += 1;
    }
  }
  console.log(`product_prices created: ${created} (skipped existing: ${skipped})`);

  // ---- سعر صرف الشركة (بلا تخمين عند العرض — §7) ------------------------
  const companies = await db.company.findMany({ where: { deletedAt: null }, select: { id: true, name: true } });
  for (const c of companies) {
    const found = await db.setting.findFirst({ where: { companyId: c.id, key: RATE_KEY } });
    if (!found) {
      await db.setting.create({
        data: {
          companyId: c.id, key: RATE_KEY, value: JSON.stringify(DEFAULT_RATE),
          groupName: "currency", description: "سعر صرف الدولار المعتمد للشركة — د.ع لكل $1",
        },
      });
      console.log(`company #${c.id} ${c.name}: usd_rate set to ${DEFAULT_RATE}`);
    } else {
      console.log(`company #${c.id} ${c.name}: usd_rate exists (${found.value}) — kept`);
    }
  }

  // ---- فحص حالات unit == packUnit المتبقية (تقرير — لا تعديل هنا) -------
  const all = await db.product.findMany({
    where: { deletedAt: null },
    select: { id: true, companyId: true, name: true, unit: true, packUnit: true, packQty: true },
  });
  const norm = (s: string) => String(s ?? "").trim().replace(/[أإآ]/g, "ا").replace(/ة/g, "ه");
  const violations = all.filter((p) => p.packUnit && norm(p.unit) === norm(p.packUnit));
  console.log(`unit==packUnit violations: ${violations.length}`);
  for (const v of violations) console.log(`  - product #${v.id} [company ${v.companyId}] ${v.name}: unit=${v.unit} packUnit=${v.packUnit} packQty=${v.packQty}`);
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
