// ar_lib.js — Arabic RTL DOCX helpers + palette + cover recipe (R1 RTL-adapted)
// Follows docx skill: design-system.md R1 recipe + common-rules.md + toc.md
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  ImageRun, PageBreak, Header, Footer, PageNumber, NumberFormat,
  AlignmentType, HeadingLevel, WidthType, BorderStyle, ShadingType,
  PageOrientation, TableLayoutType, SectionType, TableOfContents, VerticalAlign,
} = require("docx");
const fs = require("fs");
const sizeOf = require("image-size");

// ── Palette: Corporate ERP (navy + orange, per user's brand section 52) ──
const P = {
  primary: "1E293B", body: "1F2937", secondary: "64748B",
  accent: "EA580C", accentDark: "9A3412", surface: "F8FAFC",
  line: "CBD5E1", codeBg: "F1F5F9", headFill: "EEF2F7",
  cover: { bg: "16202E", titleColor: "FFFFFF", subtitleColor: "CBD5E1",
           metaColor: "E2E8F0", accent: "EA580C", footerColor: "94A3B8" },
};

const AR = { ascii: "Calibri", hAnsi: "Calibri", cs: "Calibri", eastAsia: "Calibri" };
const CODE = { ascii: "Courier New", hAnsi: "Courier New", cs: "Courier New", eastAsia: "Courier New" };

const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB };
const allNoBorders = { top: NB, bottom: NB, left: NB, right: NB, insideHorizontal: NB, insideVertical: NB };

// ── Safe text guard (common-rules.md mandatory) ──
function safeText(v, ph) {
  if (v === undefined || v === null || v === "" || String(v) === "NaN" || String(v) === "undefined")
    return ph || "\u3010يُستكمل\u3011";
  return String(v);
}

// ── Run helpers ──
function arRun(text, o = {}) {
  return new TextRun({
    text: safeText(text, o.ph), font: o.code ? CODE : AR,
    size: o.size || 24, sizeComplexScript: o.size || 24,
    bold: o.bold || false, boldComplexScript: o.bold || false,
    italics: o.italics || false,
    color: o.color || P.body, rightToLeft: o.ltr ? false : true,
  });
}
function codeRun(text, o = {}) {
  return new TextRun({ text: safeText(text), font: CODE, size: o.size || 18,
    sizeComplexScript: o.size || 18, color: o.color || P.primary, rightToLeft: false });
}

// ── Paragraph helpers (RTL) ──
function pBody(text, o = {}) {  // RTL body: justified, 1.3x line
  const runs = Array.isArray(text) ? text : [arRun(text, o)];
  return new Paragraph({
    bidirectional: true, alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: o.after !== undefined ? o.after : 120, before: o.before || 0 },
    keepNext: o.keepNext || false,
    children: runs,
  });
}
function pStart(text, o = {}) { // RTL start-aligned (right)
  const runs = Array.isArray(text) ? text : [arRun(text, o)];
  return new Paragraph({
    bidirectional: true, alignment: AlignmentType.START,
    spacing: { line: 312, after: o.after !== undefined ? o.after : 100, before: o.before || 0 },
    keepNext: o.keepNext || false,
    children: runs,
  });
}
function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1, bidirectional: true, keepNext: true,
    spacing: { before: 360, after: 160, line: 380, lineRule: "atLeast" },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: P.accent, space: 6 } },
    children: [arRun(text, { size: 32, bold: true, color: P.primary })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2, bidirectional: true, keepNext: true,
    spacing: { before: 280, after: 120, line: 340, lineRule: "atLeast" },
    children: [arRun(text, { size: 28, bold: true, color: P.primary })],
  });
}
function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3, bidirectional: true, keepNext: true,
    spacing: { before: 220, after: 100, line: 312 },
    children: [arRun(text, { size: 25, bold: true, color: P.accentDark })],
  });
}

// RTL bullet item
function bullet(text, o = {}) {
  const runs = Array.isArray(text) ? text : [arRun(text, o)];
  return new Paragraph({
    bidirectional: true, alignment: AlignmentType.START, bullet: { level: o.level || 0 },
    spacing: { line: 312, after: 60 },
    children: runs,
  });
}

// ── Code block: single-cell table, LTR, gray ──
function codeBlock(lines, title) {
  const paras = [];
  if (title) {
    paras.push(new Paragraph({
      spacing: { after: 40, line: 260 },
      children: [arRun(title, { size: 18, bold: true, color: P.secondary, ltr: true })],
    }));
  }
  for (const ln of lines) {
    paras.push(new Paragraph({
      alignment: AlignmentType.LEFT, spacing: { line: 250, lineRule: "atLeast" },
      children: [codeRun(ln === "" ? " " : ln)],
    }));
  }
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    visuallyRightToLeft: false,
    borders: { top: { style: BorderStyle.SINGLE, size: 2, color: P.line },
      bottom: { style: BorderStyle.SINGLE, size: 2, color: P.line },
      left: { style: BorderStyle.SINGLE, size: 12, color: P.accent },
      right: { style: BorderStyle.SINGLE, size: 2, color: P.line },
      insideHorizontal: NB, insideVertical: NB },
    rows: [new TableRow({
      cantSplit: false,
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: P.codeBg },
        margins: { top: 90, bottom: 90, left: 160, right: 160 },
        children: paras,
      })],
    })],
  });
}

// ── Generic RTL table ──
// cols: [{w: pct, header: "العمود"}], rows: [[cell strings or {t, code, bold, color}]]
function rtlTable(cols, rows, o = {}) {
  const headerRow = new TableRow({
    tableHeader: true, cantSplit: true,
    children: cols.map((c) => new TableCell({
      width: { size: c.w, type: WidthType.PERCENTAGE },
      shading: { type: ShadingType.CLEAR, fill: P.headFill },
      margins: { top: 70, bottom: 70, left: 100, right: 100 },
      verticalAlign: VerticalAlign.CENTER,
      children: [new Paragraph({
        bidirectional: true, alignment: AlignmentType.CENTER, spacing: { line: 280 },
        children: [arRun(c.header, { size: 20, bold: true, color: P.primary })],
      })],
    })),
  });
  const dataRows = rows.map((r, ri) => new TableRow({
    cantSplit: true,
    children: r.map((cell, ci) => {
      const c = typeof cell === "object" && cell !== null ? cell : { t: cell };
      return new TableCell({
        width: { size: cols[ci].w, type: WidthType.PERCENTAGE },
        shading: o.zebra && ri % 2 === 1 ? { type: ShadingType.CLEAR, fill: "FAFBFD" } : undefined,
        margins: { top: 55, bottom: 55, left: 100, right: 100 },
        children: [new Paragraph({
          bidirectional: !c.ltr,
          alignment: c.center ? AlignmentType.CENTER : AlignmentType.START,
          spacing: { line: 276 },
          children: [c.code ? codeRun(c.t, { size: 17 }) : arRun(c.t, { size: c.size || 19, bold: c.bold, color: c.color })],
        })],
      });
    }),
  }));
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    visuallyRightToLeft: true,
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: P.secondary },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: P.secondary },
      left: NB, right: NB,
      insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: P.line },
      insideVertical: { style: BorderStyle.SINGLE, size: 2, color: "E2E8F0" },
    },
    rows: [headerRow, ...dataRows],
  });
}

// table caption (above, keepNext)
function tCaption(text) {
  return new Paragraph({
    bidirectional: true, alignment: AlignmentType.START, keepNext: true,
    spacing: { before: 160, after: 80, line: 300 },
    children: [arRun(text, { size: 20, bold: true, color: P.secondary })],
  });
}

// figure caption (below image)
function fCaption(text) {
  return new Paragraph({
    bidirectional: true, alignment: AlignmentType.CENTER,
    spacing: { before: 60, after: 200, line: 300 },
    children: [arRun(text, { size: 20, italics: true, color: P.secondary })],
  });
}

// ── Image embed with aspect preservation ──
function image(path, displayWidth) {
  const buf = fs.readFileSync(path);
  const dims = sizeOf(buf);
  const w = displayWidth || 585;
  const h = Math.round(w * (dims.height / dims.width));
  return new Paragraph({
    alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120, after: 40 },
    children: [new ImageRun({ data: buf, transformation: { width: w, height: h }, type: "png" })],
  });
}

// ── Cover — Recipe R1 (RTL-adapted: same wrapper/heights/structure, mirrored alignment) ──
function calcTitleLayout(title, maxWidthTwips, preferredPt = 40, minPt = 24) {
  const charW = (pt) => pt * 20;
  const cpl = (pt) => Math.floor(maxWidthTwips / charW(pt));
  let titlePt = preferredPt, lines;
  const split = (t, n) => {
    if (t.length <= n) return [t];
    const out = []; let rem = t;
    while (rem.length > n) {
      let br = -1;
      for (let i = n; i >= Math.floor(n * 0.6); i--)
        if (i < rem.length && /[\s\u060C\u061B\u061F\u2014–-]/.test(rem[i - 1])) { br = i; break; }
      if (br === -1) {
        const lim = Math.min(rem.length, Math.ceil(n * 1.3));
        for (let i = n + 1; i < lim; i++)
          if (/[\s\u060C\u061B\u061F\u2014–-]/.test(rem[i - 1])) { br = i; break; }
      }
      if (br === -1) br = n;
      out.push(rem.slice(0, br).trim()); rem = rem.slice(br).trim();
    }
    if (rem) out.push(rem);
    if (out.length > 1 && out[out.length - 1].length <= 2) { const last = out.pop(); out[out.length - 1] += " " + last; }
    return out;
  };
  while (titlePt >= minPt) {
    const c = cpl(titlePt);
    if (c < 2) { titlePt -= 2; continue; }
    lines = split(title, c);
    if (lines.length <= 3) break;
    titlePt -= 2;
  }
  if (!lines || lines.length > 3) { lines = split(title, cpl(minPt)); titlePt = minPt; }
  return { titlePt, titleLines: lines };
}

function calcCoverSpacing(prm) {
  const { titleLineCount = 1, titlePt = 36, hasSubtitle = false, hasEnglishLabel = false,
    metaLineCount = 0, fixedHeight = 800, pageHeight = 16838 } = prm;
  const SAFETY = 1200;
  const usable = pageHeight - SAFETY;
  const titleH = titleLineCount * (titlePt * 23 + 200);
  const subH = hasSubtitle ? (12 * 23 + 600) : 0;
  const engH = hasEnglishLabel ? (9 * 23 + 600) : 0;
  const metaH = metaLineCount * (10 * 23 + 100);
  const content = titleH + subH + engH + metaH + fixedHeight + 3 * 300;
  const remaining = Math.max(usable - content, 400);
  const FOOTER_MIN = 800;
  const rawTop = Math.floor(remaining * 0.45), rawBottom = Math.floor(remaining * 0.45);
  const bottomSpacing = Math.max(rawBottom, FOOTER_MIN);
  const topSpacing = Math.max(rawTop - Math.max(0, FOOTER_MIN - rawBottom), 400);
  return { topSpacing, bottomSpacing };
}

function buildCoverR1RTL(config) {
  const C = P.cover;
  const padS = 1200, padE = 800; // start(right) / end(left) padding — mirrored R1
  const availableWidth = 11906 - padS - padE - 300;
  const { titlePt, titleLines } = calcTitleLayout(config.title, availableWidth, 40, 24);
  const titleSize = titlePt * 2;
  const spacing = calcCoverSpacing({
    titleLineCount: titleLines.length, titlePt,
    hasSubtitle: !!config.subtitle, hasEnglishLabel: !!config.englishLabel,
    metaLineCount: (config.metaLines || []).length, fixedHeight: 400,
  });
  const accentRight = { style: BorderStyle.SINGLE, size: 8, color: C.accent, space: 12 };
  const children = [];
  // 1. top whitespace
  children.push(new Paragraph({ spacing: { before: spacing.topSpacing } }));
  // 2. English label (LTR) with accent bottom border — indented from start (right)
  if (config.englishLabel) {
    children.push(new Paragraph({
      alignment: AlignmentType.RIGHT,
      indent: { right: padS, left: padE }, spacing: { after: 500 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: C.accent, space: 8 } },
      children: [new TextRun({ text: config.englishLabel.split("").join("  "), size: 18,
        color: C.accent, font: CODE, characterSpacing: 40 })],
    }));
  }
  // 3. title lines (RTL)
  for (let i = 0; i < titleLines.length; i++) {
    children.push(new Paragraph({
      bidirectional: true, alignment: AlignmentType.START,
      indent: { right: padS, left: padE },
      spacing: { after: i < titleLines.length - 1 ? 100 : 300, line: Math.ceil(titlePt * 23), lineRule: "atLeast" },
      children: [arRun(titleLines[i], { size: titleSize, bold: true, color: C.titleColor })],
    }));
  }
  // 4. subtitle
  if (config.subtitle) {
    children.push(new Paragraph({
      bidirectional: true, alignment: AlignmentType.START,
      indent: { right: padS, left: padE }, spacing: { after: 800, line: 380, lineRule: "atLeast" },
      children: [arRun(config.subtitle, { size: 24, color: C.subtitleColor })],
    }));
  }
  // 5. meta lines with accent bar on the right (mirror of R1 left bar)
  for (const line of (config.metaLines || [])) {
    children.push(new Paragraph({
      bidirectional: true, alignment: AlignmentType.START,
      indent: { right: padS + 200, left: padE }, spacing: { after: 80, line: 312 },
      border: { right: accentRight },
      children: [arRun(line, { size: 24, color: C.metaColor })],
    }));
  }
  // 6. bottom whitespace
  children.push(new Paragraph({ spacing: { before: spacing.bottomSpacing } }));
  // 7. footer line with top accent separator
  children.push(new Paragraph({
    bidirectional: true, alignment: AlignmentType.START,
    indent: { right: padS, left: padE },
    border: { top: { style: BorderStyle.SINGLE, size: 2, color: C.accent, space: 8 } },
    spacing: { before: 200 },
    children: [
      arRun(config.footerRight || "", { size: 16, color: C.footerColor }),
      new TextRun({ text: "                                        ", font: AR, size: 16 }),
      arRun(config.footerLeft || "", { size: 16, color: C.footerColor }),
    ],
  }));
  // single 16838 wrapper (R1 architecture, allNoBorders)
  return [new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: allNoBorders,
    rows: [new TableRow({
      height: { value: 16838, rule: "exact" },
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: C.bg }, borders: noBorders,
        verticalAlign: VerticalAlign.TOP,
        children,
      })],
    })],
  })];
}

// ── Page furniture ──
function docHeader(titleText) {
  return new Header({
    children: [new Paragraph({
      bidirectional: true, alignment: AlignmentType.CENTER,
      border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: P.line, space: 4 } },
      spacing: { after: 60, line: 260 },
      children: [arRun(titleText, { size: 17, color: "8A94A6" })],
    })],
  });
}
function pageFooter() {
  return new Footer({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER, spacing: { line: 240 },
      children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, font: AR, color: "808080" })],
    })],
  });
}

// ── TOC block (toc.md 4-element sequence) ──
// withBreak=false when body is a separate NEXT_PAGE section (avoids double-break blank page)
function tocBlock(withBreak = false) {
  const items = [
    new Paragraph({
      bidirectional: true, alignment: AlignmentType.CENTER,
      spacing: { before: 480, after: 360, line: 400, lineRule: "atLeast" },
      children: [arRun("المحتويات", { size: 32, bold: true, color: P.primary })],
    }),
    new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3" }),
    new Paragraph({
      bidirectional: true, alignment: AlignmentType.START, spacing: { before: 200, line: 280 },
      children: [arRun("ملاحظة: هذا الفهرس مولّد بحقول آلية. بعد أي تعديل على الوثيقة، انقر بزر الفأرة الأيمن على الفهرس واختر «تحديث الحقل» لتحديث أرقام الصفحات.", { size: 18, italics: true, color: "888888" })],
    }),
  ];
  if (withBreak) items.push(new Paragraph({ children: [new PageBreak()] }));
  return items;
}

// ── Document skeleton: cover / front (roman) / body (arabic) ──
const PAGE = { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1701, right: 1417 } };

function buildDoc({ coverConfig, headerText, frontChildren, bodySections }) {
  // bodySections: [{ children, landscape? }] — page numbering continues across them
  const sections = [];
  sections.push({
    properties: { page: { size: PAGE.size, margin: { top: 0, bottom: 0, left: 0, right: 0 } } },
    children: buildCoverR1RTL(coverConfig),
  });
  sections.push({
    properties: {
      type: SectionType.NEXT_PAGE, page: {
        size: PAGE.size, margin: PAGE.margin,
        pageNumbers: { start: 1, formatType: NumberFormat.UPPER_ROMAN },
      },
    },
    headers: { default: docHeader(headerText) },
    footers: { default: pageFooter() },
    children: frontChildren,
  });
  bodySections.forEach((bs, i) => {
    const size = bs.landscape
      ? { width: 16838, height: 11906, orientation: PageOrientation.LANDSCAPE }
      : PAGE.size;
    const margin = bs.landscape ? { top: 1200, bottom: 1200, left: 1200, right: 1200 } : PAGE.margin;
    const props = {
      type: SectionType.NEXT_PAGE,
      page: { size, margin },
    };
    if (i === 0) props.page.pageNumbers = { start: 1, formatType: NumberFormat.DECIMAL };
    sections.push({
      properties: props,
      headers: { default: docHeader(headerText) },
      footers: { default: pageFooter() },
      children: bs.children,
    });
  });
  return new Document({
    creator: "System Engineering",
    title: coverConfig.title,
    styles: {
      default: {
        document: {
          run: { font: AR, size: 24, color: P.body },
          paragraph: { spacing: { line: 312 } },
        },
        heading1: { run: { font: AR, size: 32, bold: true, color: P.primary },
          paragraph: { spacing: { before: 360, after: 160 }, outlineLevel: 0 } },
        heading2: { run: { font: AR, size: 28, bold: true, color: P.primary },
          paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1 } },
        heading3: { run: { font: AR, size: 25, bold: true, color: P.accentDark },
          paragraph: { spacing: { before: 220, after: 100 }, outlineLevel: 2 } },
      },
    },
    sections,
  });
}

async function writeDoc(doc, outPath) {
  const buf = await Packer.toBuffer(doc);
  fs.writeFileSync(outPath, buf);
  console.log("WROTE", outPath, Math.round(buf.length / 1024) + "KB");
}

module.exports = {
  P, AR, CODE, safeText, arRun, codeRun, pBody, pStart, h1, h2, h3, bullet,
  codeBlock, rtlTable, tCaption, fCaption, image, buildCoverR1RTL,
  docHeader, pageFooter, tocBlock, buildDoc, writeDoc,
};
