// endpoints_core.js — Auth, Organization, RBAC, Products/Pricing, Parties endpoints
const { listEp, getEp, createEp, updateEp, deleteEp, actionEp, OK_ONE, OK_MSG, J } = require("./endpoints_lib");

// ═══════════ 1. AUTH ═══════════
const AUTH = [
  {
    id: "auth_login", title: "تسجيل الدخول", method: "POST", path: "/auth/login", perm: "عام — بلا توكن",
    desc: "التحقق من بيانات الدخول وإصدار access_token (15 دقيقة) وrefresh_token (7 أيام). يرفض الحسابات المعطلة ويسجل المحاولات الفاشلة ويقفل الحساب بعد 5 محاولات (AUTH_004). يرجع مع الدخول خريطة صلاحيات المستخدم الجاهزة للاستخدام في الواجهة (مع بقاء الفحص الفعلي على الخادم).",
    req: J({ username: "admin", password: "••••••••", device_id: "ANDROID-9F2C-UNIQUE", device_name: "Redmi Note 12", push_token: "fcm:..." }),
    res: `{\n  "success": true,\n  "data": {\n    "access_token": "eyJhbGciOi...",\n    "refresh_token": "d8f3a1...",\n    "expires_in": 900,\n    "user": {\n      "id": 5, "uuid": "u-9f2c...", "username": "admin", "full_name": "أحمد المدير",\n      "company_id": 1, "branch_id": 1, "language": "ar", "theme": "system"\n    },\n    "permissions": ["sales.invoice.view", "sales.invoice.create", "inventory.transfer.approve"]\n  }\n}`,
    errors: [["AUTH_001", "401", "بيانات غير صحيحة"], ["AUTH_004", "423", "الحساب مقفول مؤقتًا"], ["AUTH_005", "403", "الحساب موقوف"]],
    validation: ["username وpassword إجباريان", "device_id إجباري من تطبيق الموبايل لتسجيل الجهاز", "IP يسجل في سجل المصادقة"],
  },
  {
    id: "auth_refresh", title: "تحديث الرمز", method: "POST", path: "/auth/refresh", perm: "عام — بلا توكن",
    desc: "تبديل refresh_token صالح برمز وصول جديد مع دوران refresh_token (يُبطل القديم). أي محاولة استخدام رمز دوران مسبق الاستخدام ترفض وتلغي السلسلة كلها كإجراء أمني.",
    req: J({ refresh_token: "d8f3a1..." }),
    res: `{\n  "success": true,\n  "data": {\n    "access_token": "eyJhbGciOi...",\n    "refresh_token": "NEW_4e7b2c...",\n    "expires_in": 900\n  }\n}`,
    errors: [["AUTH_003", "401", "رمز التحديث غير صالح أو مُستهلك"]],
  },
  { id: "auth_logout", title: "تسجيل الخروج", method: "POST", path: "/auth/logout", perm: "مصادقة",
    desc: "إبطال الرموز الحالية وجلسة الجهاز. الطلبات اللاحقة بنفس الرمز ترفض.",
    req: null, res: OK_MSG("تم تسجيل الخروج"), errors: [] },
  {
    id: "auth_me", title: "بياناتي وصلاحياتي", method: "GET", path: "/auth/me", perm: "مصادقة",
    desc: "يعرض المستخدم الحالي وصلاحياته ونطاق مستودعاته (user_warehouse_access) وإعداداته — يستخدمها الواجهة لبناء القوائم والشاشات المسموحة.",
    req: null,
    res: `{\n  "success": true,\n  "data": {\n    "user": { "id": 12, "username": "rep_ahmed", "full_name": "أحمد حسن", "role": "sales_rep" },\n    "permissions": ["sales.invoice.create", "payments.create", "visits.create"],\n    "warehouses": [{ "id": 7, "code": "REP-AHMED", "can_read": true, "can_operate": true }],\n    "assigned_warehouse_id": 7\n  }\n}`,
    errors: [],
  },
  {
    id: "auth_change_password", title: "تغيير كلمة المرور", method: "POST", path: "/auth/change-password", perm: "مصادقة",
    desc: "تغيير كلمة المرور للجلسة الحالية بعد التحقق من القديمة، مع إبطال كل الجلسات الأخرى اختياريًا.",
    req: J({ old_password: "••••", new_password: "••••••••", logout_others: true }),
    res: OK_MSG("تم تغيير كلمة المرور"),
    errors: [["AUTH_001", "401", "كلمة المرور القديمة غير صحيحة"], ["VALIDATION_001", "422", "كلمة المرور الجديدة لا تلبي سياسة التعقيد"]],
    validation: ["سياسة التعقيد: 8 أحرف فأكثر مع حرف كبير ورقم على الأقل", "لا تُقبل آخر 3 كلمات مرور سابقة"],
  },
  {
    id: "auth_forgot_password", title: "طلب إعادة تعيين", method: "POST", path: "/auth/forgot-password", perm: "عام",
    desc: "إرسال رابط/رمز إعادة تعيين مؤقت إلى البريد المسجل. الرد موحّد سواء وُجد البريد أم لا (منع حصر الحسابات).",
    req: J({ email: "user@company.com" }), res: OK_MSG("إن كان البريد مسجلًا فستصلك رسالة إعادة التعيين"), errors: [],
  },
  {
    id: "auth_reset_password", title: "تنفيذ إعادة التعيين", method: "POST", path: "/auth/reset-password", perm: "عام — يتطلب رمزًا",
    desc: "إعادة تعيين كلمة المرور باستخدام الرمز المؤقت المرسل، ثم إبطال كل الجلسات القائمة إجباريًا.",
    req: J({ token: "6d2f8a...", new_password: "••••••••" }),
    res: OK_MSG("تمت إعادة التعيين — سجل الدخول من جديد"),
    errors: [["AUTH_002", "401", "الرمز منتهي أو مستخدم مسبقًا"]],
  },
  {
    id: "auth_sessions", title: "جلساتي وأجهزتي", method: "GET", path: "/auth/sessions", perm: "مصادقة",
    desc: "قائمة جلسات المستخدم النشطة بأجهزتها وآخر ظهور، مع إمكانية إبطال جلسة بعينها.",
    req: null,
    res: `{\n  "success": true,\n  "data": [\n    { "id": 31, "device_id": "ANDROID-9F2C", "platform": "ANDROID", "last_seen_at": "2026-09-09T09:14:00Z", "current": true },\n    { "id": 17, "device_id": "WEB-CHROME-OFFICE", "platform": "WEB", "last_seen_at": "2026-09-08T16:40:00Z", "current": false }\n  ]\n}`,
    errors: [],
  },
  {
    id: "auth_revoke_session", title: "إبطال جلسة", method: "DELETE", path: "/auth/sessions/{id}", perm: "مصادقة (مالك الجلسة)",
    desc: "إنهاء جلسة/جهاز معين فورًا — يستخدم عند فقدان الهاتف مثلًا.",
    req: null, res: OK_MSG("تم إبطال الجلسة"),
    errors: [["NOT_FOUND", "404", "الجلسة غير موجودة أو ليست لك"]],
  },
];

// ═══════════ 2. ORGANIZATION (Companies / Branches / Warehouses / Users / Roles / Permissions) ═══════════
const ORG = [
  ...[["الشركات", "companies"], ["الفروع", "branches"], ["المستودعات", "warehouses"]].map(([t, e]) =>
    listEp({ entity: t, path: `/${e}`, perm: `admin.${e.replace(/s$/, "")}`, example: `{ "id": 1, "code": "BGW", "name": "فرع بغداد", "is_active": true }` })),
  ...["branches", "warehouses"].flatMap((e) => [
    createEp({ entity: e, path: `/${e}`, perm: `admin.${e.replace(/s$/, "")}`,
      req: e === "branches" ? J({ code: "BSR", name: "فرع البصرة", city: "البصرة", phone: "07800000000" }) : J({ branch_id: 2, code: "REP-ALI", name: "مخزن المندوب علي", type: "REP", is_mobile: true, manager_id: 15 }),
      res: OK_ONE(e === "branches" ? { id: 4, code: "BSR", name: "فرع البصرة", is_active: true } : { id: 12, code: "REP-ALI", type: "REP", is_active: true }),
      desc: e === "branches" ? "إنشاء فرع جديد ضمن الشركة. يتحقق من فرادة الرمز داخل الشركة." :
        "إنشاء مستودع بنوعه (MAIN/BRANCH/REP/TRANSIT/DAMAGED). إنشاء مخزن مندوب REP يتطلب ربطه لاحقًا بمندوب واحد عبر sales_reps. لا يمكن حذف مستودع عليه أرصدة — يُعطَّل فقط." }),
    updateEp({ entity: e, path: `/${e}`, perm: `admin.${e.replace(/s$/, "")}`, req: J({ name: "اسم محدث" }), res: OK_MSG("تم التحديث") }),
    deleteEp({ entity: e, path: `/${e}`, perm: `admin.${e.replace(/s$/, "")}`, desc: e === "warehouses" ? "حذف ناعم — يُرفض فورًا إن كان على المستودع أي أرصدة أو حركات (STOCK STATE)." : "حذف ناعم للفرع الخالي من مستودعات ومستخدمين." }),
  ]),
  {
    id: "companies_update", title: "تحديث بيانات الشركة", method: "PUT", path: "/companies/{id}", perm: "admin.company.edit",
    desc: "تحديث بيانات الشركة (اسم، شعار، عملة، سياسة التكلفة، السماح بالسالب...). تغيير العملة الأساسية بعد وجود حركات يتطلب سببًا ويُسجَّل تدقيقيًا ولا يعيد تقييم السجلات القديمة.",
    req: J({ name: "شركة النور للتوزيع", logo_url: "https://files.../logo.png", allow_negative_stock: false, costing_method: "WAVG" }),
    res: OK_MSG("تم التحديث"),
    errors: [["PERM_001", "403", "صلاحية Owner/Super Admin فقط"]],
  },

  listEp({ entity: "المستخدمون", path: "/users", perm: "admin.user", example: `{ "id": 12, "username": "rep_ahmed", "full_name": "أحمد حسن", "branch_id": 1, "is_active": true, "roles": ["sales_rep"] }`,
    desc: "قائمة المستخدمين مع أدوارهم وحالتهم. المندوبون يظهرون بمعرف مخازنهم. يدعم المرشح: branch_id, role, is_active, search بالاسم/الهاتف." }),
  createEp({ entity: "المستخدمون", path: "/users", perm: "admin.user.create",
    req: J({ username: "rep_ali", full_name: "علي محمد", password: "••••••••", phone: "07700000000", branch_id: 1, role_ids: [6], warehouse_ids: [12], language: "ar" }),
    res: OK_ONE({ id: 15, username: "rep_ali", is_active: true }),
    desc: "إنشاء مستخدم مع أدواره ونطاق مستودعاته دفعة واحدة. كلمة المرور تُجزَّأ فورًا ولا تُخزن صريحة أبدًا؛ إسناد دور sales_rep يتطلب تحديد مخزن REP واحد يصبح مخزن البيع الإجباري.",
    validation: ["username فريد داخل الشركة", "role_ids موجودة", "المندوب: مستودع واحد من نوع REP", "company_id من التوكن — لا يُقبل من الجسم"] }),
  updateEp({ entity: "المستخدمون", path: "/users", perm: "admin.user.edit", req: J({ full_name: "علي محمد حسن", is_active: true, role_ids: [6] }), res: OK_MSG("تم التحديث"),
    desc: "تعديل بيانات/أدوار/نطاق مستودعات. تعطيل المندوب يمنع دخوله ويُبقي سجلاته التاريخية سليمة (created_by يبقى سليمًا) — الاختبار الحرج 10." }),
  deleteEp({ entity: "المستخدمون", path: "/users", perm: "admin.user.delete",
    desc: "حذف ناعم فقط. لا يُحذف مستخدم له حركات إطلاقًا بل يُعطَّل — حماية السجل التاريخي." }),
  actionEp({ entity: "المستخدمون", action: "unlock", path: "/users", perm: "admin.user.edit", title: "فك قفل الحساب",
    desc: "تصفير عداد المحاولات الفاشلة ورفع القفل المؤقت عن حساب قُفل بسببه.",
    res: OK_MSG("تم فك القفل") }),

  listEp({ entity: "الأدوار", path: "/roles", perm: "admin.role", example: `{ "id": 6, "code": "SALES_REP", "name": "مندوب مبيعات", "is_system": true, "permissions_count": 24 }`,
    desc: "قائمة الأدوار مع عدد صلاحيات كل دور. أدوار النظام الإحدى عشرة لا تُحذف." }),
  createEp({ entity: "الأدوار", path: "/roles", perm: "admin.role.create", req: J({ code: "REGION_MGR", name: "مدير منطقة", permission_ids: [101, 102, 108, 220] }), res: OK_ONE({ id: 13, code: "REGION_MGR" }),
    desc: "دور مخصص بمجموعة صلاحيات محددة. منح صلاحية post/reverse يقتصر عمليًا على الأدوار الإدارية ويُسجَّل تعديل خريطة الصلاحيات كاملًا في audit_logs." }),
  getEp({ entity: "الدور", path: "/roles", perm: "admin.role", example: `{ "id": 6, "code": "SALES_REP", "permissions": ["sales.invoice.create", "payments.create"] }` }),
  updateEp({ entity: "الأدوار", path: "/roles", perm: "admin.role.edit", req: J({ permission_ids: [101, 102, 108] }), res: OK_MSG("تم تحديث صلاحيات الدور"),
    desc: "استبدال كامل لمجموعة صلاحيات الدور (دلالة PUT). التأثير فوري لكل مستخدمي الدور — لذا يسجل القديم والجديد في audit_logs.", reqNote: true }),
  deleteEp({ entity: "الأدوار", path: "/roles", perm: "admin.role.delete", desc: "يُرفض حذف دور عليه مستخدمون (is_system أو مرتبط). يُعطَّل أو يُفرَّغ أولًا." }),

  {
    id: "permissions_list", title: "كتالوج الصلاحيات", method: "GET", path: "/permissions", perm: "admin.role.view",
    desc: "الكتالوج الكامل للصلاحيات الذرية بصيغة module.action مجمعة حسب الوحدة — يُبنى منه محرر مصفوفة الصلاحيات في الواجهة.",
    req: null,
    res: `{\n  "success": true,\n  "data": [\n    { "module": "sales", "entity": "invoice", "actions": ["view","create","edit","delete","approve","cancel","print","export","post","reverse"] },\n    { "module": "inventory", "entity": "transfer", "actions": ["view","create","approve","cancel"] }\n  ]\n}`,
    errors: [],
  },
  {
    id: "permissions_matrix", title: "مصفوفة صلاحيات دور", method: "GET", path: "/roles/{id}/permissions", perm: "admin.role.view",
    desc: "قائمة أكواد الصلاحيات الممنوحة لدور محدد — تُستخدم عند التعديل لعرض الحالة الحالية.",
    req: null, res: `{\n  "success": true,\n  "data": { "role_id": 6, "codes": ["sales.invoice.view","sales.invoice.create","payments.create"] }\n}`,
    errors: [["NOT_FOUND", "404", "الدور غير موجود"]],
  },
];

// ═══════════ 3. PRODUCTS & PRICING ═══════════
const PROD_EX = `{ "id": 42, "uuid": "p-88c1...", "sku": "SHM-TB-400", "name_ar": "شامبو طبي 400مل", "category_id": 7, "brand_id": 3, "base_unit": { "id": 1, "code": "PCS" }, "cost_price": 1500, "default_sale_price": 2500, "tax_rate": 0, "stock": { "on_hand": 640, "available": 610 }, "is_active": true }`;

const PRODUCTS = [
  listEp({ entity: "المنتجات", path: "/products", perm: "inventory.product", example: PROD_EX,
    desc: "قائمة المنتجات مع الرصيد المتاح الإجمالي (عبر stock_balances) لكل صف. يدعم البحث بالاسم العربي/الإنجليزي وSKU والباركود، ومرشحات category_id, brand_id, is_active, low_stock=true للمنتجات تحت حد إعادة الطلب. مُحسَّن لبحث POS أقل من 200ms عبر فهارس مخصصة.",
    filters: ["page/per_page", "search: name_ar/name_en/sku/barcode", "category_id, brand_id", "low_stock=true: المتاح أقل من حد الطلب", "sort: name_ar|sku|created_at"] }),
  getEp({ entity: "المنتج", path: "/products", perm: "inventory.product", example: PROD_EX }),
  createEp({ entity: "المنتجات", path: "/products", perm: "inventory.product.create",
    req: J({ sku: "SHM-TB-400", name_ar: "شامبو طبي 400مل", name_en: "Medic Shampoo 400ml", category_id: 7, brand_id: 3, base_unit_id: 1, cost_price: 1500, default_sale_price: 2500, min_sale_price: 2000, tax_rate: 0, reorder_level: 50, is_batch_tracked: false, barcodes: [{ barcode: "6290123456789", barcode_type: "EAN13", unit_id: 1, is_primary: true }] }),
    res: OK_ONE({ id: 42, sku: "SHM-TB-400", is_active: true }),
    desc: "إنشاء منتج مع باركوداته الأولية دفعة واحدة. SKU فريد داخل الشركة، وتفعيل التتبع بالدفعات/التسلسل يُلزم الحركات اللاحقة بتعبئة بيانات التتبع.",
    errors: [["CONFLICT_001", "409", "SKU أو الباركود مستخدم مسبقًا"], ["VALIDATION_001", "422", "بيانات ناقصة"]] }),
  updateEp({ entity: "المنتجات", path: "/products", perm: "inventory.product.edit",
    req: J({ default_sale_price: 2600, reorder_level: 60 }), res: OK_MSG("تم التحديث"),
    desc: "تعديل بيانات المنتج. أي تغيير للسعر الافتراضي أو الحد الأدنى يسجل تدقيقيًا (Changed Price ضمن أمثلة القسم 42)." }),
  deleteEp({ entity: "المنتجات", path: "/products", perm: "inventory.product.delete",
    desc: "حذف ناعم — يُرفض للمنتج عليه حركات أو أرصدة (STATE_003) فيُعطَّل is_active بدلًا منه." }),
  actionEp({ entity: "المنتجات", action: "toggle-active", path: "/products", perm: "inventory.product.edit", title: "تعطيل/تفعيل منتج",
    desc: "تبديل حالة التفعيل — يخفي المنتج من POS والقوائم البيعية دون مساس بسجلاته.",
    req: J({ is_active: false }), res: OK_MSG("تم تغيير حالة المنتج") }),

  listEp({ entity: "التصنيفات", path: "/categories", perm: "inventory.category", example: `{ "id": 7, "name": "شامبو", "parent_id": 1, "level": 1, "children_count": 2, "products_count": 34 }`,
    desc: "إرجاع الشجرة كاملة أو غصن واحد (parent_id). المجموعات المنتجة children/products_count لعرض الشجرة التفاعلية." }),
  createEp({ entity: "التصنيفات", path: "/categories", perm: "inventory.category.create", req: J({ name: "طبي", parent_id: 7 }), res: OK_ONE({ id: 9, level: 2 }), desc: "إضافة عقدة للشجرة مع تحديث level آليًا." }),
  updateEp({ entity: "التصنيفات", path: "/categories", perm: "inventory.category.edit", req: J({ name: "شامبو طبي" }), res: OK_MSG("تم التحديث"),
    desc: "تعديل عقدة. نقل العقدة تحت سليل منها يرفض SCOPE/VALIDATION (منع الحلقات)." }),
  deleteEp({ entity: "التصنيفات", path: "/categories", perm: "inventory.category.delete", desc: "حذف ناعم لعقدة بلا أبناء وبلا منتجات فقط." }),

  ...[["العلامات", "brands"], ["الوحدات", "units"]].map(([t, e]) => listEp({ entity: t, path: `/${e}`, perm: `inventory.${e.replace(/s$/, "")}`, example: `{ "id": 3, "code": "CTN", "name": "كرتونة", "type": "COUNT" }` })),
  createEp({ entity: "الوحدات", path: "/units", perm: "inventory.unit.create", req: J({ code: "DZN", name: "دستة", type: "COUNT" }), res: OK_ONE({ id: 8 }), desc: "إضافة وحدة قياس جديدة." }),
  createEp({ entity: "العلامات", path: "/brands", perm: "inventory.brand.create", req: J({ code: "BR3", name: "علامة ثلاثة" }), res: OK_ONE({ id: 5 }), desc: "إضافة علامة تجارية." }),
  createEp({ entity: "تحويلات الوحدات", path: "/unit-conversions", perm: "inventory.unit.create",
    req: J({ from_unit_id: 3, to_unit_id: 1, factor: 24 }),
    res: OK_ONE({ id: 11, factor: 24 }),
    desc: "تعريف 1 كرتونة = 24 قطعة. فحص الاتجاه المعاكس تلقائيًا لمنع التعريفات المتناقضة.",
    errors: [["CONFLICT_001", "409", "التحويل معرف مسبقًا بعكس الاتجاه"]] }),
  listEp({ entity: "تحويلات الوحدات", path: "/unit-conversions", perm: "inventory.unit", example: `{ "id": 11, "from": "CTN", "to": "PCS", "factor": 24 }` }),

  listEp({ entity: "الباركودات", path: "/products/{id}/barcodes", perm: "inventory.product", example: `{ "id": 91, "barcode": "6290123456789", "type": "EAN13", "unit": "PCS", "is_primary": true }`,
    desc: "باركودات منتج واحد — أداة إدارة من داخل صفحة المنتج." }),
  createEp({ entity: "الباركودات", path: "/products/{id}/barcodes", perm: "inventory.product.edit",
    req: J({ barcode: "6290987654321", barcode_type: "EAN13", unit_id: 3, is_primary: false }),
    res: OK_ONE({ id: 92 }),
    desc: "إضافة باركود لمنتج (مثل باركود الكرتونة). الفريد عالميًا — فحص POS حاسم.",
    errors: [["CONFLICT_001", "409", "الباركود مسجل لمنتج آخر"]] }),
  deleteEp({ entity: "الباركودات", path: "/products/barcodes", perm: "inventory.product.edit", desc: "إزالة باركود — لا يُحذف الأساسي إلا بإسناد بديل." }),

  listEp({ entity: "قوائم الأسعار", path: "/price-lists", perm: "pricing.list", example: `{ "id": 2, "code": "WHS", "name": "أسعار الجملة", "priority": 10, "is_default": false, "items_count": 480 }`,
    desc: "قوائم الأسعار بأولويتها وفترات سريانها. الأولوية الأقل رقمًا أعلى ضمن الساري زمنيًا." }),
  createEp({ entity: "قوائم الأسعار", path: "/price-lists", perm: "pricing.list.create", req: J({ code: "VIP", name: "أسعار VIP", priority: 5, currency_code: "IQD", valid_from: "2026-01-01" }), res: OK_ONE({ id: 4 }),
    desc: "إنشاء قائمة أسعار جديدة. قائمة واحدة فقط قد تكون is_default." }),
  actionEp({ entity: "قوائم الأسعار", action: "items", path: "/price-lists", perm: "pricing.list.view", title: "بنود قائمة أسعار",
    desc: "بنود القائمة بفلترة product_id/unit_id؛ تدعم الترقيم والبحث السريع.",
    res: `{\n  "success": true,\n  "data": [\n    { "product_id": 42, "product": "شامبو طبي 400مل", "unit": "CTN", "price": 54000, "min_quantity": 1, "valid_from": "2026-01-01" }\n  ],\n  "pagination": { "page": 1, "per_page": 20, "total": 480, "total_pages": 24 }\n}` }),
  actionEp({ entity: "قوائم الأسعار", action: "items (إضافة/تحديث دفعي)", path: "/price-lists/{id}/items/bulk", perm: "pricing.list.edit", title: "رفع بنود دفعي",
    desc: "استبدال/إضافة دفعة بنود (حتى 1000 بند للطلب) — يستخدمه محرر القوائم والاستيراد.",
    req: J({ items: [{ product_id: 42, unit_id: 3, price: 54000, min_quantity: 1 }], mode: "upsert" }),
    res: OK_MSG("تمت معالجة 1 بند", { upserted: 1, skipped: 0 }),
    errors: [["VALIDATION_001", "422", "بند غير صالح — يرجع فهرس البند وسببه"]] }),

  listEp({ entity: "أسعار العملاء الخاصة", path: "/customer-prices", perm: "pricing.customer_price", example: `{ "id": 7, "customer": "تاجر الرافدين", "product": "شامبو طبي", "price": 2300, "min_quantity": 24 }`,
    desc: "أعلى طبقة تسعير — تعاقديات العملاء. مرشح customer_id إجباري افتراضيًا." }),
  createEp({ entity: "أسعار العملاء الخاصة", path: "/customer-prices", perm: "pricing.customer_price.create",
    req: J({ customer_id: 88, product_id: 42, unit_id: 1, price: 2300, min_quantity: 24, valid_from: "2026-09-01" }),
    res: OK_ONE({ id: 7 }), desc: "سعر تعاقدي يتفوق على القوائم والمجموعات في محرك التسعير." }),
  deleteEp({ entity: "أسعار العملاء الخاصة", path: "/customer-prices", perm: "pricing.customer_price.delete", desc: "إزالة تعاقد — يعود التسعير للطبقة التالية فورًا." }),
];

// ═══════════ 4. PARTIES (Customers / Suppliers) ═══════════
const CUST_EX = `{ "id": 88, "code": "CUS-0012", "name": "تاجر الرافدين", "phone": "07701234567", "customer_group": "جملة", "sales_rep": "أحمد حسن", "credit_limit": 5000000, "current_balance": 1250000, "payment_term_days": 30, "is_active": true }`;

const PARTIES = [
  listEp({ entity: "العملاء", path: "/customers", perm: "sales.customer", example: CUST_EX,
    desc: "قائمة العملاء. المندوب يرى عملاءه المُسندين فقط تلقائيًا (SCOPE مفروض على الخادم)، والمشرف يرى نطاقه. بحث سريع بالاسم والهاتف والكود.",
    filters: ["search: name/phone/code", "sales_rep_id (للمشرفين)", "customer_group_id", "overdue=true: لديه فواتير متأخرة"] }),
  getEp({ entity: "العميل", path: "/customers", perm: "sales.customer", example: CUST_EX }),
  createEp({ entity: "العملاء", path: "/customers", perm: "sales.customer.create",
    req: J({ code: "CUS-0012", name: "تاجر الرافدين", phone: "07701234567", province: "بغداد", district: "الكرادة", customer_group_id: 2, sales_rep_id: 12, credit_limit: 5000000, payment_term_days: 30, opening_balance: 0, latitude: 33.3152, longitude: 44.3661 }),
    res: OK_ONE({ id: 88, code: "CUS-0012" }),
    desc: "إنشاء عميل. الرصيد الافتتاحي غير الصفري يولّد قيد OPENING في customer_ledger داخل نفس المعاملة — لا رصيد بلا حركة موثقة. كود العميل مولّد آليًا إذا لم يُمرر.",
    validation: ["الهاتف إجباري وصيغته عراقية مقبولة", "credit_limit >= 0", "المندوب المُسند يجب أن يكون نشطًا"] }),
  updateEp({ entity: "العملاء", path: "/customers", perm: "sales.customer.edit", req: J({ phone: "07709998887", credit_limit: 6000000 }), res: OK_MSG("تم التحديث"),
    desc: "تعديل بيانات العميل. رفع حد الائتمان فوق السقف المعرف يفتح طلب موافقة CREDIT_LIMIT تلقائيًا بدل التنفيذ المباشر (حسب الإعداد)." }),
  deleteEp({ entity: "العملاء", path: "/customers", perm: "sales.customer.delete", desc: "حذف ناعم للعميل بلا حركات/أرصدة فقط." }),
  actionEp({ entity: "العميل", action: "ledger", path: "/customers", perm: "sales.customer.view", title: "كشف حساب العميل",
    desc: "كشف الحساب اللحظي من customer_ledger مع الرصيد التراكمي balance_after، ومرشح فترة، وصفحة تصلح للطباعة PDF مباشرة.",
    req: null,
    res: `{\n  "success": true,\n  "data": [\n    { "date": "2026-09-01", "entry_type": "INVOICE", "reference": "INV-2026-000451", "debit": 1200000, "credit": 0, "balance_after": 1200000 },\n    { "date": "2026-09-03", "entry_type": "PAYMENT", "reference": "PAY-2026-000302", "debit": 0, "credit": 500000, "balance_after": 700000 }\n  ],\n  "summary": { "opening": 0, "total_debit": 1200000, "total_credit": 500000, "closing": 700000 }\n}` }),

  listEp({ entity: "مجموعات العملاء", path: "/customer-groups", perm: "sales.customer", example: `{ "id": 2, "code": "WHS", "name": "جملة", "price_list": "أسعار الجملة", "customers_count": 64 }` }),
  createEp({ entity: "مجموعات العملاء", path: "/customer-groups", perm: "sales.customer.create", req: J({ code: "VIP2", name: "تجار مميزون", price_list_id: 4, max_discount_percent: 8 }), res: OK_ONE({ id: 5 }), desc: "مجموعة تسعير/تحليل مع قائمة أسعار وسقف خصم." }),
  updateEp({ entity: "مجموعات العملاء", path: "/customer-groups", perm: "sales.customer.edit", req: J({ max_discount_percent: 10 }), res: OK_MSG("تم التحديث") }),
  deleteEp({ entity: "مجموعات العملاء", path: "/customer-groups", perm: "sales.customer.delete", desc: "حذف ناعم — يُرفض إن كانت المجموعة عليها عملاء." }),

  actionEp({ entity: "العميل", action: "contacts", path: "/customers", perm: "sales.customer.view", title: "جهات اتصال العميل",
    desc: "قائمة/إدارة جهات اتصال العميل المتعددة.", res: `{\n  "success": true,\n  "data": [\n    { "id": 4, "name": "أبو محمد", "position": "المدير", "phone": "07701112233", "is_primary": true }\n  ]\n}` }),
  actionEp({ entity: "العميل", action: "addresses", path: "/customers", perm: "sales.customer.view", title: "عناوين العميل",
    desc: "عناوين العميل مع الإحداثيات والعنوان الافتراضي للتوصيل.",
    res: `{\n  "success": true,\n  "data": [\n    { "id": 9, "label": "المستودع", "address": "بغداد - الكرادة - شارع 62", "latitude": 33.3152, "longitude": 44.3661, "is_default": true }\n  ]\n}` }),

  listEp({ entity: "الموردون", path: "/suppliers", perm: "purchasing.supplier", example: `{ "id": 5, "code": "SUP-0003", "name": "مورد الشرق", "phone": "07801234567", "current_balance": 3200000, "payment_terms": 45 }`,
    desc: "قائمة الموردين مع الأرصدة المستحقة (Payables) من supplier_ledger. بحث بالاسم والهاتف." }),
  getEp({ entity: "المورد", path: "/suppliers", perm: "purchasing.supplier", example: `{ "id": 5, "code": "SUP-0003", "name": "مورد الشرق", "tax_number": "IQ-12345", "current_balance": 3200000 }` }),
  createEp({ entity: "الموردون", path: "/suppliers", perm: "purchasing.supplier.create",
    req: J({ code: "SUP-0003", name: "مورد الشرق", phone: "07801234567", payment_terms: 45, opening_balance: 0 }),
    res: OK_ONE({ id: 5 }),
    desc: "إنشاء مورد. الرصيد الافتتاحي يولّد قيد OPENING في supplier_ledger آليًا." }),
  updateEp({ entity: "الموردون", path: "/suppliers", perm: "purchasing.supplier.edit", req: J({ payment_terms: 60 }), res: OK_MSG("تم التحديث") }),
  deleteEp({ entity: "الموردون", path: "/suppliers", perm: "purchasing.supplier.delete", desc: "حذف ناعم للمورد بلا فواتير/حركات فقط." }),
  actionEp({ entity: "المورد", action: "ledger", path: "/suppliers", perm: "purchasing.supplier.view", title: "كشف حساب المورد",
    desc: "كشف حساب المورد اللحظي مع الأرصدة الدائنة والمدينة وفقًا لقسم 11 من الوثيقة الأم.",
    req: null,
    res: `{\n  "success": true,\n  "data": [\n    { "date": "2026-09-02", "entry_type": "SUPPLIER_INVOICE", "reference": "SIN-2026-000077", "debit": 0, "credit": 4500000, "balance_after": 4500000 },\n    { "date": "2026-09-05", "entry_type": "PAYMENT", "reference": "PAY-2026-000310", "debit": 2000000, "credit": 0, "balance_after": 2500000 }\n  ],\n  "summary": { "closing": 2500000 }\n}` }),
];

module.exports = { AUTH, ORG, PRODUCTS, PARTIES };
