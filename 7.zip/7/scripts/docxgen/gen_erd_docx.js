// gen_erd_docx.js — Full Database ERD document (Arabic RTL)
const {
  P, arRun, codeRun, pBody, pStart, h1, h2, h3, bullet,
  codeBlock, rtlTable, tCaption, fCaption, image, tocBlock, buildDoc, writeDoc,
} = require("./ar_lib");
const { Paragraph, TextRun, PageBreak, AlignmentType } = require("docx");

const { D1_CORE, D2_PRODUCTS, D3_PARTIES } = require("./tables_core");
const { D4_STOCK, D5_MOVEMENTS, D8_PURCHASING, D9_FINANCE } = require("./tables_ops");
const { D6_SALES, D7_PAYMENTS, D10_FIELD_SALES, D11_SYSTEM } = require("./tables_sales");

const ERD_DIR = "/home/z/my-project/assets/erd";
const OUT = "/home/z/my-project/download/01_ERD_تصميم_قاعدة_البيانات.docx";

// ───────────────────────── Front matter: Executive summary ─────────────────────────
const summary = [
  h1("الملخص التنفيذي"),
  pBody("تصمّم هذه الوثيقة قاعدة البيانات المرجعية الكاملة لنظام إدارة المبيعات والمخزون والمندوبين والفواتير والتوزيع، على محرك PostgreSQL 16 وما بعده، وذلك بوصفها الوثيقة التنفيذية الأولى المستخلصة من الوثيقة الأم (وثيقة التنفيذ الشاملة v1.0). تغطي الوثيقة واحدًا وثمانين جدولًا موزعة على أحد عشر مجالًا وظيفيًا، مع مخطط علاقات كيانات ERD لكل مجال، ومواصفات تفصيلية على مستوى الحقل: النوع، والقيود، والفهارس، ووصف الوظيفة بالعربية."),
  pBody("يقوم التصميم على مبدأ النظام القائم على المعاملات Transaction-Based: لا يتغير أي رصيد — مخزونًا كان أو ذمة عميل أو رصيد صندوق — إلا بحركة موثقة في دفتر لاتحققي Append-only يحمل مرجعًا حتميًا إلى المستند الذي سبّبه. وعليه فقد بُنيت الجداول بحيث تكون كل عملية بيع أو شراء أو تحويل أو تسوية معاملة ذرية واحدة تنجح كلها أو تفشل كلها، مع قيود قاعدة بيانات صارمة تمنع الأرصدة السالبة غير المصرح بها والترحيل المزدوج وحذف المستندات المعتمدة."),
  pBody("صُممت القاعدة منذ اليوم الأول لتعدد الشركات Multi-Tenant عبر عمود company_id في كل جدول ذي نطاق، ولدعم العمل دون اتصال Offline للمندوبين عبر مفتاح تكرار فريد client_transaction_id يمنع ازدواجية الترحيل، ولقابلية الترقية إلى SaaS. توثّق الوثيقة كذلك آلات الحالة الخاصة بالمستندات الحرجة (الفاتورة، التحويل، المرتجع)، وخريطة صريحة لقواعد الأعمال العشر في الوثيقة الأم إلى مواضع تنفيذها في التصميم، بما يجعلها المرجع الملزم المباشر لوكيل الذكاء الاصطناعي المطور وأي فريق هندسي لاحق."),
];

// ───────────────────────── Chapter 1: Conventions ─────────────────────────
const ch1 = [
  h1("1. نطاق الوثيقة واتفاقيات التصميم"),
  pBody("تمثل هذه الوثيقة التصميم المنطقي والبدني الفعلي لقاعدة البيانات، وتعد المرجع الحاسم عند أي خلاف تفسيري أثناء التنفيذ. كل جدول ورد فيما يلي بأعمدته الخاصة فقط، بينما تُفهم الأعمدة القياسية المبينة في القسم 1.2 موجودة ضمنًا في كل جدول موسوم بأنه قياسي (std). أسماء الجداول والأعمدة بالإنجليزية snake_case لأنها معرفات فعلية ستُنشأ في PostgreSQL، وكل الشروحات والقيم الوصفية بالعربية."),
  h2("1.1 الأعمدة القياسية الموحدة"),
  pBody("كل جدول يوسوم بـ (قياسي) في هذه الوثيقة يحمل تلقائيًا الأعمدة الآتية دون تكرارها في جداول الحقول، ما يقلص التكرار ويوحّد السلوك عبر المجالات. الاستثناءات الوحيدة هي جداول الربط وجداول الدفاتر التي لا معنى للحذف الناعم فيها، والمشار إليها صراحة.", { keepNext: true }),
  tCaption("جدول 1-1: الأعمدة القياسية ووظيفة كل منها"),
  rtlTable(
    [{ w: 20, header: "العمود" }, { w: 22, header: "النوع" }, { w: 58, header: "الوظيفة والقاعدة" }],
    [
      [{ t: "id", code: true }, { t: "BIGINT", code: true }, "مفتاح أساسي GENERATED ALWAYS AS IDENTITY — كفاءة عالية للانضمامات والفهرسة"],
      [{ t: "uuid", code: true }, { t: "UUID", code: true }, "معرف عام DEFAULT gen_random_uuid() فريد — يُستخدم في URLs والـ API ومزامنة الموبايل بدل كشف المعرفات الداخلية"],
      [{ t: "company_id", code: true }, { t: "BIGINT", code: true }, "نطاق المستأجر Multi-Tenant — موجود إجباريًا في كل الجداول ذات النطاق، ويُفرض في كل استعلام على الخادم"],
      [{ t: "created_at", code: true }, { t: "TIMESTAMPTZ", code: true }, "وقت الإنشاء DEFAULT now() — لا يُعدَّل أبدًا"],
      [{ t: "updated_at", code: true }, { t: "TIMESTAMPTZ", code: true }, "آخر تعديل — يُحدَّث آليًا بمشغل trigger"],
      [{ t: "created_by", code: true }, { t: "BIGINT NULL", code: true }, "المستخدم المنشئ FK→users(id) — للحذف الناعم وسلامة السجل التاريخي"],
      [{ t: "updated_by", code: true }, { t: "BIGINT NULL", code: true }, "آخر معدل — للجداول الحساسة"],
      [{ t: "deleted_at", code: true }, { t: "TIMESTAMPTZ NULL", code: true }, "الحذف الناعم: NULL يعني حيًا. يُمنع الحذف الفيزيائي للمستندات المعتمدة (Rule 5)"],
    ]
  ),
  h2("1.2 أنواع البيانات المتفق عليها"),
  pBody("نوعية العدد المالي والكمي حاسمة في الأنظمة المحاسبية؛ لذا يُحظر استخدام أنواع الفاصلة العائمة Float/Double في أي مبلغ أو كمية، ويُستخدم NUMERIC عالي الدقة حصرًا. الجدول الآتي يلخص الأنواع المعتمدة ودلالتها عبر كل المجالات.", { keepNext: true }),
  tCaption("جدول 1-2: الأنواع المعتمدة"),
  rtlTable(
    [{ w: 26, header: "الغرض" }, { w: 24, header: "النوع المعتمد" }, { w: 50, header: "ملاحظات" }],
    [
      ["المبالغ المالية", { t: "NUMERIC(18,4)", code: true }, "يكفي الدينار العراقي بأجزاء دقيقة وصولًا إلى التريليونات"],
      ["الكميات", { t: "NUMERIC(18,4)", code: true }, "يدعم الوحدات الوزنية الكسورية مثل كيلوغرام"],
      ["النسب المئوية", { t: "NUMERIC(5,2)", code: true }, "الضرائب والخصومات والعمولات"],
      ["معاملات تحويل الوحدات", { t: "NUMERIC(18,6)", code: true }, "دقة مضاعفة للتحويلات مثل 1/24"],
      ["الرموز والحالات", { t: "VARCHAR(n) + CHECK", code: true }, "لا ENUM-type في PostgreSQL — قيود CHECK أسهل في التوسعة والترحيل"],
      ["الأزمنة", { t: "TIMESTAMPTZ", code: true }, "دائمًا مع منطقة زمنية؛ Asia/Baghdad للتقديم"],
      ["البيانات المرنة", { t: "JSONB", code: true }, "فقط عند الحاجة الفعلية: شروط الموافقة، شرائح العمولة، حمولات المزامنة"],
      ["الإحداثيات", { t: "DECIMAL(10,7)", code: true }, "دقة ~1سم تكفي لمواقع الزيارات GPS"],
    ]
  ),
  h2("1.3 استراتيجية المعرفات والترقيم"),
  pBody("المعرف الداخلي id بصيغة BIGINT IDENTITY للكفاءة، والمُعرف العام uuid للعرض الخارجي. أما أرقام المستندات القابلة للقراءة البشرية (INV-2026-000001) فتولَّد من جدول document_sequences باستهلاك آمن تحت التزامن عبر قفل صفّي SELECT FOR UPDATE داخل معاملة الترحيل نفسها، فلا تتصدع الأرقام ولا تتكرر مهما تزامنت العمليات. لا يُسمح بترقيم متسلسل معتمد على MAX(id) إطلاقًا لأنه مصدر كلاسيكي للتصادم."),
  h2("1.4 تعدد الشركات (Multi-Tenant) ومنع التسرب"),
  pBody("كل جدول ذي نطاق يحمل company_id مع مفتاح مركب في الفهارس الفريدة (company_id, code, deleted_at) مثلًا، ويُفرض الفلترة على الخادم في طبقة Repository الوحيدة، فلا يمر استعلام تجاوز نطاق المستأجر حتى لو حاول الـ API تمرير معرفات شركات أخرى — تطبيقًا مباشرًا للقاعدة Rule 9 وقسمي 90 و49 من الوثيقة الأم. وعند الترقية إلى SaaS تضاف طبقة Row-Level Security على نفس العمود دون إعادة تصميم."),
  h2("1.5 الحذف الناعم والتصحيح بالأثر العكسي"),
  pBody("المستندات المعتمدة (فواتير مرحّلة، تحويلات مستلمة، تسويات مرحّلة، دفتر حركات، دفاتر عملاء) لا تُحذف ولا تُعدَّل فيزيائيًا مهما كان السبب. التصحيح يتم حصرًا بإحدى ثلاث: إلغاء بأثر عكسي CANCELLED مع قيود REVERSAL مقابلة، أو إشعار دائن Credit Note، أو مرتجع Return. هذا يحقق قاعدتي Rule 5 و Rule 6 ويحفظ قابلية التتبع الكامل لأي رقم إلى مستنده."),
  h2("1.6 العمل دون اتصال ومنع الازدواجية"),
  pBody("كل مستند قابل للإنشاء من تطبيق المندوب دون اتصال (فاتورة، طلب، دفعة، زيارة) يحمل عمود client_transaction_id من نوع UUID يولده الجهاز مرة واحدة لكل عملية. فهرس فريد جزئي UNIQUE WHERE NOT NULL يرفض الصف المكرر، فترحَّل العملية مرة واحدة أًيا كان عدد محاولات المزامنة — وهو الضمان الميكانيكي للاختبارين الحرجين 2 و9."),
];

// ───────────────────────── Chapter 2: Domain map ─────────────────────────
const ch2 = [
  h1("2. خريطة النطاقات الوظيفية"),
  pBody("تنقسم القاعدة إلى أحد عشر مجالًا وظيفيًا مترابطة، رُسم لكل منها مخطط علاقات مستقل في فصول هذا المستند، مع الاحتفاظ بخريطة جامعة تبيّن تقسيم المسؤولية. المجالات الأربعة الأولى تمثل البنية التحتية للبيانات (الهيكل التنظيمي، المنتجات، الأطراف، المخزون)، والمجالات من الخامس إلى التاسع تمثل دورات الأعمال (التحويلات، البيع، التحصيل، الشراء، الخزينة)، والأخيران يمثلان مبيعات الحقول وخدمات المنصة الأفقية."),
  image(`${ERD_DIR}/erd_00_overview.png`, 585),
  fCaption("الشكل 2-1: خريطة النطاقات الأحد عشرة وتدفق الأعمال الرئيسي"),
  tCaption("جدول 2-1: توزيع الجداول على المجالات"),
  rtlTable(
    [{ w: 8, header: "#" }, { w: 30, header: "المجال" }, { w: 12, header: "الجداول", center: true }, { w: 50, header: "المسؤولية" }],
    [
      [{ t: "1", center: true }, "النواة والأمان", { t: "10", center: true }, "الشركات والفروع والمستودعات والمستخدمون وRBAC والأجهزة"],
      [{ t: "2", center: true }, "المنتجات والتسعير", { t: "10", center: true }, "التصنيفات والعلامات والوحدات والباركود وقوائم الأسعار بأربع طبقات"],
      [{ t: "3", center: true }, "العملاء والموردون", { t: "5", center: true }, "بطاقات الأطراف والمجموعات والعناوين وجهات الاتصال"],
      [{ t: "4", center: true }, "المخزون", { t: "4", center: true }, "دفتر الحركات اللاتحققي والأرصدة والدفعات والتسلسلات"],
      [{ t: "5", center: true }, "حركات المخزون", { t: "8", center: true }, "التحويلات والتسويات والجرد والتالف"],
      [{ t: "6", center: true }, "المبيعات", { t: "10", center: true }, "عروض الأسعار والطلبات والتسليم والفواتير والإشعارات الدائنة"],
      [{ t: "7", center: true }, "المدفوعات والدفاتر", { t: "5", center: true }, "التحصيل والتوزيع ودفاتر العملاء والموردين اللاتحققية"],
      [{ t: "8", center: true }, "المشتريات", { t: "7", center: true }, "دورة الشراء حتى السداد مع الاستلام الجزئي ومرتجعات الشراء"],
      [{ t: "9", center: true }, "المالية", { t: "6", center: true }, "الصناديق والبنوك والمصروفات بموافقاتها"],
      [{ t: "10", center: true }, "مبيعات الحقول", { t: "8", center: true }, "المندوبون والأهداف والعمولات والزيارات والمسارات"],
      [{ t: "11", center: true }, "خدمات المنصة", { t: "10", center: true }, "الموافقات والإشعارات والتدقيق والمزامنة وB2B والإعدادات"],
    ]
  ),
];

// ───────────────────────── Domain chapters builder ─────────────────────────
function domainChapter(D, chapterNo) {
  const out = [];
  out.push(h1(`${chapterNo}. المجال ${D.no}: ${D.title}`));
  for (const para of D.intro) out.push(pBody(para));
  out.push(h2(`${chapterNo}.0 مخطط علاقات الكيانات`));
  if (D.id === "d6") {
    // sales domain ships two diagrams (A pipeline, B invoicing) — portrait-safe
    out.push(image(`${ERD_DIR}/erd_06a_pipeline.png`, 575));
    out.push(fCaption(`الشكل ${chapterNo}-1أ: مخطط مجال المبيعات (أ) — عروض الأسعار والطلبات والعملاء المحتملون`));
    out.push(image(`${ERD_DIR}/erd_06b_invoicing.png`, 575));
    out.push(fCaption(`الشكل ${chapterNo}-1ب: مخطط مجال المبيعات (ب) — التسليم والفواتير والإشعارات الدائنة`));
  } else {
    out.push(image(`${ERD_DIR}/${D.png}`, 575));
    out.push(fCaption(`الشكل ${chapterNo}-1: مخطط ERD لمجال «${D.title}» (المسميات بأسماء الجداول الفعلية في PostgreSQL)`));
  }
  D.tables.forEach((t, ti) => {
    out.push(h2(`${chapterNo}.${ti + 1} ${t.name} — ${t.title}`));
    out.push(pBody(t.desc));
    out.push(tCaption(`حقول جدول ${t.name}`));
    const rows = t.fields.map((f) => [
      { t: f[0], code: true }, { t: f[1], code: true },
      { t: f[2], code: true, size: 17 }, { t: f[3] },
    ]);
    out.push(rtlTable(
      [{ w: 21, header: "الحقل" }, { w: 20, header: "النوع" }, { w: 27, header: "القيود" }, { w: 32, header: "الوصف" }],
      rows, { zebra: true }
    ));
    if (t.indexes && t.indexes.length) {
      out.push(pStart("الفهارس والقيود الإضافية:", { bold: true, before: 120, after: 40, keepNext: true }));
      for (const ix of t.indexes) {
        out.push(new Paragraph({
          bidirectional: true, alignment: AlignmentType.START, bullet: { level: 0 },
          spacing: { line: 288, after: 40 },
          children: [codeRun(ix, { size: 17 })],
        }));
      }
    }
    if (t.checks) {
      out.push(pStart([
        arRun("قواعد إضافية: ", { size: 19, bold: true, color: P.accentDark }),
        arRun(t.checks, { size: 19 }),
      ], { before: 60, after: 120 }));
    }
  });
  return out;
}

// ───────────────────────── Chapter 12: State machines ─────────────────────────
const chStates = [
  h1("14. آلات حالة المستندات الحرجة"),
  pBody("انتقالات الحالة تُفرض حصرًا على الخادم عبر دوال انتقال Transition Functions تتحقق من الحالة الحالية وصلاحية المستخدم قبل أي تغيير، ولا تسمح بالقفز أو التراجع أو التكرار. الأشكال الآتية توثق الآلات الثلاث الأكثر حرصًا في النظام؛ أما بقية المستندات (الطلبات، المرتجعات، التسويات، الجرد) فتتبع نفس النمط العام: مسودة، اعتماد، ترحيل، إلغاء بأثر عكسي."),
  h2("14.1 آلة حالة الفاتورة"),
  image(`${ERD_DIR}/state_invoice.png`, 585),
  fCaption("الشكل 14-1: حالات الفاتورة التسع وقواعد الانتقال"),
  pBody("الفاتورة المُرحَّلة POSTED تتجمد حقولها المالية نهائيًا؛ ويتحكم مشغل قاعدة بيانات AFTER UPDATE في رفض أي تعديل عليها خارج أعمدة الحالة المالية المشتقة من الدفعات. الإلغاء بعد الترحيل يولّد حركات مخزون معاكسة وقيود دفتر معاكسة داخل معاملة واحدة، فلا تختل الأرصدة أبدًا. حالتا OVERDUE وPAID مشتقتان آليًا: الأولى بمقارنة تاريخ الاستحقاق مع المتبقي، والثانية عند اكتمال paid_amount لقيمة grand_total."),
  h2("14.2 آلة حالة التحويل"),
  image(`${ERD_DIR}/state_transfer.png`, 585),
  fCaption("الشكل 14-2: دورة التحويل من الطلب حتى الاستلام"),
  pBody("التأثير المخزني مرتبط بحالتين فقط: ISSUED يخصم المستودع المصدر بحركة TRANSFER_OUT، وRECEIVED يضيف للمستودع الهدف بحركة TRANSFER_IN. عند تفعيل مستودع العبور يمر التحويل بمرحلتين مستقلتين (مصدر→عبور ثم عبور→هدف) بنفس المستند، وضمانة عدم الاستلام المزدوج هي حرفيًا شرط الحالة في دالة الاستلام: الاستلام مسموح مرة واحدة من IN_TRANSIT فقط."),
  h2("14.3 آلة حالة المرتجع البيعي"),
  image(`${ERD_DIR}/return_sales.png`, 585),
  fCaption("الشكل 14-3: دورة المرتجع وتصنيف حالة البضاعة"),
  pBody("مرحلة الفحص INSPECTED هي محطة القرار: كل بند مرتجع يُصنَّف GOOD فيعود لمستودع البيع، أو DAMAGED فيحال إلى مستودع التالف، أو QUARANTINE فيُحجز بانتظار قرار. الترحيل POSTED يعيد المخزون بحركة SALE_RETURN وينقص ذمة العميل بقيد دائن مرتبط بالفاتورة الأصلية، مع منع إعادة كمية أكبر من المباعة في الفاتورة الأصلية بقيود على بنود المرتجع."),
];

// ───────────────────────── Chapter 13: Critical indexes & rules mapping ─────────────────────────
const chCritical = [
  h1("15. الفهارس والقيود الحرجة العابرة للمجالات"),
  pBody("إلى جانب فهارس المفاتيح الأجنبية القياسية التي تُنشأ تلقائيًا لكل علاقة، تُنشأ الفهارس الآتية لخدمة استعلامات النظام الحرجة ضمن حدود الأداء المستهدفة (بحث POS أقل من 200ms، بحث عام أقل من 300ms).", { keepNext: true }),
  tCaption("جدول 15-1: الفهارس الحرجة وسببها"),
  rtlTable(
    [{ w: 44, header: "الفهرس" }, { w: 56, header: "الغرض" }],
    [
      [{ t: "product_barcodes(barcode) UNIQUE", code: true }, "بحث الباركود في POS — فريد عالميًا لضمان حسم القراءة الفوري"],
      [{ t: "stock_transactions(product_id, warehouse_id, move_date)", code: true }, "كشف حركة صنف واستعلامات الأرصدة التاريخية"],
      [{ t: "stock_transactions(reference_type, reference_id)", code: true }, "تتبع أي مستند إلى حركاته المخزنية (القاعدة الذهبية)"],
      [{ t: "invoices(customer_id, status) + invoices(invoice_date)", code: true }, "قوائم فواتير العميل وتقارير المبيعات اليومية"],
      [{ t: "customer_ledger(customer_id, entry_date)", code: true }, "كشف حساب العميل اللحظي مع balance_after"],
      [{ t: "UNIQUE(client_transaction_id) WHERE NOT NULL", code: true }, "قفل الازدواجية لمزامنة الأوفلاين على الفواتير والطلبات والدفعات والزيارات"],
      [{ t: "UNIQUE(product_id, warehouse_id) على stock_balances", code: true }, "ضمان صف رصيد واحد لكل تركيبة — شرط التحديث الذري"],
      [{ t: "UNIQUE(sales_rep_id, invoice_id) على commissions", code: true }, "منع احتساب عمولة مرتين لنفس الفاتورة"],
      [{ t: "UNIQUE(company_id, doc_type, year) على document_sequences", code: true }, "عدّاد ترقيم واحد لكل نوع وسنة"],
      [{ t: "INDEX(due_date) WHERE status IN ('POSTED','PARTIALLY_PAID','OVERDUE')", code: true }, "فهرس جزئي لتقارير الفواتير المتأخرة فقط"],
    ],
    { zebra: true }
  ),
  h2("15.1 سياسات الصلاحيات على مستوى قاعدة البيانات"),
  pBody("تُطبق سلامة الدفاتر بحرمان مزدوج: على مستوى التطبيق لا توجد شيفرة تعدل الحركات، وعلى مستوى PostgreSQL تُسحب صلاحيات UPDATE وDELETE عن مستخدم التطبيق في جداول: stock_transactions، customer_ledger، supplier_ledger، cashbox_transactions، bank_transactions، audit_logs. هذا يضمن أن حتى ثغرة تطبيقية لا يمكنها مسح آثارها من الدفاتر."),
];

const chRules = [
  h1("16. خريطة قواعد الأعمال العشر إلى التصميم"),
  pBody("تلخص الوثيقة الأم قواعد أعمال عشر غير قابلة للتفاوض. الجدول الآتي يربط كل قاعدة بموضع تنفيذها الميكانيكي في هذا التصميم، لتكون هذه الخريطة جزءًا من معايير قبول التنفيذ.", { keepNext: true }),
  tCaption("جدول 16-1: قواعد الأعمال ومواضع تنفيذها"),
  rtlTable(
    [{ w: 8, header: "القاعدة" }, { w: 42, header: "نصها" }, { w: 50, header: "تنفيذها في التصميم" }],
    [
      [{ t: "1", center: true }, "كل فاتورة مرحّلة مرتبطة بمستودع", { t: "invoices.warehouse_id NOT NULL مع فحص في دالة الترحيل — لا POSTED بلا مستودع", }],
      [{ t: "2", center: true }, "كل بيع مرتبط بمستخدم أو مندوب", "invoices.created_by NOT NULL و sales_rep_id إجباري لبيع المندوبين؛ يُشتق من الهوية لا من الواجهة"],
      [{ t: "3", center: true }, "لا تعديل مباشر لـ stock_balances", "لا يوجد أي مسار كتابة سوى داخل معاملة stock_transactions؛ REVOKE UPDATE على مستوى الأدوار"],
      [{ t: "4", center: true }, "لا تعديل تاريخي للدفاتر", "دفاتر لاتحققية Append-only مع REVOKE UPDATE/DELETE — التصحيح بقيد REVERSAL"],
      [{ t: "5", center: true }, "لا حذف للمستندات المعتمدة", "deleted_at للحذف الناعم فقط + قيود حالة تمنع DELETE على POSTED/RECEIVED/PAID"],
      [{ t: "6", center: true }, "الإلغاء ينشئ أثرًا عكسيًا", "دالة cancel موحدة تولّد قيود REVERSAL وحركات معاكسة داخل معاملة ذرية واحدة"],
      [{ t: "7", center: true }, "الخصم فوق الحد يحتاج موافقة", "محرك approval_rules بشرط JSONB يحوّل الفاتورة آليًا إلى PENDING_APPROVAL قبل السماح بالترحيل"],
      [{ t: "8", center: true }, "كل تعديل مخزون له سبب", "reason NOT NULL في التسويات والتالف؛ وكل حركة دفتر تحمل reference_type + reference_id"],
      [{ t: "9", center: true }, "لا تجاوز لنطاق المستأجر/الشركة", "company_id إجباري + فلترة إلزامية في طبقة Repository + فهارس مركبة تبدأ بـ company_id"],
      [{ t: "10", center: true }, "العمليات المالية ذرية", "BEGIN/COMMIT واحد لكل مستند مالي: فاتورة+بنود+مخزون+دفتر+عمولة، وفشل جزء = ROLLBACK كامل"],
    ],
    { zebra: true }
  ),
  pBody("على وكيل الذكاء الاصطناعي أو الفريق المطور التحقق من كل بند في هذا الجدول عبر اختبارات آلية صريحة قبل إعلان اكتمال أي مرحلة، إذ إن هذه القواعد العشر هي جوهر الفرق بين محرك أعمال حقيقي وواجهات شكلية بلا قلب محاسبي.", { after: 200 }),
];

// ───────────────────────── Assemble ─────────────────────────
const front = [
  ...summary.slice(0, -1),
  // attach page break to last summary paragraph (avoids empty-PageBreak paragraph)
  new Paragraph({
    bidirectional: true, alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: 120 },
    children: [
      arRun("صُممت القاعدة منذ اليوم الأول لتعدد الشركات Multi-Tenant عبر عمود company_id في كل جدول ذي نطاق، ولدعم العمل دون اتصال Offline للمندوبين عبر مفتاح تكرار فريد client_transaction_id يمنع ازدواجية الترحيل، ولقابلية الترقية إلى SaaS. توثّق الوثيقة كذلك آلات الحالة الخاصة بالمستندات الحرجة (الفاتورة، التحويل، المرتجع)، وخريطة صريحة لقواعد الأعمال العشر في الوثيقة الأم إلى مواضع تنفيذها في التصميم، بما يجعلها المرجع الملزم المباشر لوكيل الذكاء الاصطناعي المطور وأي فريق هندسي لاحق."),
      new PageBreak(),
    ],
  }),
  ...tocBlock(false),
];

const domainsOrder = [D1_CORE, D2_PRODUCTS, D3_PARTIES, D4_STOCK, D5_MOVEMENTS,
  D6_SALES, D7_PAYMENTS, D8_PURCHASING, D9_FINANCE, D10_FIELD_SALES, D11_SYSTEM];

let chapter = 3;
const allBody = [];

domainsOrder.forEach((D) => {
  allBody.push(...domainChapter(D, chapter));
  chapter += 1;
});
// states & critical chapters go after all domains
allBody.push(...chStates, ...chCritical, ...chRules);

(async () => {
  const doc = buildDoc({
    coverConfig: {
      title: "تصميم قاعدة البيانات الكامل ERD",
      subtitle: "نظام إدارة المبيعات والمخزون والمندوبين والفواتير والتوزيع — Sales & Distribution Management System",
      englishLabel: "DATABASE DESIGN",
      metaLines: [
        "الوثيقة التنفيذية 1 من 3 — ERD ومواصفات الجداول",
        "المحرك: PostgreSQL 16+ — تعدد شركات Multi-Tenant",
        "83 جدولًا في 11 مجالًا وظيفيًا",
        "الإصدار 1.0 — مرجع ملزم للتنفيذ",
      ],
      footerRight: "Sales & Distribution Management System",
      footerLeft: "2026",
    },
    headerText: "تصميم قاعدة البيانات الكامل — نظام إدارة المبيعات والمخزون والمندوبين",
    frontChildren: front,
    bodySections: [
      { children: allBody },
    ],
  });
  await writeDoc(doc, OUT);
})();
