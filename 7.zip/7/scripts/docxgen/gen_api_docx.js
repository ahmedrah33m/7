// gen_api_docx.js — Full API Specification document (Arabic RTL)
const {
  P, arRun, codeRun, pBody, pStart, h1, h2, h3, bullet,
  codeBlock, rtlTable, tCaption, fCaption, image, tocBlock, buildDoc, writeDoc,
} = require("./ar_lib");
const { Paragraph, PageBreak, AlignmentType } = require("docx");
const { API_GLOBALS } = require("./endpoints_lib");
const { AUTH, ORG, PRODUCTS, PARTIES } = require("./endpoints_core");
const { INVENTORY, SALES, FINANCE_OPS, PURCHASING } = require("./endpoints_sales");
const { FIELD, REPORTS, SYSTEM } = require("./endpoints_ops");

const OUT = "/home/z/my-project/download/02_API_مواصفات_الواجهات.docx";

const GROUPS = [
  { no: 1, title: "المصادقة وإدارة الجلسات", eps: AUTH },
  { no: 2, title: "الهيكل التنظيمي والصلاحيات (RBAC)", eps: ORG },
  { no: 3, title: "المنتجات والتسعير", eps: PRODUCTS },
  { no: 4, title: "العملاء والموردون", eps: PARTIES },
  { no: 5, title: "المخزون والتحويلات والتسويات", eps: INVENTORY },
  { no: 6, title: "دورة المبيعات: العروض والطلبات والفواتير", eps: SALES },
  { no: 7, title: "المدفوعات والمرتجعات والإشعارات الدائنة", eps: FINANCE_OPS },
  { no: 8, title: "المشتريات", eps: PURCHASING },
  { no: 9, title: "مبيعات الحقول: المندوبون والأهداف والعمولات والزيارات", eps: FIELD },
  { no: 10, title: "التقارير ولوحات المؤشرات والبحث العام", eps: REPORTS },
  { no: 11, title: "خدمات النظام: الموافقات والتدقيق والمزامنة وبوابة B2B", eps: SYSTEM },
];

// ───────────────────────── Front matter ─────────────────────────
const summary = [
  h1("الملخص التنفيذي"),
  pBody("توثّق هذه الوثيقة واجهة برمجة التطبيقات الكاملة لنظام إدارة المبيعات والمخزون والمندوبين، بواجهة RESTful مُصنّفة الإصدار تحت البادئة /api/v1 وفق القسم 46 من الوثيقة الأم. تغطي أكثر من مئة وثمانين نقطة نهاية موزعة على إحدى عشرة وحدة وظيفية، وكل نقطة موثقة بمسارها وفعلها HTTP والصلاحية الدقيقة المطلوبة بصيغة module.action، وقواعد التحقق من المدخلات، ومثال طلب واستجابة JSON واقعي، وأكواد الأخطاء الخاصة بها."),
  pBody("المنهج الحاكم لكل نقطة نهاية هو سلسلة فحوص إجبارية على الخادم: المصادقة ثم التخويص ثم النطاق (الشركة ثم الفرع ثم المستودع) ثم صلاحية الكائن — تطبيقًا حرفيًا للقسمين 48 و49 من الوثيقة الأم، فلا تعتمد أي حماية على إخفاء عنصر في الواجهة. معرفات company_id وwarehouse_id الحساسة تُشتق من التوكن ومن جداول النفاذ ولا تُقبل ثقة بعميلها، والعمليات المالية تتطلب فحصًا ذريًا داخليًا يمنع سباقات التزامن والتكرار."),
  pBody("صُممت الاستجابات بمغلف موحد { success, data|message, errors } مع ترقيم صفحات قياسي وأكواد أخطاء ثابتة سهلة الربط البرمجي (STOCK_001، CREDIT_002...)، وخصصت للعمل دون اتصال بوابة مزامنة حتمية المفتاح client_transaction_id، وبوابة B2B معزولة الصلاحيات للتجار. تصلح هذه الوثيقة عقدًا ملزمًا بين الواجهة والخادم ومرجعًا لاختبارات التكامل الآلية."),
];

const ch1 = [
  h1("1. البنية العامة للـ API"),
  pBody("الواجهة RESTful خالصة: الأفعال HTTP تحمل الدلالة القياسية (GET قراءة، POST إنشاء/إجراء، PUT تعديل كامل الدلالة، DELETE حذف ناعم)، والمسارات بصيغة جمع-اسم-مورد منظمة حسب الوحدات. كل الإجراءات غير القياسية (ترحيل، اعتماد، استلام، مزامنة) نقاط POST فرعية صريحة تحت المورد: /{id}/post و/{id}/approve و/{id}/receive — صريحة لا مبهمة."),
  tCaption("جدول 1-1: الأساس والإصدار"),
  rtlTable(
    [{ w: 30, header: "العنصر" }, { w: 70, header: "القيمة" }],
    [
      ["عنوان القاعدة Base URL", { t: API_GLOBALS.baseUrl, code: true }],
      ["الإصدار", { t: "/api/v1 — الترقيم في المسار وليس الترويسات، وأي كسر توافقية يفتح v2", code: true }],
      ["الترميز", { t: "UTF-8 — application/json (الرفع عبر multipart/form-data)", code: true }],
      ["الزمن", { t: "ISO 8601 UTC في الأسلاك؛ Asia/Baghdad في العرض", code: true }],
      ["العملة", { t: "IQD افتراضيًا (ISO 4217)؛ حقل currency صريح في المستندات المالية", code: true }],
    ]
  ),
  h2("1.1 المصادقة والتخويص"),
  pBody(API_GLOBALS.authNote),
  h2("1.2 سلسلة الفحوص الإجبارية لكل طلب"),
  pBody("تنفذ كل نقطة نهاية محمية سلسلة الفحوص بالترتيب الصارم الآتي، وتفشل عند أول رفض بكود صريح. هذه السلسلة هي التنفيذ الميكانيكي للقسم 48 وتمنع فئات كاملة من الثغرات: تصعيد الصلاحيات، تسرب النطاق، التلاعب بالمعرفات.", { keepNext: true }),
  rtlTable(
    [{ w: 10, header: "#" }, { w: 26, header: "الفحص" }, { w: 64, header: "ما يتحقق منه" }],
    [
      [{ t: "1", center: true }, "المصادقة Authentication", "صلاحية التوكن وعدم انتهائه وإلغاء الجلسة"],
      [{ t: "2", center: true }, "التخويص Authorization", "وجود الصلاحية module.action في أدوار المستخدم"],
      [{ t: "3", center: true }, "النطاق Tenant/Company", "company_id مشتق من التوكن — أي معرف جسم يُتجاهل إجباريًا"],
      [{ t: "4", center: true }, "الفرع/المستودع Scope", "المستودعات المطلوبة ضمن user_warehouse_access للمستخدم (SCOPE_001)"],
      [{ t: "5", center: true }, "صلاحية الكائن", "المستند المستهدف يخص المستخدم/نطاقه (مندوب لا يلمس فاتورة غيره)"],
      [{ t: "6", center: true }, "قواعد الأعمال", "الحالة، المخزون، الائتمان، الموافقات، التكرار — ذريًا داخل معاملة"],
    ],
    { zebra: true }
  ),
];

const ch2 = [
  h1("2. الاصطلاحات العامة"),
  h2("2.1 الترويسات القياسية"),
  tCaption("جدول 2-1: الترويسات"),
  rtlTable(
    [{ w: 30, header: "الترويسة" }, { w: 30, header: "القيمة" }, { w: 40, header: "ملاحظات" }],
    API_GLOBALS.commonHeaders.map((r) => [{ t: r[0], code: true }, { t: r[1], code: true }, r[2]]),
    { zebra: true }
  ),
  h2("2.2 مغلف الاستجابة الموحد"),
  pBody("كل الاستجابات — نجاحًا وفشلًا — تتبع نفس المغلف، فلا يفكك العميل الهيكل أبدًا:"),
  codeBlock([
    "// نجاح",
    '{ "success": true, "data": { ... }, "pagination": { "page": 1, "per_page": 20, "total": 137, "total_pages": 7 } }',
    "",
    "// فشل",
    '{ "success": false, "code": "STOCK_001", "message": "الكمية المتاحة غير كافية",',
    '  "errors": { "fields": { "items.0.quantity": "المتاح 3 فقط" } } }',
  ]),
  h2("2.3 الترقيم والفرز والبحث"),
  pBody(API_GLOBALS.paginationNote),
  h2("2.4 حدود المعدل"),
  pBody(API_GLOBALS.rateLimit),
  h2("2.5 مصفوفة أكواد الأخطاء الموحدة"),
  pBody("الأكواد ثابتة عبر كل الوحدات؛ الجدول الآتي هو المرجع الوحيد وتشير إليه مواصفات كل نقطة أدناه بالأكواد الخاصة بها فقط.", { keepNext: true }),
  tCaption("جدول 2-2: أكواد الأخطاء"),
  rtlTable(
    [{ w: 22, header: "الكود" }, { w: 12, header: "HTTP", center: true }, { w: 66, header: "المعنى" }],
    API_GLOBALS.errorCodes.map((r) => [{ t: r[0], code: true }, { t: r[1], center: true, code: true }, r[2]]),
    { zebra: true }
  ),
];

// ───────────────────────── Endpoint index (quick reference) ─────────────────────────
function buildIndex() {
  const rows = [];
  let n = 0;
  for (const g of GROUPS) {
    for (const e of g.eps) {
      n += 1;
      rows.push([
        { t: String(n), center: true },
        { t: e.method, code: true, center: true, color: e.method === "GET" ? "15803D" : (e.method === "DELETE" ? "B91C1C" : P.accentDark), bold: true },
        { t: e.path, code: true, size: 16 },
        { t: e.perm, size: 16 },
      ]);
    }
  }
  return rows;
}

const chIndex = [
  h1("3. الفهرس الشامل لنقاط النهاية"),
  pBody("مرجع سريع بكل نقاط النهاية الموثقة في هذه الوثيقة مرتبة حسب الوحدات؛ التفاصيل الكاملة (التحقق والأمثلة والأخطاء) في فصول الوحدات التالية.", { keepNext: true }),
  tCaption("جدول 3-1: فهرس الـ Endpoints"),
  rtlTable(
    [{ w: 7, header: "#" }, { w: 10, header: "الفعل", center: true }, { w: 51, header: "المسار" }, { w: 32, header: "الصلاحية" }],
    buildIndex(), { zebra: true }
  ),
];

// ───────────────────────── Endpoint renderer ─────────────────────────
function renderEndpoint(e, idx, groupNo) {
  const out = [];
  out.push(h2(`${idx} ${e.title}`));
  const metaRows = [
    [{ t: "المسار", bold: true }, { t: `${e.method} /api/v1${e.path}`, code: true }],
    [{ t: "الصلاحية", bold: true }, { t: e.perm, code: true }],
  ];
  out.push(rtlTable([{ w: 18, header: "العنصر" }, { w: 82, header: "القيمة" }], metaRows));
  out.push(pBody(e.desc, { after: 80 }));
  if (e.validation && e.validation.length) {
    out.push(pStart("قواعد التحقق والقيد:", { bold: true, size: 19, color: P.accentDark, after: 40, keepNext: true }));
    for (const v of e.validation) out.push(bullet(v));
  }
  if (e.req) {
    out.push(pStart("مثال الطلب:", { bold: true, size: 19, after: 40, keepNext: true }));
    out.push(codeBlock(typeof e.req === "string" ? e.req.split("\n") : [e.req]));
  }
  if (e.res) {
    out.push(pStart("مثال الاستجابة:", { bold: true, size: 19, after: 40, keepNext: true }));
    out.push(codeBlock(e.res.split("\n")));
  }
  if (e.errors && e.errors.length) {
    out.push(tCaption("الأخطاء الخاصة بهذه النقطة"));
    out.push(rtlTable(
      [{ w: 22, header: "الكود" }, { w: 14, header: "HTTP", center: true }, { w: 64, header: "الحالة" }],
      e.errors.map((r) => [{ t: r[0], code: true }, { t: r[1], center: true, code: true }, r[2]]),
      { zebra: true }
    ));
  }
  return out;
}

// ───────────────────────── Assemble ─────────────────────────
const front = [
  ...summary.slice(0, -1),
  new Paragraph({
    bidirectional: true, alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: 120 },
    children: [
      arRun("صُممت الاستجابات بمغلف موحد { success, data|message, errors } مع ترقيم صفحات قياسي وأكواد أخطاء ثابتة سهلة الربط البرمجي (STOCK_001، CREDIT_002...)، وخصصت للعمل دون اتصال بوابة مزامنة حتمية المفتاح client_transaction_id، وبوابة B2B معزولة الصلاحيات للتجار. تصلح هذه الوثيقة عقدًا ملزمًا بين الواجهة والخادم ومرجعًا لاختبارات التكامل الآلية، وأي تنفيذ لا يلتزم بسلوك الفحوص هنا يعد انحرافًا عن المواصفة يجب إصلاحه قبل القبول."),
      new PageBreak(),
    ],
  }),
  ...tocBlock(false),
];

const body = [];
body.push(...ch1, ...ch2, ...chIndex);
let gIdx = 4;
for (const g of GROUPS) {
  body.push(h1(`${gIdx}. وحدة: ${g.title}`));
  body.push(pBody(`تغطي هذه الوحدة ${g.eps.length} نقطة نهاية موثقة أدناه بالتفصيل الكامل: المسار والصلاحية، وقواعد التحقق على الخادم، ومثال طلب واستجابة واقعيين، والأكواد الخاصة من مصفوفة الأخطاء.`));
  let eIdx = 1;
  for (const e of g.eps) {
    body.push(...renderEndpoint(e, `${gIdx}.${eIdx}`, g.no));
    eIdx += 1;
  }
  gIdx += 1;
}

(async () => {
  const doc = buildDoc({
    coverConfig: {
      title: "مواصفات واجهات البرمجة API",
      subtitle: "المرجع الكامل لكل نقطة نهاية — مسارات وصلاحيات وتحقق وأمثلة وأكواد أخطاء",
      englishLabel: "API SPECIFICATION",
      metaLines: [
        "الوثيقة التنفيذية 2 من 3 — مواصفات REST API",
        "RESTful + Versioned — /api/v1",
        `${GROUPS.reduce((a, g) => a + g.eps.length, 0)} نقطة نهاية موثقة بالتفصيل`,
        "الإصدار 1.0 — عقد ملزم بين الواجهة والخادم",
      ],
      footerRight: "Sales & Distribution Management System",
      footerLeft: "2026",
    },
    headerText: "مواصفات واجهات البرمجة API — نظام إدارة المبيعات والمخزون والمندوبين",
    frontChildren: front,
    bodySections: [{ children: body }],
  });
  await writeDoc(doc, OUT);
})();
