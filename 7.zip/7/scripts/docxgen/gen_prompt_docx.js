// gen_prompt_docx.js — Master Prompt document (bilingual: EN prompt + AR annotations)
const {
  P, arRun, codeRun, pBody, pStart, h1, h2, h3, bullet,
  codeBlock, rtlTable, tCaption, fCaption, image, tocBlock, buildDoc, writeDoc,
} = require("./ar_lib");
const { Paragraph, TextRun, PageBreak, AlignmentType } = require("docx");

const OUT = "/home/z/my-project/download/03_MASTER_PROMPT_وكيل_الذكاء_الاصطناعي.docx";

// English LTR helpers
function enPara(text, o = {}) {
  return new Paragraph({
    alignment: AlignmentType.LEFT,
    spacing: { line: 300, after: o.after !== undefined ? o.after : 100 },
    children: [new TextRun({ text, font: { ascii: "Calibri", hAnsi: "Calibri", cs: "Calibri" }, size: o.size || 22, color: o.color || P.body, bold: o.bold || false })],
  });
}
function enBullet(text) {
  return new Paragraph({
    alignment: AlignmentType.LEFT, bullet: { level: 0 },
    spacing: { line: 290, after: 40 },
    children: [new TextRun({ text, font: { ascii: "Calibri", hAnsi: "Calibri", cs: "Calibri" }, size: 21, color: P.body })],
  });
}
function enCode(lines) { return codeBlock(lines); }

// ───────────────── Front matter (Arabic) ─────────────────
const summary = [
  h1("الملخص التنفيذي"),
  pBody("هذه هي الوثيقة التنفيذية الثالثة والأخيرة: توجيه رئيسي واحد Master Prompt يُسلَّم لوكيل ذكاء اصطناعي مطور (Claude Code أو Cursor أو GPT Agent) ليبنى به المشروع كاملًا ويفحص كل زر وكل وظيفة ويجري الاختبارات آليًا. كُتب التوجيه بالإنجليزية لأنها أعلى دقة وأقل غموضًا مع وكلاء البرمجة الحاليين، وأُرفقت لكل مرحلة من مراحل التنفيذ ملخص عربي حتى تتابع التقدم وتتحقق من التسليمات بنفسك دون الحاجة لقراءة الشيفرة."),
  pBody("التوجيه ملزم بثلاث مرتكزات لا قابلة للتفاوض: أولًا النظام محرك أعمال قائم على المعاملات لا مجموعة شاشات — كل رصيد يتحرك بمستند موثق داخل معاملة ذرية؛ ثانيًا سلسلة الأمان تُفحص على الخادم في كل نقطة نهاية مهما أخفت الواجهة؛ ثالثًا لا يُعلن الاكتمال إلا بمرور الاختبارات الآلية العشرة الحرجة وسيناريو القبول ذي الخطوات الثمانية عشر على بيئة نظيفة. وعليه فقد حُدد ترتيب التنفيذ في عشر مراحل، لكل منها معايير خروج صارمة لا يجوز تجاوزها قبل تحققها."),
  pBody("طريقة الاستخدام العملية: أعطِ الوكيل هذا الملف DOCX (أو نسخة MASTER_PROMPT.md المرفقة في الحزمة) مع وثيقتي ERD ومواصفات API ووثيقتك الأم، واطلب منه بدء المرحلة 0. وبعد كل مرحلة تسلّم الوكيل تقريرًا بما بُني ونتائج الاختبارات الحقيقية والانحرافات إن وجدت، فتراجعه قبل إذن المرحلة التالية. بذلك تدير بناء نظام مؤسسي كامل بإيقاع محكم قابل للتدقيق."),
];

// ───────────────── Ch1: How to use (AR) ─────────────────
const ch1 = [
  h1("1. كيفية استخدام هذا التوجيه"),
  pBody("القسم الثاني من هذه الوثيقة هو نص التوجيه الإنجليزي نفسه، مصاغًا ليكون عقدًا تنفيذيًا كاملًا: الدور، والتقنيات الثابتة، وقواعد الأعمال غير القابلة للتفاوض، وقائمة الأمان على الخادم، ومتطلبات الواجهة، وخطة المراحل العشر بمعايير خروجها، وبروتوكول فحص كل زر، وحزمة الاختبارات الإلزامية، وسيناريو القبول، ووثيقة اكتمال الميزة، والمخرجات النهائية، وقواعد السلوك."),
  pBody("أما القسمان من الثالث إلى الخامس فملخصات عربية لك: ملخص المراحل العشر بما يُنتجه كل منها، وشرح الاختبارات الحرجة العشرة وما يعنيه فشل كل منها، وسيناريو القبول الثماني عشري خطوة بترتيبه الدقيق. ستستخدم هذه الملخصات للتحقق السريع من صحة ما يسلّمه الوكيل في نهاية كل مرحلة، وهي نفسها قائمة استلامك النهائي للمشروع."),
  h2("1.1 ترتيب التغذية للوكيل"),
  tCaption("جدول 1-1: ملفات السياق وترتيبها"),
  rtlTable(
    [{ w: 10, header: "#" }, { w: 45, header: "الملف" }, { w: 45, header: "دوره" }],
    [
      [{ t: "1", center: true }, { t: "MASTER_PROMPT.md (أو هذا الملف)", code: true }, "التوجيه الحاكم — يُلصق في سياق الوكيل أو يُشار إليه أولًا"],
      [{ t: "2", center: true }, { t: "01_ERD_تصميم_قاعدة_البيانات.docx", code: true }, "مرجع المخطط الحاسم للقاعدة — 83 جدولًا بالقيود والفهارس"],
      [{ t: "3", center: true }, { t: "02_API_مواصفات_الواجهات.docx", code: true }, "عقد الواجهات — كل نقطة نهاية وصلاحيتها وأمثلتها"],
      [{ t: "4", center: true }, "الوثيقة الأم (105 أقسام)", "نية الأعمال — تفصل عند أي تعارض تفسيري"],
    ],
    { zebra: true }
  ),
  h2("1.2 إدارة التسليم بين المراحل"),
  pBody("لا تعط الوكيل إذنًا مفتوحًا لبناء كل شيء دفعة واحدة. القاعدة العملية: مرحلة واحدة لكل جلسة عمل، ثم تقرير يتبع الصيغة المطلوبة في القسم 12 من التوجيه (ما بُني، مخرجات الاختبارات الحقيقية مقصوصة نصًا، الانحرافات عن المواصفة وسببها، الخطوة التالية). إن كان التقرير بلا مخرجات اختبار حقيقية فهو غير مقبول — أعده. عند انتقال المراحل استخدم بيئة نظيفة وأعد تشغيل الاختبارات التراكمية حتى لا تبني نجاحًا على أساس مكسور."),
];

// ───────────────── Ch2: The Master Prompt (English, full) ─────────────────
const ch2 = [
  h1("2. النص التوجيهي الرئيسي — Master Prompt (English)"),
  pBody("ما يلي هو النص الحرفي الذي يُعطى للوكيل. انسخه كما هو من القسم الثاني في النسخة الرقمية MASTER_PROMPT.md المرفقة بالحزمة إن كان وكيلك يفضل Markdown. { break-note: This section is intentionally in English. }", { after: 160 }),

  h2("§1 ROLE & MISSION"),
  enPara("You are a full software engineering team compressed into one agent: Software Architect, Backend Developer, Frontend Developer, Database Engineer, DevOps Engineer, QA Engineer, Security Engineer, and UI/UX Designer."),
  enPara("Mission: build the complete, production-ready Sales & Distribution Management System described in the three context documents — a Transaction-Based Business Engine, not a screen prototype — and prove it works by testing every function and every button automatically. You are not done when the screens exist; you are done when the 18-step acceptance scenario (§9) passes end-to-end and every automated test in §8 is green."),

  h2("§2 TECH STACK (fixed — do not substitute)"),
  enCode([
    "Next.js 16 (App Router) + TypeScript + Tailwind CSS 4 + shadcn/ui",
    "TanStack Query + React Hook Form + Zod (shared client/server schemas)",
    "Next.js Route Handlers as REST API (/api/v1/*) — same repo",
    "Prisma ORM — schema mirrors the ERD document 1:1",
    "PostgreSQL 16+ (bigint identity PK + uuid public id)",
    "Redis 7 + BullMQ (background reports, exports, notifications)",
    "JWT access 15min + rotating refresh 7d, argon2id hashing",
    "Server-side PDF (thermal 80/58mm, A4, A5) · MinIO (S3-compatible) for files",
    "Vitest (unit) + Supertest (integration) + Playwright (E2E)",
    "Docker Compose: nginx / app / postgres / redis / worker",
  ]),
  enPara("Arabic RTL is the primary UI language (English secondary). All money and quantities use Prisma Decimal — never float."),

  h2("§3 NON-NEGOTIABLE BUSINESS RULES"),
  ...[
    "1. Transaction-Based System: no balance (stock, customer, supplier, cashbox) is ever written directly — only via ledger rows (stock_transactions / customer_ledger / supplier_ledger / cashbox_transactions) carrying reference_type + reference_id.",
    "2. Atomic operations: invoice posting = invoice + items + stock txns + customer ledger + commission + allocations in ONE DB transaction; any failure = full ROLLBACK.",
    "3. Immutability after POSTED/RECEIVED: correction only via cancel-with-reverse, credit note, or return — never UPDATE. Revoke UPDATE/DELETE at DB level on all ledger and audit tables.",
    "4. Server-side authorization chain on EVERY endpoint: Authentication → module.action permission → company scope → branch/warehouse scope (user_warehouse_access) → object ownership → business rules. company_id and the rep's warehouse_id are derived from the token, never accepted from the body.",
    "5. Rep scoping: a rep sees only his customers, his documents, and ONLY his REP warehouse (auto-derived, non-selectable).",
    "6. Stock guards: available = on_hand - reserved; sale requires available >= requested unless negative stock is explicitly enabled; row-locked (SELECT ... FOR UPDATE) checks prevent concurrent double-sell of the last unit.",
    "7. Credit guard: current_debt + invoice vs credit_limit → BLOCK (CREDIT_001) or auto-approval (CREDIT_002) per setting.",
    "8. Approval engine: JSONB approval_rules auto-route discount/expense/adjustment/credit-limit events to PENDING_APPROVAL; a requester can never approve their own request.",
    "9. Offline idempotency: client_transaction_id (UUID) with a unique partial index; duplicates return the ORIGINAL result (SYNC_001) and never create a second document.",
    "10. Document numbering via row-locked document_sequences (INV-2026-000001) — no collisions, no MAX(id)+1.",
    "11. Soft delete only (deleted_at) for anything with history; physical DELETE of documents is forbidden.",
    "12. Audit every sensitive action into audit_logs (old/new values, ip, user_agent); nothing may ever delete audit rows.",
    "13. Cost snapshot: invoice_items.cost_price captured at posting (weighted average); profitability never uses today's purchase price.",
  ].map((t) => enBullet(t)),

  h2("§4 SERVER-SIDE SECURITY CHECKLIST"),
  ...[
    "HTTPS behind nginx; secure headers (CSP, HSTS, X-Frame-Options, X-Content-Type-Options).",
    "Rate limiting: 120 req/min per user, 600/min for sync → 429 RATE_001 with Retry-After.",
    "Zod validation on every body/query/param; whitelist fields; strip unknown keys.",
    "Prisma parameterized queries only — zero string-concatenated SQL.",
    "XSS-safe rendering, CSRF protection for cookie flows, SameSite cookies.",
    "File uploads: MIME + extension + size (<=10MB), generated safe filenames, stored outside executable paths.",
    "Account lockout after 5 failed logins (AUTH_004); device management for mobile sessions.",
    "Uniform error envelope { success, code, message, errors } with the fixed error-code matrix from the API spec.",
    "Separate log channels (application / security / auth / sync) with rotation.",
  ].map((t) => enBullet(t)),

  h2("§5 FRONTEND & UX REQUIREMENTS"),
  ...[
    "Arabic RTL first, responsive (desktop/tablet/mobile); Light/Dark/System theme.",
    "Sidebar exactly as SRS §94: المبيعات، المخزون، المندوبون، المشتريات، المالية، التقارير، الإدارة، الإعدادات.",
    "Design tokens: primary orange #EA580C, dark navy #1E293B, light neutral background — no hardcoded scattered colors.",
    "Data tables: search, filter, sort, pagination, column visibility, export, bulk actions, sticky header.",
    "Sensitive actions require confirmation dialogs (Arabic wording per SRS §99).",
    "Every list implements Loading / Empty / Error / Success states; every button gives feedback — a silent button is a bug.",
    "Hide unauthorized actions, but the API never relies on hiding.",
    "POS with configurable shortcuts: F2 search, F4 customer, F8 payment, F9 hold, F10 complete, ESC cancel.",
    "Role-based dashboards: admin (SRS §35) and rep (SRS §36).",
  ].map((t) => enBullet(t)),

  h2("§6 PHASED EXECUTION PLAN (exact order; report after each phase)"),
  enCode([
    "P0 Foundation   : repo, docker-compose, Prisma schema from ERD, migrations, seeders,",
    "                  JWT auth, RBAC middleware, audit service, error envelope, CI",
    "                  exit: login/lockout work; middleware blocks unauthorized; clean migrate",
    "P1 Master Data  : products, categories(tree), brands, units+conversions, barcodes,",
    "                  price lists/items/customer prices, customers(+groups/contacts/addresses), suppliers",
    "                  exit: CRUD+audit for all; barcode search <200ms; price-engine unit tests green",
    "P2 Inventory    : stock_transactions + stock_balances (row-locked), transfers (state machine),",
    "                  adjustments, stocktaking, damages",
    "                  exit: transfer loop updates both warehouses exactly once; double-receive blocked",
    "P3 Sales Core   : POS, quotations, orders (reserve), invoices + posting engine (atomic),",
    "                  customer ledger, payments + allocations + mixed, returns, credit notes",
    "                  exit: atomicity test green; no-stock → full rollback; overpay blocked;",
    "                        posted immutable; cancel reverses exactly",
    "P4 Field Sales  : reps (derived warehouse), targets, commissions (4 rule types), visits (GPS), routes",
    "                  exit: rep-isolation + commission-uniqueness tests green",
    "P5 Purchasing   : POs, receipts (ONLY stock increase), supplier invoices, supplier payments, purchase returns",
    "                  exit: stock rises ONLY on receipt post; partial receipts update PO status",
    "P6 Finance      : cashboxes+transactions, banks, expenses (approval), aging & profitability",
    "                  exit: cash equation reconciles; expense approval route works",
    "P7 Reports      : all §37 reports, admin/rep dashboards, global search, background exports",
    "                  exit: API <500ms, dashboard <2s, search <300ms",
    "P8 Sync & B2B   : sync/push, sync/pull (cursor), conflicts, B2B portal (own prices, orders, statements)",
    "                  exit: duplicate push returns original (SYNC_001); conflict path demoable",
    "P9 Hardening    : OpenAPI, demo seed, deploy scripts tested, full E2E green, docs",
    "                  exit: §8 tests + §9 scenario pass on clean docker compose up",
  ]),

  h2("§7 BUTTON-BY-BUTTON SELF-VERIFICATION PROTOCOL"),
  enPara("After each phase, verify for every screen — via Playwright E2E or API-level integration tests:"),
  ...[
    "Every button has a handler performing its real action — no dead buttons, no TODO, no alert() placeholders.",
    "Every form validates (Zod), submits to the real API, persists real data, and re-displays it after reload.",
    "Every destructive/sensitive action shows a confirmation dialog and is audited.",
    "Every list proves its loading/empty/error/success states (force each state in tests at least once).",
    "Permission-restricted buttons are hidden AND their APIs return 403 when called directly.",
    "No mock data anywhere in final code — mocks live only in test files.",
    "Maintain VERIFICATION.md: screen × control × test-name × result. A phase ends only when all its rows are green.",
  ].map((t) => enBullet(t)),

  h2("§8 REQUIRED AUTOMATED TESTS (minimum suite)"),
  enPara("Unit (Vitest):", { bold: true }),
  enPara("pricing 4-layer priority · discount rules & approval trigger · tax calc (incl/excl) · unit conversion math · credit-limit decision · commission rules (all 4 types incl. tiers) · document-number formatting.", { size: 21 }),
  enPara("Integration (Supertest, real DB):", { bold: true }),
  ...[
    "1. Cannot sell more than available (STOCK_001) — incl. concurrent double-sell of the last unit (only one succeeds).",
    "2. Re-submitting the same client_transaction_id never double-deducts stock (idempotency).",
    "3. Rep cannot see/operate another rep's warehouse (SCOPE_001); cannot override warehouse_id via body.",
    "4. Cancelling a POSTED invoice reverses stock + ledger + payment state exactly (sums reconcile to zero).",
    "5. Return cannot exceed sold quantity; double-return blocked.",
    "6. Payment cannot exceed invoice remaining (unless overpay enabled).",
    "7. Editing a POSTED invoice is impossible (API + DB trigger).",
    "8. Every stock movement has a non-null reference (DB constraint).",
    "9. Offline sync push of a duplicate batch creates zero duplicates.",
    "10. Deleting/deactivating a user never breaks or erases historical records.",
  ].map((t) => enBullet(t)),
  enPara("E2E (Playwright): the full acceptance scenario (§9) through the real UI, plus a POS sale with thermal-print preview."),

  h2("§9 ACCEPTANCE SCENARIO (18 steps — ALL must pass)"),
  enCode([
    " 1. Create a product          10. Invoice appears (POSTED)",
    " 2. Create a supplier         11. Rep warehouse drops to 30",
    " 3. Purchase 100 units (PO)   12. Register payment / open receivable",
    " 4. Receive 100 units         13. Ledger shows the movement",
    " 5. Main warehouse shows 100  14. Commission is calculated",
    " 6. Transfer 40 to the rep    15. Return 2 units",
    " 7. Main warehouse shows 60   16. Stock returns per item condition (GOOD)",
    " 8. Rep warehouse shows 40    17. Customer balance decreases",
    " 9. Sell 10 units             18. Everything appears correctly in reports",
  ]),
  enPara("Any failure at any step = the sales cycle is incomplete → fix and re-run the whole scenario from a clean seeded database."),

  h2("§10 DEFINITION OF DONE (apply to EVERY feature)"),
  enCode([
    "[ ] UI complete (RTL, states, confirmations, permissions-aware)",
    "[ ] API per 02_API spec (path, method, permission, envelope, error codes)",
    "[ ] Database per 01_ERD doc (types, constraints, indexes, soft delete)",
    "[ ] Zod validation server-side AND client-side",
    "[ ] Permission enforced server-side (route + object level)",
    "[ ] Audit log written for sensitive actions",
    "[ ] Atomicity + concurrency handled (transactions, row locks)",
    "[ ] Loading / Empty / Error states implemented",
    "[ ] Unit + integration tests written and green",
    "[ ] E2E for user-visible flows green",
    "[ ] Documented (OpenAPI generated, README updated)",
  ]),

  h2("§11 FINAL DELIVERABLES"),
  enPara("Source code · Prisma migrations + seeders · OpenAPI document · Docker Compose wired to the provided deploy package · .env.example filled · backup/restore integration · full test suite passing · VERIFICATION.md matrix · Arabic user & admin quick manual · technical README."),

  h2("§12 RULES OF CONDUCT & REPORTING FORMAT"),
  ...[
    "1. No fake features. No placeholder data in production paths. No dead buttons.",
    "2. Business logic lives ONLY in the backend — the frontend never duplicates pricing/stock/credit decisions.",
    "3. Never store secrets in code or git — use .env (template provided).",
    "4. Prefer DB constraints over application checks; prefer transactions over hope.",
    "5. On conflicts: ERD doc wins for schema, API spec wins for endpoints, SRS wins for business intent; then ask the owner.",
    "6. Work phase by phase. End-of-phase report format: (a) what was built, (b) REAL test output pasted, (c) deviations from spec + why, (d) next step.",
    "7. A report without real test output is not accepted — return and run the tests.",
    "8. Do not declare completion until §8 tests and §9 scenario pass on a clean environment.",
  ].map((t) => enBullet(t)),
];

// ───────────────── Ch3: Arabic phase summaries ─────────────────
const ch3 = [
  h1("3. ملخص المراحل بالعربية — ماذا يبني الوكيل في كل مرحلة"),
  pBody("الجدول الآتي ترجمتك الإدارية لخطة التنفيذ: استخدمه لمتابعة الوكيل مرحلةً مرحلة، فكل مرحلة لها مخرجات محددة ومعيار خروج لا يجوز التفاف عليه. إن استلمت تقرير مرحلة بلا مخرجات اختبار حقيقية أو بمعيار خروج غير مستوفى، أرجع التسليم مع إشارة لهذا الجدول.", { keepNext: true }),
  tCaption("جدول 3-1: المراحل العشر ومخرجاتها"),
  rtlTable(
    [{ w: 14, header: "المرحلة" }, { w: 44, header: "ما يُبنى" }, { w: 42, header: "معيار الخروج" }],
    [
      [{ t: "0 الأساس", bold: true }, "المستودع، Docker Compose، مخطط Prisma المطابق لوثيقة ERD، الترحيلات، البذور (الأدوار والصلاحيات)، المصادقة JWT، وسيط الصلاحيات، خدمة التدقيق، مغلف الأخطاء", "دخول/قفل يعمل؛ الوسيط يرفض غير المصرح؛ ترحيل نظيف"],
      [{ t: "1 البيانات الرئيسية", bold: true }, "المنتجات وشجرتها والعلامات والوحدات وتحويلاتها والباركود وقوائم الأسعار بثلاث طبقاتها والعملاء بمجموعاتهم وعناوينهم والموردون", "CRUD وتدقيق للجميع؛ بحث باركود < 200ms؛ اختبارات محرك التسعير خضراء"],
      [{ t: "2 المخزون", bold: true }, "دفتر الحركات والأرصدة بأقفال الصفوف، التحويلات بآلة حالتها الكاملة، التسويات، الجرد، التالف", "دورة التحويل تُحدث المستودعين مرة واحدة بالضبط؛ الاستلام المزدوج ممنوع"],
      [{ t: "3 قلب المبيعات", bold: true }, "نقطة البيع، العروض، الطلبات بالحجز، الفواتير ومحرك الترحيل الذري، دفتر العملاء، الدفعات والتوزيعات والمختلط، المرتجعات، الإشعارات الدائنة", "اختبار الذرية أخضر؛ نقص المخزون يعيد الكل؛ فاتورة مرحلة صخرية؛ الإلغاء يعكس بدقة"],
      [{ t: "4 مبيعات الحقول", bold: true }, "المندوبون بمخزنهم المشتق، الأهداف، محرك العمولات بأنماطه الأربعة، الزيارات بGPS، المسارات", "عزل المندوب وفرادة العمولة اختبارين أخضرين"],
      [{ t: "5 المشتريات", bold: true }, "أوامر الشراء، الاستلامات (الوحيدة التي تزيد المخزون)، فواتير الموردين، سدادهم، مرتجعات الشراء", "المخزون لا يزيد إلا بترحيل استلام؛ الاستلام الجزئي يحدّث حالة الأمر"],
      [{ t: "6 المالية", bold: true }, "الصناديق وحركاتها، البنوك، المصروفات بعتبات موافقتها، أعمار الذمم والربحية", "معادلة الصندوق تتوازن؛ مسار موافقة المصروف يعمل"],
      [{ t: "7 التقارير", bold: true }, "كل تقارير القسم 37، لوحتا الإدارة والمندوب، البحث العام، التصدير الخلفي", "أداء: API < 500ms، لوحة < 2s، بحث < 300ms"],
      [{ t: "8 المزامنة وB2B", bold: true }, "sync/push وpull بمؤشر دلتا، معالجة التعارض، بوابة التاجر بأسعاره وطلباته وكشوفه", "الدفع المكرر يعيد الأصل بلا ازدواج؛ مسار التعارض قابل للعرض"],
      [{ t: "9 المتانة والتسليم", bold: true }, "توليد OpenAPI، بيانات عرض، اختبار سكربتات النشر، الحزمة الكاملة للـE2E، التوثيق", "كل اختبارات §8 وسيناريو §9 أخضر على بيئة نظيفة"],
    ],
    { zebra: true }
  ),
];

// ───────────────── Ch4: Critical tests (AR) ─────────────────
const ch4 = [
  h1("4. الاختبارات الحرجة العشرة بالعربية — قائمة استلامك"),
  pBody("هذه هي نفس اختبارات القسم 8 من التوجيه الإنجليزي مترجمة للمراجعة السريعة. كل اختبار يحمي قاعدة أعمال فادحة لو انكسرت لفقد النظام مصداقيته المحاسبية. اطلب من الوكيل عرض مخرجات هذه الاختبارات العشرة نصًا في تقرير المرحلة 9.", { keepNext: true }),
  tCaption("جدول 4-1: الاختبارات الحرجة وما تحميه"),
  rtlTable(
    [{ w: 8, header: "#" }, { w: 46, header: "الاختبار" }, { w: 46, header: "الخلل الذي يمنعه" }],
    [
      [{ t: "1", center: true }, "لا يمكن بيع أكثر من المتاح — وبيع آخر قطعة لمستخدمين متزامنين ينجح لواحد فقط", "أرصدة سالبة خاطئة وخسارة بضاعة بسباق التزامن"],
      [{ t: "2", center: true }, "إعادة إرسال نفس client_transaction_id لا تخصم المخزون مرتين", "ازدواجية فواتير المندوبين عند انقطاع الشبكة"],
      [{ t: "3", center: true }, "المندوب لا يرى ولا يشغل مخزن مندوب آخر ولا يتجاوز warehouse_id من الطلب", "تسريب بيانات وتلاعب API"],
      [{ t: "4", center: true }, "إلغاء فاتورة مرحّلة يعكس المخزون والدفتر والدفع بدقة (توازن كامل للصفر)", "أرصدة متناقضة بعد الإلغاء"],
      [{ t: "5", center: true }, "المرتجع لا يتجاوز المبوع ولا يتكرر", "تضخم مخزون وهمي وتلاعب بالمرتجعات"],
      [{ t: "6", center: true }, "الدفعة لا تتجاوز المتبقي إلا بإعداد الرصيد الدائن", "تحصيل زائد غير موثق وصناديق غير متوازنة"],
      [{ t: "7", center: true }, "الفاتورة المرحّلة غير قابلة للتعديل (API ومشغل قاعدة)", "فساد السجل المحاسبي بالتعديل الصامت"],
      [{ t: "8", center: true }, "كل حركة مخزون لها مرجع غير فارغ (قيد قاعدة)", "أرقام بلا مصدر — نهاية قابلية التتبع"],
      [{ t: "9", center: true }, "دفعة مزامنة مكررة تولد صفر ازدواج", "انهيار الثقة بالمزامنة الأوفلاين"],
      [{ t: "10", center: true }, "حذف/تعطيل مستخدم لا يمس سجلاته التاريخية", "فقدان التتبع التاريخي لمن فعل ماذا"],
    ],
    { zebra: true }
  ),
];

// ───────────────── Ch5: Acceptance scenario (AR) ─────────────────
const ch5 = [
  h1("5. سيناريو القبول الكامل بالعربية (18 خطوة)"),
  pBody("هذا هو اختبار الجاهزية النهائي المنصوص في القسم 97 من الوثيقة الأم، وهو نفسه دورة الأعمال الحقيقية من الشراء حتى التقرير. نفّذه على بيئة نظيفة مزروعة بالبذور، عبر الواجهات الحقيقية لا عبر استدعاءات مباشرة للقاعدة. فشل أي خطوة يعني دورة بيع غير مكتملة.", { keepNext: true }),
  tCaption("جدول 5-1: خطوات السيناريو والنتيجة المتوقعة"),
  rtlTable(
    [{ w: 8, header: "الخطوة" }, { w: 50, header: "الإجراء" }, { w: 42, header: "النتيجة المتوقعة" }],
    [
      [{ t: "1", center: true }, "إنشاء منتج (شامبو طبي 400مل)", "يظهر في الكتالوج بباركوده وسعره"],
      [{ t: "2", center: true }, "إنشاء مورد", "بطاقة مورد برصيد صفري"],
      [{ t: "3", center: true }, "أمر شراء 100 وحدة", "أمر DRAFT→APPROVED بلا أثر مخزني"],
      [{ t: "4", center: true }, "استلام 100 وحدة", "سند POSTED مع حركات PURCHASE_RECEIPT"],
      [{ t: "5", center: true }, "فحص المستودع الرئيسي", "الرصيد 100"],
      [{ t: "6", center: true }, "تحويل 40 للمندوب (دورة كاملة)", "وصول الحالة RECEIVED"],
      [{ t: "7", center: true }, "فحص المستودع الرئيسي", "الرصيد 60"],
      [{ t: "8", center: true }, "فحص مخزن المندوب", "الرصيد 40"],
      [{ t: "9", center: true }, "بيع 10 وحدات من المندوب", "فاتورة POSTED بحركات SALE"],
      [{ t: "10", center: true }, "عرض الفاتورة", "تظهر بأرقامها وقيودها"],
      [{ t: "11", center: true }, "فحص مخزن المندوب", "الرصيد 30"],
      [{ t: "12", center: true }, "تسجيل دفعة أو فتح ذمة", "صندوق/ذمة يتحدثان بمرجع موثق"],
      [{ t: "13", center: true }, "كشف حساب العميل", "يظهر القيد برصيد بعد صحيح"],
      [{ t: "14", center: true }, "مراجعة العمولة", "سطر عمولة واحد لهذه الفاتورة"],
      [{ t: "15", center: true }, "إرجاع وحدتين", "مرتجع REQUESTED→POSTED"],
      [{ t: "16", center: true }, "فحص المخزون بعد المرتجع", "عودة 2 حسب حالة GOOD"],
      [{ t: "17", center: true }, "فحص ذمة العميل", "نقصت بقيمة المرتجع"],
      [{ t: "18", center: true }, "فتح التقارير", "كل الأرقام أعلاه متطابقة في التقارير"],
    ],
    { zebra: true }
  ),
  pBody("عند نجاح الخطوات الثماني عشرة واختبارات القسم الرابع كاملة، يحق للوكيل إعلان الجاهزية للنشر، وعندئذ انتقل إلى حزمة النشر المرفقة (deploy) لتشغيل النظام على سيرفر لينكس وفق الدليل خطوة بخطوة.", { after: 200 }),
];

// ───────────────── Assemble ─────────────────
const front = [
  ...summary.slice(0, -1),
  new Paragraph({
    bidirectional: true, alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: 120 },
    children: [
      arRun("طريقة الاستخدام العملية: أعطِ الوكيل هذا الملف (أو نسخة MASTER_PROMPT.md المرفقة) مع وثيقتي ERD ومواصفات API ووثيقتك الأم، واطلب بدء المرحلة 0. وبعد كل مرحلة استلم تقريرًا يعرض ما بُني ونتائج الاختبارات الحقيقية والانحرافات إن وجدت، فتراجعه قبل منح إذن المرحلة التالية. بذلك تدير بناء نظام مؤسسي كامل بإيقاع محكم قابل للتدقيق، وتضمن أن ما يُسلَّم ليس شاشات جميلة فوق فراغ محاسبي بل محرك أعمال حقيقي مُثبت بالاختبار."),
      new PageBreak(),
    ],
  }),
  ...tocBlock(false),
];

const body = [...ch1, ...ch2, ...ch3, ...ch4, ...ch5];

(async () => {
  const doc = buildDoc({
    coverConfig: {
      title: "التوجيه الرئيسي لوكيل الذكاء الاصطناعي",
      subtitle: "Master Prompt — بناء المشروع وفحص كل زر ووظيفة وإجراء الاختبارات آليًا",
      englishLabel: "AI BUILD AGENT MASTER PROMPT",
      metaLines: [
        "الوثيقة التنفيذية 3 من 3 — التوجيه الحاكم للوكيل",
        "ثنائي اللغة: توجيه إنجليزي دقيق + ملخصات عربية للمراحل",
        "10 مراحل تنفيذ بمعايير خروج · 10 اختبارات حرجة · سيناريو قبول من 18 خطوة",
        "الإصدار 1.0",
      ],
      footerRight: "Sales & Distribution Management System",
      footerLeft: "2026",
    },
    headerText: "التوجيه الرئيسي لوكيل الذكاء الاصطناعي — نظام إدارة المبيعات والمخزون والمندوبين",
    frontChildren: front,
    bodySections: [{ children: body }],
  });
  await writeDoc(doc, OUT);
})();
