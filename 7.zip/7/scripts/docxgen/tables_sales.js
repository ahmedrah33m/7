// tables_sales.js — Domain groups 6,7,10,11: Sales, Payments/Ledgers, Field Sales, System

const D6_SALES = {
  id: "d6", no: "6", png: "erd_06a_pipeline.png",
  title: "المبيعات — من عروض السعر إلى الفواتير والإشعارات الدائنة",
  intro: [
    "خط المبيعات الكامل: عرض سعر يُقبل فيتحول إلى طلب بيع، والطلب يُنفَّذ عبر تسليم جزئي أو كامل، وتُصدر الفاتورة من الطلب أو مباشرة (نقطة بيع). كل تحويل بين مستندات يحفظ السلسلة المرجعية quotation_id → order_id → invoice_id فلا يُقطع التتبع.",
    "الفاتورة هي مركز الجاذبية: ترحيلها POSTED معاملة ذرية واحدة تكتب الفاتورة وبنودها وحركات المخزون السالبة وقيد ذمة العميل في الدفتر ولقطة العمولة، وفشل أي جزء يعيد الكل — لا فاتورة بلا خصم مخزون ناجح. الفاتورة المُرحَّلة صخرية غير قابلة للتعديل، والتصحيح حصرًا بإشعار دائن أو مرتجع أو إلغاء بأثر عكسي.",
    "client_transaction_id فريد يقفل إعادة الإرسال من تطبيق المندوب العامل دون اتصال: أول طلب يرحَّل والمكرر يُرفض بلغة CLOSED — معالجة idempotency حتمية (الاختبارات الحرجة 2 و9)."
  ],
  tables: [
    { name: "quotations", title: "عروض الأسعار", std: true, scoped: true,
      desc: "عرض سعر بفترة صلاحية وحالاته حتى القبول أو الرفض أو التحويل لطلب، بلا أي أثر مخزني أو مالي.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["quotation_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة QT-2026-000001"],
        ["customer_id", "BIGINT", "NOT NULL FK→customers(id)", "العميل"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "مستودع التوفر المرجعي"],
        ["sales_rep_id", "BIGINT", "NULL FK→sales_reps(id)", "المندوب"],
        ["status", "VARCHAR(12)", "NOT NULL DEFAULT 'DRAFT' CHECK (IN ('DRAFT','SENT','ACCEPTED','REJECTED','EXPIRED','CONVERTED'))", "الحالة"],
        ["quotation_date", "DATE", "NOT NULL", "التاريخ"],
        ["valid_until", "DATE", "NULL", "صلاحية العرض"],
        ["subtotal / discount_amount / tax_amount / total", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الإجماليات"],
        ["converted_order_id", "BIGINT", "NULL FK→sales_orders(id)", "الطلب الناتج عند التحويل"],
        ["created_by", "BIGINT", "NOT NULL FK→users(id)", "المُنشئ"]
      ],
      indexes: ["UNIQUE(company_id, quotation_number)", "INDEX(customer_id)"] },

    { name: "quotation_items", title: "بنود عروض الأسعار", std: false,
      desc: "سعر وكمية وسطر خصم لكل بند مقترح، بنسخة من اسم المنتج لحماية العرض من تغيرات البيانات الرئيسية.",
      fields: [
        ["quotation_id", "BIGINT", "NOT NULL FK→quotations(id) ON DELETE CASCADE", "العرض"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة"],
        ["quantity", "NUMERIC(18,4)", "NOT NULL CHECK (quantity > 0)", "الكمية"],
        ["unit_price", "NUMERIC(18,4)", "NOT NULL", "سعر الوحدة عند العرض"],
        ["discount_percent", "NUMERIC(5,2)", "NOT NULL DEFAULT 0", "خصم البند"],
        ["line_total", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "إجمالي السطر"],
        ["notes", "VARCHAR(300)", "NULL", "ملاحظة بند"]
      ],
      indexes: ["INDEX(quotation_id)"] },

    { name: "sales_orders", title: "طلبات البيع", std: true, scoped: true,
      desc: "الطلب يعمل مخزنًا للالتزام: عند CONFIRMED تُحجز الكميات في quantity_reserved، وتُخصم فعليًا عند فاتورة/تسليم. حالاته السبع تشمل الفشل الجزئي PARTIALLY_FULFILLED.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["order_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة SO-2026-000001"],
        ["customer_id", "BIGINT", "NOT NULL FK→customers(id)", "العميل"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "مستودع التنفيذ — يُشتق تلقائيًا للمندوب"],
        ["sales_rep_id", "BIGINT", "NULL FK→sales_reps(id)", "المندوب"],
        ["quotation_id", "BIGINT", "NULL FK→quotations(id)", "العرض المصدر"],
        ["status", "VARCHAR(20)", "NOT NULL DEFAULT 'DRAFT' CHECK (IN ('DRAFT','PENDING','APPROVED','CONFIRMED','PARTIALLY_FULFILLED','FULFILLED','CANCELLED'))", "الحالة"],
        ["order_date", "DATE", "NOT NULL", "التاريخ"],
        ["expected_date", "DATE", "NULL", "موعد التسليم المتوقع"],
        ["subtotal / discount_amount / tax_amount / total", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الإجماليات"],
        ["client_transaction_id", "UUID", "NULL UNIQUE", "قفل تكرار المزامنة"],
        ["created_by", "BIGINT", "NOT NULL FK→users(id)", "المُنشئ"],
        ["notes", "TEXT", "NULL", "ملاحظات"]
      ],
      indexes: ["UNIQUE(company_id, order_number)", "INDEX(customer_id, status)", "INDEX(warehouse_id)", "UNIQUE(client_transaction_id) WHERE client_transaction_id IS NOT NULL"] },

    { name: "sales_order_items", title: "بنود طلبات البيع", std: false,
      desc: "الكمية والمأمور تنفيذها؛ الفرق بينهما يعطي حالة التنفيذ الجزئي ويقود قوائم الطلبات المعلقة للمندوبين.",
      fields: [
        ["order_id", "BIGINT", "NOT NULL FK→sales_orders(id) ON DELETE CASCADE", "الطلب"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة"],
        ["quantity", "NUMERIC(18,4)", "NOT NULL CHECK (quantity > 0)", "الكمية المطلوبة"],
        ["quantity_fulfilled", "NUMERIC(18,4)", "NOT NULL DEFAULT 0 CHECK (quantity_fulfilled <= quantity)", "المنفذ تراكميًا"],
        ["unit_price", "NUMERIC(18,4)", "NOT NULL", "سعر الوحدة المتفق"],
        ["discount_percent", "NUMERIC(5,2)", "NOT NULL DEFAULT 0", "خصم البند"],
        ["tax_rate", "NUMERIC(5,2)", "NOT NULL DEFAULT 0", "ضريبة البند"],
        ["line_total", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "إجمالي السطر"]
      ],
      indexes: ["INDEX(order_id)", "INDEX(product_id)"] },

    { name: "deliveries", title: "مستندات التسليم", std: true, scoped: true,
      desc: "تجهيز ونقل التسليمات من المستودع للعميل مع السائق والمركبة، وتُحدّث quantity_fulfilled في بنود الطلب عند التسليم الناجح.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["delivery_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة DLV-2026-000001"],
        ["order_id", "BIGINT", "NOT NULL FK→sales_orders(id)", "الطلب"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "مستودع الخروج"],
        ["status", "VARCHAR(12)", "NOT NULL DEFAULT 'PENDING' CHECK (IN ('PENDING','PACKED','DISPATCHED','DELIVERED','CANCELLED'))", "الحالة"],
        ["delivery_date", "DATE", "NOT NULL", "التاريخ"],
        ["driver_name", "VARCHAR(120)", "NULL", "السائق"],
        ["vehicle_number", "VARCHAR(40)", "NULL", "المركبة"],
        ["delivered_at", "TIMESTAMPTZ", "NULL", "ختم التسليم"],
        ["created_by", "BIGINT", "NOT NULL FK→users(id)", "المُنشئ"]
      ],
      indexes: ["UNIQUE(company_id, delivery_number)", "INDEX(order_id)"] },

    { name: "delivery_items", title: "بنود التسليم", std: false,
      desc: "تسليم لكل بند طلب مع إمكانية رفض العميل جزئيًا يوثَّق ويعيد الكمية للمتاح فورًا.",
      fields: [
        ["delivery_id", "BIGINT", "NOT NULL FK→deliveries(id) ON DELETE CASCADE", "التسليم"],
        ["order_item_id", "BIGINT", "NOT NULL FK→sales_order_items(id)", "بند الطلب"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج — نسخة للعرض السريع"],
        ["quantity", "NUMERIC(18,4)", "NOT NULL CHECK (quantity > 0)", "الكمية المسلَّمة"],
        ["quantity_rejected", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "المرفوض من العميل"],
        ["note", "VARCHAR(300)", "NULL", "ملاحظة"]
      ],
      indexes: ["INDEX(delivery_id)"] },

    { name: "invoices", title: "الفواتير", std: true, scoped: true,
      desc: "المستند المحوري للنظام بحالاته التسع (DRAFT, PENDING_APPROVAL, APPROVED, POSTED, PARTIALLY_PAID, PAID, OVERDUE, CANCELLED, VOID). paid_amount و remaining_amount محسوبان من الدفعات الموزعة دائمًا.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["invoice_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة INV-2026-000001"],
        ["customer_id", "BIGINT", "NOT NULL FK→customers(id)", "العميل"],
        ["branch_id", "BIGINT", "NULL FK→branches(id)", "الفرع"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "مستودع الصرف — إجباري عند POSTED (Rule 1)"],
        ["sales_rep_id", "BIGINT", "NULL FK→sales_reps(id)", "المندوب — إجباري لبيع المندوبين (Rule 2)"],
        ["order_id", "BIGINT", "NULL FK→sales_orders(id)", "الطلب المصدر"],
        ["invoice_type", "VARCHAR(10)", "NOT NULL DEFAULT 'SALES' CHECK (invoice_type IN ('SALES','POS'))", "النوع: فاتورة عادية أو نقطة بيع"],
        ["status", "VARCHAR(18)", "NOT NULL DEFAULT 'DRAFT' CHECK (IN ('DRAFT','PENDING_APPROVAL','APPROVED','POSTED','PARTIALLY_PAID','PAID','OVERDUE','CANCELLED','VOID'))", "الحالة"],
        ["invoice_date", "DATE", "NOT NULL", "تاريخ الفاتورة"],
        ["due_date", "DATE", "NULL", "الاستحقاق للآجل"],
        ["subtotal", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الإجمالي قبل الخصم والضريبة"],
        ["discount_amount", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الخصم الكلي"],
        ["discount_percent", "NUMERIC(5,2)", "NOT NULL DEFAULT 0", "نسبة الخصم الفعلية — مدخل قاعدة الموافقة"],
        ["tax_amount", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الضريبة"],
        ["grand_total", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الإجمالي النهائي"],
        ["paid_amount", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "المسدد (من التوزيعات)"],
        ["remaining_amount", "NUMERIC(18,4)", "GENERATED ALWAYS AS (grand_total - paid_amount) STORED", "المتبقي — عمود محسوب"],
        ["currency_code", "CHAR(3)", "NOT NULL DEFAULT 'IQD'", "العملة"],
        ["payment_method_hint", "VARCHAR(15)", "NULL", "طريقة السداد المهيمنة للعرض"],
        ["client_transaction_id", "UUID", "NULL UNIQUE", "مانع الترحيل المكرر من Offline Sync"],
        ["created_by", "BIGINT", "NOT NULL FK→users(id)", "المُنشئ"],
        ["posted_at / posted_by", "TIMESTAMPTZ / BIGINT", "NULL", "ختم الترحيل ومالكه"],
        ["notes", "TEXT", "NULL", "ملاحظات"]
      ],
      indexes: ["UNIQUE(company_id, invoice_number)", "INDEX(customer_id, status)", "INDEX(invoice_date)", "INDEX(due_date) WHERE status IN ('POSTED','PARTIALLY_PAID','OVERDUE')", "UNIQUE(client_transaction_id) WHERE client_transaction_id IS NOT NULL"],
      checks: "AFTER UPDATE trigger يمنع تغيير الحقول المالية على POSTED. الإلغاء يمر بـ reverse_invoices فقط." },

    { name: "invoice_items", title: "بنود الفواتير", std: false,
      desc: "نسخة تجميدية من كل بند: السعر والخصم والضريبة والتكلفة المرجعية cost_price لحظة الترحيل — أساس حساب الربح الإجمالي التاريخي الصحيح الذي حذّرت منه الوثيقة (قسم 65).",
      fields: [
        ["invoice_id", "BIGINT", "NOT NULL FK→invoices(id) ON DELETE CASCADE", "الفاتورة"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة"],
        ["quantity", "NUMERIC(18,4)", "NOT NULL CHECK (quantity > 0)", "الكمية"],
        ["unit_price", "NUMERIC(18,4)", "NOT NULL", "سعر الوحدة المفوتر"],
        ["discount_percent", "NUMERIC(5,2)", "NOT NULL DEFAULT 0", "خصم البند %"],
        ["discount_amount", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "خصم البند مبلغًا"],
        ["tax_rate", "NUMERIC(5,2)", "NOT NULL DEFAULT 0", "نسبة الضريبة"],
        ["tax_amount", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "مبلغ الضريبة"],
        ["line_total", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "إجمالي السطر"],
        ["cost_price", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "تكلفة الوحدة المرجعية عند الترحيل"]
      ],
      indexes: ["INDEX(invoice_id)", "INDEX(product_id)"] },

    { name: "credit_notes", title: "الإشعارات الدائنة", std: true, scoped: true,
      desc: "أداة التصحيح المالي لفاتورة مُرحَّلة: خصم تسعيري، تعويض، أو سلة مرتجع — تنقص ذمة العميل عبر قيد دائن في الدفتر وقد تعيد مخزونًا حسب نوعها.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["note_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة CRN-2026-000001"],
        ["customer_id", "BIGINT", "NOT NULL FK→customers(id)", "العميل"],
        ["invoice_id", "BIGINT", "NULL FK→invoices(id)", "الفاتورة المرتبطة"],
        ["reason_type", "VARCHAR(20)", "NOT NULL CHECK (IN ('PRICE_ADJUSTMENT','GOODWILL','RETURN_CANCELLED','OTHER'))", "نوع السبب"],
        ["amount", "NUMERIC(18,4)", "NOT NULL CHECK (amount > 0)", "المبلغ"],
        ["affects_stock", "BOOLEAN", "NOT NULL DEFAULT FALSE", "هل تعيد مخزونًا (مرتبطة بمرتجع)"],
        ["status", "VARCHAR(12)", "NOT NULL DEFAULT 'DRAFT' CHECK (IN ('DRAFT','APPROVED','POSTED','CANCELLED'))", "الحالة"],
        ["created_by / approved_by", "BIGINT", "FK→users(id)", "المنشئ والمعتمد"],
        ["reason", "TEXT", "NULL", "شرح تفصيلي"]
      ],
      indexes: ["UNIQUE(company_id, note_number)", "INDEX(customer_id)"] },

    { name: "sales_leads", title: "العملاء المحتملون", std: true, scoped: true,
      desc: "قمع المبيعات الأولي: عميل محتمل يديره المندوب حتى يتحول لعميل فعلي عبر زر تحويل ينسخ البيانات ويربط العلاقة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["name", "VARCHAR(200)", "NOT NULL", "الاسم"],
        ["phone", "VARCHAR(30)", "NOT NULL", "الهاتف"],
        ["source", "VARCHAR(40)", "NULL", "مصدر العميل المحتمل"],
        ["status", "VARCHAR(12)", "NOT NULL DEFAULT 'NEW' CHECK (IN ('NEW','CONTACTED','QUALIFIED','CONVERTED','LOST'))", "الحالة"],
        ["assigned_rep_id", "BIGINT", "NULL FK→sales_reps(id)", "المندوب المسؤول"],
        ["converted_customer_id", "BIGINT", "NULL FK→customers(id)", "العميل الناتج"],
        ["notes", "TEXT", "NULL", "ملاحظات"]
      ],
      indexes: ["INDEX(assigned_rep_id, status)"] }
  ]
};

const D7_PAYMENTS = {
  id: "d7", no: "9", png: "erd_07_payments.png",
  title: "المدفوعات والدفاتر — التحصيل، التوزيع وكشوف الحساب",
  intro: [
    "الدفعات نموذج واحد ثنائي الاتجاه: دفعة واردة IN من عميل أو خارجة OUT لمورد، تهبط على صندوق أو حساب بنكي وتُكتب في حركاته فورًا. الدفع المختلط MIXED يتفكك في payment_method_lines إلى أسطر بنقد وبطاقة وتحويل وائتمان معًا.",
    "التوزيع Allocations يفصل تجميع النقود عن تغطية الالتزامات: دفعة واحدة قد تغطي فاتورتين جزئيًا وكليًا، وتبقى الفواتير محدثة paid_amount آليًا عبر المشغلات، فيتحقق الاختبار الحرج 6 (لا دفع فوق المطلوب إلا بإعداد يسمح بالرصيد الدائن).",
    "دفاتر العملاء والموردين لاتحققية بقيود مدين/دائن وbalance_after متسلسل، والرصيد الحالي في بطاقة العميل مطابق دائمًا لآخر balance_after — وأي استبدال يكشفه تقرير مطابقة السلامة اليومي."
  ],
  tables: [
    { name: "payments", title: "الدفعات (واردة/خارجة)", std: true, scoped: true,
      desc: "سند القبض/الصرف الموحد مع مانع التكرار client_transaction_id لتحصيل المندوب دون اتصال.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["payment_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة PAY-2026-000001"],
        ["direction", "VARCHAR(3)", "NOT NULL CHECK (direction IN ('IN','OUT'))", "واردة من عميل أو خارجة لمورد"],
        ["customer_id", "BIGINT", "NULL FK→customers(id)", "العميل (إجباري مع IN)"],
        ["supplier_id", "BIGINT", "NULL FK→suppliers(id)", "المورد (إجباري مع OUT)"],
        ["amount", "NUMERIC(18,4)", "NOT NULL CHECK (amount > 0)", "المبلغ الكلي"],
        ["payment_method", "VARCHAR(15)", "NOT NULL CHECK (IN ('CASH','BANK_TRANSFER','CARD','ONLINE','CREDIT','MIXED'))", "الطريقة"],
        ["cashbox_id", "BIGINT", "NULL FK→cashboxes(id)", "الصندوق للنقدية"],
        ["bank_account_id", "BIGINT", "NULL FK→bank_accounts(id)", "الحساب للتحويل/البطاقة"],
        ["reference", "VARCHAR(120)", "NULL", "مرجع خارجي (رقم حوالة...)"],
        ["payment_date", "DATE", "NOT NULL", "التاريخ"],
        ["status", "VARCHAR(10)", "NOT NULL DEFAULT 'CONFIRMED' CHECK (status IN ('DRAFT','CONFIRMED','CANCELLED'))", "الحالة"],
        ["client_transaction_id", "UUID", "NULL UNIQUE", "قفل تكرار المزامنة"],
        ["created_by", "BIGINT", "NOT NULL FK→users(id)", "المُنشئ"],
        ["notes", "TEXT", "NULL", "ملاحظات"]
      ],
      indexes: ["UNIQUE(company_id, payment_number)", "INDEX(customer_id, payment_date)", "UNIQUE(client_transaction_id) WHERE client_transaction_id IS NOT NULL"],
      checks: "CHECK ( (direction='IN' AND customer_id IS NOT NULL AND supplier_id IS NULL) OR (direction='OUT' AND supplier_id IS NOT NULL AND customer_id IS NULL) )" },

    { name: "payment_method_lines", title: "أسطر طرق الدفع (للمختلط)", std: false,
      desc: "تفكيك الدفعة المختلطة: 300,000 نقد + 200,000 بطاقة + 500,000 آجل، بحيث تهبط كل وسيلة على جهتها الصحيحة صندوقًا أو بنكًا.",
      fields: [
        ["payment_id", "BIGINT", "NOT NULL FK→payments(id) ON DELETE CASCADE", "الدفعة"],
        ["method", "VARCHAR(15)", "NOT NULL CHECK (IN ('CASH','BANK_TRANSFER','CARD','ONLINE','CREDIT'))", "الوسيلة"],
        ["amount", "NUMERIC(18,4)", "NOT NULL CHECK (amount > 0)", "مبلغ الوسيلة"],
        ["cashbox_id", "BIGINT", "NULL FK→cashboxes(id)", "الصندوق إن نقدية"],
        ["bank_account_id", "BIGINT", "NULL FK→bank_accounts(id)", "الحساب إن بنكية"],
        ["reference", "VARCHAR(120)", "NULL", "مرجع الوسيلة"]
      ],
      indexes: ["INDEX(payment_id)"],
      checks: "مجموع الأسطر = payments.amount يفحصه التطبيق قبل التأكيد. أسطر CREDIT لا تهبط على خزينة وتتجه للذمة." },

    { name: "payment_allocations", title: "توزيعات الدفعات", std: false,
      desc: "ربط كل دفعة بالفواتير المغطاة ومبالغها؛ المشغلات تحدث paid_amount وحالة الفاتورة (PARTIALLY_PAID/PAID) وقيد الدائن في الدفتر داخل نفس المعاملة.",
      fields: [
        ["payment_id", "BIGINT", "NOT NULL FK→payments(id) ON DELETE CASCADE", "الدفعة"],
        ["target_type", "VARCHAR(12)", "NOT NULL CHECK (target_type IN ('CUSTOMER_INVOICE','SUPPLIER_INVOICE'))", "نوع المستند الموزع عليه"],
        ["target_id", "BIGINT", "NOT NULL", "معرف الفاتورة"],
        ["amount", "NUMERIC(18,4)", "NOT NULL CHECK (amount > 0)", "المبلغ الموزع"],
        ["created_by", "BIGINT", "NULL FK→users(id)", "الموزِّع"]
      ],
      indexes: ["INDEX(payment_id)", "INDEX(target_type, target_id)"] },

    { name: "customer_ledger", title: "دفتر حسابات العملاء (لاتحققي)", std: true,
      desc: "سجل الحياة المالية للعميل: فاتورة مدين، دفعة/مرتجع/إشعار دائن، تسوية، ورصيد افتتاحي. balance_after يجعل أي كشف حساب لحظيًا دون حساب تراكمي مكلف.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["customer_id", "BIGINT", "NOT NULL FK→customers(id)", "العميل"],
        ["entry_type", "VARCHAR(12)", "NOT NULL CHECK (IN ('OPENING','INVOICE','PAYMENT','RETURN','CREDIT_NOTE','ADJUSTMENT','REVERSAL'))", "نوع القيد"],
        ["reference_type", "VARCHAR(30)", "NOT NULL", "المستند المصدر"],
        ["reference_id", "BIGINT", "NOT NULL", "معرف المستند"],
        ["debit", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "المدين — يزيد الذمة"],
        ["credit", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الدائن — ينقصها"],
        ["balance_after", "NUMERIC(18,4)", "NOT NULL", "الرصيد بعد القيد"],
        ["entry_date", "TIMESTAMPTZ", "NOT NULL DEFAULT now()", "وقت القيد"],
        ["created_by", "BIGINT", "NULL FK→users(id)", "المنفذ"]
      ],
      indexes: ["INDEX(customer_id, entry_date)", "INDEX(reference_type, reference_id)"],
      checks: "REVOKE UPDATE/DELETE. قيد واحد على الأقل من debit/credit أكبر من صفر." },

    { name: "supplier_ledger", title: "دفتر حسابات الموردين (لاتحققي)", std: true,
      desc: "مرآة دفتر العملاء للموردين: فاتورة مورد دائن له، دفعة خارجة مدينة عليه، ومرتجع شراء ينقص الالتزام.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["supplier_id", "BIGINT", "NOT NULL FK→suppliers(id)", "المورد"],
        ["entry_type", "VARCHAR(12)", "NOT NULL CHECK (IN ('OPENING','SUPPLIER_INVOICE','PAYMENT','PURCHASE_RETURN','ADJUSTMENT','REVERSAL'))", "نوع القيد"],
        ["reference_type", "VARCHAR(30)", "NOT NULL", "المستند"],
        ["reference_id", "BIGINT", "NOT NULL", "المعرف"],
        ["debit", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "مدين"],
        ["credit", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "دائن"],
        ["balance_after", "NUMERIC(18,4)", "NOT NULL", "الرصيد بعده"],
        ["entry_date", "TIMESTAMPTZ", "NOT NULL DEFAULT now()", "الوقت"],
        ["created_by", "BIGINT", "NULL FK→users(id)", "المنفذ"]
      ],
      indexes: ["INDEX(supplier_id, entry_date)"] }
  ]
};

const D10_FIELD_SALES = {
  id: "d10", no: "10", png: "erd_10_field_sales.png",
  title: "مبيعات الحقول — المندوبون، الأهداف، العمولات والزيارات",
  intro: [
    "هوية المندوب sales_reps تربط حساب المستخدم بمخزنه المتنقل الإجباري وفريقه، وهي المفتاح الذي يشتبه به الخادم عند كل عملية مندوب: مستودع البيع يُشتق من الهوية لا من الواجهة، وقائمة عملائه تتقصر على المُسند إليه.",
    "الأهداف والعمولات محرك تحفيز متكامل: هدف شهري بالقيمة أو الكمية أو عدد الطلبات، وقواعد عمولة بأربعة أنماط (نسبة من المبيعات، من الصافي، حسب المنتج، شرائح تحقيق الهدف بصيغة JSONB). مانع التكرار UNIQUE(sales_rep_id, invoice_id) يمنع عمولة مضاعفة لنفس الفاتورة — كما تشترط الوثيقة صراحة.",
    "الزيارات مع GPS اختياري تفعيله: التقاط الإحداثيات والدقة لحظتي البدء والانتهاء، مع أعلام ما أنتجت الزيارة (طلب، تحصيل)، لتغذية تقارير الانتظام وتغطية المسارات."
  ],
  tables: [
    { name: "sales_teams", title: "فرق المبيعات", std: true, scoped: true,
      desc: "تجميع المندوبين تحت مشرف، يُستخدم في الصلاحيات الهرمية (مشرف يرى فريقه) وتقارير الأداء الجماعية.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["branch_id", "BIGINT", "NOT NULL FK→branches(id)", "الفرع"],
        ["name", "VARCHAR(120)", "NOT NULL", "اسم الفريق"],
        ["manager_id", "BIGINT", "NULL FK→users(id)", "مشرف الفريق"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["INDEX(company_id, branch_id)"] },

    { name: "sales_reps", title: "المندوبون", std: true, scoped: true,
      desc: "هوية المندوب: مستخدم واحد لكل مندوب (فريد)، مخزنه المتنقل إجباري، وفريقه ورمزه الوظيفي. تعطيل المندوب يعطل صلاحيات البيع دون مساس بسجلاته التاريخية.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["user_id", "BIGINT", "NOT NULL UNIQUE FK→users(id)", "حساب الدخول — واحد لكل مندوب"],
        ["employee_code", "VARCHAR(40)", "NULL", "الرمز الوظيفي"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "المخزن المتنقل المُسند — أساس اشتقاق مستودع البيع"],
        ["team_id", "BIGINT", "NULL FK→sales_teams(id)", "الفريق"],
        ["phone", "VARCHAR(30)", "NULL", "هاتف العمل"],
        ["default_commission_rule_id", "BIGINT", "NULL FK→commission_rules(id)", "قاعدة العمولة الافتراضية"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["UNIQUE(user_id)", "UNIQUE(company_id, warehouse_id)", "INDEX(team_id)"] },

    { name: "sales_targets", title: "أهداف المبيعات", std: true, scoped: true,
      desc: "هدف دوري لكل مندوب بقيمة/كمية/عدد طلبات؛ نسبة الإنجاز تُحسب آليًا من الفواتير المُرحَّلة في نطاق الفترة وتغذي شرائح العمولة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["sales_rep_id", "BIGINT", "NOT NULL FK→sales_reps(id)", "المندوب"],
        ["period_type", "VARCHAR(10)", "NOT NULL CHECK (IN ('DAILY','WEEKLY','MONTHLY','QUARTERLY','YEARLY'))", "نوع الدورة"],
        ["period_start", "DATE", "NOT NULL", "بداية الفترة"],
        ["period_end", "DATE", "NOT NULL", "نهايتها"],
        ["target_amount", "NUMERIC(18,4)", "NULL CHECK (target_amount > 0 OR target_quantity > 0 OR target_orders > 0)", "الهدف القيمي مثل 20,000,000 IQD"],
        ["target_quantity", "NUMERIC(18,4)", "NULL", "الهدف الكمي"],
        ["target_orders", "INTEGER", "NULL", "عدد الطلبات المستهدف"],
        ["achieved_amount", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "المحقق (مُحدَّث آليًا)"],
        ["status", "VARCHAR(8)", "NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','CLOSED'))", "الحالة"]
      ],
      indexes: ["UNIQUE(sales_rep_id, period_type, period_start)", "INDEX(period_start, period_end)"] },

    { name: "commission_rules", title: "قواعد العمولة", std: true, scoped: true,
      desc: "الأنماط الأربعة من الوثيقة: نسبة من المبيعات، نسبة من الصافي بعد المرتجعات، نسب حسب المنتج، وشرائح إنجاز الهدف. الفترة وسقف فريد لكل قاعدة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["name", "VARCHAR(120)", "NOT NULL", "اسم القاعدة"],
        ["rule_type", "VARCHAR(20)", "NOT NULL CHECK (IN ('PERCENT_OF_SALES','PERCENT_OF_NET','PER_PRODUCT','TARGET_TIERED'))", "النمط"],
        ["percent", "NUMERIC(5,2)", "NULL", "النسبة للأنماط النسبية"],
        ["product_id", "BIGINT", "NULL FK→products(id)", "المنتج لقواعد PER_PRODUCT"],
        ["tiers", "JSONB", "NULL", "شرائح الهدف مثل [{min:80,max:99,rate:3},{min:100,rate:5}]"],
        ["net_of_returns", "BOOLEAN", "NOT NULL DEFAULT FALSE", "احتساب على الصافي بعد المرتجعات"],
        ["valid_from / valid_to", "DATE", "NULL", "فترة سريان القاعدة"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["INDEX(company_id, is_active)"] },

    { name: "commissions", title: "سطور العمولات المحتسبة", std: true,
      desc: "لقطة العمولة المحتسبة لكل فاتورة مؤهلة: القاعدة المطبقة والنسبة والمبلغ، بحالة تتحرك من محتسب إلى معتمد إلى مدفوع — ولا تُعاد الحسبة أبدًا لنفس الفاتورة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["sales_rep_id", "BIGINT", "NOT NULL FK→sales_reps(id)", "المندوب المستحق"],
        ["rule_id", "BIGINT", "NULL FK→commission_rules(id)", "القاعدة المطبقة"],
        ["invoice_id", "BIGINT", "NULL FK→invoices(id)", "الفاتورة المرجعية"],
        ["sales_date", "DATE", "NOT NULL", "تاريخ البيع"],
        ["sales_amount", "NUMERIC(18,4)", "NOT NULL", "أساس الاحتساب"],
        ["commission_rate", "NUMERIC(5,2)", "NOT NULL", "النسبة المطبقة"],
        ["commission_amount", "NUMERIC(18,4)", "NOT NULL CHECK (commission_amount >= 0)", "قيمة العمولة"],
        ["status", "VARCHAR(10)", "NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','PAID','CANCELLED'))", "الحالة"]
      ],
      indexes: ["UNIQUE(sales_rep_id, invoice_id)", "INDEX(status, sales_date)"] },

    { name: "visits", title: "زيارات المندوبين", std: true, scoped: true,
      desc: "دورة الزيارة بحالاتها الخمس مع GPS عند البدء والانتهاء، وأعلام النتائج (طلب نُشئ، تحصيل جُمع) وربطها اختياريًا بالمسار والخطة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["customer_id", "BIGINT", "NOT NULL FK→customers(id)", "العميل المزور"],
        ["sales_rep_id", "BIGINT", "NOT NULL FK→sales_reps(id)", "المندوب"],
        ["route_id", "BIGINT", "NULL FK→routes(id)", "المسار"],
        ["planned_date", "DATE", "NULL", "التاريخ المخطط"],
        ["status", "VARCHAR(10)", "NOT NULL DEFAULT 'PLANNED' CHECK (IN ('PLANNED','STARTED','COMPLETED','MISSED','CANCELLED'))", "الحالة"],
        ["start_time / end_time", "TIMESTAMPTZ", "NULL", "أختام البدء والانتهاء"],
        ["start_latitude / start_longitude", "DECIMAL(10,7)", "NULL", "موقع البدء"],
        ["end_latitude / end_longitude", "DECIMAL(10,7)", "NULL", "موقع الانتهاء"],
        ["gps_accuracy_m", "NUMERIC(8,2)", "NULL", "دقة الموقع بالمتر"],
        ["order_created", "BOOLEAN", "NOT NULL DEFAULT FALSE", "أنتجت طلبًا"],
        ["payment_collected", "BOOLEAN", "NOT NULL DEFAULT FALSE", "جُمع فيها تحصيل"],
        ["client_transaction_id", "UUID", "NULL UNIQUE", "قفل تكرار المزامنة"],
        ["notes", "TEXT", "NULL", "ملاحظات الزيارة"]
      ],
      indexes: ["INDEX(sales_rep_id, planned_date)", "INDEX(customer_id, status)"] },

    { name: "routes", title: "مسارات المندوبين", std: true, scoped: true,
      desc: "مسار أسبوعي أو حسب اليوم، يُسند لمندوب ويجمع عملاءه بترتيب زيارة — أساس خطة اليوم في تطبيق المندوب.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["name", "VARCHAR(120)", "NOT NULL", "اسم المسار"],
        ["sales_rep_id", "BIGINT", "NULL FK→sales_reps(id)", "المندوب المسند"],
        ["day_of_week", "SMALLINT", "NULL CHECK (day_of_week BETWEEN 0 AND 6)", "يوم الأسبوع 0=الأحد"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["INDEX(sales_rep_id, day_of_week)"] },

    { name: "route_customers", title: "عملاء المسار", std: false,
      desc: "الربط بترتيب صريح sequence_no يحدد تسلسل الزيارة كما تظهر في تطبيق المندوب.",
      fields: [
        ["route_id", "BIGINT", "NOT NULL FK→routes(id) ON DELETE CASCADE", "المسار"],
        ["customer_id", "BIGINT", "NOT NULL FK→customers(id)", "العميل"],
        ["sequence_no", "SMALLINT", "NOT NULL DEFAULT 1", "ترتيب الزيارة"]
      ],
      indexes: ["UNIQUE(route_id, customer_id)", "INDEX(route_id, sequence_no)"] }
  ]
};

const D11_SYSTEM = {
  id: "d11", no: "11", png: "erd_11_system.png",
  title: "خدمات المنصة — الموافقات، الإشعارات، التدقيق، المزامنة وB2B",
  intro: [
    "خدمات أفقية تخدم كل الوحدات: محرك موافقات عام بقواعد شرطية JSONB يلتقط الخصم الكبير والمصروف الفوقي وتسوية المخزون وتجاوز الائتمان؛ وإشعارات متعددة القنوات داخل النظام وفوريًا وبريدًا؛ وسجل تدقيق لاتحققي يسجل من فعل ماذا ومتى ومن أي IP بالقيم قبل وبعد.",
    "المزامنة sync_operations هي بوابة العمل دون اتصال: كل عملية مندوب أوفلاين تصل بمفتاح client_transaction_id فريد؛ المكرر يُتجاهل (idempotent)، والمتصادم (تغير المخزون مثلاً) يعود CONFLICT ليقرر النظام إعادة المحاولة أو التحويل لموافقة — ناظمًا الاختبار الحرج 9.",
    "ترقيم المستندات document_sequences يضمن INV-2026-000001 دون تصادم تحت التزامن عبر قفل صفّي للسطر، والاستيراد import_jobs يمر بدورة تحقق/معاينة/تأكيد لا تلمس البيانات قبل الموافقة النهائية."
  ],
  tables: [
    { name: "approvals", title: "طلبات الموافقة", std: true, scoped: true,
      desc: "حاوية الطلب الموحد لكل أنواع الموافقات مع payload كامل لحظة الطلب، وقرار المعتمد وسببه، ويُربط بالمستند عبر entity_type + entity_id.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["request_type", "VARCHAR(20)", "NOT NULL CHECK (IN ('INVOICE_DISCOUNT','EXPENSE','STOCK_ADJUSTMENT','CREDIT_LIMIT'))", "النوع الأربعة من الوثيقة"],
        ["entity_type", "VARCHAR(30)", "NOT NULL", "المستند: INVOICE/EXPENSE/ADJUSTMENT..."],
        ["entity_id", "BIGINT", "NOT NULL", "معرفه"],
        ["requested_by", "BIGINT", "NOT NULL FK→users(id)", "مقدم الطلب"],
        ["status", "VARCHAR(10)", "NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED','CANCELLED'))", "الحالة"],
        ["approver_id", "BIGINT", "NULL FK→users(id)", "المعتمد الفعلي"],
        ["decided_at", "TIMESTAMPTZ", "NULL", "وقت القرار"],
        ["rejection_reason", "TEXT", "NULL", "سبب الرفض"],
        ["payload", "JSONB", "NOT NULL DEFAULT '{}'", "لقطة السياق: نسبة الخصم، المبلغ، الحد..."]
      ],
      indexes: ["INDEX(company_id, status)", "INDEX(entity_type, entity_id)"] },

    { name: "approval_rules", title: "قواعد الموافقة", std: true, scoped: true,
      desc: "شروط تفعيل الموافقة بصيغة JSONB قابلة للتهيئة بلا كود: تجاوز نسبة خصم، مبلغ مصروف، أي تسوية مخزون، تجاوز حد ائتمان — مع الدور المخوّل بالاعتماد.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["rule_type", "VARCHAR(20)", "NOT NULL CHECK (IN ('INVOICE_DISCOUNT','EXPENSE','STOCK_ADJUSTMENT','CREDIT_LIMIT'))", "النوع"],
        ["condition", "JSONB", "NOT NULL", "مثل {\"discount_percent_gt\":10} أو {\"amount_gt\":500000}"],
        ["approver_role_id", "BIGINT", "NOT NULL FK→roles(id)", "الدور المخول بالاعتماد"],
        ["priority", "SMALLINT", "NOT NULL DEFAULT 100", "ترتيب الفحص"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["INDEX(company_id, rule_type, is_active)"] },

    { name: "notifications", title: "الإشعارات", std: true, scoped: true,
      desc: "الإشعار للأحداث التسعة المنصوصة (فاتورة جديدة، دفعة مستلمة، موافقة مطلوبة...) بثلاث قنوات، مع حالة القراءة وتوجيه للمستخدم أو الدور.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["user_id", "BIGINT", "NULL FK→users(id)", "المستخدم المستهدف (أو NULL مع role_id)"],
        ["role_id", "BIGINT", "NULL FK→roles(id)", "بث لأدوار كاملة مثل الموافقات"],
        ["channel", "VARCHAR(8)", "NOT NULL CHECK (channel IN ('IN_APP','PUSH','EMAIL'))", "القناة"],
        ["type", "VARCHAR(40)", "NOT NULL", "رمز الحدث مثل INVOICE_POSTED"],
        ["title", "VARCHAR(200)", "NOT NULL", "العنوان"],
        ["body", "TEXT", "NULL", "النص"],
        ["entity_type", "VARCHAR(30)", "NULL", "المستند المرتبط"],
        ["entity_id", "BIGINT", "NULL", "معرفه"],
        ["is_read", "BOOLEAN", "NOT NULL DEFAULT FALSE", "مقروء"],
        ["read_at", "TIMESTAMPTZ", "NULL", "وقت القراءة"]
      ],
      indexes: ["INDEX(user_id, is_read, created_at DESC)", "INDEX(role_id, is_read)"] },

    { name: "audit_logs", title: "سجل التدقيق (لاتحققي)", std: false,
      desc: "تسجيل كل عملية حساسة: إنشاء فاتورة، تعديل عميل، تغيير سعر، اعتماد خصم، إلغاء، تسوية مخزون. لا يُحذف ولا يُعدَّل من أي واجهة — متطلب صريح في قسم 42.",
      fields: [
        ["company_id", "BIGINT", "NULL FK→companies(id)", "الشركة (NULL لأحداث المنصة)"],
        ["user_id", "BIGINT", "NULL FK→users(id)", "الفاعل"],
        ["action", "VARCHAR(40)", "NOT NULL", "الفعل: CREATE/UPDATE/APPROVE/CANCEL/POST..."],
        ["module", "VARCHAR(40)", "NOT NULL", "الوحدة مثل sales"],
        ["entity_type", "VARCHAR(40)", "NOT NULL", "الكيان"],
        ["entity_id", "BIGINT", "NULL", "معرف الكيان"],
        ["old_values", "JSONB", "NULL", "القيم قبل التعديل"],
        ["new_values", "JSONB", "NULL", "القيم بعده"],
        ["ip_address", "INET", "NULL", "عنوان IP"],
        ["user_agent", "TEXT", "NULL", "وكيل المستخدم/الجهاز"],
        ["created_at", "TIMESTAMPTZ", "NOT NULL DEFAULT now()", "الوقت"]
      ],
      indexes: ["INDEX(entity_type, entity_id, created_at DESC)", "INDEX(user_id, created_at DESC)"],
      checks: "REVOKE UPDATE/DELETE لكل الأدوار. جدول بلا deleted_at إطلاقًا." },

    { name: "settings", title: "إعدادات النظام", std: true, scoped: true,
      desc: "مخزن الإعدادات المعرفي (مفاتيح قسيمة 62): معلومات الشركة، الترقيم، الضرائب، قواعد الائتمان والعمولات، الطباعة، الأمان — قيمة JSONB لكل مفتاح.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["key", "VARCHAR(100)", "NOT NULL", "مفتاح مثل invoice.numbering.format"],
        ["value", "JSONB", "NOT NULL", "القيمة"],
        ["group_name", "VARCHAR(50)", "NOT NULL DEFAULT 'general'", "مجموعة العرض"],
        ["description", "VARCHAR(300)", "NULL", "شرح الإعداد"],
        ["updated_by", "BIGINT", "NULL FK→users(id)", "آخر معدل"]
      ],
      indexes: ["UNIQUE(company_id, key)"] },

    { name: "document_sequences", title: "متسلسلات ترقيم المستندات", std: false, scoped: true,
      desc: "عدّاد لكل نوع مستند وسنة، يُستهلك بقفل صفّي (SELECT ... FOR UPDATE) داخل معاملة الترحيل — يمنع التصادم تحت طلبات متزامنة وفقًا للقسم 63.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["doc_type", "VARCHAR(30)", "NOT NULL CHECK (IN ('INVOICE','ORDER','QUOTATION','PAYMENT','TRANSFER','ADJUSTMENT','STOCKTAKING','DAMAGE','RET','PO','RCPT','SIN','PRET','EXP','CRN','DLV','STK'))", "نوع المستند"],
        ["prefix", "VARCHAR(15)", "NOT NULL", "البادئة مثل INV"],
        ["year", "SMALLINT", "NOT NULL", "سنة الترقيم"],
        ["current_number", "BIGINT", "NOT NULL DEFAULT 0", "العدّاد الحالي"],
        ["padding", "SMALLINT", "NOT NULL DEFAULT 6", "عدد الخانات مثل 000001"]
      ],
      indexes: ["UNIQUE(company_id, doc_type, year)"] },

    { name: "sync_operations", title: "عمليات المزامنة (Offline)", std: true, scoped: true,
      desc: "سجل واردات تطبيق المندوب: المفتاح الفريد يمنع الازدواج، والحالة تتقدم من PENDING إلى SYNCED أو ترجع CONFLICT/REJECTED مع السبب وتصبح قابلة لمراجعة بشري.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["user_id", "BIGINT", "NOT NULL FK→users(id)", "المندوب"],
        ["device_id", "BIGINT", "NULL FK→user_devices(id)", "الجهاز المصدر"],
        ["client_transaction_id", "UUID", "NOT NULL UNIQUE", "مفتاح القوة القاهرة للتكرار — من التطبيق"],
        ["entity_type", "VARCHAR(40)", "NOT NULL CHECK (IN ('INVOICE','ORDER','PAYMENT','VISIT','RETURN'))", "نوع العملية"],
        ["payload", "JSONB", "NOT NULL", "حمولة العملية الكاملة"],
        ["sync_status", "VARCHAR(10)", "NOT NULL DEFAULT 'PENDING' CHECK (IN ('PENDING','SYNCED','CONFLICT','REJECTED'))", "الحالة"],
        ["result_reference_id", "BIGINT", "NULL", "معرف المستند الناتج عند النجاح"],
        ["conflict_reason", "TEXT", "NULL", "شرح التعارض"],
        ["created_at / synced_at", "TIMESTAMPTZ", "NULL/NOT NULL DEFAULT now()", "الأختام"]
      ],
      indexes: ["UNIQUE(client_transaction_id)", "INDEX(sync_status)", "INDEX(user_id, created_at DESC)"] },

    { name: "attachments", title: "المرفقات", std: false, scoped: true,
      desc: "فهرس ملفات التخزين الكائني (MinIO/S3): سندات مصروفات، صور مرتجعات، ملفات استيراد — مع تحقق MIME وحجم وأسماء آمنة مولدة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["entity_type", "VARCHAR(40)", "NOT NULL", "الكيان المرفق به"],
        ["entity_id", "BIGINT", "NOT NULL", "معرفه"],
        ["file_name", "VARCHAR(255)", "NOT NULL", "الاسم الأصلي للعرض"],
        ["file_url", "TEXT", "NOT NULL", "رابط التخزين الآمن (موقع تنفيذ خارجي)"],
        ["mime_type", "VARCHAR(100)", "NOT NULL", "النوع بعد التحقق"],
        ["file_size", "BIGINT", "NOT NULL CHECK (file_size <= 10485760)", "الحجم بحد 10MB"],
        ["uploaded_by", "BIGINT", "NULL FK→users(id)", "الرافع"]
      ],
      indexes: ["INDEX(entity_type, entity_id)"] },

    { name: "import_jobs", title: "مهام الاستيراد", std: true, scoped: true,
      desc: "دورة الاستيراد الآمنة من قسم 67: رفع ثم تحقق ثم معاينة أخطاء ثم تأكيد يدوي ثم معالجة خلفية، ولا يدخل صف واحد قبل التأكيد.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["job_type", "VARCHAR(20)", "NOT NULL CHECK (IN ('PRODUCTS','CUSTOMERS','SUPPLIERS','OPENING_STOCK','OPENING_BALANCES','PRICE_LISTS'))", "نوع البيانات"],
        ["file_url", "TEXT", "NOT NULL", "ملف Excel/CSV المرفوع"],
        ["status", "VARCHAR(18)", "NOT NULL DEFAULT 'UPLOADED' CHECK (IN ('UPLOADED','VALIDATING','VALIDATION_FAILED','PENDING_CONFIRM','PROCESSING','DONE','FAILED'))", "الحالة"],
        ["total_rows", "INTEGER", "NULL", "عدد الصفوف"],
        ["error_count", "INTEGER", "NULL", "عدد الأخطاء"],
        ["errors", "JSONB", "NULL", "قائمة الأخطاء بصفوفها"],
        ["summary", "JSONB", "NULL", "ملخص النتيجة"],
        ["created_by", "BIGINT", "NOT NULL FK→users(id)", "المستورد"],
        ["confirmed_at", "TIMESTAMPTZ", "NULL", "ختم التأكيد"]
      ],
      indexes: ["INDEX(company_id, status)"] },

    { name: "b2b_portal_users", title: "مستخدمو بوابة B2B", std: true, scoped: true,
      desc: "حساب تسجيل دخول مستقل للعميل/التاجر (منفصل عن موظفي الشركة): يتصفح أسعاره الخاصة ويطلب ويتابع ويحمّل فواتيره PDF — وفق صلاحيات قسم 61.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["customer_id", "BIGINT", "NOT NULL UNIQUE FK→customers(id)", "العميل المرتبط — حساب لكل عميل"],
        ["email", "VARCHAR(160)", "NOT NULL UNIQUE", "البريد للدخول"],
        ["password_hash", "VARCHAR(255)", "NOT NULL", "تجزئة كلمة المرور"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة — إيقاف فوري عند تجاوز ائتمان"],
        ["last_login_at", "TIMESTAMPTZ", "NULL", "آخر دخول"]
      ],
      indexes: ["UNIQUE(customer_id)", "UNIQUE(email)"] }
  ]
};

module.exports = { D6_SALES, D7_PAYMENTS, D10_FIELD_SALES, D11_SYSTEM };
