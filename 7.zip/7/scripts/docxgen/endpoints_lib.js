// endpoints_lib.js — API endpoint model + standard CRUD factory
// Generates full-detailed endpoint specs programmatically.

// ── Response envelope constants ──
const OK_LIST = (item, extra = {}) => JSON.stringify({
  success: true, data: [item], pagination: { page: 1, per_page: 20, total: 137, total_pages: 7 }, ...extra,
}, null, 2);
const OK_ONE = (item) => JSON.stringify({ success: true, data: item }, null, 2);
const OK_MSG = (msg, data = null) => JSON.stringify(
  data ? { success: true, message: msg, data } : { success: true, message: msg }, null, 2);
const ERR = (code, msg, status) => JSON.stringify({ success: false, code, message: msg }, null, 2);

// ── Endpoint factory helpers ──
// ep = { id, group, title, method, path, perm, desc, req?, res, resAlt?, errors, notes?, validation? }

function listEp({ entity, path, perm, example, title, desc, filters }) {
  return {
    id: `${entity}_list`, title: title || `قائمة ${entity}`,
    method: "GET", path, perm: perm + ".view",
    desc: desc || `استرجاع قائمة ${entity} مع دعم البحث والفرز والترقيم. النتائج محصورة دائمًا في نطاق company_id الخاص بالمستخدم ونطاق مستودعاته/فروعه وفق جدولي النفاذ.`,
    req: null,
    res: `{\n  "success": true,\n  "data": [\n${example},\n    // ... 19 صفًا إضافيًا\n  ],\n  "pagination": { "page": 1, "per_page": 20, "total": 137, "total_pages": 7 }\n}`,
    errors: [["PERM_001", "403", "لا تملك صلاحية العرض"]],
    validation: filters || [
      "page / per_page: ترقيم قياسي (افتراضي 1 / 20، بحد أقصى 100)",
      "search: بحث نصي في الحقول المعرفة للكيان",
      "sort: اسم حقل مسموح + dir=asc|desc",
      "status / date_from / date_to: مرشحات قياسية عند توفرها",
    ],
  };
}

function getEp({ entity, path, perm, example }) {
  return {
    id: `${entity}_get`, title: `تفاصيل ${entity}`,
    method: "GET", path: path + "/{id}", perm: perm + ".view",
    desc: `استرجاع تفاصيل سجل واحد بواسطة المعرف (يدعم uuid أيضًا). يرفع 404 إن لم يوجد ضمن نطاق المستخدم وcompany_id.`,
    req: null, res: `{\n  "success": true,\n  "data": ${example}\n}`,
    errors: [["PERM_001", "403", "لا تملك صلاحية العرض"], ["NOT_FOUND", "404", "السجل غير موجود في نطاقك"]],
  };
}

function createEp({ entity, path, perm, req, res, title, desc, errors, validation }) {
  return {
    id: `${entity}_create`, title: title || `إنشاء ${entity}`,
    method: "POST", path, perm: perm + ".create",
    desc: desc || `إنشاء سجل جديد لـ${entity}. يتم التحقق من كل الحقول عبر مخطط Zod على الخادم ثم تُطبق قواعد الأعمال قبل الحفظ، وتسجَّل العملية في audit_logs.`,
    req, res,
    errors: errors || [
      ["VALIDATION_001", "422", "بيانات غير صالحة — تفاصيل الحقول في errors.fields"],
      ["PERM_001", "403", "لا تملك صلاحية الإنشاء"],
    ],
    validation: validation || [
      "كل الحقول الإجبارية موجودة وبأنواعها الصحيحة",
      "code/sku إن وُجد: فريد داخل نطاق company_id",
      "company_id يُشتق من التوكن ولا يُقبل من الجسم مطلقًا",
    ],
  };
}

function updateEp({ entity, path, perm, req, res, desc }) {
  return {
    id: `${entity}_update`, title: `تعديل ${entity}`,
    method: "PUT", path: path + "/{id}", perm: perm + ".edit",
    desc: desc || `تعديل سجل. المستندات المعتمدة/المرحّلة ترفض التعديل بكود حالة واضح — التصحيح إلغاء أو إشعار دائن أو مرتجع. الفرق قبل/بعد يسجَّل في audit_logs.`,
    req, res,
    errors: [
      ["VALIDATION_001", "422", "بيانات غير صالحة"],
      ["PERM_001", "403", "لا تملك صلاحية التعديل"],
      ["STATE_002", "409", "المستند معتمد/مرحّل — التعديل ممنوع"],
    ],
  };
}

function deleteEp({ entity, path, perm, desc }) {
  return {
    id: `${entity}_delete`, title: `حذف ${entity}`,
    method: "DELETE", path: path + "/{id}", perm: perm + ".delete",
    desc: desc || `حذف ناعم فقط (deleted_at) للسجلات غير المعتمدة وغير المرتبطة بحركات. أي محاولة حذف سجل له حركات ترفض بكود صريح. يسجَّل في audit_logs.`,
    req: null,
    res: OK_MSG("تم الحذف بنجاح"),
    errors: [
      ["PERM_001", "403", "لا تملك صلاحية الحذف"],
      ["STATE_003", "409", "لا يمكن حذف سجل مرتبط بحركات — استخدم التعطيل"],
      ["NOT_FOUND", "404", "غير موجود"],
    ],
  };
}

// action endpoint (post/approve/cancel/receive...)
function actionEp({ entity, action, path, perm, title, desc, req, res, errors, validation }) {
  return {
    id: `${entity}_${action}`, title: title || `${action} — ${entity}`,
    method: "POST", path: `${path}/{id}/${action}`, perm,
    desc,
    req: req || null, res,
    errors: errors || [["PERM_001", "403", "لا تملك الصلاحية المطلوبة"], ["STATE_001", "409", "الحالة الحالية لا تسمح بهذا الإجراء"]],
    validation,
  };
}

// ── Global sections data ──
const API_GLOBALS = {
  baseUrl: "https://api.example.com/api/v1",
  authNote: "جميع الطلبات (عدا الدخول والتحديث) تتطلب ترويسة Authorization: Bearer {access_token} مع انتهاء صلاحية افتراضي 15 دقيقة وrefresh token مدته 7 أيام يدور دوريًا. الدخول مقفول مؤقتًا بعد 5 محاولات فاشلة (AUTH_004) لمدة قابلة للتهيئة.",
  commonHeaders: [
    ["Authorization", "Bearer {access_token}", "إجباري عدا /auth/login و /auth/refresh"],
    ["Content-Type", "application/json", "للطلبات ذات الجسم"],
    ["Accept-Language", "ar | en", "لغة رسائل الأخطاء (افتراضي ar)"],
    ["X-Client-Version / X-Device-Id", "نص", "إجباري من تطبيق المندوب للمزامنة"],
  ],
  paginationNote: "كل قوائم الإرجاع تتبع نفس شكل pagination: { page, per_page, total, total_pages } مع حد أقصى per_page=100. الفرز sort=field&dir=asc|desc محصور بحقول مسموحة لكل كيان لمنع فحص الأعمدة.",
  errorCodes: [
    ["AUTH_001", "401", "بيانات دخول غير صحيحة"],
    ["AUTH_002", "401", "الرمز منتهي أو غير صالح"],
    ["AUTH_003", "401", "رمز التحديث غير صالح — يلزم دخول جديد"],
    ["AUTH_004", "423", "الحساب مقفول مؤقتًا بسبب المحاولات الفاشلة"],
    ["AUTH_005", "403", "الحساب موقوف"],
    ["PERM_001", "403", "لا تملك الصلاحية المطلوبة"],
    ["SCOPE_001", "403", "محاولة الوصول لنطاق شركة/فرع/مستودع خارج صلاحياتك"],
    ["VALIDATION_001", "422", "فشل التحقق من المدخلات"],
    ["NOT_FOUND", "404", "السجل غير موجود في نطاقك"],
    ["CONFLICT_001", "409", "تكرار — السجل موجود مسبقًا"],
    ["STATE_001", "409", "انتقال حالة غير مسموح"],
    ["STATE_002", "409", "المستند معتمد/مرحّل — التعديل ممنوع"],
    ["STATE_003", "409", "لا يمكن الحذف — السجل مرتبط بحركات"],
    ["STOCK_001", "422", "الكمية المتاحة غير كافية"],
    ["STOCK_002", "422", "لا يجوز البيع من مستودع غير مخزن المندوب"],
    ["CREDIT_001", "402", "تجاوز حد الائتمان — مرفوض حسب الإعداد"],
    ["CREDIT_002", "409", "تجاوز حد الائتمان — أُحيل للموافقة حسب الإعداد"],
    ["PAYMENT_001", "422", "الدفعة تتجاوز المبلغ المطلوب"],
    ["PAYMENT_002", "422", "مجموع التوزيعات لا يساوي مبلغ الدفعة"],
    ["SYNC_001", "409", "client_transaction_id مكرر — العملية رُحّلت سابقًا"],
    ["SYNC_002", "409", "تعارض مزامنة — يتطلب مراجعة"],
    ["APPROVAL_001", "409", "العملية تتطلب موافقة معلقة قبل التنفيذ"],
    ["APPROVAL_002", "403", "أنت مقدّم الطلب — لا يمكنك اعتماده"],
    ["IMPORT_001", "422", "الملف يحتوي أخطاء — راجع errors قبل التأكيد"],
    ["RATE_001", "429", "تجاوز حد معدل الطلبات"],
  ],
  rateLimit: "حدود معدل افتراضية: 120 طلبًا/دقيقة لكل مستخدم، و600/دقيقة للمزامنة الدفعية. تجاوزها يعيد 429 مع ترويسات Retry-After.",
};

// JSON request example helper (compact multi-line string with 2-space indent)
function J(obj) { return JSON.stringify(obj, null, 2); }

module.exports = { OK_LIST, OK_ONE, OK_MSG, ERR, listEp, getEp, createEp, updateEp, deleteEp, actionEp, API_GLOBALS, J };
