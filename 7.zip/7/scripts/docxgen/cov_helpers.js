// =====================================================================
// cov_helpers.js — RTL helpers proven in gen_compliance_report.js
// Cover: Recipe R1 (RTL adaptation) · Navy+Gold executive palette
// =====================================================================
const {
  Paragraph, TextRun, Table, TableRow, TableCell, Header, Footer,
  PageNumber, AlignmentType, HeadingLevel, WidthType, BorderStyle,
  ShadingType, TableLayoutType,
} = require("docx");

// ---------- Palette: Navy + Gold (executive verification report) ----------
const PAL = {
  bg: "12233B", accent: "C9A45C",
  cover: { titleColor: "FFFFFF", subtitleColor: "C7D2E0", metaColor: "AEBFD3", footerColor: "8CA0B8" },
  table: { headerBg: "1E3A5F", headerText: "FFFFFF", accentLine: "C9A45C", innerLine: "D9DDE3", surface: "F4F6F9" },
  primaryText: "13233A", body: "1B2634", muted: "5A6A7C",
};
const STATUS = {
  FULL: { label: "مطابق", color: "2E7D4F", bg: "E8F3EC" },
  PART: { label: "مطابق جزئياً", color: "B26A00", bg: "FBF3E4" },
  MISS: { label: "غير منفذ", color: "B3261E", bg: "FBEAE8" },
};
const FONT = { ascii: "Arial", hAnsi: "Arial", cs: "Arial" };

const noBorder = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const allNoBorders = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder, insideHorizontal: noBorder, insideVertical: noBorder };
const cellNoBorders = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder };

// ---------- RTL runs ----------
function rt(text, opts = {}) {
  return new TextRun({
    text, rightToLeft: true, font: FONT,
    size: opts.size ?? 24, sizeComplexScript: opts.size ?? 24,
    bold: opts.bold ?? false, boldComplexScript: opts.bold ?? false,
    italics: opts.italics ?? false,
    color: opts.color ?? PAL.body,
  });
}
function rtEn(text, opts = {}) {
  return new TextRun({
    text, font: FONT, size: opts.size ?? 24,
    bold: opts.bold ?? false, color: opts.color ?? PAL.body,
    characterSpacing: opts.charSpace ?? 0,
  });
}
function para(children, opts = {}) {
  return new Paragraph({
    bidirectional: opts.ltr ? false : true,
    alignment: opts.alignment ?? AlignmentType.JUSTIFIED,
    spacing: { line: 312, before: opts.before ?? 0, after: opts.after ?? 120 },
    indent: opts.indent,
    border: opts.border,
    keepNext: opts.keepNext ?? false,
    heading: opts.heading,
    children,
  });
}
function body(text, opts = {}) { return para([rt(text, { size: 22 })], opts); }
function h1(num, text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1, bidirectional: true,
    spacing: { before: 400, after: 180, line: 380, lineRule: "atLeast" },
    border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: PAL.accent, space: 6 } },
    children: [rt(num + ". " + text, { size: 30, bold: true, color: PAL.primaryText })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2, bidirectional: true,
    spacing: { before: 280, after: 140, line: 340, lineRule: "atLeast" },
    children: [rt(text, { size: 25, bold: true, color: "7A5A1E" })],
  });
}

// ---------- RTL table (Horizontal-Only business style) ----------
// cell: string | { t, color?, bold?, align?, bg?, en? }
function rtlTable(headers, rows, widths, opts = {}) {
  const cellSize = opts.size ?? 20;
  const mkPara = (runs, align) => para(runs, { alignment: align, after: 0 });
  const headRow = new TableRow({
    tableHeader: true, cantSplit: true,
    children: headers.map((tx, i) => new TableCell({
      width: { size: widths[i], type: WidthType.PERCENTAGE },
      shading: { type: ShadingType.CLEAR, fill: PAL.table.headerBg },
      margins: { top: 70, bottom: 70, left: 100, right: 100 },
      children: [mkPara([rt(tx, { size: cellSize, bold: true, color: PAL.table.headerText })], AlignmentType.CENTER)],
    })),
  });
  const dataRows = rows.map((cells, rIdx) => new TableRow({
    cantSplit: true,
    children: cells.map((cell, i) => {
      const isObj = typeof cell === "object" && cell !== null;
      const txt = isObj ? cell.t : cell;
      const color = isObj && cell.color ? cell.color : PAL.body;
      const bold = isObj && cell.bold ? true : false;
      const fill = isObj && cell.bg ? cell.bg : (opts.zebra && rIdx % 2 === 1 ? PAL.table.surface : "FFFFFF");
      const align = isObj && cell.align ? cell.align : AlignmentType.RIGHT;
      const runs = (isObj && cell.en)
        ? [rtEn(String(txt), { size: cellSize, color, bold })]
        : [rt(String(txt), { size: cellSize, color, bold })];
      return new TableCell({
        width: { size: widths[i], type: WidthType.PERCENTAGE },
        shading: { type: ShadingType.CLEAR, fill },
        margins: { top: 55, bottom: 55, left: 100, right: 100 },
        children: [mkPara(runs, align)],
      });
    }),
  }));
  return new Table({
    visuallyRightToLeft: true,
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: PAL.table.accentLine },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: PAL.table.accentLine },
      left: noBorder, right: noBorder,
      insideHorizontal: { style: BorderStyle.SINGLE, size: 1, color: PAL.table.innerLine },
      insideVertical: noBorder,
    },
    rows: [headRow, ...dataRows],
  });
}
function tableCaption(text) {
  return para([rt(text, { size: 20, bold: true, color: PAL.muted })], { alignment: AlignmentType.RIGHT, keepNext: true, after: 80 });
}
function stFull(note) { return { t: note ?? STATUS.FULL.label, color: STATUS.FULL.color, bold: true, align: AlignmentType.CENTER, bg: STATUS.FULL.bg }; }

// ---------- Cover title layout (Arabic char width ≈ pt × 11.5 twips) ----------
function splitTitleLines(title, charsPerLine) {
  if (title.length <= charsPerLine) return [title];
  const words = title.split(" ");
  const lines = []; let cur = "";
  for (const w of words) {
    const cand = cur ? cur + " " + w : w;
    if (cand.length > charsPerLine && cur) { lines.push(cur); cur = w; } else { cur = cand; }
  }
  if (cur) lines.push(cur);
  if (lines.length > 1 && lines[lines.length - 1].length <= 4) {
    const last = lines.pop(); lines[lines.length - 1] += " " + last;
  }
  return lines;
}
function calcTitleLayoutAr(title, maxWidthTwips, preferredPt = 40, minPt = 24) {
  const charWidth = (pt) => Math.ceil(pt * 11.5);
  let titlePt = preferredPt, lines;
  while (titlePt >= minPt) {
    const cpl = Math.floor(maxWidthTwips / charWidth(titlePt));
    if (cpl < 4) { titlePt -= 2; continue; }
    lines = splitTitleLines(title, cpl);
    if (lines.length <= 3) break;
    titlePt -= 2;
  }
  if (!lines || lines.length > 3) { lines = splitTitleLines(title, Math.floor(maxWidthTwips / charWidth(minPt))); titlePt = minPt; }
  return { titlePt, titleLines: lines };
}
function calcCoverSpacing(params) {
  const { titleLineCount = 1, titlePt = 36, hasSubtitle = false, hasEnglishLabel = false,
    metaLineCount = 0, fixedHeight = 800, pageHeight = 16838 } = params;
  const SAFETY = 1200;
  const usable = pageHeight - SAFETY;
  const titleH = titleLineCount * (titlePt * 23 + 200);
  const subH = hasSubtitle ? (13 * 23 + 600) : 0;
  const engH = hasEnglishLabel ? (9 * 23 + 600) : 0;
  const metaH = metaLineCount * (11 * 23 + 120);
  const implicit = 3 * 300;
  const content = titleH + subH + engH + metaH + fixedHeight + implicit;
  const remaining = Math.max(usable - content, 400);
  const FOOTER_MIN = 800;
  const rawTop = Math.floor(remaining * 0.45), rawBottom = Math.floor(remaining * 0.45);
  const bottomSpacing = Math.max(rawBottom, FOOTER_MIN);
  const topSpacing = Math.max(rawTop - Math.max(0, FOOTER_MIN - rawBottom), 400);
  const midSpacing = Math.max(remaining - topSpacing - bottomSpacing, 0);
  return { topSpacing, midSpacing, bottomSpacing };
}

// ---------- Cover R1 (RTL adaptation — right-aligned navy full page) ----------
function buildCoverR1RTL(config) {
  const P = config.palette;
  const padStart = 1200, padEnd = 800;
  const availableWidth = 11906 - padStart - padEnd - 300;
  const { titlePt, titleLines } = calcTitleLayoutAr(config.title, availableWidth, 40, 24);
  const titleSize = titlePt * 2;
  const spacing = calcCoverSpacing({
    titleLineCount: titleLines.length, titlePt,
    hasSubtitle: !!config.subtitle, hasEnglishLabel: !!config.englishLabel,
    metaLineCount: (config.metaLines || []).length, fixedHeight: 400,
  });
  const accentStart = { style: BorderStyle.SINGLE, size: 8, color: P.accent, space: 12 };
  const children = [];
  children.push(new Paragraph({ spacing: { before: spacing.topSpacing } }));
  if (config.englishLabel) {
    children.push(new Paragraph({
      alignment: AlignmentType.RIGHT,
      indent: { left: padEnd, right: padStart },
      spacing: { after: 500 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: P.accent, space: 8 } },
      children: [rtEn(config.englishLabel.split("").join("  "), { size: 18, color: P.accent, charSpace: 40 })],
    }));
  }
  for (let i = 0; i < titleLines.length; i++) {
    children.push(new Paragraph({
      bidirectional: true,
      indent: { left: padEnd, right: padStart },
      spacing: { after: i < titleLines.length - 1 ? 100 : 300, line: Math.ceil(titlePt * 23), lineRule: "atLeast" },
      children: [rt(titleLines[i], { size: titleSize, bold: true, color: P.cover.titleColor })],
    }));
  }
  if (config.subtitle) {
    children.push(new Paragraph({
      bidirectional: true,
      indent: { left: padEnd, right: padStart },
      spacing: { after: 800, line: 380, lineRule: "atLeast" },
      children: [rt(config.subtitle, { size: 26, color: P.cover.subtitleColor })],
    }));
  }
  for (const line of (config.metaLines || [])) {
    children.push(new Paragraph({
      bidirectional: true,
      indent: { left: padEnd + 200, right: padStart + 200 },
      spacing: { after: 90, line: 320, lineRule: "atLeast" },
      border: { right: accentStart },
      children: [rt(line, { size: 22, color: P.cover.metaColor })],
    }));
  }
  children.push(new Paragraph({ spacing: { before: spacing.bottomSpacing } }));
  children.push(new Paragraph({
    bidirectional: true,
    indent: { left: padEnd, right: padStart },
    border: { top: { style: BorderStyle.SINGLE, size: 2, color: P.accent, space: 8 } },
    spacing: { before: 200 },
    children: [rt(config.footerRight + "          " + config.footerLeft, { size: 17, color: P.cover.footerColor })],
  }));
  return [new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: allNoBorders,
    rows: [new TableRow({
      height: { value: 16838, rule: "exact" },
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: P.bg }, borders: cellNoBorders,
        children,
      })],
    })],
  })];
}

const pgSize = { width: 11906, height: 16838 };
const pgMargin = { top: 1440, bottom: 1440, left: 1417, right: 1701 }; // مرايا RTL: التجليد يميناً

function pageFooter() {
  return new Footer({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080", font: FONT })],
    })],
  });
}
function docHeader(text) {
  return new Header({
    children: [new Paragraph({
      bidirectional: true, alignment: AlignmentType.CENTER,
      border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine, space: 4 } },
      children: [rt(text, { size: 17, color: "888888" })],
    })],
  });
}

module.exports = {
  PAL, STATUS, FONT, allNoBorders, cellNoBorders, noBorder,
  rt, rtEn, para, body, h1, h2, rtlTable, tableCaption, stFull,
  buildCoverR1RTL, pgSize, pgMargin, pageFooter, docHeader,
};
