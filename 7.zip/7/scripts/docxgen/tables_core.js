// tables_core.js — Domain groups 1-3: Core/Security, Products/Pricing, Parties
// Field row: [name, type, constraints, description_ar]

const D1_CORE = {
  id: "d1", no: "1", png: "erd_01_core.png",
  title: "النواة والأمان — المؤسسات، الفروع، المستخدمون والصلاحيات",
  intro: [
    "يشكّل هذا المجال الهيكل التنظيمي للنظام بأكمله، إذ تعتمد عليه جميع المجالات الأخرى في تحديد النطاق والملكية. يبدأ من الشركة (Company) التي تمثل حدود المستأجر Tenant، وينزل عبر الفروع (Branches) إلى المستودعات (Warehouses) التي تعد وحدات تخزين فعليًا ومنطقيًا، بما فيها مخازن المندوبين المتنقلة التي تُعامل كمستودعات مستقلة من نوع REP.",
    "أما إدارة الوصول فتقوم على نموذج RBAC ثلاثي الطبقات: المستخدم مرتبط بأدوار (Roles)، وكل دور يحمل صلاحيات ذرية (Permissions) بصيغة module.action مثل sales.invoice.approve. تُفحص الصلاحيات دائمًا على الخادم عند كل طلب API وليس في الواجهة فقط، مع نطاقات إضافية على مستوى الفرع والمستودع عبر جدولي user_warehouse_access و user_roles.branch_id.",
    "يتضمن المجال أيضًا إدارة الأجهزة (user_devices) لدعم تطبيق المندوب والإشعارات الفورية، وسياسات قفل الحساب بعد المحاولات الفاشلة، بما يغطي متطلبات الأمان في الوثيقة الأم (الأقسام 3 و4 و47)."
  ],
  tables: [
    { name: "companies", title: "الشركات", std: true,
      desc: "جدول المستأجرين الجذري. كل صف يمثل شركة مستقلة تعيش بياناتها داخل نطاق company_id في بقية الجداول، ما يجعل التحويل إلى SaaS متعدد الشركات ممكنًا دون إعادة تصميم. العملة الافتراضية إجبارية وتعتمد الدينار العراقي IQD افتراضيًا.",
      fields: [
        ["name", "VARCHAR(200)", "NOT NULL", "الاسم التجاري بالعربية"],
        ["name_en", "VARCHAR(200)", "NULL", "الاسم بالإنجليزية"],
        ["legal_name", "VARCHAR(250)", "NULL", "الاسم القانوني للسجلات الرسمية"],
        ["tax_number", "VARCHAR(60)", "NULL", "الرقم الضريبي ويظهر على الفواتير"],
        ["phone", "VARCHAR(30)", "NULL", "هاتف الشركة"],
        ["email", "VARCHAR(160)", "NULL", "البريد الرسمي"],
        ["address", "TEXT", "NULL", "العنوان الكامل"],
        ["logo_url", "TEXT", "NULL", "رابط الشعار في التخزين الكائني Object Storage"],
        ["currency_code", "CHAR(3)", "NOT NULL DEFAULT 'IQD'", "العملة الأساسية (ISO 4217)"],
        ["base_language", "VARCHAR(5)", "NOT NULL DEFAULT 'ar'", "لغة الواجهة الافتراضية"],
        ["allow_negative_stock", "BOOLEAN", "NOT NULL DEFAULT FALSE", "السماح بالبيع بالسالب صراحة — القاعدة الافتراضية المنع"],
        ["costing_method", "VARCHAR(20)", "NOT NULL DEFAULT 'WAVG' CHECK (costing_method IN ('FIFO','WAVG','STD'))", "سياسة التكلفة على مستوى الشركة"],
        ["settings", "JSONB", "NOT NULL DEFAULT '{}'", "إعدادات مرنة إضافية (قواعد الموافقة، ترقيم المستندات...)"]
      ],
      indexes: ["UNIQUE(uuid)", "UNIQUE(name, deleted_at)"] },

    { name: "branches", title: "الفروع", std: true, scoped: true,
      desc: "الفروع التشغيلية للشركة. كل فرع يستطيع امتلاك مستودعات وفرق مبيعات ومستخدمين، وتُطبَّق صلاحية مدير الفرع ضمن نطاق فرعه فقط. الرقم code فريد داخل الشركة ويُستخدم في ترقيم المستندات الاختياري.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["code", "VARCHAR(30)", "NOT NULL", "رمز الفرع (مثل BGW للبغداد)"],
        ["name", "VARCHAR(150)", "NOT NULL", "اسم الفرع"],
        ["phone", "VARCHAR(30)", "NULL", "هاتف الفرع"],
        ["address", "TEXT", "NULL", "عنوان الفرع"],
        ["city", "VARCHAR(80)", "NULL", "المدينة"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "تعطيل بدون حذف"]
      ],
      indexes: ["UNIQUE(company_id, code, deleted_at)", "INDEX(company_id, is_active)"] },

    { name: "warehouses", title: "المستودعات", std: true, scoped: true,
      desc: "وحدات التخزين الفعلية والمنطقية. مخزن المندوب المتنقل مستودع من نوع REP مرتبط بالمندوب عبر sales_reps.warehouse_id، ولا يمكن للمندوب البيع من غيره لأن الخادم يشتقه تلقائيًا. نوع TRANSIT اختياري لاحتواء الكميات العابرة أثناء التحويل ومنع الاحتساب المزدوج.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["branch_id", "BIGINT", "NOT NULL FK→branches(id)", "الفرع التابع له"],
        ["code", "VARCHAR(30)", "NOT NULL", "رمز المستودع (مثل WH-MAIN أو REP-AHMED)"],
        ["name", "VARCHAR(150)", "NOT NULL", "اسم المستودع"],
        ["type", "VARCHAR(15)", "NOT NULL CHECK (type IN ('MAIN','BRANCH','REP','TRANSIT','DAMAGED'))", "النوع الخمسة المنصوص عليها في الوثيقة"],
        ["manager_id", "BIGINT", "NULL FK→users(id)", "أمين المستودع"],
        ["is_mobile", "BOOLEAN", "NOT NULL DEFAULT FALSE", "مستودع متنقل (سيارة مندوب)"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["UNIQUE(company_id, code, deleted_at)", "INDEX(branch_id)", "INDEX(type)"],
      checks: "لا يمكن حذف مستودع عليه أرصدة — يُعطَّل فقط. يجب وجود مستودع MAIN واحد على الأقل لكل شركة." },

    { name: "users", title: "المستخدمون", std: true, scoped: true,
      desc: "حسابات الدخول لكل الأدوار (إدارة، كاشير، محاسب، مندوب...). كلمة المرور تُخزَّن بتجزئة bcrypt/argon2 فقط. القفل التلقائي بعد عدد محاولات فاشلة قابل للتهيئة، والحذف ناعم دائمًا حفاظًا على سلامة السجلات التاريخية التي تحمل created_by.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["branch_id", "BIGINT", "NULL FK→branches(id)", "الفرع الافتراضي (NULL للمستويات العليا)"],
        ["username", "VARCHAR(80)", "NOT NULL", "اسم الدخول"],
        ["email", "VARCHAR(160)", "NULL", "البريد — فريد عند وجوده"],
        ["phone", "VARCHAR(30)", "NULL", "الهاتف"],
        ["password_hash", "VARCHAR(255)", "NOT NULL", "تجزئة كلمة المرور (argon2id)"],
        ["full_name", "VARCHAR(150)", "NOT NULL", "الاسم الكامل"],
        ["language", "VARCHAR(5)", "NOT NULL DEFAULT 'ar'", "تفضيل اللغة ar/en"],
        ["theme", "VARCHAR(10)", "NOT NULL DEFAULT 'system' CHECK (theme IN ('light','dark','system'))", "تفضيل المظهر"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"],
        ["failed_login_count", "SMALLINT", "NOT NULL DEFAULT 0", "عداد المحاولات الفاشلة"],
        ["locked_until", "TIMESTAMPTZ", "NULL", "قفل مؤقت بعد تجاوز الحد"],
        ["last_login_at", "TIMESTAMPTZ", "NULL", "آخر دخول"]
      ],
      indexes: ["UNIQUE(company_id, username, deleted_at)", "UNIQUE(email) WHERE email IS NOT NULL"] },

    { name: "roles", title: "الأدوار", std: true, scoped: true,
      desc: "أدوار RBAC القابلة للتهيئة. تُزرع أدوار النظام الإحدى عشرة من الوثيقة (Owner, Super Admin, Branch Manager, Sales Manager, Warehouse Manager, Sales Rep, Cashier, Accountant, Purchasing Officer, Auditor, Viewer) على إنشاء الشركة، ويُسمح بإضافة أدوار مخصصة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["code", "VARCHAR(50)", "NOT NULL", "رمز الدور مثل SALES_MANAGER"],
        ["name", "VARCHAR(100)", "NOT NULL", "الاسم المعروض"],
        ["description", "TEXT", "NULL", "وصف الاختصاصات"],
        ["is_system", "BOOLEAN", "NOT NULL DEFAULT FALSE", "دور نظام لا يُحذف"]
      ],
      indexes: ["UNIQUE(company_id, code, deleted_at)"] },

    { name: "permissions", title: "الصلاحيات الذرية", std: false,
      desc: "كتالوج عام مشترك لكل الصلاحيات بصيغة module.action (مثل sales.invoice.create و inventory.transfer.approve). يتولد تلقائيًا من شجرة الوحدات، وتُمنح للأدوار لا للمستخدمين مباشرة. يشمل الحدود الاثني عشر: view, create, edit, delete, approve, reject, cancel, print, export, import, post, reverse.",
      fields: [
        ["code", "VARCHAR(80)", "NOT NULL UNIQUE", "المعرف الكامل مثل sales.invoice.post"],
        ["module", "VARCHAR(50)", "NOT NULL", "الوحدة مثل sales"],
        ["entity", "VARCHAR(50)", "NOT NULL", "الكيان مثل invoice"],
        ["action", "VARCHAR(30)", "NOT NULL CHECK (action IN ('view','create','edit','delete','approve','reject','cancel','print','export','import','post','reverse'))", "الفعل"],
        ["description_ar", "VARCHAR(250)", "NULL", "وصف عربي للعرض"]
      ],
      indexes: ["UNIQUE(code)"] },

    { name: "role_permissions", title: "صلاحيات الأدوار", std: false, scoped: true,
      desc: "جدول الربط بين الأدوار والصلاحيات. التعديل عليه يُسجَّل كاملًا في audit_logs لأنه يغير خريطة الوصول للنظام بأكمله.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["role_id", "BIGINT", "NOT NULL FK→roles(id)", "الدور"],
        ["permission_id", "BIGINT", "NOT NULL FK→permissions(id)", "الصلاحية"]
      ],
      indexes: ["UNIQUE(role_id, permission_id)", "INDEX(permission_id)"] },

    { name: "user_roles", title: "أدوار المستخدمين", std: false, scoped: true,
      desc: "ربط المستخدمين بالأدوار مع إمكانية تضييق الدور إلى فرع محدد؛ فيغدو مدير المبيعات مديرًا لفرع البصرة دون غيره. يدعم تعدد الأدوار للمستخدم الواحد، وتُجمع صلاحياته كاتحاد لكل أدواره.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["user_id", "BIGINT", "NOT NULL FK→users(id)", "المستخدم"],
        ["role_id", "BIGINT", "NOT NULL FK→roles(id)", "الدور"],
        ["branch_id", "BIGINT", "NULL FK→branches(id)", "تقييد الدور بفرع — NULL يعني كل الفروع"]
      ],
      indexes: ["UNIQUE(user_id, role_id, branch_id)"] },

    { name: "user_warehouse_access", title: "نفاذ المستخدمين للمستودعات", std: false, scoped: true,
      desc: "النطاق الثاني للصلاحيات: يحدد أي مستودعات يرى المستخدم ويشتغل عليها. المندوب يحمل صفاً واحداً لمخزنه فقط، وهو أساس منع رؤية مخازن مندوبين آخرين (الاختبار الحرج 3). لا يعتمد أي استعلام مخزون على الواجهة — يُفرض WHERE على الخادم.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["user_id", "BIGINT", "NOT NULL FK→users(id)", "المستخدم"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "المستودع المصرّح"],
        ["can_read", "BOOLEAN", "NOT NULL DEFAULT TRUE", "قراءة الأرصدة"],
        ["can_operate", "BOOLEAN", "NOT NULL DEFAULT FALSE", "تنفيذ حركات (بيع، تحويل...)"]
      ],
      indexes: ["UNIQUE(user_id, warehouse_id)", "INDEX(warehouse_id)"] },

    { name: "user_devices", title: "أجهزة المستخدمين", std: false, scoped: true,
      desc: "سجل أجهزة المندوبين لتطبيق Flutter والإشعارات الفورية. يفعّل إدارة الأجهزة من حساب المستخدم (عرض/إبطال جلسة جهاز)، ويُستخدم مع sync_operations لتتبع مصدر عمليات العمل دون اتصال.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["user_id", "BIGINT", "NOT NULL FK→users(id)", "المستخدم المالك"],
        ["device_id", "VARCHAR(120)", "NOT NULL", "معرف الجهاز الفريد المولد من التطبيق"],
        ["device_name", "VARCHAR(120)", "NULL", "اسم الجهاز الوصفي"],
        ["platform", "VARCHAR(30)", "NULL CHECK (platform IN ('ANDROID','IOS','WEB'))", "المنصة"],
        ["app_version", "VARCHAR(30)", "NULL", "إصدار التطبيق"],
        ["push_token", "TEXT", "NULL", "رمز الإشعارات FCM/APNs"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "إبطال الجهاز عند الفقدان"],
        ["last_seen_at", "TIMESTAMPTZ", "NULL", "آخر اتصال"]
      ],
      indexes: ["UNIQUE(user_id, device_id)", "INDEX(is_active)"] }
  ]
};

const D2_PRODUCTS = {
  id: "d2", no: "2", png: "erd_02_products.png",
  title: "المنتجات والتسعير — الأصناف، الوحدات، الباركود وقوائم الأسعار",
  intro: [
    "يغطي هذا المجال البيانات الرئيسية للمنتجات بدءًا من شجرة التصنيفات ذات المستويات غير المحدودة (parent_id ذاتي)، مرورًا بالعلامات التجارية ووحدات القياس مع تحويلاتها، وصولًا إلى المنتج نفسه بكامل سماته: تتبع الدفعات، التسلسل، الصلاحية، وحدود إعادة الطلب.",
    "نظام التسعير مطبّق بأربع طبقات أولوية صريحة يفحصها محرك التسعير على الخادم بالترتيب: سعر العميل الخاص (customer_product_prices) ثم سعر مجموعة العملاء ثم قائمة الأسعار السارية ثم السعر الافتراضي للمنتج. كل طبقة تدعم الوحدة وحدّ الكمية الأدنى وفترة صلاحية، ما يحقق سيناريوهات الجملة والقطاعي والموزعين دون منطق مكرر.",
    "الباركود متعدد لكل منتج مع وحدة لكل باركود، ويُفهرس فهرسًا فريدًا لضمان بحث أقل من 200ms في نقطة البيع POS كما تشترط مؤشرات الأداء."
  ],
  tables: [
    { name: "categories", title: "تصنيفات المنتجات (شجرة)", std: true, scoped: true,
      desc: "شجرة تصنيفات لا نهائية المستويات عبر parent_id الذاتي، مثل: المنتجات ← شامبو ← طبي. الحذف مسموح فقط للتصنيفات الخالية من منتجات وأبناء، وإلا يُعطَّل.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["parent_id", "BIGINT", "NULL FK→categories(id)", "التصنيف الأب — NULL للجذر"],
        ["code", "VARCHAR(30)", "NULL", "رمز اختياري"],
        ["name", "VARCHAR(150)", "NOT NULL", "الاسم بالعربية"],
        ["name_en", "VARCHAR(150)", "NULL", "الاسم بالإنجليزية"],
        ["level", "SMALLINT", "NOT NULL DEFAULT 0", "عمق العقدة — يُحدّث آليًا"],
        ["sort_order", "INTEGER", "NOT NULL DEFAULT 0", "ترتيب العرض"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["INDEX(company_id, parent_id)", "UNIQUE(company_id, parent_id, name)"] },

    { name: "brands", title: "العلامات التجارية", std: true, scoped: true,
      desc: "علامات المنتجات التجارية مع شعار اختياري، وتُستخدم في التقارير التحليلية حسب العلامة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["code", "VARCHAR(30)", "NOT NULL", "رمز العلامة"],
        ["name", "VARCHAR(150)", "NOT NULL", "الاسم"],
        ["logo_url", "TEXT", "NULL", "الشعار"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["UNIQUE(company_id, code, deleted_at)"] },

    { name: "units", title: "وحدات القياس", std: true, scoped: true,
      desc: "وحدات القياس الأساسية: Piece, Box, Carton, Pack, Dozen, Kg, Liter. المنتج يعلن وحدته الأساسية base_unit وكل حركة مخزون تُحوَّل إليها داخليًا في quantity_base لتوحيد الاحتساب.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["code", "VARCHAR(20)", "NOT NULL", "الرمز مثل PCS/CTN"],
        ["name", "VARCHAR(50)", "NOT NULL", "الاسم"],
        ["type", "VARCHAR(12)", "NOT NULL CHECK (type IN ('COUNT','WEIGHT','VOLUME','LENGTH'))", "طبيعة الوحدة"],
        ["is_base", "BOOLEAN", "NOT NULL DEFAULT FALSE", "وحدة أساسية لا تُشتق"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["UNIQUE(company_id, code, deleted_at)"] },

    { name: "unit_conversions", title: "تحويلات الوحدات", std: false, scoped: true,
      desc: "معاملات التحويل بين الوحدات مثل 1 كرتونة = 24 قطعة. يفحص النظام التكافؤ بالاتجاهين (from→to و to→from) عند الحساب، ومنع التحويلات المتسلسلة المتناقضة عبر التحقق عند الإدخال.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["from_unit_id", "BIGINT", "NOT NULL FK→units(id)", "من وحدة"],
        ["to_unit_id", "BIGINT", "NOT NULL FK→units(id)", "إلى وحدة"],
        ["factor", "NUMERIC(18,6)", "NOT NULL CHECK (factor > 0)", "المعامل: 1 from = factor to"]
      ],
      indexes: ["UNIQUE(from_unit_id, to_unit_id)", "CHECK (from_unit_id <> to_unit_id)"] },

    { name: "products", title: "المنتجات", std: true, scoped: true,
      desc: "قلب البيانات الرئيسية. يدعم ثنائية اللغة، وسمات التتبع الثلاثة (تشغيل الدفعات، التسلسل، الصلاحية) التي تُلزم حركات المخزون بتعبئة batch_id/serial_id وتاريخ الانتهاء عند تفعيلها. الأسعار الافتراضية هنا أدنى طبقة تسعير.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["sku", "VARCHAR(60)", "NOT NULL", "رمز المنتج الفريد"],
        ["name_ar", "VARCHAR(200)", "NOT NULL", "الاسم بالعربية"],
        ["name_en", "VARCHAR(200)", "NULL", "الاسم بالإنجليزية"],
        ["short_description", "VARCHAR(300)", "NULL", "وصف مختصر"],
        ["description", "TEXT", "NULL", "وصف كامل"],
        ["category_id", "BIGINT", "NOT NULL FK→categories(id)", "التصنيف"],
        ["brand_id", "BIGINT", "NULL FK→brands(id)", "العلامة"],
        ["base_unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة الأساسية للاحتساب"],
        ["tax_rate", "NUMERIC(5,2)", "NOT NULL DEFAULT 0", "نسبة الضريبة الافتراضية %"],
        ["cost_price", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "تكلفة مرجعية أولية"],
        ["default_sale_price", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "سعر البيع الافتراضي"],
        ["min_sale_price", "NUMERIC(18,4)", "NULL", "أدنى سعر مسموح — يقيّد الخصم ويستدعي الموافقة"],
        ["reorder_level", "NUMERIC(18,4)", "NULL", "حد إعادة الطلب — يشغّل تنبيه Low Stock"],
        ["max_stock_level", "NUMERIC(18,4)", "NULL", "الحد الأقصى المرغوب"],
        ["is_serialized", "BOOLEAN", "NOT NULL DEFAULT FALSE", "تتبع بالأرقام التسلسلية"],
        ["is_batch_tracked", "BOOLEAN", "NOT NULL DEFAULT FALSE", "تتبع بالدفعات"],
        ["is_expirable", "BOOLEAN", "NOT NULL DEFAULT FALSE", "له تاريخ صلاحية"],
        ["shelf_life_days", "INTEGER", "NULL", "عمر افتراضي بالأيام"],
        ["image_url", "TEXT", "NULL", "صورة المنتج — تخزين كائني"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["UNIQUE(company_id, sku, deleted_at)", "INDEX(category_id)", "INDEX(brand_id)", "INDEX(name_ar)"] },

    { name: "product_barcodes", title: "باركودات المنتجات", std: false,
      desc: "باركود متعدد لكل منتج، لكل باركود وحدة قراءة (قراءة كرتونة تحيل كمية كرتونة). يخدم الماسح الضوئي USB وكاميرا الهاتف والإدخال اليدوي مع بحث سريع جدًا.",
      fields: [
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["barcode", "VARCHAR(80)", "NOT NULL", "قيمة الباركود"],
        ["barcode_type", "VARCHAR(15)", "NOT NULL DEFAULT 'EAN13' CHECK (barcode_type IN ('EAN13','EAN8','UPC','CODE128','CODE39','CUSTOM'))", "النوع"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة التي يمثلها"],
        ["is_primary", "BOOLEAN", "NOT NULL DEFAULT FALSE", "الباركود الرئيسي"]
      ],
      indexes: ["UNIQUE(barcode)", "INDEX(product_id)"] },

    { name: "product_suppliers", title: "موردو المنتجات", std: false,
      desc: "ربط المنتج بمورديه المتعددين مع سعر شراء مرجعي ورمز المورد، ويحدد المورّد المفضل افتراضيًا عند توليد أوامر الشراء.",
      fields: [
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["supplier_id", "BIGINT", "NOT NULL FK→suppliers(id)", "المورد"],
        ["supplier_sku", "VARCHAR(60)", "NULL", "رمز المنتج عند المورد"],
        ["purchase_price", "NUMERIC(18,4)", "NULL", "آخر سعر شراء متفق"],
        ["currency_code", "CHAR(3)", "NULL", "عملة التعاقد إن اختلفت"],
        ["is_preferred", "BOOLEAN", "NOT NULL DEFAULT FALSE", "المورد المفضل"],
        ["lead_time_days", "SMALLINT", "NULL", "مدة التوريد المتوقعة"]
      ],
      indexes: ["UNIQUE(product_id, supplier_id)"] },

    { name: "price_lists", title: "قوائم الأسعار", std: true, scoped: true,
      desc: "القوائم: Retail, Wholesale, Dealer, VIP, Special بأولوية صريحة وفترة سريان. تُربط بمجموعات العملاء أو بالعملاء مباشرة، وتُطبَّق الأعلى أولوية ضمن الصالح زمنيًا عند التسعير.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["code", "VARCHAR(30)", "NOT NULL", "الرمز مثل WHS"],
        ["name", "VARCHAR(120)", "NOT NULL", "الاسم"],
        ["currency_code", "CHAR(3)", "NOT NULL DEFAULT 'IQD'", "عملة القائمة"],
        ["priority", "SMALLINT", "NOT NULL DEFAULT 100", "الأولوية — الأقل رقمًا أعلى"],
        ["valid_from", "DATE", "NULL", "بداية السريان"],
        ["valid_to", "DATE", "NULL", "نهاية السريان"],
        ["is_default", "BOOLEAN", "NOT NULL DEFAULT FALSE", "القائمة الافتراضية للشركة"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["UNIQUE(company_id, code, deleted_at)"] },

    { name: "price_list_items", title: "بنود قوائم الأسعار", std: false,
      desc: "سعر المنتج بالوحدة ضمن قائمة، مع حد أدنى للكمية يفعّل تسعير الكميات (كرتونة أرخص من قطعة). فترة سريان على مستوى البند تتجاوز الافتراضي عند الحاجة.",
      fields: [
        ["price_list_id", "BIGINT", "NOT NULL FK→price_lists(id)", "القائمة"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة"],
        ["price", "NUMERIC(18,4)", "NOT NULL CHECK (price >= 0)", "سعر الوحدة"],
        ["min_quantity", "NUMERIC(18,4)", "NOT NULL DEFAULT 1", "أدنى كمية لتفعيل السعر"],
        ["valid_from", "DATE", "NULL", "تجاوز بداية السريان"],
        ["valid_to", "DATE", "NULL", "تجاوز نهاية السريان"]
      ],
      indexes: ["UNIQUE(price_list_id, product_id, unit_id, min_quantity, valid_from)", "INDEX(product_id)"] },

    { name: "customer_product_prices", title: "أسعار العملاء الخاصة", std: false, scoped: true,
      desc: "أعلى طبقة تسعير: سعر تعاقدي لعميل محدد يتفوق على كل ما عداه. تُستخدم لعقود التجار الكبار والعروض الخاصة، وتظهر في B2B Portal كسعر العميل المعروض.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["customer_id", "BIGINT", "NOT NULL FK→customers(id)", "العميل"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة"],
        ["price", "NUMERIC(18,4)", "NOT NULL CHECK (price >= 0)", "السعر التعاقدي"],
        ["min_quantity", "NUMERIC(18,4)", "NOT NULL DEFAULT 1", "أدنى كمية"],
        ["valid_from", "DATE", "NULL", "بداية السريان"],
        ["valid_to", "DATE", "NULL", "نهاية السريان"]
      ],
      indexes: ["UNIQUE(customer_id, product_id, unit_id, min_quantity, valid_from)"] }
  ]
};

const D3_PARTIES = {
  id: "d3", no: "3", png: "erd_03_parties.png",
  title: "العملاء والموردون — بطاقات الأطراف وبياناتها",
  intro: [
    "يمثل هذا المجال طرفي المعاملة التجارية: العملاء والتجار من جهة والموردون من جهة أخرى. العميل يحمل المجموعة التي تحدد قائمة أسعاره، والمندوب المسؤول الذي يقتصر رؤيته على عملائه (مع نافذة صلاحية أوسع للمشرفين)، وحد الائتمان وشروط السداد اللذين يفحصهما محرك الائتمان عند كل فاتورة آجلة.",
    "أرصدة العملاء والموردين ليست أعمدة يُعدَّل يدويًا فحسب؛ بل قيم محفوظة cached تُشتق وتُطابق دائمًا مع دفاتر customer_ledger و supplier_ledger، وأي فتق بينهما يكشف خللاً — وهو ما تعتمده اختبارات سلامة البيانات.",
    "الإحداثيات الجغرافية للعميل وعناوينه المتعددة تخدم تطبيق المندوب (التنقل عبر المسارات) والتحقق من موقع الزيارة GPS."
  ],
  tables: [
    { name: "customer_groups", title: "مجموعات العملاء", std: true, scoped: true,
      desc: "تجميع العملاء لغرض التسعير والتحليل (تجار جملة، موزعون، قطاعي). المجموعة قد تحيل إلى قائمة أسعار افتراضية وتحمل نسبة خصم سقفية للتحقق عند الفوترة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["code", "VARCHAR(30)", "NOT NULL", "الرمز"],
        ["name", "VARCHAR(120)", "NOT NULL", "الاسم"],
        ["price_list_id", "BIGINT", "NULL FK→price_lists(id)", "قائمة الأسعار الافتراضية للمجموعة"],
        ["max_discount_percent", "NUMERIC(5,2)", "NULL", "سقف خصم المجموعة قبل استدعاء الموافقة"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["UNIQUE(company_id, code, deleted_at)"] },

    { name: "customers", title: "العملاء", std: true, scoped: true,
      desc: "بطاقة العميل/التاجر الكاملة مع الموقع الجغرافي والحد الائتماني. الرصيد الافتتاحي يُرحَّل آليًا كقيد OPENING في دفتر العميل عند التفعيل فلا يوجد رصيد بلا حركة موثقة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["code", "VARCHAR(40)", "NOT NULL", "كود العميل الفريد"],
        ["name", "VARCHAR(200)", "NOT NULL", "اسم العميل/المحل"],
        ["company_name", "VARCHAR(200)", "NULL", "اسم الشركة للتجار"],
        ["phone", "VARCHAR(30)", "NOT NULL", "الهاتف — مفتاح بحث رئيسي"],
        ["whatsapp", "VARCHAR(30)", "NULL", "رقم واتساب للتنبيهات"],
        ["email", "VARCHAR(160)", "NULL", "البريد"],
        ["address", "TEXT", "NULL", "العنوان النصي الرئيسي"],
        ["province", "VARCHAR(80)", "NULL", "المحافظة"],
        ["district", "VARCHAR(80)", "NULL", "القضاء/المنطقة"],
        ["latitude", "DECIMAL(10,7)", "NULL", "خط العرض للخرائط وزيارات GPS"],
        ["longitude", "DECIMAL(10,7)", "NULL", "خط الطول"],
        ["customer_group_id", "BIGINT", "NULL FK→customer_groups(id)", "المجموعة"],
        ["sales_rep_id", "BIGINT", "NULL FK→sales_reps(id)", "المندوب المسؤول — يحدد نطاق رؤية المندوب"],
        ["price_list_id", "BIGINT", "NULL FK→price_lists(id)", "قائمة أسعار خاصة تتفوق على المجموعة"],
        ["credit_limit", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "حد الائتمان — 0 يعني نقدًا فقط"],
        ["payment_term_days", "SMALLINT", "NOT NULL DEFAULT 0", "أجل السداد بالأيام"],
        ["opening_balance", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الرصيد الافتتاحي — يُرحَّل للدفتر آليًا"],
        ["current_balance", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الرصيد الجاري (مشتق ومطابق للدفتر)"],
        ["portal_user_id", "BIGINT", "NULL FK→b2b_portal_users(id)", "حساب البوابة إن وجد"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"],
        ["notes", "TEXT", "NULL", "ملاحظات"]
      ],
      indexes: ["UNIQUE(company_id, code, deleted_at)", "INDEX(phone)", "INDEX(sales_rep_id)", "INDEX(customer_group_id)"] },

    { name: "customer_contacts", title: "جهات اتصال العملاء", std: false,
      desc: "أشخاص التواصل داخل حساب العميل الواحد مع تمييز المسؤول الأساسي، وتخدم تنبيهات واتساب والبريد لاحقًا.",
      fields: [
        ["customer_id", "BIGINT", "NOT NULL FK→customers(id)", "العميل"],
        ["name", "VARCHAR(150)", "NOT NULL", "الاسم"],
        ["position", "VARCHAR(80)", "NULL", "الصفة/المسمى"],
        ["phone", "VARCHAR(30)", "NULL", "الهاتف"],
        ["email", "VARCHAR(160)", "NULL", "البريد"],
        ["is_primary", "BOOLEAN", "NOT NULL DEFAULT FALSE", "جهة التواصل الرئيسية"]
      ],
      indexes: ["INDEX(customer_id)"] },

    { name: "customer_addresses", title: "عناوين العملاء", std: false,
      desc: "عناوين متعددة للعميل (المستودع، المحل، المستودع الثاني) مع إحداثيات دقيقة تستخدمها مركبات التوصيل وتطبيق المندوب.",
      fields: [
        ["customer_id", "BIGINT", "NOT NULL FK→customers(id)", "العميل"],
        ["label", "VARCHAR(60)", "NOT NULL", "وسم العنوان مثل المستودع"],
        ["address", "TEXT", "NOT NULL", "النص الكامل"],
        ["district", "VARCHAR(80)", "NULL", "القضاء"],
        ["city", "VARCHAR(80)", "NULL", "المدينة"],
        ["latitude", "DECIMAL(10,7)", "NULL", "خط العرض"],
        ["longitude", "DECIMAL(10,7)", "NULL", "خط الطول"],
        ["is_default", "BOOLEAN", "NOT NULL DEFAULT FALSE", "العنوان الافتراضي للتوصيل"]
      ],
      indexes: ["INDEX(customer_id)"] },

    { name: "suppliers", title: "الموردون", std: true, scoped: true,
      desc: "بطاقة المورد بكشف حسابه المستقل supplier_ledger، وشروط سداد تُحسب لها الاستحقاقات Payables في التقارير المالية. الرصيد الافتتاحي يُرحَّل كقيد افتتاحي موثق كذلك.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["code", "VARCHAR(40)", "NOT NULL", "كود المورد"],
        ["name", "VARCHAR(200)", "NOT NULL", "الاسم"],
        ["company_name", "VARCHAR(200)", "NULL", "الشركة"],
        ["phone", "VARCHAR(30)", "NOT NULL", "الهاتف"],
        ["email", "VARCHAR(160)", "NULL", "البريد"],
        ["address", "TEXT", "NULL", "العنوان"],
        ["tax_number", "VARCHAR(60)", "NULL", "الرقم الضريبي"],
        ["payment_terms", "SMALLINT", "NOT NULL DEFAULT 0", "أجل التوريد بالأيام"],
        ["opening_balance", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الرصيد الافتتاحي"],
        ["current_balance", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الرصيد الجاري المستحق للمورد"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"],
        ["notes", "TEXT", "NULL", "ملاحظات"]
      ],
      indexes: ["UNIQUE(company_id, code, deleted_at)", "INDEX(phone)", "INDEX(name)"] }
  ]
};

module.exports = { D1_CORE, D2_PRODUCTS, D3_PARTIES };
