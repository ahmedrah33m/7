#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Post-process DOCX for WPS/Word compatibility (toc.md rules):
1. Remove empty <w:pgNumType/> from sections without pageNumbers
2. Patch footer PAGE instrText with explicit \\* ROMAN / \\* arabic switches
   by resolving footerReference per sectPr order.
3. Add <w:bidi/> to RTL section? (not needed; paragraphs carry bidi)
"""
import re, shutil, sys, zipfile, os, tempfile

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

def main(path):
    tmp = tempfile.mkdtemp()
    with zipfile.ZipFile(path) as z:
        z.extractall(tmp)

    doc_path = os.path.join(tmp, "word", "document.xml")
    rels_path = os.path.join(tmp, "word", "_rels", "document.xml.rels")
    with open(doc_path, encoding="utf-8") as f:
        doc = f.read()
    with open(rels_path, encoding="utf-8") as f:
        rels = f.read()

    # 1. remove empty pgNumType
    n_removed = len(re.findall(r"<w:pgNumType/>", doc))
    doc = doc.replace("<w:pgNumType/>", "")

    # map rId -> footer file
    rel_map = dict(re.findall(r'<Relationship[^>]*Id="([^"]+)"[^>]*Target="(footer\d+\.xml)"', rels))
    rel_map.update({m[0]: m[1] for m in re.findall(r'<Relationship[^>]*Target="(?:.*?)(footer\d+\.xml)"[^>]*Id="([^"]+)"', rels) and []})

    # find sectPr blocks in order, get their footerReference ids + pgNumType fmt
    sect_blocks = re.findall(r"<w:sectPr[ >].*?</w:sectPr>", doc, flags=re.S)
    fmt_by_footer = {}
    for sb in sect_blocks:
        m_fmt = re.search(r'<w:pgNumType[^>]*w:fmt="([^"]+)"', sb)
        fmt = m_fmt.group(1) if m_fmt else None
        for rid in re.findall(r'<w:footerReference[^>]*r:id="([^"]+)"', sb):
            fname = rel_map.get(rid)
            if fname:
                fmt_by_footer[fname] = fmt

    patched = []
    for fname, fmt in fmt_by_footer.items():
        fpath = os.path.join(tmp, "word", fname)
        if not os.path.exists(fpath):
            continue
        with open(fpath, encoding="utf-8") as f:
            fx = f.read()
        switch = "ROMAN" if fmt == "upperRoman" else ("roman" if fmt == "lowerRoman" else "arabic")
        fx2, n = re.subn(
            r"(<w:instrText[^>]*>)\s*PAGE\s*(</w:instrText>)",
            rf"\1 PAGE \\* {switch} \\* MERGEFORMAT \2",
            fx)
        if n:
            with open(fpath, "w", encoding="utf-8") as f:
                f.write(fx2)
            patched.append(f"{fname}->{switch}({n})")

    with open(doc_path, "w", encoding="utf-8") as f:
        f.write(doc)

    # rezip
    out = path
    tmpzip = path + ".tmp"
    with zipfile.ZipFile(tmpzip, "w", zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(tmp):
            for fn in files:
                full = os.path.join(root, fn)
                arc = os.path.relpath(full, tmp)
                z.write(full, arc)
    shutil.move(tmpzip, out)
    shutil.rmtree(tmp)
    print(f"OK: removed {n_removed} empty pgNumType; footers patched: {', '.join(patched) or 'none'}")

if __name__ == "__main__":
    main(sys.argv[1])
