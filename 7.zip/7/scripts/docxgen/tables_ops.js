// tables_ops.js — Domain groups 4,5,8,9: Stock, Movements, Purchasing, Finance

const D4_STOCK = {
  id: "d4", no: "4", png: "erd_04_stock.png",
  title: "المخزون — دفتر حركات المخزون والأرصدة",
  intro: [
    "هذا هو القلب المحاسبي للنظام: لا يتغير أي رصيد مخزني إلا بحركة موثقة في stock_transactions تحمل نوع الحركة والمرجع الذي سبّبها (فاتورة، استلام، تحويل، تسوية...)، فبإمكان أي رقم في أي تقرير أن يُتتبَّع رجوعًا إلى المستند المصدر — وهي القاعدة الذهبية في الوثيقة الأم.",
    "الدفتر Append-only: يُمنع التحديث والحذف على مستوى صلاحيات قاعدة البيانات بعد اعتماد الحركة. التصحيح يحدث دائمًا بعملية عكسية Reverse + حركة جديدة صحيحة، وتُستخدم REVERSAL كنوع مرجعي يحيل إلى الحركة الأصلية.",
    "stock_balances هو جدول الأداء المشدود بمجموعة فريدة UNIQUE(product_id, warehouse_id)، يُحدَّث حصريًا داخل نفس Transaction الوليدة للحركة وبقفل صفّي SELECT FOR UPDATE لمنع سباقات التزامن، والكمية المتاحة quantity_available عمود مولّد Generated = On Hand - Reserved."
  ],
  tables: [
    { name: "stock_transactions", title: "دفتر حركات المخزون (غير قابل للتعديل)", std: true, scoped: true,
      desc: "سجل كل حركة كمية بمعناها الاتجاهي: إشتراط المرجع reference_type + reference_id إجباري لكل صف (الاختبار الحرج 8)، وتحويل الوحدة إلى الوحدة الأساسية في quantity_base. التكلفة unit_cost تُلتقط لحظة الحركة لخدمة تكلفة المتوسط المرجح وتقارير الربحية.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "المستودع"],
        ["transaction_type", "VARCHAR(20)", "NOT NULL CHECK (IN ('PURCHASE_RECEIPT','SALE','SALE_RETURN','PURCHASE_RETURN','TRANSFER_OUT','TRANSFER_IN','ADJUSTMENT_IN','ADJUSTMENT_OUT','DAMAGE','OPENING'))", "نوع الحركة العشرة"],
        ["quantity", "NUMERIC(18,4)", "NOT NULL CHECK (quantity <> 0)", "الكمية بوحدة الحركة — موجب دائمًا مع إشارة الاتجاه محددة بالنوع"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "وحدة الحركة"],
        ["quantity_base", "NUMERIC(18,4)", "NOT NULL", "الكمية محولة للوحدة الأساسية (سالب للخروج)"],
        ["unit_cost", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "تكلفة الوحدة لحظة الحركة"],
        ["reference_type", "VARCHAR(30)", "NOT NULL", "نوع المستند المصدر مثل INVOICE / TRANSFER"],
        ["reference_id", "BIGINT", "NOT NULL", "معرف المستند المصدر"],
        ["batch_id", "BIGINT", "NULL FK→batches(id)", "الدفعة إن كان التتبع مفعّلًا"],
        ["serial_id", "BIGINT", "NULL FK→serials(id)", "الرقم التسلسلي للمنتجات المتسلسلة"],
        ["move_date", "TIMESTAMPTZ", "NOT NULL DEFAULT now()", "تاريخ الحركة الفعلي (قد يختلف عن الإنشاء)"],
        ["created_by", "BIGINT", "NULL FK→users(id)", "من نفّذ الحركة"]
      ],
      indexes: ["INDEX(product_id, warehouse_id, move_date)", "INDEX(reference_type, reference_id)", "INDEX(company_id, move_date)"],
      checks: "REVOKE UPDATE, DELETE على هذا الجدول عن كل أدوار التطبيق. القيد: reference_type + reference_id إجباريان." },

    { name: "stock_balances", title: "أرصدة المخزون (جدول الأداء)", std: false,
      desc: "الرصيد المجمّع لكل منتج/مستودع يُحدَّث ذريًا مع كل حركة. لا يعدّله أي مسار مباشر — قاعدة Rule 3 في الوثيقة — بل فقط ضمن معاملة الحركة، ويُسوّى بعملية Reconciliation دورية تقارنه بإجمالي الدفتر.",
      fields: [
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "المستودع"],
        ["quantity_on_hand", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الكمية الفعلية"],
        ["quantity_reserved", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "محجوزة لطلبات معتمدة غير منفذة"],
        ["quantity_available", "NUMERIC(18,4)", "GENERATED ALWAYS AS (quantity_on_hand - quantity_reserved) STORED", "المتاح — عمود محسوب"],
        ["avg_cost", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "تكلفة المتوسط المرجح للمستودع"],
        ["updated_at", "TIMESTAMPTZ", "NOT NULL DEFAULT now()", "آخر تحديث"]
      ],
      indexes: ["UNIQUE(product_id, warehouse_id)", "CHECK (quantity_on_hand >= 0 OR الشركة سمحت بالسالب في الإعدادات)"] },

    { name: "batches", title: "دفعات الإنتاج", std: false, scoped: true,
      desc: "تتبع الدفعات للمنتجات القابلة للتلف: رقم الدفعة وتاريخ الإنتاج والانتهاء، مع تنبيهات آلية قبل انتهاء الصلاحية بمدة قابلة للتهيئة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["batch_number", "VARCHAR(60)", "NOT NULL", "رقم الدفعة"],
        ["production_date", "DATE", "NULL", "تاريخ الإنتاج"],
        ["expiry_date", "DATE", "NULL", "تاريخ الانتهاء — يغذي تقرير التالف قبل الانتهاء"],
        ["quantity", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الكمية الحالية بالدفعة"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "موقع الدفعة"]
      ],
      indexes: ["UNIQUE(company_id, product_id, batch_number)", "INDEX(expiry_date) WHERE expiry_date IS NOT NULL"] },

    { name: "serials", title: "الأرقام التسلسلية", std: false, scoped: true,
      desc: "تتبع قطعة-بقطعة للمنتجات المكلفة؛ حالة الرقم تتحرك تلقائيًا مع حركات المخزون (IN_STOCK عند الاستلام، SOLD مع البيع، RETURNED مع المرتجع).",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["serial_number", "VARCHAR(80)", "NOT NULL", "الرقم التسلسلي"],
        ["status", "VARCHAR(15)", "NOT NULL DEFAULT 'IN_STOCK' CHECK (status IN ('IN_STOCK','SOLD','RETURNED','DAMAGED'))", "الحالة"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "الموقع الحالي"],
        ["last_reference_type", "VARCHAR(30)", "NULL", "آخر مستند مسّ الرقم"],
        ["last_reference_id", "BIGINT", "NULL", "معرفه"]
      ],
      indexes: ["UNIQUE(product_id, serial_number)", "INDEX(status)"] }
  ]
};

const D5_MOVEMENTS = {
  id: "d5", no: "5", png: "erd_05_movements.png",
  title: "حركات المخزون — التحويلات، التسويات، الجرد والتالف",
  intro: [
    "أربع مستندات تصف كل تغيير مخزني خارج البيع والشراء: التحويل بين مستودعين (وهو أسلوب تجهيز مخزن المندوب)، التسوية للأعلى أو للأسفل بسبب، الجرد الدوري بمطابقة العد الفعلي مع النظام، وإعدام التالف. لكل مستند رأس وبنود، وحالات آلة حالة تمنع القفز أو التكرار.",
    "الأثر المخزني يُكتب حصرًا عند الحالات التي تستوجبه: التحويل يخصم من المصدر عند ISSUED ويضيف للمستقبل عند RECEIVED (مرورًا اختياريًا بمستودع TRANSIT)، بينما تُرحَّل التسويات والجرد والتالف فور الاعتماد POSTED بحركات ADJUSTMENT_IN/OUT أو DAMAGE في الدفتر.",
    "كل هذه المستندات تحمل سببًا إجباريًا (reason) عند الحاجة — تطبيقًا للقاعدة Rule 8 — وتخضع لقواعد الموافقة المعرفة في approval_rules."
  ],
  tables: [
    { name: "transfers", title: "التحويلات بين المستودعات", std: true, scoped: true,
      desc: "آلة الحالة: DRAFT→REQUESTED→APPROVED→ISSUED→IN_TRANSIT→RECEIVED مع إلغاء مسموح قبل الإصدار فقط. منع الاستلام المزدوج مضمون بمنتقي الحالة (الاختبار الحرج 5 و16 في السيناريو القبولي).",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["transfer_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة TRF-2026-000001"],
        ["from_warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "المستودع المصدر"],
        ["to_warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "المستودع الهدف — غالبًا مخزن مندوب"],
        ["transit_warehouse_id", "BIGINT", "NULL FK→warehouses(id)", "مستودع العبور عند تفعيله"],
        ["status", "VARCHAR(15)", "NOT NULL DEFAULT 'DRAFT' CHECK (IN ('DRAFT','REQUESTED','APPROVED','ISSUED','IN_TRANSIT','RECEIVED','CANCELLED'))", "الحالة"],
        ["transfer_date", "DATE", "NOT NULL", "تاريخ التحويل"],
        ["driver_name", "VARCHAR(120)", "NULL", "السائق"],
        ["vehicle_number", "VARCHAR(40)", "NULL", "رقم المركبة"],
        ["requested_by", "BIGINT", "NOT NULL FK→users(id)", "مقدم الطلب"],
        ["approved_by", "BIGINT", "NULL FK→users(id)", "المعتمد"],
        ["issued_by / received_by", "BIGINT", "NULL FK→users(id)", "الساحب والمستلم"],
        ["issued_at / received_at", "TIMESTAMPTZ", "NULL", "أختام الحالتين"],
        ["notes", "TEXT", "NULL", "ملاحظات"]
      ],
      indexes: ["UNIQUE(company_id, transfer_number)", "INDEX(status)", "INDEX(to_warehouse_id, status)"],
      checks: "CHECK (from_warehouse_id <> to_warehouse_id). لا حركة TRANSFER_OUT دون حالة ISSUED." },

    { name: "transfer_items", title: "بنود التحويل", std: false,
      desc: "ثلاث كميات لكل بند: المطلوبة والمسحوبة والمستلمة، ما يسمح بعجز مقبول في الاستلام يوثَّق مع سببه.",
      fields: [
        ["transfer_id", "BIGINT", "NOT NULL FK→transfers(id) ON DELETE CASCADE", "التحويل"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة"],
        ["quantity_requested", "NUMERIC(18,4)", "NOT NULL CHECK (quantity_requested > 0)", "المطلوبة"],
        ["quantity_issued", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "المسحوبة فعليًا"],
        ["quantity_received", "NUMERIC(18,4)", "NOT NULL DEFAULT 0 CHECK (quantity_received <= quantity_issued)", "المستلمة — لا تجاوز للمسحوبة"],
        ["unit_cost", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "تكلفة الوحدة المرجعية"]
      ],
      indexes: ["INDEX(transfer_id)", "INDEX(product_id)"] },

    { name: "adjustments", title: "تسويات المخزون", std: true, scoped: true,
      desc: "زيادة أو نقصان بسببة موثقة (تلف جزئي، فرق قياس، هدية مورد...). كل تسوية POSTED تولّد ADJUSTMENT_IN أو ADJUSTMENT_OUT مع تسجيل من اعتمدها.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["adjustment_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة ADJ-2026-000001"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "المستودع"],
        ["adjustment_type", "VARCHAR(5)", "NOT NULL CHECK (adjustment_type IN ('IN','OUT'))", "الاتجاه"],
        ["status", "VARCHAR(18)", "NOT NULL DEFAULT 'DRAFT' CHECK (IN ('DRAFT','PENDING_APPROVAL','APPROVED','POSTED','REJECTED','CANCELLED'))", "الحالة"],
        ["adjustment_date", "DATE", "NOT NULL", "التاريخ"],
        ["reason", "TEXT", "NOT NULL", "السبب — إجباري (Rule 8)"],
        ["created_by", "BIGINT", "NOT NULL FK→users(id)", "المُنشئ"],
        ["approved_by", "BIGINT", "NULL FK→users(id)", "المعتمد — إجباري قبل POSTED"],
        ["approved_at", "TIMESTAMPTZ", "NULL", "وقت الاعتماد"]
      ],
      indexes: ["UNIQUE(company_id, adjustment_number)", "INDEX(warehouse_id, status)"] },

    { name: "adjustment_items", title: "بنود التسويات", std: false,
      desc: "الكمية المعدَّلة بالوحدة مع تكلفة الوحدة لتقييم الأثر المالي عند الزيادة، وسطر سبب تفصيلي عند الحاجة.",
      fields: [
        ["adjustment_id", "BIGINT", "NOT NULL FK→adjustments(id) ON DELETE CASCADE", "التسوية"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة"],
        ["quantity", "NUMERIC(18,4)", "NOT NULL CHECK (quantity > 0)", "الكمية المعدلة"],
        ["unit_cost", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "التكلفة المرجعية"],
        ["batch_id", "BIGINT", "NULL FK→batches(id)", "الدفعة عند التتبع"],
        ["note", "VARCHAR(300)", "NULL", "ملاحظة بند"]
      ],
      indexes: ["INDEX(adjustment_id)"] },

    { name: "stocktakings", title: "الجرد الدوري", std: true, scoped: true,
      desc: "جلسة جرد لمستودع كامل أو تصنيف منه: تُجمّد الحركات على النطاق أثناء العد أو تُسمح بسياسة اللمّا، ثم تُرحَّل فروق الجرد كتسويات آلية عند الاعتماد.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["stocktaking_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة STK-2026-000001"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "المستودع المجرود"],
        ["status", "VARCHAR(18)", "NOT NULL DEFAULT 'OPEN' CHECK (IN ('OPEN','COUNTING','PENDING_APPROVAL','APPROVED','POSTED','CANCELLED'))", "الحالة"],
        ["start_date", "DATE", "NOT NULL", "بداية الجرد"],
        ["end_date", "DATE", "NULL", "نهايته"],
        ["scope_category_id", "BIGINT", "NULL FK→categories(id)", "نطاق جزئي بتصنيف"],
        ["counted_by", "BIGINT", "NULL FK→users(id)", "لجنة العد"],
        ["approved_by", "BIGINT", "NULL FK→users(id)", "المعتمد"]
      ],
      indexes: ["UNIQUE(company_id, stocktaking_number)", "INDEX(warehouse_id, status)"] },

    { name: "stocktaking_items", title: "بنود الجرد", std: false,
      desc: "مطابقة الكمية النظامية لحظة الفتح مع العدّ الفعلي؛ الفرق يُحسب آليًا ويصبح بنود تسوية عند الاعتماد.",
      fields: [
        ["stocktaking_id", "BIGINT", "NOT NULL FK→stocktakings(id) ON DELETE CASCADE", "الجرد"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة"],
        ["system_quantity", "NUMERIC(18,4)", "NOT NULL", "رصيد النظام لحظة الفتح"],
        ["counted_quantity", "NUMERIC(18,4)", "NULL", "العد الفعلي"],
        ["difference", "NUMERIC(18,4)", "GENERATED ALWAYS AS (COALESCE(counted_quantity, system_quantity) - system_quantity) STORED", "الفرق المحسوب"],
        ["counted_by", "BIGINT", "NULL FK→users(id)", "من عدها"],
        ["counted_at", "TIMESTAMPTZ", "NULL", "وقت العد"]
      ],
      indexes: ["INDEX(stocktaking_id)"] },

    { name: "damages", title: "مستند التالف", std: true, scoped: true,
      desc: "إعدام كميات تالفة أو منتهية من المستودع إلى مستودع DAMAGED أو للخارج حسب السياسة، بحركات DAMAGE في الدفتر، مع رفع تنبيه التكلفة للإدارة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["damage_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة DMG-2026-000001"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "مستودع المصدر"],
        ["to_warehouse_id", "BIGINT", "NULL FK→warehouses(id)", "مستودع التالف عند النقل الداخلي"],
        ["status", "VARCHAR(18)", "NOT NULL DEFAULT 'DRAFT' CHECK (IN ('DRAFT','PENDING_APPROVAL','APPROVED','POSTED','CANCELLED'))", "الحالة"],
        ["damage_date", "DATE", "NOT NULL", "التاريخ"],
        ["reason", "TEXT", "NOT NULL", "السبب"],
        ["created_by", "BIGINT", "NOT NULL FK→users(id)", "المُنشئ"],
        ["approved_by", "BIGINT", "NULL FK→users(id)", "المعتمد"]
      ],
      indexes: ["UNIQUE(company_id, damage_number)"] },

    { name: "damage_items", title: "بنود التالف", std: false,
      desc: "الكمية المعدومة وحالتها وحكمها (إتلاف، إعادة تصنيع، خصم للموظف) لتوثيق مسار كل قطعة.",
      fields: [
        ["damage_id", "BIGINT", "NOT NULL FK→damages(id) ON DELETE CASCADE", "المستند"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة"],
        ["quantity", "NUMERIC(18,4)", "NOT NULL CHECK (quantity > 0)", "الكمية"],
        ["condition", "VARCHAR(12)", "NOT NULL CHECK (condition IN ('DAMAGED','EXPIRED','BROKEN'))", "طبيعة التلف"],
        ["unit_cost", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "قيمة الخسارة المرجعية"],
        ["batch_id", "BIGINT", "NULL FK→batches(id)", "الدفعة"],
        ["disposition", "VARCHAR(120)", "NULL", "المصير النهائي"]
      ],
      indexes: ["INDEX(damage_id)"] }
  ]
};

const D8_PURCHASING = {
  id: "d8", no: "6", png: "erd_08_purchasing.png",
  title: "المشتريات — دورة الشراء حتى السداد",
  intro: [
    "دورة الشراء الكاملة: أمر شراء → استلام → فاتورة مورد → دفعة، مع قاعدة فاصلة: المخزون لا يزيد عند إنشاء أمر الشراء ولا عند فاتورة المورد، بل حصرًا عند ترحيل سند الاستلام بحركة PURCHASE_RECEIPT — تطبيقًا حرفيًا لقسم 27 من الوثيقة.",
    "الاستلام يسمح بقبول ورفض جزئي لكل بند (كميات مقبولة/مرفوضة) مع تسجيل الدفعة وتاريخ الصلاحية للمنتجات المتبعة، ويحدّث آليًا qty_received في أمر الشراء لحساب حالة التنفيذ الجزئي PARTIALLY_RECEIVED.",
    "فاتورة المورد تُنشأ يدويًا أو تُولّد من الاستلام، وتصبح هدفًا للتوزيع في payment_allocations عند سداد الدفعات الخارجة، فتُغذّى تقارير الدائنون Payables مباشرة من supplier_ledger."
  ],
  tables: [
    { name: "purchase_orders", title: "أوامر الشراء", std: true, scoped: true,
      desc: "رأس أمر الشراء بحالاته السبع، مع مورّد ومستودع وجهة، ولا أثر مخزني أو مالي عند إنشائه.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["po_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة PO-2026-000001"],
        ["supplier_id", "BIGINT", "NOT NULL FK→suppliers(id)", "المورد"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "مستودع الاستلام المتوقع"],
        ["status", "VARCHAR(20)", "NOT NULL DEFAULT 'DRAFT' CHECK (IN ('DRAFT','PENDING','APPROVED','CONFIRMED','PARTIALLY_RECEIVED','RECEIVED','CANCELLED'))", "الحالة"],
        ["order_date", "DATE", "NOT NULL", "تاريخ الأمر"],
        ["expected_date", "DATE", "NULL", "التاريخ المتوقع للتوريد"],
        ["subtotal / discount_amount / tax_amount / total", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الإجماليات المحسوبة عند الترحيل"],
        ["currency_code", "CHAR(3)", "NOT NULL DEFAULT 'IQD'", "عملة الأمر"],
        ["created_by", "BIGINT", "NOT NULL FK→users(id)", "المُنشئ"],
        ["approved_by", "BIGINT", "NULL FK→users(id)", "المعتمد"],
        ["notes", "TEXT", "NULL", "ملاحظات"]
      ],
      indexes: ["UNIQUE(company_id, po_number)", "INDEX(supplier_id, status)"] },

    { name: "purchase_order_items", title: "بنود أوامر الشراء", std: false,
      desc: "الكمية والسعر بالوحدة مع تحديث آلي للمستلم منها عند كل استلام، ومنع استلام أكثر من المأمور به إلا بمستند إضافي.",
      fields: [
        ["po_id", "BIGINT", "NOT NULL FK→purchase_orders(id) ON DELETE CASCADE", "الأمر"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة"],
        ["quantity", "NUMERIC(18,4)", "NOT NULL CHECK (quantity > 0)", "الكمية المأمورة"],
        ["quantity_received", "NUMERIC(18,4)", "NOT NULL DEFAULT 0 CHECK (quantity_received <= quantity)", "المستلم تراكميًا"],
        ["unit_cost", "NUMERIC(18,4)", "NOT NULL CHECK (unit_cost >= 0)", "تكلفة الوحدة"],
        ["discount_percent", "NUMERIC(5,2)", "NOT NULL DEFAULT 0", "خصم البند"],
        ["tax_rate", "NUMERIC(5,2)", "NOT NULL DEFAULT 0", "ضريبة البند"],
        ["line_total", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "إجمالي السطر"]
      ],
      indexes: ["INDEX(po_id)", "INDEX(product_id)"] },

    { name: "purchase_receipts", title: "سندات الاستلام", std: true, scoped: true,
      desc: "اللحظة الوحيدة التي يزيد فيها المخزون: POSTED يكتب PURCHASE_RECEIPT ويحدّث stock_balances وavg_cost داخل معاملة واحدة، ويحدّث حالة أمر الشراء تلقائيًا.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["receipt_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة RCPT-2026-000001"],
        ["po_id", "BIGINT", "NULL FK→purchase_orders(id)", "الأمر المرجعي (NULL لاستلام مباشر مسموح مفعّلًا)"],
        ["supplier_id", "BIGINT", "NOT NULL FK→suppliers(id)", "المورد"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "مستودع الاستلام"],
        ["status", "VARCHAR(12)", "NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','POSTED','CANCELLED'))", "الحالة"],
        ["receipt_date", "DATE", "NOT NULL", "تاريخ الاستلام"],
        ["delivery_note_no", "VARCHAR(60)", "NULL", "رقم بوليصة التسليم"],
        ["created_by", "BIGINT", "NOT NULL FK→users(id)", "المستلم"],
        ["posted_at", "TIMESTAMPTZ", "NULL", "ختم الترحيل"],
        ["notes", "TEXT", "NULL", "ملاحظات"]
      ],
      indexes: ["UNIQUE(company_id, receipt_number)", "INDEX(po_id)", "INDEX(supplier_id)"] },

    { name: "purchase_receipt_items", title: "بنود الاستلام", std: false,
      desc: "قبول/رفض لكل بند مع بيانات الدفعة والصلاحية إجبارية للمنتجات المتبعة، والرفض يوثَّق بسببه ولا يدخل المخزون.",
      fields: [
        ["receipt_id", "BIGINT", "NOT NULL FK→purchase_receipts(id) ON DELETE CASCADE", "السند"],
        ["po_item_id", "BIGINT", "NULL FK→purchase_order_items(id)", "بند الأمر المرجعي"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة"],
        ["quantity_accepted", "NUMERIC(18,4)", "NOT NULL CHECK (quantity_accepted >= 0)", "المقبول — يدخل المخزون"],
        ["quantity_rejected", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "المرفوض مع سببه"],
        ["reject_reason", "VARCHAR(300)", "NULL", "سبب الرفض"],
        ["unit_cost", "NUMERIC(18,4)", "NOT NULL", "تكلفة القبول النهائية"],
        ["batch_number", "VARCHAR(60)", "NULL", "رقم الدفعة الواردة"],
        ["expiry_date", "DATE", "NULL", "الصلاحية الواردة"]
      ],
      indexes: ["INDEX(receipt_id)", "INDEX(product_id)"] },

    { name: "supplier_invoices", title: "فواتير الموردين", std: true, scoped: true,
      desc: "المستند المالي لالتزام الشراء: يُرحَّل في supplier_ledger مدينًا للمورد، وتُغطى لاحقًا بدفعات موزعة. الأرصدة المستحقة تتغذى منه مباشرة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["supplier_invoice_number", "VARCHAR(60)", "NOT NULL", "رقم فاتورة المورد كما وردت"],
        ["internal_number", "VARCHAR(30)", "NOT NULL", "رقم داخلي SIN-2026-000001"],
        ["supplier_id", "BIGINT", "NOT NULL FK→suppliers(id)", "المورد"],
        ["po_id", "BIGINT", "NULL FK→purchase_orders(id)", "الأمر"],
        ["receipt_id", "BIGINT", "NULL FK→purchase_receipts(id)", "الاستلام"],
        ["invoice_date", "DATE", "NOT NULL", "تاريخ الفاتورة"],
        ["due_date", "DATE", "NULL", "الاستحقاق"],
        ["subtotal / tax_amount / total", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الإجماليات"],
        ["paid_amount", "NUMERIC(18,4)", "NOT NULL DEFAULT 0 CHECK (paid_amount <= total + 0.0001)", "المسدد تراكميًا"],
        ["status", "VARCHAR(15)", "NOT NULL DEFAULT 'UNPAID' CHECK (IN ('UNPAID','PARTIALLY_PAID','PAID','CANCELLED'))", "الحالة المالية"],
        ["created_by", "BIGINT", "NOT NULL FK→users(id)", "المُنشئ"]
      ],
      indexes: ["UNIQUE(company_id, supplier_id, supplier_invoice_number)", "INDEX(supplier_id, status)", "INDEX(due_date)"] },

    { name: "purchase_returns", title: "مرتجعات المشتريات", std: true, scoped: true,
      desc: "إعادة بضاع للمورد من ضمن مستند استلام، تخصم المخزون بحركة PURCHASE_RETURN عند الترحيل وتخفض رصيد المورد عند الإشعارات.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["return_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة PRET-2026-000001"],
        ["supplier_id", "BIGINT", "NOT NULL FK→suppliers(id)", "المورد"],
        ["receipt_id", "BIGINT", "NULL FK→purchase_receipts(id)", "الاستلام الأصلي"],
        ["warehouse_id", "BIGINT", "NOT NULL FK→warehouses(id)", "مستودع الخروج"],
        ["status", "VARCHAR(12)", "NOT NULL DEFAULT 'REQUESTED' CHECK (IN ('REQUESTED','APPROVED','SENT','POSTED','REJECTED','CANCELLED'))", "الحالة"],
        ["return_date", "DATE", "NOT NULL", "التاريخ"],
        ["reason", "TEXT", "NOT NULL", "السبب"],
        ["created_by / approved_by", "BIGINT", "FK→users(id)", "المنشئ والمعتمد"]
      ],
      indexes: ["UNIQUE(company_id, return_number)", "INDEX(supplier_id)"] },

    { name: "purchase_return_items", title: "بنود مرتجعات المشتريات", std: false,
      desc: "الكمية المرتجعة بتكلفتها الأصلية لتصحيح متوسط التكلفة عند الحاجة.",
      fields: [
        ["return_id", "BIGINT", "NOT NULL FK→purchase_returns(id) ON DELETE CASCADE", "المرتجع"],
        ["product_id", "BIGINT", "NOT NULL FK→products(id)", "المنتج"],
        ["unit_id", "BIGINT", "NOT NULL FK→units(id)", "الوحدة"],
        ["quantity", "NUMERIC(18,4)", "NOT NULL CHECK (quantity > 0)", "الكمية"],
        ["unit_cost", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "تكلفة الإرجاع"],
        ["batch_id", "BIGINT", "NULL FK→batches(id)", "الدفعة"],
        ["reason", "VARCHAR(300)", "NULL", "سبب البند"]
      ],
      indexes: ["INDEX(return_id)"] }
  ]
};

const D9_FINANCE = {
  id: "d9", no: "7", png: "erd_09_finance.png",
  title: "المالية — الصناديق، الحسابات البنكية والمصروفات",
  intro: [
    "الخزينة في النظام على نوعين: صناديق نقدية cashboxes (رئيسية/فرع/مندوب) وحسابات بنكية bank_accounts، وكلاهما يعمل بمنطق الدفتر اللاتحققي: كل تغيير رصيد حركة IN/OUT موثقة بمرجعها (دفعة عميل، مصروف، تحويل خزينة...) مع balance_after اللحظي للتدقيق السريع.",
    "المعادلة المقننة Closing = Opening + In - Out تُطبَّق في تقارير الصندوق اليومية، وأي فتق بين مجموع الحركات والرصيد المخزن يُصنَّف خطأً حرجًا تلتقطه اختبارات السلامة.",
    "المصروفات تمر بآلة موافقة: ينشئ الموظف المسودة، والقواعد الرقمية في approval_rules (مثل مصروف أكبر من 500,000) تحولها تلقائيًا إلى PENDING_APPROVAL، ولا يُخصم الصندوق إلا عند الاعتماد والدفع."
  ],
  tables: [
    { name: "cashboxes", title: "الصناديق النقدية", std: true, scoped: true,
      desc: "صندوق لكل مستوى (MAIN/BRANCH/REP) بأمين محدد، ويُمنع حذف صندوق عليه حركات — يُعطَّل فقط.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["branch_id", "BIGINT", "NULL FK→branches(id)", "الفرع (NULL للرئيسي)"],
        ["code", "VARCHAR(30)", "NOT NULL", "الرمز"],
        ["name", "VARCHAR(120)", "NOT NULL", "الاسم"],
        ["type", "VARCHAR(10)", "NOT NULL CHECK (type IN ('MAIN','BRANCH','REP'))", "النوع"],
        ["custodian_id", "BIGINT", "NULL FK→users(id)", "أمين الصندوق"],
        ["opening_balance", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الافتتاحي — يرحَّل كحركة OPENING"],
        ["current_balance", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الرصيد الجاري (مشتق)"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["UNIQUE(company_id, code, deleted_at)"] },

    { name: "cashbox_transactions", title: "حركات الصناديق (لاتحققي)", std: false,
      desc: "كل داخلة/خارجة بمرجعها الحتمي وبalance_after. التحويل بين صندوقين يكتب قيدين متقابلين بنفس مرجع التحويل فيمنع الاختلال المزدوج.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["cashbox_id", "BIGINT", "NOT NULL FK→cashboxes(id)", "الصندوق"],
        ["txn_type", "VARCHAR(12)", "NOT NULL CHECK (IN ('OPENING','IN','OUT','TRANSFER_IN','TRANSFER_OUT'))", "النوع"],
        ["amount", "NUMERIC(18,4)", "NOT NULL CHECK (amount > 0)", "المبلغ موجب دائمًا"],
        ["balance_after", "NUMERIC(18,4)", "NOT NULL", "الرصيد بعد الحركة"],
        ["reference_type", "VARCHAR(30)", "NOT NULL", "المصدر: PAYMENT/EXPENSE/TRANSFER..."],
        ["reference_id", "BIGINT", "NOT NULL", "معرف المصدر"],
        ["description", "VARCHAR(300)", "NULL", "وصف"],
        ["txn_date", "TIMESTAMPTZ", "NOT NULL DEFAULT now()", "وقت الحركة"],
        ["created_by", "BIGINT", "NULL FK→users(id)", "المنفذ"]
      ],
      indexes: ["INDEX(cashbox_id, txn_date)", "INDEX(reference_type, reference_id)"],
      checks: "REVOKE UPDATE/DELETE — دفتر لاتحققي بالكامل." },

    { name: "bank_accounts", title: "الحسابات البنكية", std: true, scoped: true,
      desc: "حسابات الشركة البنكية المستخدمة في تحويلات العملاء وسداد الموردين، بعملة الحساب ورصيد جاري مشتق.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["bank_name", "VARCHAR(120)", "NOT NULL", "اسم البنك"],
        ["account_name", "VARCHAR(150)", "NOT NULL", "اسم الحساب"],
        ["account_number", "VARCHAR(60)", "NOT NULL", "رقم الحساب"],
        ["iban", "VARCHAR(40)", "NULL", "الآيبان"],
        ["currency_code", "CHAR(3)", "NOT NULL DEFAULT 'IQD'", "العملة"],
        ["current_balance", "NUMERIC(18,4)", "NOT NULL DEFAULT 0", "الرصيد الجاري"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["UNIQUE(company_id, account_number, deleted_at)"] },

    { name: "bank_transactions", title: "حركات البنوك (لاتحققي)", std: false,
      desc: "مرآة كشف الحساب: كل دفعة بنكية أو خصم رسوم سطر موثق بمرجعه، ويُسوّى مع كشف البنك شهريًا عبر حالة مطابقة.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["bank_account_id", "BIGINT", "NOT NULL FK→bank_accounts(id)", "الحساب"],
        ["txn_type", "VARCHAR(5)", "NOT NULL CHECK (txn_type IN ('IN','OUT'))", "الاتجاه"],
        ["amount", "NUMERIC(18,4)", "NOT NULL CHECK (amount > 0)", "المبلغ"],
        ["balance_after", "NUMERIC(18,4)", "NULL", "الرصيد بعد الحركة"],
        ["reference_type", "VARCHAR(30)", "NOT NULL", "المصدر"],
        ["reference_id", "BIGINT", "NOT NULL", "معرف المصدر"],
        ["txn_date", "TIMESTAMPTZ", "NOT NULL DEFAULT now()", "الوقت"],
        ["notes", "VARCHAR(300)", "NULL", "ملاحظات"]
      ],
      indexes: ["INDEX(bank_account_id, txn_date)"] },

    { name: "expense_categories", title: "تصنيفات المصروفات", std: true, scoped: true,
      desc: "شجرة مسطحة لتصنيف المصروفات (إيجار، وقود، عمولات...) مع علم إجبار الموافقة على مستوى التصنيف.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["code", "VARCHAR(30)", "NOT NULL", "الرمز"],
        ["name", "VARCHAR(120)", "NOT NULL", "الاسم"],
        ["requires_approval", "BOOLEAN", "NOT NULL DEFAULT TRUE", "إجبار الموافقة دائمًا"],
        ["is_active", "BOOLEAN", "NOT NULL DEFAULT TRUE", "الحالة"]
      ],
      indexes: ["UNIQUE(company_id, code, deleted_at)"] },

    { name: "expenses", title: "المصروفات", std: true, scoped: true,
      desc: "المستند المالي للمصروف: يسحب من صندوق أو حساب محدد عند الدفع، ويولّد حركة OUT بالمرجع، والمرفق (صورة سند) في التخزين الكائني عبر attachments.",
      fields: [
        ["company_id", "BIGINT", "NOT NULL FK→companies(id)", "نطاق المستأجر"],
        ["expense_number", "VARCHAR(30)", "NOT NULL", "الرقم بصيغة EXP-2026-000001"],
        ["category_id", "BIGINT", "NOT NULL FK→expense_categories(id)", "التصنيف"],
        ["branch_id", "BIGINT", "NULL FK→branches(id)", "الفرع"],
        ["warehouse_id", "BIGINT", "NULL FK→warehouses(id)", "مستودع مرتبط إن وجد"],
        ["amount", "NUMERIC(18,4)", "NOT NULL CHECK (amount > 0)", "المبلغ"],
        ["payment_method", "VARCHAR(15)", "NOT NULL CHECK (IN ('CASH','BANK_TRANSFER','CARD'))", "طريقة الدفع"],
        ["cashbox_id", "BIGINT", "NULL FK→cashboxes(id)", "الصندوق المصدر للنقدية"],
        ["bank_account_id", "BIGINT", "NULL FK→bank_accounts(id)", "الحساب المصدر للتحويل"],
        ["expense_date", "DATE", "NOT NULL", "التاريخ"],
        ["description", "TEXT", "NOT NULL", "الوصف"],
        ["status", "VARCHAR(18)", "NOT NULL DEFAULT 'DRAFT' CHECK (IN ('DRAFT','PENDING_APPROVAL','APPROVED','PAID','REJECTED','CANCELLED'))", "الحالة"],
        ["created_by", "BIGINT", "NOT NULL FK→users(id)", "المُنشئ"],
        ["approved_by", "BIGINT", "NULL FK→users(id)", "المعتمد"]
      ],
      indexes: ["UNIQUE(company_id, expense_number)", "INDEX(status)", "INDEX(category_id, expense_date)"] }
  ]
};

module.exports = { D4_STOCK, D5_MOVEMENTS, D8_PURCHASING, D9_FINANCE };
