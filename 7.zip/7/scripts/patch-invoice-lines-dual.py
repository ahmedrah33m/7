# جراحة أسطر شاملة: بنود الفاتورة الجديدة (كراتين + حبات بسعرين مستقلين وإجمالي واحد)
P = "/home/z/my-project/src/components/sales/new-invoice-tab.tsx"
src = open(P, encoding="utf-8").read()
n0 = len(src)

def rep(old, new, tag):
    global src
    assert src.count(old) == 1, f"[{tag}] anchor count = {src.count(old)}"
    src = src.replace(old, new)
    print(f"  ✓ {tag}")

# ---- 1) نموذج البند: كرتون + حبات + سعران -----------------------------------
rep('''interface Line {
  key: number;
  product_id: number | "";
  qty: number | "";         // الكمية المدخلة
  unit: "PIECE" | "PACKAGE"; // وحدة الكمية — قائمة داخل الخانة للمنتجات المعبأة
  price: number | "";       // حسب الأساس
  price_basis: "PIECE" | "PACKAGE";
  discount_pct: number | "";
  discount_amount: number | "";
}

const emptyLine = (key: number): Line => ({
  key, product_id: "", qty: "", unit: "PIECE", price: "", price_basis: "PIECE", discount_pct: "", discount_amount: "",
});''',
'''interface Line {
  key: number;
  product_id: number | "";
  pkg_qty: number | "";      // عدد الكراتين/العبوات الكاملة
  loose_qty: number | "";    // عدد الحبات/العلب/الأكياس المفردة (وحدة المنتج الأساسية)
  pack_price: number | "";   // سعر الكرتونة — يُملأ تلقائيًا من المنتج وقابل للتعديل
  piece_price: number | "";  // سعر الحبة/الوحدة الأساسية — يُملأ تلقائيًا وقابل للتعديل
  discount_pct: number | "";
  discount_amount: number | "";
}

// الإجمالي = (كراتين × سعر الكرتونة) + (حبات × سعر الحبة) − الخصومات
const emptyLine = (key: number): Line => ({
  key, product_id: "", pkg_qty: "", loose_qty: "", pack_price: "", piece_price: "", discount_pct: "", discount_amount: "",
});''', "Line-model")

# ---- 2) القارئ: حمولة إعادة الطلب تشمل package_price -------------------------
rep('''        lines: { product_id: string; product_id_num: number | null; package_qty: number; loose_qty: number; qty: number; unit_price: number; discount_pct: number }[];''',
'''        lines: { product_id: string; product_id_num: number | null; package_qty: number; loose_qty: number; qty: number; unit_price: number; package_price: number | null; discount_pct: number }[];''', "clone-payload-type")

rep('''      // البنود: حل المنتج بالكود أو المعرف + تعبئة العبوات/الحبات/السعر
      const newLines: Line[] = [];
      let key = keyRef.current;
      for (const cl of payload.lines) {
        const p =
          products.find((x) => x.code === cl.product_id) ??
          (cl.product_id_num ? products.find((x) => x.id === cl.product_id_num) : undefined);
        if (!p) continue;
        const hasPackRow = !!p.pack_unit && !!p.pack_qty && Number(p.pack_qty) > 1;
        key = keyRef.current++;
        if (hasPackRow && cl.package_qty > 0 && cl.loose_qty === 0) {
          // الكمية الأصلية بالعبوات — تُستعاد كما هي
          newLines.push({ key, product_id: p.id, qty: cl.package_qty, unit: "PACKAGE", price: cl.unit_price || "", price_basis: "PACKAGE", discount_pct: cl.discount_pct || "", discount_amount: "" });
        } else if (hasPackRow) {
          // مزيج عبوات+حبات أو حبات فقط — تُستعاد كحبات إجمالية بلا لبس
          const totalPieces = Number(p.pack_qty) * cl.package_qty + cl.loose_qty;
          newLines.push({ key, product_id: p.id, qty: totalPieces, unit: "PIECE", price: cl.unit_price || "", price_basis: "PIECE", discount_pct: cl.discount_pct || "", discount_amount: "" });
        } else {
          newLines.push({ key, product_id: p.id, qty: cl.qty, unit: "PIECE", price: cl.unit_price || "", price_basis: "PIECE", discount_pct: cl.discount_pct || "", discount_amount: "" });
        }
      }''',
'''      // البنود: حل المنتج بالكود أو المعرف + استعادة الكرتون والحبات والسعرين
      const newLines: Line[] = [];
      let key = keyRef.current;
      for (const cl of payload.lines) {
        const p =
          products.find((x) => x.code === cl.product_id) ??
          (cl.product_id_num ? products.find((x) => x.id === cl.product_id_num) : undefined);
        if (!p) continue;
        key = keyRef.current++;
        const hasPackRow = !!p.pack_unit && !!p.pack_qty && Number(p.pack_qty) > 1;
        const pieceDef = p.sale_price;
        const packDef = hasPackRow
          ? (p.pack_sale_price != null ? Number(p.pack_sale_price) : Math.round(Number(p.pack_qty) * pieceDef * 100) / 100)
          : "";
        if (hasPackRow) {
          // unit_price المخزن = سعر الحبة دائمًا (§تخزين الخادم) — package_price سعر الكرتونة
          newLines.push({
            key, product_id: p.id,
            pkg_qty: cl.package_qty > 0 ? cl.package_qty : "",
            loose_qty: cl.loose_qty > 0 ? cl.loose_qty : "",
            pack_price: cl.package_qty > 0 ? (cl.package_price ?? packDef) : (packDef as number | ""),
            piece_price: cl.unit_price || pieceDef,
            discount_pct: cl.discount_pct || "", discount_amount: "",
          });
        } else {
          newLines.push({
            key, product_id: p.id,
            pkg_qty: "",
            loose_qty: (cl.qty || cl.loose_qty || ""),
            pack_price: "",
            piece_price: cl.unit_price || pieceDef,
            discount_pct: cl.discount_pct || "", discount_amount: "",
          });
        }
      }''', "clone-builder")

# ---- 3) المساعدات: hasPack عامة + إجمالي خام + سعر كرتونة افتراضي -----------
rep('''  const productById = (id: number | "") => (id === "" ? undefined : products.find((p) => p.id === Number(id)));
  const hasPack = (l: Line) => {
    const p = productById(l.product_id);
    return !!p?.pack_unit && !!p?.pack_qty && Number(p.pack_qty) > 1;
  };
  const packQtyOf = (l: Line) => Number(productById(l.product_id)?.pack_qty ?? 1);
  const packSalePriceOf = (l: Line): number | null => {
    const p = productById(l.product_id);
    return p?.pack_sale_price != null ? Number(p.pack_sale_price) : null;
  };

  // سعر الحبة/العبوة الفعليين للسطر (محاكاة منطق الخادم §18/§19)
  function linePrices(l: Line): { piecePrice: number; pkgPrice: number | null } {
    const p = productById(l.product_id);
    if (!p) return { piecePrice: 0, pkgPrice: null };
    const entered = num(l.price);
    if (!hasPack(l)) return { piecePrice: entered || p.sale_price, pkgPrice: null };
    const pkgDefault = packSalePriceOf(l) ?? Math.round(packQtyOf(l) * p.sale_price * 100) / 100;
    if (l.price_basis === "PACKAGE") {
      return { piecePrice: p.sale_price, pkgPrice: entered || pkgDefault };
    }
    return { piecePrice: entered || p.sale_price, pkgPrice: pkgDefault };
  }

  function baseQty(l: Line): number {
    if (!hasPack(l)) return decNum(qtyR(dec(l.qty)));
    const q = l.unit === "PACKAGE"
      ? qtyR(dec(l.qty).mul(packQtyOf(l)))
      : qtyR(dec(l.qty));
    return decNum(q);
  }

  // Phase 3: حساب السلة عبر Decimal — ممنوع float في الحساب المالي
  function lineTotal(l: Line): number {
    const { piecePrice, pkgPrice } = linePrices(l);
    const gross = hasPack(l)
      ? (l.unit === "PACKAGE" ? dec(l.qty).mul(pkgPrice ?? 0) : dec(l.qty).mul(piecePrice))
      : dec(l.qty).mul(piecePrice);
    const after = gross.mul(new Decimal(1).minus(dec(l.discount_pct).div(100))).minus(dec(l.discount_amount));
    return decNum(Decimal.max(new Decimal(0), moneyR(after)));
  }''',
'''  const productById = (id: number | "") => (id === "" ? undefined : products.find((p) => p.id === Number(id)));
  const productHasPack = (p?: ProductRow) => !!p?.pack_unit && !!p?.pack_qty && Number(p.pack_qty) > 1;
  const hasPack = (l: Line) => productHasPack(productById(l.product_id));
  const packQtyOf = (l: Line) => Number(productById(l.product_id)?.pack_qty ?? 1);
  const packSalePriceOf = (l: Line): number | null => {
    const p = productById(l.product_id);
    return p?.pack_sale_price != null ? Number(p.pack_sale_price) : null;
  };
  // سعر الكرتونة الافتراضي من المنتج (للتعبئة التلقائية عند اختيار منتج)
  const packDefaultOf = (p: ProductRow): number | "" =>
    productHasPack(p)
      ? (p.pack_sale_price != null ? Number(p.pack_sale_price) : Math.round(Number(p.pack_qty) * p.sale_price * 100) / 100)
      : "";

  // الإجمالي الخام للسطر (محاكاة الخادم §18/§19): كراتين×سعر الكرتونة + حبات×سعر الحبة
  // كل كتابة تحسب لحالها — وإن كُتب الاثنان اجتمعا في إجمالي واحد
  function lineGross(l: Line): Decimal {
    const p = productById(l.product_id);
    if (!p) return dec(0);
    const pk = productHasPack(p) ? dec(num(l.pkg_qty)).mul(num(l.pack_price)) : dec(0);
    const ls = dec(num(l.loose_qty)).mul(num(l.piece_price));
    return pk.plus(ls);
  }

  function baseQty(l: Line): number {
    const p = productById(l.product_id);
    if (!p) return 0;
    if (!productHasPack(p)) return decNum(qtyR(dec(l.loose_qty)));
    return decNum(qtyR(dec(num(l.pkg_qty)).mul(Number(p.pack_qty)).plus(dec(l.loose_qty))));
  }

  // Phase 3: حساب السلة عبر Decimal — ممنوع float في الحساب المالي
  function lineTotal(l: Line): number {
    const after = lineGross(l).mul(new Decimal(1).minus(dec(l.discount_pct).div(100))).minus(dec(l.discount_amount));
    return decNum(Decimal.max(new Decimal(0), moneyR(after)));
  }''', "helpers")

# ---- 4) setLine: تعبئة السعرين تلقائيًا عند اختيار المنتج --------------------
rep('''        const next = { ...l, ...patch };
        if (patch.product_id !== undefined) {
          const p = productById(patch.product_id);
          next.price_basis = "PIECE";
          next.price = p ? p.sale_price : "";
          next.qty = "";
          next.unit = "PIECE";
          next.discount_pct = "";
          next.discount_amount = "";
          schedulePreviewRefresh();
        }
        return next;''',
'''        const next = { ...l, ...patch };
        if (patch.product_id !== undefined) {
          const p = productById(patch.product_id);
          next.piece_price = p ? p.sale_price : "";
          next.pack_price = p ? packDefaultOf(p) : "";
          next.pkg_qty = "";
          next.loose_qty = "";
          next.discount_pct = "";
          next.discount_amount = "";
          schedulePreviewRefresh();
        }
        return next;''', "setLine-prefill")

# ---- 5) إجمالي الفاتورة الفرعي ----------------------------------------------
rep('''  const subtotal = decNum(moneyR(sumOf(lines, (l) => {
    const { piecePrice, pkgPrice } = linePrices(l);
    return hasPack(l)
      ? (l.unit === "PACKAGE" ? dec(l.qty).mul(pkgPrice ?? 0) : dec(l.qty).mul(piecePrice))
      : dec(l.qty).mul(piecePrice);
  })));''',
'''  const subtotal = decNum(moneyR(sumOf(lines, (l) => decNum(lineGross(l)))));''', "subtotal")

# ---- 6) الباركود: كل مسح = حبة على بند المنتج نفسه ---------------------------
rep('''    const existing = lines.find((l) => l.product_id === p.id);
    if (existing) {
      if (hasPack(existing) && existing.unit === "PACKAGE") {
        // مسح قطعة إضافية على بند مُدخل بالكراتين → التحويل لحبات لتفادي اللبس
        const total = num(existing.qty) * packQtyOf(existing) + 1;
        setLine(existing.key, { unit: "PIECE", price_basis: "PIECE", qty: total });
      } else {
        setLine(existing.key, { qty: num(existing.qty) + 1 });
      }
    } else {
      const empty = lines.find((l) => l.product_id === "");
      if (empty) setLine(empty.key, { product_id: p.id, price: p.sale_price });
      else {
        setLines((ls) => [...ls, { key: keyRef.current++, product_id: p.id, qty: 1, unit: "PIECE" as const, price: p.sale_price, price_basis: "PIECE" as const, discount_pct: "", discount_amount: "" }]);
        schedulePreviewRefresh();
      }
    }''',
'''    const existing = lines.find((l) => l.product_id === p.id);
    if (existing) {
      // كل مسح = حبة واحدة إضافية على بند المنتج نفسه (الحبات خانة مستقلة عن الكراتين)
      setLine(existing.key, { loose_qty: num(existing.loose_qty) + 1 });
    } else {
      const empty = lines.find((l) => l.product_id === "");
      if (empty) {
        setLine(empty.key, { product_id: p.id });
        setLines((ls) => ls.map((x) => (x.key === empty.key ? { ...x, loose_qty: 1 } : x)));
        schedulePreviewRefresh();
      } else {
        setLines((ls) => [...ls, { key: keyRef.current++, product_id: p.id, pkg_qty: "", loose_qty: 1, pack_price: packDefaultOf(p), piece_price: p.sale_price, discount_pct: "", discount_amount: "" }]);
        schedulePreviewRefresh();
      }
    }''', "barcode")

# ---- 7) طباعة المسودة: أعمدة الكرتون والحبات والسعرين ------------------------
rep('''    const rows = filled.map((l) => {
      const p = productById(l.product_id)!;
      const { piecePrice, pkgPrice } = linePrices(l);
      const isPkg = hasPack(l) && l.unit === "PACKAGE";
      const qtyTxt = isPkg
        ? `${l.qty} ${unitCount(num(l.qty), p.pack_unit)} (${baseQty(l)} ${p.unit})`
        : `${l.qty} ${unitCount(num(l.qty), p.unit)}`;
      const priceTxt = money(isPkg ? (pkgPrice ?? 0) : piecePrice);
      const discTxt = [l.discount_pct ? `${l.discount_pct}%` : "", l.discount_amount ? money(num(l.discount_amount)) : ""].filter(Boolean).join(" + ") || "—";
      return `<tr><td>${p.name}<div class="dim">${p.code}${p.pack_unit && p.pack_qty ? ` · ${p.pack_unit} = ${Number(p.pack_qty)} ${p.unit}` : ""}</div></td><td>${qtyTxt}</td><td>${priceTxt}</td><td>${discTxt}</td><td class="b">${money(lineTotal(l))}</td></tr>`;
    }).join("");''',
'''    const rows = filled.map((l) => {
      const p = productById(l.product_id)!;
      const parts: string[] = [];
      if (num(l.pkg_qty) > 0) parts.push(qtyWord(num(l.pkg_qty), p.pack_unit));
      if (num(l.loose_qty) > 0) parts.push(qtyWord(num(l.loose_qty), p.unit));
      const qtyTxt = parts.join(" + ") || "—";
      const discTxt = [l.discount_pct ? `${l.discount_pct}%` : "", l.discount_amount ? money(num(l.discount_amount)) : ""].filter(Boolean).join(" + ") || "—";
      const packPriceTxt = productHasPack(p) ? money(num(l.pack_price)) : "—";
      return `<tr><td>${p.name}<div class="dim">${p.code}${p.pack_unit && p.pack_qty ? ` · ${p.pack_unit} = ${Number(p.pack_qty)} ${p.unit}` : ""}</div></td><td>${qtyTxt}</td><td>${packPriceTxt}</td><td>${money(num(l.piece_price))}</td><td>${discTxt}</td><td class="b">${money(lineTotal(l))}</td></tr>`;
    }).join("");''', "print-rows")

rep('''    <table><thead><tr><th>المنتج</th><th>الكمية</th><th>السعر</th><th>الخصم</th><th>الإجمالي</th></tr></thead><tbody>${rows}</tbody></table>''',
'''    <table><thead><tr><th>المنتج</th><th>الكمية</th><th>سعر الكرتونة</th><th>سعر الحبة</th><th>الخصم</th><th>الإجمالي</th></tr></thead><tbody>${rows}</tbody></table>''', "print-header")

# ---- 8) الإرسال: package_qty + loose_qty + السعرين ---------------------------
rep('''    const validLines = lines
      .filter((l) => l.product_id !== "")
      .map((l) => {
        if (hasPack(l)) {
          const v = num(l.qty);
          return {
            product_id: Number(l.product_id),
            package_qty: l.unit === "PACKAGE" ? v : 0,
            loose_qty: l.unit === "PACKAGE" ? 0 : v,
            unit_price: l.price === "" ? undefined : Number(l.price),
            price_unit: l.price_basis,
            discount_pct: l.discount_pct === "" ? undefined : Number(l.discount_pct),
            discount_amount: l.discount_amount === "" ? undefined : Number(l.discount_amount),
          };
        }
        return {
          product_id: Number(l.product_id),
          qty: num(l.qty),
          unit_price: l.price === "" ? undefined : Number(l.price),
          discount_pct: l.discount_pct === "" ? undefined : Number(l.discount_pct),
          discount_amount: l.discount_amount === "" ? undefined : Number(l.discount_amount),
        };
      })
      .filter((l) => (l as { package_qty?: number; loose_qty?: number; qty?: number }).package_qty! + (l as { loose_qty?: number }).loose_qty! > 0 || (l as { qty?: number }).qty! > 0);''',
'''    const validLines = lines
      .filter((l) => l.product_id !== "")
      .map((l) => ({
        product_id: Number(l.product_id),
        package_qty: hasPack(l) ? num(l.pkg_qty) : 0,
        loose_qty: num(l.loose_qty),
        package_price: hasPack(l) && l.pack_price !== "" ? Number(l.pack_price) : undefined,
        piece_price: l.piece_price === "" ? undefined : Number(l.piece_price),
        discount_pct: l.discount_pct === "" ? undefined : Number(l.discount_pct),
        discount_amount: l.discount_amount === "" ? undefined : Number(l.discount_amount),
      }))
      .filter((l) => l.package_qty! + l.loose_qty > 0);''', "submit-lines")

open(P, "w", encoding="utf-8").write(src)
print(f"new-invoice-tab.tsx ✓ (8 تعديلات) — {n0} → {len(src)} حرفًا")
