#!/usr/bin/env python3
# =====================================================================
# Phase 6 — فحص قاعدة البيانات للبوابة (Migration + Backup/Restore)
#   migrate: تحقق أن كل جداول @@map في المخطط موجودة + integrity_check
#   backup : نسخة احتياطية + تحقق سلامتها + تطابق عدد صفوف الجداول المفتاحية
# =====================================================================
import sqlite3, sys, re, shutil, os, datetime

ROOT = "/home/z/my-project"
DB = os.path.join(ROOT, "db/custom.db")
SCHEMA = os.path.join(ROOT, "prisma/schema.prisma")

KEY_TABLES = [
    "companies", "users", "products", "sales_invoices", "sales_invoice_lines",
    "stock_movements", "cost_layers", "delivery_notes", "delivery_note_lines",
    "cash_transactions",
]

def open_ro(path):
    # readonly URI يضمن عدم المساس بالقاعدة الحية
    return sqlite3.connect(f"file:{path}?mode=ro", uri=True)

def migrate():
    schema = open(SCHEMA, encoding="utf-8").read()
    maps = re.findall(r'@@map\("([^"]+)"\)', schema)
    con = open_ro(DB)
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    missing = [t for t in maps if t not in tables]
    integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
    con.close()
    if missing:
        print(f"جداول ناقصة: {', '.join(missing)}"); sys.exit(1)
    if integrity != "ok":
        print(f"integrity_check: {integrity}"); sys.exit(1)
    print(f"{len(maps)} جدولاً موجودة · integrity ok")

def backup():
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    bdir = os.path.join(ROOT, "backups/phase6")
    os.makedirs(bdir, exist_ok=True)
    target = os.path.join(bdir, f"gate-backup-{stamp}.db")
    shutil.copy2(DB, target)
    live = open_ro(DB)
    copy = open_ro(target)
    integrity = copy.execute("PRAGMA integrity_check").fetchone()[0]
    if integrity != "ok":
        print(f"النسخة الاحتياطية تالفة: {integrity}"); sys.exit(1)
    diffs = []
    for t in KEY_TABLES:
        a = live.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        b = copy.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        if a != b:
            diffs.append(f"{t}: live={a} backup={b}")
    live.close(); copy.close()
    if diffs:
        print("عدم تطابق الصفوف: " + " · ".join(diffs)); sys.exit(1)
    print(f"{len(KEY_TABLES)} جداول متطابقة → {os.path.basename(target)}")

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "migrate"
    (migrate if mode == "migrate" else backup)()
