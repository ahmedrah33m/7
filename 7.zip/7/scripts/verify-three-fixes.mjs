// =====================================================================
// verify-three-fixes.mjs — تحقق تكاملي للتعديلات الثلاثة (2026-09-18)
// 1) فصل شعار النظام عن شعار الشركة (SystemBrand مستقل عن Company.logoUrl)
// 2) لا زر طي في الهيدر (الطي/التوسيع من داخل القائمة الجانبية فقط)
// 3) لا اسم مستخدم/شركة/زر خروج في أسفل القائمة الجانبية
// =====================================================================
import { chromium } from "playwright";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const results = [];
function check(name, ok, extra = "") {
  results.push(`${ok ? "✓" : "✗"} ${name}${extra ? " — " + extra : ""}`);
  if (!ok) process.exitCode = 1;
}

async function jfetch(path, { method = "GET", token, body, form } = {}) {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body) headers["Content-Type"] = "application/json";
  const res = await fetch(BASE + path, { method, headers, body: form ?? (body ? JSON.stringify(body) : undefined) });
  let json = null;
  try { json = await res.json(); } catch {}
  return { res, json };
}

// ---------- توليد PNG مميزين (أحمر للنظام، أزرق للشركة) عبر canvas ----------
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: "ar" });
const page = await ctx.newPage();
const pngB64 = (color) => page.evaluate((c) => {
  const cv = document.createElement("canvas"); cv.width = 64; cv.height = 64;
  const x = cv.getContext("2d"); x.fillStyle = c; x.fillRect(0, 0, 64, 64);
  return cv.toDataURL("image/png").split(",")[1];
}, color);
const redPng = Buffer.from(await pngB64("#dc2626"), "base64");
const bluePng = Buffer.from(await pngB64("#2563eb"), "base64");

async function uploadLogo(path, token, buf, fname) {
  const fd = new FormData();
  fd.append("file", new Blob([buf], { type: "image/png" }), fname);
  const res = await fetch(BASE + path, { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: fd });
  let json = null; try { json = await res.json(); } catch {}
  return { res, json };
}

// ---------- 0) تنظيف أي بقايا سابقة + دخول المالك ----------
const login = await jfetch("/api/v1/auth/login", { method: "POST", body: { username: "admin", password: "Admin@123" } });
const token = login.json?.data?.access_token;
check("دخول admin ناجح", !!token, login.json?.message ?? "");
check("صلاحية system.settings.edit ممنوحة للمالك", (login.json?.data?.permissions ?? []).includes("system.settings.edit"));

if (token) {
  // تنظيف قبل البدء (تجاهل الفشل — قد لا يوجد شعار)
  await jfetch("/api/v1/admin/system-logo", { method: "DELETE", token }).catch(() => {});
  await jfetch("/api/v1/admin/company-logo", { method: "DELETE", token }).catch(() => {});

  const br0 = await jfetch("/api/v1/branding");
  check("الحالة الابتدائية: /branding بلا شعار نظام", br0.json?.data?.logo_url === null, JSON.stringify(br0.json?.data));

  // ---------- 1) فصل الشعارين — طبقة API ----------
  const upSys = await uploadLogo("/api/v1/admin/system-logo", token, redPng, "system-logo.png");
  check("رفع شعار النظام → 200", upSys.res.status === 200 && upSys.json?.success, upSys.json?.message ?? "");
  const sysFile = upSys.json?.data?.file?.name ?? "";
  check("شعار النظام يُخزن كملف مستقل", !!sysFile, sysFile);

  const br1 = await jfetch("/api/v1/branding");
  check("/branding يعيد شعار النظام + إصدار", br1.json?.data?.logo_url != null && !!br1.json?.data?.logo_version, JSON.stringify(br1.json?.data));

  const sysBytes = await fetch(BASE + "/api/v1/branding/logo");
  const sysBuf = Buffer.from(await sysBytes.arrayBuffer());
  check("/branding/logo يقدم بايتات شعار النظام (الأحمر)", sysBytes.status === 200 && Buffer.compare(sysBuf, redPng) === 0, `ct=${sysBytes.headers.get("content-type")}`);

  const upCo = await uploadLogo("/api/v1/admin/company-logo", token, bluePng, "company-logo.png");
  check("رفع شعار الشركة → 200", upCo.res.status === 200 && upCo.json?.success, upCo.json?.message ?? "");
  const coFile = upCo.json?.data?.file?.name ?? "";
  const coUrl = upCo.json?.data?.logo_url ?? "";
  check("شعار الشركة مخزن في ملف مختلف عن شعار النظام", !!coFile && coFile !== sysFile, `${coFile} ≠ ${sysFile}`);

  const sysBytes2 = await fetch(BASE + "/api/v1/branding/logo");
  const sysBuf2 = Buffer.from(await sysBytes2.arrayBuffer());
  check("الجوهر: رفع شعار الشركة لم يغيّر شعار النظام (لا يزال الأحمر)", sysBytes2.status === 200 && Buffer.compare(sysBuf2, redPng) === 0);

  const me = await jfetch("/api/v1/auth/me", { token });
  const scopeCo = (me.json?.data?.scope?.companies ?? []).find((c) => c.id === me.json?.data?.company?.id);
  check("شعار الشركة ظاهر في scope عبر /me (وليس في /branding)", !!scopeCo?.logo_url, scopeCo?.logo_url ?? "null");

  // ---------- 2) واجهة: الهيدر + القائمة الجانبية ----------
  await page.goto(BASE + "/", { waitUntil: "networkidle" });
  // تسجيل دخول عبر الواجهة إن ظهرت شاشة الدخول
  if (await page.locator("input").count() >= 2 && !(await page.locator("aside").count())) {
    await page.locator("input").first().fill("admin");
    await page.locator('input[type="password"]').fill("Admin@123");
    await page.getByRole("button", { name: /دخول/ }).click();
    await page.waitForSelector("aside", { timeout: 20000 }).catch(() => {});
  }
  check("اللوحة ظاهرة (aside)", await page.locator("aside").count() > 0);

  const header = page.locator("header");
  const headerCollapseBtns = await header.getByRole("button", { name: /طي القائمة/ }).count();
  check("الجوهر: لا زر طي في الهيدر", headerCollapseBtns === 0, `عدد أزرار الطي في header = ${headerCollapseBtns}`);

  const aside = page.locator("aside").first();
  const asideCollapseBtn = await aside.getByRole("button", { name: "طي القائمة الجانبية" }).count();
  check("زر الطي موجود داخل القائمة الجانبية نفسها", asideCollapseBtn >= 1);

  // الطي/التوسيع فعلياً
  const w0 = (await aside.boundingBox())?.width ?? 0;
  await aside.getByRole("button", { name: "طي القائمة الجانبية" }).first().click();
  await page.waitForTimeout(400);
  const w1 = (await aside.boundingBox())?.width ?? 0;
  check("الطي يعمل من داخل القائمة (256→68)", w0 > 200 && w1 < 90, `${w0}px → ${w1}px`);
  // التوسيع بالنقر على شعار الشركة عند الطي
  await aside.locator("button").first().click();
  await page.waitForTimeout(400);
  const w2 = (await aside.boundingBox())?.width ?? 0;
  check("التوسيع بالنقر على الشعار يعمل", w2 > 200, `${w2}px`);

  const asideLogout = await aside.getByRole("button", { name: /خروج/ }).count();
  check("الجوهر: لا زر خروج في أسفل القائمة الجانبية", asideLogout === 0, `عدد = ${asideLogout}`);
  const asideText = await aside.innerText();
  check("الجوهر: لا اسم مستخدم في القائمة الجانبية", !asideText.includes("@admin") && !asideText.includes("@" + "admin"), "");
  check("الجوهر: لا شريحة انتماء شركة/فرع في ذيل القائمة", !asideText.includes("جلسة عملك"), "");

  // شعار النظام في الهيدر بعد الرفع (تحديث فوري عبر حدث أو إعادة تحميل)
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForTimeout(800);
  const headerSysLogo = await header.locator('img[alt="شعار النظام"]').count();
  check("الهيدر يعرض شعار النظام (img[alt=شعار النظام])", headerSysLogo >= 1);
  const headerSrc = await header.locator('img[alt="شعار النظام"]').first().getAttribute("src").catch(() => "");
  check("شعار الهيدر يأتي من /branding/logo (النظام)", !!headerSrc && headerSrc.includes("/branding/logo"), headerSrc ?? "");

  const asideCoLogo = await aside.locator('img[alt="شعار الشركة"]').count();
  const asideCoSrc = asideCoLogo ? await aside.locator('img[alt="شعار الشركة"]').first().getAttribute("src") : "";
  check("القائمة الجانبية تعرض شعار الشركة (الأزرق) من /files", asideCoLogo >= 1 && asideCoSrc.includes("/api/v1/files/"), asideCoSrc ?? "لا يوجد");
  check("الجوهر: مصدرا الشعارين مختلفان فعلاً", !!headerSrc && headerSrc.includes("/branding/logo") && !!asideCoSrc && asideCoSrc.includes("/api/v1/files/"));

  // شاشة الدخول تعرض شعار النظام فقط
  await page.evaluate(() => { localStorage.removeItem("maydan.sidebar.collapsed"); });
  await ctx.clearCookies();
  const loginPage = await ctx.newPage();
  await loginPage.goto(BASE + "/", { waitUntil: "networkidle" });
  await loginPage.waitForTimeout(600);
  const loginSysLogo = await loginPage.locator('img[alt="شعار النظام"]').count();
  check("شاشة الدخول تعرض شعار النظام", loginSysLogo >= 1);
  await loginPage.screenshot({ path: "/home/z/my-project/download/verify3-login-system-logo.png", fullPage: true });
  await loginPage.close();

  await page.screenshot({ path: "/home/z/my-project/download/verify3-dashboard-two-logos.png", fullPage: false });

  // ---------- 3) تنظيف كامل ----------
  const rmSys = await jfetch("/api/v1/admin/system-logo", { method: "DELETE", token });
  check("إزالة شعار النظام → 200", rmSys.res.status === 200, rmSys.json?.message ?? "");
  const rmCo = await jfetch("/api/v1/admin/company-logo", { method: "DELETE", token });
  check("إزالة شعار الشركة → 200", rmCo.res.status === 200, rmCo.json?.message ?? "");
  const brEnd = await jfetch("/api/v1/branding");
  check("النهاية: /branding فارغ (لا سقوط لشعار الشركة فيه)", brEnd.json?.data?.logo_url === null, JSON.stringify(brEnd.json?.data));
  const logo404 = await fetch(BASE + "/api/v1/branding/logo");
  check("النهاية: /branding/logo → 404", logo404.status === 404, `status=${logo404.status}`);
} else {
  check("لا يمكن المتابعة بدون توكن", false);
}

await browser.close();
console.log("\n=== نتائج التحقق (التعديلات الثلاثة) ===");
console.log(results.join("\n"));
const pass = results.filter((r) => r.startsWith("✓")).length;
console.log(`\nالمجموع: ${pass}/${results.length} ناجح`);
