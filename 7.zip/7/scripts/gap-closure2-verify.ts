// =====================================================================
// Gap-closure II acceptance suite (Task 23) — 4 features:
//   §27 purchase returns (stock OUT at cost + supplier relief + cash IN)
//   §41 approval engine (discount / expense / credit-exceeded triggers)
//   §8  multiple barcodes (add / dup / search / delete)
//   §14 stock reservation (order confirm reserves, cancel releases,
//       convert releases+deducts, direct sale blocked STOCK_002)
// Exit 0 = all pass.
// =====================================================================

import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000/api/v1";
const db = new PrismaClient();

let pass = 0;
let fail = 0;

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  ✅ ${name}`);
  } else {
    fail++;
    console.log(`  ❌ ${name} ${detail ? "— " + detail : ""}`);
  }
}

async function req(method: string, path: string, token?: string, body?: unknown): Promise<{ status: number; body: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json };
}

async function main() {
  console.log("═══ Gap-closure II verification (§27 / §41 / §8 / §14) ═══");

  // 0) logins
  const admin = await req("POST", "/auth/login", undefined, { username: "admin", password: "Admin@123" });
  check("admin login", admin.status === 200 && admin.body.success);
  const T = admin.body.data?.access_token as string;

  const cashier = await req("POST", "/auth/login", undefined, { username: "cashier", password: "Cashier@123" });
  check("cashier login", cashier.status === 200);
  const CT = cashier.body.data?.access_token as string;

  const me = await req("GET", "/auth/me", T);
  const WH_MAIN: number = me.body.data?.warehouses?.[0]?.id ?? 1;
  check("warehouse scope readable", typeof WH_MAIN === "number");

  const cashboxes0 = await req("GET", "/finance/cashboxes", T);
  const cashboxId0 = (cashboxes0.body.data ?? [])[0]?.id as number;

  // fresh fixtures — a dedicated supplier + product, self-provisioned stock
  const stamp = Date.now().toString().slice(-8);
  const sup = await req("POST", "/suppliers", T, { name: `مورد اختبار الإغلاق ${stamp}`, phone: "07700000000" });
  const supplierId = sup.body.data?.id as number;
  check("fixture supplier created", sup.status === 201 || sup.status === 200, JSON.stringify(sup.body).slice(0, 120));
  const supplierBalance = () => db.supplier.findFirst({ where: { id: supplierId } }).then((s) => s?.balance ?? 0);
  const supBefore0 = await supplierBalance();

  const prod = await req("POST", "/products", T, {
    code: `P-GC2-${stamp}`, name: `منتج اختبار الإغلاق ${stamp}`, cost_price: 2000, sale_price: 3500, tax_rate_pct: 0,
  });
  const productId = prod.body.data?.id as number;
  check("fixture product created", prod.status === 201 || prod.status === 200, JSON.stringify(prod.body).slice(0, 120));

  const purQty = 20;
  const purchase = await req("POST", "/purchases/invoices", T, {
    supplier_id: supplierId, warehouse_id: WH_MAIN, type: "CREDIT",
    lines: [{ product_id: productId, qty: purQty, unit_cost: 2000 }],
  });
  const purchaseId = purchase.body.data?.id as number;
  check("fixture purchase invoice (20 × 2000 = 40000)", purchase.status === 201, JSON.stringify(purchase.body).slice(0, 140));
  const purchaseLine = await db.purchaseInvoiceLine.findFirst({ where: { invoiceId: purchaseId, productId } });
  check("purchase line resolvable", !!purchaseLine?.id);

  const supBefore = await supplierBalance();
  check("supplier payable = 40000 after credit purchase", supBefore === 40000, `balance=${supBefore}`);

  // ═══════════════════════ §27 PURCHASE RETURNS ═══════════════════════
  console.log("── §27 مرتجع الشراء ──");

  const balAfterPurchase = (await req("GET", `/inventory/balances?warehouse_id=${WH_MAIN}&per_page=300`, T))
    .body.data?.find((b: any) => b.product_id === productId)?.qty ?? 0;

  const pret = await req("POST", "/purchases/returns", T, {
    supplier_id: supplierId, warehouse_id: WH_MAIN, purchase_invoice_id: purchaseId,
    cashbox_id: cashboxId0, refund_cash: 4000,
    lines: [{ purchase_line_id: purchaseLine?.id, product_id: productId, qty: 5, unit_cost: 2000 }],
  });
  check("purchase return 201 (5 × 2000 = 10000)", pret.status === 201, JSON.stringify(pret.body).slice(0, 160));
  check("return total = 10000", pret.body.data?.total_amount === 10000);
  check("refund_cash = 4000 / credit_note = 6000", pret.body.data?.refund_cash === 4000 && pret.body.data?.credit_note === 6000);
  const pretNumber: string = pret.body.data?.number ?? "";
  check("numbering PRET-YYYY-NNNNNN", /^PRET-\d{4}-\d{6}$/.test(pretNumber), pretNumber);

  const balAfterReturn = (await req("GET", `/inventory/balances?warehouse_id=${WH_MAIN}&per_page=300`, T))
    .body.data?.find((b: any) => b.product_id === productId)?.qty ?? 0;
  check("stock OUT 5 (balance − 5)", balAfterReturn === balAfterPurchase - 5, `${balAfterPurchase} → ${balAfterReturn}`);

  const mv = await db.stockMovement.findFirst({
    where: { productId, refType: "PURCHASE_RETURN" }, orderBy: { id: "desc" },
  });
  check("movement row refType=PURCHASE_RETURN OUT cost=2000", mv?.direction === "OUT" && Number(mv?.unitCost) === 2000);

  const supAfter = await supplierBalance();
  check("supplier payable −6000 (credit note)", supAfter === supBefore - 6000, `${supBefore} → ${supAfter}`);

  const cashRows = await db.cashTransaction.findFirst({
    where: { refType: "PURCHASE_RETURN", supplierId, direction: "IN" }, orderBy: { id: "desc" },
  });
  check("cash IN refund row 4000 documented", Number(cashRows?.amount) === 4000 && cashRows?.direction === "IN");

  // R1 — over-return blocked (linked to the purchase line → remaining = 15)
  const over = await req("POST", "/purchases/returns", T, {
    supplier_id: supplierId, warehouse_id: WH_MAIN, purchase_invoice_id: purchaseId,
    cashbox_id: cashboxId0, refund_cash: 0,
    lines: [{ purchase_line_id: purchaseLine?.id, product_id: productId, qty: 16, unit_cost: 2000 }],
  });
  check("over-return beyond purchased blocked VAL_001", over.status === 422, `status=${over.status} code=${over.body.code}`);

  // permission barrier — cashier has no purchasing.purchase_returns.create
  const pretNoPerm = await req("POST", "/purchases/returns", CT, {
    supplier_id: supplierId, warehouse_id: WH_MAIN, refund_cash: 0, lines: [{ product_id: productId, qty: 1, unit_cost: 2000 }],
  });
  check("cashier blocked PERM_001 (403)", pretNoPerm.status === 403 && pretNoPerm.body.code === "PERM_001", `status=${pretNoPerm.status}`);

  const pretList = await req("GET", "/purchases/returns", T);
  check("returns ledger GET 200 + row present", pretList.status === 200 && (pretList.body.data ?? []).some((r: any) => r.number === pretNumber));

  // ═══════════════════════ §8 MULTIPLE BARCODES ═══════════════════════
  console.log("── §8 تعدد الباركودات ──");

  const bc1 = await req("POST", `/products/${productId}/barcodes`, T, { barcode: `GC2-ALT-${stamp}`, qty_factor: 1 });
  check("add secondary barcode 201", bc1.status === 201, JSON.stringify(bc1.body).slice(0, 120));
  const bc2 = await req("POST", `/products/${productId}/barcodes`, T, { barcode: `GC2-CTN-${stamp}`, qty_factor: 12, note: "كرتون" });
  check("add carton barcode (×12) 201", bc2.status === 201);

  const dup = await req("POST", `/products/${productId}/barcodes`, T, { barcode: `GC2-ALT-${stamp}` });
  check("duplicate barcode blocked VAL_002 409", dup.status === 409, `status=${dup.status}`);

  const bcList = await req("GET", `/products/${productId}/barcodes`, T);
  check("barcode list has 2 rows", bcList.status === 200 && bcList.body.data?.length === 2);

  const searchByAlt = await req("GET", `/products?q=GC2-CTN-${stamp}`, T);
  check("product search by secondary barcode finds product", searchByAlt.status === 200 && (searchByAlt.body.data ?? []).some((p: any) => p.id === productId));

  const delBc = await req("DELETE", `/products/${productId}/barcodes/${bc2.body.data?.id}`, T);
  check("delete barcode 200", delBc.status === 200);
  const bcListAfter = await req("GET", `/products/${productId}/barcodes`, T);
  check("list back to 1", bcListAfter.body.data?.length === 1);

  const bcNoPerm = await req("POST", `/products/${productId}/barcodes`, CT, { barcode: `GC2-X-${stamp}` });
  check("cashier blocked PERM_001 (403) on barcode create", bcNoPerm.status === 403);

  // ═══════════════════════ §14 STOCK RESERVATION ═══════════════════════
  console.log("── §14 حجز المخزون ──");

  // order for ALL remaining stock → confirmed → fully reserved
  const custRes = await req("POST", "/customers", T, {
    name: `عميل حجز ${stamp}`, credit_limit: 0, credit_days: 0,
  });
  const customerId = custRes.body.data?.id ?? custRes.body.data?.customer?.id;
  check("fixture customer created", !!customerId, JSON.stringify(custRes.body).slice(0, 120));

  const onHandNow = (await req("GET", `/inventory/balances?warehouse_id=${WH_MAIN}&per_page=300`, T))
    .body.data?.find((b: any) => b.product_id === productId)?.qty ?? 0;

  // order for ALL remaining stock → confirmed → fully reserved
  const order = await req("POST", "/sales/orders", T, {
    customer_id: customerId, warehouse_id: WH_MAIN,
    lines: [{ product_id: productId, qty: onHandNow, unit_price: 3500 }],
  });
  const orderId = order.body.data?.id;
  check("order created (DRAFT)", order.status === 201 || order.status === 200, JSON.stringify(order.body).slice(0, 140));

  const conf = await req("POST", `/sales/orders/${orderId}/confirm`, T);
  check("order confirmed → reservation made", conf.status === 200, JSON.stringify(conf.body).slice(0, 120));

  const reservedRow = (await req("GET", `/inventory/balances?warehouse_id=${WH_MAIN}&per_page=300`, T))
    .body.data?.find((b: any) => b.product_id === productId);
  check("balance exposes qty_reserved = on-hand", Number(reservedRow?.qty_reserved) === onHandNow, `reserved=${reservedRow?.qty_reserved} onHand=${onHandNow}`);
  check("available = qty − reserved = 0", Number(reservedRow?.available) === 0);

  // direct sale that would eat the reserved stock → STOCK_002
  const eatReserved = await req("POST", "/sales/invoices", T, {
    customer_id: customerId, warehouse_id: WH_MAIN, type: "CASH",
    lines: [{ product_id: productId, qty: 2, unit_price: 3500 }],
  });
  check("direct sale into reservation blocked STOCK_002 409", eatReserved.status === 409 && eatReserved.body.code === "STOCK_002", `status=${eatReserved.status} code=${eatReserved.body.code}`);

  // damage into reservation → STOCK_002 as well
  const dmgReserved = await req("POST", "/inventory/damages", T, {
    warehouse_id: WH_MAIN, product_id: productId, qty: 1, reason: "تلف بالتخزين",
  });
  check("damage into reservation blocked STOCK_002 409", dmgReserved.status === 409 && dmgReserved.body.code === "STOCK_002", `code=${dmgReserved.body.code}`);

  // cancel order → reservation released
  const cancel = await req("POST", `/sales/orders/${orderId}/cancel`, T);
  check("order cancelled", cancel.status === 200, JSON.stringify(cancel.body).slice(0, 120));
  const afterCancel = (await req("GET", `/inventory/balances?warehouse_id=${WH_MAIN}&per_page=300`, T))
    .body.data?.find((b: any) => b.product_id === productId);
  check("reservation released on cancel (qty_reserved=0)", Number(afterCancel?.qty_reserved) === 0, `reserved=${afterCancel?.qty_reserved}`);

  // re-create order → confirm → convert: reservation released INSIDE posting tx
  const order2 = await req("POST", "/sales/orders", T, {
    customer_id: customerId, warehouse_id: WH_MAIN,
    lines: [{ product_id: productId, qty: 4, unit_price: 3500 }],
  });
  const orderId2 = order2.body.data?.id;
  await req("POST", `/sales/orders/${orderId2}/confirm`, T);
  const conv = await req("POST", `/sales/orders/${orderId2}/convert`, T, { type: "CASH" });
  check("convert confirmed order → invoice POSTED", conv.status === 200 && conv.body.data?.invoice_number, JSON.stringify(conv.body).slice(0, 140));
  const afterConvert = (await req("GET", `/inventory/balances?warehouse_id=${WH_MAIN}&per_page=300`, T))
    .body.data?.find((b: any) => b.product_id === productId);
  check("convert released reservation (reserved=0) + stock −4", Number(afterConvert?.qty_reserved) === 0 && Number(afterConvert?.qty) === onHandNow - 4,
    `reserved=${afterConvert?.qty_reserved} qty=${afterConvert?.qty}`);

  // over-reservation blocked: order more than available
  const availNow = Number(afterConvert?.available ?? 0);
  const order3 = await req("POST", "/sales/orders", T, {
    customer_id: customerId, warehouse_id: WH_MAIN,
    lines: [{ product_id: productId, qty: availNow + 5, unit_price: 3500 }],
  });
  const conf3 = await req("POST", `/sales/orders/${order3.body.data?.id}/confirm`, T);
  check("over-reservation blocked STOCK_002 409 on confirm", conf3.status === 409 && conf3.body.code === "STOCK_002", `status=${conf3.status} code=${conf3.body.code}`);

  // ═══════════════════════ §41 APPROVAL ENGINE ═══════════════════════
  console.log("── §41 محرك الموافقات ──");

  // clean slate — deactivate any leftover rules from previous runs
  await db.approvalRule.updateMany({ where: { companyId: 1 }, data: { isActive: false } });

  // rules CRUD
  const ruleDiscount = await req("POST", "/approvals/rules", T, {
    name: "خصم يفوق 10%", trigger_type: "INVOICE_DISCOUNT_PCT", threshold: 10,
  });
  check("create discount rule 201", ruleDiscount.status === 201, JSON.stringify(ruleDiscount.body).slice(0, 120));
  const ruleExpense = await req("POST", "/approvals/rules", T, {
    name: "مصروف كبير", trigger_type: "EXPENSE_AMOUNT", threshold: 500000,
  });
  check("create expense rule 201", ruleExpense.status === 201);

  const rulesNoPerm = await req("POST", "/approvals/rules", CT, { name: "x", trigger_type: "EXPENSE_AMOUNT", threshold: 1 });
  check("cashier blocked PERM_001 (403) on rule create", rulesNoPerm.status === 403);

  const rulesList = await req("GET", "/approvals/rules", T);
  check("rules list 200", rulesList.status === 200);

  // invoice with 20% discount → PENDING_APPROVAL (no stock effect)
  const stockBeforePending = (await req("GET", `/inventory/balances?warehouse_id=${WH_MAIN}&per_page=300`, T))
    .body.data?.find((b: any) => b.product_id === productId)?.qty ?? 0;

  const invPending = await req("POST", "/sales/invoices", T, {
    customer_id: customerId, warehouse_id: WH_MAIN, type: "CASH",
    lines: [{ product_id: productId, qty: 2, unit_price: 3500, discount_pct: 20 }],
  });
  check("discounted invoice routed to approval (pending_approval=true)", invPending.status === 201 && invPending.body.data?.pending_approval === true, JSON.stringify(invPending.body).slice(0, 200));
  const pendingInvoiceId = invPending.body.data?.id;
  const pendingRequestId = invPending.body.data?.request_id;
  check("pending invoice carries number + request_id", !!pendingInvoiceId && !!pendingRequestId);

  const stockAfterPending = (await req("GET", `/inventory/balances?warehouse_id=${WH_MAIN}&per_page=300`, T))
    .body.data?.find((b: any) => b.product_id === productId)?.qty ?? 0;
  check("NO stock deducted while pending", stockAfterPending === stockBeforePending, `${stockBeforePending} → ${stockAfterPending}`);

  const invRow = await db.salesInvoice.findFirst({ where: { id: pendingInvoiceId } });
  check("invoice row status=PENDING_APPROVAL", invRow?.status === "PENDING_APPROVAL", invRow?.status);

  // commission must NOT exist before approval
  const commBefore = await db.commission.findFirst({ where: { invoiceId: pendingInvoiceId } });
  check("no commission before approval", commBefore == null);

  // cashier cannot approve
  const approveNoPerm = await req("POST", `/approvals/${pendingRequestId}/approve`, CT);
  check("cashier blocked PERM_001 (403) on approve", approveNoPerm.status === 403);

  // double-approve impossible — approve once, second attempt must fail VAL_004
  const approve = await req("POST", `/approvals/${pendingRequestId}/approve`, T);
  check("approve 200 → invoice POSTED", approve.status === 200 && approve.body.data?.status === "POSTED", JSON.stringify(approve.body).slice(0, 160));
  const approveAgain = await req("POST", `/approvals/${pendingRequestId}/approve`, T);
  check("double-approve blocked VAL_004 409", approveAgain.status === 409, `status=${approveAgain.status}`);

  const stockAfterApprove = (await req("GET", `/inventory/balances?warehouse_id=${WH_MAIN}&per_page=300`, T))
    .body.data?.find((b: any) => b.product_id === productId)?.qty ?? 0;
  check("stock deducted ONLY at approval (−2)", stockAfterApprove === stockBeforePending - 2, `${stockBeforePending} → ${stockAfterApprove}`);
  const loyaltyAfter = await db.loyaltyTransaction.findFirst({ where: { refType: "SALES_INVOICE", refId: pendingInvoiceId } });
  check("loyalty earned ONLY at approval (same engine as direct posting)", loyaltyAfter != null);

  // rejection path — zero side effects
  const stockBeforeReject = (await req("GET", `/inventory/balances?warehouse_id=${WH_MAIN}&per_page=300`, T))
    .body.data?.find((b: any) => b.product_id === productId)?.qty ?? 0;
  const invReject = await req("POST", "/sales/invoices", T, {
    customer_id: customerId, warehouse_id: WH_MAIN, type: "CASH",
    lines: [{ product_id: productId, qty: 3, unit_price: 3500, discount_pct: 30 }],
  });
  const rejectReqId = invReject.body.data?.request_id;
  const reject = await req("POST", `/approvals/${rejectReqId}/reject`, T, { note: "خصم غير مقبول" });
  check("reject 200", reject.status === 200 && reject.body.data?.status === "REJECTED", JSON.stringify(reject.body).slice(0, 140));
  const rejectedRow = await db.salesInvoice.findFirst({ where: { id: invReject.body.data?.id } });
  check("rejected invoice status=REJECTED", rejectedRow?.status === "REJECTED", rejectedRow?.status);
  const stockAfterReject = (await req("GET", `/inventory/balances?warehouse_id=${WH_MAIN}&per_page=300`, T))
    .body.data?.find((b: any) => b.product_id === productId)?.qty ?? 0;
  check("rejection left ZERO stock side effects", stockAfterReject === stockBeforeReject, `${stockBeforeReject} → ${stockAfterReject}`);

  // expense approval path
  const cashboxes = await req("GET", "/finance/cashboxes", T);
  const cashboxId = (cashboxes.body.data ?? [])[0]?.id;
  let boxBefore = (cashboxes.body.data ?? [])[0]?.balance ?? 0;
  // fixture ديناميكي: تعبئة الصندوق إن كان رصيده أقل من مبلغ المصروف
  // (النفاد متوقع بعد تكرارات التشغيل على نفس القاعدة) — مبدأ استقلالية الحزمة عن حالة القاعدة
  if (boxBefore < 700000) {
    const topUp = await req("POST", "/finance/transactions", T, {
      kind: "opening", cashbox_id: cashboxId, amount: 700000 - boxBefore, note: "تعبئة fixture لاختبار المصروف",
    });
    check("cashbox top-up for expense fixture", topUp.status < 300, JSON.stringify(topUp.body).slice(0, 140));
    boxBefore = (await req("GET", "/finance/cashboxes", T)).body.data?.[0]?.balance ?? boxBefore;
  }
  const expPending = await req("POST", "/finance/transactions", T, {
    kind: "expense", cashbox_id: cashboxId0, amount: 600000, title: "شراء أثاث مكتبي",
  });
  check("big expense routed to approval", (expPending.status === 200 || expPending.status === 201) && expPending.body.data?.pending_approval === true, JSON.stringify(expPending.body).slice(0, 160));
  const expReqId = expPending.body.data?.request_id;
  const expApprove = await req("POST", `/approvals/${expReqId}/approve`, T);
  check("expense approve 200 → cash row posted", expApprove.status === 200 && !!expApprove.body.data?.number, JSON.stringify(expApprove.body).slice(0, 140));
  const expRow = await db.cashTransaction.findFirst({ where: { id: expApprove.body.data?.id } });
  check("cash ledger OUT EXPENSE 600000 with balanceAfter", expRow?.direction === "OUT" && Number(expRow?.amount) === 600000 && Number(expRow?.balanceAfter) === boxBefore - 600000);

  // credit-exceeded rule → CREDIT invoice over limit goes PENDING instead of CREDIT_001
  const ruleCredit = await req("POST", "/approvals/rules", T, { name: "ائتمان فوق الحد", trigger_type: "CREDIT_EXCEEDED", threshold: 0 });
  check("create credit-exceeded rule", ruleCredit.status === 201);
  await db.customer.update({ where: { id: customerId }, data: { creditLimit: 1000 } });
  check("customer credit_limit lowered to 1000 (db)", true);

  const invCredit = await req("POST", "/sales/invoices", T, {
    customer_id: customerId, warehouse_id: WH_MAIN, type: "CREDIT", paid_amount: 0,
    lines: [{ product_id: productId, qty: 1, unit_price: 3500 }],
  });
  check("credit breach routed to approval (not CREDIT_001)", invCredit.status === 201 && invCredit.body.data?.pending_approval === true, JSON.stringify(invCredit.body).slice(0, 200));
  const creditReqId = invCredit.body.data?.request_id;
  const creditApprove = await req("POST", `/approvals/${creditReqId}/approve`, T);
  check("credit override approved → POSTED", creditApprove.status === 200 && creditApprove.body.data?.status === "POSTED", JSON.stringify(creditApprove.body).slice(0, 140));

  // deactivate discount rule → direct posting returns
  const deactivate = await req("PATCH", "/approvals/rules", T, { id: ruleDiscount.body.data?.id, is_active: false });
  check("rule deactivated", deactivate.status === 200 && deactivate.body.data?.isActive === false);
  const invDirect = await req("POST", "/sales/invoices", T, {
    customer_id: customerId, warehouse_id: WH_MAIN, type: "CASH",
    lines: [{ product_id: productId, qty: 1, unit_price: 3500, discount_pct: 20 }],
  });
  check("inactive rule → invoice posts directly (no pending)", invDirect.status === 201 && invDirect.body.data?.pending_approval == null, JSON.stringify(invDirect.body).slice(0, 160));
  // cleanup ALL approval rules so other suites keep their default semantics
  // (CREDIT_001 hard block, expenses post directly, discounts post freely)
  await db.approvalRule.updateMany({ where: { companyId: 1 }, data: { isActive: false } });

  // requests list + audit trail
  const reqList = await req("GET", "/approvals?status=APPROVED", T);
  check("approved requests list 200", reqList.status === 200 && (reqList.body.data ?? []).length >= 3);
  const auditCount = await db.auditLog.count({ where: { entityType: "approval_request" } });
  check("audit trail rows for approvals", auditCount >= 3, `count=${auditCount}`);

  console.log(`\n═══ Result: ${pass}/${pass + fail} ═══`);
  if (fail > 0) process.exit(1);
  await db.$disconnect();
}

main().catch(async (e) => {
  console.error("FATAL", e);
  await db.$disconnect();
  process.exit(1);
});
