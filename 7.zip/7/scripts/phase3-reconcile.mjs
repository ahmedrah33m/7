// =====================================================================
// Phase 3 — post-migration reconciliation (§7 من وثيقة المرحلة)
// يقارن كل القيم المالية بين قاعدتين: PRE (قبل الترحيل) وPOST (بعده).
// القاعدة: القيم لا تُعاد حسابها أثناء الترحيل — يجب التطابق التام
// (مقارنة رقمية عبر Decimal، تتحمل فرق التمثيل INTEGER/REAL في SQLite).
// الاستخدام:
//   node scripts/phase3-reconcile.mjs <pre.db> <post.db>
// =====================================================================
import { PrismaClient } from "@prisma/client";
import Decimal from "decimal.js";
Decimal.set({ precision: 40, rounding: Decimal.ROUND_HALF_UP, toExpNeg: -18, toExpPos: 48 });

const [, , PRE_PATH, POST_PATH] = process.argv;
if (!PRE_PATH || !POST_PATH) {
  console.error("الاستخدام: node scripts/phase3-reconcile.mjs <pre.db> <post.db>");
  process.exit(2);
}

function d(v) {
  if (v == null) return new Decimal(0);
  if (v instanceof Decimal) return v;
  if (typeof v === "object" && typeof v.toString === "function") return new Decimal(v.toString());
  return new Decimal(v);
}
function s(v) { return d(v).toString(); }

const pre = new PrismaClient({ datasourceUrl: `file:${PRE_PATH}` });
const post = new PrismaClient({ datasourceUrl: `file:${POST_PATH}` });

let checked = 0;
const diffs = [];

function cmp(label, a, b) {
  checked++;
  const sa = s(a), sb = s(b);
  if (sa !== sb) diffs.push(`${label}: pre=${sa} post=${sb}`);
}

async function main() {
  // ---- الفواتير + بنودها (أهم ما يجب أن يتطابق حرفيًا)
  const preInv = await pre.salesInvoice.findMany({ include: { lines: true }, orderBy: { id: "asc" } });
  const postInv = await post.salesInvoice.findMany({ include: { lines: true }, orderBy: { id: "asc" } });
  if (preInv.length !== postInv.length) diffs.push(`invoices count: pre=${preInv.length} post=${postInv.length}`);
  const invPost = new Map(postInv.map((i) => [i.id, i]));
  const INV_F = ["subtotal", "discountTotal", "taxTotal", "grandTotal", "paidAmount", "previousBalance", "newBalance", "creditLimitSnap", "exchangeRate"];
  for (const i of preInv) {
    const j = invPost.get(i.id);
    if (!j) { diffs.push(`invoice ${i.id} مفقودة بعد الترحيل`); continue; }
    for (const f of INV_F) cmp(`invoice ${i.number}.${f}`, i[f], j[f]);
    const liPost = new Map(j.lines.map((l) => [l.id, l]));
    const LINE_F = ["qty", "orderedQty", "packageQty", "looseQty", "packageConversion", "packagePrice", "unitPrice", "unitCost", "discountPct", "discountAmount", "taxAmount", "lineTotal", "stockBefore", "stockAfter", "priceExchangeRate"];
    for (const l of i.lines) {
      const k = liPost.get(l.id);
      if (!k) { diffs.push(`invoice ${i.number} line ${l.id} مفقود`); continue; }
      for (const f of LINE_F) cmp(`inv ${i.number} line ${l.id}.${f}`, l[f], k[f]);
    }
  }

  // ---- المنتجات + الأسعار المهيكلة
  const F3 = (model, fields, orderBy = { id: "asc" }) => async (client) => client[model].findMany({ orderBy });
  const pair = async (name, model, fields, where = undefined) => {
    const a = await pre[model].findMany({ where, orderBy: { id: "asc" } });
    const b = await post[model].findMany({ where, orderBy: { id: "asc" } });
    if (a.length !== b.length) diffs.push(`${name} count: pre=${a.length} post=${b.length}`);
    const bm = new Map(b.map((r) => [r.id, r]));
    for (const r of a) {
      const t = bm.get(r.id);
      if (!t) { diffs.push(`${name} #${r.id} مفقود`); continue; }
      for (const f of fields) cmp(`${name} #${r.id}.${f}`, r[f], t[f]);
    }
  };

  await pair("products", "product", ["packQty", "packSalePrice", "costPrice", "salePrice", "taxRatePct", "minStock"]);
  await pair("product_prices", "productPrice", ["amount"]);
  await pair("customers", "customer", ["creditLimit", "balance", "discountPct"]);
  await pair("suppliers", "supplier", ["balance"]);
  await pair("stock_balances", "stockBalance", ["qty"]);
  await pair("stock_movements", "stockMovement", ["qty", "unitCost", "balanceAfter"]);
  await pair("cashboxes", "cashbox", ["balance"]);
  await pair("cash_transactions", "cashTransaction", ["amount", "balanceAfter"]);
  await pair("purchase_invoices", "purchaseInvoice", ["subtotal", "grandTotal", "paidAmount"]);
  const prePurLines = await pre.purchaseInvoiceLine.findMany({ orderBy: { id: "asc" } });
  const postPurLines = await post.purchaseInvoiceLine.findMany({ orderBy: { id: "asc" } });
  {
    const bm = new Map(postPurLines.map((r) => [r.id, r]));
    for (const r of prePurLines) {
      const t = bm.get(r.id);
      if (!t) { diffs.push(`purchase_invoice_line #${r.id} مفقود`); continue; }
      for (const f of ["qty", "unitCost", "lineTotal"]) cmp(`pur_line #${r.id}.${f}`, r[f], t[f]);
    }
  }
  await pair("sales_returns", "salesReturn", ["totalAmount", "refundCash", "creditNote"]);
  await pair("sales_orders", "salesOrder", ["subtotal", "discountTotal", "taxTotal", "grandTotal"]);
  await pair("quotations", "quotation", ["subtotal", "discountTotal", "taxTotal", "grandTotal"]);
  await pair("b2b_orders", "b2BOrder", ["subtotal", "grandTotal"]);
  await pair("commissions", "commission", ["baseAmount", "totalQty", "amount"]);
  await pair("commission_rules", "commissionRule", ["rate", "amount", "perUnitRate", "minInvoiceTotal"]);
  await pair("rep_targets", "repTarget", ["targetAmount"]);
  await pair("packages", "package", ["originalQty", "remainingQty"]);
  await pair("packaging_ledger", "packagingLedger", ["openingQty", "issuedQty", "remainingQty"]);
  await pair("stocktakes", "stocktake", ["diffValue"]);
  await pair("stocktake_lines", "stocktakeLine", ["systemQty", "countedQty", "diffQty", "unitCost"]);
  await pair("sales_return_lines", "salesReturnLine", ["qty", "unitPrice", "lineTotal"]);
  await pair("sales_order_lines", "salesOrderLine", ["qty", "unitPrice", "discountPct", "lineTotal"]);
  await pair("quotation_lines", "quotationLine", ["qty", "unitPrice", "discountPct", "lineTotal"]);
  await pair("b2b_order_lines", "b2BOrderLine", ["qty", "unitPrice", "lineTotal"]);
  await pair("stock_transfer_lines", "stockTransferLine", ["qty"]);
  await pair("visits", "visit", ["orderValue"]);

  console.log(`فحوص المطابقة: ${checked}`);
  if (diffs.length) {
    console.log(`اختلافات: ${diffs.length}`);
    for (const x of diffs.slice(0, 40)) console.log("  ✗", x);
    process.exitCode = 1;
  } else {
    console.log("✓ تطابق تام — كل القيم المالية قبل/بعد الترحيل متطابقة");
  }
}

main()
  .catch((e) => { console.error("خطأ المطابقة:", e); process.exitCode = 1; })
  .finally(async () => { await pre.$disconnect().catch(() => {}); await post.$disconnect().catch(() => {}); });
