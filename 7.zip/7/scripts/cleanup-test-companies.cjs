// تنظيف شركات الاختبار المتبقية من جولات التحقق (حذف ناعم رسمي عبر API)
const { PrismaClient } = require("/home/z/my-project/node_modules/@prisma/client");
const p = new PrismaClient();
const BASE = "http://localhost:3000/api/v1";

(async () => {
  const post = (path, a, d) => fetch(BASE + path, { method: "POST", headers: { ...a, "content-type": "application/json" }, body: JSON.stringify(d) }).then(r => r.json());
  const del = (path, a) => fetch(BASE + path, { method: "DELETE", headers: a }).then(r => r.json());
  const login = await post("/auth/login", {}, { username: "admin", password: "Admin@123" });
  const A = { authorization: "Bearer " + login.data.access_token };
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const rows = await p.company.findMany({
    where: {
      deletedAt: null, createdAt: { gte: today },
      OR: [{ name: { contains: "اختبار HS" } }, { name: { contains: "تصحيح" } }, { name: { contains: "تدقيق" } }],
    },
    select: { id: true, code: true, name: true },
  });
  console.log("test companies to delete:", rows.length);
  for (const c of rows) {
    const r = await del("/admin/companies/" + c.id, A);
    console.log(c.id, c.code, r.success ? "✓ deleted" : "✗ " + (r.message ?? ""));
  }
  await p.$disconnect();
})();
