// =====================================================================
// RP5 §10 — زرع صلاحيات الملفات الناقصة + منحها لأدوار الملكية/إدارة النظام
// الخلفية: مسار /uploads يتطلب system.files.create لكن الصلاحية لم تكن
// محزوعة إطلاقاً — الرفع كان PERM_001 للجميع (فجوة قائمة قبل RP5).
// الزرع: أكواد system.files.* من الكتالوج → منح لأدوار (المالك + مدير النظام)
// في كل الشركات. Idempotent.
// =====================================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const wanted = [
  { code: "system.files.view", module: "system", entity: "files", action: "view", ar: "عرض الملفات والصور" },
  { code: "system.files.create", module: "system", entity: "files", action: "create", ar: "رفع الملفات والصور" },
];
const stats = { permsCreated: 0, grantsCreated: 0, grantsExisting: 0 };

for (const w of wanted) {
  let perm = await db.permission.findUnique({ where: { code: w.code } });
  if (!perm) {
    perm = await db.permission.create({ data: { code: w.code, module: w.module, entity: w.entity, action: w.action, descriptionAr: w.ar } });
    stats.permsCreated++;
  }
  // الأدوار المستهدفة في كل الشركات: المالك + مدير النظام
  const roles = await db.role.findMany({ where: { name: { in: ["المالك", "مدير النظام"] } }, select: { id: true, companyId: true } });
  for (const r of roles) {
    const exists = await db.rolePermission.findFirst({ where: { roleId: r.id, permissionId: perm.id, companyId: r.companyId } });
    if (exists) { stats.grantsExisting++; continue; }
    await db.rolePermission.create({ data: { companyId: r.companyId, roleId: r.id, permissionId: perm.id } });
    stats.grantsCreated++;
  }
}
console.log(JSON.stringify(stats));
await db.$disconnect();
