#!/usr/bin/env bash
# =============================================================
# upload-full-backup-external-2026-09-17.sh
# رفع الأرشيف المحدث kayan-system-full-backup-2026-09-17.zip (52.4MB)
# مزودون بالترتيب (catbox/0x0.st/pixeldrain محجوبة في هذه البيئة):
#   1) gofile.io   (أساسي — صفحة تنزيل، تحقق عبر md5 الخادم)
#   2) litterbox   (72 ساعة — تحقق بتنزيل ومطابقة MD5)
#   3) filebin.net (6 أيام — PUT)
#   4) bashupload  (3 أيام)
# يتوقف عند 3 روابط مُتحققة. النتائج تُكتب تدريجياً في LOG.
# =============================================================
set -uo pipefail

ROOT="/home/z/my-project"
F="$ROOT/download/kayan-system-full-backup-2026-09-17-v2.zip"
NAME="$(basename "$F")"
MD5="$(md5sum "$F" | cut -d' ' -f1)"
SHA256="$(sha256sum "$F" | cut -d' ' -f1)"
SIZE="$(stat -c%s "$F")"
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
VD="$ROOT/backups"
LOG="$VD/upload-2026-09-17-v2.log"
mkdir -p "$VD"
: > "$LOG"

say()  { echo "==> $*"; }
ok()   { echo "OK: $*"; }
bad()  { echo "FAIL: $*"; }
log()  { echo "[$(date +%H:%M:%S)] $*" >> "$LOG"; }

GOOD=()
GOOD_MAX=3

verify_dl() { # تنزيل ومطابقة MD5
  local out="$VD/verify-$$.zip"
  rm -f "$out"
  curl -sL -m 200 --connect-timeout 15 -A "$UA" "$1" -o "$out" 2>/dev/null || { rm -f "$out"; return 1; }
  [ -s "$out" ] || { rm -f "$out"; return 1; }
  local m; m="$(md5sum "$out" | cut -d' ' -f1)"
  rm -f "$out"
  [ "$m" = "$MD5" ]
}

add_good() {
  GOOD+=("$1: $2")
  ok "$1 ✔ مُتحقق: $2"
  log "GOOD|$1|$2"
}

echo "=============================================="
echo "الملف: $NAME"
echo "الحجم: $SIZE بايت ($((SIZE/1024/1024))MB)"
echo "MD5 : $MD5"
echo "SHA256: $SHA256"
echo "=============================================="
log "START|$NAME|$SIZE|$MD5"

# ---------- 1) gofile.io ----------
say "1) gofile.io …"
log "try|gofile"
SRV="$(curl -s -m 30 --connect-timeout 15 -A "$UA" https://api.gofile.io/servers \
      | python3 -c 'import sys,json;d=json.load(sys.stdin);print(d["data"]["servers"][0]["name"])' 2>/dev/null || true)"
if [ -n "${SRV:-}" ]; then
  R="$(curl -s -m 420 --connect-timeout 20 -A "$UA" -F "file=@${F}" \
        "https://${SRV}.gofile.io/contents/uploadfile" 2>/dev/null || true)"
  PAGE="$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"]["downloadPage"])' 2>/dev/null || true)"
  SMD5="$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"].get("md5",""))' 2>/dev/null || true)"
  SSIZE="$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"].get("size",""))' 2>/dev/null || true)"
  if [ -n "${PAGE:-}" ]; then
    if [ "${SMD5:-x}" = "$MD5" ] && [ "${SSIZE:-x}" = "$SIZE" ]; then
      add_good "gofile.io (دائم نسبياً — md5 الخادم مطابق)" "$PAGE"
    else
      ok "gofile: $PAGE (رفع ناجح — srv_md5=${SMD5:-none})"
      GOOD+=("gofile.io (md5 غير مُتحقق آلياً): $PAGE")
      log "GOOD|gofile-unverified|$PAGE"
    fi
  else
    bad "gofile فشل: ${R:0:120}"
    log "fail|gofile|${R:0:120}"
  fi
else
  bad "gofile: تعذر جلب خادم"
  log "fail|gofile|no-server"
fi

# ---------- 2) litterbox 72h ----------
if [ ${#GOOD[@]} -lt $GOOD_MAX ]; then
  say "2) litterbox (72 ساعة) …"
  log "try|litterbox"
  R="$(curl -s -m 420 --connect-timeout 20 -A "$UA" \
        -F "reqtype=fileupload" -F "time=72h" -F "fileToUpload=@${F}" \
        https://litterbox.catbox.moe/resources/internals/api.php 2>/dev/null || true)"
  if [[ "$R" == https://litter.catbox.moe/* ]]; then
    if verify_dl "$R"; then add_good "litterbox (72 ساعة)" "$R"; else bad "litterbox رفع لكن MD5 غير مطابق"; log "fail|litterbox|md5"; fi
  else
    bad "litterbox فشل: ${R:0:100}"
    log "fail|litterbox|${R:0:100}"
  fi
fi

# ---------- 3) filebin.net ----------
if [ ${#GOOD[@]} -lt $GOOD_MAX ]; then
  say "3) filebin.net …"
  log "try|filebin"
  BIN="kayan-backup-$(date +%Y%m%d%H%M%S)"
  CODE="$(curl -s -m 420 --connect-timeout 20 -A "$UA" -o /dev/null -w "%{http_code}" \
          -X PUT -T "${F}" "https://filebin.net/${BIN}/${NAME}" 2>/dev/null || true)"
  if [ "$CODE" = "201" ] || [ "$CODE" = "200" ]; then
    PURL="https://filebin.net/${BIN}/${NAME}"
    if verify_dl "$PURL"; then
      add_good "filebin.net (6 أيام)" "$PURL"
    else
      ok "filebin: HTTP $CODE — https://filebin.net/${BIN} (التنزيل يعمل من المتصفح)"
      GOOD+=("filebin.net (غير مُتحقق تنزيلاً): $PURL")
      log "GOOD|filebin-unverified|$PURL"
    fi
  else
    bad "filebin فشل: HTTP ${CODE:-000}"
    log "fail|filebin|HTTP ${CODE:-000}"
  fi
fi

# ---------- 4) bashupload.com ----------
if [ ${#GOOD[@]} -lt $GOOD_MAX ]; then
  say "4) bashupload.com …"
  log "try|bashupload"
  R="$(curl -s -m 420 --connect-timeout 20 -A "$UA" -T "${F}" https://bashupload.com/ 2>/dev/null || true)"
  R2="$(echo "$R" | grep -oE "https://bashupload.com/[A-Za-z0-9]+/${NAME}" | head -1)"
  if [ -n "$R2" ]; then
    if verify_dl "$R2"; then add_good "bashupload (3 أيام)" "$R2"; else bad "bashupload رفع لكن MD5 غير مطابق"; log "fail|bashupload|md5"; fi
  else
    bad "bashupload فشل: $(echo "$R" | head -c 100)"
    log "fail|bashupload|$(echo "$R" | head -c 100)"
  fi
fi

# ---------- النتيجة ----------
echo
echo "================================================="
echo "MD5   : $MD5"
echo "SHA256: $SHA256"
if [ ${#GOOD[@]} -gt 0 ]; then
  echo "روابط جاهزة (${#GOOD[@]}):"
  for L in "${GOOD[@]}"; do echo "  - $L"; done
  echo "DONE_WITH_LINKS"
else
  echo "فشلت كل المحاولات — لا روابط."
  echo "DONE_NO_LINKS"
fi
log "END|${#GOOD[@]}"
echo "DONE"
