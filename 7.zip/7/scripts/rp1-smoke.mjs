// RP1 §5 — دخان مباشر: العروض والكتالوج B2B يقرأان من ProductPrice (ليس Legacy)
import { PrismaClient } from "@prisma/client";
import { createQuotation } from "../src/lib/quotation-service.ts";
import { b2bCatalog } from "../src/lib/b2b-service.ts";

const db = new PrismaClient();
const companyId = 1; // شركة النخبة — منتجاتها مُرحَّلة في RP1

const user = await db.user.findFirst({ where: { username: "admin" } });
const warehouses = await db.warehouse.findMany({ where: { companyId }, select: { id: true } });
const branchIds = (await db.branch.findMany({ where: { companyId }, select: { id: true } })).map((b) => b.id);
const customer = await db.customer.findFirst({ where: { companyId, deletedAt: null } });
const product = await db.product.findFirst({ where: { companyId, id: 1 } });
if (!user || !customer || !product) throw new Error("بيانات التمهيد غير مكتملة");

const ctx = { userId: user.id, companyId, warehouseIds: [...warehouses.map((w) => w.id), ...branchIds] };

// 1) عرض سعر بلا unitPrice صريح — يجب أن يأتي 8500 من صف SALE/PIECE المُرحَّل
const q = await createQuotation(ctx, { customerId: customer.id, lines: [{ productId: product.id, qty: 2 }] });
const line = q.lines[0];
console.log(`quotation: product=${product.id} unitPrice=${line.unitPrice} lineTotal=${line.lineTotal}`);
if (Number(line.unitPrice) !== 8500) throw new Error(`FAIL: توقع 8500 من ProductPrice — وجد ${line.unitPrice}`);
console.log("QUOTATION_FROM_PRODUCTPRICE = YES");

// 2) كتالوج B2B — list_price يجب أن يكون من ProductPrice
const cat = await b2bCatalog(customer.id);
const catP = cat.products.find((p) => p.id === product.id);
console.log(`b2b catalog: list_price=${catP.list_price} your_price=${catP.your_price}`);
if (catP.list_price !== 8500) throw new Error(`FAIL: list_price توقع 8500 — وجد ${catP.list_price}`);
console.log("B2B_FROM_PRODUCTPRICE = YES");

// 3) تنظيف: حذف عرض الدخان
await db.quotationLine.deleteMany({ where: { quotationId: q.id } });
await db.quotation.delete({ where: { id: q.id } });
console.log("cleanup: quotation deleted");
await db.$disconnect();
