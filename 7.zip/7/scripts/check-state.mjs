import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const rows = await db.company.findMany({
  where: { deletedAt: null },
  select: { id: true, code: true, name: true, subscriptionEndsAt: true, isSuspended: true },
});
console.log("=== Companies ===");
for (const c of rows) console.log(c);

const users = await db.user.findMany({
  where: { deletedAt: null },
  select: {
    id: true, username: true, isActive: true, companyId: true, scopeType: true, branchId: true,
    companyAccess: { select: { companyId: true, isPrimary: true } },
  },
  orderBy: { id: "asc" },
});
console.log("\n=== Users (deletedAt=null) ===");
for (const u of users)
  console.log(`#${u.id} ${u.username} | companyId=${u.companyId} scope=${u.scopeType} active=${u.isActive} access=[${u.companyAccess.map((c) => c.companyId + (c.isPrimary ? "*" : "")).join(",")}]`);

await db.$disconnect();
