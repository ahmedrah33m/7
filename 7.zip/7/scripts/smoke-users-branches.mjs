// اختبار دخاني سريع لمسارات إدارة المستخدمين والفروع (Task 25)
const BASE = "http://localhost:3000/api/v1";

async function call(path, method = "GET", body, token) {
  const res = await fetch(BASE + path, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json().catch(() => ({})) };
}

async function login(username, password) {
  const { status, json } = await call("/auth/login", "POST", { username, password });
  if (status !== 200) throw new Error(`login ${username} failed ${status}: ${JSON.stringify(json)}`);
  return json.data.access_token;
}

const t = (n, ok, extra = "") => console.log(`${ok ? "PASS" : "FAIL"} ${n} ${ok ? "" : extra}`);
const rand = Math.floor(Math.random() * 100000);

(async () => {
  const admin = await login("admin", "Admin@123");

  // 1) GET branches الجديد
  const gb = await call("/admin/branches", "GET", null, admin);
  t("GET /admin/branches", gb.status === 200 && Array.isArray(gb.json.data) && gb.json.data.length >= 2, JSON.stringify(gb.json).slice(0, 200));
  const baghdadId = gb.json.data.find((b) => b.code === "BGW")?.id;

  // 2) POST user — مندوب مرتبط بفرع بغداد
  const repBody = {
    username: `rep.t${rand}`, password: "Test@12345", full_name: "مندوب اختبار حي",
    branch_id: baghdadId, role_codes: ["SALES_REP"],
  };
  const pu = await call("/admin/users", "POST", repBody, admin);
  t("POST /admin/users (مندوب)", pu.status === 201 || pu.status === 200, JSON.stringify(pu.json).slice(0, 300));
  t("مستودع سيارة آلي", pu.json?.data?.created_warehouse_id != null, JSON.stringify(pu.json.data));

  // 3) دخول المستخدم الجديد بيوزره الخاص
  const nl = await call("/auth/login", "POST", { username: repBody.username, password: repBody.password });
  t("دخول المندوب الجديد", nl.status === 200, JSON.stringify(nl.json).slice(0, 150));
  const repTok = nl.json?.data?.access_token;

  // 4) كلمة مرور ضعيفة تُرفض
  const weak = await call("/admin/users", "POST", { username: `w${rand}`, password: "abc", full_name: "x", role_codes: ["CASHIER"] }, admin);
  t("رفض كلمة مرور ضعيفة", weak.status === 422, JSON.stringify(weak.json).slice(0, 150));

  // 5) اسم مستخدم مكرر يُرفض
  const dup = await call("/admin/users", "POST", { ...repBody, username: "admin" }, admin);
  t("رفض اسم مكرر", dup.status === 409, JSON.stringify(dup.json).slice(0, 150));

  // 6) كاشير لا يملك صلاحية إنشاء مستخدمين
  const cashier = await login("cashier", "Cashier@123");
  const forbidden = await call("/admin/users", "POST", repBody, cashier);
  t("كاشير 403 على إنشاء مستخدم", forbidden.status === 403, String(forbidden.status));

  // 7) إنشاء فرع بمدير بيوزر — لمشة واحدة
  const mb = await call("/admin/branches", "POST", {
    code: `T${String(rand).slice(0, 4)}`, name: "فرع الاختبار الحي", city: "الموصل",
    manager: { username: `mgr.t${rand}`, password: "Mgr@12345", full_name: "مدير فرع اختبار" },
  }, admin);
  t("POST /admin/branches + مدير", mb.status === 201, JSON.stringify(mb.json).slice(0, 300));
  t("تجهيز آلي: مستودع+صندوق+مدير", mb.json?.data?.warehouse?.code?.startsWith("WH-") && mb.json?.data?.cashbox?.code?.startsWith("CB-") && mb.json?.data?.manager?.id > 0, JSON.stringify(mb.json.data));

  // 8) دخول مدير الفرع الجديد
  const mgl = await call("/auth/login", "POST", { username: `mgr.t${rand}`, password: "Mgr@12345" });
  t("دخول مدير الفرع الجديد", mgl.status === 200, JSON.stringify(mgl.json).slice(0, 150));

  // 9) عزل نطاق مدير الفرع — يرى فرعه فقط
  const mgTok = mgl.json?.data?.access_token;
  const mgrBranches = await call("/admin/branches", "GET", null, mgTok);
  const allBranches = await call("/admin/branches", "GET", null, admin);
  t("مدير الفرع يرى فرعه فقط", mgrBranches.json?.data?.length === 1 && allBranches.json?.data?.length > 1,
    `mgr=${mgrBranches.json?.data?.length} all=${allBranches.json?.data?.length}`);

  // 10) تعطيل المستخدم يمنع الدخول فورًا
  const newUserId = pu.json?.data?.id;
  await call(`/admin/users/${newUserId}`, "PATCH", { is_active: false }, admin);
  const deact = await call("/auth/login", "POST", { username: repBody.username, password: repBody.password });
  t("تعطيل الحساب يمنع الدخول", deact.status === 403, String(deact.status));

  // 11) تصفير كلمة المرور
  await call(`/admin/users/${newUserId}`, "PATCH", { is_active: true, password: "New@123456" }, admin);
  const re1 = await call("/auth/login", "POST", { username: repBody.username, password: "Test@12345" });
  const re2 = await call("/auth/login", "POST", { username: repBody.username, password: "New@123456" });
  t("كلمة المرور القديمة تُرفض", re1.status === 401, String(re1.status));
  t("كلمة المرور الجديدة تعمل", re2.status === 200, String(re2.status));

  // 12) سجل التدقيق خلق أثر CREATE للمستخدم والفرع
  const aud = await call("/admin/audit-logs?per_page=30", "GET", null, admin);
  const actions = (aud.json?.data ?? []).map((r) => `${r.action}:${r.module}`).join(",");
  t("تدقيق USER_CREATE", actions.includes("CREATE:users"), actions.slice(0, 200));
  t("تدقيق BRANCH_CREATE", actions.includes("CREATE:branches"), actions.slice(0, 200));

  // 13) المندوب الجديد يظهر في قائمة المندوبين (§20)
  const reps = await call("/users/reps", "GET", null, admin);
  t("المندوب في /users/reps", (reps.json?.data ?? []).some((r) => r.username === repBody.username), JSON.stringify(reps.json?.data?.slice(0, 3)));
})();
