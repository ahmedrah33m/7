// E2E — حذف المستخدمين/المستودعات + إدارة اشتراك الشركات (لوحة المالك)
// Run: node scripts/subscription-delete-e2e.mjs
const BASE = "http://localhost:3000";
let TOKEN = null;
let pass = 0, fail = 0;
const results = [];

function check(name, cond, extra = "") {
  if (cond) { pass++; results.push(`  ✅ ${name}${extra ? " — " + extra : ""}`); }
  else { fail++; results.push(`  ❌ ${name}${extra ? " — " + extra : ""}`); }
}

async function call(method, path, body, token = TOKEN) {
  const res = await fetch(BASE + path, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  let json = {};
  try { json = await res.json(); } catch {}
  return { status: res.status, body: json };
}

async function main() {
  console.log("\n══ E2E: حذف مستخدمين/مستودعات + اشتراك الشركات ══\n");

  const login = await call("POST", "/api/v1/auth/login", { username: "admin", password: "Admin@123" });
  check("دخول admin", login.status === 200 && login.body.success);
  TOKEN = login.body.data?.access_token;
  check("لافتة الاشتراك في نطاق الجلسة", login.body.data?.scope?.subscription !== undefined,
    `status=${login.body.data?.scope?.subscription?.status}`);

  const uniq = Date.now().toString().slice(-6);

  // ═══ 1) حذف المستخدمين ═══
  console.log("1) حذف المستخدمين:");
  const branches = await call("GET", "/api/v1/admin/branches");
  const firstBranch = (branches.body.data ?? [])[0];
  const uCreate = await call("POST", "/api/v1/admin/users", {
    username: `deltest${uniq}`, password: "Test@12345", full_name: "مستخدم حذف اختبار",
    role_code: "VIEWER", scope_type: "BRANCH", branch_id: firstBranch.id, branch_ids: [firstBranch.id],
  });
  check("إنشاء مستخدم للاختبار", uCreate.status === 201 && uCreate.body.success,
    uCreate.body.data ? `id=${uCreate.body.data.id}` : JSON.stringify(uCreate.body).slice(0, 120));
  const uid = uCreate.body.data?.id;

  const me = await call("GET", "/api/v1/auth/me");
  const myId = me.body.data?.user?.id;
  const delSelf = await call("DELETE", `/api/v1/admin/users/${myId}`);
  check("منع حذف نفسك (PERM_001)", delSelf.status === 403 && delSelf.body.code === "PERM_001", `http=${delSelf.status}`);

  const delUser = await call("DELETE", `/api/v1/admin/users/${uid}`);
  check("حذف المستخدم", delUser.status === 200 && delUser.body.data?.deleted === true);

  const usersList = await call("GET", "/api/v1/admin/users");
  check("المستخدم المحذوف اختفى من القائمة", !(usersList.body.data ?? []).some((u) => u.id === uid));

  const deadLogin = await call("POST", "/api/v1/auth/login", { username: `deltest${uniq}`, password: "Test@12345" });
  check("دخول المستخدم المحذوف مرفوض", deadLogin.status === 401 || deadLogin.status === 403, `http=${deadLogin.status}`);

  const delAgain = await call("DELETE", `/api/v1/admin/users/${uid}`);
  check("حذف محذوف → VAL_003", delAgain.status === 404 && delAgain.body.code === "VAL_003", `http=${delAgain.status}`);

  // ═══ 2) حذف المستودعات ═══
  console.log("\n2) حذف المستودعات:");
  const whs = await call("GET", "/api/v1/admin/warehouses");
  const whList = whs.body.data ?? [];
  const mainWh = whList.find((w) => w.type === "MAIN");
  const delMain = await call("DELETE", `/api/v1/admin/warehouses?id=${mainWh.id}`);
  check("منع حذف المستودع الرئيسي (WH_001)", delMain.status === 409 && delMain.body.code === "WH_001", `http=${delMain.status}`);

  const whCreate = await call("POST", "/api/v1/admin/warehouses", {
    code: `TWH${uniq}`, name: "مستودع حذف اختبار", branch_id: firstBranch.id, type: "BRANCH",
  });
  check("إنشاء مستودع فارغ", whCreate.status === 201 && whCreate.body.success);
  const whId = whCreate.body.data?.id;

  const delEmptyWh = await call("DELETE", `/api/v1/admin/warehouses?id=${whId}`);
  check("حذف مستودع فارغ", delEmptyWh.status === 200 && delEmptyWh.body.data?.deleted === true);

  // مستودع يحمل مخزونًا → مرفوض
  const wh2 = await call("POST", "/api/v1/admin/warehouses", {
    code: `TWS${uniq}`, name: "مستودع بمخزون", branch_id: firstBranch.id, type: "BRANCH",
  });
  const wh2Id = wh2.body.data?.id;
  const prods = await call("GET", "/api/v1/products?per_page=5");
  const prod = (prods.body.data ?? [])[0];
  const sups = await call("GET", "/api/v1/suppliers");
  const sup = (sups.body.data ?? []).find((s) => s.is_active);
  const inv = await call("POST", "/api/v1/purchases/invoices", {
    supplier_id: sup.id, warehouse_id: wh2Id, type: "CREDIT",
    lines: [{ product_id: prod.id, qty: 4, unit_cost: 1000 }],
  });
  check("ترحيل فاتورة شراء للمستودع الجديد (مخزون 4)", inv.status === 201, inv.body.data ? `number=${inv.body.data.number}` : "");

  const delStockedWh = await call("DELETE", `/api/v1/admin/warehouses?id=${wh2Id}`);
  check("رفض حذف مستودع يحمل مخزونًا (WH_001)", delStockedWh.status === 409 && delStockedWh.body.code === "WH_001",
    delStockedWh.body.message?.slice(0, 60));

  const delInv = await call("DELETE", `/api/v1/purchases/invoices/${inv.body.data?.id}`);
  check("حذف فاتورة الشراء (عكس المخزون) — ميزة الجولة السابقة", delInv.status === 200 && delInv.body.success);

  const delWh2 = await call("DELETE", `/api/v1/admin/warehouses?id=${wh2Id}`);
  check("بعد تصفير المخزون → الحذف ينجح", delWh2.status === 200 && delWh2.body.data?.deleted === true);

  // ═══ 3) حذف الفروع (موجودة — تحقق سريع) ═══
  console.log("\n3) حذف الفروع:");
  const brCreate = await call("POST", "/api/v1/admin/branches", { code: `TBR${uniq}`, name: "فرع حذف اختبار" });
  const brId = brCreate.body.data?.id;
  const delBr = await call("DELETE", `/api/v1/admin/branches/${brId}`);
  check("حذف فرع فارغ", delBr.status === 200 && delBr.body.data?.deleted === true, `http=${delBr.status}`);

  // ═══ 4) اشتراك الشركات ═══
  console.log("\n4) إدارة اشتراك الشركات (لوحة المالك):");
  const coCreate = await call("POST", "/api/v1/admin/companies", { code: `SUB${uniq}`, name: `شركة اشتراك ${uniq}` });
  check("إنشاء شركة اختبار", coCreate.status === 201 && coCreate.body.success,
    coCreate.body.data ? `companyId=${coCreate.body.data.companyId}` : JSON.stringify(coCreate.body).slice(0, 120));
  const co = coCreate.body.data;
  const coId = co.companyId;

  const uCreate2 = await call("POST", "/api/v1/admin/users", {
    username: `subu${uniq}`, password: "Test@12345", full_name: "مستخدم شركة الاشتراك",
    role_code: "CASHIER", company_id: coId, scope_type: "BRANCH",
    branch_id: co.branchId, branch_ids: [co.branchId],
  });
  check("إنشاء مستخدم في شركة الاختبار", uCreate2.status === 201 && uCreate2.body.success,
    uCreate2.body.data ? `id=${uCreate2.body.data.id}` : JSON.stringify(uCreate2.body).slice(0, 140));
  const subUsername = `subu${uniq}`;

  const yesterday = new Date(Date.now() - 24 * 3600_000).toISOString();
  const expireIt = await call("PATCH", `/api/v1/admin/companies/${coId}`, { subscription_ends_at: yesterday, subscription_note: "باقة تجريبية" });
  check("ضبط تاريخ ماضٍ → الحالة EXPIRED", expireIt.body.data?.subscription?.status === "EXPIRED",
    `status=${expireIt.body.data?.subscription?.status}`);

  const blockedLogin = await call("POST", "/api/v1/auth/login", { username: subUsername, password: "Test@12345" });
  check("دخول مستخدم شركة منتهية → 423 SUB_001", blockedLogin.status === 423 && blockedLogin.body.code === "SUB_001",
    `http=${blockedLogin.status} code=${blockedLogin.body.code}`);

  const suspendIt = await call("PATCH", `/api/v1/admin/companies/${coId}`, { is_suspended: true, subscription_ends_at: null });
  check("التعليق اليدوي → SUSPENDED", suspendIt.body.data?.subscription?.status === "SUSPENDED",
    `sessions_revoked=${suspendIt.body.data?.sessions_revoked ?? 0}`);

  const suspendedLogin = await call("POST", "/api/v1/auth/login", { username: subUsername, password: "Test@12345" });
  check("دخول مستخدم شركة معلّقة → 423 SUB_002", suspendedLogin.status === 423 && suspendedLogin.body.code === "SUB_002",
    `http=${suspendedLogin.status} code=${suspendedLogin.body.code}`);

  const in30 = new Date(Date.now() + 30 * 86_400_000).toISOString();
  const activate = await call("PATCH", `/api/v1/admin/companies/${coId}`, { subscription_ends_at: in30, is_suspended: false });
  check("تمديد 30 يوماً → ACTIVE", activate.body.data?.subscription?.status === "ACTIVE",
    `days_left=${activate.body.data?.subscription?.days_left}`);

  const okLogin = await call("POST", "/api/v1/auth/login", { username: subUsername, password: "Test@12345" });
  check("دخول ناجح بعد التجديد", okLogin.status === 200 && okLogin.body.success);
  const subRefresh = okLogin.body.data?.refresh_token;
  const subScopeStatus = okLogin.body.data?.scope?.subscription?.status;
  check("نطاق الجلسة يحمل حالة الاشتراك", subScopeStatus === "ACTIVE", `status=${subScopeStatus}`);

  // إنهاء جلسات الشركة كاملة → refresh يموت
  const kill = await call("PATCH", `/api/v1/admin/companies/${coId}`, { kill_sessions: true });
  check("kill_sessions → إنهاء الجلسات", kill.status === 200 && (kill.body.data?.sessions_revoked ?? 0) >= 1,
    `revoked=${kill.body.data?.sessions_revoked}`);
  const deadRefresh = await call("POST", "/api/v1/auth/refresh", { refresh_token: subRefresh });
  check("refresh بعد القتل مرفوض (AUTH_006)", deadRefresh.status === 401 && deadRefresh.body.code === "AUTH_006",
    `http=${deadRefresh.status}`);

  const soon = new Date(Date.now() + 14 * 86_400_000).toISOString();
  const soonRes = await call("PATCH", `/api/v1/admin/companies/${coId}`, { subscription_ends_at: soon });
  check("بعد 14 يوم → EXPIRING_SOON (تحذير)", soonRes.body.data?.subscription?.status === "EXPIRING_SOON",
    `status=${soonRes.body.data?.subscription?.status}`);

  const restore = await call("PATCH", "/api/v1/admin/companies/" + coId, { subscription_ends_at: null, is_suspended: false, subscription_note: null });
  check("استعادة مفتوح بلا حد (تنظيف)", restore.body.data?.subscription?.status === "OPEN", `status=${restore.body.data?.subscription?.status}`);

  const cos = await call("GET", "/api/v1/admin/companies");
  const coRow = (cos.body.data ?? []).find((c) => c.id === coId);
  check("GET الشركات يتضمن بيانات الاشتراك", !!coRow?.subscription && coRow.subscription.status === "OPEN");

  console.log("\n────────── النتائج ──────────");
  results.forEach((r) => console.log(r));
  console.log(`\nالمجموع: ${pass} ناجح / ${fail} فاشل من ${pass + fail}\n`);
  process.exit(fail ? 1 : 0);
}

main().catch((e) => { console.error("FATAL:", e); process.exit(1); });
