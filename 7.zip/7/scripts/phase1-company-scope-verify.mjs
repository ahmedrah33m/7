// تحقق: العزل الصارم لمستخدمي COMPANY scope (التمايز عن مالك المنصة GLOBAL)
const BASE = "http://localhost:3000";
let pass = 0, fail = 0;
function check(label, ok, extra = "") {
  console.log(`${ok ? "✅" : "❌"} ${label}${extra ? " — " + extra : ""}`);
  ok ? pass++ : fail++;
  if (!ok) process.exitCode = 1;
}
async function j(path, init = {}, token) {
  const res = await fetch(BASE + path, {
    ...init,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  });
  return { status: res.status, body: await res.json().catch(() => ({})) };
}
const data = (r) => r.body?.data;
const del = (p, t) => j(p, { method: "DELETE" }, t);

// p1.dual في شركة A — نطاق COMPANY بصلاحيات SUPER_ADMIN
const login = await j("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: "p1.dual", password: "DualA@12345", company_id: 1 }) });
const t = data(login)?.access_token;
check("دخول p1.dual (COMPANY scope) إلى شركة A", !!t);

const me = data(await j("/api/v1/auth/me", {}, t));
check("النطاق COMPANY وشركته A فقط", me?.user?.scope_type === "COMPANY" && me?.user?.company_id === 1,
  `scope=${me?.user?.scope_type} co=${me?.user?.company_id}`);

// T4 المكافئ: قائمة المستخدمين = شركة A فقط (لا مستخدمي B معرّفاتهم 5+)
const users = data(await j("/api/v1/admin/users?per_page=200", {}, t)) ?? [];
const foreign = users.filter((u) => u.company_id !== 1);
check("COMPANY: قائمة المستخدمين تخص شركة A حصراً", users.length > 0 && foreign.length === 0,
  `عدد=${users.length} أجانب=${foreign.length}`);

// T5 المكافئ: مستخدم شركة B (id داخل شركات أخرى) غير متاح بالمعرّف
let leaked = null;
for (const cid of [2, 3]) {
  const listB = data(await j(`/api/v1/admin/users?company_id=${cid}`, {}, t));
  // مرفوض أصلاً (SCOPE_004) — الجلب أعلاه يجب أن يفشل
  if (listB !== undefined && listB !== null) {
    const body = await j(`/api/v1/admin/users?company_id=${cid}`, {}, t);
    if (body.status === 200) leaked = `company_id=${cid} أُعيدت بنجاح`;
  }
}
check("COMPANY: طلب مستخدمي شركة أخرى ?company_id → مرفوض (SCOPE_004)", leaked === null);

// حاول حذف مستخدم من شركة B بالمعرّف (rep.b#17) — يجب أن يُرفض 404
const del17 = await del("/api/v1/admin/users/17", t);
check("COMPANY: DELETE /admin/users/{id لشركة B} → مرفوض (404/403)",
  del17.status === 404 || del17.status === 403, `HTTP ${del17.status}`);

// التبديل إلى شركة B غير متاح لنطاق COMPANY
const sw = await j("/api/v1/auth/switch-company", { method: "POST", body: JSON.stringify({ company_id: 3 }) }, t);
check("COMPANY: محاولة التبديل لشركة خارج النطاق → مرفوض (SCOPE_004)", sw.status >= 400, `HTTP ${sw.status} ${sw.body?.code ?? ""}`);

console.log(`\nالنتيجة: ✅ ${pass} | ❌ ${fail}`);
