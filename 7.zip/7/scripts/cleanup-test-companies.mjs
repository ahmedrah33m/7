// Cleanup test companies created during verification (soft-delete convention)
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const testCompanies = await db.company.findMany({
  where: { code: { startsWith: "CO-T" }, deletedAt: null },
  select: { id: true, code: true, name: true },
});

for (const c of testCompanies) {
  const now = new Date();
  await db.company.update({ where: { id: c.id }, data: { deletedAt: now } });
  await db.branch.updateMany({ where: { companyId: c.id, deletedAt: null }, data: { deletedAt: now, isActive: false } });
  await db.warehouse.updateMany({ where: { companyId: c.id, deletedAt: null }, data: { deletedAt: now, isActive: false } });
  await db.role.updateMany({ where: { companyId: c.id, deletedAt: null }, data: { deletedAt: now } });
  await db.userCompanyAccess.deleteMany({ where: { companyId: c.id } });
  console.log(`🧹 حُذفت شركة الاختبار: ${c.code} — ${c.name}`);
}

if (!testCompanies.length) console.log("لا شركات اختبار للحذف");

const remaining = await db.company.findMany({ where: { deletedAt: null }, select: { id: true, code: true, name: true } });
console.log("الشركات المتبقية:", remaining.map((c) => `${c.id}:${c.name}`).join(" | "));
await db.$disconnect();
