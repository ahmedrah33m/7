/** تحقق نهائي من أسعار المنتج 10 في لوميره */
import { PrismaClient } from "@prisma/client";

async function main() {
  const db = new PrismaClient();
  const p = await db.product.findFirst({
    where: { id: 10 },
    select: { code: true, name: true, unit: true, packUnit: true, packQty: true, packSalePrice: true, salePrice: true, costPrice: true },
  });
  console.log(JSON.stringify(p, null, 2));
  if (p) {
    console.log(`\nكارتون = ${(p.packSalePrice / 1550).toFixed(2)}$ · علبة = ${(p.salePrice / 1550).toFixed(4)}$ · تكلفة كارتون = ${(p.costPrice / 1550).toFixed(2)}$`);
    console.log(`فحص الاتساق: 11 علبة = ${p.salePrice * 11} د.ع مقابل كارتون ${p.packSalePrice} د.ع`);
  }
  await db.$disconnect();
}

main();
