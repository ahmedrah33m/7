// تشخيص مباشر للمشكلات الثلاث كما يراها المستخدم
const B = "http://localhost:3000";

async function req(path, opts = {}, token) {
  const res = await fetch(B + path, {
    ...opts,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  });
  const body = await res.json().catch(() => ({}));
  return { status: res.status, body };
}

// 1) دخول المالك
const login = await req("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: "admin", password: "Admin@123" }) });
const T = login.body.data.access_token;
console.log("admin login:", login.status);

// 2) قائمة المستخدمين والحاظرة في الشركة 1 — هل تظهر كل اليوزرات؟
const users = await req("/api/v1/admin/users", {}, T);
const list = users.body.data ?? [];
const companies = new Set(list.map((u) => u.company_name));
console.log("\n[P1] users visible to owner:", list.length, "| companies represented:", [...companies]);
console.log("[P1] users in DB but HIDDEN from owner list:");
const { PrismaClient } = await import("@prisma/client");
const db = new PrismaClient();
const all = await db.user.findMany({ where: { deletedAt: null, isActive: true }, select: { id: true, username: true, companyId: true } });
for (const u of all) if (!list.find((v) => v.id === u.id)) console.log(`   - #${u.id} ${u.username} (companyId=${u.companyId}) ← CAN LOGIN but NOT in list`);
await db.$disconnect();

// 3) اختبار 423: اجعل شركة 11 منتهية ثم جرّب دخول مستخدمها
await req("/api/v1/admin/companies/11", { method: "PATCH", body: JSON.stringify({ subscription_ends_at: "2026-09-01" }) }, T);
const subUser = await req("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: "subu662197", password: "SubU@12345" }) });
console.log("\n[P2] login of expired-company user:", subUser.status, JSON.stringify({ code: subUser.body.code, msg: subUser.body.message }));

// 3ب) مالك يبدّل لشركة منتهية — صامت؟
const sw = await req("/api/v1/auth/switch-company", { method: "POST", body: JSON.stringify({ company_id: 11 }) }, T);
console.log("[P2] owner switch to expired company:", sw.status, "| subscription in scope:", JSON.stringify(sw.body.data?.scope?.subscription ?? null));

// 3ج) مالك يسجل دخول مباشرة إلى الشركة المنتهية company_id=11
const admExp = await req("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: "admin", password: "Admin@123", company_id: 11 }) });
console.log("[P2] owner login into expired company:", admExp.status, "| subscription:", JSON.stringify(admExp.body.data?.scope?.subscription ?? null));

// 4) الحالة: هل شركات المبدّل تحمل معلومة الاشتراك؟
const me = await req("/api/v1/auth/me", {}, T);
console.log("\n[P3] /me scope.companies carry subscription?", me.body.data?.scope?.companies?.[0]);
console.log("[P3] /me scope.subscription:", JSON.stringify(me.body.data?.scope?.subscription ?? null));

// استعادة
await req("/api/v1/admin/companies/11", { method: "PATCH", body: JSON.stringify({ subscription_ends_at: null }) }, T);
console.log("\nrestored company 11 → OPEN");
