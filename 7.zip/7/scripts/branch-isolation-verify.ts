// =====================================================================
// Branch-isolation acceptance suite — multi-branch demo (Baghdad+Basra):
//   · basra.manager (BRANCH_MANAGER @ BSR) sees ONLY Basra customers,
//     invoices, orders, suppliers, dashboard KPIs — SCOPE_001/SCOPE_002
//     block cross-branch reads/writes
//   · admin (NULL assignment = كل الفروع) sees everything
//   · new party creation is auto-stamped with the actor's branch
// Exit 0 = all pass.
// =====================================================================

import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000/api/v1";
const db = new PrismaClient();

let pass = 0;
let fail = 0;

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  ✅ ${name}`);
  } else {
    fail++;
    console.log(`  ❌ ${name} ${detail ? "— " + detail : ""}`);
  }
}

async function req(method: string, path: string, token?: string, body?: unknown): Promise<{ status: number; body: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json };
}

async function main() {
  console.log("═══ Branch isolation verification — بغداد + البصرة ═══");

  // 0) logins
  const admin = await req("POST", "/auth/login", undefined, { username: "admin", password: "Admin@123" });
  check("admin login", admin.status === 200 && admin.body.success);
  const A = admin.body.data?.access_token as string;

  const bm = await req("POST", "/auth/login", undefined, { username: "basra.manager", password: "Basra@123" });
  check("basra.manager login", bm.status === 200 && bm.body.success, JSON.stringify(bm.body).slice(0, 120));
  const B = bm.body.data?.access_token as string;

  const cashier = await req("POST", "/auth/login", undefined, { username: "cashier", password: "Cashier@123" });
  const C = cashier.body.data?.access_token as string;
  check("cashier login (NULL assignment = كل الفروع)", cashier.status === 200);

  // 1) customers isolation
  const bmCusts = await req("GET", "/customers?per_page=100", B);
  const bmNames = JSON.stringify(bmCusts.body.data ?? []);
  check("basra sees Basra customers", bmNames.includes("C-90001") && bmNames.includes("C-90002"));
  check("basra CANNOT see Baghdad customers", !bmNames.includes("بقالة الأمانة") && !bmNames.includes("C-00001"));
  check("basra customers total >= 2 (seed pair)", (bmCusts.body.data?.length ?? 0) >= 2, `got ${bmCusts.body.data?.length}`);

  const adminCusts = await req("GET", "/customers?per_page=100", A);
  const adminNames = JSON.stringify(adminCusts.body.data ?? []);
  check("admin sees both branches", adminNames.includes("C-90001") && adminNames.includes("بقالة الأمانة"));

  const cCusts = await req("GET", "/customers?per_page=100", C);
  const cNames = JSON.stringify(cCusts.body.data ?? []);
  check("cashier (all-branch) sees BOTH branches", cNames.includes("بقالة الأمانة") && cNames.includes("C-90001"));

  // 2) cross-branch write barriers
  const WH_MAIN = 1, WH_BSR = 3;
  const products = await req("GET", "/products?per_page=100", B);
  const product = (products.body.data ?? [])[0];
  check("basra can read products (company-wide catalog)", !!product?.id);

  // basra posting to Baghdad warehouse → warehouse scope blocks (403)
  const crossWh = await req("POST", "/sales/invoices", B, {
    warehouse_id: WH_MAIN, customer_id: (bmCusts.body.data ?? [])[0]?.id, type: "CASH",
    lines: [{ product_id: product.id, qty: 1, unit_price: 1000 }],
  });
  check("basra invoice in Baghdad WH → 403 SCOPE_002", crossWh.status === 403 && crossWh.body.code === "SCOPE_002",
    JSON.stringify(crossWh.body).slice(0, 140));

  // 3) Basra branch operations — intake then invoice (transactional chain)
  const intake = await req("POST", "/inventory/movements", B, {
    warehouse_id: WH_BSR, product_id: product.id, direction: "IN", qty: 50, note: "تزويد اختبار العزل",
  });
  check("basra intake in own WH → 201", intake.status === 201, JSON.stringify(intake.body).slice(0, 140));

  const basraCust = (bmCusts.body.data ?? []).find((c: any) => c.code === "C-90001");
  const inv = await req("POST", "/sales/invoices", B, {
    warehouse_id: WH_BSR, customer_id: basraCust?.id, type: "CASH",
    lines: [{ product_id: product.id, qty: 3, unit_price: 2500 }],
  });
  check("basra invoice in own WH → 201", inv.status === 201, JSON.stringify(inv.body).slice(0, 140));
  const invNumber = inv.body.data?.number as string;
  check("invoice response carries number", !!invNumber);

  // branch stamp on the invoice row (documents self-stamp from warehouse branch)
  const invRow = invNumber ? await db.salesInvoice.findFirst({ where: { number: invNumber } }) : null;
  check("invoice stamped branch_id = Basra(2)", invRow?.branchId === 2, `branchId=${invRow?.branchId}`);

  // stock + balance chain inside Basra
  check("invoice grand_total = 7500", inv.body.data?.grand_total === 7500, `grand_total=${inv.body.data?.grand_total}`);

  // 4) invoices list isolation
  const bmInvs = await req("GET", "/sales/invoices?per_page=100", B);
  const bmInvStr = JSON.stringify(bmInvs.body.data ?? []);
  const adminInvs = await req("GET", "/sales/invoices?per_page=100", A);
  const adminInvStr = JSON.stringify(adminInvs.body.data ?? []);
  check("basra invoices list has his invoice", bmInvStr.includes(invNumber));
  // Dynamic Baghdad fixture: an admin-visible invoice stamped to the
  // Baghdad main warehouse — never visible to the Basra manager.
  const baghdadInvoice = (adminInvs.body.data ?? []).find((i: any) => i.warehouse?.code === "WH-MAIN");
  check("basra CANNOT see Baghdad invoices", !!baghdadInvoice && !bmInvStr.includes(baghdadInvoice.number));
  const bmInvCount = bmInvs.body.data?.length ?? 0;
  check("admin invoices cover both branches", adminInvStr.includes(invNumber) && (adminInvs.body.data?.length ?? 0) > bmInvCount,
    `admin=${adminInvs.body.data?.length} basra=${bmInvCount}`);

  // 5) orders isolation (admin creates Baghdad order → hidden from basra)
  const baghdadCust = (adminCusts.body.data ?? []).find((c: any) => c.name === "بقالة الأمانة");
  const ord = await req("POST", "/sales/orders", A, {
    customer_id: baghdadCust?.id, warehouse_id: WH_MAIN,
    lines: [{ product_id: product.id, qty: 2, unit_price: 1000 }],
  });
  check("admin Baghdad order 201", ord.status === 201, JSON.stringify(ord.body).slice(0, 140));
  const ordNumber = ord.body.data?.number as string;
  const bmOrders = await req("GET", "/sales/orders?per_page=100", B);
  check("basra CANNOT see Baghdad order", !JSON.stringify(bmOrders.body.data ?? []).includes(ordNumber));
  const adminOrders = await req("GET", "/sales/orders?per_page=100", A);
  check("admin sees his Baghdad order", JSON.stringify(adminOrders.body.data ?? []).includes(ordNumber));

  // 6) customer-statement cross-branch guard
  const bmStatement = await req("GET", `/reports/customer-statement?customer_id=${baghdadCust?.id}`, B);
  check("basra statement of Baghdad customer → 404 VAL_003", bmStatement.status === 404 && bmStatement.body.code === "VAL_003",
    JSON.stringify(bmStatement.body).slice(0, 120));
  const okStatement = await req("GET", `/reports/customer-statement?customer_id=${basraCust?.id}`, B);
  check("basra statement of own customer → 200", okStatement.status === 200 && okStatement.body.success);

  // 7) suppliers isolation — basra lacks parties.suppliers.view (PERM_001)
  //    → zero data leak either way; admin sees Baghdad suppliers.
  const bmSup = await req("GET", "/suppliers", B);
  const bmSupBlocked = bmSup.status === 403 || (bmSup.body.data?.length ?? 0) === 0;
  check("basra gets no supplier data (403 PERM_001 أو قائمة فارغة)", bmSupBlocked,
    `status=${bmSup.status} len=${bmSup.body.data?.length}`);
  const adminSup = await req("GET", "/suppliers", A);
  check("admin sees suppliers (Baghdad)", (adminSup.body.data?.length ?? 0) >= 2);

  // 8) auto-stamping on creation
  const bmNewCust = await req("POST", "/customers", B, { name: "عميل البصرة الجديد", credit_limit: 100000 });
  check("basra creates customer → 201", bmNewCust.status === 201, JSON.stringify(bmNewCust.body).slice(0, 140));
  const bmNewRow = await db.customer.findFirst({ where: { name: "عميل البصرة الجديد", deletedAt: null } });
  check("new customer auto-stamped branch = Basra(2)", bmNewRow?.branchId === 2, `branchId=${bmNewRow?.branchId}`);

  const bmForeignCust = await req("POST", "/customers", B, { name: "محاولة بغداد", credit_limit: 0, branch_id: 1 });
  check("basra explicit Baghdad stamp → 403 SCOPE_001", bmForeignCust.status === 403 && bmForeignCust.body.code === "SCOPE_001",
    JSON.stringify(bmForeignCust.body).slice(0, 140));

  const adminNewCust = await req("POST", "/customers", A, { name: "عميل بغداد الجديد (أدمن)", credit_limit: 50000 });
  const adminNewRow = await db.customer.findFirst({ where: { name: "عميل بغداد الجديد (أدمن)", deletedAt: null } });
  check("admin new customer defaults to first branch Baghdad(1)", adminNewRow?.branchId === 1, `branchId=${adminNewRow?.branchId}`);

  // 9) dashboard KPIs scoped (receivables = scalar number)
  const bmStats = await req("GET", "/dashboard/stats", B);
  const adminStats = await req("GET", "/dashboard/stats", A);
  check("basra stats 200", bmStats.status === 200);
  const bmReceivable = bmStats.body.data?.receivables ?? null;
  const adminReceivable = adminStats.body.data?.receivables ?? null;
  check("basra receivables < admin receivables (scoped KPIs)",
    typeof bmReceivable === "number" && typeof adminReceivable === "number" && bmReceivable < adminReceivable,
    `bm=${bmReceivable} admin=${adminReceivable}`);

  // 10) audit trail on the isolation demo
  const audits = await req("GET", "/admin/audit-logs?per_page=30", A);
  const auditStr = JSON.stringify(audits.body.data ?? []);
  check("audit captures branch demo activity", auditStr.includes("عميل البصرة الجديد") || auditStr.includes("customer"));

  console.log(`\n═══ Result: ${pass} passed, ${fail} failed ═══`);
  await db.$disconnect();
  process.exit(fail === 0 ? 0 : 1);
}

main().catch((e) => {
  console.error("FATAL", e);
  process.exit(1);
});
