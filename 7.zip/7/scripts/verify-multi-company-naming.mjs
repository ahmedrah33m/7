// =====================================================================
// E2E verification — Multi-Company dynamic naming
// 1) login as admin
// 2) GET companies (baseline)
// 3) POST new company (provisioning)
// 4) POST refresh-scope → scope.companies must include the new company
// 5) POST switch-company → active company = new company
// 6) GET auth/me → company.name = NEW company name (invoice header source)
// 7) PATCH rename → GET /me reflects the new name
// =====================================================================
const BASE = "http://localhost:3000";

async function j(path, init = {}, token) {
  const res = await fetch(BASE + path, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(init.headers ?? {}),
    },
  });
  const body = await res.json().catch(() => ({}));
  return { status: res.status, body };
}

function check(label, ok, extra = "") {
  console.log(`${ok ? "✅" : "❌"} ${label}${extra ? " — " + extra : ""}`);
  if (!ok) process.exitCode = 1;
}

const login = await j("/api/v1/auth/login", {
  method: "POST",
  body: JSON.stringify({ username: "admin", password: "Admin@123" }),
});
const token = login.body?.data?.access_token;
check("تسجيل دخول admin", !!token, login.body?.message ?? "");

const list1 = await j("/api/v1/admin/companies", {}, token);
const before = list1.body?.data?.length ?? 0;
check("GET /admin/companies (قائمة الشركات)", list1.status === 200 && list1.body?.success, `عدد الشركات: ${before}`);

const suffix = Date.now().toString().slice(-6);
const created = await j("/api/v1/admin/companies", {
  method: "POST",
  body: JSON.stringify({
    code: `CO-T${suffix}`,
    name: `شركة التجربة ${suffix} للتوزيع`,
    name_en: `Test Co ${suffix}`,
    phone: "+9647700000000",
  }),
}, token);
const newCompany = created.body?.data;
check("POST /admin/companies (إنشاء شركة + تجهيز كامل)", created.status === 201 && !!newCompany?.companyId,
  `id=${newCompany?.companyId} roles=${newCompany?.rolesCreated}`);

// duplicate code must fail
const dup = await j("/api/v1/admin/companies", {
  method: "POST",
  body: JSON.stringify({ code: `CO-T${suffix}`, name: "مكرر" }),
}, token);
check("منع تكرار كود الشركة (VAL_002)", dup.status === 409 && dup.body?.code === "VAL_002", dup.body?.code ?? String(dup.status));

const refreshed = await j("/api/v1/auth/refresh-scope", { method: "POST" }, token);
const scopeCompanies = refreshed.body?.data?.scope?.companies ?? [];
check("POST /auth/refresh-scope (ظهور الشركة الجديدة في النطاق)",
  refreshed.body?.success && scopeCompanies.some((c) => c.id === newCompany.companyId),
  `الشركات في النطاق: ${scopeCompanies.length}`);

const switched = await j("/api/v1/auth/switch-company", {
  method: "POST",
  body: JSON.stringify({ company_id: newCompany.companyId }),
}, token);
check("POST /auth/switch-company (التبديل للشركة الجديدة)", switched.body?.success, switched.body?.message ?? "");
const token2 = switched.body?.data?.access_token ?? token;

const me = await j("/api/v1/auth/me", {}, token2);
check("GET /auth/me — company.name = اسم الشركة الجديدة (مصدر ترويسة الفاتورة)",
  me.body?.data?.company?.id === newCompany.companyId && me.body?.data?.company?.name?.includes(`التجربة ${suffix}`),
  me.body?.data?.company?.name ?? "");

// provisioning sanity: walk-in customer + branch + warehouse of new company
const customers = await j("/api/v1/customers?per_page=50", {}, token2);
const hasWalkin = (customers.body?.data?.items ?? customers.body?.data ?? []).some?.((c) => c.customer_type === "WALK_IN") ?? false;
check("تجهيز الزبون النقدي/المتردد الافتراضي للشركة الجديدة", hasWalkin, "CASH-001 WALK_IN");

const rename = await j(`/api/v1/admin/companies/${newCompany.companyId}`, {
  method: "PATCH",
  body: JSON.stringify({ name: `شركة التجربة المُعدّلة ${suffix}` }),
}, token);
check("PATCH /admin/companies/[id] (تعديل الاسم)", rename.body?.success && rename.body?.data?.name === `شركة التجربة المُعدّلة ${suffix}`, rename.body?.data?.name ?? "");

const me2 = await j("/api/v1/auth/me", {}, token2);
check("الاسم الجديد يصل إلى /me فورًا (يظهر في الفواتير)",
  me2.body?.data?.company?.name === `شركة التجربة المُعدّلة ${suffix}`,
  me2.body?.data?.company?.name ?? "");

// switch back to original company
const originalId = scopeCompanies.find((c) => c.id !== newCompany.companyId)?.id;
const back = await j("/api/v1/auth/switch-company", {
  method: "POST",
  body: JSON.stringify({ company_id: originalId }),
}, token2);
check("العودة للشركة الأصلية", back.body?.success, back.body?.data?.scope?.active_company_id ? `active=${back.body.data.scope.active_company_id}` : "");

console.log("\n— انتهى الفحص —");
