#!/bin/bash
# Fully-detached daemon start for the Next.js dev server.
# Double-setsid + full stdio detach so nothing ties it to the tool shell.
cd /home/z/my-project

# stop anything already bound to 3000
fuser -k 3000/tcp 2>/dev/null
sleep 1

setsid bash -c 'cd /home/z/my-project && exec npx next dev --port 3000 --hostname 0.0.0.0' \
  > /home/z/my-project/.dev-server.log 2>&1 < /dev/null &

DAEMON_PID=$!
echo "daemon spawned pid=$DAEMON_PID"
# wait for readiness
for i in $(seq 1 30); do
  if curl -s -o /dev/null --max-time 2 http://localhost:3000/; then
    echo "READY after ${i}s"
    break
  fi
  sleep 1
done
curl -s -o /dev/null -w "in-call check: HTTP %{http_code}\n" --max-time 30 http://localhost:3000/
