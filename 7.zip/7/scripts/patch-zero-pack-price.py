# إصلاح خلل «كراتين بلا سعر»: صف PACKAGE صفر يظلّل الاشتقاق من سعر الحبة
# 1) product-pricing: لا صف SALE/PACKAGE عند غياب سعر الكرتونة (بدل صف صفر)
# 2) sales-service: defPackIqd الصفري يُعامل كغائب → الاشتقاق packQty×سعر الحبة
P1 = "/home/z/my-project/src/lib/product-pricing.ts"
src = open(P1, encoding="utf-8").read()

old1 = '''  if (hasPack) {
    wanted.push({ priceType: "SALE", unit: "PACKAGE", currency: packCurrency, amount: input.pack_sale_price ?? 0 });
  }'''
new1 = '''  // إصلاح «كراتين بلا سعر»: بلا سعر كرتونة موجب لا يُنشأ صف PACKAGE إطلاقًا —
  // صف صفر يظلّل الاشتقاق من سعر الحبة في الفواتير (0 ?? البديل يبقى 0)
  if (hasPack && (input.pack_sale_price ?? 0) > 0) {
    wanted.push({ priceType: "SALE", unit: "PACKAGE", currency: packCurrency, amount: input.pack_sale_price! });
  }'''
assert src.count(old1) == 1, f"anchor1 = {src.count(old1)}"
src = src.replace(old1, new1)
open(P1, "w", encoding="utf-8").write(src)
print("  ✓ product-pricing.ts — لا صفوف PACKAGE صفرية")

P2 = "/home/z/my-project/src/lib/sales-service.ts"
src = open(P2, encoding="utf-8").read()

old2 = '''    const defPackIqd =
      info.hasPack && packageQty.isPositive()
        ? salePack
          ? toIqd(salePack.amount, salePack.currency, priceRate ?? 1)
          : p.packSalePrice != null
            ? (legacyFallbackWarn("invoice:package", companyId, p.id, p.name), moneyOf(dec(p.packSalePrice)))
            : moneyOf(defPieceIqd.mul(info.packQty))
        : null;'''
new2 = '''    const defPackIqd =
      info.hasPack && packageQty.isPositive()
        ? salePack && dec(salePack.amount).gt(0)
          ? toIqd(salePack.amount, salePack.currency, priceRate ?? 1)
          : p.packSalePrice != null && dec(p.packSalePrice).gt(0)
            ? (legacyFallbackWarn("invoice:package", companyId, p.id, p.name), moneyOf(dec(p.packSalePrice)))
            : moneyOf(defPieceIqd.mul(info.packQty)) // سعر الكرتونة غائب/صفر → اشتقاق من سعر الحبة
        : null;'''
assert src.count(old2) == 1, f"anchor2 = {src.count(old2)}"
src = src.replace(old2, new2)
open(P2, "w", encoding="utf-8").write(src)
print("  ✓ sales-service.ts — سعر الكرتونة الصفري غائب (اشتقاق من الحبة)")
