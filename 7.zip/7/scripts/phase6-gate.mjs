// =====================================================================
// Phase 6 §9 — Production Gate (بوابة الإنتاج)
// لا يُعلن «Production Ready» إلا إذا كانت كل البوابات خضراء:
//   1 Unit · 2 Integration · 3 E2E · 4 Security · 5 Inventory ·
//   6 Finance · 7 Migration · 8 Backup/Restore (+9 Regression مع --full)
// تشغيل:  node scripts/phase6-gate.mjs [--full]
// =====================================================================
import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";
import path from "node:path";

const require = createRequire(import.meta.url);
void require; // متاح للامتدادات — غير مستخدم حالياً
// RP3 §8 — نقلية البوابة: يعمل على أي جهاز/CI/Staging/Production من مجلد المشروع
const ROOT = process.env.KAYAN_ROOT || process.cwd();
const FULL = process.argv.includes("--full");
const results = [];

function gate(name, fn) {
  const t0 = Date.now();
  try {
    const detail = fn();
    results.push({ name, pass: true, detail: detail ?? "", ms: Date.now() - t0 });
    console.log(`  ✓ ${name} ${detail ? `— ${detail}` : ""} (${((Date.now() - t0) / 1000).toFixed(1)}s)`);
  } catch (e) {
    results.push({ name, pass: false, detail: String(e.message ?? e).slice(0, 300), ms: Date.now() - t0 });
    console.log(`  ✗ ${name} — ${String(e.message ?? e).slice(0, 300)}`);
  }
}

/** تشغيل vitest على مسار/ملفات — يرمي عند فشل أي اختبار */
function vitest(paths) {
  const r = spawnSync("bunx", ["vitest", "run", ...paths, "--reporter=dot"], {
    cwd: ROOT, encoding: "utf8", timeout: 600_000, shell: true,
  });
  const out = `${r.stdout ?? ""}\n${r.stderr ?? ""}`;
  const m = out.match(/Tests\s+(\d+) passed/);
  const tests = m ? `${m[1]} tests` : "tests";
  if (r.status !== 0) {
    const tail = out.split("\n").filter((l) => /FAIL|×|failed/.test(l)).slice(-6).join(" | ");
    throw new Error(tail || `exit=${r.status}`);
  }
  return tests;
}

async function main() {
  console.log("=".repeat(70));
  console.log("PHASE 6 — PRODUCTION GATE (بوابة الإنتاج)");
  console.log("=".repeat(70));
  const cool = (ms) => new Promise((r) => setTimeout(r, ms));

  // ---------- 1) Unit ----------
  gate("1) Unit PASS", () => vitest(["tests/unit"]));
  await cool(20_000); // تهدئة حد المعدل قبل بوابات إنشاء الشركات

  // ---------- 2) Integration (APIs + انحدار التعبئة) ----------
  gate("2) Integration PASS", () => vitest(["tests/integration/api.test.ts", "tests/integration/packaging-regression.test.ts"]));
  await cool(20_000);

  // ---------- 3) E2E ----------
  gate("3) E2E PASS", () => vitest(["tests/e2e"]));
  await cool(20_000);

  // ---------- 4) Security (multi-tenant ×7) ----------
  gate("4) Security PASS", () => vitest(["tests/integration/security.test.ts"]));
  await cool(20_000);

  // ---------- 5) Inventory (ثابت الدفتر عبر دورة الحياة) ----------
  gate("5) Inventory PASS", () => vitest(["tests/integration/stock-integrity.test.ts"]));
  await cool(20_000);

  // ---------- 6) Finance (المطابقة المالية) ----------
  gate("6) Finance PASS", () => vitest(["tests/integration/finance-reconciliation.test.ts"]));
  await cool(10_000);

  // ---------- 7) Migration (schema ↔ قاعدة) ----------
  gate("7) Migration PASS", () => {
    // 7a — db push idempotent (يجب أن ينجح بلا تغييرات)
    const push = spawnSync("bunx", ["prisma", "db", "push", "--skip-generate"], {
      cwd: ROOT, encoding: "utf8", timeout: 180_000, shell: true,
    });
    if (push.status !== 0) throw new Error(`db push failed: ${(push.stderr || push.stdout).slice(-200)}`);
    // 7b — كل جداول @@map موجودة في SQLite + integrity_check (python3)
    const chk = spawnSync("python3", [path.join(ROOT, "scripts/phase6-dbcheck.py"), "migrate"], {
      encoding: "utf8", timeout: 120_000,
    });
    if (chk.status !== 0) throw new Error((chk.stdout || chk.stderr || "failed").trim().slice(0, 200));
    return (chk.stdout || "").trim();
  });

  // ---------- 8) Backup/Restore ----------
  gate("8) Backup/Restore PASS", () => {
    const chk = spawnSync("python3", [path.join(ROOT, "scripts/phase6-dbcheck.py"), "backup"], {
      encoding: "utf8", timeout: 120_000,
    });
    if (chk.status !== 0) throw new Error((chk.stdout || chk.stderr || "failed").trim().slice(0, 200));
    return (chk.stdout || "").trim();
  });

  // ---------- 9) Regression (اختياري مع --full) ----------
  if (FULL) {
    const suites = [
      ["phase5", "node", ["scripts/phase5-verify.mjs"]],
      ["phase4", "node", ["scripts/phase4-verify.mjs"]],
      ["phase3", "node", ["scripts/phase3-verify.mjs"]],
      ["phase2", "node", ["scripts/phase2-verify.mjs"]],
      ["phase0", "node", ["scripts/phase0-verify.ts"]],
      ["multi-branch", "bunx", ["tsx", "scripts/multi-branch-verify.ts"]],
      ["invoice-smart", "bunx", ["tsx", "scripts/invoice-smart-verify.ts"]],
      ["phase1-security", "node", ["scripts/phase1-security-verify.mjs"]],
      ["phase1-scope", "node", ["scripts/phase1-company-scope-verify.mjs"]],
      ["currency-edit", "node", ["scripts/verify-currency-and-product-edit.mjs"]],
    ];
    for (const [name, cmd, args] of suites) {
      gate(`9) Regression — ${name}`, () => {
        // محاولتان — الثانية بعد تهدئة 30s (حد المعدل يضرب الجناحات المتلاحقة)
        let lastErr;
        for (let attempt = 0; attempt < 2; attempt++) {
          if (attempt > 0) {
            spawnSync("sleep", ["30"], { shell: true });
          }
          const r = spawnSync(cmd, args, { cwd: ROOT, encoding: "utf8", timeout: 420_000, shell: true });
          const out = `${r.stdout ?? ""}\n${r.stderr ?? ""}`;
          try {
            if (/FAIL=\d+/g.test(out)) {
              const m = [...out.matchAll(/FAIL=(\d+)/g)].map((x) => Number(x[1]));
              if (m.some((x) => x > 0)) throw new Error(out.split("\n").filter((l) => /✗/.test(l)).slice(0, 3).join(" | "));
              return out.match(/PASS=\d+/)?.[0] ?? "pass";
            }
            if (/فاشل\s*[·|]\s*[1-9]|❌\s*[1-9]/.test(out)) throw new Error("فحوصات فاشلة");
            if (r.status !== 0) throw new Error(out.split("\n").filter(Boolean).slice(-3).join(" | "));
            return out.match(/(النتيجة[^%\n]*|Result:[^\n]*|PASS=\d+ FAIL=0)/)?.[0]?.trim() ?? "pass";
          } catch (e) {
            lastErr = e;
          }
        }
        throw lastErr;
      });
    }
  }

  // ---------- الحكم النهائي ----------
  console.log("=".repeat(70));
  const failed = results.filter((r) => !r.pass);
  const totalMs = results.reduce((a, r) => a + r.ms, 0);
  for (const r of results) {
    console.log(`${r.pass ? "PASS" : "FAIL"}  ${r.name}  (${(r.ms / 1000).toFixed(1)}s)${r.pass && r.detail ? ` — ${r.detail}` : ""}`);
  }
  console.log("=".repeat(70));
  if (failed.length === 0) {
    console.log(`★ PRODUCTION READY — كل البوابات (${results.length}) خضراء في ${(totalMs / 1000).toFixed(0)}s`);
  } else {
    console.log(`✗ NOT READY — ${failed.length}/${results.length} بوابة فاشلة: ${failed.map((f) => f.name).join(", ")}`);
    process.exitCode = 1;
  }
}

main().catch((e) => { console.error(e); process.exitCode = 1; });
