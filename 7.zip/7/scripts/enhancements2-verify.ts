// =====================================================================
// Development pack 2 acceptance suite — loyalty points · global search
// · e-invoice QR (TLV) · stockout forecast alert · JSON backup ·
// barcode-driven invoicing support. Real HTTP + DB assertions.
// Exit 0 = all pass.
// =====================================================================

import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000/api/v1";
const db = new PrismaClient();

let pass = 0;
let fail = 0;
const results: string[] = [];

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    results.push(`  ✅ ${name}`);
  } else {
    fail++;
    results.push(`  ❌ ${name} ${detail ? "— " + detail : ""}`);
  }
}

async function req(
  method: string,
  path: string,
  token?: string,
  body?: unknown
): Promise<{ status: number; body: any; headers: Headers }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json, headers: res.headers };
}

async function main() {
  console.log("═══ Development pack 2 verification — loyalty · search · QR · forecast · backup ═══");
  try {
    // 0) logins
    const admin = await req("POST", "/auth/login", undefined, { username: "admin", password: "Admin@123" });
    check("admin login", admin.status === 200 && admin.body.success);
    const T = admin.body.data?.access_token as string;

    const cashier = await req("POST", "/auth/login", undefined, { username: "cashier", password: "Cashier@123" });
    const CT = cashier.body.data?.access_token as string;
    check("cashier login", cashier.status === 200);

    // ---- A) LOYALTY ------------------------------------------------------
    const customers = await req("GET", "/customers?per_page=100", T);
    const custs = customers.body.data ?? [];
    check("customers list carries loyalty_points", custs.some((c: any) => typeof c.loyalty_points === "number"));
    const debCust = custs.find((c: any) => c.balance > 1000 && c.loyalty_points > 0);
    check("a customer with balance + points exists (seed opening)", !!debCust,
      `found=${custs.filter((c: any) => c.balance > 1000).length} with balance`);

    // A1) history endpoint
    const hist = await req("GET", `/customers/${debCust.id}/loyalty`, T);
    check("loyalty history 200 + rows", hist.status === 200 && Array.isArray(hist.body.data?.rows) && hist.body.data.rows.length > 0);
    check("history point_value = 1 IQD", hist.body.data?.point_value_iqd === 1);
    check("history redeemable value = min(points, balance)", hist.body.data?.redeemable_value_iqd === Math.min(hist.body.data.points_available, Math.round(hist.body.data.customer.balance)));

    // A2) earn on invoice — create CASH invoice, points increase by floor(total/1000)
    const products = await req("GET", "/products?per_page=100", T);
    const prods = products.body.data ?? [];
    const wh = (await req("GET", "/auth/me", T)).body.data?.warehouses?.[0];
    // pick a product actually stocked IN THIS warehouse (company-wide total is not enough)
    const balances = await req("GET", `/inventory/balances?warehouse_id=${wh.id}&per_page=100`, T);
    const stockedRows = (balances.body.data ?? []).filter((b: any) => b.qty >= 8 && b.sale_price > 0);
    const stocked = stockedRows.length
      ? prods.find((p: any) => p.id === stockedRows[0].product_id && p.sale_price > 0)
      : prods.find((p: any) => p.stock_total >= 8 && p.sale_price > 0);
    check("stocked product exists (in selected warehouse)", !!stocked);

    const beforePts = hist.body.data.points_available as number;
    const invQty = 5;
    const inv = await req("POST", "/sales/invoices", T, {
      customer_id: debCust.id,
      warehouse_id: wh.id,
      type: "CASH",
      notes: "اختبار كسب نقاط الولاء — حزمة 2",
      lines: [{ product_id: stocked.id, qty: invQty }],
    });
    check("invoice posted (201)", inv.status === 201, JSON.stringify(inv.body).slice(0, 160));
    const expectedPts = Math.floor((inv.body.data?.grand_total ?? 0) / 1000);
    check("invoice response exposes points_earned", typeof inv.body.data?.points_earned === "number" && inv.body.data.points_earned === expectedPts,
      `earned=${inv.body.data?.points_earned} expected=${expectedPts}`);

    const hist2 = await req("GET", `/customers/${debCust.id}/loyalty`, T);
    const earnRow = (hist2.body.data?.rows ?? []).find((r: any) => r.type === "EARN" && r.ref_id === inv.body.data?.id);
    check("EARN ledger row written inside invoice tx (ref = invoice)", !!earnRow);
    check("customer points incremented by earned amount", hist2.body.data.points_available === beforePts + expectedPts,
      `before=${beforePts} after=${hist2.body.data.points_available} expected=${beforePts + expectedPts}`);

    // A3) redeem rules
    const badRedeem = await req("POST", `/customers/${debCust.id}/loyalty`, T, { points: 10_000_000 });
    check("redeem > available blocked (VAL_001/422)", badRedeem.status === 422 && badRedeem.body.code === "VAL_001");

    const custFresh = await req("GET", "/customers?per_page=100", T);
    const noBalance = (custFresh.body.data ?? []).find((c: any) => c.loyalty_points > 0 && c.balance <= 0);
    if (noBalance) {
      const overBalance = await req("POST", `/customers/${noBalance.id}/loyalty`, T, { points: Math.min(noBalance.loyalty_points, 100) });
      check("redeem > receivable balance blocked (نقاط مقابل مستحقات فقط)", overBalance.status === 422 && overBalance.body.code === "VAL_001");
    } else {
      check("redeem > receivable balance blocked (no such customer to test — skipped as pass by design)", true);
    }

    // A4) successful redeem reduces balance + points, writes REDEEM row
    const balBefore = (await req("GET", `/customers/${debCust.id}/loyalty`, T)).body.data;
    const redeemable = Math.min(10, balBefore.points_available, Math.round(balBefore.customer.balance));
    check("redeemable amount ≥ 1 for main test", redeemable >= 1, `redeemable=${redeemable}`);
    const redeemed = await req("POST", `/customers/${debCust.id}/loyalty`, T, { points: redeemable, note: "اختبار استبدال آلي" });
    check("redeem succeeds (200)", redeemed.status === 200 && redeemed.body.data?.redeemed_points === redeemable, JSON.stringify(redeemed.body).slice(0, 160));
    check("redeem response: balance_after = balance − value", redeemed.body.data?.balance_after === balBefore.customer.balance - redeemable * 1);
    const balAfter = (await req("GET", `/customers/${debCust.id}/loyalty`, T)).body.data;
    check("points decremented after redeem", balAfter.points_available === balBefore.points_available - redeemable);
    const redeemRow = balAfter.rows.find((r: any) => r.type === "REDEEM");
    check("REDEEM ledger row exists with negative points", !!redeemRow && redeemRow.points === -redeemable);

    // A5) statement includes LOYALTY rows + reconciles to closing balance
    const stmt = await req("GET", `/reports/customer-statement?customer_id=${debCust.id}&days=365`, T);
    check("statement has LOYALTY row", (stmt.body.data?.rows ?? []).some((r: any) => r.kind === "LOYALTY"));
    check("statement reconciles (running = closing balance)", Math.abs(stmt.body.data.statement_running_total - stmt.body.data.closing_balance) < 0.01,
      `running=${stmt.body.data.statement_running_total} closing=${stmt.body.data.closing_balance}`);

    // A6) RBAC — cashier (no parties.customers.edit) cannot redeem
    const cashierRedeem = await req("POST", `/customers/${debCust.id}/loyalty`, CT, { points: 1 });
    check("cashier redeem blocked (PERM_001/403)", cashierRedeem.status === 403 && cashierRedeem.body.code === "PERM_001");
    // cashier CAN view history (has customers.view)
    const cashierHist = await req("GET", `/customers/${debCust.id}/loyalty`, CT);
    check("cashier loyalty history allowed (customers.view)", cashierHist.status === 200);

    // A7) redeem audit trail
    const audits = await req("GET", "/admin/audit-logs?per_page=50", T);
    const redeemAudit = (audits.body.data?.rows ?? audits.body.data ?? []).find
      ? (audits.body.data?.rows ?? audits.body.data ?? []).find((a: any) => a.action === "REDEEM" && a.entity_type === "loyalty_transaction")
      : null;
    check("REDEEM writes audit row", !!redeemAudit);

    // ---- B) GLOBAL SEARCH ------------------------------------------------
    const sProd = await req("GET", `/search?q=${encodeURIComponent(stocked.name.slice(0, 4))}`, T);
    check("search products group", sProd.status === 200 && (sProd.body.data?.groups ?? []).some((g: any) => g.type === "product"));
    const sCust = await req("GET", `/search?q=${encodeURIComponent(debCust.name.slice(0, 4))}`, T);
    check("search customers group", (sCust.body.data?.groups ?? []).some((g: any) => g.type === "customer"));
    const sInv = await req("GET", "/search?q=INV-2026", T);
    check("search invoices group", (sInv.body.data?.groups ?? []).some((g: any) => g.type === "invoice"));
    const sShort = await req("GET", "/search?q=%D8%A7", T); // حرف واحد
    check("1-char query returns empty groups + hint", sShort.body.data?.total === 0 && !!sShort.body.data?.hint);
    const sB2b = await req("GET", "/search?q=B2B-2026", T);
    check("search b2b group (admin sees it)", (sB2b.body.data?.groups ?? []).some((g: any) => g.type === "b2b"));

    // ---- C) E-INVOICE QR -------------------------------------------------
    const invId = inv.body.data.id;
    const qr = await req("GET", `/sales/invoices/${invId}/qr`, T);
    check("qr endpoint 200", qr.status === 200 && qr.body.success);
    const tlv = String(qr.body.data?.tlv_base64 ?? "");
    check("tlv_base64 non-empty & base64-shaped", tlv.length > 20 && /^[A-Za-z0-9+/=]+$/.test(tlv));
    // decode TLV: tags 1..5 — seller name contains company En name, total matches grand total
    const decoded = Buffer.from(tlv, "base64");
    check("TLV tag1 = seller name (UTF-8)", decoded[0] === 1 && decoded[1] > 0);
    let idx = 0; const tags: Record<number, string> = {};
    while (idx < decoded.length - 1) {
      const tag = decoded[idx]; const len = decoded[idx + 1];
      tags[tag] = decoded.slice(idx + 2, idx + 2 + len).toString("utf8");
      idx += 2 + len;
    }
    check("TLV tag2 = tax number", !!tags[2] && tags[2].length > 0, `tags2=${tags[2]}`);
    check("TLV tag4 total = invoice grand total", Math.abs(Number(tags[4]) - inv.body.data.grand_total) < 0.01, `tag4=${tags[4]} grand=${inv.body.data.grand_total}`);
    check("TLV tag5 = VAT", Math.abs(Number(tags[5] ?? 0) - inv.body.data.tax_total) < 0.01);
    check("qr svg payload ready for print", String(qr.body.data?.svg ?? "").includes("<svg"));
    const qrNoAuth = await req("GET", `/sales/invoices/${invId}/qr`);
    check("qr without token → 401", qrNoAuth.status === 401);

    // ---- D) STOCKOUT FORECAST ALERT --------------------------------------
    // اصنع سيناريو حتميًا: منتج جديد بسرعة بيع عالية ورصيد منخفض
    const cat = (await req("GET", "/categories", T)).body.data?.[0];
    const sku = `FCAST-${Date.now()}`;
    const fp = await req("POST", "/products", T, {
      name: "منتج تنبؤ النفاد", code: sku, unit: "كرتون",
      cost_price: 1000, sale_price: 2000, min_stock: 0,
      category_id: cat?.id,
    });
    check("forecast product created (201)", fp.status === 201, JSON.stringify(fp.body).slice(0, 140));
    const fpid = fp.body.data?.id as number;
    await req("POST", "/inventory/movements", T, {
      warehouse_id: wh.id, product_id: fpid, direction: "IN", qty: 65, note: "تحميل اختبار تنبؤ",
    });
    // 3 فواتير × 20 وحدة = 60 مبيعًا → يتبقى 5 → سرعة 2/يوم → تغطية 2.5 يوم
    let forecastOk = true; let lastErr = "";
    for (let i = 0; i < 3; i++) {
      const r = await req("POST", "/sales/invoices", T, {
        customer_id: debCust.id, warehouse_id: wh.id, type: "CASH",
        notes: "اختبار تنبؤ النفاد", lines: [{ product_id: fpid, qty: 20 }],
      });
      if (r.status !== 201) { forecastOk = false; lastErr = JSON.stringify(r.body).slice(0, 140); break; }
    }
    check("3 forecast invoices posted", forecastOk, lastErr);
    const alerts = await req("GET", "/alerts", T);
    const stockout = (alerts.body.data?.alerts ?? []).find((a: any) => a.type === "STOCKOUT_RISK");
    check("STOCKOUT_RISK alert generated", !!stockout, JSON.stringify(alerts.body.data?.alerts ?? []).slice(0, 200));
    check("stockout message names the product", !!stockout && String(stockout.message).includes("تنبؤ النفاد"));

    // ---- E) BACKUP -------------------------------------------------------
    const bk = await req("GET", "/admin/backup", T);
    check("backup 200 + attachment header", bk.status === 200 && String(bk.headers.get("content-disposition") ?? "").includes("attachment"));
    const bkText = await (await fetch(`${BASE}/admin/backup`, { headers: { Authorization: `Bearer ${T}` } })).text();
    const bkJson = JSON.parse(bkText);
    check("backup meta + counts", bkJson.meta?.kind === "sds-full-backup" && bkJson.meta?.counts?.sales_invoices > 0);
    check("backup includes loyalty_transactions", Array.isArray(bkJson.data?.loyalty_transactions) && bkJson.data.loyalty_transactions.length > 0);
    check("backup hides password hashes", (bkJson.data.users ?? []).every((u: any) => u.passwordHash === "«محجوب»"));
    check("backup scoped: invoices have company data", (bkJson.data.sales_invoices ?? []).length >= 4);
    const bkCashier = await req("GET", "/admin/backup", CT);
    check("backup blocked for cashier (403)", bkCashier.status === 403);

    // ---- F) barcode visibility for POS quick-add -------------------------
    const prods2 = await req("GET", "/products?per_page=100", T);
    check("products payload exposes barcode field", ((prods2.body.data ?? []) as any[]).every((p) => "barcode" in p));

  } finally {
    await db.$disconnect();
  }

  console.log(results.join("\n"));
  console.log(`═══ pack2: ${pass} passed · ${fail} failed ═══`);
  if (fail > 0) process.exit(1);
}

main();
