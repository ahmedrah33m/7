#!/bin/bash
# Dev watchdog: keeps the Next.js dev server alive in the sandbox.
# Installed as a cron job — safe to run every minute.
LOG=/tmp/next-dev.log
if ! curl -s -m 3 http://127.0.0.1:3000/api/v1/health > /dev/null 2>&1; then
  cd /home/z/my-project
  nohup bun run dev >> "$LOG" 2>&1 < /dev/null &
fi
