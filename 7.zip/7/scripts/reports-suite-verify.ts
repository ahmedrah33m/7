// =====================================================================
// Reports suite acceptance (Task 27) — مجموعة التقارير الشاملة 26 تقريرًا:
//   · 33 نوع تقرير على /api/v1/reports/[type] — 200 + shape لكل نوع
//   · عينات حية: شراء إدخال + فاتورة نقدية بخصم (سماح) + فاتورة آجلة
//     بدون سداد + تحصيل + مصروف + مواد أولية + مادة تحت حد الطلب
//   · اتساق محاسبي: افتتاحي + وارد − صادر = ختامي (حركة مادة/صندوق)
//   · عزل الفروع: مدير فرع جديد لا يرى زبائن/مخزون بغداد
//   · صلاحيات: الكاشير محجوب عن التقارير (403)
// Exit 0 = all pass.
// =====================================================================

import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000/api/v1";
const db = new PrismaClient();

let pass = 0;
let fail = 0;
const created = {
  products: [] as number[],
  customers: [] as number[],
  branchId: 0,
  managerUsername: "",
};

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  ✅ ${name}`);
  } else {
    fail++;
    console.log(`  ❌ ${name} ${detail ? "— " + detail : ""}`);
  }
}

async function req(method: string, path: string, token?: string, body?: unknown): Promise<{ status: number; body: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json };
}

const D = (b: any) => b?.data;

async function main() {
  console.log("═══ Reports suite verification (Task 27) ═══");
  const rand = Date.now().toString().slice(-6);
  const today = new Date().toISOString().slice(0, 10);

  // ─────────── 0) الدخول ───────────
  console.log("\n— الدخول —");
  const admin = await req("POST", "/auth/login", undefined, { username: "admin", password: "Admin@123" });
  check("admin login", admin.status < 300 && admin.body.success);
  const T = admin.body.data?.access_token as string;

  // ─────────── 1) العينات الحية ───────────
  console.log("\n— بناء العينات: مواد + شراء + مبيعات + نقدية —");

  // مادة أولية
  const rawP = await req("POST", "/products", T, { name: `سكر خام ت-${rand}`, product_type: "RAW", unit: "كيس", cost_price: 500, sale_price: 600 });
  check("create RAW product", rawP.status === 201 && D(rawP.body)?.id, `${rawP.status}`);
  const RAW_ID = D(rawP.body)?.id as number;
  created.products.push(RAW_ID);

  // مادة تامة للبيع
  const finP = await req("POST", "/products", T, { name: `زيت دوار شمس ت-${rand}`, unit: "كرتون", cost_price: 1000, sale_price: 1500, min_stock: 5 });
  check("create FINISHED product", finP.status === 201 && D(finP.body)?.id);
  const FIN_ID = D(finP.body)?.id as number;
  created.products.push(FIN_ID);

  // مادة تحت حد الطلب (إدخال 20 بحد 100 → عجز 80)
  const lowP = await req("POST", "/products", T, { name: `منظف ت-${rand}`, unit: "كرتون", cost_price: 2000, sale_price: 2600, min_stock: 100 });
  check("create below-reorder product", lowP.status === 201 && D(lowP.body)?.id);
  const LOW_ID = D(lowP.body)?.id as number;
  created.products.push(LOW_ID);

  // مورد (أول مورد من البذرة)
  const sup = await db.supplier.findFirst({ where: { deletedAt: null }, select: { id: true } });
  check("seed supplier exists", !!sup);

  // فاتورة شراء: إدخال 100 زيت @1000 + 200 سكر @500 + 20 منظف @2000 — مستودع بغداد الرئيسي
  const purch = await req("POST", "/purchases/invoices", T, {
    supplier_id: sup!.id, warehouse_id: 1, paid_amount: 150000, type: "CREDIT",
    lines: [
      { product_id: FIN_ID, qty: 100, unit_cost: 1000 },
      { product_id: RAW_ID, qty: 200, unit_cost: 500 },
      { product_id: LOW_ID, qty: 20, unit_cost: 2000 },
    ],
  });
  check("purchase intake posted", purch.status === 201, `${purch.status} ${JSON.stringify(purch.body?.error ?? "")}`);

  // فاتورة نقدية بخصم بند 10% (سماح): 30 زيت @1500
  const cashInv = await req("POST", "/sales/invoices", T, {
    customer_id: 1, warehouse_id: 1, type: "CASH",
    lines: [{ product_id: FIN_ID, qty: 30, unit_price: 1500, discount_pct: 10 }],
  });
  check("cash invoice with line discount", cashInv.status === 201, `${cashInv.status} ${JSON.stringify(cashInv.body?.error ?? "")}`);
  const INV_NUM = D(cashInv.body)?.number as string | undefined;
  const INV_TOTAL = Number(D(cashInv.body)?.grand_total ?? 0);
  // lineTotal = 30×1500×0.9 = 40500
  check("discounted total = 40,500", INV_TOTAL === 40500, `got ${INV_TOTAL}`);

  // فاتورة آجلة بلا سداد لزبون 2 → مدين + متأخر لاحقًا
  const credInv = await req("POST", "/sales/invoices", T, {
    customer_id: 2, warehouse_id: 1, type: "CREDIT", paid_amount: 0,
    lines: [{ product_id: FIN_ID, qty: 5, unit_price: 1500 }],
  });
  check("credit invoice unpaid", credInv.status === 201);
  const CRED_NUM = D(credInv.body)?.number as string | undefined;

  // تحصيل نقدي حر 15,000 لزبون 2
  const coll = await req("POST", "/finance/transactions", T, { kind: "collection", customer_id: 2, cashbox_id: 1, amount: 15000, note: "تحصيل عينة تقارير" });
  check("collection posted", coll.status === 201, `${coll.status}`);

  // مصروف 5,000
  const exp = await req("POST", "/finance/transactions", T, { kind: "expense", cashbox_id: 1, amount: 5000, title: "نقل عينة تقارير" });
  check("expense posted", exp.status === 201, `${exp.status}`);

  // زبون بغداد + زبون بصرة (للعزل)
  const custBgw = await req("POST", "/customers", T, { name: `زبون بغداد ت-${rand}`, phone: "07700000001", branch_id: 1 });
  check("create Baghdad customer", custBgw.status === 201 && D(custBgw.body)?.id);
  created.customers.push(D(custBgw.body)?.id);

  const custBsr = await req("POST", "/customers", T, { name: `زبون بصرة ت-${rand}`, phone: "07700000002", branch_id: 2 });
  check("create Basra customer", custBsr.status === 201 && D(custBsr.body)?.id);
  created.customers.push(D(custBsr.body)?.id);

  // ─────────── 2) كل الأنواع الثلاثة والثلاثون → 200 ───────────
  console.log("\n— الاتصال بكل أنواع التقارير —");
  const ALL_TYPES = [
    "customer-statement", "customers-list", "customers-balances", "receivables-due", "profit-by-customer",
    "item-movement", "stock-balances", "below-reorder", "raw-materials", "products-catalog", "selling-prices",
    "sales-by-product", "profit-by-product",
    "daily-summary", "sales-analysis", "sales-by-month", "allowances", "sales-daily", "top-products",
    "purchases-analysis", "purchases-by-month", "purchase-daily",
    "cashbox-statement", "receipts", "payments", "balance-sheet", "profit-analysis", "vat-summary", "valuation",
    "rep-performance", "warehouse-keepers", "aging", "damages-summary",
  ];
  const results = new Map<string, { status: number; body: any }>();
  for (const t of ALL_TYPES) {
    const url =
      t === "item-movement" ? `/reports/${t}?product_id=${FIN_ID}&from=2020-01-01&to=${today}`
      : t === "customer-statement" ? `/reports/${t}?customer_id=2&from=2020-01-01&to=${today}`
      : t === "cashbox-statement" ? `/reports/${t}?cashbox_id=1&from=2020-01-01&to=${today}`
      : `/reports/${t}?from=2020-01-01&to=${today}`;
    const r = await req("GET", url, T);
    results.set(t, r);
    check(`GET ${t} → 200`, r.status === 200 && r.body.success, `${r.status} ${JSON.stringify(r.body?.error ?? "").slice(0, 90)}`);
  }

  // ─────────── 3) فحوص الاتساق والمحتوى ───────────
  console.log("\n— اتساق المحتوى —");

  // حركة المادة: افتتاحي + وارد − صادر = ختامي
  const mv = D(results.get("item-movement")!.body);
  check("item-movement: opening + in − out = closing", Math.abs(mv.opening_balance + mv.total_in - mv.total_out - mv.closing_balance) < 0.01,
    `${mv.opening_balance}+${mv.total_in}-${mv.total_out}≠${mv.closing_balance}`);
  check("item-movement: rows has intake+sale (≥2)", mv.rows.length >= 2, `${mv.rows?.length}`);
  check("item-movement: closing = 65 (100−30−5 آجل)", Math.abs(mv.closing_balance - 65) < 0.001, `${mv.closing_balance}`);
  check("item-movement: sales qty = 35 (نقدي+آجل)", Math.abs(mv.sales_in_period.qty - 35) < 0.001);
  check("item-movement: purchases value = 100,000", Math.abs(mv.purchases_in_period.value - 100000) < 0.01);

  // السماحات: الفاتورة بخصم البند موجودة (4500 = 40500−45000)
  const al = D(results.get("allowances")!.body);
  check("allowances: includes discounted invoice", al.rows.some((r: any) => r.number === INV_NUM && Math.abs(r.discount_total - 4500) < 0.01), JSON.stringify(al.rows?.slice(0, 2)));
  check("allowances: total ≥ 4500", al.totals.total_discount >= 4500 - 0.01);

  // الزبائن
  const cl = D(results.get("customers-list")!.body);
  check("customers-list: sees Basra customer (owner)", cl.rows.some((r: any) => r.name.includes(`زبون بصرة ت-${rand}`)));
  check("customers-list: invoices_count on customer 2 ≥ 1", cl.rows.find((r: any) => r.code === "C-00002")?.invoices_count >= 1);

  const cb = D(results.get("customers-balances")!.body);
  check("customers-balances: C-00002 is مدين", cb.rows.some((r: any) => r.code === "C-00002" && r.balance > 0 && r.direction.includes("مدين")));
  check("customers-balances: debit_total ≥ 7500 (آجلة − تحصيل)", cb.totals.debit_total >= 7500 - 0.01, `${cb.totals.debit_total}`);

  // الجرد
  const sb = D(results.get("stock-balances")!.body);
  check("stock-balances: FIN qty = 65 (100−30−5)", Math.abs(sb.rows.find((r: any) => r.product_id === FIN_ID)?.total_qty - 65) < 0.001);
  check("stock-balances: cost_value totals > 0", sb.totals.cost_value > 0);

  const br = D(results.get("below-reorder")!.body);
  check("below-reorder: LOW shortage = 80", Math.abs(br.rows.find((r: any) => r.product_id === LOW_ID)?.shortage - 80) < 0.001);
  check("below-reorder: FIN not included (65 ≥ 5)", !br.rows.some((r: any) => r.product_id === FIN_ID));

  const rm = D(results.get("raw-materials")!.body);
  check("raw-materials: includes RAW product", rm.rows.some((r: any) => r.product_id === RAW_ID));
  check("raw-materials: excludes FINISHED", !rm.rows.some((r: any) => r.product_id === FIN_ID));

  // المخططات والتحليلات
  const sm = D(results.get("sales-by-month")!.body);
  const thisMonth = today.slice(0, 7);
  const mRow = sm.rows.find((r: any) => r.month === thisMonth);
  check("sales-by-month: this month ≥ 40500+7500", mRow && mRow.total >= 48000 - 0.01, `${mRow?.total}`);
  check("sales-by-month: 12 rows", sm.rows.length === 12);

  const pm = D(results.get("purchases-by-month")!.body);
  const pRow = pm.rows.find((r: any) => r.month === thisMonth);
  check("purchases-by-month: this month ≥ 240000", pRow && pRow.total >= 240000 - 0.01, `${pRow?.total}`);

  const sa = D(results.get("sales-analysis")!.body);
  check("sales-analysis: revenue ≥ 48000", sa.totals.revenue >= 48000 - 0.01);
  check("sales-analysis: top_customers non-empty", sa.top_customers.length > 0);

  const pa = D(results.get("purchases-analysis")!.body);
  check("purchases-analysis: total ≥ 240000", pa.totals.total >= 240000 - 0.01);
  check("purchases-analysis: due ≥ 90000 (عينتنا غير مسددة ضمن الكل)", pa.totals.due >= 90000 - 0.01, `${pa.totals.due}`);

  const pf = D(results.get("profit-analysis")!.body);
  check("profit-analysis: revenue ≥ 48000", pf.totals.revenue >= 48000 - 0.01);
  check("profit-analysis: gross = revenue − cogs", Math.abs(pf.totals.gross_profit - (pf.totals.revenue - pf.totals.cogs)) < 0.02);
  check("profit-analysis: cogs ≥ 35000 (بنودنا ضمن الفترة)", pf.totals.cogs >= 35000 - 0.02, `${pf.totals.cogs}`);

  // المدفوعات والمقبوضات
  const pay = D(results.get("payments")!.body);
  check("payments: includes expense 5000", pay.rows.some((r: any) => r.category.includes("مصروف") && Math.abs(r.amount - 5000) < 0.01));
  check("payments: expenses_total ≥ 5000", pay.totals.expenses_total >= 5000 - 0.01);

  const rec = D(results.get("receipts")!.body);
  check("receipts: includes collection 15000", rec.rows.some((r: any) => Math.abs(r.amount - 15000) < 0.01));
  check("receipts: total_in ≥ 15000", rec.totals.total_in >= 15000 - 0.01);

  // الصندوق
  const cs = D(results.get("cashbox-statement")!.body);
  check("cashbox-statement: opening + in − out = closing", Math.abs(cs.opening_balance + cs.total_in - cs.total_out - cs.closing_balance) < 0.02,
    `${cs.opening_balance}+${cs.total_in}-${cs.total_out}≠${cs.closing_balance}`);
  check("cashbox-statement: closing = current book balance", Math.abs(cs.closing_balance - cs.current_book_balance) < 0.02,
    `${cs.closing_balance} vs ${cs.current_book_balance}`);
  check("cashbox-statement: rows ≥ 2 (تحصيل + مصروف)", cs.rows.length >= 2);

  // الأرباح حسب المواد والزبائن
  const pbp = D(results.get("profit-by-product")!.body);
  const finRow = pbp.rows.find((r: any) => r.product_id === FIN_ID);
  check("profit-by-product: FIN revenue = 48000", finRow && Math.abs(finRow.revenue - 48000) < 0.02, `${finRow?.revenue}`);
  check("profit-by-product: FIN profit = 13000", finRow && Math.abs(finRow.profit - 13000) < 0.02, `${finRow?.profit}`);
  check("profit-by-product: margin = 27.08%", finRow && Math.abs(finRow.margin_pct - 27.08) < 0.05, `${finRow?.margin_pct}`);

  const pbc = D(results.get("profit-by-customer")!.body);
  check("profit-by-customer: revenue ≥ 48000 (فواتيرنا ضمن الإجمالي)", pbc.totals.revenue >= 48000 - 0.02, `${pbc.totals.revenue}`);
  check("profit-by-customer: rows shape (code+name+profit)", pbc.rows.length > 0 && "code" in pbc.rows[0] && "profit" in pbc.rows[0]);

  // الكتالوج والأسعار
  const cat = D(results.get("products-catalog")!.body);
  check("products-catalog: includes RAW with نوع أولية", cat.rows.some((r: any) => r.id === RAW_ID && r.product_type === "أولية"));
  check("products-catalog: FIN stock_total = 65", Math.abs(cat.rows.find((r: any) => r.id === FIN_ID)?.stock_total - 65) < 0.001);

  const sp = D(results.get("selling-prices")!.body);
  check("selling-prices: FIN margin = 33.33%", Math.abs(sp.rows.find((r: any) => r.id === FIN_ID)?.margin_pct - 33.33) < 0.05);

  // اليومي والموازنة
  const ds = D(results.get("daily-summary")!.body);
  check("daily-summary: sales ≥ 48000", ds.sales.total >= 48000 - 0.01);
  check("daily-summary: cash net = receipts − payments (اتساق داخلي)", Math.abs(ds.cash.net - (ds.cash.receipts_total - ds.cash.payments_total)) < 0.02, `${ds.cash.net}`);

  const bs = D(results.get("balance-sheet")!.body);
  check("balance-sheet: equity = assets − liabilities", Math.abs(bs.equity - (bs.assets.total - bs.liabilities.total)) < 0.02);
  check("balance-sheet: assets > 0", bs.assets.total > 0);

  // المتأخرون وكشف الحساب
  const rd = D(results.get("receivables-due")!.body);
  check("receivables-due: credit invoice present", rd.rows.some((r: any) => r.number === CRED_NUM && Math.abs(r.due_amount - 7500) < 0.01));

  const st = D(results.get("customer-statement")!.body);
  check("customer-statement: credit invoice + collection rows", st.rows.some((r: any) => r.ref === CRED_NUM) && st.rows.some((r: any) => r.kind === "COLLECTION"));
  check("customer-statement: closing = customer balance", Math.abs(st.closing_balance - (st.statement_running_total)) < 0.05, `${st.closing_balance} vs ${st.statement_running_total}`);

  // المؤردين
  const wk = D(results.get("warehouse-keepers")!.body);
  check("warehouse-keepers: rows array shape", Array.isArray(wk.rows));

  // ─────────── 4) عزل الفروع ───────────
  console.log("\n— عزل الفروع (مدير فرع جديد) —");
  const br2 = await req("POST", "/admin/branches", T, {
    code: `T${rand}`, name: `فرع تقارير ${rand}`, city: "الموصل",
    manager: { username: `mgr.rep${rand}`, password: "RepMgr@123", full_name: "مدير تقارير" },
  });
  check("create branch with manager", br2.status === 201 && D(br2.body)?.id, `${br2.status} ${JSON.stringify(br2.body?.error ?? "").slice(0, 80)}`);
  created.branchId = D(br2.body)?.id ?? 0;
  created.managerUsername = `mgr.rep${rand}`;

  const mgr = await req("POST", "/auth/login", undefined, { username: `mgr.rep${rand}`, password: "RepMgr@123" });
  check("branch manager login", mgr.status < 300 && mgr.body.success);
  const MT = mgr.body.data?.access_token as string;

  const mcl = await req("GET", "/reports/customers-list", MT);
  const mclData = D(mcl.body);
  check("manager: customers-list 200", mcl.status === 200);
  check("manager: does NOT see Baghdad customer", !mclData?.rows?.some((r: any) => r.name.includes(`زبون بغداد ت-${rand}`)));
  check("manager: does NOT see Basra customer", !mclData?.rows?.some((r: any) => r.name.includes(`زبون بصرة ت-${rand}`)));

  const msb = await req("GET", "/reports/stock-balances", MT);
  const msbData = D(msb.body);
  check("manager: stock-balances 200", msb.status === 200);
  check("manager: FIN product (بغداد) hidden", !msbData?.rows?.some((r: any) => r.product_id === FIN_ID));

  const msales = await req("GET", `/reports/sales-analysis?from=2020-01-01&to=${today}`, MT);
  check("manager: sales-analysis revenue = 0 (لا مبيعات فرعه)", msales.status === 200 && Number(D(msales.body)?.totals?.revenue ?? -1) === 0,
    `${D(msales.body)?.totals?.revenue}`);

  // ─────────── 5) الصلاحيات ───────────
  console.log("\n— الصلاحيات —");
  const cash = await req("POST", "/auth/login", undefined, { username: "cashier", password: "Cashier@123" });
  check("cashier login", cash.status < 300);
  const CT = cash.body.data?.access_token as string;
  const blocked = await req("GET", "/reports/customers-list", CT);
  check("cashier blocked from reports (403)", blocked.status === 403, `${blocked.status}`);
  const blocked2 = await req("GET", "/reports/balance-sheet", CT);
  check("cashier blocked from balance-sheet (403)", blocked2.status === 403, `${blocked2.status}`);

  // نوع غير معروف
  const unknown = await req("GET", "/reports/does-not-exist", T);
  check("unknown type → VAL_003", unknown.status === 404 || unknown.status === 400, `${unknown.status}`);

  // ─────────── 6) التنظيف ───────────
  console.log("\n— تنظيف العينات —");
  const del = await db.product.updateMany({ where: { id: { in: created.products } }, data: { deletedAt: new Date() } });
  const delC = await db.customer.updateMany({ where: { id: { in: created.customers } }, data: { deletedAt: new Date() } });
  check("soft-deleted fixtures", del.count === created.products.length && delC.count === created.customers.length,
    `p:${del.count} c:${delC.count}`);

  console.log(`\n═══ Result: ${pass}/${pass + fail} ═══`);
  if (fail > 0) process.exit(1);
}

main()
  .catch((e) => {
    console.error("FATAL:", e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
