# جراحة عرض الجدول: أعمدة كراتين/حبات + سعرَي الكرتونة/الحبة
P = "/home/z/my-project/src/components/sales/new-invoice-tab.tsx"
src = open(P, encoding="utf-8").read()

def rep(old, new, tag):
    global src
    assert src.count(old) == 1, f"[{tag}] anchor count = {src.count(old)}"
    src = src.replace(old, new)
    print(f"  ✓ {tag}")

# ---- 1) رأس الجدول ------------------------------------------------------------
rep('''                    <th className="p-2 font-medium min-w-52">المنتج</th>
                    <th className="p-2 font-medium w-44">الكمية + الوحدة</th>
                    <th className="p-2 font-medium w-32">السعر + الأساس</th>
                    <th className="p-2 font-medium w-20">خصم %</th>''',
'''                    <th className="p-2 font-medium min-w-52">المنتج</th>
                    <th className="p-2 font-medium w-24">عدد الكراتين</th>
                    <th className="p-2 font-medium w-24">عدد الحبات/الوحدات</th>
                    <th className="p-2 font-medium w-28">سعر الكرتونة</th>
                    <th className="p-2 font-medium w-28">سعر الحبة</th>
                    <th className="p-2 font-medium w-20">خصم %</th>''', "thead")

# ---- 2) فتح الخريطة: p في النطاق بدل تدمير linePrices --------------------------
rep('''                  {lines.map((l) => {
                    const packed = hasPack(l);
                    const { piecePrice, pkgPrice } = linePrices(l);
                    const stockInfo = l.product_id !== "" ? preview?.packages?.[String(l.product_id)] : undefined;''',
'''                  {lines.map((l) => {
                    const packed = hasPack(l);
                    const p = productById(l.product_id);
                    const stockInfo = l.product_id !== "" ? preview?.packages?.[String(l.product_id)] : undefined;''', "map-open")

# ---- 3) كتلة معلومات المنتج المعبأ: أسعار المنتج الافتراضية --------------------
rep('''                          {packed && (() => {
                            const p = productById(l.product_id);
                            if (!p) return null;
                            // §11: كتلة الوحدات والأسعار — لا تُظهر «1 كرتون = 11 كرتون» أبدًا''',
'''                          {packed && p && (() => {
                            // §11: كتلة الوحدات والأسعار — لا تُظهر «1 كرتون = 11 كرتون» أبدًا''', "info-guard")

rep('''                            const pkgSrc = p.pack_sale_currency === "USD" && p.pack_sale_amount != null ? ` (${formatUSD(p.pack_sale_amount)})` : "";
                            const pieceSrc = p.sale_currency === "USD" && p.sale_amount != null ? ` (${formatUSD(p.sale_amount)})` : "";
                            return (''',
'''                            const pkgSrc = p.pack_sale_currency === "USD" && p.pack_sale_amount != null ? ` (${formatUSD(p.pack_sale_amount)})` : "";
                            const pieceSrc = p.sale_currency === "USD" && p.sale_amount != null ? ` (${formatUSD(p.sale_amount)})` : "";
                            const pkgDefault = packSalePriceOf(l) ?? Math.round(packQtyOf(l) * p.sale_price * 100) / 100;
                            return (''', "info-defaults")

rep('''                                <div>سعر {p.unit}: <span className="font-medium">{money(piecePrice)}</span>{pieceSrc} · سعر {packUnitSafe}: <span className="font-semibold text-foreground">{pkgPrice != null ? money(pkgPrice) : "—"}</span>{pkgSrc}</div>''',
'''                                <div>سعر {p.unit}: <span className="font-medium">{money(p.sale_price)}</span>{pieceSrc} · سعر {packUnitSafe}: <span className="font-semibold text-foreground">{money(pkgDefault)}</span>{pkgSrc}</div>''', "info-prices")

# ---- 4) خلية الكمية القديمة → خليتا الكراتين والحبات ---------------------------
rep('''                        <td className="p-2">
                          <div className="flex gap-1">
                            <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={String(l.qty)} onChange={(e) => setLine(l.key, { qty: e.target.value === "" ? "" : Number(e.target.value) })} placeholder="0" />
                            {packed ? (
                              <select
                                className={inputCls + " w-24"}
                                value={l.unit}
                                title="وحدة الكمية — القائمة داخل الخانة"
                                onChange={(e) => {
                                  const u = e.target.value as "PIECE" | "PACKAGE";
                                  setLine(l.key, { unit: u, price_basis: u });
                                }}
                              >
                                <option value="PIECE">{productById(l.product_id)?.unit ?? "حبة"}</option>
                                <option value="PACKAGE">{productById(l.product_id)?.pack_unit ?? "كرتونة"}</option>
                              </select>
                            ) : (
                              <span className="inline-flex items-center px-1 text-xs text-muted-foreground whitespace-nowrap">{productById(l.product_id)?.unit ?? "وحدة"}</span>
                            )}
                          </div>
                          {packed && baseQty(l) > 0 && (
                            <div className="text-[10px] text-muted-foreground mt-1">= {baseQty(l)} {productById(l.product_id)?.unit}</div>
                          )}
                        </td>''',
'''                        <td className="p-2">
                          {packed ? (
                            <>
                              <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={String(l.pkg_qty)} onChange={(e) => setLine(l.key, { pkg_qty: e.target.value === "" ? "" : Number(e.target.value) })} placeholder="0" />
                              <div className="text-[10px] text-muted-foreground mt-1">{p?.pack_unit ?? "عبوة"}</div>
                            </>
                          ) : (
                            <div className="text-center text-muted-foreground pt-2" title="هذا المنتج يُباع بالوحدة الأساسية فقط — بلا تعبئة كراتين">—</div>
                          )}
                        </td>
                        <td className="p-2">
                          <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={String(l.loose_qty)} onChange={(e) => setLine(l.key, { loose_qty: e.target.value === "" ? "" : Number(e.target.value) })} placeholder="0" />
                          <div className="text-[10px] text-muted-foreground mt-1">{p?.unit ?? "الوحدة"}</div>
                        </td>''', "qty-cells")

# ---- 5) خلية السعر القديمة → خليتا سعر الكرتونة وسعر الحبة ---------------------
rep('''                        <td className="p-2">
                          <div className="flex gap-1">
                            <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={String(toDisplay(l.price))} onChange={(e) => setLine(l.key, { price: e.target.value === "" ? "" : fromDisplay(Number(e.target.value)) })} />
                            {packed && (
                              <select className={inputCls + " w-20"} value={l.price_basis} onChange={(e) => setLine(l.key, { price_basis: e.target.value as "PIECE" | "PACKAGE" })} title="أساس السعر">
                                <option value="PIECE">حبة</option>
                                <option value="PACKAGE">{productById(l.product_id)?.pack_unit ?? "عبوة"}</option>
                              </select>
                            )}
                          </div>
                          {packed && (
                            <div className="text-[10px] text-muted-foreground mt-1">
                              {l.price_basis === "PIECE" ? `سعر ${productById(l.product_id)?.pack_unit}: ${money(pkgPrice ?? 0)}` : `سعر الحبة: ${money(piecePrice)}`}
                            </div>
                          )}
                        </td>''',
'''                        <td className="p-2">
                          {packed ? (
                            <>
                              <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={String(toDisplay(l.pack_price))} onChange={(e) => setLine(l.key, { pack_price: e.target.value === "" ? "" : fromDisplay(Number(e.target.value)) })} />
                              {num(l.pkg_qty) > 0 && (
                                <div className="text-[10px] text-muted-foreground mt-1">
                                  {qtyWord(num(l.pkg_qty), p?.pack_unit)} × {money(num(l.pack_price))} = <span className="font-medium" dir="ltr">{money(decNum(dec(num(l.pkg_qty)).mul(num(l.pack_price))))}</span>
                                </div>
                              )}
                            </>
                          ) : (
                            <div className="text-center text-muted-foreground pt-2">—</div>
                          )}
                        </td>
                        <td className="p-2">
                          <input type="number" min="0" step="any" className={inputCls} dir="ltr" value={String(toDisplay(l.piece_price))} onChange={(e) => setLine(l.key, { piece_price: e.target.value === "" ? "" : fromDisplay(Number(e.target.value)) })} />
                          {num(l.loose_qty) > 0 && (
                            <div className="text-[10px] text-muted-foreground mt-1">
                              {qtyWord(num(l.loose_qty), p?.unit)} × {money(num(l.piece_price))} = <span className="font-medium" dir="ltr">{money(decNum(dec(num(l.loose_qty)).mul(num(l.piece_price))))}</span>
                            </div>
                          )}
                        </td>''', "price-cells")

# ---- 6) خلية الإجمالي: صياغة كمية عربية سليمة ----------------------------------
rep('''                        <td className="p-2 font-semibold" dir="ltr">
                          {money(lineTotal(l))}
                          {l.product_id !== "" && baseQty(l) > 0 && (
                            <div className="text-[10px] font-normal text-muted-foreground mt-0.5">
                              الإجمالي: {baseQty(l)} {productById(l.product_id)?.unit}
                            </div>
                          )}
                        </td>''',
'''                        <td className="p-2 font-semibold" dir="ltr">
                          {money(lineTotal(l))}
                          {p && baseQty(l) > 0 && (
                            <div className="text-[10px] font-normal text-muted-foreground mt-0.5" dir="rtl">
                              = {qtyWord(baseQty(l), p.unit)}
                            </div>
                          )}
                        </td>''', "total-cell")

open(P, "w", encoding="utf-8").write(src)
print("عرض الجدول ✓ (6 تعديلات)")
