// تحقق واجهة الفاتورة — جولة «الكراتين والحبات بسعرين» + إعادة إظهار القائمة المنسدلة (2026-09-19)
import { chromium } from "playwright";

const BASE = "http://localhost:3000";
let pass = 0, fail = 0;
const ok = (name, cond) => { if (cond) { pass++; console.log(`  ✔ ${name}`); } else { fail++; console.log(`  ✘ ${name}`); } };
const digits = (s) => Number(String(s).replace(/[^\d]/g, "")) || 0;

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

try {
  // دخول
  await page.goto(BASE, { waitUntil: "networkidle" });
  await page.fill("input[name=username], #username, input[type=text]", "admin");
  await page.fill("input[type=password]", "Admin@123");
  await page.click("button[type=submit]");
  await page.waitForTimeout(2500);

  const token = await page.evaluate(async () => {
    const r = await fetch("/api/v1/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: "admin", password: "Admin@123" }) });
    const j = await r.json();
    return j.data.access_token;
  });

  // تجهيز منتج السيناريو الحرفي: كرتونة 12 حبة · الحبة 6000 · الكرتونة 72000 + مخزون
  // المخزون يوضع في المستودع الأول من auth/me — نفس مصدر النموذج وافتراضه
  const setup = await page.evaluate(async (t) => {
    const H = { "Content-Type": "application/json", Authorization: `Bearer ${t}` };
    const me = await fetch("/api/v1/auth/me", { headers: H }).then((r) => r.json());
    const whId = me.data?.warehouses?.[0]?.id;
    const p = await fetch("/api/v1/products", { method: "POST", headers: H, body: JSON.stringify({ name: `ز تجربة السعرين ${Date.now() % 10000}`, unit: "حبة", pack_unit: "كرتونة", pack_qty: 12, sale_price: 6000, pack_sale_price: 72000, cost_price: 4000, min_stock: 0 }) }).then((r) => r.json());
    if (!p.success) return { error: JSON.stringify(p).slice(0, 150) };
    const mv = await fetch("/api/v1/inventory/movements", { method: "POST", headers: H, body: JSON.stringify({ warehouse_id: whId, product_id: p.data.id, direction: "IN", qty: 100, unit_cost: 4000, note: "تجهيز تحقق" }) }).then((r) => r.json());
    return { id: p.data.id, name: p.data.name, whId, mv: mv.success };
  }, token);
  ok("تجهيز منتج السيناريو + مخزون 100 في مستودع النموذج", !!setup.id && setup.mv !== false);
  if (setup.error) console.log("   خطأ التجهيز:", setup.error);

  // فتح تبويب فاتورة جديدة + تثبيت مستودع التخزين صراحة
  await page.click("text=فاتورة جديدة").catch(async () => { await page.click("text=بيع").catch(() => {}); });
  await page.waitForTimeout(1800);
  if (setup.whId) {
    await page.locator("form select").first().selectOption(String(setup.whId));
    await page.waitForTimeout(400);
  }

  // 1) بحث العميل: النقر يفتح القائمة كاملة قبل أي كتابة (الشكوى الأساسية)
  const custSearch = page.locator('input[placeholder*="اكتب اسم العميل"]').first();
  ok("1) حقل بحث العميل موجود", await custSearch.count() > 0);
  await custSearch.click();
  await page.waitForTimeout(400);
  const custDropCount = await page.locator("div.fixed.shadow-lg button").count();
  ok(`1) النقر يفتح القائمة المنسدلة كاملة قبل الكتابة (${custDropCount} خيارًا)`, custDropCount > 0);
  ok("1) سهم القائمة المنسدلة ظاهر في الخانة", await page.locator('button[aria-label="فتح القائمة المنسدلة"]').count() > 0);
  await custSearch.fill("مت");
  await page.waitForTimeout(350);
  const custFiltered = await page.locator("div.fixed.shadow-lg button").count();
  ok(`1) الكتابة تصفّي القائمة (${custFiltered} نتيجة)`, custFiltered > 0 && custFiltered <= custDropCount);
  await page.keyboard.press("Escape");
  await page.waitForTimeout(200);

  // اختيار المنتج من القائمة
  const prodSearch = page.locator('input[placeholder*="اكتب اسم المنتج"]').first();
  ok("2) حقل بحث المنتج موجود", await prodSearch.count() > 0);
  await prodSearch.click();
  await prodSearch.fill("ز تجربة");
  await page.waitForTimeout(650);
  await page.locator("div.fixed.shadow-lg button").first().dispatchEvent("mousedown");
  await page.waitForTimeout(900);

  // 2) خليتا الكمية: كراتين + حبات مع تسمية الوحدة تحت كل خانة
  const row = page.locator("table tbody tr").first();
  const qtyInputs = row.locator('input[type=number]');
  const qtyCount = await qtyInputs.count();
  ok(`2) خانتان للكمية والأسعار على الأقل (${qtyCount})`, qtyCount >= 4);
  const rowText = await row.innerText();
  ok("2) تسمية الكرتونة ظاهرة تحت خانتها", /كرتونة/.test(rowText));
  ok("2) تسمية الحبة ظاهرة تحت خانتها", /حبة/.test(rowText));

  // 3) كتلة المعلومات: التحويل والأسعار الافتراضية
  const infoCell = await row.locator("td").first().innerText();
  ok("3) كتلة المعلومات تعرض التحويل (1 كرتونة = 12 حبة)", /التحويل:\s*1\s*كرتونة\s*=\s*12\s*حبة/.test(infoCell.replace(/\n/g, " ")));
  ok("3) كتلة المعلومات تعرض سعر الحبة وسعر الكرتونة", /سعر/.test(infoCell) && /72,000|72000/.test(infoCell));

  // الأسعار المعبأة تلقائيًا: سعر الكرتونة 72000 · سعر الحبة 6000
  const vals = await row.locator('input[type=number]').evaluateAll((els) => els.map((e) => e.value));
  // [كراتين، حبات، سعر كرتونة، سعر حبة، خصم%، خصم مبلغ]
  ok(`3) سعر الكرتونة مُعبأ تلقائيًا = 72000 (${vals[2]})`, digits(vals[2]) === 72000);
  ok(`3) سعر الحبة مُعبأ تلقائيًا = 6000 (${vals[3]})`, digits(vals[3]) === 6000);

  // 4) السيناريو الحرفي: 1 كرتونة فقط → الإجمالي 72,000
  const totalCell = row.locator("td").nth(7);
  const totalFirstLine = async () => (await totalCell.innerText()).trim().split("\n")[0];
  await row.locator('input[type=number]').nth(0).fill("1");
  await page.waitForTimeout(350);
  ok(`4) 1 كرتونة → الإجمالي 72,000 (${await totalFirstLine()})`, digits(await totalFirstLine()) === 72000);

  // ثم +2 حبة → تجتمع: 72,000 + 12,000 = 84,000
  await row.locator('input[type=number]').nth(1).fill("2");
  await page.waitForTimeout(350);
  const totalTxt = await totalFirstLine();
  ok(`4) +2 حبة → الإجمالي يجتمع 84,000 (${totalTxt})`, digits(totalTxt) === 84000);
  ok("4) سطر «= 14 حبة» تحت الإجمالي", /= 14 حبة/.test(await totalCell.innerText()));

  // الحبات وحدها: امسح الكرتون → 2 × 6000 = 12,000
  await row.locator('input[type=number]').nth(0).fill("");
  await page.waitForTimeout(350);
  const onlyLoose = await totalFirstLine();
  ok(`4) الحبات فقط (2 حبة) → 12,000 (${onlyLoose})`, digits(onlyLoose) === 12000);

  // أعِد الكرتون للسجل النهائي
  await row.locator('input[type=number]').nth(0).fill("1");
  await page.waitForTimeout(300);

  // 5) ملاحظات + الصرف رغم النقص
  const notes = page.locator("textarea[placeholder*='التسليم']").first();
  ok("5) حقل ملاحظات الفاتورة ظاهر", await notes.count() > 0);
  ok("5) مربع «الصرف رغم نقص المخزون» موجود", await page.locator("text=السماح بالصرف رغم نقص المخزون").count() > 0);

  // 6) أزرار الطباعة والإلغاء والترحيل
  ok("6) زر «طباعة مسودة» موجود", await page.locator("button:has-text('طباعة مسودة')").count() > 0);
  ok("6) زر «إلغاء الفاتورة» موجود", await page.locator("button:has-text('إلغاء الفاتورة')").count() > 0);
  ok("6) زر ترحيل الفاتورة سليم", await page.locator("button:has-text('ترحيل الفاتورة')").count() > 0);

  // ترحيل فعلي للتحقق من الحلقة كاملة ثم إبطال لتنظيف البيانات
  // الرصد عبر الشبكة — أضمن من الرسائل التي تختفي تلقائيًا
  const respP = page.waitForResponse(
    (r) => r.url().includes("/api/v1/sales/invoices") && r.request().method() === "POST",
    { timeout: 20000 }
  );
  await page.click("button:has-text('ترحيل الفاتورة')");
  const resp = await respP.catch(() => null);
  const j = resp ? await resp.json().catch(() => null) : null;
  console.log(`   · POST الفاتورة: HTTP ${resp?.status()} · success=${j?.success} · ${j?.message ?? ""} ${j?.errors ? JSON.stringify(j.errors).slice(0, 160) : ""}`);
  const posted = !!j?.success;
  ok(`7) الترحيل نجح (HTTP ${resp?.status()})`, posted);
  const invNumber = j?.data?.number;
  if (posted) {
    const invText = await page.locator("text=نتيجة الفاتورة").locator("..").innerText().catch(() => "");
    const m = invNumber ? [null, invNumber] : invText.match(/INV-[\d-]+/);
    const grand = page.locator("text=قيمة الفاتورة").locator("..").innerText().then((t) => digits(t)).catch(() => 0);
    const total = await grand;
    ok(`7) قيمة الفاتورة المرحّلة = 84,000 (${total})`, total === 84000);
    if (m) {
      const v = await page.evaluate(async ({ t, n }) => {
        const H = { "Content-Type": "application/json", Authorization: `Bearer ${t}` };
        const list = await fetch(`/api/v1/sales/invoices?q=${n}`, { headers: H }).then((r) => r.json());
        const id = list.data?.[0]?.id;
        if (!id) return false;
        const r = await fetch(`/api/v1/sales/invoices/${id}/void`, { method: "POST", headers: H, body: JSON.stringify({ reason: "تحقق آلي — جولة السعرين" }) }).then((x) => x.json());
        return r.success;
      }, { t: token, n: m[0] });
      ok("7) أُبطلت فاتورة التحقق (نظافة البيانات)", v);
    }
  }

  // لقطة
  await page.screenshot({ path: "download/verify-new-invoice-lines.png", fullPage: false });
  console.log("   · لقطة: download/verify-new-invoice-lines.png");
} catch (e) {
  fail++;
  console.log("  ✘ استثناء:", e.message?.slice(0, 250));
} finally {
  await browser.close();
}
console.log(`\n=== النتيجة: ${pass} ✓ · ${fail} ✘ ===`);
process.exit(fail ? 1 : 0);
