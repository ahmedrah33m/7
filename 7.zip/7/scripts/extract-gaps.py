# -*- coding: utf-8 -*-
"""استخراج سجل الفجوات من تقرير المطابقة الشامل docx"""
from docx import Document
import re

path = '/home/z/my-project/download/تقرير-المطابقة-الشامل-نظام-المبيعات-والتوزيع.docx'
doc = Document(path)

# اطبع كل الجداول التي تبدو كسجل فجوات (تحتوي أعمدة أولوية أو حالة)
for ti, table in enumerate(doc.tables):
    header = ' | '.join(c.text.strip() for c in table.rows[0].cells)
    if ('أولوية' in header or 'الحالة' in header or 'الفجوة' in header):
        print(f"=== TABLE {ti}: {header}")
        for row in table.rows[1:]:
            cells = [c.text.strip().replace('\n', ' ') for c in row.cells]
            print(' || '.join(cells))
        print()
