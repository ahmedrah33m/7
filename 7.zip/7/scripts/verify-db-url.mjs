// التحقق من أن DATABASE_URL النسبي يُحلّ صح (نسبة إلى prisma/) ويصل للقاعدة الحية
import { PrismaClient } from "@prisma/client";

const p = new PrismaClient();
try {
  const tables = await p.$queryRaw`SELECT COUNT(*) AS c FROM sqlite_master WHERE type='table'`;
  console.log("tables_count =", tables[0].c);
  try {
    const companies = await p.company.count();
    const users = await p.user.count();
    console.log("companies =", companies, "| users =", users);
  } catch {
    console.log("(model names differ — raw check only)");
  }
  if (Number(tables[0].c) < 50) {
    console.error("FAIL: قاعدة غير مكتملة — مسار خاطئ!");
    process.exit(1);
  }
  console.log("DB_URL_OK");
} finally {
  await p.$disconnect();
}
