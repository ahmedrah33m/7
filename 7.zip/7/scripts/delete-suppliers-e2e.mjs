// E2E test — الميزات الجديدة: حذف فاتورة شراء + حذف منتج + إضافة موردين
// Run: node scripts/delete-suppliers-e2e.mjs
const BASE = "http://localhost:3000";
let TOKEN = null;
let pass = 0, fail = 0;
const results = [];

function check(name, cond, extra = "") {
  if (cond) { pass++; results.push(`  ✅ ${name}${extra ? " — " + extra : ""}`); }
  else { fail++; results.push(`  ❌ ${name}${extra ? " — " + extra : ""}`); }
}

async function call(method, path, body) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(TOKEN ? { Authorization: `Bearer ${TOKEN}` } : {}),
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  let json = {};
  try { json = await res.json(); } catch {}
  return { status: res.status, body: json };
}

async function main() {
  console.log("\n══════ E2E: حذف فواتير الشراء + حذف المنتجات + الموردون ══════\n");

  // 1) دخول
  const login = await call("POST", "/api/v1/auth/login", { username: "admin", password: "Admin@123" });
  check("تسجيل الدخول admin", login.status === 200 && login.body.success);
  TOKEN = login.body.data?.access_token;

  // ── أ) الموردون ──────────────────────────────────────────────
  console.log("أ) إضافة الموردين:");
  const supBefore = await call("GET", "/api/v1/suppliers");
  const nBefore = Array.isArray(supBefore.body.data) ? supBefore.body.data.length : 0;

  const uniq = Date.now().toString().slice(-6);
  const supName = `مورد اختبار ${uniq}`;
  const supCreate = await call("POST", "/api/v1/suppliers", {
    name: supName, phone: "07701234567", address: "بغداد - الكرادة", opening_balance: 25000,
  });
  check("POST مورد جديد (رصيد افتتاحي 25,000)", supCreate.status === 201 && supCreate.body.success,
    supCreate.body.data ? `code=${supCreate.body.data.code}` : JSON.stringify(supCreate.body));
  const supCode = supCreate.body.data?.code;
  const supId = supCreate.body.data?.id;

  const supAfter = await call("GET", "/api/v1/suppliers");
  const created = (supAfter.body.data ?? []).find((s) => s.id === supId);
  check("المورد يظهر في القائمة برصيده", !!created && created.balance === 25000 && created.is_active === true,
    created ? `balance=${created.balance}` : "غير موجود");

  const dup = await call("POST", "/api/v1/suppliers", { name: supName });
  check("رفض الاسم المكرر (VAL_002)", dup.status === 409 && dup.body.code === "VAL_002", `http=${dup.status}`);

  const shortName = await call("POST", "/api/v1/suppliers", { name: "م" });
  check("رفض الاسم القصير جداً (422)", shortName.status === 422, `http=${shortName.status}`);

  // ── ب) حذف فاتورة شراء آجلة ─────────────────────────────────
  console.log("\nب) حذف فاتورة شراء (آجلة) — عكس كامل:");
  const prods = await call("GET", "/api/v1/products?per_page=50");
  const plist = Array.isArray(prods.body.data) ? prods.body.data : [];
  check("تتوفر منتجات للاختبار", plist.length > 0, `count=${plist.length}`);
  const whs = await call("GET", "/api/v1/admin/warehouses");
  const whList = whs.body.data?.items ?? whs.body.data ?? [];
  const whId = whList[0]?.id;
  const prod = plist.find((p) => (p.stock_total ?? 0) >= 0);
  const stockBefore0 = prod?.stock_total ?? 0;

  const invCredit = await call("POST", "/api/v1/purchases/invoices", {
    supplier_id: supId, warehouse_id: whId, type: "CREDIT",
    lines: [{ product_id: prod.id, qty: 7, unit_cost: 2000 }],
  });
  check("ترحيل فاتورة شراء آجلة (7×2000)", invCredit.status === 201 && invCredit.body.success,
    invCredit.body.data ? `number=${invCredit.body.data.number} due=${invCredit.body.data.due_amount}` : JSON.stringify(invCredit.body).slice(0, 120));
  const invId = invCredit.body.data?.id;
  const invNumber = invCredit.body.data?.number;

  const prodMid = await call("GET", `/api/v1/products?per_page=50&q=${encodeURIComponent(prod.code)}`);
  const prodMidRow = (prodMid.body.data ?? []).find((p) => p.id === prod.id);
  check("المخزون زاد +7 بعد الترحيل", prodMidRow?.stock_total === stockBefore0 + 7,
    `before=${stockBefore0} after=${prodMidRow?.stock_total}`);

  const supMid = await call("GET", "/api/v1/suppliers");
  const supMidRow = (supMid.body.data ?? []).find((s) => s.id === supId);
  check("ذمة المورد زادت 14,000 (الجزء الآجل)", supMidRow?.balance === 25000 + 14000,
    `balance=${supMidRow?.balance} (متوقع ${25000 + 14000})`);

  const delInv = await call("DELETE", `/api/v1/purchases/invoices/${invId}`);
  check("DELETE فاتورة الشراء", delInv.status === 200 && delInv.body.success,
    delInv.body.data ? `stock_reversed=${delInv.body.data.stock_lines_reversed} due_reversed=${delInv.body.data.supplier_due_reversed}` : JSON.stringify(delInv.body).slice(0, 150));

  const prodPost = await call("GET", `/api/v1/products?per_page=50&q=${encodeURIComponent(prod.code)}`);
  const prodPostRow = (prodPost.body.data ?? []).find((p) => p.id === prod.id);
  check("المخزون عاد لما كان عليه", prodPostRow?.stock_total === stockBefore0,
    `after-delete=${prodPostRow?.stock_total} (متوقع ${stockBefore0})`);

  const supPost = await call("GET", "/api/v1/suppliers");
  const supPostRow = (supPost.body.data ?? []).find((s) => s.id === supId);
  check("ذمة المورد عادت للرصيد الافتتاحي", supPostRow?.balance === 25000, `balance=${supPostRow?.balance}`);

  const invGone = await call("GET", "/api/v1/purchases/invoices?q=" + encodeURIComponent(invNumber));
  check("الفاتورة المحذوفة اختفت من القائمة", !(invGone.body.data ?? []).some((r) => r.id === invId));

  const delAgain = await call("DELETE", `/api/v1/purchases/invoices/${invId}`);
  check("حذف مرة ثانية → VAL_003 (404)", delAgain.status === 404 && delAgain.body.code === "VAL_003", `http=${delAgain.status}`);

  // ── ج) حذف فاتورة شراء نقدية — إرجاع المبلغ للصندوق ─────────
  console.log("\nج) حذف فاتورة شراء نقدية — ردّ المبلغ للصندوق:");
  const boxes = await call("GET", "/api/v1/finance/cashboxes");
  const boxList = boxes.body.data?.items ?? boxes.body.data ?? [];
  const boxBalBefore = boxList[0]?.balance ?? 0;
  check("يوجد صندوق نقدي", boxList.length > 0, `balance=${boxBalBefore}`);

  const invCash = await call("POST", "/api/v1/purchases/invoices", {
    supplier_id: supId, warehouse_id: whId, type: "CASH",
    lines: [{ product_id: prod.id, qty: 3, unit_cost: 1500 }],
  });
  check("ترحيل فاتورة نقدية (3×1500=4500)", invCash.status === 201 && invCash.body.success,
    invCash.body.data ? `number=${invCash.body.data.number} paid=${invCash.body.data.paid_amount}` : JSON.stringify(invCash.body).slice(0, 150));

  const boxesMid = await call("GET", "/api/v1/finance/cashboxes");
  const boxMidBal = (boxesMid.body.data?.items ?? boxesMid.body.data ?? [])[0]?.balance ?? 0;
  check("الصندوق خُصم منه 4,500", boxMidBal === boxBalBefore - 4500, `after=${boxMidBal} (متوقع ${boxBalBefore - 4500})`);

  const delCash = await call("DELETE", `/api/v1/purchases/invoices/${invCash.body.data?.id}`);
  check("DELETE الفاتورة النقدية", delCash.status === 200 && delCash.body.success,
    delCash.body.data ? `cash_returned=${delCash.body.data.cash_returned}` : JSON.stringify(delCash.body).slice(0, 150));

  const boxesPost = await call("GET", "/api/v1/finance/cashboxes");
  const boxPostBal = (boxesPost.body.data?.items ?? boxesPost.body.data ?? [])[0]?.balance ?? 0;
  check("الصندوق استرد 4,500", boxPostBal === boxBalBefore, `after=${boxPostBal} (متوقع ${boxBalBefore})`);

  // ── د) حذف المنتجات ──────────────────────────────────────────
  console.log("\nد) حذف المنتجات في الكتالوج:");
  const newProd = await call("POST", "/api/v1/products", {
    name: `منتج حذف ${uniq}`, unit: "قطعة", sale_price: 1000, cost_price: 500,
  });
  check("إنشاء منتج جديد", newProd.status === 201 && newProd.body.success,
    newProd.body.data ? `code=${newProd.body.data.code}` : JSON.stringify(newProd.body).slice(0, 120));
  const newProdId = newProd.body.data?.id;

  const delProd = await call("DELETE", `/api/v1/products/${newProdId}`);
  check("DELETE منتج بدون مخزون", delProd.status === 200 && delProd.body.success && delProd.body.data?.deleted === true);

  const prodGone = await call("GET", `/api/v1/products?per_page=100&q=${encodeURIComponent(`منتج حذف ${uniq}`)}`);
  check("المنتج المحذوف اختفى من الكتالوج", !(prodGone.body.data ?? []).some((p) => p.id === newProdId));

  const delProdAgain = await call("DELETE", `/api/v1/products/${newProdId}`);
  check("حذف منتج محذوف → VAL_003", delProdAgain.status === 404 && delProdAgain.body.code === "VAL_003", `http=${delProdAgain.status}`);

  // منتج له مخزون → يُرفض
  const stockProd = plist.find((p) => (p.stock_total ?? 0) > 0);
  if (stockProd) {
    const delBlocked = await call("DELETE", `/api/v1/products/${stockProd.id}`);
    check("رفض حذف منتج لديه مخزون (PRD_001)", delBlocked.status === 409 && delBlocked.body.code === "PRD_001",
      `product=${stockProd.name} stock=${stockProd.stock_total} http=${delBlocked.status}`);
  } else {
    check("رفض حذف منتج لديه مخزون", true, "(تخطّي — لا يوجد منتج بمخزون)");
  }

  // ── هـ) تنظيف: حذف مورد الاختبار ────────────────────────────
  // (لا يوجد DELETE للمورد — نتركه؛ الحساب سليم: الرصيد عاد للافتتاحي)

  console.log("\n────────── النتائج ──────────");
  results.forEach((r) => console.log(r));
  console.log(`\nالمجموع: ${pass} ناجح / ${fail} فاشل من ${pass + fail}\n`);
  process.exit(fail ? 1 : 0);
}

main().catch((e) => { console.error("FATAL:", e); process.exit(1); });
