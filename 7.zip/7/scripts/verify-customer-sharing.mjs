// =====================================================================
// verify-customer-sharing.mjs — تحقق تكاملي لحزمة «مشاركة العملاء» (2026-09-18)
// 1) الفاتورة العامة الكاملة: /verify/<token> — بنود + إجماليات + طباعة + شعار
// 2) الخصوصية: لا تكاليف/أرباح/أرصدة تاريخية في حمولة /verify
// 3) واتساب سريع من صف الفواتير + تذكير سداد (التقاط window.open)
// 4) مشاركة عرض السعر واتساب + رابط معاينة عامة + DRAFT→SENT تلقائي
// 5) كشف حساب العميل على واتساب
// 6) عرض السعر العام عبر uuid + رمز غير صالح → شاشة التحذير
// =====================================================================
import { chromium } from "playwright";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const results = [];
function check(name, ok, extra = "") {
  results.push(`${ok ? "✓" : "✗"} ${name}${extra ? " — " + extra : ""}`);
  if (!ok) process.exitCode = 1;
}

async function jfetch(path, { method = "GET", token, body } = {}) {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body) headers["Content-Type"] = "application/json";
  const res = await fetch(BASE + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let json = null;
  try { json = await res.json(); } catch {}
  return { res, json };
}

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: "ar" });
const page = await ctx.newPage();
const consoleErrors = [];
page.on("console", (m) => { if (m.type() === "error") consoleErrors.push(m.text()); });

// التقاط window.open (المشاركة لا تفتح wa.me فعلياً داخل الاختبار)
async function captureOpen(action) {
  await page.evaluate(() => {
    window.__capturedOpen = null;
    window.open = (url) => { window.__capturedOpen = String(url ?? ""); return null; };
  });
  await action();
  await page.waitForTimeout(700);
  return page.evaluate(() => window.__capturedOpen);
}

// ---------- 0) دخول المالك ----------
const login = await jfetch("/api/v1/auth/login", { method: "POST", body: { username: "admin", password: "Admin@123" } });
const token = login.json?.data?.access_token;
check("دخول admin ناجح", !!token, login.json?.message ?? "");

if (token) {
  // ---------- 1) فاتورة برمز تحقق (من القائمة الحقيقية) ----------
  const invs = await jfetch("/api/v1/sales/invoices?per_page=10", { token });
  const invRow = (invs.json?.data ?? [])[0];
  check("توجد فاتورة للاختبار", !!invRow, invRow?.number ?? "لا فواتير");
  let detail = null;
  if (invRow) {
    const d = await jfetch(`/api/v1/sales/invoices/${invRow.id}`, { token });
    detail = d.json?.data ?? null;
    check("الفاتورة تحمل verify_token", !!detail?.verify_token);
  }

  if (detail?.verify_token) {
    const T = detail.verify_token;
    // ---------- 2) حمولة /verify — الكمال والخصوصية ----------
    const pub = await jfetch(`/api/v1/verify/${T}`); // بلا توثيق — صفحة عامة
    const p = pub.json?.data ?? {};
    check("الحمولة العامة: valid + kind=INVOICE", p.valid === true && p.kind === "INVOICE", `kind=${p.kind}`);
    check("الحمولة: شركة + عميل + حالة", !!p.company?.name && !!p.customer?.name && !!p.status_ar);
    check("الحمولة: بنود كاملة", Array.isArray(p.lines) && p.lines.length === (detail.lines?.length ?? -1), `${p.lines?.length} بند`);
    check("الحمولة: إجماليات + مدفوع/متبقي", !!p.totals && typeof p.totals.grand_total === "number" && typeof p.totals.due_amount === "number");
    // الخصوصية — لا حقول التكلفة/الربح/الأرصدة/الموظفين
    const raw = JSON.stringify(p);
    check("الخصوصية: بلا unit_cost/cogs", !/unit_cost|cogs|cost_price/i.test(raw));
    check("الخصوصية: بلا أرصدة سابقة/جديدة", !("previous_balance" in p) && !("new_balance" in p));
    check("الخصوصية: بلا created_by", !/created_by/i.test(raw));

    // ---------- 3) الصفحة العامة تعرض فاتورة كاملة ----------
    await page.goto(`${BASE}/verify/${T}`, { waitUntil: "networkidle" });
    await page.waitForTimeout(600);
    const bodyText = await page.locator("body").innerText();
    check("الصفحة العامة: فاتورة مبيعات", bodyText.includes("فاتورة مبيعات"));
    check("الصفحة العامة: رقم الفاتورة ظاهر", bodyText.includes(detail.number));
    check("الصفحة العامة: اسم الشركة ظاهر", bodyText.includes(p.company?.name ?? ""));
    check("الصفحة العامة: جدول البنود + طباعة", bodyText.includes("الإجمالي النهائي") && bodyText.includes("طباعة / حفظ PDF"));
    check("الصفحة العامة: شريط التوثيق", bodyText.includes("موثّق"));
    // لقطة للفاتورة العامة
    await page.screenshot({ path: "download/share-public-invoice.png", fullPage: true }).catch(() => {});

    // ---------- 4) الشعار العام (200 صورة أو 404 مقبول حسب وجود شعار) ----------
    const logoRes = await fetch(`${BASE}/api/v1/verify/${T}/logo`);
    check("نقطة الشعار العامة تستجيب", logoRes.status === 200 || logoRes.status === 404, `status=${logoRes.status}${logoRes.status === 200 ? " mime=" + logoRes.headers.get("content-type") : ""}`);
    if (logoRes.status === 200) check("الشعار: content-type صورة", (logoRes.headers.get("content-type") ?? "").startsWith("image/"));
  } else {
    check("توجد فاتورة برمز تحقق", false, "لا يمكن متابعة اختبارات الصفحة العامة");
  }

  // ---------- 5) واتساب سريع من صف الفواتير ----------
  await page.goto(BASE + "/", { waitUntil: "networkidle" });
  if ((await page.locator("input").count()) >= 2 && !(await page.locator("aside").count())) {
    await page.locator("input").first().fill("admin");
    await page.locator('input[type="password"]').fill("Admin@123");
    await page.getByRole("button", { name: /دخول/ }).click();
    await page.waitForSelector("aside", { timeout: 20000 }).catch(() => {});
  }
  check("اللوحة ظاهرة (aside)", await page.locator("aside").count() > 0);

  await page.locator("aside").getByRole("button", { name: "الفواتير" }).first().click();
  await page.waitForTimeout(1500);
  const waRowBtns = page.locator("table tbody tr button[title='إرسال الفاتورة على واتساب']");
  const waCount = await waRowBtns.count();
  check("أزرار واتساب سريعة في صفوف الفواتير", waCount > 0, `${waCount} زر`);

  if (waCount > 0) {
    const captured = await captureOpen(() => waRowBtns.first().click());
    let waOk = false, waText = "";
    if (captured) {
      try {
        waText = decodeURIComponent(captured);
        waOk = captured.startsWith("https://wa.me/") && waText.includes("فاتورة");
      } catch {}
    }
    check("النقر يبني رابط wa.me بنص الفاتورة", waOk, captured ? waText.slice(0, 90).replace(/\n/g, " ") : "لم يُلتقط window.open");
    // الرسالة تحتوي رابط المعاينة العام إن كان للفاتورة رمز
    if (detail?.verify_token) check("رسالة الفاتورة تتضمن رابط /verify/", waText.includes(`/verify/${detail.verify_token}`));
  }

  // زر التذكير (يظهر فقط للفواتير الآجلة غير المسددة)
  const remindBtns = page.locator("table tbody tr button[title='تذكير العميل بالسداد']");
  const remindCount = await remindBtns.count();
  check("أزرار تذكير السداد مشروطة بالآجال", remindCount >= 0, `${remindCount} زر (قد تكون 0 إن لا آجال مستحقة)`);
  if (remindCount > 0) {
    const cap2 = await captureOpen(() => remindBtns.first().click());
    const t2 = cap2 ? (() => { try { return decodeURIComponent(cap2); } catch { return ""; } })() : "";
    check("رسالة التذكير: صياغة سداد + wa.me", !!cap2 && cap2.startsWith("https://wa.me/") && t2.includes("تذكير") && t2.includes("المتبقي"));
  }

  // ---------- 6) عرض السعر: مشاركة واتساب + معاينة عامة + DRAFT→SENT ----------
  const prods = await jfetch("/api/v1/products?per_page=5", { token });
  const custs = await jfetch("/api/v1/customers?per_page=5", { token });
  const prod = (prods.json?.data ?? [])[0];
  const cust = (custs.json?.data ?? [])[0];
  check("توجد بيانات لإنشاء عرض سعر", !!prod && !!cust, prod ? `${prod.name}` : "لا منتجات");

  let qUuid = null, qId = null;
  if (prod && cust) {
    const createQ = await jfetch("/api/v1/sales/quotations", { method: "POST", token, body: {
      customer_id: cust.id,
      lines: [{ product_id: prod.id, qty: 2, discount_pct: 0 }],
    } });
    check("إنشاء عرض سعر DRAFT", createQ.json?.success === true, createQ.json?.message ?? "");
    qId = createQ.json?.data?.id ?? null;
    if (qId) {
      const qd = await jfetch(`/api/v1/sales/quotations/${qId}`, { token });
      qUuid = qd.json?.data?.uuid ?? null;
      check("تفاصيل العرض تُرجع uuid للمعاينة العامة", !!qUuid);

      await page.locator("aside").getByRole("button", { name: "عروض الأسعار" }).first().click();
      await page.waitForTimeout(1200);
      // فتح تفاصيل العرض (الصف الأول)
      await page.locator("table tbody tr").first().click();
      await page.waitForTimeout(800);
      const qWaBtn = page.getByRole("button", { name: /واتساب/ }).first();
      check("زر واتساب في تفاصيل العرض", await qWaBtn.count() > 0);
      if (await qWaBtn.count() > 0) {
        const cap3 = await captureOpen(() => qWaBtn.click());
        const t3 = cap3 ? (() => { try { return decodeURIComponent(cap3); } catch { return ""; } })() : "";
        check("رسالة العرض: عرض سعر + بنود + wa.me", !!cap3 && t3.includes("عرض سعر") && t3.includes("البنود"));
        check("رسالة العرض تتضمن رابط /verify/<uuid>", !!qUuid && t3.includes(`/verify/${qUuid}`));
      }
      await page.waitForTimeout(1000);
      const qAfter = await jfetch(`/api/v1/sales/quotations/${qId}`, { token });
      check("المشاركة حوّلت DRAFT → SENT", qAfter.json?.data?.status === "SENT", `status=${qAfter.json?.data?.status}`);

      // الصفحة العامة لعرض السعر
      if (qUuid) {
        await page.goto(`${BASE}/verify/${qUuid}`, { waitUntil: "networkidle" });
        await page.waitForTimeout(600);
        const qb = await page.locator("body").innerText();
        check("الصفحة العامة: عرض سعر", qb.includes("عرض سعر") && qb.includes("صالح حتى"));
        check("الصفحة العامة للعرض: الإجمالي + طباعة", qb.includes("الإجمالي النهائي") && qb.includes("طباعة / حفظ PDF"));
        await page.screenshot({ path: "download/share-public-quotation.png", fullPage: true }).catch(() => {});
        // إغلاق العرض التجريبي (تنظيف)
        await jfetch(`/api/v1/sales/quotations/${qId}`, { method: "PATCH", token, body: { status: "CANCELLED" } });
      }
    }
  }

  // ---------- 7) كشف حساب العميل على واتساب ----------
  await page.goto(BASE + "/", { waitUntil: "networkidle" });
  await page.waitForSelector("aside", { timeout: 20000 }).catch(() => {});
  await page.locator("aside").getByRole("button", { name: "العملاء" }).first().click();
  await page.waitForTimeout(1200);
  const stmtBtn = page.getByRole("button", { name: /كشف حساب/ }).first();
  check("زر كشف حساب في صفوف العملاء", await stmtBtn.count() > 0);
  if (await stmtBtn.count() > 0) {
    await stmtBtn.click();
    await page.waitForTimeout(1200);
    const stmtWa = page.getByRole("button", { name: /واتساب/ }).first();
    check("زر واتساب داخل نافذة كشف الحساب", await stmtWa.count() > 0);
    if (await stmtWa.count() > 0) {
      const cap4 = await captureOpen(() => stmtWa.click());
      const t4 = cap4 ? (() => { try { return decodeURIComponent(cap4); } catch { return ""; } })() : "";
      check("رسالة الكشف: عنوان + رصيد + آخر الحركات", !!cap4 && t4.includes("كشف حساب") && t4.includes("الرصيد الحالي"));
    }
    await page.screenshot({ path: "download/share-statement-dialog.png", fullPage: false }).catch(() => {});
  }

  // ---------- 8) رمز غير صالح → شاشة التحذير ----------
  await page.goto(`${BASE}/verify/ffffffff-ffff-ffff-ffff-ffffffffffff`, { waitUntil: "networkidle" });
  await page.waitForTimeout(600);
  const inv2 = await page.locator("body").innerText();
  check("رمز غير صالح: شاشة مستند غير معروف", inv2.includes("مستند غير معروف"));

  // ---------- 9) نظافة الكونسول ----------
  const realErrors = consoleErrors.filter((e) => !/favicon|Download the React DevTools/i.test(e));
  check("لا أخطاء console", realErrors.length === 0, realErrors.slice(0, 2).join(" | ").slice(0, 120));
} // end token

console.log("\n===== نتائج تحقق حزمة مشاركة العملاء =====");
for (const r of results) console.log(r);
const passed = results.filter((r) => r.startsWith("✓")).length;
console.log(`\nالنتيجة: ${passed}/${results.length}`);
await browser.close();
