// =====================================================================
// Phase 4 — §10 بطارية الاختبارات الرسمية (Cost Layer · FIFO · WAVG ·
//           STANDARD · LAST · COGS Engine)
// تشغيل: node scripts/phase4-verify.mjs   (يتطلب dev server على :3000)
//
// مثال الوثيقة الإلزامي (§3): طبقتا 100@1000 و 50@1200 وبيع 120 →
//   FIFO COGS = 100×1000 + 20×1200 = 124000 بالضبط
//   WAVG COGS = 120 × (160000/150) = 128000 بالضبط
//
// التغطية (§10 من وثيقة المرحلة):
//   FIFO · WAVG · Opening Balance · Purchase · Sale · Return · Transfer
//   · Stocktake · Void Invoice · Negative stock prevention · Historical invoice
//   + التقارير §9 (layers/inventory/cogs/variance) + أيutzer الطبقات=الأرصدة
// كل الثوابت تُعاد حسابها من القاعدة بـ Decimal (precision 40).
// =====================================================================
const BASE = "http://localhost:3000/api/v1";
import { PrismaClient } from "@prisma/client";
import Decimal from "decimal.js";

Decimal.set({ precision: 40, rounding: Decimal.ROUND_HALF_UP, toExpNeg: -18, toExpPos: 48 });
const db = new PrismaClient();

let PASS = 0, FAIL = 0;
const failures = [];
function ok(name, cond, detail = "") {
  if (cond) { PASS++; console.log(`  ✓ ${name}`); }
  else { FAIL++; failures.push({ name, detail }); console.log(`  ✗ ${name} — ${detail}`); }
}
const dec = (v) => {
  if (v == null || v === "") return new Decimal(0);
  if (v instanceof Decimal) return v;
  if (typeof v === "object" && typeof v.toString === "function") { const d = new Decimal(v.toString()); return d.isFinite() ? d : new Decimal(0); }
  const d = new Decimal(v);
  return d.isFinite() ? d : new Decimal(0);
};
const moneyR = (v) => dec(v).toDecimalPlaces(4, Decimal.ROUND_HALF_UP);
const qtyR = (v) => dec(v).toDecimalPlaces(6, Decimal.ROUND_HALF_UP);
const eq = (a, b) => dec(a).toString() === dec(b).toString();

async function jfetch(path, init) {
  const res = await fetch(`${BASE}${path}`, init);
  const body = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, body };
}
const post = (path, auth, data) => jfetch(path, { method: "POST", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(data) });
const put = (path, auth, data) => jfetch(path, { method: "PUT", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(data) });
const patch = (path, auth, data) => jfetch(path, { method: "PATCH", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(data) });
const get = (path, auth) => jfetch(path, { headers: auth });

function bail(cond, msg) { if (cond) throw Object.assign(new Error(msg), { bail: true }); }

/** الثابت الذهبي: مجموع متبقي الطبقات = رصيد المخزون لكل (مستودع، منتج) بالشركة. */
async function layerStockConsistency(companyId, label) {
  const balances = await db.stockBalance.findMany({ where: { companyId } });
  let allOk = true, detail = "";
  for (const b of balances) {
    const agg = await db.costLayer.aggregate({
      where: { companyId, warehouseId: b.warehouseId, productId: b.productId, status: "ACTIVE" },
      _sum: { remainingQuantity: true },
    });
    const layerQty = qtyR(dec(agg._sum.remainingQuantity));
    if (!eq(layerQty, qtyR(dec(b.qty)))) {
      allOk = false;
      detail += ` [wh${b.warehouseId}/p${b.productId}: layers=${layerQty} balance=${qtyR(dec(b.qty))}]`;
    }
  }
  ok(label, allOk, detail || "no rows");
}

async function main() {
  try { await runTests(); } catch (e) { if (!e?.bail) console.error(e); }
  console.log("=".repeat(70));
  console.log(`RESULT: PASS=${PASS} FAIL=${FAIL}`);
  if (failures.length) {
    console.log("الفشل:");
    for (const fl of failures) console.log(`  ✗ ${fl.name}: ${fl.detail}`);
  }
  console.log("=".repeat(70));
  if (FAIL > 0) process.exitCode = 1;
}

async function runTests() {
  console.log("=".repeat(70));
  console.log("PHASE 4 VERIFY — §10 Cost Layer engine battery (FIFO/WAVG/STD/LAST)");
  console.log("=".repeat(70));
  const sfx = Date.now().toString().slice(-6);

  // ---------- الإعداد: شركة معزولة ----------
  const login = await post("/auth/login", {}, { username: "admin", password: "Admin@123" });
  const t1 = login.body.data?.access_token;
  ok("SETUP login admin", !!t1, JSON.stringify(login.body).slice(0, 100));

  const comp = await post("/admin/companies", { authorization: `Bearer ${t1}` }, {
    code: `P4T${sfx}`, name: `شركة فحص التكلفة ${sfx}`,
  });
  const companyId = comp.body.data?.companyId;
  const whId = comp.body.data?.warehouseId;
  ok("SETUP شركة اختبار P4T + provisioning", comp.status === 201 && !!companyId && !!whId,
    JSON.stringify(comp.body).slice(0, 140));

  const sw = await post("/auth/switch-company", { authorization: `Bearer ${t1}` }, { company_id: companyId });
  const auth = { authorization: `Bearer ${sw.body.data?.access_token ?? ""}`, "content-type": "application/json" };
  ok("SETUP switch-company", !!sw.body.data?.access_token, JSON.stringify(sw.body).slice(0, 100));

  await put("/settings/usd-rate", auth, { rate: 1300 });
  const walkin = await get("/customers/default-walkin", auth);
  const walkinId = walkin.body.data?.id;
  const sup = (await post("/suppliers", auth, { name: `مورد P4T ${sfx}`, phone: "07700000000" })).body.data;
  ok("SETUP walk-in + supplier", !!walkinId && !!sup?.id, "none");
  await db.cashbox.create({ data: { companyId, branchId: comp.body.data.branchId, code: "MAIN", name: "الصندوق الرئيسي", balance: new Decimal(50000000) } });

  // المنتج A — بدون تعبئة (كميات حبة صرفة، أرقام الوثيقة)
  const prodA = (await post("/products", auth, {
    name: `صنف FIFO ${sfx}`, unit: "حبة", cost_price: 1000, sale_price: 1500, min_stock: 0,
  })).body.data;
  ok("SETUP منتج A (FIFO)", !!prodA?.id, JSON.stringify(prodA).slice(0, 100));
  const prodB = (await post("/products", auth, {
    name: `صنف WAVG ${sfx}`, unit: "حبة", cost_price: 1000, sale_price: 1500, min_stock: 0,
  })).body.data;
  ok("SETUP منتج B (WAVG/STD/LAST)", !!prodB?.id, JSON.stringify(prodB).slice(0, 100));

  // ---------- T-Method: الإعدادات ----------
  console.log("\n■ T-SET — مسار إعدادات طريقة التكلفة");
  const gm0 = await get("/settings/costing-method", auth);
  ok("T-SETa GET الافتراضي WEIGHTED_AVERAGE (WAVG قديم → مُطبَّع)",
    gm0.ok && gm0.body.data?.costing_method === "WEIGHTED_AVERAGE", JSON.stringify(gm0.body));
  const badMethod = await put("/settings/costing-method", auth, { costing_method: "MAGIC" });
  ok("T-SETb طريقة غير معروفة → رفض 422/400", !badMethod.ok && [400, 422].includes(badMethod.status), `status=${badMethod.status}`);
  const setFifo = await put("/settings/costing-method", auth, { costing_method: "FIFO" });
  ok("T-SETc PUT FIFO → 200", setFifo.ok && setFifo.body.data?.costing_method === "FIFO", JSON.stringify(setFifo.body));

  // ---------- T1: Opening Balance (§2) ----------
  console.log("\n■ T1 — Opening Balance: إدخال افتتاحي 100 @ 1000");
  const intake = await post("/inventory/movements", auth, {
    warehouse_id: whId, product_id: prodA.id, direction: "IN", qty: 100, unit_cost: 1000, note: "افتتاحي",
  });
  ok("T1a إدخال افتتاحي 100@1000 → 201", intake.status === 201, JSON.stringify(intake.body).slice(0, 120));
  const layerA1 = await db.costLayer.findFirst({ where: { productId: prodA.id, warehouseId: whId }, orderBy: { id: "asc" } });
  ok("T1b طبقة OPENING_BALANCE: 100 حبة متبقية @1000 IQD",
    layerA1?.sourceType === "OPENING_BALANCE" && eq(layerA1?.quantity, 100) && eq(layerA1?.remainingQuantity, 100)
    && eq(layerA1?.unitCost, 1000) && layerA1?.status === "ACTIVE" && layerA1?.currency === "IQD",
    JSON.stringify(layerA1 && { s: layerA1.sourceType, q: layerA1.quantity?.toString(), r: layerA1.remainingQuantity?.toString(), c: layerA1.unitCost?.toString() }));

  // ---------- T2: Purchase (§2) ----------
  console.log("\n■ T2 — Purchase: شراء 50 @ 1200 → طبقة جديدة + lastCost");
  const buy = await post("/purchases/invoices", auth, {
    supplier_id: sup.id, warehouse_id: whId, type: "CASH",
    lines: [{ product_id: prodA.id, qty: 50, unit_cost: 1200 }],
  });
  ok("T2a شراء 50@1200 → 201", buy.ok, JSON.stringify(buy.body).slice(0, 140));
  const layerA2 = await db.costLayer.findFirst({ where: { productId: prodA.id, warehouseId: whId, sourceType: "PURCHASE" }, orderBy: { id: "desc" } });
  ok("T2b طبقة PURCHASE: 50@1200 — الأحدث بعد الافتتاحية",
    !!layerA2 && eq(layerA2.quantity, 50) && eq(layerA2.remainingQuantity, 50) && eq(layerA2.unitCost, 1200)
    && layerA2.sourceId != null && layerA2.sourceLineId != null,
    JSON.stringify(layerA2 && { q: layerA2.quantity?.toString(), c: layerA2.unitCost?.toString() }));
  const prodADb = await db.product.findUnique({ where: { id: prodA.id } });
  ok("T2c lastCost = 1200 (آخر تكلفة شراء فعلية — منفصلة عن المتوسط §5)",
    eq(prodADb?.lastCost, 1200), `last=${prodADb?.lastCost?.toString()}`);
  ok("T2d costPrice المتوسط المرجّح = (100×1000+50×1200)/150 = 1066.6667",
    eq(prodADb?.costPrice, moneyR(dec(100).mul(1000).plus(dec(50).mul(1200)).div(150))), `wavg=${prodADb?.costPrice?.toString()}`);
  await layerStockConsistency(companyId, "T2e الثابت الذهبي: Σ متبقي الطبقات = أرصدة المخزون");

  // ---------- T3: FIFO Sale (مثال الوثيقة §3) ----------
  console.log("\n■ T3 — FIFO: بيع 120 → COGS = 100×1000 + 20×1200 = 124000 (مثال الوثيقة)");
  const invFifo = await post("/sales/invoices", auth, {
    customer_id: walkinId, warehouse_id: whId, type: "CASH", currency_code: "IQD",
    lines: [{ product_id: prodA.id, qty: 120 }],
  });
  const invFifoId = invFifo.body.data?.id;
  bail(!invFifoId, "فاتورة FIFO فشلت — لا يمكن متابعة السلسلة");
  const fifoLine = await db.salesInvoiceLine.findFirst({ where: { invoiceId: invFifoId, productId: prodA.id } });
  ok("T3a COGS = 124000 بالضبط (لقطة cogsTotal البند)",
    eq(fifoLine?.cogsTotal, 124000), `cogs=${fifoLine?.cogsTotal?.toString()}`);
  ok("T3b cogs_unit_cost = moneyR(124000/120) = 1033.3333",
    eq(fifoLine?.cogsUnitCost, moneyR(dec(124000).div(120))), `u=${fifoLine?.cogsUnitCost?.toString()}`);
  ok("T3c طريقة التكلفة على البند والترويسة = FIFO",
    fifoLine?.cogsMethod === "FIFO", `line=${fifoLine?.cogsMethod}`);
  const fifoHdr = await db.salesInvoice.findUnique({ where: { id: invFifoId } });
  ok("T3d ترويسة الفاتورة: costMethod=FIFO + cogsTotal=124000 (§6 لقطة غير قابلة للتغيير)",
    fifoHdr?.costMethod === "FIFO" && eq(fifoHdr?.cogsTotal, 124000),
    `m=${fifoHdr?.costMethod} t=${fifoHdr?.cogsTotal?.toString()}`);
  const fifoLayersRef = JSON.parse(fifoLine?.cogsLayers ?? "[]");
  ok("T3e مراجع الطبقات: قطعتان — 100 من الطبقة1@1000 + 20 من الطبقة2@1200",
    fifoLayersRef.length === 2 && eq(fifoLayersRef[0]?.qty, 100) && eq(fifoLayersRef[0]?.unit_cost, 1000)
    && eq(fifoLayersRef[1]?.qty, 20) && eq(fifoLayersRef[1]?.unit_cost, 1200)
    && fifoLayersRef[0]?.layer_id === layerA1.id && fifoLayersRef[1]?.layer_id === layerA2.id,
    JSON.stringify(fifoLayersRef));
  const after1 = await db.costLayer.findUnique({ where: { id: layerA1.id } });
  const after2 = await db.costLayer.findUnique({ where: { id: layerA2.id } });
  ok("T3f الأقدم استُنفد (EXHAUSTED) والأحدث بقي 30 (ACTIVE)",
    after1?.status === "EXHAUSTED" && eq(after1?.remainingQuantity, 0)
    && after2?.status === "ACTIVE" && eq(after2?.remainingQuantity, 30),
    `l1=${after1?.status}/${after1?.remainingQuantity?.toString()} l2=${after2?.status}/${after2?.remainingQuantity?.toString()}`);
  const consRows = await db.costConsumption.findMany({ where: { refType: "SALES_INVOICE", refId: invFifoId } });
  ok("T3g سجل الصرف: صفان غير قابلين للتغيير بمجموع 124000",
    consRows.length === 2 && eq(consRows.reduce((a, r) => a.plus(dec(r.totalCost)), new Decimal(0)), 124000),
    `rows=${consRows.length}`);
  const mvFifo = await db.stockMovement.findFirst({ where: { refType: "SALES_INVOICE", refId: invFifoId }, orderBy: { id: "asc" } });
  ok("T3h حركة المخزون حملت التكلفة الفعلية 1033.3333",
    eq(mvFifo?.unitCost, moneyR(dec(124000).div(120))), `mv=${mvFifo?.unitCost?.toString()}`);

  // ---------- T4: Return (§7) ----------
  console.log("\n■ T4 — Return: مرتجع 10 من فاتورة FIFO → يعود بتكلفة الصرف الفعلية");
  const ret = await post("/sales/returns", auth, {
    invoice_id: invFifoId, refund_cash: 0,
    lines: [{ invoice_line_id: fifoLine.id, qty: 10 }],
  });
  ok("T4a مرتجع 10 → 201", ret.ok, JSON.stringify(ret.body).slice(0, 160));
  const retLayer = await db.costLayer.findFirst({ where: { productId: prodA.id, sourceType: "SALES_RETURN" }, orderBy: { id: "desc" } });
  ok("T4b طبقة SALES_RETURN 10@1000 — بتكلفة الطبقة الأصلية التي خرج منها (محاسبياً صحيح)",
    !!retLayer && eq(retLayer.quantity, 10) && eq(retLayer.unitCost, 1000),
    JSON.stringify(retLayer && { q: retLayer.quantity?.toString(), c: retLayer.unitCost?.toString() }));
  const fifoLineAfter = await db.salesInvoiceLine.findUnique({ where: { id: fifoLine.id } });
  ok("T4c لقطة COGS للفاتورة القديمة لم تتغير بعد المرتجع (§6)",
    eq(fifoLineAfter?.cogsTotal, 124000) && eq(fifoLineAfter?.cogsUnitCost, moneyR(dec(124000).div(120))),
    `cogs=${fifoLineAfter?.cogsTotal?.toString()}`);

  // ---------- T5: Transfer (§8) ----------
  console.log("\n■ T5 — Transfer: نقل 20 لمستودع ثانٍ — طبقات بنفس التكلفة، بلا تكلفة جديدة");
  const branch2 = await db.branch.create({ data: { companyId, code: `W2${sfx}`, name: "فرع ثانٍ P4T" } });
  const wh2 = await db.warehouse.create({ data: { companyId, branchId: branch2.id, code: `WH2${sfx}`, name: "مستودع ثانٍ P4T", type: "BRANCH" } });
  // النطاق COMPANY/GLOBAL يحسم المستودعات ديناميكياً من القاعدة عند كل طلب —
  // المستودع الجديد يدخل النطاق تلقائياً.
  const trf = await post("/inventory/transfers", auth, {
    from_warehouse_id: whId, to_warehouse_id: wh2.id, auto_dispatch: true,
    lines: [{ product_id: prodA.id, qty: 20 }],
  });
  ok("T5a إنشاء تحويل 20 (إرسال فوري) → 201", trf.ok, JSON.stringify(trf.body).slice(0, 160));
  const trfId = trf.body.data?.id;
  bail(!trfId, "التحويل فشل");
  const trfRec = await post(`/inventory/transfers/${trfId}/receive`, auth, {});
  ok("T5b استلام التحويل → 200", trfRec.ok, JSON.stringify(trfRec.body).slice(0, 140));
  const destLayers = await db.costLayer.findMany({ where: { warehouseId: wh2.id, productId: prodA.id, sourceType: "TRANSFER_RECEIPT" } });
  ok("T5c طبقة الوجهة: 20@1200 — نفس تكلفة المصدر (لا تكلفة عشوائية §8)",
    destLayers.length === 1 && eq(destLayers[0].quantity, 20) && eq(destLayers[0].unitCost, 1200),
    JSON.stringify(destLayers.map((l) => ({ q: l.quantity?.toString(), c: l.unitCost?.toString() }))));
  const outCons = await db.costConsumption.findMany({ where: { refType: "TRANSFER_OUT", refId: trfId } });
  ok("T5d سجل الصرف TRANSFER_OUT موثق بتكلفة المصدر الفعلية",
    outCons.length >= 1 && eq(outCons.reduce((a, r) => a.plus(dec(r.totalCost)), new Decimal(0)), dec(20).mul(1200)),
    `rows=${outCons.length} sum=${outCons.reduce((a, r) => a.plus(dec(r.totalCost)), new Decimal(0)).toString()}`);
  await layerStockConsistency(companyId, "T5e الثابت الذهبي بعد التحويل (المستودعان)");

  // ---------- T6: Stocktake (§1/§2/§3) ----------
  console.log("\n■ T6 — Stocktake: زيادة عجز → طبقة/صرف بتكلفة فعلية");
  // حالة المصدر الحالية: 30@1200 متبقية من الشراء + 10@1000 مرتجع = 40
  const stCreate = await post("/inventory/stocktakes", auth, { warehouse_id: whId, notes: "جرد P4T" });
  const stId = stCreate.body.data?.id;
  bail(!stId, "إنشاء الجرد فشل");
  const stLineA = (stCreate.body.data?.lines ?? []).find((l) => l.productId === prodA.id);
  bail(!stLineA, "سطر الجرد للمنتج A غير موجود");
  const counted1 = dec(stLineA.systemQty).plus(5).toNumber(); // زيادة 5
  await patch("/inventory/stocktakes", auth, { id: stId, counts: [{ product_id: prodA.id, counted_qty: counted1 }] });
  const stPost1 = await post(`/inventory/stocktakes/${stId}`, auth, { action: "post" });
  ok("T6a ترحيل جرد بزيادة 5 → 200", stPost1.ok, JSON.stringify(stPost1.body).slice(0, 140));
  const stLayer = await db.costLayer.findFirst({ where: { sourceType: "STOCK_ADJUSTMENT", sourceId: stId, productId: prodA.id } });
  // تكلفة سطر الجرد = costPrice للمنتج لحظة إنشاء الجرد = المتوسط بعد الشراء 1066.6667
  const wavgAfterPurchase = moneyR(dec(100).mul(1000).plus(dec(50).mul(1200)).div(150));
  ok("T6b الزيادة أنشأت طبقة STOCK_ADJUSTMENT 5@متوسط_ساري (تكلفة سطر الجرد)",
    !!stLayer && eq(stLayer.quantity, 5) && eq(stLayer.unitCost, wavgAfterPurchase),
    JSON.stringify(stLayer && { q: stLayer.quantity?.toString(), c: stLayer.unitCost?.toString() }) + ` expected=${wavgAfterPurchase.toString()}`);

  // عجز: جرد ثانٍ بعجز 3
  const st2 = await post("/inventory/stocktakes", auth, { warehouse_id: whId, notes: "جرد عجز P4T" });
  const st2Id = st2.body.data?.id;
  const st2Line = (st2.body.data?.lines ?? []).find((l) => l.productId === prodA.id);
  bail(!st2Id || !st2Line, "الجرد الثاني فشل");
  const counted2 = dec(st2Line.systemQty).minus(3).toNumber(); // عجز 3
  await patch("/inventory/stocktakes", auth, { id: st2Id, counts: [{ product_id: prodA.id, counted_qty: counted2 }] });
  const st2Post = await post(`/inventory/stocktakes/${st2Id}`, auth, { action: "post" });
  ok("T6c ترحيل جرد بعجز 3 → 200", st2Post.ok, JSON.stringify(st2Post.body).slice(0, 140));
  // المصدر الآن: 10@1200 (بقي من الشراء 30-20) ثم 10@1000 ثم 5@1000 — العجز يستهلك الأقدم 3@1200
  const adjCons = await db.costConsumption.findMany({ where: { refType: "ADJUSTMENT", refId: st2Id, productId: prodA.id } });
  ok("T6d العجز صُرف من الأقدم بتكلفة فعلية 3@1200 (سجل ADJUSTMENT)",
    adjCons.length >= 1 && eq(adjCons.reduce((a, r) => a.plus(dec(r.totalCost)), new Decimal(0)), dec(3).mul(1200)),
    `sum=${adjCons.reduce((a, r) => a.plus(dec(r.totalCost)), new Decimal(0)).toString()}`);
  await layerStockConsistency(companyId, "T6e الثابت الذهبي بعد الجرد");

  // ---------- T7: Void Invoice (§6/§7) ----------
  console.log("\n■ T7 — Void Invoice: إلغاء بيع يعيد الطبقات بتكلفة الصرف");
  const balBeforeVoid = await db.stockBalance.findFirst({ where: { warehouseId: whId, productId: prodA.id } });
  const invVoid = await post("/sales/invoices", auth, {
    customer_id: walkinId, warehouse_id: whId, type: "CASH", currency_code: "IQD",
    lines: [{ product_id: prodA.id, qty: 5 }],
  });
  const invVoidId = invVoid.body.data?.id;
  bail(!invVoidId, "فاتورة الإلغاء فشلت");
  const voidLine = await db.salesInvoiceLine.findFirst({ where: { invoiceId: invVoidId, productId: prodA.id } });
  ok("T7a فاتورة 5 حبات بلقطة COGS", !!voidLine?.cogsTotal && dec(voidLine.cogsTotal).isPositive(), `cogs=${voidLine?.cogsTotal?.toString()}`);
  const vRes = await post(`/sales/invoices/${invVoidId}/void`, auth, { reason: "فحص إلغاء P4T" });
  ok("T7b إلغاء الفاتورة → 200", vRes.ok, JSON.stringify(vRes.body).slice(0, 140));
  const restoreLayer = await db.costLayer.findFirst({ where: { productId: prodA.id, sourceType: "VOID_RESTORE", sourceId: invVoidId }, orderBy: { id: "desc" } });
  ok("T7c طبقة VOID_RESTORE أُنشئت بتكلفة الصرف الفعلية",
    !!restoreLayer && eq(restoreLayer.quantity, 5), JSON.stringify(restoreLayer && { q: restoreLayer.quantity?.toString(), c: restoreLayer.unitCost?.toString() }));
  ok("T7c2 تكلفة طبقة الاسترجاع = تكلفة الصرف المسجلة",
    !!restoreLayer && !!voidLine?.cogsUnitCost && eq(restoreLayer.unitCost, voidLine.cogsUnitCost),
    `restore=${restoreLayer?.unitCost?.toString()} consumed=${voidLine?.cogsUnitCost?.toString()}`);
  const balAfterVoid = await db.stockBalance.findFirst({ where: { warehouseId: whId, productId: prodA.id } });
  ok("T7d المخزون عاد كما كان قبل الفاتورة",
    eq(balAfterVoid?.qty, dec(balBeforeVoid?.qty)), `${balBeforeVoid?.qty?.toString()} → ${balAfterVoid?.qty?.toString()}`);
  const voidHdr = await db.salesInvoice.findUnique({ where: { id: invVoidId } });
  ok("T7e لقطة COGS للفاتورة الملغاة باقية (تاريخية — لا تُمس §6)",
    voidHdr?.status === "VOID" && eq(voidHdr?.cogsTotal, voidLine?.cogsTotal), `status=${voidHdr?.status}`);
  await layerStockConsistency(companyId, "T7f الثابت الذهبي بعد الإلغاء");

  // ---------- T8: Negative stock prevention ----------
  console.log("\n■ T8 — منع المخزون السالب");
  const balA = await db.stockBalance.findFirst({ where: { warehouseId: whId, productId: prodA.id } });
  const tooMuch = dec(balA?.qty).plus(999).toNumber();
  const negInv = await post("/sales/invoices", auth, {
    customer_id: walkinId, warehouse_id: whId, type: "CASH", currency_code: "IQD",
    lines: [{ product_id: prodA.id, qty: tooMuch }],
  });
  ok("T8a بيع أكثر من المتاح → مرفوض STOCK_001", !negInv.ok && negInv.body?.code === "STOCK_001",
    `status=${negInv.status} code=${negInv.body?.code}`);
  const layersCountA = await db.costLayer.count({ where: { productId: prodA.id, status: "ACTIVE" } });
  ok("T8b لا طبقات جديدة أُنشئت بالرفض", layersCountA > 0, `count=${layersCountA}`);

  // ---------- T9-11: WAVG ثم STANDARD ثم LAST (منتج B) ----------
  console.log("\n■ T9 — WAVG: نفس أرقام الوثيقة → COGS = 120 × (160000/150) = 128000");
  await put("/settings/costing-method", auth, { costing_method: "WEIGHTED_AVERAGE" });
  const intakeB = await post("/inventory/movements", auth, {
    warehouse_id: whId, product_id: prodB.id, direction: "IN", qty: 100, unit_cost: 1000, note: "افتتاحي B",
  });
  ok("T9a إدخال افتتاحي B: 100@1000", intakeB.status === 201, JSON.stringify(intakeB.body).slice(0, 120));
  const buyB = await post("/purchases/invoices", auth, {
    supplier_id: sup.id, warehouse_id: whId, type: "CASH",
    lines: [{ product_id: prodB.id, qty: 50, unit_cost: 1200 }],
  });
  ok("T9b شراء B: 50@1200", buyB.ok, JSON.stringify(buyB.body).slice(0, 120));
  const invWavg = await post("/sales/invoices", auth, {
    customer_id: walkinId, warehouse_id: whId, type: "CASH", currency_code: "IQD",
    lines: [{ product_id: prodB.id, qty: 120 }],
  });
  const wavgId = invWavg.body.data?.id;
  bail(!wavgId, "فاتورة WAVG فشلت");
  const wavgLine = await db.salesInvoiceLine.findFirst({ where: { invoiceId: wavgId, productId: prodB.id } });
  ok("T9c WAVG COGS = 128000 بالضبط (بلا انحراف تقريب — R9)",
    eq(wavgLine?.cogsTotal, 128000), `cogs=${wavgLine?.cogsTotal?.toString()}`);
  ok("T9d cogsMethod = WEIGHTED_AVERAGE", wavgLine?.cogsMethod === "WEIGHTED_AVERAGE", `m=${wavgLine?.cogsMethod}`);

  console.log("\n■ T10 — STANDARD_COST: تكلفة معيارية 1100 منفصلة عن الشراء (§5)");
  await put("/settings/costing-method", auth, { costing_method: "STANDARD_COST" });
  const stdSet = await patch(`/products/${prodB.id}`, auth, { standard_cost: 1100 });
  ok("T10a ضبط standard_cost=1100 عبر PATCH", stdSet.ok && Number(stdSet.body.data?.standard_cost) === 1100, JSON.stringify(stdSet.body).slice(0, 120));
  const prodBDb1 = await db.product.findUnique({ where: { id: prodB.id } });
  ok("T10b التكلفة المعيارية منفصلة عن lastCost(1200) وcostPrice(المتوسط)",
    eq(prodBDb1?.standardCost, 1100) && eq(prodBDb1?.lastCost, 1200) && !eq(prodBDb1?.costPrice, 1100),
    `std=${prodBDb1?.standardCost?.toString()} last=${prodBDb1?.lastCost?.toString()} wavg=${prodBDb1?.costPrice?.toString()}`);
  const invStd = await post("/sales/invoices", auth, {
    customer_id: walkinId, warehouse_id: whId, type: "CASH", currency_code: "IQD",
    lines: [{ product_id: prodB.id, qty: 30 }],
  });
  const stdId = invStd.body.data?.id;
  bail(!stdId, "فاتورة STANDARD فشلت");
  const stdLine = await db.salesInvoiceLine.findFirst({ where: { invoiceId: stdId, productId: prodB.id } });
  ok("T10c COGS = 30 × 1100 = 33000 بالضبط بالتكلفة المعيارية",
    eq(stdLine?.cogsTotal, 33000) && stdLine?.cogsMethod === "STANDARD_COST",
    `cogs=${stdLine?.cogsTotal?.toString()} m=${stdLine?.cogsMethod}`);

  console.log("\n■ T11 — LAST_COST: آخر تكلفة شراء 1200");
  await put("/settings/costing-method", auth, { costing_method: "LAST_COST" });
  const invLast = await post("/sales/invoices", auth, {
    customer_id: walkinId, warehouse_id: whId, type: "CASH", currency_code: "IQD",
    lines: [{ product_id: prodB.id, qty: 20 }],
  });
  const lastId = invLast.body.data?.id;
  bail(!lastId, "فاتورة LAST فشلت");
  const lastLine = await db.salesInvoiceLine.findFirst({ where: { invoiceId: lastId, productId: prodB.id } });
  ok("T11a COGS = 20 × 1200 = 24000 بالضبط (آخر تكلفة شراء)",
    eq(lastLine?.cogsTotal, 24000) && lastLine?.cogsMethod === "LAST_COST",
    `cogs=${lastLine?.cogsTotal?.toString()} m=${lastLine?.cogsMethod}`);

  // ---------- T12: Historical invoice (§6) ----------
  console.log("\n■ T12 — Historical invoice: تغير التكلفة لاحقاً لا يمس الفواتير القديمة");
  await db.product.update({ where: { id: prodA.id }, data: { costPrice: new Decimal(99999) } });
  const fifoRecheck = await db.salesInvoiceLine.findUnique({ where: { id: fifoLine.id } });
  ok("T12a فاتورة FIFO القديمة: cogs=124000 بعد تغيير تكلفة المنتج لـ99999",
    eq(fifoRecheck?.cogsTotal, 124000) && eq(fifoRecheck?.cogsUnitCost, moneyR(dec(124000).div(120))),
    `cogs=${fifoRecheck?.cogsTotal?.toString()}`);
  const wavgRecheck = await db.salesInvoiceLine.findFirst({ where: { invoiceId: wavgId, productId: prodB.id } });
  ok("T12b فاتورة WAVG القديمة: cogs=128000 بلا تغيير",
    eq(wavgRecheck?.cogsTotal, 128000), `cogs=${wavgRecheck?.cogsTotal?.toString()}`);
  await db.product.update({ where: { id: prodA.id }, data: { costPrice: moneyR(dec(100).mul(1000).plus(dec(50).mul(1200)).div(150)) } });
  ok("T12c استعادة تكلفة المنتج A", true, "");

  // ---------- T13: التقارير §9 ----------
  console.log("\n■ T13 — تقارير التكلفة (§9): layers/inventory/cogs/variance");
  const repLayers = await get("/reports/costing-layers?warehouse_id=" + whId, auth);
  const rlRows = repLayers.body.data?.rows ?? [];
  ok("T13a costing-layers: طبقات A المتبقية بالترتيب (أقدم أولاً) + summary",
    repLayers.ok && rlRows.length > 0
    && rlRows.every((r) => Number(r.remaining_qty) > 0 && Number(r.unit_cost) >= 0)
    && typeof repLayers.body.data?.summary?.total_value === "number",
    `rows=${rlRows.length} summary=${JSON.stringify(repLayers.body.data?.summary)}`);
  // الأقدم أولاً: أول طبقة لبند A يجب أن تكون صرف العجز (بقايا 7@1200)
  const aLayers = rlRows.filter((r) => r.product_id === prodA.id);
  ok("T13b ترتيب FIFO في التقرير: الأقدم أولاً (7@1200 قبل 10@1000)",
    aLayers.length >= 2 && Number(aLayers[0].unit_cost) === 1200 && Number(aLayers[1].unit_cost) === 1000,
    JSON.stringify(aLayers.map((r) => ({ q: r.remaining_qty, c: r.unit_cost }))));

  const repInv = await get("/reports/costing-inventory", auth);
  const riA = (repInv.body.data?.rows ?? []).find((r) => r.product_id === prodA.id);
  const layersA = await db.costLayer.findMany({ where: { productId: prodA.id, status: "ACTIVE" } });
  const layersAValue = moneyR(layersA.reduce((acc, l) => acc.plus(qtyR(dec(l.remainingQuantity)).mul(moneyR(dec(l.unitCost)))), new Decimal(0)));
  ok("T13c costing-inventory: inventory_value = Σ متبقي×تكلفة من القاعدة",
    repInv.ok && !!riA && eq(riA.inventory_value, layersAValue) && Number(riA.wavg_cost) >= 0,
    `report=${riA?.inventory_value} recomputed=${layersAValue.toString()}`);
  ok("T13d أعمدة §9 كاملة: wavg + product_wavg + standard + last_purchase",
    riA && "wavg_cost" in riA && "product_wavg_cost" in riA && "standard_cost" in riA && "last_purchase_cost" in riA,
    JSON.stringify(riA && { w: riA.wavg_cost, pw: riA.product_wavg_cost, s: riA.standard_cost, l: riA.last_purchase_cost }));

  const repCogs = await get("/reports/costing-cogs", auth);
  const rcA = (repCogs.body.data?.rows ?? []).find((r) => r.product_id === prodA.id);
  const revenueA = moneyR(dec(rcA?.revenue));
  ok("T13e costing-cogs: gross_profit = revenue − cogs (من لقطات البنود)",
    repCogs.ok && !!rcA && eq(dec(rcA.revenue).minus(dec(rcA.cogs)), rcA.gross_profit) && dec(rcA.cogs).isPositive(),
    JSON.stringify(rcA && { rev: rcA.revenue, cogs: rcA.cogs, gp: rcA.gross_profit, m: rcA.cost_methods }));
  ok("T13f COGS التقرير = لقطة الفاتورة الفعلية (124000 × العائد المخصوم) — cogs > 0 وmethods FIFO",
    !!rcA && String(rcA.cost_methods).includes("FIFO"), `methods=${rcA?.cost_methods}`);

  const repVar = await get("/reports/costing-variance", auth);
  const rvB = (repVar.body.data?.rows ?? []).find((r) => r.product_id === prodB.id);
  ok("T13g costing-variance: variance_unit = wavg(1066.6667) − standard(1100) = −33.3333",
    repVar.ok && !!rvB && eq(rvB.variance_unit, moneyR(dec(prodBDb1.costPrice).minus(1100))),
    JSON.stringify(rvB && { s: rvB.standard_cost, w: rvB.wavg_cost, v: rvB.variance_unit }));

  // ---------- T14: ثابت نهائي شامل ----------
  await layerStockConsistency(companyId, "T14a الثابت الذهبي النهائي: كل الطبقات = كل الأرصدة");
  const allLayers = await db.costLayer.findMany({ where: { companyId } });
  ok("T14b سلامة الطبقات: remaining ≤ quantity لكل طبقة + الحالات صحيحة",
    allLayers.every((l) => dec(l.remainingQuantity).lte(dec(l.quantity)) && !dec(l.remainingQuantity).isNegative()
      && (l.status === "ACTIVE" ? dec(l.remainingQuantity).isPositive() : dec(l.remainingQuantity).lte(0))),
    `layers=${allLayers.length}`);
  const consAll = await db.costConsumption.findMany({ where: { companyId } });
  ok("T14c سلامة سجل الصرف: totalCost = moneyR(qty × unitCost) لكل صف",
    consAll.every((c) => eq(c.totalCost, moneyR(dec(c.qty).mul(dec(c.unitCost))))), `rows=${consAll.length}`);
}

main().catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
