// =====================================================================
// RP1-Audit — تدقيق إغلاق بيانات التسعير (MASTER REPAIR PROMPT — PHASE 1 §1)
// يفحص كل Company/Product/ProductPrice ويكتشف:
//   A) منتجات بلا أي ProductPrice نشط
//   B) منتجات بلا COST/PIECE نشط (مع تمييز من له costPrice>0 قابل للترحيل)
//   C) منتجات بلا SALE/PIECE نشط
//   D) منتج معبأ (packQty>1) بلا SALE/PACKAGE نشط
//   E) تكرار أسعار نشطة لنفس (company,product,priceType,unit,currency)
//   F) عملة/نوع/وحدة غير صالحة + مبالغ سالبة + أسعار صفرية معلوماتياً
// الناتج: docs/RP1_PRICE_AUDIT.md + backups/rp1-audit.json
// =====================================================================
import { PrismaClient } from "@prisma/client";
import { writeFileSync } from "node:fs";

const db = new PrismaClient();
const PRICE_TYPES = ["SALE", "COST", "WHOLESALE", "RETAIL", "SPECIAL", "PROMOTIONAL"];
const UNITS = ["PIECE", "PACKAGE"];
const CURRENCIES = ["IQD", "USD"];
const n = (v) => Number(v ?? 0);

const companies = await db.company.findMany({ select: { id: true, name: true } });
const out = { generatedAt: new Date().toISOString(), companies: [], totals: {} };
const T = { products: 0, noActivePrice: 0, noCostPiece: 0, noSalePiece: 0, packagedNoPackage: 0, dupGroups: 0, invalidRows: 0, zeroSaleRows: 0, migratable: 0 };

for (const c of companies) {
  const products = await db.product.findMany({
    where: { companyId: c.id, deletedAt: null },
    select: { id: true, name: true, code: true, packQty: true, packUnit: true, salePrice: true, costPrice: true, packSalePrice: true },
  });
  const prices = await db.productPrice.findMany({ where: { companyId: c.id } });
  const byProduct = new Map();
  for (const p of prices) {
    const arr = byProduct.get(p.productId) ?? [];
    arr.push(p);
    byProduct.set(p.productId, arr);
  }
  const co = { companyId: c.id, companyName: c.name, products: products.length, findings: {} };

  const noActive = [], noCost = [], noCostMigratable = [], noSale = [], packagedNoPack = [], zeroSale = [];
  for (const p of products) {
    const act = (byProduct.get(p.id) ?? []).filter((r) => r.isActive);
    const has = (t, u) => act.some((r) => r.priceType === t && r.unit === u);
    if (act.length === 0) noActive.push(p);
    if (!has("COST", "PIECE")) {
      noCost.push(p);
      if (n(p.costPrice) > 0) noCostMigratable.push(p);
    }
    if (!has("SALE", "PIECE")) noSale.push(p);
    if (n(p.packQty) > 1 && !has("SALE", "PACKAGE")) packagedNoPack.push(p);
    for (const r of act) {
      if (r.priceType === "SALE" && r.unit === "PIECE" && n(r.amount) === 0) zeroSale.push({ productId: p.id, name: p.name, priceId: r.id });
    }
  }

  // E) تكرارات نشطة
  const groups = new Map();
  for (const r of prices.filter((x) => x.isActive)) {
    const k = `${r.companyId}|${r.productId}|${r.priceType}|${r.unit}|${r.currency}`;
    const arr = groups.get(k) ?? [];
    arr.push(r);
    groups.set(k, arr);
  }
  const dups = [...groups.entries()].filter(([, arr]) => arr.length > 1).map(([k, arr]) => ({ key: k, ids: arr.map((r) => r.id), effectiveFroms: arr.map((r) => r.effectiveFrom) }));

  // F) صفوف غير صالحة
  const invalid = prices.filter((r) => !PRICE_TYPES.includes(r.priceType) || !UNITS.includes(r.unit) || !CURRENCIES.includes(r.currency) || n(r.amount) < 0);

  co.findings = {
    noActivePrice: noActive.map((p) => ({ id: p.id, name: p.name, code: p.code })),
    noCostPiece: { total: noCost.length, migratableCostPriceGt0: noCostMigratable.map((p) => ({ id: p.id, name: p.name, costPrice: n(p.costPrice) })) },
    noSalePiece: noSale.map((p) => ({ id: p.id, name: p.name, salePrice: n(p.salePrice) })),
    packagedNoPackagePrice: packagedNoPack.map((p) => ({ id: p.id, name: p.name, packQty: n(p.packQty), packUnit: p.packUnit, packSalePrice: p.packSalePrice == null ? null : n(p.packSalePrice) })),
    duplicateActiveGroups: dups,
    invalidRows: invalid.map((r) => ({ id: r.id, productId: r.productId, priceType: r.priceType, unit: r.unit, currency: r.currency, amount: n(r.amount) })),
    zeroSalePieceRows: zeroSale,
  };
  Object.assign(co.findings, {});
  out.companies.push(co);
  T.products += products.length;
  T.noActivePrice += noActive.length;
  T.noCostPiece += noCost.length;
  T.noSalePiece += noSale.length;
  T.packagedNoPackage += packagedNoPack.length;
  T.dupGroups += dups.length;
  T.invalidRows += invalid.length;
  T.zeroSaleRows += zeroSale.length;
  T.migratable += noCostMigratable.length + noSale.filter((p) => n(p.salePrice) > 0).length + packagedNoPack.filter((p) => p.packSalePrice != null && n(p.packSalePrice) > 0).length;
}
out.totals = T;

// ---- Markdown
let md = `# RP1 — تقرير تدقيق إغلاق بيانات التسعير\n\n_generated: ${out.generatedAt}_\n\n## الإجماليات\n\n| المؤشر | العدد |\n|---|---|\n| المنتجات | ${T.products} |\n| منتجات بلا أي سعر نشط (A) | ${T.noActivePrice} |\n| منتجات بلا COST/PIECE (B) | ${T.noCostPiece} |\n| منتجات بلا SALE/PIECE (C) | ${T.noSalePiece} |\n| معبأة بلا SALE/PACKAGE (D) | ${T.packagedNoPackage} |\n| مجموعات مكررة نشطة (E) | ${T.dupGroups} |\n| صفوف غير صالحة (F) | ${T.invalidRows} |\n| صفوف SALE/PIECE صفرية (معلوماتية) | ${T.zeroSaleRows} |\n| صفوف قابلة للترحيل من Legacy | ~${T.migratable} |\n\n`;
for (const c of out.companies) {
  const f = c.findings;
  md += `## شركة #${c.companyId} — ${c.companyName} (${c.products} منتجاً)\n\n`;
  md += `- A بلا أي سعر نشط: ${f.noActivePrice.length}${f.noActivePrice.length ? " → " + f.noActivePrice.map((p) => `#${p.id}:${p.name}`).join(" · ") : ""}\n`;
  md += `- B بلا COST/PIECE: ${f.noCostPiece.total}${f.noCostPiece.migratableCostPriceGt0.length ? ` (قابل للترحيل: ${f.noCostPiece.migratableCostPriceGt0.map((p) => `#${p.id}=${p.costPrice}`).join(" · ")})` : ""}\n`;
  md += `- C بلا SALE/PIECE: ${f.noSalePiece.length}${f.noSalePiece.length ? " → " + f.noSalePiece.map((p) => `#${p.id}:${p.name}(sale=${p.salePrice})`).join(" · ") : ""}\n`;
  md += `- D معبأة بلا SALE/PACKAGE: ${f.packagedNoPackagePrice.length}${f.packagedNoPackagePrice.length ? " → " + f.packagedNoPackagePrice.map((p) => `#${p.id}:${p.name}(packQty=${p.packQty},packSale=${p.packSalePrice})`).join(" · ") : ""}\n`;
  md += `- E مجموعات مكررة: ${f.duplicateActiveGroups.length}\n`;
  md += `- F صفوف غير صالحة: ${f.invalidRows.length}\n`;
  md += `- G صفوف SALE/PIECE صفرية: ${f.zeroSalePieceRows.length}\n\n`;
}
writeFileSync("docs/RP1_PRICE_AUDIT.md", md);
writeFileSync("backups/rp1-audit.json", JSON.stringify(out, null, 2));
console.log(md);
await db.$disconnect();
