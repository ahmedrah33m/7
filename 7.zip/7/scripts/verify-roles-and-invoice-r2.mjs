// =====================================================================
// E2E — تعديل الأدوار + تطوير الفاتورة (جولة 2)
//
// Section A — تعديل الأدوار:
//   A1 قائمة الأدوار مع الصلاحيات      A2 تعديل اسم/وصف الدور
//   A3 استعادة الاسم                    A4 صلاحيات OWNER محمية PERM_002
//   A5 عزل: دور شركة B من جلسة A → VAL_003   A6 عزل معاكس: دور A من جلسة B
//   A7 استبدال صلاحيات دور بالكامل      A8 كود صلاحية غير صالح
//   A10 دور يملكه المستخدم نفسه → PERM_001   A11 تعديل أدوارك الشخصية → PERM_001
//   A12 استبدال أدوار مستخدم (فردي)     A13 استبدال متعدد
//   A14 role_codes فارغة → 400          A15 دور غير موجود
//   A16 تعطيل مستخدمي الاختبار
//
// Section B — تطوير الفاتورة (جولة 2):
//   B1 فاتورة نقدية جديدة              B2 payments في التفاصيل
//   B3 تأكيد الاستلام والتوقيع          B4 منع التوقيع المكرر VAL_004
//   B5 تحصيل على فاتورة آجلة → يظهر في payments
//   B6 إلغاء الفاتورة → صف OUT في payments
//   B7 توقيع فاتورة ملغاة → VAL_004
// =====================================================================
const BASE = "http://localhost:3000";

let pass = 0, fail = 0, skip = 0;
function check(label, ok, extra = "") {
  console.log(`${ok ? "✅" : "❌"} ${label}${extra ? " — " + extra : ""}`);
  ok ? pass++ : fail++;
  if (!ok) process.exitCode = 1;
}
function note(label, why) {
  console.log(`⏭️  SKIP ${label} — ${why}`);
  skip++;
}

async function j(path, init = {}, token) {
  const res = await fetch(BASE + path, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(init.headers ?? {}),
    },
  });
  const body = await res.json().catch(() => ({}));
  return { status: res.status, body };
}
const login = async (u, p) =>
  (await j("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: u, password: p }) })).body?.data?.access_token;

const stamp = () => new Date().toISOString().replace(/[-:.TZ]/g, "").slice(0, 14); // فريد لكل تشغيل (يضم الوقت)

// ---------------------------------------------------------------- setup
const tokenA = await login("admin", "Admin@123");
check("دخول admin (شركة A)", !!tokenA);
const meA = await j("/api/v1/auth/me", {}, tokenA);
const adminUserId = meA.body?.data?.user?.id;
const adminRoleIds = (meA.body?.data?.roles ?? []).map((r) => r.id);

// =====================================================================
// SECTION A — تعديل الأدوار
// =====================================================================
console.log("\n━━━ A) تعديل الأدوار ━━━");

const rolesA = await j("/api/v1/admin/roles", {}, tokenA);
const roleList = rolesA.body?.data ?? [];
check("A1 قائمة الأدوار مع الصلاحيات", rolesA.status === 200 && roleList.length >= 11 && roleList.every((r) => Array.isArray(r.permissions)),
  `${roleList.length} دور`);
const auditor = roleList.find((r) => r.code === "AUDITOR");
const owner = roleList.find((r) => r.code === "OWNER");
const viewer = roleList.find((r) => r.code === "VIEWER");
const salesManager = roleList.find((r) => r.code === "SALES_MANAGER");

// A2 — تعديل اسم/وصف الدور (بلا تغيير صلاحيات)
const rename1 = await j("/api/v1/admin/roles", {
  method: "PATCH",
  body: JSON.stringify({ role_id: auditor.id, name: "مراجع أول", description: "قراءة كل شيء + سجل التدقيق (معدّل اختبارياً)" }),
}, tokenA);
check("A2 تعديل اسم ووصف الدور", rename1.status === 200 && rename1.body?.data?.name === "مراجع أول", rename1.body?.message ?? "");

// A3 — استعادة الاسم الأصلي
const rename2 = await j("/api/v1/admin/roles", {
  method: "PATCH",
  body: JSON.stringify({ role_id: auditor.id, name: "مراجع", description: "قراءة كل شيء + سجل التدقيق دون أي تعديل" }),
}, tokenA);
check("A3 استعادة اسم الدور", rename2.status === 200 && rename2.body?.data?.name === "مراجع", "");

// A4 — صلاحيات OWNER محمية
const ownerEdit = await j("/api/v1/admin/roles", {
  method: "PATCH",
  body: JSON.stringify({ role_id: owner.id, permissions: ["sales.invoices.view"] }),
}, tokenA);
check("A4 صلاحيات OWNER محمية (PERM_002)", ownerEdit.status === 403 && ownerEdit.body?.code === "PERM_002",
  `${ownerEdit.status} ${ownerEdit.body?.code ?? ""}`);

// A5/A6 — العزل الصارم للأدوار بين الشركات
const companiesList = await j("/api/v1/admin/companies", {}, tokenA);
const compB = (companiesList.body?.data ?? []).find((c) => c.code === "CO-B");
let bRoleIsolationOk = false, bRoleIsolationMsg = "شركة B غير موجودة";
if (compB?.id) {
  const sw = await j("/api/v1/auth/switch-company", { method: "POST", body: JSON.stringify({ company_id: compB.id }) }, tokenA);
  if (sw.status === 200) {
    const tokenB = sw.body?.data?.access_token ?? tokenA;
    const rolesB = await j("/api/v1/admin/roles", {}, tokenB);
    const bAuditor = (rolesB.body?.data ?? []).find((r) => r.code === "AUDITOR");
    // من جلسة B: تعديل دور الشركة A → غير موجود (عزل)
    const crossFromB = await j("/api/v1/admin/roles", {
      method: "PATCH", body: JSON.stringify({ role_id: auditor.id, name: "اختراق" }),
    }, tokenB);
    bRoleIsolationOk = crossFromB.status === 404 || (crossFromB.status === 403 && crossFromB.body?.code === "VAL_003");
    bRoleIsolationMsg = `${crossFromB.status} ${crossFromB.body?.code ?? ""}`;
    // من جلسة B: تعديل دور B نفسه → نجاح + استبدال صلاحيات كامل (A7)
    // (نسخة B من VIEWER تبدأ بصلاحية system.company.view فقط)
    const permReplace = await j("/api/v1/admin/roles", {
      method: "PATCH",
      body: JSON.stringify({ role_id: bAuditor.id, permissions: ["system.company.view", "sales.invoices.view", "sales.invoices.create"] }),
    }, tokenB);
    const permsAfter = permReplace.body?.data?.permissions ?? [];
    check("A7 استبدال صلاحيات دور بالكامل (شركة B)",
      permReplace.status === 200 && permsAfter.includes("sales.invoices.view") && permsAfter.includes("system.company.view") && permsAfter.length === 3,
      `${permReplace.status} count=${permsAfter.length}`);
    // A8 — كود صلاحية غير صالح (VAL_003 → 404 بلا تسريب)
    const badPerm = await j("/api/v1/admin/roles", {
      method: "PATCH", body: JSON.stringify({ role_id: bAuditor.id, permissions: ["fake.module.view"] }),
    }, tokenB);
    check("A8 كود صلاحية غير صالح → VAL_003", [400, 404].includes(badPerm.status) && badPerm.body?.code === "VAL_003", `${badPerm.status} ${badPerm.body?.code ?? ""}`);
    // استعادة: أعد صلاحيات AUDITOR في B الافتراضية (كل core view + قراءات) — نعيدها إلى نفس مستوى نسخة A
    await j("/api/v1/admin/roles", {
      method: "PATCH", body: JSON.stringify({ role_id: bAuditor.id, permissions: auditor.permissions }),
    }, tokenB);
    // عودة إلى الشركة A
    const compA = (companiesList.body?.data ?? []).find((c) => c.id === meA.body?.data?.company?.id);
    if (compA?.id) await j("/api/v1/auth/switch-company", { method: "POST", body: JSON.stringify({ company_id: compA.id }) }, tokenA);
  } else {
    note("A5/A6/A7 عزل الأدوار بين الشركات", "فشل التبديل إلى شركة B");
  }
} else {
  note("A5/A6/A7 عزل الأدوار بين الشركات", "لا توجد شركة CO-B");
}
check("A5 عزل: دور شركة A غير قابل للتعديل من جلسة B", bRoleIsolationOk, bRoleIsolationMsg);

// A10 — لا تعديل صلاحيات دور تملكه بنفسك
const t1Stamp = stamp();
const createT1 = await j("/api/v1/admin/users", {
  method: "POST",
  body: JSON.stringify({
    username: `role_t1_${t1Stamp}`, password: "RoleT1@12345", full_name: "مختبر الأدوار 1",
    role_code: "OWNER", scope_type: "COMPANY",
  }),
}, tokenA);
const t1Created = createT1.status === 201;
// امنح T1 دورين (OWNER + SALES_MANAGER) — تعديل أدوار مستخدم آخر يعمل
let t1MultiGranted = false;
if (t1Created) {
  const grant = await j("/api/v1/admin/users", {
    method: "PATCH",
    body: JSON.stringify({ user_id: createT1.body?.data?.id, role_codes: ["OWNER", "SALES_MANAGER"] }),
  }, tokenA);
  t1MultiGranted = grant.status === 200;
}
check("A9 منح مستخدم دورين معاً (OWNER+SALES_MANAGER)", t1Created && t1MultiGranted, `${createT1.status} ${createT1.body?.message ?? ""}`);

const tokenT1 = t1Created ? await login(`role_t1_${t1Stamp}`, "RoleT1@12345") : null;
if (tokenT1) {
  const selfOwned = await j("/api/v1/admin/roles", {
    method: "PATCH", body: JSON.stringify({ role_id: salesManager.id, permissions: ["sales.invoices.view"] }),
  }, tokenT1);
  check("A10 منع تعديل صلاحيات دورٍ يملكه المستخدم (PERM_001)", selfOwned.status === 403 && selfOwned.body?.code === "PERM_001",
    `${selfOwned.status} ${selfOwned.body?.code ?? ""}`);
} else {
  note("A10 منع تعديل دورك المملوك", "لم يُنشأ مستخدم T1");
}

// A11 — لا تعديل أدوارك الشخصية
const selfRoles = await j("/api/v1/admin/users", {
  method: "PATCH",
  body: JSON.stringify({ user_id: adminUserId, role_codes: ["VIEWER"] }),
}, tokenA);
check("A11 منع تعديل أدوارك الشخصية (PERM_001)", selfRoles.status === 403 && selfRoles.body?.code === "PERM_001",
  `${selfRoles.status} ${selfRoles.body?.code ?? ""}`);

// A12/A13 — استبدال أدوار مستخدم آخر (فردي ثم متعدد)
const createT2 = await j("/api/v1/admin/users", {
  method: "POST",
  body: JSON.stringify({
    username: `role_target_${t1Stamp}`, password: "RoleT2@12345", full_name: "هدف تعديل الأدوار",
    role_code: "CASHIER", scope_type: "COMPANY",
  }),
}, tokenA);
const t2Id = createT2.body?.data?.id;
let singleOk = false, multiOk = false, bothShown = false;
if (t2Id) {
  const single = await j("/api/v1/admin/users", {
    method: "PATCH", body: JSON.stringify({ user_id: t2Id, role_codes: ["VIEWER"] }),
  }, tokenA);
  singleOk = single.status === 200;
  const usersAfterSingle = await j("/api/v1/admin/users", {}, tokenA);
  const t2Row = (usersAfterSingle.body?.data ?? []).find((u) => u.id === t2Id);
  singleOk = singleOk && t2Row?.roles?.length === 1 && t2Row.roles[0].code === "VIEWER";

  const multi = await j("/api/v1/admin/users", {
    method: "PATCH", body: JSON.stringify({ user_id: t2Id, role_codes: ["CASHIER", "AUDITOR"] }),
  }, tokenA);
  multiOk = multi.status === 200;
  const usersAfterMulti = await j("/api/v1/admin/users", {}, tokenA);
  const t2b = (usersAfterMulti.body?.data ?? []).find((u) => u.id === t2Id);
  const codes = (t2b?.roles ?? []).map((r) => r.code).sort();
  bothShown = codes.join(",") === "AUDITOR,CASHIER";
}
check("A12 استبدال أدوار مستخدم بدور واحد", singleOk, "");
check("A13 منح دورين معاً وتظهر في الجدول", multiOk && bothShown, "");

// A14 — role_codes فارغة
const emptyRoles = await j("/api/v1/admin/users", {
  method: "PATCH", body: JSON.stringify({ user_id: t2Id ?? 1, role_codes: [] }),
}, tokenA);
check("A14 role_codes فارغة → رفض", [400, 422].includes(emptyRoles.status), `${emptyRoles.status}`);

// A15 — دور غير موجود
const badRole = await j("/api/v1/admin/users", {
  method: "PATCH", body: JSON.stringify({ user_id: t2Id ?? 1, role_codes: ["NOPE_ROLE"] }),
}, tokenA);
check("A15 دور غير موجود → VAL_003", [400, 404].includes(badRole.status) && badRole.body?.code === "VAL_003", `${badRole.status} ${badRole.body?.code ?? ""}`);

// A16 — تعطيل مستخدمي الاختبار (نظافة القائمة)
if (t2Id) await j("/api/v1/admin/users", { method: "PATCH", body: JSON.stringify({ user_id: t2Id, is_active: false }) }, tokenA);
if (t1Created) await j("/api/v1/admin/users", { method: "PATCH", body: JSON.stringify({ user_id: createT1.body?.data?.id, is_active: false }) }, tokenA);
console.log("🧹 عُطّل مستخدما الاختبار role_t1/role_target");

// =====================================================================
// SECTION B — تطوير الفاتورة (جولة 2)
// =====================================================================
console.log("\n━━━ B) تطوير الفاتورة — جولة 2 ━━━");

const scopeA = meA.body?.data?.scope ?? {};
const whId = (scopeA.warehouses ?? [])[0]?.id;
const prods = await j("/api/v1/products?per_page=100", {}, tokenA);
const product = (prods.body?.data ?? []).find((p) => p.stock_total > 0) ?? (prods.body?.data ?? [])[0];
const walkin = await j("/api/v1/customers/default-walkin", {}, tokenA);
const walkinId = walkin.body?.data?.id;

let inv1Id = null, inv1Number = null;
if (whId && product && walkinId) {
  const inv1 = await j("/api/v1/sales/invoices", {
    method: "POST",
    body: JSON.stringify({
      customer_id: walkinId, warehouse_id: whId, type: "CASH",
      sale_type: "CASH", payment_method: "CASH", paid_amount: 6000,
      lines: [{ product_id: product.id, qty: 2 }],
    }),
  }, tokenA);
  inv1Id = inv1.body?.data?.id;
  inv1Number = inv1.body?.data?.number;
  check("B1 فاتورة نقدية جديدة (POSTED)", inv1.status === 201 && inv1.body?.data?.status === "POSTED",
    `${inv1.status} ${inv1Number ?? inv1.body?.message ?? ""}`);
} else {
  note("B1-B7", "بيانات أساسية ناقصة (مستودع/منتج/زبون متردد)");
}

if (inv1Id) {
  // B2 — payments موجود في التفاصيل (الدفع النقدي الأصلي يظهر كصف SALES_INVOICE_CASH)
  const det1 = await j(`/api/v1/sales/invoices/${inv1Id}`, {}, tokenA);
  const det1d = det1.body?.data ?? {};
  const cashInRow = (det1d.payments ?? []).find((p) => p.direction === "IN" && p.category === "COLLECTION");
  check("B2 التفاصيل تتضمن payments (دفعة إنشاء الفاتورة النقدية)", det1.status === 200 && Array.isArray(det1d.payments) && det1d.payments.length === 1 && !!cashInRow,
    `payments=${det1d.payments?.length ?? "?"} first=${cashInRow?.amount ?? "—"}`);

  // B3 — تأكيد الاستلام والتوقيع
  const receipt = await j(`/api/v1/sales/invoices/${inv1Id}/confirm-receipt`, {
    method: "POST",
    body: JSON.stringify({ receiver_name: "أحمد المستلم", receiver_phone: "07701234567" }),
  }, tokenA);
  check("B3 تأكيد الاستلام والتوقيع", receipt.status === 200 && !!receipt.body?.data?.signed_at,
    `${receipt.status} ${receipt.body?.message ?? ""}`);

  // B4 — منع التوقيع المكرر (VAL_004 → 409)
  const receipt2 = await j(`/api/v1/sales/invoices/${inv1Id}/confirm-receipt`, {
    method: "POST",
    body: JSON.stringify({ receiver_name: "موقّع ثانٍ" }),
  }, tokenA);
  check("B4 منع التوقيع المكرر (VAL_004)", receipt2.status === 409 && receipt2.body?.code === "VAL_004",
    `${receipt2.status} ${receipt2.body?.code ?? ""}`);

  // B6 — إلغاء الفاتورة → صف OUT في payments (استرداد من SALES_INVOICE_VOID)
  const voided = await j(`/api/v1/sales/invoices/${inv1Id}/void`, {
    method: "POST", body: JSON.stringify({ reason: "اختبار سجل المدفوعات — استرداد كامل" }),
  }, tokenA);
  const det2 = await j(`/api/v1/sales/invoices/${inv1Id}`, {}, tokenA);
  const det2d = det2.body?.data ?? {};
  const outRow = (det2d.payments ?? []).find((p) => p.direction === "OUT");
  check("B6 إلغاء الفاتورة يُظهر صف استرداد OUT في payments", voided.status === 200 && !!outRow && Number(outRow.amount) === Number(det2d.paid_amount),
    `payments=${(det2d.payments ?? []).length} OUT=${outRow?.amount ?? "—"} paid=${det2d.paid_amount}`);

  // B7 — توقيع فاتورة ملغاة → VAL_004 (409)
  const receiptVoid = await j(`/api/v1/sales/invoices/${inv1Id}/confirm-receipt`, {
    method: "POST", body: JSON.stringify({ receiver_name: "محاولة على ملغاة" }),
  }, tokenA);
  check("B7 توقيع فاتورة ملغاة مرفوض (VAL_004)", receiptVoid.status === 409 && receiptVoid.body?.code === "VAL_004",
    `${receiptVoid.status} ${receiptVoid.body?.code ?? ""}`);
}

// B5 — تحصيل على فاتورة آجلة → يظهر في payments
const customers = await j("/api/v1/customers?per_page=100", {}, tokenA);
const registered = (customers.body?.data ?? []).find(
  (c) => !c.is_walkin && c.status === "ACTIVE" && Number(c.credit_limit ?? 0) > 0 && c.customer_type === "REGISTERED"
);
if (inv1Id !== null && registered && whId && product) {
  const inv2 = await j("/api/v1/sales/invoices", {
    method: "POST",
    body: JSON.stringify({
      customer_id: registered.id, warehouse_id: whId, type: "CREDIT",
      sale_type: "CREDIT", payment_method: "CASH", paid_amount: 0,
      lines: [{ product_id: product.id, qty: 1 }],
    }),
  }, tokenA);
  if (inv2.status === 201) {
    const inv2Id = inv2.body?.data?.id;
    const cashboxes = await j("/api/v1/finance/cashboxes", {}, tokenA);
    const box = (cashboxes.body?.data ?? []).find((b) => b.is_active);
    if (box) {
      const total = inv2.body?.data?.grand_total ?? 5000;
      const collect = await j("/api/v1/finance/transactions", {
        method: "POST",
        body: JSON.stringify({
          kind: "collection", customer_id: registered.id, cashbox_id: box.id,
          amount: Math.min(2000, total), invoice_id: inv2Id,
          note: "تحصيل اختبار سجل المدفوعات",
        }),
      }, tokenA);
      const det3 = await j(`/api/v1/sales/invoices/${inv2Id}`, {}, tokenA);
      const d3 = det3.body?.data ?? {};
      const inRow = (d3.payments ?? []).find((p) => p.direction === "IN");
      check("B5 تحصيل جزئي يظهر في payments وحدّث المدفوع",
        collect.status === 201 && !!inRow && Number(d3.paid_amount) > 0,
        `paid=${d3.paid_amount} IN=${inRow?.amount ?? "—"}`);
      // تنظيف: أعد الفاتورة الآجلة لوضع سليم — لا إلغاء (تبقى للعرض) — لكن حدّث لا شيء
    } else {
      note("B5", "لا صندوق نقدي نشط");
    }
  } else {
    note("B5", `فشل إنشاء فاتورة آجلة: ${inv2.body?.message ?? inv2.status}`);
  }
} else {
  note("B5", "لا عميل مسجل بحد ائتماني");
}

// =====================================================================
console.log(`\n━━━ النتيجة: ${pass} نجاح · ${fail} فشل · ${skip} تخطّي ━━━`);
process.exit(fail ? 1 : 0);
