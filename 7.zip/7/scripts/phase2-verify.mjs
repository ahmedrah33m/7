// =====================================================================
// Phase 2 — بطارية التحقق الشاملة E2E (§13 + DoD)
// تشغيل: bun run scripts/phase2-verify.mjs   (يتطلب dev server على :3000)
//
// التغطية:
//   V1-V7   التحقق المركزي للتعبئة (POST/PATCH/IMPORT) — §3
//   S1-S4   بنية المنتج: الأساس/التعبئة/11 حبة + أسعار بعملتها — §1/§2/§5/§6
//   ST      شراء 10 كراتين (مخزون بالحبات)
//   M1-M5   المثال الإلزامي §9: 5 كراتين = 130$ · 3 حبات ≈ 7.090909$ · مختلط
//   O1-O4   الكرتون المفتوح §10: كرتونة مغلقة سُحبت كاملة + مفتوحة بقي 8 — لا كسور
//   C1-C3   العملة §7: فاتورة IQD لمنتج مسعّر بالدولار + سعر الصرف + PRD_006 بلا سعر
//   H1-H2   لقطة الفاتورة غير قابلة للتغيير بعد تعديل السعر — §8
//   D1-D5   Definition of Done
// =====================================================================
const BASE = "http://localhost:3000/api/v1";
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

let PASS = 0, FAIL = 0;
const failures = [];
function ok(name, cond, detail = "") {
  if (cond) { PASS++; console.log(`  ✓ ${name}`); }
  else { FAIL++; failures.push({ name, detail }); console.log(`  ✗ ${name} — ${detail}`); }
}
async function jfetch(path, init) {
  const res = await fetch(`${BASE}${path}`, init);
  const body = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, body };
}
const post = (path, auth, data) => jfetch(path, { method: "POST", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(data) });
const patch = (path, auth, data) => jfetch(path, { method: "PATCH", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(data) });
const get = (path, auth) => jfetch(path, { headers: auth });
const approx = (a, b, tol = 0.01) => Math.abs(a - b) <= tol;

async function main() {
  console.log("=".repeat(70));
  console.log("PHASE 2 VERIFY — Units · Packaging · Pricing · Currency");
  console.log("=".repeat(70));

  // ---------- الدخول + شركة الاختبار (3 = شركة B) ----------
  const login = await post("/auth/login", {}, { username: "admin", password: "Admin@123" });
  const t1 = login.body.data?.access_token;
  ok("SETUP login", !!t1, JSON.stringify(login.body).slice(0, 100));
  const sw = await post("/auth/switch-company", { authorization: `Bearer ${t1}` }, { company_id: 3 });
  const auth = { authorization: `Bearer ${sw.body.data?.access_token ?? ""}`, "content-type": "application/json" };
  ok("SETUP switch company B", !!sw.body.data?.access_token, JSON.stringify(sw.body).slice(0, 100));

  const me = await get("/auth/me", auth);
  const wh = me.body.data?.warehouses?.[0];
  ok("SETUP warehouse", !!wh, "no warehouse");
  const walkin = await get("/customers/default-walkin", auth);
  const custId = walkin.body.data?.id;
  ok("SETUP walk-in customer", !!custId, "no customer");

  let sup = (await get("/suppliers", auth)).body.data?.find((s) => s.is_active);
  if (!sup) {
    const created = await post("/suppliers", auth, { name: "مورد اختبار P2", phone: "07700000000" });
    sup = created.body.data;
  }
  ok("SETUP supplier", !!sup?.id, "no supplier");

  const suffix = Date.now().toString().slice(-6);
  const nameA = `شامبو اختبار P2 ${suffix}`;

  // ---------- §3: التحقق المركزي ----------
  console.log("\n■ §3 Packaging validation (server-side)");
  let r = await post("/products", auth, { name: `V1-${suffix}`, unit: "حبة", pack_unit: "كرتون", pack_qty: 1 });
  ok("V1 packQty<=1 → 422 PRD_002", r.status === 422 && r.body.code === "PRD_002", `got ${r.status} ${r.body.code}`);

  r = await post("/products", auth, { name: `V2-${suffix}`, unit: "كرتون", pack_unit: "كرتون", pack_qty: 11 });
  ok("V2 packUnit==unit → 422 PRD_003", r.status === 422 && r.body.code === "PRD_003", `got ${r.status} ${r.body.code}`);

  r = await post("/products", auth, { name: `V2b-${suffix}`, unit: "كرتونة", pack_unit: "كرتون", pack_qty: 11 });
  ok("V2b كرتونة/كرتون نفس العائلة → PRD_003", r.status === 422 && r.body.code === "PRD_003", `got ${r.status} ${r.body.code}`);

  r = await post("/products", auth, { name: `V3-${suffix}`, unit: "حبة", pack_sale_price: 100 });
  ok("V3 packPrice بلا packUnit → 422 PRD_004", r.status === 422 && r.body.code === "PRD_004", `got ${r.status} ${r.body.code}`);

  r = await post("/products", auth, { name: `V4-${suffix}`, unit: "حبة", pack_unit: "كرتون" });
  ok("V4 packUnit بلا packQty → 422 PRD_005", r.status === 422 && r.body.code === "PRD_005", `got ${r.status} ${r.body.code}`);

  r = await post("/products", auth, { name: `V5-${suffix}`, unit: "حبة", pack_unit: "كرتون", pack_qty: 0 });
  ok("V5 packQty=0 → 422 PRD_002", r.status === 422 && r.body.code === "PRD_002", `got ${r.status} ${r.body.code}`);

  // USD بلا سعر صرف: نحجب إعداد الشركة مؤقتاً ثم نعيده
  const rateSetting = await db.setting.findFirst({ where: { companyId: 3, key: "currency.usd_rate_iqd" } });
  const rateValue = rateSetting?.value ?? null;
  if (rateSetting) await db.setting.update({ where: { id: rateSetting.id }, data: { value: JSON.stringify(0) } });
  r = await post("/products", auth, { name: `V6-${suffix}`, unit: "حبة", sale_price: 26, sale_currency: "USD" });
  const v6ok = r.status === 422 && r.body.code === "PRD_006";
  if (rateSetting) await db.setting.update({ where: { id: rateSetting.id }, data: { value: rateValue } });
  else await db.setting.create({ data: { companyId: 3, key: "currency.usd_rate_iqd", value: rateValue ?? JSON.stringify(1550), groupName: "currency" } });
  ok("V6 سعر USD بلا سعر صرف → 422 PRD_006 (لا تخمين 1300)", v6ok, `got ${r.status} ${r.body.code}`);

  r = await post("/products", auth, { name: `V7-${suffix}`, unit: "حبة", pack_unit: "كرتون", pack_qty: 11, pack_sale_price: 40300, sale_price: 3663.64, cost_price: 38750 });
  ok("V7 منتج غير معبأ صالح → 201", r.status === 201, `got ${r.status} ${r.body.code ?? ""}`);
  if (r.body.data?.id) await patch(`/products/${r.body.data.id}`, auth, { is_active: false });

  // PATCH: تحويل منتج لجعله فاسداً مرفوض
  r = await post("/products", auth, { name: `V8-${suffix}`, unit: "علبة", sale_price: 10 });
  const v8id = r.body.data?.id;
  const pr = await patch(`/products/${v8id}`, auth, { unit: "كرتون", pack_unit: "كرتون", pack_qty: 11 });
  ok("V8 PATCH إلى unit==packUnit → 422 PRD_003", pr.status === 422 && pr.body.code === "PRD_003", `got ${pr.status} ${pr.body.code}`);

  // IMPORT: صف فاسد يُبلّغ عنه ولا يوقف الصالح
  const imp = await post("/products/import", auth, {
    csv: `اسم,بيع,تكلفة,وحدة,باركود,حد,تعبئة,عدد,سعر-كرتونة
استيراد-صالح-${suffix},50,30,حبة,,,كرتون,6,300
استيراد-فاسد-${suffix},50,30,كرتون,,,كرتون,6,300`,
  });
  const impData = imp.body.data;
  ok("IMPORT صالح يُنشأ والفاسد يُبلّغ", imp.ok && impData?.created === 1 && impData?.errors?.length === 1,
    JSON.stringify(impData));

  // ---------- §1/§2/§5/§6: بنية المنتج والأسعار ----------
  console.log("\n■ §1/§2/§5/§6 Product structure + priced-in-USD");
  r = await post("/products", auth, {
    name: nameA, unit: "علبة",
    pack_unit: "كرتون", pack_qty: 11,
    pack_sale_price: 26, pack_sale_currency: "USD",
    sale_price: 2.363636, sale_currency: "USD",
    cost_price: 25, cost_currency: "USD",
    exchange_rate: 1550,
    min_stock: 5,
  });
  const prodId = r.body.data?.id;
  ok("S1 منتج معبأ بأسعار USD → 201", r.status === 201 && !!prodId, `got ${r.status} ${JSON.stringify(r.body).slice(0, 120)}`);

  const d = r.body.data ?? {};
  ok("S2 unit=علبة pack=كرتون×11", d.unit === "علبة" && d.pack_unit === "كرتون" && Number(d.pack_qty) === 11,
    `unit=${d.unit} pack=${d.pack_unit}×${d.pack_qty}`);

  const prods = await get("/products?per_page=100", auth);
  const pA = prods.body.data?.find((p) => p.id === prodId);
  ok("S3 أسعار مهيكلة كما دخلت: 26 USD/PACKAGE · 2.363636 USD/PIECE · 25 USD COST",
    pA?.prices?.sale_package?.amount === 26 && pA?.prices?.sale_package?.currency === "USD"
    && approx(pA?.prices?.sale_piece?.amount ?? 0, 2.363636, 1e-6) && pA?.prices?.sale_piece?.currency === "USD"
    && pA?.prices?.cost_piece?.amount === 25 && pA?.prices?.cost_piece?.currency === "USD",
    JSON.stringify(pA?.prices));
  ok("S4 إسقاط IQD: كرتون 40300 · حبة 3663.64 · تكلفة 38750",
    Number(pA?.pack_sale_price) === 40300 && approx(Number(pA?.sale_price), 3663.64) && approx(Number(pA?.cost_price), 38750),
    `pack=${pA?.pack_sale_price} sale=${pA?.sale_price} cost=${pA?.cost_price}`);
  ok("S5 GET يعرض العملة المصدر وسعر الشركة (DoD: لا USD/1300)",
    pA?.pack_sale_currency === "USD" && Number(pA?.company_usd_rate) === 1550,
    `cur=${pA?.pack_sale_currency} rate=${pA?.company_usd_rate}`);

  // ---------- المخزون: شراء 10 كراتين ----------
  console.log("\n■ Stock setup — purchase 10 cartons (110 pieces)");
  const pieceCost = Math.round((25 * 1550 / 11) * 1e6) / 1e6; // 3522.727273 د.ع/حبة
  const buy = await post("/purchases/invoices", auth, {
    supplier_id: sup.id, warehouse_id: wh.id, type: "CASH",
    lines: [{ product_id: prodId, qty: 110, unit_cost: pieceCost }],
  });
  ok("ST شراء 110 حبة (10 كراتين)", buy.ok, JSON.stringify(buy.body).slice(0, 140));

  let prev = await post("/sales/invoices/preview", auth, { customer_id: custId, warehouse_id: wh.id, product_ids: [prodId] });
  const pkg0 = prev.body.data?.packages?.[String(prodId)];
  ok("ST العبوات: 10 كراتين مغلقة", Number(pkg0?.closed_packages) === 10 && Number(pkg0?.open_packages) === 0,
    JSON.stringify(pkg0));

  // ---------- §9: المثال الإلزامي ----------
  console.log("\n■ §9 Mandatory example — 26 USD/carton · 11 pieces");
  // M1: 5 كراتين بفاتورة دولار
  let inv = await post("/sales/invoices", auth, {
    customer_id: custId, warehouse_id: wh.id, type: "CASH",
    currency_code: "USD", exchange_rate: 1550,
    lines: [{ product_id: prodId, package_qty: 5, loose_qty: 0 }],
  });
  ok("M1 فاتورة 5 كراتين USD → 201", inv.ok, JSON.stringify(inv.body).slice(0, 160));
  const m1 = inv.body.data;
  ok("M2 الإجمالي المخزن 201,500 د.ع (5×40300)", Number(m1?.grand_total) === 201500, `grand=${m1?.grand_total}`);
  ok("M3 المعروض بالدولار = 130.00$ بالضبط", approx(Number(m1?.grand_total) / 1550, 130, 1e-9), `$${(Number(m1?.grand_total) / 1550).toFixed(4)}`);

  // M2: 3 حبات
  inv = await post("/sales/invoices", auth, {
    customer_id: custId, warehouse_id: wh.id, type: "CASH",
    currency_code: "USD", exchange_rate: 1550,
    lines: [{ product_id: prodId, package_qty: 0, loose_qty: 3 }],
  });
  const m2 = inv.body.data;
  ok("M4 3 حبات = 10,990.92 د.ع ≈ $7.090909", inv.ok && approx(Number(m2?.grand_total) / 1550, 7.090909, 0.001),
    `grand=${m2?.grand_total} → $${(Number(m2?.grand_total) / 1550).toFixed(6)}`);

  // M3: مختلط 1 كرتون + 3 حبات
  inv = await post("/sales/invoices", auth, {
    customer_id: custId, warehouse_id: wh.id, type: "CASH",
    currency_code: "USD", exchange_rate: 1550,
    lines: [{ product_id: prodId, package_qty: 1, loose_qty: 3 }],
  });
  const m3 = inv.body.data;
  ok("M5 مختلط 1 كرتون + 3 حبات ≈ $33.0909 (26 + 7.0909)", inv.ok && approx(Number(m3?.grand_total) / 1550, 33.090909, 0.001),
    `grand=${m3?.grand_total}`);

  // لقطة السعر على بنود M3 (§8): السعر الافتراضي مصدره USD بمعامل 1550
  const m3lines = await db.salesInvoiceLine.findMany({ where: { invoiceId: m3.id } });
  ok("M6 لقطة البند: priceCurrency=USD + rate=1550 + وحدات (علبة/كرتون)",
    m3lines.every((l) => l.priceCurrency === "USD" && Number(l.priceExchangeRate) === 1550
      && l.baseUnitLabel === "علبة" && l.packageUnitLabel === "كرتون" && l.costCurrency === "USD"),
    JSON.stringify(m3lines.map((l) => ({ c: l.priceCurrency, r: l.priceExchangeRate, b: l.baseUnitLabel, pk: l.packageUnitLabel }))));

  // ---------- §10: الكرتون المفتوح ----------
  console.log("\n■ §10 Open carton — whole sealed consumed + 8 remaining");
  // بعد 5 كراتين (M1) + 1 كرتون + 3 حبات (M3) + 3 حبات (M2):
  // 110 − 55 = 55 → 55 − 14 = 41 → 41 − 3 = 38 = 3 مغلقة (33) + مفتوحة (5)
  prev = await post("/sales/invoices/preview", auth, { customer_id: custId, warehouse_id: wh.id, product_ids: [prodId] });
  const pkg = prev.body.data?.packages?.[String(prodId)];
  ok("O1 كراتين مغلقة كاملة = 3", Number(pkg?.closed_packages) === 3, JSON.stringify(pkg));
  ok("O2 كرتونة مفتوحة واحدة بقي فيها 5 حبات", Number(pkg?.open_packages) === 1 && Number(pkg?.open_qty) === 5, JSON.stringify(pkg));

  // ملاحظة §10 عبر دفتر التعبئة (أدق من النص): بند M3 يجب أن يسجل
  // ISSUE كامل 11 حبة (كرتونة مغلقة سُحبت كاملة) + سحب 3 حبات للحبات المفردة
  const m3Ledger = await db.packagingLedger.findMany({
    where: { refType: "SALES_INVOICE", refId: m3.id, productId: prodId, direction: "ISSUE" },
  });
  const wholeIssue = m3Ledger.find((r) => Number(r.issuedQty) === 11 && /كاملة/.test(r.note ?? ""));
  const looseIssue = m3Ledger.find((r) => Number(r.issuedQty) === 3);
  ok("O3 دفتر التعبئة: ISSUE كامل 11 (كرتونة كاملة) + ISSUE 3 حبات",
    !!wholeIssue && !!looseIssue,
    JSON.stringify(m3Ledger.map((r) => ({ q: r.issuedQty, n: r.note }))));

  const pkgRows = await db.package.findMany({ where: { productId: prodId, status: { not: "EMPTY" } } });
  ok("O4 لا كسور فيزيائية — كل العبوات أعداد صحيحة (DoD)",
    pkgRows.every((k) => Number.isInteger(Number(String(k.remainingQty))) && Number.isInteger(Number(String(k.originalQty)))),
    JSON.stringify(pkgRows.map((k) => ({ s: k.status, r: k.remainingQty }))));
  const bal = await db.stockBalance.findFirst({ where: { productId: prodId, warehouseId: wh.id } });
  ok("O5 الرصيد 38 حبة صحيح (لا 3.45 كرتون)", Number(bal?.qty) === 38, `qty=${bal?.qty}`);

  // ---------- §7: فاتورة دينار لمنتج مسعّر بالدولار ----------
  console.log("\n■ §7 IQD invoice for USD-priced product + exchange rate");
  inv = await post("/sales/invoices", auth, {
    customer_id: custId, warehouse_id: wh.id, type: "CASH", currency_code: "IQD",
    lines: [{ product_id: prodId, package_qty: 1, loose_qty: 0 }],
  });
  const c1 = inv.body.data;
  ok("C1 فاتورة IQD: كرتون واحد = 40,300 د.ع (26×1550 من سعر الشركة)", inv.ok && Number(c1?.grand_total) === 40300,
    `grand=${c1?.grand_total}`);

  // ---------- §8: اللقطة التاريخية + تغيير السعر ----------
  console.log("\n■ §8 Invoice snapshot immutable after price change");
  const oldInv = await get(`/sales/invoices/${m1.id}`, auth);
  const oldLine = oldInv.body.data?.lines?.[0];
  const oldTotal = Number(oldInv.body.data?.grand_total);
  const oldUnit = Number(oldLine?.unit_price ?? oldLine?.unitPrice ?? 0);

  // تغيير سعر الكرتونة إلى 30 USD
  const chg = await patch(`/products/${prodId}`, auth, {
    pack_sale_price: 30, pack_sale_currency: "USD", exchange_rate: 1550,
  });
  ok("H1 PATCH سعر الكرتونة 26→30 USD", chg.ok, JSON.stringify(chg.body).slice(0, 120));

  const oldInv2 = await get(`/sales/invoices/${m1.id}`, auth);
  const oldLine2 = oldInv2.body.data?.lines?.[0];
  ok("H2 الفاتورة القديمة لم تتغير (الإجمالي + سعر البند)",
    Number(oldInv2.body.data?.grand_total) === oldTotal
    && approx(Number(oldLine2?.unit_price ?? oldLine2?.unitPrice ?? 0), oldUnit, 1e-6),
    `before=${oldTotal} after=${oldInv2.body.data?.grand_total}`);

  inv = await post("/sales/invoices", auth, {
    customer_id: custId, warehouse_id: wh.id, type: "CASH",
    currency_code: "USD", exchange_rate: 1550,
    lines: [{ product_id: prodId, package_qty: 1, loose_qty: 0 }],
  });
  ok("H3 فاتورة جديدة بالسعر الجديد: $30 (46,500 د.ع)", inv.ok && Number(inv.body.data?.grand_total) === 46500,
    `grand=${inv.body.data?.grand_total}`);

  // صفوف الأسعار: القديم مغلق effectiveTo + جديد ساري (تاريخ أسعار §4)
  const priceHistory = await db.productPrice.findMany({
    where: { productId: prodId, priceType: "SALE", unit: "PACKAGE" },
    orderBy: { id: "asc" },
  });
  ok("H4 تاريخ الأسعار: صف مغلق (effectiveTo) + صف ساري",
    priceHistory.length === 2 && priceHistory[0].isActive === false && priceHistory[0].effectiveTo != null
    && priceHistory[1].isActive === true && Number(priceHistory[1].amount) === 30,
    JSON.stringify(priceHistory.map((h) => ({ a: h.amount, c: h.currency, on: h.isActive }))));

  // ---------- DoD نهائي ----------
  console.log("\n■ Definition of Done");
  const audit = await get("/products?per_page=100", auth);
  const allProducts = audit.body.data ?? [];
  const norm = (s) => String(s ?? "").trim().replace(/[أإآ]/g, "ا").replace(/ة/g, "ه");
  const badUnits = allProducts.filter((p) => p.pack_unit && norm(p.unit) === norm(p.pack_unit));
  ok("D1 لا unit==packUnit في الكتالوج", badUnits.length === 0, JSON.stringify(badUnits.map((p) => p.name)));

  const dbProducts = await db.product.findMany({ where: { deletedAt: null, companyId: 3 }, select: { id: true } });
  const dbPrices = await db.productPrice.findMany({ where: { isActive: true, productId: { in: dbProducts.map((p) => p.id) } } });
  const covered = new Set(dbPrices.map((r) => r.productId));
  const uncovered = dbProducts.filter((p) => !covered.has(p.id));
  ok("D2 لا تسعير بلا عملة — كل المنتجات بصفوف ProductPrice", uncovered.length === 0,
    `uncovered: ${uncovered.map((p) => p.id).join(",")}`);

  const usdBad = dbPrices.filter((r) => r.currency !== "IQD" && r.currency !== "USD");
  ok("D3 كل الأسعار بعملة معروفة (IQD|USD)", usdBad.length === 0, "");

  ok("D4 كل فحوص §9/§10/§7/§8 أعلاه ناجحة", FAIL === 0, `${FAIL} فشل`);

  console.log("=".repeat(70));
  console.log(`RESULT: PASS=${PASS} FAIL=${FAIL}`);
  if (failures.length) {
    console.log("الفشل:");
    for (const f of failures) console.log(`  ✗ ${f.name}: ${f.detail}`);
  }
  console.log("=".repeat(70));
}

main().catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
