/**
 * fix-lumiere-piece-prices.ts — إصلاح جذري لأسعار الحبة في شركة لوميره
 *
 * المشكلة: سعر البيع (للحبة المفردة) مُدخل = سعر الكارتون لكل المنتجات
 *   (شامبو: الحبة $26 بدل $2.36!) — يفسد بيع الحبات المفردة ويضاعف الإجماليات.
 * الإصلاح: sale_price = pack_sale_price ÷ pack_qty (دقة 6 خانات)
 *   + تصحيح وحدة سبلاش (كارتون ← علبة).
 * شغّله على السيرفر:  npx tsx scripts/fix-lumiere-piece-prices.ts
 */
const BASE = process.env.SDS_BASE ?? "http://localhost:3000";
const RATE = 1550;

interface LoginResp { success: boolean; data?: { access_token?: string }; message?: string }
interface ProductRow { id: number; code: string; name: string; unit: string; pack_unit: string | null; pack_qty: number | null; pack_sale_price: number | null; sale_price: number }

async function main() {
  const login = (await (await fetch(`${BASE}/api/v1/auth/login`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: "admin", password: "Admin@123" }),
  })).json()) as LoginResp;
  const t1 = login.data?.access_token;
  if (!t1) throw new Error(login.message ?? "LOGIN_FAILED");
  const sw = (await (await fetch(`${BASE}/api/v1/auth/switch-company`, {
    method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${t1}` },
    body: JSON.stringify({ company_id: 2 }),
  })).json()) as LoginResp;
  const token = sw.data?.access_token;
  if (!token) throw new Error("SWITCH_FAILED");
  const H = { "Content-Type": "application/json", Authorization: `Bearer ${token}` };

  const res = (await (await fetch(`${BASE}/api/v1/products?per_page=100`, { headers: H })).json()) as { success: boolean; data?: ProductRow[] };
  const products = res.data ?? [];
  console.log(`منتجات لوميره: ${products.length}\n`);

  let fixed = 0;
  for (const p of products) {
    const patches: Record<string, unknown> = {};
    if (p.unit.trim() === "كارتون" || p.unit.trim() === "كرتون") patches.unit = "علبة";

    if (p.pack_qty && p.pack_qty > 1 && p.pack_sale_price && p.pack_sale_price > 0) {
      const desired = Math.round((p.pack_sale_price / p.pack_qty) * 1e6) / 1e6;
      if (Math.abs(p.sale_price - desired) > 0.01) patches.sale_price = desired;
    }

    if (!Object.keys(patches).length) {
      console.log(`✓ ${p.code} ${p.name} — سليم (حبة=$${(p.sale_price / RATE).toFixed(3)})`);
      continue;
    }

    const r = (await (await fetch(`${BASE}/api/v1/products/${p.id}`, {
      method: "PATCH", headers: H, body: JSON.stringify(patches),
    })).json()) as { success: boolean; message?: string };
    if (!r.success) { console.log(`✗ ${p.code}: ${r.message}`); continue; }
    fixed++;
    if (patches.sale_price != null) {
      console.log(`✓ ${p.code} ${p.name}: سعر الحبة ${(p.sale_price / RATE).toFixed(2)}$ ← $${((patches.sale_price as number) / RATE).toFixed(4)} (= الكارتون $${(p.pack_sale_price! / RATE).toFixed(2)} ÷ ${p.pack_qty})`);
    }
    if (patches.unit) console.log(`  ↳ الوحدة: ${p.unit} ← علبة`);
  }
  console.log(`\nصُحّح ${fixed} منتجاً`);
}

main().catch((e) => { console.error("FIX_PRICES_ERROR:", e instanceof Error ? e.message : e); process.exit(1); });
