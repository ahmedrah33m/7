// =====================================================================
// PHASE 1 §9 — Endpoint Audit generator
// يفحص كل route.ts ويستخرج: المسار، الأساليب، الصلاحيات المطلوبة
// (guard/requirePermission)، ثم يصنّف نطاق الشركة/الفرع/المستودع
// وفق مكتبة scope المستخدمة داخل الملف.
// الناتج: docs/PHASE1_ENDPOINT_AUDIT.md
// =====================================================================
import { readdirSync, readFileSync, statSync, writeFileSync, mkdirSync } from "fs";
import { join, relative } from "path";

const ROOT = "/home/z/my-project";
const API_DIR = join(ROOT, "src/app/api");
const files = [];

function walk(dir) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    const st = statSync(p);
    if (st.isDirectory()) walk(p);
    else if (name === "route.ts") files.push(p);
  }
}
walk(API_DIR);

function relRoute(file) {
  // src/app/api/v1/products/[id]/route.ts → /api/v1/products/[id]
  const rel = relative(join(ROOT, "src/app/api"), file).replace(/\\/g, "/");
  return "/" + rel.replace(/\/route\.ts$/, "");
}

const rows = [];
for (const file of files) {
  const src = readFileSync(file, "utf8");
  const path = relRoute(file);

  const methods = [];
  for (const m of ["GET", "POST", "PATCH", "PUT", "DELETE"]) {
    if (new RegExp(`export const ${m}\\s*=`).test(src)) methods.push(m);
  }

  // الصلاحيات: guard(req, "x.y") أو requirePermission(session, "x.y")
  const perms = new Set();
  for (const m of src.matchAll(/guard\(\s*req(?:,\s*[\w$]+)?,\s*"([^"]+)"/g)) perms.add(m[1]);
  for (const m of src.matchAll(/guard\(\s*req,\s*"([^"]+)"/g)) perms.add(m[1]);
  for (const m of src.matchAll(/requirePermission\(\s*session,\s*"([^"]+)"/g)) perms.add(m[1]);
  // guard(req) بلا صلاحية = مصادقة فقط
  const authOnly = /guard\(\s*req\s*\)/.test(src) && perms.size === 0;
  const b2b = /verifyB2BToken/.test(src);
  const public_ = !/guard\(|verifyAccessToken|verifyB2BToken/.test(src);

  // نطاقات مستخدمة داخل الملف
  const uses = (re) => re.test(src);
  const companyScope = uses(/session\.companyId|companyId:\s*session\.company|branchWhere\(session\)|scope\.companyId/);
  const clientCompanyId = uses(/body\.company_id|company_id:\s*z\./) && !/admin\/companies/.test(path);
  const branchScope = uses(/branchWhere\(|effectiveBranchIds|assertBranchInScope|activeBranchId|session\.branchIds|resolveCreateBranch/);
  const whScope = uses(/assertWarehouseInScope|session\.warehouseIds|warehouseWhere\(|requireWarehouseAccess/);
  const cross = uses(/entityExistsOutsideCompany|SCOPE_006/);

  rows.push({
    path, methods,
    perm: perms.size ? [...perms].join(", ") : (public_ ? "— عام (بدون توكن)" : b2b ? "B2B token" : authOnly ? "مصادقة فقط" : "داخلي"),
    company: companyScope ? "session.companyId" : (clientCompanyId ? "⚠️ يقرأ company_id من العميل" : "غير مخصص"),
    branch: branchScope ? "نطاق الفروع + activeBranch" : "—",
    wh: whScope ? "نطاق المستودعات" : "—",
    cross: cross ? "SCOPE_006 صريح" : companyScope ? "404 ضمن الشركة" : "—",
  });
}

rows.sort((a, b) => a.path.localeCompare(b.path));

let md = `# PHASE 1 §9 — تدقيق نقاط النهاية (Endpoint Audit)

> مولّد آلياً من الكود (scripts/gen-endpoint-audit.mjs) بتاريخ ${new Date().toISOString().slice(0, 10)} —
> كل مسارات \`src/app/api/**/route.ts\` مع الصلاحية المطلوبة ونطاقات العزل.
>
> **القواعد الثابتة في كل النظام:**
> - \`companyId\` يأتي من الجلسة (JWT) **دائماً** — العميل لا يستطيع تجاوزه (§4).
> - الفرع النشط (\`brn\` في JWT) يضيّق القراءة والكتابة إلى فرعه (§5).
> - المستودعات تُتحقق: \`warehouse.companyId === session.companyId\` + ضمن نطاق الجلسة (§6).
> - المرجع العابر للشركات يُرفض بـ \`SCOPE_006\` أو 404 (منع تسريب الوجود) (§7).
> - مالك المنصة (GLOBAL) يرى كل شركات نطاقه في مسارات الإدارة **عمداً** (إدارة المنصة) —
>   مستخدمو نطاق COMPANY/BRANCH/WAREHOUSE معزولون تماماً (مثبت بـ phase1-security-verify.mjs).

| Endpoint | Methods | Required Permission | Company Scope | Branch Scope | Warehouse Scope | Cross-company |
|---|---|---|---|---|---|---|
`;

for (const r of rows) {
  md += `| \`${r.path}\` | ${r.methods.join(" ") || "—"} | ${r.perm} | ${r.company} | ${r.branch} | ${r.wh} | ${r.cross} |\n`;
}

mkdirSync(join(ROOT, "docs"), { recursive: true });
writeFileSync(join(ROOT, "docs/PHASE1_ENDPOINT_AUDIT.md"), md, "utf8");
console.log(`✔ docs/PHASE1_ENDPOINT_AUDIT.md — ${rows.length} مسار`);
