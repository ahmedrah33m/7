// =====================================================================
// verify-five-features.mjs — تحقق تكاملي للتعديلات الخمسة على قاعدة حية
// 1) شعار النظام (رفع/نقطة عامة/إزالة)
// 2+3) القائمة الجانبية (فحص واجهة في سكربت منفصل)
// 4) حذف شركة (على شركة اختبار مؤقتة)
// 5) قائمة قديمة بنفس رقمها (على الشركة المؤقتة — صفر أثر على البيانات الحية)
// =====================================================================
import { chromium } from "playwright";
import { writeFileSync } from "fs";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const results = [];
function check(name, ok, extra = "") {
  results.push(`${ok ? "✓" : "✗"} ${name}${extra ? " — " + extra : ""}`);
  if (!ok) process.exitCode = 1;
}

async function jfetch(path, { method = "GET", token, body, form } = {}) {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body) headers["Content-Type"] = "application/json";
  const res = await fetch(BASE + path, { method, headers, body: form ?? (body ? JSON.stringify(body) : undefined) });
  let json = null;
  try { json = await res.json(); } catch {}
  return { res, json };
}

// ---------- 0) دخول المالك ----------
const login = await jfetch("/api/v1/auth/login", { method: "POST", body: { username: "admin", password: "Admin@123" } });
const token = login.json?.data?.access_token;
check("دخول admin ناجح", !!token, login.json?.message ?? "");

if (token) {
  // ---------- 1) صلاحية system.company.delete بعد مزامنة الإقلاع ----------
  const perms = login.json.data.permissions ?? [];
  check("صلاحية system.company.delete ممنوحة للمالك (مزامنة الإقلاع)", perms.includes("system.company.delete"));

  // ---------- 2) شعار النظام ----------
  // PNG صغير 64x64 (أحمر) — بايتات صالحة لفحص magic bytes
  const pngB64 = "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAKklEQVR4nO3NMQEAIAzAsIF/z0OGBx4SaqGpqalpaWpqalqamlqampqWpqampqalqal5b7wDkXkD4wAAAABJRU5ErkJggg==";
  const png = Buffer.from(pngB64, "base64");
  const fd = new FormData();
  fd.append("file", new Blob([png], { type: "image/png" }), "logo-test.png");
  const up = await jfetch("/api/v1/admin/company-logo", { method: "POST", token, form: fd });
  check("رفع الشعار → 200", up.res.status === 200 && up.json?.success, up.json?.message ?? "");
  const logoFile = up.json?.data?.file?.name;

  const br = await jfetch("/api/v1/branding");
  check("نقطة /branding العامة تعيد الشعار", br.json?.data?.logo_url != null, JSON.stringify(br.json?.data));
  const logoRes = await fetch(BASE + "/api/v1/branding/logo");
  const ctype = logoRes.headers.get("content-type");
  check("/branding/logo يقدم صورة بلا مصادقة", logoRes.status === 200 && ctype?.startsWith("image/"), `ct=${ctype}`);
  check("بايتات الشعار مطابقة", Buffer.compare(Buffer.from(await logoRes.arrayBuffer()), png) === 0);

  // الشعار داخل حمولة الجلسة (scope.companies[].logo_url)
  const me = await jfetch("/api/v1/auth/me", { token });
  const meCompany = me.json?.data?.company;
  check("‏/me يعيد logoUrl للشركة النشطة", !!meCompany?.logoUrl, meCompany?.logoUrl ?? "null");
  check("scope.companies تحمل logo_url", !!(me.json?.data?.scope?.companies ?? []).find((c) => c.id === meCompany?.id)?.logo_url);

  const rm = await jfetch("/api/v1/admin/company-logo", { method: "DELETE", token });
  check("إزالة الشعار → الرجوع للافتراضي", rm.res.status === 200 && rm.json?.data?.logo_url === null);
  const br2 = await jfetch("/api/v1/branding");
  check("/branding يرجع null بعد الإزالة", br2.json?.data?.logo_url === null);
  void logoFile;

  // ---------- 3) شركة اختبار مؤقتة: إنشاء → حذف ----------
  const suffix = String(Date.now()).slice(-6);
  const code = `CO-T${suffix}`;
  const create = await jfetch("/api/v1/admin/companies", { method: "POST", token, body: { code, name: `شركة اختبار مؤقتة ${suffix}` } });
  const companyId = create.json?.data?.companyId;
  check(`إنشاء شركة اختبار ${code}`, create.res.status === 201 && !!companyId, create.json?.message ?? "");

  // مطلوبات الفاتورة داخل الشركة المؤقتة
  const sw = await jfetch("/api/v1/auth/switch-company", { method: "POST", token, body: { company_id: companyId } });
  check("تبديل الجلسة إلى الشركة المؤقتة", sw.res.status === 200 && sw.json?.success, sw.json?.message ?? "");
  const t2 = sw.json?.data?.access_token ?? token;

  const prod = await jfetch("/api/v1/products", { method: "POST", token: t2, body: { code: `P-T${suffix}`, name: "منتج اختبار تكاملي", unit: "قطعة", sale_price: 1000, cost_price: 500 } });
  let productId = prod.json?.data?.id;
  if (!productId) {
    // بنية حقل المنتج قد تختلف — اجلب قائمة حقول من الخطأ
    check("إنشاء منتج في الشركة المؤقتة (فحص الحقول)", false, JSON.stringify(prod.json).slice(0, 200));
    productId = null;
  }
  if (productId) {
    const whs = (sw.json?.data?.scope?.warehouses ?? []);
    const whId = whs[0]?.id;
    const move = await jfetch("/api/v1/inventory/movements", { method: "POST", token: t2, body: { warehouse_id: whId, product_id: productId, direction: "IN", qty: 50, unit_cost: 500, note: "تهيئة اختبار" } });
    check("إدخال مخزون 50 للمنتج الاختباري", move.res.status === 200 || move.res.status === 201, JSON.stringify(move.json?.message ?? "").slice(0, 120));

    const walk = await jfetch("/api/v1/customers/default-walkin", { token: t2 });
    const customerId = walk.json?.data?.id;
    check("الزبون النقدي الافتراضي جاهز", !!customerId, walk.json?.message ?? "");

    // ---------- 4) قائمة قديمة بنفس رقمها ----------
    const inv = await jfetch("/api/v1/sales/invoices", { method: "POST", token: t2, body: {
      customer_id: customerId, warehouse_id: whId, type: "CASH",
      custom_number: "INV-2026-999001",
      lines: [{ product_id: productId, qty: 2, unit_price: 1000 }],
    }});
    check("ترحيل قائمة برقم مخصص INV-2026-999001", inv.res.status === 201 && inv.json?.data?.number === "INV-2026-999001", `got=${inv.json?.data?.number} ${inv.json?.message ?? ""}`);

    const dup = await jfetch("/api/v1/sales/invoices", { method: "POST", token: t2, body: {
      customer_id: customerId, warehouse_id: whId, type: "CASH",
      custom_number: "INV-2026-999001",
      lines: [{ product_id: productId, qty: 1, unit_price: 1000 }],
    }});
    check("رفض تكرار نفس الرقم (VAL_002)", dup.res.status >= 400 && dup.res.status < 500 && dup.json?.code === "VAL_002", `code=${dup.json?.code} status=${dup.res.status}`);

    const auto = await jfetch("/api/v1/sales/invoices", { method: "POST", token: t2, body: {
      customer_id: customerId, warehouse_id: whId, type: "CASH",
      lines: [{ product_id: productId, qty: 1, unit_price: 1000 }],
    }});
    check("الترقيم التلقائي تقدم بعد الرقم المخصص (999002)", auto.json?.data?.number === "INV-2026-999002", `got=${auto.json?.data?.number}`);

    // ---------- 5) حذف الشركة المؤقتة ----------
    // مستخدم محلي داخل الشركة المؤقتة — دخوله يجب أن يُمنع بعد الحذف
    const uname = `t${suffix}`;
    const mkUser = await jfetch("/api/v1/admin/users", { method: "POST", token: t2, body: {
      username: uname, password: "Local@12345", full_name: "مستخدم الشركة المؤقتة",
      role_code: "CASHIER", company_id: companyId, scope_type: "COMPANY",
      branch_ids: [], warehouse_ids: [],
    }});
    check("إنشاء مستخدم محلي في الشركة المؤقتة", mkUser.res.status === 200 || mkUser.res.status === 201, JSON.stringify(mkUser.json?.message ?? mkUser.json?.errors ?? "").slice(0, 140));

    // أعد التوكن الأصلي (مالك GLOBAL في الشركة الرئيسية) للحذف من خارجها
    const del = await jfetch(`/api/v1/admin/companies/${companyId}`, { method: "DELETE", token });
    check("حذف الشركة المؤقتة → 200 + إنهاء الجلسات", del.res.status === 200 && del.json?.success, JSON.stringify(del.json?.message ?? del.json?.data?.sessions_revoked ?? ""));

    // جلسة GLOBAL كانت على الشركة المحذوفة → تسقط للشركة الأم (وليس بياناتها)
    const after = await jfetch("/api/v1/auth/me", { token: t2 });
    const afterCompany = after.json?.data?.company?.id;
    check("جلسة المالك على الشركة المحذوفة سقطت للشركة الأم (لا 401 ولا تسريب)",
      after.res.status === 200 ? afterCompany !== companyId : [401, 403].includes(after.res.status),
      `status=${after.res.status} company=${afterCompany}`);

    // دخول مستخدم الشركة المحذوفة مرفوض (رفض موحد AUTH_003)
    const localLogin = await jfetch("/api/v1/auth/login", { method: "POST", body: { username: uname, password: "Local@12345" } });
    check("مستخدم الشركة المحذوفة ممنوع من الدخول", localLogin.res.status >= 400 && localLogin.res.status < 500, `status=${localLogin.res.status} code=${localLogin.json?.code}`);

    const list = await jfetch("/api/v1/admin/companies", { token });
    const stillThere = (list.json?.data ?? []).some((c) => c.id === companyId);
    check("الشركة المحذوفة اختفت من قائمة الشركات", !stillThere);

    // إعادة الدخول → النطاق خالٍ من الشركة المحذوفة
    const relogin = await jfetch("/api/v1/auth/login", { method: "POST", body: { username: "admin", password: "Admin@123" } });
    const scopeCompanies = relogin.json?.data?.scope?.companies ?? [];
    check("النطاق بعد إعادة الدخول خالٍ من الشركة المحذوفة", !scopeCompanies.some((c) => c.id === companyId));
    check("صلاحية الحذف ظاهرة في الجلسة الجديدة", (relogin.json?.data?.permissions ?? []).includes("system.company.delete"));
  }
}

// ---------- 6) لقطة شاشة الدخول (الشعار أُزيل → أيقونة افتراضية) ----------
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1366, height: 850 } });
const consoleErrors = [];
page.on("console", (m) => { if (m.type() === "error") consoleErrors.push(m.text().slice(0, 120)); });
page.on("pageerror", (e) => consoleErrors.push(String(e).slice(0, 120)));
await page.goto(BASE, { waitUntil: "networkidle", timeout: 30000 });
await page.getByLabel("اسم المستخدم").waitFor({ timeout: 20000 });
check("شاشة الدخول تُعرض بلا أخطاء console", consoleErrors.length === 0, consoleErrors.join(" | "));
await browser.close();

console.log("\n===== نتائج التحقق التكاملي =====");
console.log(results.join("\n"));
const fails = results.filter((r) => r.startsWith("✗")).length;
console.log(`\nالمجموع: ${results.length} — ناجح: ${results.length - fails} — فاشل: ${fails}`);
