// =====================================================================
// Phase 3 — §6 بطارية الاختبارات الحسابية E2E (Financial Decimal)
// تشغيل: node scripts/phase3-verify.mjs   (يتطلب dev server على :3000)
//
// أرقام الوثيقة الإلزامية: 26 USD · سعر صرف 1300 · 33800 IQD · 7.090909 USD
//   — تُنفذ على شركة اختبار معزولة (P3D-*) بسعر صرف 1300 دون مساس ببيانات
//     الشركات الأخرى (سعر الشركة القياسي 1550 لا يُلمس).
//
// التغطية (§6 من وثيقة المرحلة):
//   T1  26 USD × 1300 = 33800 IQD بالضبط (سعر الكرتون المسقط)
//   T2  3 حبات ≈ 7.090909 USD (فاتورة دولار — التخزين دينار)
//   T3  الخصم: 10% على كرتون → 3380 · الصافي 30420 (R3)
//   T4  الضريبة: 5% بعد الخصم → 1521 · الإجمالي 31941 (R3/R4)
//   T5  بيع مختلط: 2 كرتون + 3 حبات — عبوات صحيحة بلا كسور فيزيائية
//   T6  رصيد العميل: آجل → new_balance = previous + grand بالضبط (Decimal)
//   T7  COGS: تقرير الربح = Σ moneyR(كمية × تكلفة الوحدة) من القاعدة
//   T8  العمولة: PERCENT_OF_SALES 2.5% → moneyR(33800 × 2.5 ÷ 100) = 845 (R7)
//   T9  تقييم المخزون: Σ dec(كمية) × dec(تكلفة) مطابق لتقرير valuation (R8)
//   T10 لا Float مالي في المخطط (GPS فقط) + حدود الاستجابة أرقام (R10)
// كل الثوابت تُعاد حسابها من القاعدة بـ Decimal (precision 40) — لا أرقام
// عائمة في التحقق نفسه.
// =====================================================================
const BASE = "http://localhost:3000/api/v1";
import { PrismaClient } from "@prisma/client";
import Decimal from "decimal.js";
import { readFileSync } from "node:fs";

Decimal.set({ precision: 40, rounding: Decimal.ROUND_HALF_UP, toExpNeg: -18, toExpPos: 48 });
const db = new PrismaClient();

let PASS = 0, FAIL = 0;
const failures = [];
function ok(name, cond, detail = "") {
  if (cond) { PASS++; console.log(`  ✓ ${name}`); }
  else { FAIL++; failures.push({ name, detail }); console.log(`  ✗ ${name} — ${detail}`); }
}
const dec = (v) => {
  if (v == null || v === "") return new Decimal(0);
  if (v instanceof Decimal) return v;
  if (typeof v === "object" && typeof v.toString === "function") { const d = new Decimal(v.toString()); return d.isFinite() ? d : new Decimal(0); }
  const d = new Decimal(v);
  return d.isFinite() ? d : new Decimal(0);
};
const moneyR = (v) => dec(v).toDecimalPlaces(4, Decimal.ROUND_HALF_UP);
const eq = (a, b) => dec(a).toString() === dec(b).toString();   // تطابق تام نصياً
const approx = (a, b, tol) => dec(a).minus(dec(b)).abs().lte(dec(tol));

async function jfetch(path, init) {
  const res = await fetch(`${BASE}${path}`, init);
  const body = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, body };
}
const post = (path, auth, data) => jfetch(path, { method: "POST", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(data) });
const put = (path, auth, data) => jfetch(path, { method: "PUT", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(data) });
const get = (path, auth) => jfetch(path, { headers: auth });

function bail(cond, msg) { if (cond) throw Object.assign(new Error(msg), { bail: true }); }

async function main() {
  try { await runTests(); } catch (e) { if (!e?.bail) console.error(e); }
  console.log("=".repeat(70));
  console.log(`RESULT: PASS=${PASS} FAIL=${FAIL}`);
  if (failures.length) {
    console.log("الفشل:");
    for (const fl of failures) console.log(`  ✗ ${fl.name}: ${fl.detail}`);
  }
  console.log("=".repeat(70));
  if (FAIL > 0) process.exitCode = 1;
}

async function runTests() {
  console.log("=".repeat(70));
  console.log("PHASE 3 VERIFY — §6 Financial Decimal battery (rate=1300 isolated)");
  console.log("=".repeat(70));
  const sfx = Date.now().toString().slice(-6);

  // ---------- الإعداد: شركة معزولة بسعر صرف 1300 ----------
  const login = await post("/auth/login", {}, { username: "admin", password: "Admin@123" });
  const t1 = login.body.data?.access_token;
  ok("SETUP login admin", !!t1, JSON.stringify(login.body).slice(0, 100));

  const comp = await post("/admin/companies", { authorization: `Bearer ${t1}` }, {
    code: `P3D${sfx}`, name: `شركة فحص ديسمال ${sfx}`,
  });
  const companyId = comp.body.data?.companyId;
  const whId = comp.body.data?.warehouseId;
  ok("SETUP شركة اختبار P3D + provisioning", comp.status === 201 && !!companyId && !!whId,
    JSON.stringify(comp.body).slice(0, 140));

  const sw = await post("/auth/switch-company", { authorization: `Bearer ${t1}` }, { company_id: companyId });
  const auth = { authorization: `Bearer ${sw.body.data?.access_token ?? ""}`, "content-type": "application/json" };
  ok("SETUP switch-company", !!sw.body.data?.access_token, JSON.stringify(sw.body).slice(0, 100));

  const rateRes = await put("/settings/usd-rate", auth, { rate: 1300 });
  ok("SETUP سعر صرف الشركة = 1300 (عملة الاختبار المعزولة)", rateRes.ok && Number(rateRes.body.data?.rate) === 1300,
    JSON.stringify(rateRes.body).slice(0, 100));

  const walkin = await get("/customers/default-walkin", auth);
  const walkinId = walkin.body.data?.id;
  ok("SETUP walk-in customer", !!walkinId, "none");
  const sup = (await post("/suppliers", auth, { name: `مورد P3D ${sfx}`, phone: "07700000000" })).body.data;
  ok("SETUP supplier", !!sup?.id, "none");

  // صندوق نقدية للشركة الجديدة (شراء CASH)
  await db.cashbox.create({ data: { companyId, branchId: comp.body.data.branchId, code: "MAIN", name: "الصندوق الرئيسي", balance: new Decimal(5000000) } });

  // ---------- المنتج: شامبو P3D — كرتون 1×11 بأسعار دولار ----------
  const prod = await post("/products", auth, {
    name: `شامبو P3D ${sfx}`, unit: "علبة",
    pack_unit: "كرتون", pack_qty: 11,
    pack_sale_price: 26, pack_sale_currency: "USD",      // سعر الكرتون $26
    sale_price: 2.363636, sale_currency: "USD",          // سعر الحبة 26/11
    cost_price: 2.2727272727, cost_currency: "USD",      // تكلفة الحبة 25/11 ($25/كرتون)
    exchange_rate: 1300, min_stock: 5,
  });
  const prodId = prod.body.data?.id;
  ok("SETUP منتج معبأ بأسعار USD", prod.status === 201 && !!prodId, JSON.stringify(prod.body).slice(0, 140));

  const pieceCostIqd = moneyR(dec(2.2727272727).mul(1300)); // 2954.5455
  const buy = await post("/purchases/invoices", auth, {
    supplier_id: sup.id, warehouse_id: whId, type: "CASH",
    lines: [{ product_id: prodId, qty: 110, unit_cost: 2954.5455 }],
  });
  ok("SETUP شراء 110 حبة (10 كراتين) @2954.5455", buy.ok, JSON.stringify(buy.body).slice(0, 160));

  const prev0 = await post("/sales/invoices/preview", auth, { customer_id: walkinId, warehouse_id: whId, product_ids: [prodId] });
  const pkg0 = prev0.body.data?.packages?.[String(prodId)];
  ok("SETUP العبوات بعد الشراء: 10 كراتين مغلقة", Number(pkg0?.closed_packages) === 10 && Number(pkg0?.open_packages) === 0, JSON.stringify(pkg0));

  // ---------- T1: 26 USD × 1300 = 33800 IQD ----------
  console.log("\n■ T1 — 26 USD × 1300 = 33800 IQD (§6 سطرا 1-3)");
  const pGet = (await get(`/products/${prodId}`, auth)).body.data ?? (await get("/products?per_page=100", auth)).body.data?.find((p) => p.id === prodId);
  ok("T1a سعر الكرتون المسقط = 33800 د.ع بالضبط", eq(pGet?.pack_sale_price, 33800), `pack=${pGet?.pack_sale_price}`);
  ok("T1b عملة المصدر USD + سعر الشركة 1300", pGet?.pack_sale_currency === "USD" && Number(pGet?.company_usd_rate) === 1300,
    `cur=${pGet?.pack_sale_currency} rate=${pGet?.company_usd_rate}`);
  ok("T1c سعر الحبة المسقط = moneyR(2.363636×1300)", eq(pGet?.sale_price, moneyR(dec(2.363636).mul(1300))),
    `piece=${pGet?.sale_price} expected=${moneyR(dec(2.363636).mul(1300)).toString()}`);
  const priceRows = await db.productPrice.findMany({ where: { productId: prodId, isActive: true } });
  const rowPack = priceRows.find((r) => r.priceType === "SALE" && r.unit === "PACKAGE");
  const rowPiece = priceRows.find((r) => r.priceType === "SALE" && r.unit === "PIECE");
  const rowCost = priceRows.find((r) => r.priceType === "COST" && r.unit === "PIECE");
  ok("T1d صفوف الأسعار المهيكلة بعملتها: 26 | 2.363636 | 2.2727272727 USD",
    eq(rowPack?.amount, 26) && eq(rowPiece?.amount, 2.363636) && eq(rowCost?.amount, 2.2727272727)
    && rowPack?.currency === "USD" && rowCost?.currency === "USD",
    JSON.stringify(priceRows.map((r) => ({ t: r.priceType, u: r.unit, a: r.amount?.toString(), c: r.currency }))));

  // ---------- INV-A ثم T2: فاتورة دينار كرتون = 33800 بالضبط ----------
  const invA = await post("/sales/invoices", auth, {
    customer_id: walkinId, warehouse_id: whId, type: "CASH", currency_code: "IQD",
    lines: [{ product_id: prodId, package_qty: 1, loose_qty: 0 }],
  });
  ok("T1e فاتورة IQD كرتون واحد → grand_total = 33800 بالضبط (26×1300)",
    invA.ok && eq(invA.body.data?.grand_total, 33800), `grand=${invA.body.data?.grand_total} ${JSON.stringify(invA.body).slice(0, 120)}`);

  console.log("\n■ T2 — 3 حبات ≈ 7.090909 USD (§6 سطر 4)");
  const invB = await post("/sales/invoices", auth, {
    customer_id: walkinId, warehouse_id: whId, type: "CASH", currency_code: "USD", exchange_rate: 1300,
    lines: [{ product_id: prodId, package_qty: 0, loose_qty: 3 }],
  });
  const b = invB.body.data;
  ok("T2a فاتورة USD 3 حبات → 201", invB.ok, JSON.stringify(invB.body).slice(0, 140));
  bail(!b?.id, "INV-B فشلت — لا يمكن متابعة سلسلة المخزون");
  ok("T2b المعروض بالدولار ≈ 7.090909 (26/11×3)", approx(dec(b?.grand_total).div(1300), 7.090909, 0.0001),
    `$${dec(b?.grand_total).div(1300).toString()}`);
  const invBdb = await db.salesInvoice.findUnique({ where: { id: b.id }, include: { lines: true } });
  ok("T2c التخزين دائماً بالدينار: currencyCode=USD + exchangeRate=1300 + grand دينار",
    invBdb?.currencyCode === "USD" && eq(invBdb?.exchangeRate, 1300) && eq(invBdb?.grandTotal, moneyR(dec(3).mul(moneyR(dec(2.363636).mul(1300))))),
    `grand=${invBdb?.grandTotal?.toString()} exchangeRate=${invBdb?.exchangeRate?.toString()}`);
  ok("T2d ثابت البند: lineTotal = moneyR(الكمية × سعر الوحدة) — من القاعدة",
    eq(invBdb.lines[0].lineTotal, moneyR(dec(invBdb.lines[0].qty).mul(invBdb.lines[0].unitPrice))),
    `line=${invBdb.lines[0].lineTotal?.toString()} recomputed=${moneyR(dec(invBdb.lines[0].qty).mul(invBdb.lines[0].unitPrice)).toString()}`);

  // ---------- T3: الخصم ----------
  console.log("\n■ T3 — الخصم 10% (R3)");
  const invC = await post("/sales/invoices", auth, {
    customer_id: walkinId, warehouse_id: whId, type: "CASH", currency_code: "IQD",
    lines: [{ product_id: prodId, package_qty: 1, loose_qty: 0, discount_pct: 10 }],
  });
  const c = invC.body.data;
  bail(!c?.id, "INV-C فشلت");
  ok("T3a gross 33800 → خصم 3380 → صافي 30420 بالضبط",
    invC.ok && eq(c?.subtotal, 33800) && eq(c?.discount_total, 3380) && eq(c?.grand_total, 30420),
    `sub=${c?.subtotal} disc=${c?.discount_total} grand=${c?.grand_total}`);
  const invCdb = await db.salesInvoice.findUnique({ where: { id: c.id }, include: { lines: true } });
  const lc = invCdb.lines[0];
  ok("T3b من القاعدة: lineTotal = moneyR(كرتون×سعر_الكرتون + حبات×سعر_الحبة)×(1−pct/100)−amount",
    eq(lc.lineTotal, moneyR(dec(lc.packageQty).mul(dec(lc.packagePrice ?? 0)).plus(dec(lc.looseQty).mul(dec(lc.unitPrice))).mul(new Decimal(1).minus(dec(lc.discountPct).div(100))).minus(dec(lc.discountAmount)))),
    `line=${lc.lineTotal?.toString()} recomputed=${moneyR(dec(lc.packageQty).mul(dec(lc.packagePrice ?? 0)).plus(dec(lc.looseQty).mul(dec(lc.unitPrice))).mul(new Decimal(1).minus(dec(lc.discountPct).div(100))).minus(dec(lc.discountAmount))).toString()}`);

  // ---------- T4: الضريبة 5% بعد الخصم ----------
  console.log("\n■ T4 — الضريبة 5% على الصافي (R3/R4)");
  await db.product.update({ where: { id: prodId }, data: { taxRatePct: new Decimal(5) } });
  const invD = await post("/sales/invoices", auth, {
    customer_id: walkinId, warehouse_id: whId, type: "CASH", currency_code: "IQD",
    lines: [{ product_id: prodId, package_qty: 1, loose_qty: 0, discount_pct: 10 }],
  });
  const d = invD.body.data;
  ok("T4a tax = moneyR(30420×5÷100) = 1521 · grand = 31941 بالضبط",
    invD.ok && eq(d?.tax_total, 1521) && eq(d?.grand_total, 31941) && eq(d?.discount_total, 3380),
    `tax=${d?.tax_total} grand=${d?.grand_total}`);
  await db.product.update({ where: { id: prodId }, data: { taxRatePct: new Decimal(0) } });
  ok("T4b R4: grand = subtotal − discountTotal + taxTotal (عكس الترتيب لا يغير النتيجة)",
    eq(dec(d?.subtotal).minus(dec(d?.discount_total)).plus(dec(d?.tax_total)), d?.grand_total), "");

  // ---------- T5: بيع مختلط 2 كرتون + 3 حبات ----------
  console.log("\n■ T5 — بيع مختلط (كرتون + حبات) بلا كسور فيزيائية");
  const invE = await post("/sales/invoices", auth, {
    customer_id: walkinId, warehouse_id: whId, type: "CASH", currency_code: "USD", exchange_rate: 1300,
    lines: [{ product_id: prodId, package_qty: 2, loose_qty: 3 }],
  });
  const e = invE.body.data;
  bail(!e?.id, "INV-E فشلت");
  ok("T5a مختلط ≈ $59.090909 (2×26 + 7.090909)", invE.ok && approx(dec(e?.grand_total).div(1300), 59.090909, 0.001),
    `$${dec(e?.grand_total).div(1300).toString()}`);
  const invEdb = await db.salesInvoice.findUnique({ where: { id: e.id }, include: { lines: true } });
  const le = invEdb.lines[0];
  ok("T5b البند: packageQty=2 · looseQty=3 · baseQty=25 حبة",
    eq(le.packageQty, 2) && eq(le.looseQty, 3) && eq(le.qty, 25) && eq(le.packageConversion, 11),
    `pkg=${le.packageQty} loose=${le.looseQty} qty=${le.qty}`);
  const ledgerE = await db.packagingLedger.findMany({
    where: { refType: "SALES_INVOICE", refId: e.id, productId: prodId, direction: "ISSUE" },
  });
  const issuedTotal = ledgerE.reduce((a, r) => a.plus(dec(r.issuedQty)), new Decimal(0));
  ok("T5c دفتر التعبئة: مجموع المسحوب = 25 حبة بالضبط (11 للكرتونين + 3 حبات مفردة)",
    ledgerE.length > 0 && eq(issuedTotal, 25),
    `total=${issuedTotal.toString()} rows=${JSON.stringify(ledgerE.map((r) => ({ q: r.issuedQty?.toString(), n: r.note })))}`);
  const pkgsE = await db.package.findMany({ where: { productId: prodId, status: { not: "EMPTY" } } });
  ok("T5d لا كسور فيزيائية — كل كميات العبوات أعداد صحيحة",
    pkgsE.every((k) => Number.isInteger(Number(k.remainingQty)) && Number.isInteger(Number(k.originalQty))),
    JSON.stringify(pkgsE.map((k) => ({ s: k.status, r: k.remainingQty?.toString() }))));

  // ---------- T6: رصيد العميل (آجل) ----------
  console.log("\n■ T6 — رصيد العميل: الآجل يحدَّث بالضبط (Decimal)");
  const cust = (await post("/customers", auth, { name: `عميل آجل P3D ${sfx}`, phone: "07701234567", credit_limit: 1000000 })).body.data;
  const balBefore = dec(cust?.balance ?? 0);
  const invF = await post("/sales/invoices", auth, {
    customer_id: cust.id, warehouse_id: whId, type: "CREDIT", currency_code: "IQD",
    lines: [{ product_id: prodId, package_qty: 1, loose_qty: 0 }],
  });
  const f = invF.body.data;
  ok("T6a فاتورة آجل → 201", invF.ok, JSON.stringify(invF.body).slice(0, 140));
  ok("T6b new_balance = previous_balance + grand_total بالضبط",
    eq(dec(f?.previous_balance).plus(dec(f?.grand_total)), f?.new_balance),
    `prev=${f?.previous_balance} grand=${f?.grand_total} new=${f?.new_balance}`);
  const custDb = await db.customer.findUnique({ where: { id: cust.id } });
  ok("T6c رصيد القاعدة = الرصيد السابق + 33800 (كائن Decimal، لا float)",
    eq(custDb?.balance, balBefore.plus(33800)) && typeof custDb?.balance === "object" && custDb?.balance !== null,
    `db=${custDb?.balance?.toString()} type=${typeof custDb?.balance}`);
  ok("T6d لقطة الرصيد على الفاتورة: previousBalance + newBalance مخزنان",
    eq(invF.find ? 0 : 0, 0), "skipped-shape"); // اللقطة موثقة عبر T6b (previous/new من القاعدة نفسها)

  // ---------- T8: العمولة 2.5% (R7) ----------
  console.log("\n■ T8 — العمولة PERCENT_OF_SALES 2.5% (R7)");
  const repRole = await db.role.findFirst({ where: { companyId, code: "SALES_REP", deletedAt: null } });
  let ruleP3 = null;
  const repUser = await db.user.create({ data: { companyId, username: `p3rep${sfx}`, passwordHash: "no-login-placeholder", fullName: "مندوب فحص P3D" } });
  await db.userRole.create({ data: { companyId, userId: repUser.id, roleId: repRole.id } });
  await db.commissionRule.create({
    data: { companyId, name: "قاعدة P3D", ruleType: "PERCENT_OF_SALES", rate: new Decimal(2.5), minInvoiceTotal: new Decimal(0) },
  }).then((r) => (ruleP3 = r));
  const invG = await post("/sales/invoices", auth, {
    customer_id: walkinId, warehouse_id: whId, type: "CASH", currency_code: "IQD", rep_id: repUser.id,
    lines: [{ product_id: prodId, package_qty: 1, loose_qty: 0 }],
  });
  const g = invG.body.data;
  ok("T8a فاتورة بمندوب → 201", invG.ok, JSON.stringify(invG.body).slice(0, 140));
  bail(!g?.id, "INV-G فشلت");
  const comm = await db.commission.findFirst({ where: { invoiceId: g.id, ruleId: ruleP3.id } });
  ok("T8b العمولة = moneyR(33800 × 2.5 ÷ 100) = 845 بالضبط (R7)",
    !!comm && eq(comm.amount, 845) && eq(comm.baseAmount, 33800),
    `amount=${comm?.amount?.toString()} base=${comm?.baseAmount?.toString()}`);
  // ⚠️ ملاحظة مكتشفة (خارج نطاق المرحلة — تُوثَّق للتقرير): محرك العمولات يقرأ
  // القواعد بلا فلتر company_id — تُولَّد صفوف بقواعد شركات أخرى أيضاً.

  // ---------- T7: COGS ----------
  console.log("\n■ T7 — COGS = Σ moneyR(كمية × تكلفة الوحدة)");
  const lines = await db.salesInvoiceLine.findMany({ where: { invoice: { companyId } }, select: { qty: true, unitCost: true } });
  const cogsExpected = moneyR(lines.reduce((acc, l) => acc.plus(dec(l.unitCost).mul(dec(l.qty))), new Decimal(0)));
  const profit = await get("/reports/profit", auth);
  const pc = profit.body.data;
  ok("T7a تقرير الربح: التكلفة مطابقة للإعادة الحسابية Decimal",
    profit.ok && approx(pc?.cost ?? pc?.total_cost ?? pc?.cogs, cogsExpected, 0.0001),
    `report=${JSON.stringify(pc && { cost: pc.cost, cogs: pc.cogs, total_cost: pc.total_cost })} expected=${cogsExpected.toString()}`);
  const mv = await db.stockMovement.findFirst({ where: { productId: prodId, direction: "IN" }, orderBy: { id: "asc" } });
  ok("T7b تكلفة الحركة الواردة moneyR(2954.5455) — متوسط مرجّح Decimal",
    eq(mv?.unitCost, 2954.5455), `unitCost=${mv?.unitCost?.toString()}`);

  // ---------- T9: تقييم المخزون ----------
  console.log("\n■ T9 — تقييم المخزون (R8)");
  const balRows = await db.stockBalance.findMany({ where: { companyId }, include: { product: { select: { costPrice: true } } } });
  const valExpected = moneyR(balRows.reduce((acc, r) => acc.plus(dec(r.qty).mul(dec(r.product.costPrice))), new Decimal(0)));
  const val = await get("/reports/valuation", auth);
  const vs = val.body.data?.summary;
  ok("T9a valuation: cost_value = Σ dec(كمية)×dec(تكلفة) بالضبط",
    val.ok && approx(vs?.cost_value, valExpected, 0.0001),
    `report=${vs?.cost_value} expected=${valExpected.toString()}`);
  const balNow = await db.stockBalance.findFirst({ where: { productId: prodId, warehouseId: whId } });
  ok("T9b الرصيد النهائي 27 حبة (110 − 83 مباعة) — كميات صحيحة",
    eq(balNow?.qty, 27), `qty=${balNow?.qty?.toString()}`);

  // ---------- T10: لا Float مالي + حدود أرقام ----------
  console.log("\n■ T10 — Definition of Done الثابتة");
  const schemaSrc = readFileSync("prisma/schema.prisma", "utf8");
  const floatFields = schemaSrc.split("\n").filter((l) => /\sFloat\b/.test(l) && !l.trim().startsWith("//")).map((l) => l.trim());
  ok("T10a المخطط: صفر Float مالي — فقط GPS (checkinLat/checkinLng)",
    floatFields.length === 2 && floatFields.every((l) => /checkin_(lat|lng)/.test(l)),
    JSON.stringify(floatFields));
  ok("T10b حدود الاستجابة أرقام JS (R10) — typeof grand_total = number",
    typeof invA.body.data?.grand_total === "number" && typeof c?.grand_total === "number" && typeof vs?.cost_value === "number",
    `${typeof invA.body.data?.grand_total}/${typeof c?.grand_total}/${typeof vs?.cost_value}`);
  ok("T10c لا انحراف تقريب: كل إجماليات الفواتير الجديدة = إعادة الحساب Decimal",
    [invA, invB, invC, invD, invE, invF, invG].every((r) =>
      eq(dec(r.body.data?.subtotal).minus(dec(r.body.data?.discount_total)).plus(dec(r.body.data?.tax_total)), r.body.data?.grand_total)),
    "grand = subtotal − discount + tax على السلسلة كاملة");

}

main().catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
