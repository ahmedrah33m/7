// =====================================================================
// Phase 4–7 acceptance suite — finance · purchasing · returns ·
// transfers · reports. Uses the REAL HTTP API with real side effects
// and verifies DB state through Prisma. Exit code 0 = all pass.
// =====================================================================

import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000/api/v1";
const db = new PrismaClient();

let pass = 0;
let fail = 0;
const results: string[] = [];

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    results.push(`  ✅ ${name}`);
  } else {
    fail++;
    results.push(`  ❌ ${name} ${detail ? "— " + detail : ""}`);
  }
}

async function req(
  method: string,
  path: string,
  token?: string,
  body?: unknown
): Promise<{ status: number; body: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json };
}

async function main() {
  console.log("═══ Phase 4–7 verification ═══");

  // 0) login
  const admin = await req("POST", "/auth/login", undefined, { username: "admin", password: "Admin@123" });
  check("admin login", admin.status === 200 && admin.body.success);
  const T = admin.body.data?.access_token as string;
  const REF = admin.body.data?.refresh_token as string;

  const cashier = await req("POST", "/auth/login", undefined, { username: "cashier", password: "Cashier@123" });
  const CT = cashier.body.data?.access_token as string;
  check("cashier login", cashier.status === 200);

  // 1) cashboxes
  const boxes = await req("GET", "/finance/cashboxes", T);
  check("cashboxes list (finance.cashboxes.view)", boxes.status === 200 && boxes.body.data?.length > 0);
  const cbMain = boxes.body.data?.[0];

  // 2) cash ledger list
  const txs = await req("GET", "/finance/transactions?per_page=50", T);
  const cats = new Set((txs.body.data ?? []).map((t: any) => t.category));
  check("cash ledger lists OPENING+COLLECTION+EXPENSE", ["OPENING", "COLLECTION", "EXPENSE"].every((c) => cats.has(c)));

  // 3) collection with balance check
  const customers = await req("GET", "/customers?per_page=100", T);
  const debtor = (customers.body.data ?? []).find((c: any) => c.balance > 0);
  check("a customer with receivable exists", !!debtor, "needed for collection test");
  if (debtor) {
    const before = debtor.balance;
    const col = await req("POST", "/finance/transactions", T, {
      kind: "collection", customer_id: debtor.id, cashbox_id: cbMain.id, amount: 1000, note: "اختبار قبول",
    });
    check("collection posts (PAY-…)", col.status === 201 && String(col.body.data?.number ?? "").startsWith("PAY-"));
    const after = (await req("GET", `/customers?per_page=100`, T)).body.data.find((c: any) => c.id === debtor.id).balance;
    check("customer balance decremented by 1000", Math.abs(after - (before - 1000)) < 0.01, `${before}→${after}`);
    const boxAfter = (await req("GET", "/finance/cashboxes", T)).body.data.find((b: any) => b.id === cbMain.id).balance;
    check("cashbox balance incremented by 1000", Math.abs(boxAfter - (cbMain.balance + 1000)) < 0.01);
    // over-collect guard
    const over = await req("POST", "/finance/transactions", T, {
      kind: "collection", customer_id: debtor.id, cashbox_id: cbMain.id, amount: 999_999_999,
    });
    check("over-collect blocked (VAL_001)", over.status === 422 && over.body.code === "VAL_001");
  }

  // 4) supplier payment
  const suppliers = await req("GET", "/suppliers", T);
  const payable = (suppliers.body.data ?? []).find((s: any) => s.balance > 0);
  check("a supplier with payable exists", !!payable);
  if (payable) {
    const pay = await req("POST", "/finance/transactions", T, {
      kind: "supplier", supplier_id: payable.id, cashbox_id: cbMain.id, amount: 5000,
    });
    check("supplier payment posts", pay.status === 201);
    const after = (await req("GET", "/suppliers", T)).body.data.find((s: any) => s.id === payable.id).balance;
    check("supplier balance decremented by 5000", Math.abs(after - (payable.balance - 5000)) < 0.01);
  }

  // 5) expense
  const exp = await req("POST", "/finance/transactions", T, {
    kind: "expense", cashbox_id: cbMain.id, amount: 2500, title: "وقود سيارات — اختبار",
  });
  check("expense posts (EXP-…)", exp.status === 201 && String(exp.body.data?.number ?? "").startsWith("EXP-"));

  // 6) purchase invoice CASH → stock IN + cost update
  const products = (await req("GET", "/products?per_page=100", T)).body.data;
  const prod = products[products.length - 1];
  const whs = admin.body.data ? null : null; // warehouse scope from /me
  const me = await req("GET", "/auth/me", T);
  const warehouseId = me.body.data?.warehouses?.[0]?.id;
  const balBefore = await db.stockBalance.findUnique({
    where: { warehouseId_productId: { warehouseId, productId: prod.id } },
  });
  const costBefore = (await db.product.findUnique({ where: { id: prod.id } }))!.costPrice;
  const sup = (await req("GET", "/suppliers", T)).body.data[0];
  const pur = await req("POST", "/purchases/invoices", T, {
    supplier_id: sup.id, warehouse_id: warehouseId, type: "CASH",
    lines: [{ product_id: prod.id, qty: 5, unit_cost: costBefore + 100 }],
  });
  check("purchase invoice posts (PUR-…)", pur.status === 201 && String(pur.body.data?.number ?? "").startsWith("PUR-"));
  const balAfter = await db.stockBalance.findUnique({
    where: { warehouseId_productId: { warehouseId, productId: prod.id } },
  });
  check("stock increased by 5", (balAfter?.qty ?? 0) === (balBefore?.qty ?? 0) + 5, `${balBefore?.qty}→${balAfter?.qty}`);
  const costAfter = (await db.product.findUnique({ where: { id: prod.id } }))!.costPrice;
  check("WAVG cost updated", costAfter > costBefore, `${costBefore}→${costAfter}`);

  // 7) sales invoice → return (R1: qty ≤ remaining)
  const cust = (customers.body.data ?? [])[0];
  const sale = await req("POST", "/sales/invoices", T, {
    customer_id: cust.id, warehouse_id: warehouseId, type: "CASH",
    lines: [{ product_id: prod.id, qty: 2 }],
  });
  check("sales invoice posts for return test", sale.status === 201);
  const saleBal = await db.stockBalance.findUnique({
    where: { warehouseId_productId: { warehouseId, productId: prod.id } },
  });
  const invId = sale.body.data?.id;
  const invDetail = (await req("GET", `/sales/invoices/${invId}`, T)).body.data;
  const lineId = invDetail.lines[0].id;

  const ret = await req("POST", "/sales/returns", T, {
    invoice_id: invId, cashbox_id: cbMain.id, refund_cash: invDetail.lines[0].unit_price,
    lines: [{ invoice_line_id: lineId, qty: 1 }],
  });
  check("return posts (RET-…)", ret.status === 201 && String(ret.body.data?.number ?? "").startsWith("RET-"));
  const retBalAfter = await db.stockBalance.findUnique({
    where: { warehouseId_productId: { warehouseId, productId: prod.id } },
  });
  check("stock returned (+1)", retBalAfter?.qty === saleBal!.qty + 1, `${saleBal?.qty}→${retBalAfter?.qty}`);

  const retOver = await req("POST", "/sales/returns", T, {
    invoice_id: invId, lines: [{ invoice_line_id: lineId, qty: 999 }],
  });
  check("over-return blocked (VAL_001, R1)", retOver.status === 422 && retOver.body.code === "VAL_001");

  // 8) transfer → receive → double-receive blocked
  const meWh = me.body.data?.warehouses ?? [];
  if (meWh.length >= 2) {
    const from = meWh[0].id, to = meWh[1].id;
    const trf = await req("POST", "/inventory/transfers", T, {
      from_warehouse_id: from, to_warehouse_id: to,
      lines: [{ product_id: prod.id, qty: 2 }],
    });
    check("transfer dispatched (TRF-…, IN_TRANSIT)", trf.status === 201 && trf.body.data?.status === "IN_TRANSIT");
    const srcAfterDispatch = await db.stockBalance.findUnique({
      where: { warehouseId_productId: { warehouseId: from, productId: prod.id } },
    });
    const r1 = await req("POST", `/inventory/transfers/${trf.body.data.id}/receive`, T, {});
    check("receive posts (RECEIVED)", r1.status === 200 && r1.body.data?.status === "RECEIVED");
    const dstAfter = await db.stockBalance.findUnique({
      where: { warehouseId_productId: { warehouseId: to, productId: prod.id } },
    });
    check("destination stock +2", (dstAfter?.qty ?? 0) >= 2);
    const r2 = await req("POST", `/inventory/transfers/${trf.body.data.id}/receive`, T, {});
    check("double-receive blocked (VAL_004)", r2.status === 409 && r2.body.code === "VAL_004");
    check("source deducted exactly once", (srcAfterDispatch?.qty ?? 0) === retBalAfter!.qty - 2);
  } else {
    check("transfer test skipped (need 2 warehouses in scope)", false);
  }

  // 9) reports
  for (const r of ["sales-daily", "top-products", "aging", "valuation", "profit"]) {
    const rep = await req("GET", `/reports/${r}`, T);
    check(`report ${r}`, rep.status === 200 && rep.body.success);
  }

  // 10) RBAC — cashier
  const cashLedger = await req("GET", "/finance/transactions", CT);
  check("cashier blocked from ledger view (PERM_001)", cashLedger.status === 403 && cashLedger.body.code === "PERM_001");
  const cashPurchase = await req("POST", "/purchases/invoices", CT, {
    supplier_id: sup.id, warehouse_id: warehouseId, type: "CASH", lines: [{ product_id: prod.id, qty: 1 }],
  });
  check("cashier blocked from purchasing (PERM_001)", cashPurchase.status === 403 && cashPurchase.body.code === "PERM_001");
  const cashCol = await req("POST", "/finance/transactions", CT, {
    kind: "collection", customer_id: debtor ? debtor.id : cust.id, cashbox_id: cbMain.id, amount: 1,
  });
  check("cashier CAN collect at POS (201)", cashCol.status === 201, `got ${cashCol.status} ${cashCol.body?.code ?? ""}`);

  // 11) audit coverage
  const audit = await req("GET", "/admin/audit-logs?per_page=200", T);
  const entities = new Set((audit.body.data?.items ?? audit.body.data ?? []).map((a: any) => a.entity_type));
  check(
    "audit has purchase_invoice + sales_return + customer_collection",
    ["purchase_invoice", "sales_return", "customer_collection", "expense"].every((e) => entities.has(e)),
    [...entities].slice(0, 12).join(",")
  );

  // logout admin (invalidate refresh chain gracefully) — keep cashier session
  await req("POST", "/auth/logout", REF, {}).catch(() => {});
  await db.$disconnect();

  console.log(results.join("\n"));
  console.log(`\n═══ ${pass} passed · ${fail} failed ═══`);
  process.exit(fail === 0 ? 0 : 1);
}

main().catch((e) => {
  console.error("suite crashed:", e);
  process.exit(1);
});
