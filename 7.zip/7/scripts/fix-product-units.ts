/**
 * fix-product-units.ts — تصحيح «الوحدة» للمنتجات التي وُضعت بالخطأ = وحدة التعبئة
 *
 * المشكلة: منتجات أُنشئت بـ الوحدة = "كارتون" AND وحدة التعبئة = "كارتون"
 *   فيظهر: «1 كارتون = 11 كارتون» و«متاح 220 كارتون» والصحيح «متاح 220 علبة».
 * القاعدة: الوحدة = أصغر وحدة بيع (علبة/حبة) · وحدة التعبئة = الكارتون.
 *
 * الاستخدام على السيرفر:  npx tsx scripts/fix-product-units.ts
 * آمن للإعادة (idempotent): لا يلمس منتجاً صحّت وحدته.
 */
const BASE = process.env.SDS_BASE ?? "http://localhost:3000";
const PACK_LABELS = new Set(["كارتون", "كرتونة", "كرتون", "صندوق", "باكيت"]);

interface LoginResp { success: boolean; data?: { access_token?: string; scope?: { companies?: { id: number; name: string }[] } }; message?: string }
interface ProductRow { id: number; code: string; name: string; unit: string; pack_unit: string | null; pack_qty: number | null }

async function main() {
  const login = (await (await fetch(`${BASE}/api/v1/auth/login`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: "admin", password: "Admin@123" }),
  })).json()) as LoginResp;
  const t1 = login.data?.access_token;
  if (!t1) throw new Error(login.message ?? "LOGIN_FAILED");
  const companies = login.data?.scope?.companies ?? [];
  if (!companies.length) throw new Error("لا شركات في النطاق");
  console.log(`الشركات: ${companies.map((c) => c.name).join(" · ")}`);

  let fixed = 0, checked = 0;
  for (const c of companies) {
    const sw = (await (await fetch(`${BASE}/api/v1/auth/switch-company`, {
      method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${t1}` },
      body: JSON.stringify({ company_id: c.id }),
    })).json()) as LoginResp;
    const token = sw.data?.access_token;
    if (!token) { console.log(`⚠ تخطي ${c.name}: فشل التبديل`); continue; }
    const H = { "Content-Type": "application/json", Authorization: `Bearer ${token}` };

    let page = 1;
    for (;;) {
      const res = (await (await fetch(`${BASE}/api/v1/products?per_page=100&page=${page}`, { headers: H })).json()) as { success: boolean; data?: ProductRow[] };
      const rows = res.data ?? [];
      if (!rows.length) break;
      for (const p of rows) {
        checked++;
        if (p.pack_unit && p.unit.trim() === p.pack_unit.trim() && PACK_LABELS.has(p.unit.trim())) {
          const patch = (await (await fetch(`${BASE}/api/v1/products/${p.id}`, {
            method: "PATCH", headers: H, body: JSON.stringify({ unit: "علبة" }),
          })).json()) as { success: boolean; message?: string };
          if (patch.success) {
            fixed++;
            console.log(`✓ [${c.name}] ${p.code} ${p.name}: الوحدة «${p.unit}» ← «علبة» (التعبئة تبقى ${p.pack_unit} × ${p.pack_qty})`);
          } else {
            console.log(`✗ [${c.name}] ${p.code}: ${patch.message}`);
          }
        }
      }
      if (rows.length < 100) break;
      page++;
    }
  }
  console.log(`\nالنتيجة: فُحص ${checked} منتجاً · صُحّح ${fixed}`);
}

main().catch((e) => { console.error("FIX_UNITS_ERROR:", e instanceof Error ? e.message : e); process.exit(1); });
