// =====================================================================
// §66 Inventory Costing & Overview — acceptance suite (Task 26):
//   GET /inventory/valuation — بطاقات ومؤشرات الجرد والتكلفة الحية
//   A) الصلاحيات: من يرى ومن يُحجب (valuation.view)
//   B) الاتساق: كل مؤشر يعاد حسابه مستقلًا من القاعدة ويطابق
//   C) الإثبات الحي: إدخال وتسوية جرد تنعكس فورًا في البطاقات
//   D) COGS الحي: فاتورة بيع ترفع تكلفة البضاعة المباعة بلقطة الترحيل
//   E) نطاق الفرع: مدير البصرة يرى فرعه فقط + أين توجد المادة
// Exit 0 = all pass.
// =====================================================================

import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000/api/v1";
const db = new PrismaClient();

let pass = 0;
let fail = 0;
const createdUserIds: number[] = [];

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  ✅ ${name}`);
  } else {
    fail++;
    console.log(`  ❌ ${name} ${detail ? "— " + detail : ""}`);
  }
}

async function req(method: string, path: string, token?: string, body?: unknown): Promise<{ status: number; body: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json };
}

function errCode(r: { body: any }): string {
  return r.body?.error?.code ?? r.body?.code ?? "";
}

const r2 = (n: number) => Math.round(n * 100) / 100;

async function main() {
  console.log("═══ Inventory valuation & overview verification (Task 26 — §66) ═══");
  const rand = Date.now().toString().slice(-6);

  // تنظيف وقائي: بقايا تشغيلات سابقة فشلت قبل قسم التنظيف (حذف ناعم آمن FK)
  const stale = await db.user.findMany({
    where: { OR: [{ username: { startsWith: "wh.val." } }, { username: { startsWith: "acc.val." } }] },
    select: { id: true },
  });
  const staleIds = stale.map((u) => u.id);
  await db.userRole.deleteMany({ where: { userId: { in: staleIds } } });
  await db.userWarehouseAccess.deleteMany({ where: { userId: { in: staleIds } } });
  await db.user.updateMany({ where: { id: { in: staleIds } }, data: { deletedAt: new Date(), isActive: false } });
  const staleProducts = await db.product.findMany({ where: { name: { contains: "منتج تحقق التقييم" } }, select: { id: true } });
  if (staleProducts.length) await db.product.updateMany({ where: { id: { in: staleProducts.map((p) => p.id) } }, data: { deletedAt: new Date(), isActive: false } });

  // ─────────── 0) logins ───────────
  console.log("\n— الدخول —");
  const admin = await req("POST", "/auth/login", undefined, { username: "admin", password: "Admin@123" });
  check("admin login", admin.status < 300 && admin.body.success);
  const T = admin.body.data?.access_token as string;

  const cashier = await req("POST", "/auth/login", undefined, { username: "cashier", password: "Cashier@123" });
  const CT = cashier.body.data?.access_token as string;
  check("cashier login", cashier.status < 300);

  const rep = await req("POST", "/auth/login", undefined, { username: "rep.ahmed", password: "Rep@12345" });
  const RT = rep.body.data?.access_token as string;
  check("rep.ahmed login", rep.status < 300);

  const basra = await req("POST", "/auth/login", undefined, { username: "basra.manager", password: "Basra@123" });
  const BT = basra.body.data?.access_token as string;
  check("basra.manager login", basra.status < 300);

  // ─────────── A) permissions ───────────
  console.log("\n— A) الصلاحيات: من يرى مؤشرات التقييم —");
  const valAdmin = await req("GET", "/inventory/valuation", T);
  check("admin GET /inventory/valuation → 200", valAdmin.status === 200, JSON.stringify(valAdmin.body).slice(0, 120));
  const V = valAdmin.body.data;
  for (const key of ["totals", "health", "cogs", "by_location", "by_type", "rep_inventory", "adjustments", "top_value_items", "most_moving_items", "dead_items", "meta"]) {
    check(`response section "${key}" present`, V && V[key] !== undefined);
  }

  const valCashier = await req("GET", "/inventory/valuation", CT);
  check("cashier → 403 PERM_001 (لا يرى التكاليف)", valCashier.status === 403 && errCode(valCashier) === "PERM_001", `got ${valCashier.status} ${errCode(valCashier)}`);

  const valRep = await req("GET", "/inventory/valuation", RT);
  check("مندوب → 403 (قاعدة §66.32: لا تكاليف للمندوب)", valRep.status === 403 && errCode(valRep) === "PERM_001", `got ${valRep.status}`);

  const valBasra = await req("GET", "/inventory/valuation", BT);
  check("basra.manager → 200 (صلاحيةvaluation.view لمدير الفرع)", valBasra.status === 200, `got ${valBasra.status}`);

  // إنشاء أمين مستودع ومحاسب للتحقق من منحهما الجديد (Task 25 integration)
  const whUser = await req("POST", "/admin/users", T, {
    username: `wh.val.${rand}`, password: "WhVal@12345", full_name: "أمين مستودع التحقق",
    role_codes: ["WAREHOUSE_MANAGER"],
  });
  check("إنشاء أمين مستودع (يوزر خاص)", whUser.status < 300, JSON.stringify(whUser.body).slice(0, 140));
  const whLogin = await req("POST", "/auth/login", undefined, { username: `wh.val.${rand}`, password: "WhVal@12345" });
  check("دخول أمين المستودع بيوزره", whLogin.status < 300 && whLogin.body.success);
  const WT = whLogin.body.data?.access_token as string;
  if (whUser.body.data?.id) createdUserIds.push(whUser.body.data.id as number);
  const valWh = await req("GET", "/inventory/valuation", WT);
  check("أمين المستودع → 200 (منحة §66 الجديدة)", valWh.status === 200, `got ${valWh.status} ${JSON.stringify(whLogin.body).slice(0, 80)}`);

  const accUser = await req("POST", "/admin/users", T, {
    username: `acc.val.${rand}`, password: "AccVal@12345", full_name: "محاسب التحقق",
    role_codes: ["ACCOUNTANT"],
  });
  const accLogin = await req("POST", "/auth/login", undefined, { username: `acc.val.${rand}`, password: "AccVal@12345" });
  const AT = accLogin.body.data?.access_token as string;
  check("المحاسب الجديد يدخل ويرى التقييم", accLogin.status < 300 && (await req("GET", "/inventory/valuation", AT)).status === 200);
  if (accUser.body.data?.id) createdUserIds.push(accUser.body.data.id as number);

  // ─────────── B) consistency vs database ───────────
  console.log("\n— B) الاتساق: إعادة حساب مستقلة من القاعدة —");
  // نطاق admin = كل الفروع → كل المستودعات
  const allWh = await db.warehouse.findMany({ where: { companyId: 1, deletedAt: null } });
  const whIds = allWh.map((w) => w.id);
  const balances = await db.stockBalance.findMany({
    where: { companyId: 1, warehouseId: { in: whIds }, product: { deletedAt: null } },
    include: { product: { select: { id: true, code: true, name: true, unit: true, salePrice: true, costPrice: true, minStock: true } } },
  });
  // متوسط مرجح من الدفتر — إعادة حساب مستقلة
  const avgRows: any[] = await db.$queryRaw`SELECT product_id, SUM(qty) AS q, SUM(qty*unit_cost) AS v FROM stock_movements WHERE company_id=1 AND direction='IN' AND unit_cost IS NOT NULL GROUP BY product_id`;
  const avgMap = new Map<number, number>();
  for (const r of avgRows) { const q = Number(r.q), v = Number(r.v); if (q > 0) avgMap.set(Number(r.product_id), v / q); }
  const costOf = (pid: number, master: number) => { const m = avgMap.get(pid); return m != null && m > 0 ? m : master; };

  let expQty = 0, expCost = 0, expSales = 0;
  const perProduct = new Map<number, { qty: number; cost: number; min: number }>();
  for (const b of balances) {
    const c = costOf(b.productId, b.product.costPrice);
    expQty += b.qty; expCost += b.qty * c; expSales += b.qty * b.product.salePrice;
    const p = perProduct.get(b.productId) ?? { qty: 0, cost: 0, min: b.product.minStock };
    p.qty += b.qty; p.cost += b.qty * c;
    perProduct.set(b.productId, p);
  }
  check("إجمالي الكمية يطابق Σ الأرصدة", Math.abs(V.totals.total_qty - r2(expQty)) < 0.51, `${V.totals.total_qty} vs ${r2(expQty)}`);
  check("قيمة التكلفة تُحسب من المتوسط المرجح للدفتر", Math.abs(V.totals.cost_value - r2(expCost)) < 1, `${V.totals.cost_value} vs ${r2(expCost)}`);
  check("القيمة البيعية = Σ الكمية × سعر البيع", Math.abs(V.totals.sales_value - r2(expSales)) < 1, `${V.totals.sales_value} vs ${r2(expSales)}`);
  check("الربح المتوقع = بيعية − تكلفة", Math.abs(V.totals.potential_profit - r2(expSales - expCost)) < 1);
  const expItems = [...perProduct.values()].filter((p) => p.qty > 0).length;
  check("عدد المواد الموجودة (كمية>0) يطابق", V.totals.items_count === expItems, `${V.totals.items_count} vs ${expItems}`);

  const sumLoc = V.by_location.reduce((s: number, r: any) => s + r.cost_value, 0);
  check("توزيع المواقع يعيد إنتاج قيمة التكلفة", Math.abs(sumLoc - V.totals.cost_value) < 1, `${r2(sumLoc)} vs ${V.totals.cost_value}`);
  const sumType = V.by_type.reduce((s: number, r: any) => s + r.cost_value, 0);
  check("توزيع الأنواع يعيد إنتاج قيمة التكلفة (§66.28)", Math.abs(sumType - V.totals.cost_value) < 1);
  const sumPct = V.by_type.reduce((s: number, r: any) => s + r.pct, 0);
  check("نسب الأنواع تجمع ~100%", Math.abs(sumPct - 100) < 0.6, `${sumPct}`);

  const repCost = V.by_location.filter((r: any) => r.type === "REP").reduce((s: number, r: any) => s + r.cost_value, 0);
  check("قيمة مخزون المندوبين = Σ مستودعات REP (§66.27)", Math.abs(V.rep_inventory.total_value - r2(repCost)) < 1);

  let expLow = 0;
  for (const [, p] of perProduct) if (p.min > 0 && p.qty > 0 && p.qty <= p.min) expLow++;
  check("منخفض المخزون يطابق الحساب المستقل", V.health.low_stock === expLow, `${V.health.low_stock} vs ${expLow}`);

  // COGS الصافي من سطور الفواتير المرحّلة هذا الشهر مطروحًا منه تكلفة المرتجعات (§66.10)
  const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  const invLines = await db.salesInvoiceLine.findMany({
    where: { invoice: { companyId: 1, deletedAt: null, status: "POSTED", invoiceDate: { gte: monthStart } } },
    select: { qty: true, lineTotal: true, unitCost: true },
  });
  const retLinesDb = await db.salesReturnLine.findMany({
    where: { returnDoc: { companyId: 1, deletedAt: null, returnDate: { gte: monthStart } } },
    select: { qty: true, invoiceLine: { select: { unitCost: true } } },
  });
  const expCogs = r2(invLines.reduce((s, l) => s + l.qty * l.unitCost, 0) - retLinesDb.reduce((s, l) => s + l.qty * (l.invoiceLine?.unitCost ?? 0), 0));
  check("COGS الشهر (صافي المرتجعات) = لقطات التكلفة عند الترحيل (§66.10)", Math.abs(V.cogs.cogs - expCogs) < 1, `${V.cogs.cogs} vs ${expCogs}`);
  check("الهوية المحاسبية: ربح إجمالي = صافي المبيعات − COGS", Math.abs(V.cogs.gross_profit - r2(V.cogs.net_sales - V.cogs.cogs)) < 0.02);

  // ─────────── C) live proof — product lifecycle ───────────
  console.log("\n— C) الإثبات الحي: إدخال وتسوية تنعكسان فورًا —");
  const prod = await req("POST", "/products", T, {
    name: `منتج تحقق التقييم ${rand}`, cost_price: 5000, sale_price: 8000, min_stock: 10,
  });
  check("إنشاء منتج الاختبار", prod.status < 300 && !!prod.body.data?.id, JSON.stringify(prod.body).slice(0, 120));
  const PID = prod.body.data?.id as number;

  const mainWh = allWh.find((w) => w.code === "WH-MAIN")!;
  const in1 = await req("POST", "/inventory/movements", T, { warehouse_id: mainWh.id, product_id: PID, direction: "IN", qty: 100, unit_cost: 6000 });
  check("إدخال 100 × 6,000", in1.status < 300, JSON.stringify(in1.body).slice(0, 120));
  const in2 = await req("POST", "/inventory/movements", T, { warehouse_id: mainWh.id, product_id: PID, direction: "IN", qty: 200, unit_cost: 8000 });
  check("إدخال 200 × 8,000", in2.status < 300);
  // §66.8: المتوسط المرجح = 2,200,000 ÷ 300 = 7,333.33
  const val1 = await req("GET", `/inventory/valuation?product_id=${PID}`, T);
  const P1 = val1.body.data?.product;
  check("متوسط التكلفة بعد طبقتين = 7,333.33 (§66.8)", P1 && Math.abs(P1.avg_cost - 2200000 / 300) < 0.01, `avg=${P1?.avg_cost}`);
  check("آخر تكلفة = 8,000 (طبقة أحدث)", P1 && Math.abs(P1.last_cost - 8000) < 0.01, `last=${P1?.last_cost}`);
  check("كمية المنتج في البطاقات = 300", P1 && Math.abs(P1.totals.qty - 300) < 0.01);
  check("قيمته التكلفية = 2,200,000", P1 && Math.abs(P1.totals.cost_value - 2200000) < 1);

  // تسوية جرد — عجز 5 (§66.16): OUT = ADJUSTMENT آليًا
  const adjOut = await req("POST", "/inventory/movements", T, { warehouse_id: mainWh.id, product_id: PID, direction: "OUT", qty: 5, note: "فرق جرد — عجز تحقق" });
  check("تسوية عجز −5 قُيدت كـ ADJUSTMENT", adjOut.status < 300);
  // تسوية زيادة +3 (§66.15): Adjustment In صريح
  const adjIn = await req("POST", "/inventory/movements", T, { warehouse_id: mainWh.id, product_id: PID, direction: "IN", qty: 3, unit_cost: 7333.33, note: "فرق جرد — زيادة تحقق", ref_type: "ADJUSTMENT" });
  check("تسوية زيادة +3 قُيدت كـ Adjustment In", adjIn.status < 300);
  const val2 = await req("GET", `/inventory/valuation?product_id=${PID}`, T);
  const P2 = val2.body.data?.product;
  check("الرصيد انعكس فورًا: 300−5+3=298", P2 && Math.abs(P2.totals.qty - 298) < 0.01, `qty=${P2?.totals?.qty}`);

  const valAfter = await req("GET", "/inventory/valuation", T);
  const VA = valAfter.body.data;
  const adjRows = await db.stockMovement.count({ where: { companyId: 1, refType: "ADJUSTMENT", productId: PID } });
  check("عدّاد فروقات الجرد التقط التسويتين", VA.adjustments.count >= adjRows && adjRows === 2, `count=${VA.adjustments.count}, db=${adjRows}`);
  const shortageVal = VA.adjustments.shortage_value;
  const surplusVal = VA.adjustments.surplus_value;
  check("قيمة العجز تشمل 5 × المتوسط (§66.14)", shortageVal >= 5 * (2200000 / 300) - 1, `shortage=${shortageVal}`);
  check("قيمة الزيادة تشمل 3 × 7,333.33", surplusVal >= 3 * 7333.33 - 1, `surplus=${surplusVal}`);
  check("الصافي = زيادة − عجز", Math.abs(VA.adjustments.net_value - r2(surplusVal - shortageVal)) < 0.02);

  // ─────────── D) COGS live — invoice posting ───────────
  console.log("\n— D) COGS الحي: فاتورة ترفع تكلفة البضاعة المباعة —");
  const cust = await req("POST", "/customers", T, { name: `عميل تحقق التقييم ${rand}`, credit_limit: 100000000 });
  const CID = cust.body.data?.id as number;
  check("إنشاء عميل الاختبار", cust.status < 300 && !!CID);
  const cogsBefore = VA.cogs.cogs;
  const inv = await req("POST", "/sales/invoices", T, {
    customer_id: CID, warehouse_id: mainWh.id, type: "CASH",
    lines: [{ product_id: PID, qty: 20 }],
  });
  check("فاتورة بيع 20 وحدة أُنشئت", inv.status < 300 && !!inv.body.data?.id, JSON.stringify(inv.body).slice(0, 140));
  const invId = inv.body.data?.id as number;
  const val3 = await req("GET", "/inventory/valuation", T);
  const V3 = val3.body.data;
  const line = await db.salesInvoiceLine.findFirst({ where: { invoiceId: invId }, select: { qty: true, unitCost: true } });
  check("لقطة تكلفة البند مسجّلة عند الترحيل", !!line && line.unitCost > 0, JSON.stringify(line));
  const expDelta = r2((line?.qty ?? 0) * (line?.unitCost ?? 0));
  check("COGS ارتفع بـ qty × لقطة التكلفة", Math.abs(V3.cogs.cogs - (cogsBefore + expDelta)) < 1, `${V3.cogs.cogs} vs ${cogsBefore}+${expDelta}`);
  check("إيراد الفاتورة داخل صافي المبيعات", V3.cogs.revenue >= r2(inv.body.data?.grand_total ?? 0) - 1);
  const valP3 = await req("GET", `/inventory/valuation?product_id=${PID}`, T);
  check("رصيد المنتج نزل 20 وحدة بعد البيع (298−20=278)", valP3.body.data?.product?.totals?.qty === 278, `qty=${valP3.body.data?.product?.totals?.qty}`);

  // ─────────── E) branch scope + where-is-item ───────────
  console.log("\n— E) نطاق الفرع وأين توجد المادة —");
  const basraWh = allWh.filter((w) => w.branchId === 2);
  check("مدير البصرة يرى مستودعات فرعه فقط", valBasra.body.data.by_location.every((r: any) => basraWh.some((w) => w.id === r.warehouse_id)) && valBasra.body.data.by_location.length === basraWh.filter((w: any) => true).length, JSON.stringify(valBasra.body.data.by_location));
  const basraExpCost = V.by_location.filter((r: any) => basraWh.some((w) => w.id === r.warehouse_id)).reduce((s: number, r: any) => s + r.cost_value, 0);
  check("قيمة البصرة ⊂ قيمة الشركة وتطابق جزء الإدارة", Math.abs(valBasra.body.data.totals.cost_value - r2(basraExpCost)) < 1, `${valBasra.body.data.totals.cost_value} vs ${r2(basraExpCost)}`);
  check("مدير البصرة لا يرى منتج الاختبار (مخزونه في بغداد)", !(valBasra.body.data.by_location.some((r: any) => r.warehouse_id === mainWh.id)));

  // where-is-item عبر منتج موجود في عدة مواقع: حوّل 40 وحدة لمخزن المندوب
  const repWh = allWh.find((w) => w.type === "REP" && w.branchId === 1)!;
  const tr = await req("POST", "/inventory/transfers", T, {
    from_warehouse_id: mainWh.id, to_warehouse_id: repWh.id,
    lines: [{ product_id: PID, qty: 40 }],
  });
  check("تحويل 40 وحدة لمخزن المندوب (لتعدد المواقع)", tr.status < 300, JSON.stringify(tr.body).slice(0, 140));
  const rec = await req("POST", `/inventory/transfers/${tr.body.data?.id}/receive`, T, {});
  check("استلام التحويل", rec.status < 300, JSON.stringify(rec.body).slice(0, 120));
  const val4 = await req("GET", `/inventory/valuation?product_id=${PID}`, T);
  const P4 = val4.body.data?.product;
  const locs = P4?.locations ?? [];
  check("أين توجد المادة؟ يعرض مواقعين (رئيسي + مندوب)", locs.length === 2, JSON.stringify(locs));
  check("مجموع مواقع المنتج = الرصيد الكلي", Math.abs(locs.reduce((s: number, l: any) => s + l.qty, 0) - P4.totals.qty) < 0.01);
  check("الإجمالي الكلي للشركة انعكس في البطاقات (298−20=278)", P4.totals.qty === 278);

  // إعدادات §66.7/66.23
  check("طريقة التكلفة الافتراضية WEIGHTED_AVERAGE", V.meta.cost_method === "WEIGHTED_AVERAGE");
  const valD30 = await req("GET", "/inventory/valuation?dead_days=30", T);
  check("تعريف الراكد قابل للتهيئة dead_days=30", valD30.body.data?.meta?.dead_days === 30);

  // ─────────── F) cleanup ───────────
  console.log("\n— F) التنظيف —");
  await db.product.updateMany({ where: { id: PID }, data: { deletedAt: new Date(), isActive: false } });
  check("منتج الاختبار حُذف ناعمًا (يختفي من البطاقات)", true);
  if (CID) await db.customer.updateMany({ where: { id: CID }, data: { deletedAt: new Date(), isActive: false } });
  if (invId) await db.salesInvoice.updateMany({ where: { id: invId }, data: { deletedAt: new Date() } });
  // حركة الاختبار تبقى في الدفتر (غير قابل للحذف بالتصميم §66.32-12) لكن منتجها محذوف
  const valFinal = await req("GET", "/inventory/valuation", T);
  check("البطاقات سليمة بعد التنظيف (المنتج المحذوف اختفى)", valFinal.status === 200 && valFinal.body.data.totals.items_count === V.totals.items_count, `${valFinal.body.data?.totals?.items_count} vs ${V.totals.items_count}`);
  for (const uid of createdUserIds) {
    await db.userRole.deleteMany({ where: { userId: uid } });
    await db.userWarehouseAccess.deleteMany({ where: { userId: uid } });
    await db.user.updateMany({ where: { id: uid }, data: { deletedAt: new Date(), isActive: false } });
  }
  check("مستخدمو التحقق نُظفوا", true);

  // ═══════════ النتيجة ═══════════
  console.log(`\n════════════════════════════════════`);
  console.log(`PASSED: ${pass}  FAILED: ${fail}`);
  console.log(`════════════════════════════════════`);
  await db.$disconnect();
  process.exit(fail === 0 ? 0 : 1);
}

main().catch(async (e) => {
  console.error("FATAL:", e);
  await db.$disconnect();
  process.exit(1);
});
