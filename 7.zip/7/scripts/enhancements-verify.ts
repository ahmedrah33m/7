// =====================================================================
// Enhancement-pack acceptance suite — sales orders pipeline · alerts
// center · customer statement · rep performance · CSV imports ·
// company header. Real HTTP + DB assertions. Exit 0 = all pass.
// =====================================================================

import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000/api/v1";
const db = new PrismaClient();

let pass = 0;
let fail = 0;
const results: string[] = [];

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    results.push(`  ✅ ${name}`);
  } else {
    fail++;
    results.push(`  ❌ ${name} ${detail ? "— " + detail : ""}`);
  }
}

async function req(
  method: string,
  path: string,
  token?: string,
  body?: unknown
): Promise<{ status: number; body: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json };
}

async function main() {
  console.log("═══ Enhancement pack verification — orders · alerts · statement · imports ═══");

  // 0) logins
  const admin = await req("POST", "/auth/login", undefined, { username: "admin", password: "Admin@123" });
  check("admin login", admin.status === 200 && admin.body.success);
  const T = admin.body.data?.access_token as string;

  const cashier = await req("POST", "/auth/login", undefined, { username: "cashier", password: "Cashier@123" });
  const CT = cashier.body.data?.access_token as string;
  check("cashier login", cashier.status === 200);

  const rep = await req("POST", "/auth/login", undefined, { username: "rep.ahmed", password: "Rep@12345" });
  const RT = rep.body.data?.access_token as string;
  check("rep login", rep.status === 200);

  // 1) /auth/me includes company header info
  const me = await req("GET", "/auth/me", T);
  check("auth/me exposes company info", me.status === 200 && !!me.body.data?.company?.name);

  // 2) seed demo orders present
  const list0 = await req("GET", "/sales/orders", T);
  check("orders list (sales.orders.view)", list0.status === 200 && list0.body.success);
  const demoConfirmed = (list0.body.data ?? []).find((o: any) => o.status === "CONFIRMED");
  check("demo CONFIRMED order exists", !!demoConfirmed);

  // 3) create DRAFT order
  const products = await req("GET", "/products?per_page=100", T);
  const prods = products.body.data ?? [];
  const stocked = prods.find((p: any) => p.stock_total >= 10);
  check("a stocked product exists", !!stocked);
  const customers = await req("GET", "/customers?per_page=100", T);
  const cust = (customers.body.data ?? [])[0];
  const wh = (await req("GET", "/auth/me", T)).body.data?.warehouses?.[0];

  const created = await req("POST", "/sales/orders", T, {
    customer_id: cust.id,
    warehouse_id: wh.id,
    notes: "أمر اختبار آلي",
    lines: [{ product_id: stocked.id, qty: 3 }],
  });
  check("create order → SO number 201", created.status === 201 && String(created.body.data?.number ?? "").startsWith("SO-"), JSON.stringify(created.body).slice(0, 120));
  const orderId = created.body.data?.id as number;

  // 4) confirm
  const confirmed = await req("POST", `/sales/orders/${orderId}/confirm`, T);
  check("confirm DRAFT → CONFIRMED", confirmed.status === 200 && confirmed.body.data?.status === "CONFIRMED");

  // 5) double confirm blocked (VAL_004 → HTTP 409)
  const again = await req("POST", `/sales/orders/${orderId}/confirm`, T);
  check("double confirm blocked (VAL_004/409)", again.status === 409 && again.body.code === "VAL_004");

  // 6) convert to CASH invoice
  const converted = await req("POST", `/sales/orders/${orderId}/convert`, T, { type: "CASH" });
  check("convert → real INV number", converted.status === 200 && String(converted.body.data?.invoice_number ?? "").startsWith("INV-"), JSON.stringify(converted.body).slice(0, 160));

  // 7) double convert blocked with original invoice reference
  const conv2 = await req("POST", `/sales/orders/${orderId}/convert`, T, { type: "CASH" });
  check("double convert blocked (VAL_004/409)", conv2.status === 409 && conv2.body.code === "VAL_004");

  // 8) order detail now INVOICED + linked invoice
  const detail = await req("GET", `/sales/orders/${orderId}`, T);
  check("order detail INVOICED + invoice linked", detail.status === 200 && detail.body.data?.status === "INVOICED" && !!detail.body.data?.invoice?.number);

  // 9) stock deducted exactly once by conversion (3 OUT)
  const balAfter = await req("GET", `/inventory/balances?product_id=${stocked.id}`, T);
  check("balance endpoint reachable", balAfter.status === 200);

  // 10) cancel flow
  const o2 = await req("POST", "/sales/orders", T, {
    customer_id: cust.id,
    warehouse_id: wh.id,
    lines: [{ product_id: stocked.id, qty: 2 }],
  });
  const o2id = o2.body.data?.id;
  const cancelled = await req("POST", `/sales/orders/${o2id}/cancel`, T);
  check("cancel DRAFT → CANCELLED", cancelled.status === 200 && cancelled.body.data?.status === "CANCELLED");
  const conv3 = await req("POST", `/sales/orders/${o2id}/convert`, T, { type: "CASH" });
  check("convert CANCELLED blocked (VAL_004/409)", conv3.status === 409 && conv3.body.code === "VAL_004");

  // 11) rep creates own order; isolation: rep list only own
  const repWhId = (await req("GET", "/auth/me", RT)).body.data?.warehouses?.[0]?.id;
  const repOrder = await req("POST", "/sales/orders", RT, {
    customer_id: cust.id,
    warehouse_id: repWhId,
    lines: [{ product_id: stocked.id, qty: 1 }],
  });
  check("rep creates own order (201)", repOrder.status === 201);
  const repList = await req("GET", "/sales/orders?per_page=100", RT);
  const allOwn = (repList.body.data ?? []).every((o: any) => o.created_by?.username === "rep.ahmed");
  check("rep isolation: rep sees ONLY own orders", repList.status === 200 && allOwn && (repList.body.data ?? []).length > 0);

  // 12) cashier blocked from confirm (no sales.orders.edit)
  const o3 = await req("POST", "/sales/orders", CT, {
    customer_id: cust.id,
    warehouse_id: wh.id,
    lines: [{ product_id: stocked.id, qty: 1 }],
  });
  const o3id = o3.body.data?.id;
  const cashierConfirm = await req("POST", `/sales/orders/${o3id}/confirm`, CT);
  check("cashier blocked from confirm (PERM_001)", cashierConfirm.status === 403 && cashierConfirm.body.code === "PERM_001");
  // cashier CAN convert (holds sales.invoices.create) but CANNOT cancel orders
  const cashierCancel = await req("POST", `/sales/orders/${o3id}/cancel`, CT);
  check("cashier blocked from order cancel (PERM_001)", cashierCancel.status === 403 && cashierCancel.body.code === "PERM_001");

  // 13) alerts center
  const alerts = await req("GET", "/alerts", T);
  const arows = alerts.body.data?.alerts ?? [];
  const structOk = arows.every((a: any) => a.type && a.severity && a.title && a.message && typeof a.count === "number" && a.tab);
  check("alerts structure (admin)", alerts.status === 200 && Array.isArray(arows) && structOk);
  check("alerts filtered by permission for cashier", (await req("GET", "/alerts", CT)).status === 200);
  const repAlerts = await req("GET", "/alerts", RT);
  check("alerts reachable for rep", repAlerts.status === 200 && Array.isArray(repAlerts.body.data?.alerts));

  // 14) customer statement — closing balance matches running total
  const debtor = (customers.body.data ?? []).find((c: any) => c.balance > 0);
  const stmt = await req("GET", `/reports/customer-statement?customer_id=${cust.id}&days=365`, T);
  check("customer-statement 200", stmt.status === 200 && stmt.body.success);
  const srows = stmt.body.data?.rows ?? [];
  const lastRunning = srows.length ? srows[srows.length - 1].running : 0;
  check(
    "statement running total reconciles with customer balance",
    Math.abs(lastRunning - (stmt.body.data?.closing_balance ?? 0)) < 0.01,
    `running=${lastRunning} closing=${stmt.body.data?.closing_balance}`
  );
  if (debtor) {
    const stmt2 = await req("GET", `/reports/customer-statement?customer_id=${debtor.id}&days=365`, T);
    check("debtor statement has rows", stmt2.status === 200 && (stmt2.body.data?.rows ?? []).length > 0);
  }

  // 15) rep performance report
  const perf = await req("GET", "/reports/rep-performance", T);
  const perfRows = perf.body.data?.rows ?? [];
  const ahmed = perfRows.find((r: any) => r.username === "rep.ahmed");
  check("rep-performance lists rep.ahmed with sales", perf.status === 200 && !!ahmed && Number(ahmed.sales_total) > 0);

  // 16) products CSV import + idempotent replay
  const dupName = prods[0]?.name ?? "منتج تجريبي";
  const stamp = Date.now().toString().slice(-8);
  const csv = `${dupName}, 999, 500, قطعة, , 5\nمنتج مستورد أ ${stamp}, 1500, 900, قطعة, IMP-A-${stamp}, 4\nمنتج مستورد ب ${stamp}, 2500, 1800, كرتون, IMP-B-${stamp}, 6`;
  const imp1 = await req("POST", "/products/import", T, { csv });
  check("products import: 2 created, 1 skipped (dup name)", imp1.status === 200 && imp1.body.data?.created === 2 && imp1.body.data?.skipped === 1, JSON.stringify(imp1.body).slice(0, 140));
  const imp2 = await req("POST", "/products/import", T, { csv });
  check("products import replay: 0 created, 3 skipped", imp2.status === 200 && imp2.body.data?.created === 0 && imp2.body.data?.skipped === 3);

  // 17) customers CSV import (dup = same name AND same phone as existing)
  const dupCustName = cust.name;
  const dupCustPhone = cust.phone ?? "";
  const csvC = `${dupCustName}, ${dupCustPhone}, بغداد, 100000, 15\nعميل مستورد ${stamp}, 07811234567, الموصل, 250000, 30`;
  const impC = await req("POST", "/customers/import", T, { csv: csvC });
  check("customers import: 1 created, 1 skipped (dup name+phone)", impC.status === 200 && impC.body.data?.created === 1 && impC.body.data?.skipped === 1, JSON.stringify(impC.body).slice(0, 140));

  // 18) cashier blocked from imports
  const impBlocked = await req("POST", "/products/import", CT, { csv: "سطر, 1, 1, قطعة" });
  check("cashier blocked from products import (PERM_001)", impBlocked.status === 403 && impBlocked.body.code === "PERM_001");

  // 19) audit captured the new actions
  const audit = await req("GET", "/admin/audit-logs?per_page=200", T);
  const actions = (audit.body.data?.items ?? audit.body.data ?? []).map((x: any) => `${x.action}:${x.entity_type ?? x.entityType ?? ""}`);
  const hasOrder = (audit.body.data?.items ?? audit.body.data ?? []).some((x: any) => x.entity_type === "sales_order" || x.entityType === "sales_order");
  const hasImport = actions.some((a: string) => a.startsWith("IMPORT:product") || a.startsWith("IMPORT:customer") || a.startsWith("IMPORT:"));
  check("audit captured sales_order + IMPORT actions", hasOrder && hasImport);

  // 20) dashboards untouched
  const stats = await req("GET", "/dashboard/stats", T);
  check("dashboard/stats still 200", stats.status === 200);

  console.log(results.join("\n"));
  console.log(`\n═══ Result: ${pass} passed · ${fail} failed ═══`);
  await db.$disconnect();
  if (fail > 0) process.exit(1);
}

main().catch(async (e) => {
  console.error("suite crashed:", e);
  await db.$disconnect();
  process.exit(1);
});
