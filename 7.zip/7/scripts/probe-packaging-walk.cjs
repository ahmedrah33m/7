// مسبار أدق لعزل انحدار دفتر التعبئة: شراء 3 كراتين → بيع كرتونة → بيع 3 حبات
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();
const BASE = "http://localhost:3000/api/v1";
const jf = (p, a, i) => fetch(`${BASE}${p}`, i ? { ...i, headers: { ...a, "content-type": "application/json", ...(i.headers||{}) } } : { headers: a }).then((r) => r.json());
const post = (p, a, d) => jf(p, a, { method: "POST", body: JSON.stringify(d) });
(async () => {
  const login = await post("/auth/login", {}, { username: "admin", password: "Admin@123" });
  const t1 = login.data?.access_token;
  const sw = await post("/auth/switch-company", { authorization: `Bearer ${t1}` }, { company_id: 6 });
  const auth = { authorization: `Bearer ${sw.data?.access_token}` };
  const me = await jf("/auth/me", auth);
  const wh = me.data?.warehouses?.[0];
  const walkin = (await jf("/customers/default-walkin", auth)).data?.id;
  const sfx = Date.now().toString().slice(-6);
  const prod = (await post("/products", auth, {
    name: `PROBE-${sfx}`, unit: "علبة", pack_unit: "كرتون", pack_qty: 11,
    pack_sale_price: 26, pack_sale_currency: "USD", sale_price: 2.363636, sale_currency: "USD",
    cost_price: 2.2727272727, cost_currency: "USD", exchange_rate: 1300, min_stock: 1,
  })).data;
  const sup = (await post("/suppliers", auth, { name: `SUP-${sfx}` })).data;
  const buy = await post("/purchases/invoices", auth, { supplier_id: sup.id, warehouse_id: wh.id, type: "CASH", lines: [{ product_id: prod.id, qty: 33, unit_cost: 2954.5455 }] });
  console.log("buy ok:", buy.success);
  const pkgsAfterBuy = await db.package.findMany({ where: { productId: prod.id }, orderBy: { id: "asc" }, select: { id: true, code: true, status: true, remainingQty: true } });
  console.log("after buy:", pkgsAfterBuy.map((k) => `${k.id}:${k.status}:${k.remainingQty}`).join("  "));

  const inv1 = await post("/sales/invoices", auth, { customer_id: walkin, warehouse_id: wh.id, type: "CASH", currency_code: "IQD", lines: [{ product_id: prod.id, package_qty: 1, loose_qty: 0 }] });
  console.log("inv1 (1 كرتون):", inv1.success, inv1.data?.grand_total);
  const inv2 = await post("/sales/invoices", auth, { customer_id: walkin, warehouse_id: wh.id, type: "CASH", currency_code: "IQD", lines: [{ product_id: prod.id, package_qty: 0, loose_qty: 3 }] });
  console.log("inv2 (3 حبات):", inv2.success, inv2.data?.grand_total);

  const led = await db.packagingLedger.findMany({ where: { productId: prod.id }, orderBy: { id: "asc" } });
  for (const r of led) console.log(r.id, r.direction.padEnd(7), "pkg", r.packageId, "open", r.openingQty?.toString().padEnd(4), "iss", r.issuedQty?.toString().padEnd(4), "rem", r.remainingQty?.toString().padEnd(4), (r.note || "").slice(0, 40));
  const pkgs = await db.package.findMany({ where: { productId: prod.id }, orderBy: { id: "asc" }, select: { id: true, status: true, remainingQty: true } });
  console.log("final:", pkgs.map((k) => `${k.id}:${k.status}:${k.remainingQty}`).join("  "));
  await db.$disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
