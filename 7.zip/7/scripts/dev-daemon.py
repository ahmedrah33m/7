#!/usr/bin/env python3
"""Classic double-fork daemonizer — escapes tool-session process cleanup.
Starts the Next.js dev server as an orphan adopted by PID 1 (own session,
no controlling tty). Idempotent: exits if port 3000 already answers."""
import os
import sys
import time
import urllib.request

def alive():
    try:
        with urllib.request.urlopen("http://127.0.0.1:3000/api/v1/health", timeout=3) as r:
            return r.status == 200
    except Exception:
        return False

if alive():
    print("dev server already running")
    sys.exit(0)

pid = os.fork()
if pid:
    # parent — wait briefly then report
    for _ in range(30):
        time.sleep(1)
        if alive():
            print("dev server started (daemon pid unknown, port 3000 up)")
            sys.exit(0)
    print("dev server did not come up in 30s — check /tmp/next-dev.log")
    sys.exit(1)

# child 1: new session, detach tty
os.setsid()
pid2 = os.fork()
if pid2:
    os._exit(0)

# child 2: orphan → adopted by PID 1
os.chdir("/home/z/my-project")
devnull = os.open(os.devnull, os.O_RDWR)
out = os.open("/tmp/next-dev.log", os.O_CREAT | os.O_WRONLY | os.O_APPEND)
os.dup2(devnull, 0)
os.dup2(out, 1)
os.dup2(out, 2)
os.close(devnull)
os.environ.setdefault("NODE_ENV", "development")
os.execvp("bun", ["bun", "run", "dev"])
