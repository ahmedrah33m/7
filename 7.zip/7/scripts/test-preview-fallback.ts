/**
 * اختبار إصلاح المعاينة: العبوات المشتقة من الرصيد للمخزون القديم
 * المتوقع: الشامبو (رصيد 200، عبوات غير مُزامنة) يعرض 18 كراتين كاملة + 2 حبة بدل 0
 */
const BASE = "http://localhost:3000";

interface LoginResp { success: boolean; data?: { access_token?: string }; message?: string }

async function main() {
  // دخول + تبديل إلى لوميره (id=2)
  const login = (await (await fetch(`${BASE}/api/v1/auth/login`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: "admin", password: "Admin@123" }),
  })).json()) as LoginResp;
  const t1 = login.data?.access_token;
  if (!t1) throw new Error("LOGIN_FAILED");
  const sw = (await (await fetch(`${BASE}/api/v1/auth/switch-company`, {
    method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${t1}` },
    body: JSON.stringify({ company_id: 2 }),
  })).json()) as LoginResp;
  const token = sw.data?.access_token;
  if (!token) throw new Error("SWITCH_FAILED");
  const H = { "Content-Type": "application/json", Authorization: `Bearer ${token}` };

  // المستودع الأول + المنتج 10
  const me = (await (await fetch(`${BASE}/api/v1/auth/me`, { headers: H })).json()) as {
    success: boolean; data?: { warehouses?: { id: number; name: string }[] };
  };
  const wh = me.data?.warehouses?.[0];
  if (!wh) throw new Error("NO_WAREHOUSE");
  console.log(`المستودع: ${wh.name} (id=${wh.id})`);

  const prev = (await (await fetch(`${BASE}/api/v1/sales/invoices/preview`, {
    method: "POST", headers: H,
    body: JSON.stringify({ customer_id: 8, warehouse_id: wh.id, product_ids: [10] }),
  })).json()) as {
    success: boolean;
    data?: { packages?: Record<string, { has_pack: boolean; closed_packages?: number; open_packages?: number; open_qty?: number; total_pieces?: number; text?: string; packages_synced?: boolean }> };
  };
  const pkg = prev.data?.packages?.["10"];
  console.log("\n=== حالة عبوات المنتج 10 (شامبو) ===");
  console.log(JSON.stringify(pkg, null, 2));

  const okCase = pkg && pkg.has_pack && (pkg.total_pieces ?? 0) > 0;
  console.log(`\n${okCase ? "✓ النجاح: العبوات معروضة من الرصيد (بدل صفر)" : "✗ فشل: ما زالت صفر"}`);
  if (!okCase) process.exit(1);
}

main().catch((e) => { console.error("TEST_ERROR:", e instanceof Error ? e.message : e); process.exit(1); });
