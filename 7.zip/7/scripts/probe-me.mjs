// Quick probe: login → switch to company 6 (الفرات) → GET /me → print warehouses
const BASE = "http://localhost:3000";
const j = async (path, init = {}, token) => {
  const res = await fetch(BASE + path, { ...init, headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) } });
  return { status: res.status, body: await res.json().catch(() => ({})) };
};

const login = await j("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: "admin", password: "Admin@123" }) });
const t1 = login.body?.data?.access_token;
const sw = await j("/api/v1/auth/switch-company", { method: "POST", body: JSON.stringify({ company_id: 6 }) }, t1);
const t2 = sw.body?.data?.access_token;
console.log("switch ok:", !!t2);
const me = await j("/api/v1/auth/me", {}, t2);
console.log("me.company:", me.body?.data?.company?.name);
console.log("me.user.company_id:", me.body?.data?.user?.company_id);
console.log("me.warehouses:", JSON.stringify(me.body?.data?.warehouses));
console.log("me.scope.warehouses:", JSON.stringify(me.body?.data?.scope?.warehouses));
console.log("me.scope.branches:", JSON.stringify(me.body?.data?.scope?.branches));
