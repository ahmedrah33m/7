#!/usr/bin/env bash
# =============================================================
# make-v4-package.sh — تجهيز نسخة التغليف وبناء أرشيف v4
# - ينسخ كل ملفات النظام إلى مجلد تغليف نظيف (.pkg-v4)
# - لقطة آمنة (sqlite backup API) لقاعدة البيانات الحية
# - .env قابل للحمل (مسار نسبي) لعمل على أي سيرفر
# - يتحقق من وجود إصلاحات المشاكل الثلاث في المصدر
# - يبني الأرشيف: download/sales-distribution-system-full-v4-2026-09-16.zip
# =============================================================
set -euo pipefail

ROOT="/home/z/my-project"
STAGE="$ROOT/.pkg-v4"
OUT="$ROOT/download/sales-distribution-system-full-v4-2026-09-16.zip"

say() { echo -e "\n\033[1;36m==> $*\033[0m"; }
ok()  { echo -e "\033[1;32m✔ $*\033[0m"; }
die() { echo -e "\033[1;31m✘ $*\033[0m"; exit 1; }

cd "$ROOT"

say "تنظيف نسخة التغليف السابقة…"
rm -rf "$STAGE"
mkdir -p "$STAGE/db"

say "نسخ المجلدات الرئيسية…"
rsync -a --exclude '*.png' src/          "$STAGE/src/"
rsync -a                          prisma/ "$STAGE/prisma/"
rsync -a --exclude '*.png' scripts/       "$STAGE/scripts/"
rsync -a                          docs/   "$STAGE/docs/"
rsync -a                          assets/ "$STAGE/assets/"
rsync -a                          upload/ "$STAGE/upload/"
rsync -a                          deploy/ "$STAGE/deploy/"
ok "src · prisma · scripts(بلا PNG) · docs · assets · upload · deploy"

say "نسخ ملفات الجذر…"
for f in package.json package-lock.json bun.lock tsconfig.json next.config.ts \
         postcss.config.mjs eslint.config.mjs next-env.d.ts README.md \
         VERIFICATION.md DEPLOY-UBUNTU.md worklog.md .env.example .gitignore; do
  [ -f "$f" ] && cp -a "$f" "$STAGE/" || die "ملف مفقود: $f"
done
ok "ملفات الجذر (13)"

say "نسخ احتياطي آمن للنسخة phase0 من القاعدة…"
cp -a db/custom.phase0.bak "$STAGE/db/"

say "لقطة آمنة (online backup) لقاعدة البيانات الحية…"
python3 - <<'PY'
import sqlite3, os
src = "/home/z/my-project/db/custom.db"
dst = "/home/z/my-project/.pkg-v4/db/custom.db"
s = sqlite3.connect(f"file:{src}?mode=ro", uri=True)
d = sqlite3.connect(dst)
s.backup(d)
d.close(); s.close()
# فحص سريع للقطة
c = sqlite3.connect(dst)
n_comp = c.execute("SELECT COUNT(*) FROM companies").fetchone()[0]
n_user = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
c.close()
print(f"    snapshot OK: companies={n_comp} users={n_user} size={os.path.getsize(dst)} bytes")
PY
ok "لقطة قاعدة البيانات"

say "كتابة .env قابل للحمل (مسار نسبي يعمل على أي سيرفر)…"
cat > "$STAGE/.env" <<'EOF'
# SQLite — مسار نسبي من مجلد prisma/ (يعمل من أي مجلد تثبيت)
# في الإنتاج يُفضَّل مسار مطلق، مثال: DATABASE_URL=file:/opt/sds/db/custom.db
DATABASE_URL=file:../db/custom.db

# أسرار التوكنات — ولّد قيمة عشوائية للإنتاج بالأمر: openssl rand -hex 32
# JWT_ACCESS_SECRET=<ضع هنا قيمة عشوائية بطول 64 حرف>
EOF
ok ".env قابل للحمل"

say "التحقق من وجود إصلاحات المشاكل الثلاث في المصدر…"
grep -q "visible_company_ids" "$STAGE/src/app/api/v1/admin/users/route.ts" \
  || die "إصلاح 1 (رؤية كل المستخدمين) غير موجود!"
grep -q "SUB_001" "$STAGE/src/components/sales-dashboard.tsx" \
  || die "إصلاح 2 (توست 423) غير موجود!"
grep -q "subscription" "$STAGE/src/lib/session-payload.ts" \
  || die "إصلاح 3 (حالة الشركة في الجلسة) غير موجود!"
grep -q "subscriptionEndsAt" "$STAGE/prisma/schema.prisma" \
  || die "حقول الاشتراك غير موجودة في schema!"
ok "إصلاحات المشاكل الثلاث + حقول الاشتراك ✔"

say "بناء الأرشيف…"
mkdir -p "$ROOT/download"
rm -f "$OUT"
( cd "$STAGE" && zip -r -X -q "$OUT" . )
ok "الأرشيف: $OUT"

echo
echo "عدد الملفات في الأرشيف: $(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
echo "حجم الأرشيف: $(du -h "$OUT" | cut -f1)"
