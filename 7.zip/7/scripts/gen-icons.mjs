// Generates PWA icons (192/512) via the global playwright chromium.
// Run: node scripts/gen-icons.mjs
import { createRequire } from "module";
import { mkdirSync } from "fs";
const require = createRequire(import.meta.url);
let pw;
try { pw = require("playwright"); }
catch { pw = require("/home/z/.npm-global/lib/node_modules/playwright"); }

const html = `<!doctype html><html><head><style>
*{margin:0;padding:0}
body{width:100vw;height:100vh;display:flex;align-items:center;justify-content:center;background:transparent}
.box{width:86vmin;height:86vmin;border-radius:18%;background:linear-gradient(135deg,#f97316,#ea580c);display:flex;align-items:center;justify-content:center;box-shadow:0 4% 10% rgba(0,0,0,.2)}
.box svg{width:55%}
</style></head><body>
<div class="box"><svg viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
<path d="M2 7l1.5-3h17L22 7"/><path d="M2 7h20v3a3 3 0 0 1-6 0 3 3 0 0 1-6 0 3 3 0 0 1-6 0V7z"/><path d="M4 12v8a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-8"/><path d="M9 21v-5h6v5"/>
</svg></div></body></html>`;

mkdirSync("public/icons", { recursive: true });
const browser = await pw.chromium.launch({ headless: true, args: ["--no-sandbox"] });
for (const size of [192, 512]) {
  const page = await browser.newPage({ viewport: { width: size, height: size }, deviceScaleFactor: 1 });
  await page.setContent(html, { waitUntil: "load" });
  await page.screenshot({ path: `public/icons/icon-${size}.png`, omitBackground: true });
  await page.close();
  console.log(`icon-${size}.png done`);
}
await browser.close();
