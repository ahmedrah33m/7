# جراحة أسطر: إضافة package_price/piece_price إلى خدمة المبيعات (§18/§19)
import re, sys

P = "/home/z/my-project/src/lib/sales-service.ts"
src = open(P, encoding="utf-8").read()

# ---- 1) حقول الإدخال الجديدة بعد price_unit --------------------------------
old1 = '  price_unit?: "PIECE" | "PACKAGE"; // what unit_price refers to (default PIECE)\n  discount_pct?: number | null;'
new1 = ('  price_unit?: "PIECE" | "PACKAGE"; // what unit_price refers to (default PIECE)\n'
        '  package_price?: number | null; // سعر الكرتونة الصريح — يتجاوز unit_price (§19)\n'
        '  piece_price?: number | null;   // سعر الحبة الصريح — يتجاوز unit_price\n'
        '  discount_pct?: number | null;')
assert src.count(old1) == 1, f"anchor1 = {src.count(old1)}"
src = src.replace(old1, new1)

# ---- 2) لقطة مصدر السعر: أي سعر يدوي صريح يعدل العملة ----------------------
old2 = "    if (l.unit_price != null) {\n      if (currencyCode === \"USD\") { priceCurrency = \"USD\"; priceExchangeRate = exchangeRate; }"
new2 = ("    if (l.unit_price != null || l.package_price != null || l.piece_price != null) {\n"
        "      if (currencyCode === \"USD\") { priceCurrency = \"USD\"; priceExchangeRate = exchangeRate; }")
assert src.count(old2) == 1, f"anchor2 = {src.count(old2)}"
src = src.replace(old2, new2)

# ---- 3) منطق الأسعار: كرتون + حبات بسعرين مستقلين ---------------------------
old3 = '''    // price resolution (§18/§19): carton price may differ from 12 × piece price
    const priceUnit = l.price_unit ?? (l.unit === "PACKAGE" ? "PACKAGE" : "PIECE");
    let piecePrice: Decimal, packagePrice: Decimal | null = null;
    if (info.hasPack && packageQty.isPositive()) {
      packagePrice = priceUnit === "PACKAGE"
        ? moneyOf(l.unit_price ?? defPackIqd ?? moneyOf(moneyOf(info.packQty).mul(defPieceIqd)))
        : moneyOf(defPackIqd ?? moneyOf(moneyOf(info.packQty).mul(l.unit_price ?? defPieceIqd)));
      piecePrice = priceUnit === "PIECE" && l.unit_price != null ? moneyOf(dec(l.unit_price)) : defPieceIqd;
    } else {
      piecePrice = moneyOf(l.unit_price ?? defPieceIqd);
    }'''
new3 = '''    // price resolution (§18/§19): كرتون وحبات معًا بسعرين مستقلين.
    // الأولوية: package_price/piece_price الصريحان → unit_price حسب أساسه → الافتراضي.
    const priceUnit = l.price_unit ?? (l.unit === "PACKAGE" ? "PACKAGE" : "PIECE");
    let piecePrice: Decimal, packagePrice: Decimal | null = null;
    if (info.hasPack && packageQty.isPositive()) {
      packagePrice = l.package_price != null
        ? moneyOf(dec(l.package_price))
        : priceUnit === "PACKAGE"
          ? moneyOf(l.unit_price ?? defPackIqd ?? moneyOf(moneyOf(info.packQty).mul(defPieceIqd)))
          : moneyOf(defPackIqd ?? moneyOf(moneyOf(info.packQty).mul(l.unit_price ?? defPieceIqd)));
      piecePrice = l.piece_price != null
        ? moneyOf(dec(l.piece_price))
        : priceUnit === "PIECE" && l.unit_price != null
          ? moneyOf(dec(l.unit_price))
          : defPieceIqd;
    } else {
      piecePrice = l.piece_price != null
        ? moneyOf(dec(l.piece_price))
        : moneyOf(l.unit_price ?? defPieceIqd);
    }'''
assert src.count(old3) == 1, f"anchor3 = {src.count(old3)}"
src = src.replace(old3, new3)

open(P, "w", encoding="utf-8").write(src)
print("sales-service.ts ✓ (3 تعديلات)")
