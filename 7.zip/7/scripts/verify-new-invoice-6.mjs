// تحقق واجهة شاشة الفاتورة الجديدة — التعديلات الستة (2026-09-18)
import { chromium } from "playwright";

const BASE = "http://localhost:3000";
let pass = 0, fail = 0;
const ok = (name, cond) => { if (cond) { pass++; console.log(`  ✔ ${name}`); } else { fail++; console.log(`  ✘ ${name}`); } };

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

try {
  // دخول
  await page.goto(BASE, { waitUntil: "networkidle" });
  await page.fill("input[name=username], #username, input[type=text]", "admin");
  await page.fill("input[type=password]", "Admin@123");
  await page.click("button[type=submit]");
  await page.waitForTimeout(2500);

  // فتح تبويب فاتورة جديدة
  await page.click("text=فاتورة جديدة").catch(async () => { await page.click("text=بيع").catch(() => {}); });
  await page.waitForTimeout(1500);

  // 1) بحث العميل: حقل نصي قابل للكتابة (وليس select)
  const custSearch = page.locator('input[placeholder*="اكتب اسم العميل"]').first();
  ok("1) بحث العميل — حقل بحث نصي موجود", await custSearch.count() > 0);
  await custSearch.click();
  await custSearch.fill("متجر");
  await page.waitForTimeout(400);
  const custOptions = page.locator("div.z-50 button");
  ok("1) بحث العميل — قائمة نتائج مصفّاة", await custOptions.count() > 0);
  await page.keyboard.press("Escape");

  // 2+3) المنتج: بحث + قائمة وحدة داخل الخانة
  const prodSearch = page.locator('input[placeholder*="اكتب اسم المنتج"]').first();
  ok("2) بحث المنتج — حقل بحث نصي موجود", await prodSearch.count() > 0);

  // ابحث عن منتج معبأ عبر API ثم اختره من القائمة
  const token = await page.evaluate(async () => {
    const r = await fetch("/api/v1/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: "admin", password: "Admin@123" }) });
    const j = await r.json();
    return j.data.access_token;
  });
  const prods = await page.evaluate(async (t) => {
    const r = await fetch("/api/v1/products?per_page=100", { headers: { Authorization: `Bearer ${t}` } });
    const j = await r.json();
    return (j.data ?? []).map((p) => ({ id: p.id, name: p.name, pack: p.pack_qty, unit: p.unit, stock: p.stock_total }));
  }, token);
  const packed = prods.find((p) => p.pack && Number(p.pack) > 1) ?? prods[0];
  console.log(`   · منتج الاختبار: ${packed.name} (pack=${packed.pack}, unit=${packed.unit}, stock=${packed.stock})`);

  await prodSearch.click();
  await prodSearch.fill(packed.name.slice(0, 4));
  await page.waitForTimeout(400);
  await page.locator("div.z-50 button").first().dispatchEvent("mousedown");
  await page.waitForTimeout(800);

  const unitSelect = page.locator("table select[title*='وحدة الكمية']").first();
  ok("2) قائمة وحدة الكمية داخل الخانة (للمعبأ)", await unitSelect.count() > 0);
  if (await unitSelect.count()) {
    const opts = await unitSelect.locator("option").allTextContents();
    ok(`2) خيارا الحبة والعبوة في القائمة (${opts.join(" / ")})`, opts.length === 2);
  }

  // كتلة المعلومات: التحويل والأسعار
  const cellText = await page.locator("table tbody tr").first().locator("td").first().innerText();
  ok("3) كتلة المعلومات تعرض التحويل (1 كرتونة = N)", /التحويل:/.test(cellText));
  ok("3) كتلة المعلومات تعرض سعر الحبة والكرتونة", /سعر/.test(cellText) && /التعبئة/.test(cellText));
  ok("3) صياغة المتاح بلا ازدواج الرقم (لا «2 حبتين»)", !/2 حبتين/.test(cellText));

  // 4) ملاحظات الفاتورة ظاهرة
  const notes = page.locator("textarea[placeholder*='التسليم']").first();
  ok("4) حقل ملاحظات الفاتورة ظاهر", await notes.count() > 0);
  await notes.fill("ملاحظة تحقق آلي — تسليم الخميس");

  // 5) مربع الصرف رغم النقص
  const negBox = page.locator("text=السماح بالصرف رغم نقص المخزون").first();
  ok("5) مربع «الصرف رغم نقص المخزون» موجود", await negBox.count() > 0);

  // 6) زرا الطباعة والإلغاء قبل الترحيل
  ok("6) زر «طباعة مسودة» موجود", await page.locator("button:has-text('طباعة مسودة')").count() > 0);
  ok("6) زر «إلغاء الفاتورة» موجود", await page.locator("button:has-text('إلغاء الفاتورة')").count() > 0);

  // زر ترحيل ما زال موجودًا
  ok("زر ترحيل الفاتورة سليم", await page.locator("button:has-text('ترحيل الفاتورة')").count() > 0);

  // لقطة
  await page.screenshot({ path: "download/verify-new-invoice-6.png", fullPage: false });
  console.log("   · لقطة: download/verify-new-invoice-6.png");
} catch (e) {
  fail++;
  console.log("  ✘ استثناء:", e.message?.slice(0, 200));
} finally {
  await browser.close();
}
console.log(`\n=== النتيجة: ${pass} ✓ · ${fail} ✘ ===`);
process.exit(fail ? 1 : 0);
