#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ERD renderer — dbdiagram.io-style entity relationship diagrams.
Renders domain ERDs as PNG via Playwright (Chromium), crow's foot notation.
"""
import os
from playwright.sync_api import sync_playwright

OUT_DIR = "/home/z/my-project/assets/erd"
os.makedirs(OUT_DIR, exist_ok=True)

# Brand palette (matches document design): navy + orange accent
NAVY = "#1E293B"
ORANGE = "#EA580C"
LINE = "#94A3B8"
TYPE_C = "#64748B"
BORDER = "#CBD5E1"

CARD_W = 250
COL_PITCH = 350
ROW_PITCH = 300
MARGIN = 40


def entity_html(e):
    """Build one entity card HTML. e: {name, x, y, w?, fields: [(badge, name, type)]}"""
    w = e.get("w", CARD_W)
    rows = []
    for badge, name, ftype in e["fields"]:
        b = ""
        if badge:
            color = ORANGE if badge == "PK" else ("#0F766E" if badge == "UQ" else "#475569")
            bg = "#FFEDD5" if badge == "PK" else ("#CCFBF1" if badge == "UQ" else "#E2E8F0")
            b = f'<span class="badge" style="color:{color};background:{bg}">{badge}</span>'
        rows.append(
            f'<div class="row"><div class="fname">{b}<span>{name}</span></div>'
            f'<div class="ftype">{ftype}</div></div>'
        )
    return (
        f'<div class="entity" id="{e["name"]}" style="left:{e["x"]}px;top:{e["y"]}px;width:{w}px">'
        f'<div class="ehead">{e["name"]}</div>{"".join(rows)}</div>'
    )


def _marker(x, y, dx, dy, many):
    """Crow's foot (many=True) or single tick (one) marker at endpoint (x,y),
    with (dx,dy) = unit vector pointing OUT of the card."""
    px, py = -dy, dx  # perpendicular
    if many:
        p1 = (x - dx * 12 + px * 7, y - dy * 12 + py * 7)
        p2 = (x - dx * 12 - px * 7, y - dy * 12 - py * 7)
        c = (x - dx * 12, y - dy * 12)
        return (
            f'<line x1="{x}" y1="{y}" x2="{p1[0]:.1f}" y2="{p1[1]:.1f}"/>'
            f'<line x1="{x}" y1="{y}" x2="{p2[0]:.1f}" y2="{p2[1]:.1f}"/>'
            f'<line x1="{x}" y1="{y}" x2="{c[0]:.1f}" y2="{c[1]:.1f}"/>'
        )
    else:
        p1 = (x + dx * 2 + px * 6, y + dy * 2 + py * 6)
        p2 = (x + dx * 2 - px * 6, y + dy * 2 - py * 6)
        return f'<line x1="{p1[0]:.1f}" y1="{p1[1]:.1f}" x2="{p2[0]:.1f}" y2="{p2[1]:.1f}"/>'


def _label(x, y, dx, dy, text):
    lx, ly = x + dx * 16 - dy * 11, y + dy * 16 - dx * 11
    return f'<text class="card" x="{lx:.1f}" y="{ly:.1f}">{text}</text>'


def edge_svg(entities, edge):
    """Build SVG for one relationship.
    edge: {f, t, fm:'l|r|t|b', tm:..., midX?, midY?, card_f:'1|N', card_t:'1|N', dash?:True}
    fm/tm = side of the FROM/TO card the wire attaches to.
    card_f/card_t = cardinality displayed at FROM/TO end."""
    fe, te = entities[edge["f"]], entities[edge["t"]]
    w_f, w_t = fe.get("w", CARD_W), te.get("w", CARD_W)
    h_f, h_t = fe.get("_h"), te.get("_h")

    def anchor(e, w, h, side):
        x, y = e["x"], e["y"]
        if side == "l":
            return x, y + h / 2, -1, 0
        if side == "r":
            return x + w, y + h / 2, 1, 0
        if side == "t":
            return x + w / 2, y, 0, -1
        return x + w / 2, y + h, 0, 1

    x1, y1, d1x, d1y = anchor(fe, w_f, h_f, edge.get("fm", "r"))
    x2, y2, d2x, d2y = anchor(te, w_t, h_t, edge.get("tm", "l"))
    dash = ' stroke-dasharray="6,4"' if edge.get("dash") else ""

    horizontal = edge.get("fm", "r") in ("l", "r") and edge.get("tm", "l") in ("l", "r")
    if horizontal:
        if abs(y1 - y2) < 2:
            seg = f"M {x1} {y1} L {x2} {y2}"
        else:
            mid = edge.get("midX", (x1 + x2) / 2)
            seg = f"M {x1} {y1} L {mid} {y1} L {mid} {y2} L {x2} {y2}"
    else:
        if abs(x1 - x2) < 2:
            seg = f"M {x1} {y1} L {x2} {y2}"
        else:
            mid = edge.get("midY", (y1 + y2) / 2)
            seg = f"M {x1} {y1} L {x1} {mid} L {x2} {mid} L {x2} {y2}"

    d1, d2 = (d1x, d1y), (d2x, d2y)
    if horizontal and abs(y1 - y2) >= 2:
        d1 = (1 if x2 > x1 else -1, 0)
        d2 = (-1 if x2 > x1 else 1, 0)
    if not horizontal and abs(x1 - x2) >= 2:
        d1 = (0, 1 if y2 > y1 else -1)
        d2 = (0, -1 if y2 > y1 else 1)

    parts = [f'<path d="{seg}" fill="none"{dash}/>']
    parts.append(_marker(x1, y1, d1[0], d1[1], edge.get("card_f", "1") == "N"))
    parts.append(_marker(x2, y2, d2[0], d2[1], edge.get("card_t", "N") == "N"))
    parts.append(_label(x1, y1, d1[0], d1[1], edge.get("card_f", "1")))
    parts.append(_label(x2, y2, d2[0], d2[1], edge.get("card_t", "N")))
    return "".join(parts)


def render_diagram(title, subtitle, entities, edges, out_name, note=None):
    """entities: ordered dict name -> {name,x,y,w?,fields}; edges: list of dicts."""
    ents = {}
    for k, e in entities.items():
        ee = dict(e)
        ee["_h"] = 36 + len(e["fields"]) * 24 + 6
        ents[k] = ee
    max_x = max(e["x"] + e.get("w", CARD_W) for e in ents.values())
    max_y = max(e["y"] + e["_h"] for e in ents.values())
    W, H = max_x + MARGIN, max_y + MARGIN + (56 if note else 30)

    svg_edges = "".join(edge_svg(ents, ed) for ed in edges)
    cards = "".join(entity_html(e) for e in ents.values())
    note_html = f'<div class="note">{note}</div>' if note else ""

    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    * {{ margin:0; padding:0; box-sizing:border-box; }}
    body {{ background:#FFFFFF; font-family:'DejaVu Sans','FreeSans',sans-serif; }}
    .wrap {{ position:relative; width:{W}px; height:{H}px; background:#FFFFFF; }}
    .title {{ position:absolute; left:8px; top:10px; font-size:17px; font-weight:700; color:{NAVY}; }}
    .subtitle {{ position:absolute; left:8px; top:34px; font-size:12px; color:{TYPE_C}; }}
    .legend {{ position:absolute; right:10px; top:12px; font-size:10.5px; color:{TYPE_C}; }}
    svg.wires {{ position:absolute; left:0; top:0; z-index:0; }}
    svg.wires path {{ stroke:{LINE}; stroke-width:1.6; }}
    svg.wires line {{ stroke:{LINE}; stroke-width:1.6; }}
    svg.wires text {{ font-size:10px; fill:{TYPE_C}; font-weight:600;
      font-family:'DejaVu Sans',sans-serif; }}
    .entity {{ position:absolute; z-index:1; background:#FFFFFF; border:1px solid {BORDER};
      border-radius:7px; overflow:hidden; box-shadow:0 1px 4px rgba(15,23,42,.10); }}
    .ehead {{ background:{NAVY}; color:#FFFFFF; font-size:13px; font-weight:700;
      padding:7px 10px 6px; font-family:'DejaVu Sans Mono',monospace; letter-spacing:.2px; }}
    .row {{ display:flex; justify-content:space-between; align-items:center;
      padding:3px 9px; border-top:1px solid #F1F5F9; min-height:24px; }}
    .fname {{ font-size:11.5px; color:#1F2937; font-family:'DejaVu Sans Mono',monospace;
      display:flex; align-items:center; gap:5px; }}
    .ftype {{ font-size:10px; color:{TYPE_C}; font-family:'DejaVu Sans Mono',monospace; }}
    .badge {{ font-size:8.5px; font-weight:800; border-radius:3px; padding:1px 4px;
      font-family:'DejaVu Sans',sans-serif; }}
    .note {{ position:absolute; left:8px; bottom:8px; font-size:11px; color:{TYPE_C};
      max-width:{W - 60}px; }}
    </style></head><body><div class="wrap">
    <div class="title">{title}</div>
    <div class="legend">PK = Primary Key &nbsp;|&nbsp; FK = Foreign Key &nbsp;|&nbsp; UQ = Unique</div>
    <div class="subtitle">{subtitle}</div>
    <svg class="wires" width="{W}" height="{H}">{svg_edges}</svg>
    {cards}{note_html}
    </div></body></html>"""

    tmp = os.path.join(OUT_DIR, out_name + ".html")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(html)
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": W, "height": H}, device_scale_factor=2)
        pg.goto("file://" + tmp)
        pg.wait_for_timeout(250)
        pg.screenshot(path=os.path.join(OUT_DIR, out_name + ".png"),
                      clip={"x": 0, "y": 0, "width": W, "height": H})
        b.close()
    print(f"OK {out_name}.png  ({W}x{H})")
