#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Render all ERD diagrams + state machines."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from erd_render import render_diagram
from erd_domains_a import (d1_core, d2_products, d3_parties, d4_stock, d5_movements,
                           d6a_sales_pipeline, d6b_sales_invoicing)
from erd_domains_b import (d7_payments, d8_purchasing, d9_finance, d10_field_sales,
                           d11_system, d0_overview)

STATE_CHIP = """<!DOCTYPE html><html><head><meta charset="utf-8"><style>
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{ font-family:'DejaVu Sans',sans-serif; background:#FFFFFF; }}
.wrap {{ padding:22px 20px; width:{W}px; }}
.title {{ font-size:17px; font-weight:800; color:#1E293B; margin-bottom:3px; }}
.subtitle {{ font-size:11.5px; color:#64748B; margin-bottom:16px; }}
.row {{ display:flex; align-items:center; flex-wrap:wrap; gap:0; margin-bottom:10px; }}
.chip {{ font-size:11.5px; font-weight:700; padding:7px 13px; border-radius:20px;
  border:1.6px solid #1E293B; background:#F8FAFC; color:#1E293B; white-space:nowrap; }}
.chip.term {{ border-color:#9A3412; background:#FFEDD5; color:#9A3412; }}
.chip.ok {{ border-color:#15803D; background:#F0FDF4; color:#15803D; }}
.arrow {{ font-size:14px; color:#94A3B8; margin:0 7px; font-weight:700; }}
.lbl {{ font-size:10px; color:#64748B; margin:0 7px 0 3px; font-style:italic; }}
.note {{ font-size:11px; color:#64748B; margin-top:8px; line-height:1.6; }}
</style></head><body><div class="wrap">
<div class="title">{title}</div><div class="subtitle">{subtitle}</div>
{rows}
<div class="note">{note}</div>
</div></body></html>"""


def render_state(out_name, title, subtitle, rows_html, note, W=1180):
    html = STATE_CHIP.format(W=W, title=title, subtitle=subtitle, rows=rows_html, note=note)
    out = f"/home/z/my-project/assets/erd/{out_name}.html"
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": W, "height": 500}, device_scale_factor=2)
        pg.goto("file://" + out)
        pg.wait_for_timeout(200)
        pg.screenshot(path=f"/home/z/my-project/assets/erd/{out_name}.png", full_page=True)
        b.close()
    print(f"OK {out_name}.png")


def chain(*steps):
    """steps: (text, cls) tuples; cls '' | 'term' | 'ok'. Label after arrow optional 3rd."""
    parts = []
    for i, s in enumerate(steps):
        if isinstance(s, tuple):
            text = s[0]
            cls = s[1] if len(s) > 1 else ""
            lbl = s[2] if len(s) > 2 else ""
        else:
            text, cls, lbl = s, "", ""
        if i > 0:
            parts.append('<span class="arrow">&#8594;</span>')
            if lbl:
                parts.append(f'<span class="lbl">{lbl}</span>')
        parts.append(f'<span class="chip {cls}">{text}</span>')
    return '<div class="row">' + "".join(parts) + "</div>"


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "all"

    if which in ("all", "one"):
        render_diagram(*d1_core()[:4], note=d1_core()[4]) if False else None
    jobs = [d1_core, d2_products, d3_parties, d4_stock, d5_movements,
            d6a_sales_pipeline, d6b_sales_invoicing,
            d7_payments, d8_purchasing, d9_finance, d10_field_sales, d11_system]
    if which in ("all", "domains"):
        for j in jobs:
            name, sub, E, ED, note = j()
            render_diagram("PostgreSQL ERD — " + sub.split("—")[-1].strip(),
                           sub, E, ED, name, note)
        d0_overview()

    if which in ("all", "states"):
        render_state("state_invoice", "Invoice State Machine",
            "Status transitions enforced server-side; POSTED invoices are immutable.",
            chain(("DRAFT", ""), ("PENDING_APPROVAL", "", "when approval rule matches (discount &gt; 10%, credit limit)"),
                  ("APPROVED", ""), ("POSTED", "ok"), ("PARTIALLY_PAID", ""), ("PAID", "ok")) +
            chain(("POSTED", "ok", "auto-flag when past due date"), ("OVERDUE", "term")) +
            chain(("POSTED", "ok"), ("CANCELLED", "term"), "creates reverse stock + ledger entries"),
            "Rules: DRAFT editable; PENDING_APPROVAL requires approval_rule match; never delete — correction via CANCELLED/Credit Note/Return with reverse effect.")

        render_state("state_transfer", "Transfer State Machine",
            "Rep warehouse replenishment flow with optional TRANSIT warehouse.",
            chain(("DRAFT", ""), ("REQUESTED", ""), ("APPROVED", ""), ("ISSUED", "ok"),
                  ("IN_TRANSIT", ""), ("RECEIVED", "ok"), ("CANCELLED", "term")),
            "Stock effect: ISSUED = source -qty (TRANSFER_OUT); RECEIVED = destination +qty (TRANSFER_IN). Re-entry into RECEIVED is blocked by status guard — no double receipt.")

        render_state("return_sales", "Sales Return State Machine",
            "Returned goods condition decides the destination warehouse.",
            chain(("REQUESTED", ""), ("APPROVED", ""), ("RECEIVED", ""), ("INSPECTED", ""),
                  ("POSTED", "ok"), ("REJECTED", "term")),
            "Inspection marks items GOOD / DAMAGED / QUARANTINE: GOOD returns to selling warehouse (SALE_RETURN), DAMAGED to DAMAGED warehouse, QUARANTINE held aside. Ledger: decreases customer receivable.")
