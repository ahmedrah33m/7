#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Trim uniform white margins from ERD PNGs (keep ~24px padding)."""
from PIL import Image, ImageChops
import glob, os

PADDING = 26

def trim(path):
    im = Image.open(path).convert("RGB")
    bg = Image.new("RGB", im.size, (255, 255, 255))
    diff = ImageChops.difference(im, bg)
    bbox = diff.getbbox()
    if not bbox:
        return
    l, t, r, b = bbox
    l = max(0, l - PADDING); t = max(0, t - PADDING)
    r = min(im.width, r + PADDING); b = min(im.height, b + PADDING)
    im.crop((l, t, r, b)).save(path)
    print(f"trimmed {os.path.basename(path)} -> {r-l}x{b-t}")

if __name__ == "__main__":
    for p in sorted(glob.glob("/home/z/my-project/assets/erd/*.png")):
        trim(p)
