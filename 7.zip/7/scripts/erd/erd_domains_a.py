#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ERD domain definitions A: Core, Products, Customers, Stock, Movements, Sales."""

# Common field shorthand: (badge, name, type) — badge in {PK, FK, UQ, ""}


def d1_core():
    E = {
        "companies": {"name": "companies", "x": 40, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "uuid", "UUID"), ("", "name", "VARCHAR(200)"),
            ("", "name_en", "VARCHAR(200)"), ("", "currency_code", "CHAR(3)"),
            ("", "is_active", "BOOLEAN")]},
        "branches": {"name": "branches", "x": 390, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("", "code", "VARCHAR(30)"),
            ("", "name", "VARCHAR(150)"), ("", "city", "VARCHAR(80)"), ("", "is_active", "BOOLEAN")]},
        "warehouses": {"name": "warehouses", "x": 740, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("FK", "branch_id", "BIGINT"),
            ("", "code", "VARCHAR(30)"), ("", "type", "ENUM 5 values"), ("", "is_mobile", "BOOLEAN"),
            ("FK", "manager_id", "BIGINT")]},
        "users": {"name": "users", "x": 390, "y": 400, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("FK", "branch_id", "BIGINT"),
            ("UQ", "username", "VARCHAR(80)"), ("", "password_hash", "VARCHAR(255)"),
            ("", "is_active", "BOOLEAN"), ("", "locked_until", "TIMESTAMPTZ")]},
        "roles": {"name": "roles", "x": 40, "y": 430, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("UQ", "code", "VARCHAR(50)"),
            ("", "name", "VARCHAR(100)"), ("", "is_system", "BOOLEAN")]},
        "permissions": {"name": "permissions", "x": 40, "y": 700, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "code", "VARCHAR(80)"), ("", "module", "VARCHAR(50)"),
            ("", "action", "VARCHAR(30)")]},
        "role_permissions": {"name": "role_permissions", "x": 390, "y": 680, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "role_id", "BIGINT"), ("FK", "permission_id", "BIGINT")]},
        "user_roles": {"name": "user_roles", "x": 740, "y": 430, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "user_id", "BIGINT"), ("FK", "role_id", "BIGINT"),
            ("FK", "branch_id", "BIGINT NULL")]},
        "user_warehouse_access": {"name": "user_warehouse_access", "x": 740, "y": 620, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "user_id", "BIGINT"), ("FK", "warehouse_id", "BIGINT")]},
        "user_devices": {"name": "user_devices", "x": 740, "y": 790, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "user_id", "BIGINT"), ("", "device_id", "VARCHAR(120)"),
            ("", "platform", "VARCHAR(30)"), ("", "push_token", "TEXT NULL")]},
    }
    EDGES = [
        {"f": "companies", "t": "branches", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "branches", "t": "warehouses", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "companies", "t": "users", "fm": "b", "tm": "t", "midY": 370, "card_f": "1", "card_t": "N"},
        {"f": "branches", "t": "users", "fm": "b", "tm": "t", "midY": 350, "dash": True, "card_f": "1", "card_t": "N"},
        {"f": "companies", "t": "roles", "fm": "b", "tm": "t", "midY": 380, "card_f": "1", "card_t": "N"},
        {"f": "roles", "t": "role_permissions", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "permissions", "t": "role_permissions", "fm": "r", "tm": "b", "card_f": "1", "card_t": "N"},
        {"f": "users", "t": "user_roles", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "users", "t": "user_warehouse_access", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "users", "t": "user_devices", "fm": "b", "tm": "l", "card_f": "1", "card_t": "N"},
    ]
    return "erd_01_core", "Domain 1 — Core Organization & Security (RBAC)", E, EDGES, \
        "All tenant-scoped tables carry company_id. warehouses.type = MAIN | BRANCH | REP | TRANSIT | DAMAGED."


def d2_products():
    E = {
        "categories": {"name": "categories", "x": 40, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("FK", "parent_id", "BIGINT NULL"),
            ("", "name", "VARCHAR(150)"), ("", "level", "SMALLINT")]},
        "brands": {"name": "brands", "x": 40, "y": 330, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("", "code", "VARCHAR(30)"),
            ("", "name", "VARCHAR(150)")]},
        "units": {"name": "units", "x": 40, "y": 500, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("", "code", "VARCHAR(20)"),
            ("", "name", "VARCHAR(50)"), ("", "type", "ENUM 4 values")]},
        "unit_conversions": {"name": "unit_conversions", "x": 40, "y": 740, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "from_unit_id", "BIGINT"), ("FK", "to_unit_id", "BIGINT"),
            ("", "factor", "NUMERIC(18,6)")]},
        "products": {"name": "products", "x": 440, "y": 120, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "uuid", "UUID"), ("UQ", "sku", "VARCHAR(60)"),
            ("FK", "category_id", "BIGINT"), ("FK", "brand_id", "BIGINT"),
            ("FK", "base_unit_id", "BIGINT"), ("", "name_ar / name_en", "VARCHAR(200)"),
            ("", "cost_price", "NUMERIC(18,4)"), ("", "default_sale_price", "NUMERIC(18,4)"),
            ("", "tax_rate", "NUMERIC(5,2)"), ("", "is_batch_tracked", "BOOLEAN")]},
        "product_barcodes": {"name": "product_barcodes", "x": 840, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "product_id", "BIGINT"), ("UQ", "barcode", "VARCHAR(80)"),
            ("FK", "unit_id", "BIGINT"), ("", "is_primary", "BOOLEAN")]},
        "product_suppliers": {"name": "product_suppliers", "x": 840, "y": 280, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "product_id", "BIGINT"), ("FK", "supplier_id", "BIGINT"),
            ("", "purchase_price", "NUMERIC(18,4)"), ("", "is_preferred", "BOOLEAN")]},
        "price_lists": {"name": "price_lists", "x": 840, "y": 500, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("", "code", "VARCHAR(30)"),
            ("", "priority", "SMALLINT"), ("", "valid_from / valid_to", "DATE NULL")]},
        "price_list_items": {"name": "price_list_items", "x": 440, "y": 560, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "price_list_id", "BIGINT"), ("FK", "product_id", "BIGINT"),
            ("FK", "unit_id", "BIGINT"), ("", "price", "NUMERIC(18,4)"),
            ("", "min_quantity", "NUMERIC(18,4)")]},
        "customer_product_prices": {"name": "customer_product_prices", "x": 440, "y": 810, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "customer_id", "BIGINT"), ("FK", "product_id", "BIGINT"),
            ("FK", "unit_id", "BIGINT"), ("", "price", "NUMERIC(18,4)")]},
    }
    EDGES = [
        {"f": "categories", "t": "products", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "brands", "t": "products", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "units", "t": "products", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "categories", "t": "categories", "fm": "r", "tm": "t", "dash": True,
         "card_f": "1", "card_t": "N", "midY": 30},
        {"f": "products", "t": "product_barcodes", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "products", "t": "product_suppliers", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "price_lists", "t": "price_list_items", "fm": "b", "tm": "r", "card_f": "1", "card_t": "N"},
        {"f": "products", "t": "price_list_items", "fm": "b", "tm": "t", "midY": 520, "card_f": "1", "card_t": "N"},
        {"f": "products", "t": "customer_product_prices", "fm": "b", "tm": "t", "card_f": "1", "card_t": "N"},
        {"f": "units", "t": "unit_conversions", "fm": "b", "tm": "t", "card_f": "1", "card_t": "N"},
    ]
    return "erd_02_products", "Domain 2 — Products, Categories, Units & Pricing", E, EDGES, \
        "categories.parent_id = self reference (tree). Price priority: customer_product_prices > customer_group price > price_list_items > products.default_sale_price."


def d3_parties():
    E = {
        "customer_groups": {"name": "customer_groups", "x": 40, "y": 90, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("", "code", "VARCHAR(30)"),
            ("", "name", "VARCHAR(120)"), ("FK", "price_list_id", "BIGINT NULL")]},
        "customers": {"name": "customers", "x": 440, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "uuid", "UUID"), ("UQ", "code", "VARCHAR(40)"),
            ("FK", "customer_group_id", "BIGINT"), ("FK", "sales_rep_id", "BIGINT NULL"),
            ("FK", "price_list_id", "BIGINT NULL"), ("", "phone / whatsapp", "VARCHAR(30)"),
            ("", "credit_limit", "NUMERIC(18,4)"), ("", "payment_term_days", "SMALLINT"),
            ("", "opening_balance", "NUMERIC(18,4)"), ("", "latitude / longitude", "DECIMAL(10,7)")]},
        "customer_contacts": {"name": "customer_contacts", "x": 840, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "customer_id", "BIGINT"), ("", "name", "VARCHAR(150)"),
            ("", "phone", "VARCHAR(30)"), ("", "is_primary", "BOOLEAN")]},
        "customer_addresses": {"name": "customer_addresses", "x": 840, "y": 300, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "customer_id", "BIGINT"), ("", "label", "VARCHAR(60)"),
            ("", "address", "TEXT"), ("", "latitude / longitude", "DECIMAL(10,7)")]},
        "suppliers": {"name": "suppliers", "x": 440, "y": 430, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "uuid", "UUID"), ("UQ", "code", "VARCHAR(40)"),
            ("", "name / company_name", "VARCHAR(200)"), ("", "phone", "VARCHAR(30)"),
            ("", "tax_number", "VARCHAR(60)"), ("", "payment_terms", "SMALLINT"),
            ("", "opening_balance", "NUMERIC(18,4)")]},
        "sales_reps": {"name": "sales_reps", "x": 40, "y": 480, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("UQ", "user_id", "BIGINT"),
            ("FK", "warehouse_id", "BIGINT"), ("", "employee_code", "VARCHAR(40)")]},
    }
    EDGES = [
        {"f": "customer_groups", "t": "customers", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "customers", "t": "customer_contacts", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "customers", "t": "customer_addresses", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "sales_reps", "t": "customers", "fm": "r", "tm": "b", "dash": True, "card_f": "1", "card_t": "N"},
    ]
    return "erd_03_parties", "Domain 3 — Customers, Contacts, Addresses & Suppliers", E, EDGES, \
        "sales_reps belongs to Field Sales domain; shown here for its 1:N link to customers (each rep sees only own customers)."


def d4_stock():
    E = {
        "products": {"name": "products (D2)", "x": 40, "y": 200, "w": 200, "fields": [
            ("PK", "id", "BIGINT"), ("", "sku", "VARCHAR(60)"),
            ("", "is_batch_tracked", "BOOLEAN"), ("", "is_serialized", "BOOLEAN")]},
        "warehouses": {"name": "warehouses (D1)", "x": 40, "y": 470, "w": 200, "fields": [
            ("PK", "id", "BIGINT"), ("", "code", "VARCHAR(30)"), ("", "type", "ENUM 5 values")]},
        "stock_balances": {"name": "stock_balances", "x": 340, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "product_id", "BIGINT"), ("FK", "warehouse_id", "BIGINT"),
            ("", "quantity_on_hand", "NUMERIC(18,4)"), ("", "quantity_reserved", "NUMERIC(18,4)"),
            ("", "quantity_available", "GENERATED"), ("", "avg_cost", "NUMERIC(18,4)")]},
        "stock_transactions": {"name": "stock_transactions", "x": 340, "y": 340, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "product_id", "BIGINT"), ("FK", "warehouse_id", "BIGINT"),
            ("", "transaction_type", "ENUM 10 values"), ("", "quantity / quantity_base", "NUMERIC(18,4)"),
            ("FK", "unit_id", "BIGINT"), ("", "reference_type + id", "VARCHAR + BIGINT"),
            ("FK", "batch_id", "BIGINT NULL"), ("", "unit_cost", "NUMERIC(18,4)")]},
        "batches": {"name": "batches", "x": 760, "y": 130, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "product_id", "BIGINT"), ("", "batch_number", "VARCHAR(60)"),
            ("", "expiry_date", "DATE NULL"), ("", "quantity", "NUMERIC(18,4)")]},
        "serials": {"name": "serials", "x": 760, "y": 380, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "product_id", "BIGINT"), ("UQ", "serial_number", "VARCHAR(80)"),
            ("", "status", "ENUM 4 values"), ("FK", "warehouse_id", "BIGINT")]},
    }
    EDGES = [
        {"f": "products", "t": "stock_balances", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "products", "t": "stock_transactions", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "warehouses", "t": "stock_balances", "fm": "r", "tm": "b", "card_f": "1", "card_t": "N"},
        {"f": "warehouses", "t": "stock_transactions", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "batches", "t": "stock_transactions", "fm": "l", "tm": "r", "dash": True, "card_f": "1", "card_t": "N"},
        {"f": "serials", "t": "stock_transactions", "fm": "b", "tm": "t", "dash": True, "card_f": "1", "card_t": "N"},
    ]
    return "erd_04_stock", "Domain 4 — Stock Ledger & Balances (Append-only Ledger)", E, EDGES, \
        "transaction_type = PURCHASE_RECEIPT | SALE | SALE_RETURN | PURCHASE_RETURN | TRANSFER_OUT | TRANSFER_IN | ADJUSTMENT_IN | ADJUSTMENT_OUT | DAMAGE | OPENING. Ledger rows are immutable — corrections use reversal + new entry. UNIQUE(product_id, warehouse_id) on stock_balances."


def d5_movements():
    def master(name, x, y, extra, status):
        return {"name": name, "x": x, "y": y, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "uuid", "UUID"), ("", f"{name[:-1] if name.endswith('s') else name}_number", "VARCHAR(30)"),
            ("FK", "warehouse_id", "BIGINT"), ("", "status", status)] + extra}

    E = {
        "transfers": master("transfers", 40, 60, [
            ("FK", "from_warehouse_id", "BIGINT"), ("FK", "to_warehouse_id", "BIGINT"),
            ("FK", "approved_by", "BIGINT NULL")],
            "DRAFT\u2192\u2026\u2192RECEIVED"),
        "transfer_items": {"name": "transfer_items", "x": 440, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "transfer_id", "BIGINT"), ("FK", "product_id", "BIGINT"),
            ("", "qty_requested", "NUMERIC(18,4)"), ("", "qty_issued", "NUMERIC(18,4)"),
            ("", "qty_received", "NUMERIC(18,4)")]},
        "adjustments": master("adjustments", 40, 400, [
            ("", "adjustment_type", "IN | OUT"), ("", "reason", "TEXT"),
            ("FK", "approved_by", "BIGINT NULL")], "DRAFT\u2192\u2026\u2192POSTED"),
        "adjustment_items": {"name": "adjustment_items", "x": 440, "y": 400, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "adjustment_id", "BIGINT"), ("FK", "product_id", "BIGINT"),
            ("", "quantity", "NUMERIC(18,4)"), ("", "unit_cost", "NUMERIC(18,4)")]},
        "stocktakings": master("stocktakings", 840, 60, [
            ("", "start_date / end_date", "DATE"), ("FK", "counted_by", "BIGINT NULL")],
            "OPEN\u2192\u2026\u2192POSTED"),
        "stocktaking_items": {"name": "stocktaking_items", "x": 1200, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "stocktaking_id", "BIGINT"), ("FK", "product_id", "BIGINT"),
            ("", "system_qty", "NUMERIC(18,4)"), ("", "counted_qty", "NUMERIC(18,4)")]},
        "damages": master("damages", 840, 400, [
            ("", "reason", "TEXT"), ("FK", "approved_by", "BIGINT NULL")],
            "DRAFT\u2192\u2026\u2192POSTED"),
        "damage_items": {"name": "damage_items", "x": 1200, "y": 400, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "damage_id", "BIGINT"), ("FK", "product_id", "BIGINT"),
            ("", "quantity", "NUMERIC(18,4)"), ("", "condition", "ENUM 3 values")]},
    }
    EDGES = [
        {"f": "transfers", "t": "transfer_items", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "adjustments", "t": "adjustment_items", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "stocktakings", "t": "stocktaking_items", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "damages", "t": "damage_items", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
    ]
    return "erd_05_movements", "Domain 5 — Inventory Movements (Transfers, Adjustments, Stocktaking, Damages)", E, EDGES, \
        "Every POSTED movement writes stock_transactions with its own reference_type. Transfers: STOCK deduction at ISSUED, STOCK addition at RECEIVED (optional TRANSIT warehouse in between)."


def d6a_sales_pipeline():
    """Sales pipeline part A: quotations + sales orders (compact, portrait-safe)."""
    E = {
        "quotations": {"name": "quotations", "x": 40, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "uuid", "UUID"), ("UQ", "quotation_number", "VARCHAR(30)"),
            ("FK", "customer_id", "BIGINT"), ("FK", "warehouse_id", "BIGINT"),
            ("", "status", "ENUM 6 values"), ("", "valid_until", "DATE NULL"),
            ("FK", "converted_order_id", "BIGINT NULL")]},
        "quotation_items": {"name": "quotation_items", "x": 440, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "quotation_id", "BIGINT"), ("FK", "product_id", "BIGINT"),
            ("", "quantity", "NUMERIC(18,4)"), ("", "unit_price", "NUMERIC(18,4)"),
            ("", "line_total", "NUMERIC(18,4)")]},
        "sales_orders": {"name": "sales_orders", "x": 40, "y": 380, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "uuid", "UUID"), ("UQ", "order_number", "VARCHAR(30)"),
            ("FK", "customer_id", "BIGINT"), ("FK", "warehouse_id", "BIGINT"),
            ("FK", "sales_rep_id", "BIGINT NULL"), ("FK", "quotation_id", "BIGINT NULL"),
            ("", "status", "ENUM 7 values"), ("", "total", "NUMERIC(18,4)"),
            ("UQ", "client_transaction_id", "UUID NULL")]},
        "sales_order_items": {"name": "sales_order_items", "x": 440, "y": 400, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "order_id", "BIGINT"), ("FK", "product_id", "BIGINT"),
            ("", "quantity", "NUMERIC(18,4)"), ("", "qty_fulfilled", "NUMERIC(18,4)"),
            ("", "unit_price / line_total", "NUMERIC(18,4)")]},
        "sales_leads": {"name": "sales_leads", "x": 40, "y": 750, "fields": [
            ("PK", "id", "BIGINT"), ("", "name / phone", "VARCHAR"),
            ("FK", "assigned_rep_id", "BIGINT NULL"), ("FK", "converted_customer_id", "BIGINT NULL"),
            ("", "status", "ENUM 5 values")]},
    }
    EDGES = [
        {"f": "quotations", "t": "quotation_items", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "quotations", "t": "sales_orders", "fm": "b", "tm": "t", "dash": True, "card_f": "1", "card_t": "1"},
        {"f": "sales_orders", "t": "sales_order_items", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
    ]
    return "erd_06a_pipeline", "Sales Pipeline (A) — Quotations, Sales Orders, Leads", E, EDGES, \
        "CONVERTED quotation becomes its linked order (converted_order_id back-reference). Sales continue in diagram (B): orders feed deliveries and invoices."


def d6b_sales_invoicing():
    """Sales pipeline part B: deliveries + invoices + credit notes."""
    E = {
        "sales_orders": {"name": "sales_orders (A)", "x": 40, "y": 60, "w": 210, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "order_number", "VARCHAR(30)"),
            ("FK", "warehouse_id", "BIGINT"), ("", "status", "ENUM 7 values")]},
        "deliveries": {"name": "deliveries", "x": 350, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "delivery_number", "VARCHAR(30)"),
            ("FK", "order_id", "BIGINT"), ("FK", "warehouse_id", "BIGINT"),
            ("", "status", "ENUM 5 values"), ("", "driver / vehicle", "VARCHAR")]},
        "delivery_items": {"name": "delivery_items", "x": 350, "y": 330, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "delivery_id", "BIGINT"), ("FK", "order_item_id", "BIGINT"),
            ("", "quantity", "NUMERIC(18,4)"), ("", "quantity_rejected", "NUMERIC(18,4)")]},
        "invoices": {"name": "invoices", "x": 700, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "uuid", "UUID"), ("UQ", "invoice_number", "VARCHAR(30)"),
            ("FK", "customer_id", "BIGINT"), ("FK", "warehouse_id", "BIGINT"),
            ("FK", "order_id", "BIGINT NULL"), ("", "invoice_type", "SALES | POS"),
            ("", "status", "ENUM 9 values"), ("", "grand_total / paid_amount", "NUMERIC(18,4)"),
            ("UQ", "client_transaction_id", "UUID NULL")]},
        "invoice_items": {"name": "invoice_items", "x": 700, "y": 430, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "invoice_id", "BIGINT"), ("FK", "product_id", "BIGINT"),
            ("", "quantity / unit_price", "NUMERIC(18,4)"), ("", "tax_rate / tax_amount", "NUMERIC"),
            ("", "cost_price", "NUMERIC(18,4)")]},
        "credit_notes": {"name": "credit_notes", "x": 1060, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "note_number", "VARCHAR(30)"), ("FK", "customer_id", "BIGINT"),
            ("FK", "invoice_id", "BIGINT NULL"), ("", "affects_stock", "BOOLEAN"),
            ("", "amount", "NUMERIC(18,4)"), ("", "status", "ENUM 4 values")]},
    }
    EDGES = [
        {"f": "sales_orders", "t": "deliveries", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "deliveries", "t": "delivery_items", "fm": "b", "tm": "t", "card_f": "1", "card_t": "N"},
        {"f": "sales_orders", "t": "invoices", "fm": "t", "tm": "t", "dash": True, "card_f": "1", "card_t": "N", "midY": 30},
        {"f": "invoices", "t": "invoice_items", "fm": "b", "tm": "t", "card_f": "1", "card_t": "N"},
        {"f": "invoices", "t": "credit_notes", "fm": "r", "tm": "l", "dash": True, "card_f": "1", "card_t": "N"},
    ]
    return "erd_06b_invoicing", "Sales Pipeline (B) — Deliveries, Invoices, Credit Notes", E, EDGES, \
        "Invoice POST is atomic: invoice + items + stock_transactions + customer_ledger + commission snapshot. client_transaction_id enforces offline-sync idempotency (no double posting)."
