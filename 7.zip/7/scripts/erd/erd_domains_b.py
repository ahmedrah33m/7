#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ERD domain definitions B: Payments, Purchasing, Finance, Field Sales, System."""


def d7_payments():
    E = {
        "payments": {"name": "payments", "x": 40, "y": 80, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "uuid", "UUID"), ("UQ", "payment_number", "VARCHAR(30)"),
            ("FK", "customer_id", "BIGINT NULL"), ("FK", "supplier_id", "BIGINT NULL"),
            ("", "direction", "IN | OUT"), ("", "amount", "NUMERIC(18,4)"),
            ("", "payment_method", "ENUM 6 values"), ("FK", "cashbox_id", "BIGINT NULL"),
            ("FK", "bank_account_id", "BIGINT NULL"), ("UQ", "client_transaction_id", "UUID NULL")]},
        "payment_method_lines": {"name": "payment_method_lines", "x": 480, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "payment_id", "BIGINT"), ("", "method", "ENUM 6 values"),
            ("", "amount", "NUMERIC(18,4)"), ("FK", "cashbox_id", "BIGINT NULL")]},
        "payment_allocations": {"name": "payment_allocations", "x": 480, "y": 330, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "payment_id", "BIGINT"),
            ("", "target_type", "CUST_INV | SUPP_INV"), ("", "target_id", "BIGINT"),
            ("", "amount", "NUMERIC(18,4)")]},
        "customer_ledger": {"name": "customer_ledger", "x": 480, "y": 560, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "customer_id", "BIGINT"),
            ("", "entry_type", "ENUM 6 values"), ("", "debit / credit", "NUMERIC(18,4)"),
            ("", "balance_after", "NUMERIC(18,4)"), ("", "reference_type + id", "VARCHAR+BIGINT")]},
        "supplier_ledger": {"name": "supplier_ledger", "x": 480, "y": 830, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "supplier_id", "BIGINT"),
            ("", "entry_type", "ENUM 6 values"), ("", "debit / credit", "NUMERIC(18,4)"),
            ("", "balance_after", "NUMERIC(18,4)")]},
    }
    EDGES = [
        {"f": "payments", "t": "payment_method_lines", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "payments", "t": "payment_allocations", "fm": "b", "tm": "t", "card_f": "1", "card_t": "N"},
        {"f": "payments", "t": "customer_ledger", "fm": "r", "tm": "t", "dash": True, "card_f": "1", "card_t": "N"},
        {"f": "payments", "t": "supplier_ledger", "fm": "b", "tm": "t", "dash": True, "card_f": "1", "card_t": "N"},
    ]
    return "erd_07_payments", "Domain 7 — Payments, Allocations & Account Ledgers (Append-only)", E, EDGES, \
        "Dashed = logical reference (reference_type + reference_id), not a hard FK. MIXED payments split into payment_method_lines; allocations distribute a payment across many invoices. Ledgers are immutable — corrections via reversal entries only."


def d8_purchasing():
    E = {
        "purchase_orders": {"name": "purchase_orders", "x": 40, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "uuid", "UUID"), ("UQ", "po_number", "VARCHAR(30)"),
            ("FK", "supplier_id", "BIGINT"), ("FK", "warehouse_id", "BIGINT"),
            ("", "status", "ENUM 7 values"), ("", "total", "NUMERIC(18,4)")]},
        "purchase_order_items": {"name": "purchase_order_items", "x": 440, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "po_id", "BIGINT"), ("FK", "product_id", "BIGINT"),
            ("", "quantity", "NUMERIC(18,4)"), ("", "qty_received", "NUMERIC(18,4)"),
            ("", "unit_cost", "NUMERIC(18,4)")]},
        "purchase_receipts": {"name": "purchase_receipts", "x": 40, "y": 400, "fields": [
            ("PK", "id", "BIGINT"), ("", "receipt_number", "VARCHAR(30)"), ("FK", "po_id", "BIGINT"),
            ("FK", "warehouse_id", "BIGINT"), ("", "status", "DRAFT | POSTED | CANCELLED")]},
        "purchase_receipt_items": {"name": "purchase_receipt_items", "x": 440, "y": 400, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "receipt_id", "BIGINT"), ("FK", "po_item_id", "BIGINT"),
            ("", "qty_accepted", "NUMERIC(18,4)"), ("", "qty_rejected", "NUMERIC(18,4)"),
            ("", "batch_number / expiry", "VARCHAR | DATE")]},
        "supplier_invoices": {"name": "supplier_invoices", "x": 840, "y": 400, "fields": [
            ("PK", "id", "BIGINT"), ("", "invoice_number", "VARCHAR(60)"), ("FK", "supplier_id", "BIGINT"),
            ("FK", "receipt_id", "BIGINT NULL"), ("", "total / paid_amount", "NUMERIC(18,4)"),
            ("", "due_date", "DATE")]},
        "purchase_returns": {"name": "purchase_returns", "x": 840, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("", "return_number", "VARCHAR(30)"), ("FK", "supplier_id", "BIGINT"),
            ("FK", "receipt_id", "BIGINT NULL"), ("FK", "warehouse_id", "BIGINT"),
            ("", "status", "ENUM 5 values")]},
        "purchase_return_items": {"name": "purchase_return_items", "x": 1240, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "return_id", "BIGINT"), ("FK", "product_id", "BIGINT"),
            ("", "quantity", "NUMERIC(18,4)"), ("", "unit_cost", "NUMERIC(18,4)")]},
    }
    EDGES = [
        {"f": "purchase_orders", "t": "purchase_order_items", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "purchase_orders", "t": "purchase_receipts", "fm": "b", "tm": "t", "card_f": "1", "card_t": "N"},
        {"f": "purchase_receipts", "t": "purchase_receipt_items", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "purchase_receipts", "t": "supplier_invoices", "fm": "r", "tm": "l", "dash": True, "card_f": "1", "card_t": "N"},
        {"f": "purchase_receipts", "t": "purchase_returns", "fm": "r", "tm": "b", "dash": True, "card_f": "1", "card_t": "N"},
        {"f": "purchase_returns", "t": "purchase_return_items", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
    ]
    return "erd_08_purchasing", "Domain 8 — Procure-to-Pay Cycle", E, EDGES, \
        "Stock increases ONLY at purchase_receipts POSTED (PURCHASE_RECEIPT ledger entry), never at PO creation. Supplier payments flow through payments (direction=OUT) + payment_allocations(target_type=SUPP_INV)."


def d9_finance():
    E = {
        "cashboxes": {"name": "cashboxes", "x": 40, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("FK", "branch_id", "BIGINT"),
            ("", "type", "MAIN | BRANCH | REP"), ("", "current_balance", "NUMERIC(18,4)"),
            ("FK", "custodian_id", "BIGINT NULL")]},
        "cashbox_transactions": {"name": "cashbox_transactions", "x": 40, "y": 340, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "cashbox_id", "BIGINT"),
            ("", "txn_type", "IN | OUT | OPENING | TRANSFER"), ("", "amount", "NUMERIC(18,4)"),
            ("", "balance_after", "NUMERIC(18,4)"), ("", "reference_type + id", "VARCHAR+BIGINT")]},
        "bank_accounts": {"name": "bank_accounts", "x": 440, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("", "bank_name", "VARCHAR(120)"),
            ("", "account_number / iban", "VARCHAR(60)"), ("", "current_balance", "NUMERIC(18,4)")]},
        "bank_transactions": {"name": "bank_transactions", "x": 440, "y": 330, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "bank_account_id", "BIGINT"),
            ("", "txn_type", "IN | OUT"), ("", "amount", "NUMERIC(18,4)"),
            ("", "reference_type + id", "VARCHAR+BIGINT")]},
        "expense_categories": {"name": "expense_categories", "x": 840, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("", "name", "VARCHAR(120)"),
            ("", "requires_approval", "BOOLEAN")]},
        "expenses": {"name": "expenses", "x": 840, "y": 290, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "uuid", "UUID"), ("UQ", "expense_number", "VARCHAR(30)"),
            ("FK", "category_id", "BIGINT"), ("FK", "branch_id", "BIGINT"),
            ("FK", "cashbox_id", "BIGINT NULL"), ("", "amount", "NUMERIC(18,4)"),
            ("", "status", "ENUM 5 values"), ("FK", "approved_by", "BIGINT NULL")]},
    }
    EDGES = [
        {"f": "cashboxes", "t": "cashbox_transactions", "fm": "b", "tm": "t", "card_f": "1", "card_t": "N"},
        {"f": "bank_accounts", "t": "bank_transactions", "fm": "b", "tm": "t", "card_f": "1", "card_t": "N"},
        {"f": "expense_categories", "t": "expenses", "fm": "b", "tm": "t", "card_f": "1", "card_t": "N"},
        {"f": "cashboxes", "t": "expenses", "fm": "r", "tm": "l", "dash": True, "card_f": "1", "card_t": "N"},
    ]
    return "erd_09_finance", "Domain 9 — Treasury: Cashboxes, Banks & Expenses", E, EDGES, \
        "Closing = Opening + IN - OUT. cashbox_transactions / bank_transactions are append-only; balances derived and cached. Expense approval threshold configurable per company."


def d10_field_sales():
    E = {
        "sales_teams": {"name": "sales_teams", "x": 40, "y": 80, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("FK", "branch_id", "BIGINT"),
            ("FK", "manager_id", "BIGINT NULL"), ("", "name", "VARCHAR(120)")]},
        "sales_reps": {"name": "sales_reps", "x": 440, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "uuid", "UUID"), ("UQ", "user_id", "BIGINT"),
            ("FK", "warehouse_id", "BIGINT"), ("FK", "team_id", "BIGINT NULL"),
            ("", "employee_code", "VARCHAR(40)"), ("", "is_active", "BOOLEAN")]},
        "routes": {"name": "routes", "x": 840, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("FK", "sales_rep_id", "BIGINT"),
            ("", "day_of_week", "SMALLINT NULL"), ("", "name", "VARCHAR(120)")]},
        "route_customers": {"name": "route_customers", "x": 1240, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "route_id", "BIGINT"), ("FK", "customer_id", "BIGINT"),
            ("", "sequence_no", "SMALLINT")]},
        "visits": {"name": "visits", "x": 1240, "y": 300, "fields": [
            ("PK", "id", "BIGINT"), ("UQ", "uuid", "UUID"), ("FK", "customer_id", "BIGINT"),
            ("FK", "sales_rep_id", "BIGINT"), ("FK", "route_id", "BIGINT NULL"),
            ("", "status", "ENUM 5 values"), ("", "start/end lat,lng", "DECIMAL(10,7)"),
            ("", "order_created", "BOOLEAN"), ("", "payment_collected", "BOOLEAN")]},
        "sales_targets": {"name": "sales_targets", "x": 440, "y": 350, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "sales_rep_id", "BIGINT"),
            ("", "period_type", "ENUM 5 values"), ("", "period_start / end", "DATE"),
            ("", "target_amount", "NUMERIC(18,4)"), ("", "target_orders", "INTEGER NULL")]},
        "commission_rules": {"name": "commission_rules", "x": 40, "y": 380, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"),
            ("", "rule_type", "ENUM 4 values"), ("", "percent", "NUMERIC(5,2)"),
            ("FK", "product_id", "BIGINT NULL"), ("", "tiers", "JSONB NULL")]},
        "commissions": {"name": "commissions", "x": 840, "y": 350, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "sales_rep_id", "BIGINT"),
            ("FK", "rule_id", "BIGINT NULL"), ("FK", "invoice_id", "BIGINT NULL"),
            ("", "sales_amount", "NUMERIC(18,4)"), ("", "commission_amount", "NUMERIC(18,4)"),
            ("", "status", "PENDING | APPROVED | PAID | CANCELLED")]},
    }
    EDGES = [
        {"f": "sales_teams", "t": "sales_reps", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "sales_reps", "t": "routes", "fm": "r", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "routes", "t": "route_customers", "fm": "b", "tm": "t", "card_f": "1", "card_t": "N"},
        {"f": "sales_reps", "t": "visits", "fm": "b", "tm": "l", "card_f": "1", "card_t": "N"},
        {"f": "sales_reps", "t": "sales_targets", "fm": "b", "tm": "t", "card_f": "1", "card_t": "N"},
        {"f": "commission_rules", "t": "commissions", "fm": "r", "tm": "l", "dash": True, "card_f": "1", "card_t": "N"},
        {"f": "sales_reps", "t": "commissions", "fm": "r", "tm": "t", "midY": 320, "card_f": "1", "card_t": "N"},
    ]
    return "erd_10_field_sales", "Domain 10 — Field Sales: Reps, Targets, Commissions, Visits & Routes", E, EDGES, \
        "commission_rules.tiers JSONB example: [{min:80,max:99,rate:3},{min:100,rate:5}]. UNIQUE(sales_rep_id, invoice_id) prevents double commission. Visits capture GPS accuracy/lat/lng/timestamp at start & end."


def d11_system():
    E = {
        "approvals": {"name": "approvals", "x": 40, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"),
            ("", "request_type", "ENUM 4 values"), ("", "entity_type + entity_id", "VARCHAR+BIGINT"),
            ("FK", "requested_by", "BIGINT"), ("", "status", "ENUM 4 values"),
            ("FK", "approver_id", "BIGINT NULL"), ("", "payload", "JSONB")]},
        "approval_rules": {"name": "approval_rules", "x": 40, "y": 380, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"),
            ("", "rule_type", "ENUM 4 values"), ("", "condition", "JSONB"),
            ("FK", "approver_role_id", "BIGINT"), ("", "priority", "SMALLINT")]},
        "notifications": {"name": "notifications", "x": 440, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("FK", "user_id", "BIGINT NULL"),
            ("", "channel", "IN_APP | PUSH | EMAIL"), ("", "type / title / body", "VARCHAR/TEXT"),
            ("", "entity_type + entity_id", "VARCHAR+BIGINT"), ("", "is_read / read_at", "BOOLEAN/TZ")]},
        "audit_logs": {"name": "audit_logs", "x": 840, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT NULL"), ("FK", "user_id", "BIGINT NULL"),
            ("", "action / module", "VARCHAR"), ("", "entity_type + entity_id", "VARCHAR+BIGINT"),
            ("", "old_values / new_values", "JSONB"), ("", "ip_address / user_agent", "INET/TEXT")]},
        "settings": {"name": "settings", "x": 840, "y": 360, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("UQ", "key", "VARCHAR(100)"),
            ("", "value", "JSONB"), ("", "group", "VARCHAR(50)")]},
        "document_sequences": {"name": "document_sequences", "x": 440, "y": 360, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("", "doc_type", "VARCHAR(30)"),
            ("", "prefix", "VARCHAR(15)"), ("", "current_number", "BIGINT"), ("", "year", "SMALLINT")]},
        "sync_operations": {"name": "sync_operations", "x": 40, "y": 640, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("FK", "user_id", "BIGINT"),
            ("UQ", "client_transaction_id", "UUID"), ("FK", "device_id", "BIGINT"),
            ("", "entity_type", "VARCHAR(50)"), ("", "payload", "JSONB"),
            ("", "sync_status", "ENUM 4 values")]},
        "attachments": {"name": "attachments", "x": 440, "y": 640, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"),
            ("", "entity_type + entity_id", "VARCHAR+BIGINT"), ("", "file_name / file_url", "VARCHAR"),
            ("", "mime_type / file_size", "VARCHAR/BIGINT")]},
        "import_jobs": {"name": "import_jobs", "x": 840, "y": 640, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("", "job_type", "ENUM 6 values"),
            ("", "file_url", "TEXT"), ("", "status", "ENUM 7 values"),
            ("", "errors / summary", "JSONB")]},
        "b2b_portal_users": {"name": "b2b_portal_users", "x": 1240, "y": 60, "fields": [
            ("PK", "id", "BIGINT"), ("FK", "company_id", "BIGINT"), ("UQ", "customer_id", "BIGINT"),
            ("UQ", "email", "VARCHAR(160)"), ("", "password_hash", "VARCHAR(255)"),
            ("", "is_active", "BOOLEAN")]},
    }
    EDGES = [
        {"f": "approval_rules", "t": "approvals", "fm": "t", "tm": "b", "dash": True, "card_f": "1", "card_t": "N"},
        {"f": "approvals", "t": "notifications", "fm": "r", "tm": "l", "dash": True, "card_f": "1", "card_t": "N"},
    ]
    return "erd_11_system", "Domain 11 — Platform Services: Approvals, Notifications, Audit, Sync, B2B", E, EDGES, \
        "audit_logs is append-only (no UPDATE/DELETE grants). document_sequences UNIQUE(company_id, doc_type, year) + row lock guarantees gapless concurrent numbering. sync_operations.client_transaction_id = offline idempotency key."


def d0_overview():
    """Overview map: 11 domain cards, no wires."""
    domains = [
        ("D1", "Core & Security", "companies, branches, users, roles, permissions, warehouses, devices"),
        ("D2", "Products & Pricing", "products, categories, brands, units, barcodes, price lists"),
        ("D3", "Customers & Suppliers", "customers, groups, contacts, addresses, suppliers"),
        ("D4", "Stock", "stock_transactions, stock_balances, batches, serials"),
        ("D5", "Movements", "transfers, adjustments, stocktakings, damages"),
        ("D6", "Sales", "quotations, orders, deliveries, invoices, credit notes"),
        ("D7", "Payments & Ledgers", "payments, allocations, customer/supplier ledgers"),
        ("D8", "Purchasing", "POs, receipts, supplier invoices, purchase returns"),
        ("D9", "Finance", "cashboxes, banks, expenses"),
        ("D10", "Field Sales", "reps, targets, commissions, visits, routes"),
        ("D11", "System", "approvals, notifications, audit, sync, B2B, settings"),
    ]
    cards = "".join(
        f'<div class="dcard"><div class="dnum">{n}</div><div class="dname">{t}</div>'
        f'<div class="dtbls">{d}</div></div>'
        for n, t, d in domains
    )
    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    * {{ margin:0; padding:0; box-sizing:border-box; }}
    body {{ font-family:'DejaVu Sans',sans-serif; background:#FFFFFF; }}
    .wrap {{ width:1240px; padding:24px 20px; }}
    .title {{ font-size:19px; font-weight:800; color:#1E293B; }}
    .subtitle {{ font-size:12px; color:#64748B; margin:4px 0 18px; }}
    .grid {{ display:grid; grid-template-columns:repeat(4,1fr); gap:14px; }}
    .dcard {{ border:1px solid #CBD5E1; border-radius:9px; padding:12px 14px;
      background:#F8FAFC; box-shadow:0 1px 3px rgba(15,23,42,.06); }}
    .dnum {{ display:inline-block; font-size:10.5px; font-weight:800; color:#FFFFFF;
      background:#1E293B; border-radius:5px; padding:2px 8px; margin-bottom:7px; }}
    .dname {{ font-size:13.5px; font-weight:700; color:#1F2937; margin-bottom:5px; }}
    .dtbls {{ font-size:10.5px; line-height:1.5; color:#64748B; }}
    .flow {{ margin-top:18px; border:1px dashed #94A3B8; border-radius:9px; padding:12px 16px;
      font-size:11.5px; color:#334155; line-height:1.8; background:#FFF7ED; }}
    </style></head><body><div class="wrap">
    <div class="title">Database Domain Map — Sales &amp; Distribution Management System</div>
    <div class="subtitle">11 domains · 83 tables · PostgreSQL · multi-tenant (company_id on every tenant-scoped table)</div>
    <div class="grid">{cards}</div>
    <div class="flow"><b>Master flow:</b> Supplier → Purchase Receipt → Main Warehouse → (Branch / REP Warehouse) → Sales Rep → Customer → Order / Invoice / Payment → Customer Ledger → Reports</div>
    </div></body></html>"""
    import os
    from playwright.sync_api import sync_playwright
    out = "/home/z/my-project/assets/erd/erd_00_overview.html"
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1240, "height": 900}, device_scale_factor=2)
        pg.goto("file://" + out)
        pg.wait_for_timeout(200)
        pg.screenshot(path="/home/z/my-project/assets/erd/erd_00_overview.png", full_page=True)
        b.close()
    print("OK erd_00_overview.png")
