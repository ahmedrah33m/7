// =====================================================================
// Phase 4 + 8 + 9 acceptance suite — field sales (targets, GPS visits,
// routes, commission engine), B2B portal (own prices, orders→invoice),
// offline sync (SYNC_001 idempotency, cursor pull), hardening (RBAC,
// audit, OpenAPI). Uses the REAL HTTP API; exit code 0 = all pass.
// =====================================================================

import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000/api/v1";
const db = new PrismaClient();

let pass = 0;
let fail = 0;
const results: string[] = [];

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    results.push(`  ✅ ${name}`);
  } else {
    fail++;
    results.push(`  ❌ ${name} ${detail ? "— " + detail : ""}`);
  }
}

async function req(
  method: string,
  path: string,
  token?: string,
  body?: unknown
): Promise<{ status: number; body: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json };
}

function period(d = new Date()): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

async function main() {
  console.log("═══ Phase 4/8/9 verification — field · B2B · sync · hardening ═══");
  const P = period();

  // ---------- logins ----------
  const admin = await req("POST", "/auth/login", undefined, { username: "admin", password: "Admin@123" });
  check("admin login", admin.status === 200 && admin.body.success);
  const T = admin.body.data?.access_token as string;

  const rep = await req("POST", "/auth/login", undefined, { username: "rep.ahmed", password: "Rep@12345" });
  const RT = rep.body.data?.access_token as string;
  check("rep login", rep.status === 200);

  const cashier = await req("POST", "/auth/login", undefined, { username: "cashier", password: "Cashier@123" });
  const CT = cashier.body.data?.access_token as string;
  check("cashier login", cashier.status === 200);

  // ---------- RBAC hardening ----------
  const rbac1 = await req("POST", "/field/targets", CT, { rep_id: 4, period: P, target_amount: 1000 });
  check("RBAC: cashier blocked from field.targets.create (PERM_001)", rbac1.status === 403 && rbac1.body.code === "PERM_001", `${rbac1.status}/${rbac1.body.code}`);

  const rbac2 = await req("POST", "/field/commissions/1/approve", CT, {});
  check("RBAC: cashier blocked from field.commissions.approve (PERM_001)", rbac2.status === 403 && rbac2.body.code === "PERM_001", `${rbac2.status}/${rbac2.body.code}`);

  const rbac3 = await req("GET", "/b2b/admin/orders", CT);
  check("RBAC: cashier blocked from b2b.orders.view (PERM_001)", rbac3.status === 403 && rbac3.body.code === "PERM_001", `${rbac3.status}/${rbac3.body.code}`);

  // ---------- targets + performance ----------
  const setT = await req("POST", "/field/targets", T, { rep_id: 4, period: P, target_amount: 3_000_000 });
  check("admin sets monthly target", setT.status === 201 || (setT.body.success && setT.body.data?.target_amount === 3_000_000), JSON.stringify(setT.body).slice(0, 80));

  const repSelfTarget = await req("POST", "/field/targets", RT, { rep_id: 4, period: P, target_amount: 100 });
  check("rep isolation: rep cannot set targets (PERM_001)", repSelfTarget.status === 403 && repSelfTarget.body.code === "PERM_001", `${repSelfTarget.status}/${repSelfTarget.body.code}`);

  const perf = await req("GET", `/field/targets?period=${P}`, T);
  const ahmed = (perf.body.data ?? []).find((r: any) => r.repName?.includes("أحمد"));
  check("performance shows sales + achievement", perf.status === 200 && !!ahmed && ahmed.sales >= 0 && ahmed.achievementPct != null, JSON.stringify(perf.body).slice(0, 100));

  // ---------- visit state machine with GPS ----------
  const custs = await req("GET", "/customers?per_page=50", T);
  const c2 = (custs.body.data ?? [])[1];
  const planned = await req("POST", "/field/visits", RT, {
    customer_id: c2.id,
    planned_date: new Date().toISOString(),
    notes: "زيارة اختبار آلي",
  });
  check("rep plans a visit (rep isolation → own)", planned.status === 201 && planned.body.success, JSON.stringify(planned.body).slice(0, 80));
  const vid = planned.body.data?.id as number;

  const completeTooEarly = await req("POST", `/field/visits/${vid}/complete`, RT, { outcome: "ORDERED" });
  check("complete before check-in blocked (VAL_004)", completeTooEarly.status === 409 && completeTooEarly.body.code === "VAL_004", `${completeTooEarly.status}/${completeTooEarly.body.code}`);

  const badGps = await req("POST", `/field/visits/${vid}/checkin`, RT, { lat: 999, lng: 44.3 });
  check("invalid GPS rejected (VAL_001)", badGps.status === 422 && badGps.body.code === "VAL_001", `${badGps.status}/${badGps.body.code}`);

  const checkin = await req("POST", `/field/visits/${vid}/checkin`, RT, { lat: 33.3152, lng: 44.3661 });
  check("GPS check-in → CHECKED_IN", checkin.status === 200 && checkin.body.data?.status === "CHECKED_IN", JSON.stringify(checkin.body).slice(0, 80));

  const checkin2 = await req("POST", `/field/visits/${vid}/checkin`, RT, { lat: 33.3152, lng: 44.3661 });
  check("double check-in blocked (VAL_004)", checkin2.status === 409 && checkin2.body.code === "VAL_004", `${checkin2.status}/${checkin2.body.code}`);

  const complete = await req("POST", `/field/visits/${vid}/complete`, RT, { outcome: "ORDERED", order_value: 8500 });
  check("complete with outcome → COMPLETED", complete.status === 200 && complete.body.data?.status === "COMPLETED" && complete.body.data?.order_value === 8500, JSON.stringify(complete.body).slice(0, 80));

  const repVisits = await req("GET", "/field/visits", RT);
  const allMine = (repVisits.body.data ?? []).every((v: any) => v.rep?.id === 4);
  check("rep isolation: rep sees ONLY own visits", repVisits.status === 200 && allMine && (repVisits.body.data ?? []).length > 0);

  // ---------- commission engine ----------
  const prods = await req("GET", "/products?per_page=200", T);
  const water = (prods.body.data ?? []).find((p: any) => p.name?.includes("مياه")) ?? prods.body.data?.[0];

  const beforeComm = await req("GET", "/field/commissions", RT);
  const beforeCount = (beforeComm.body.data ?? []).length;

  const repWh = (await req("GET", "/auth/me", RT)).body.data?.warehouses?.[0]?.id;
  const repInv = await req("POST", "/sales/invoices", RT, {
    customer_id: c2.id, warehouse_id: repWh, type: "CASH",
    lines: [{ product_id: water.id, qty: 2 }],
  });
  check("rep posts invoice from van warehouse", repInv.status === 201 && repInv.body.success, JSON.stringify(repInv.body).slice(0, 120));
  const newInvoiceId = repInv.body.data?.id;

  const afterComm = await req("GET", "/field/commissions", RT);
  const afterRows = afterComm.body.data ?? [];
  check("commission engine auto-generated rows for rep invoice", afterRows.length > beforeCount, `before=${beforeCount} after=${afterRows.length}`);

  const pairs = new Set<string>();
  let dupFree = true;
  for (const c of afterRows) pairs.add(`${c.invoice.id}:${c.rule}`);
  const keyed = afterRows.map((c: any) => `${c.invoice.id}:${c.rule}`);
  if (new Set(keyed).size !== keyed.length) dupFree = false;
  check("commission uniqueness: no (invoice, rule) pair duplicated", dupFree, `rows=${keyed.length} unique=${new Set(keyed).size}`);

  const dbDupes = await db.$queryRawUnsafe<{ n: number }[]>(
    `SELECT COUNT(*) as n FROM (SELECT invoice_id, rule_id, COUNT(*) c FROM commissions GROUP BY invoice_id, rule_id HAVING c > 1) x`
  ) as any;
  const dbDupesN = Array.isArray(dbDupes) ? Number(dbDupes[0]?.n ?? 0) : Number((dbDupes as any)[0]?.n ?? 0);
  check("DB constraint: zero duplicate (invoice, rule) rows in table", dbDupesN === 0, `dupes=${dbDupesN}`);

  const pending = afterRows.find((c: any) => c.status === "PENDING" && c.invoice.id === newInvoiceId);
  if (pending) {
    const appr = await req("POST", `/field/commissions/${pending.id}/approve`, T, {});
    check("commission approve → APPROVED", appr.status === 200 && appr.body.data?.status === "APPROVED");
    const appr2 = await req("POST", `/field/commissions/${pending.id}/approve`, T, {});
    check("double approve blocked (VAL_004)", appr2.status === 409 && appr2.body.code === "VAL_004", `${appr2.status}/${appr2.body.code}`);
    // fresh list — pay a STILL-PENDING commission (different id) → VAL_004
    const fresh = await req("GET", "/field/commissions", RT);
    const otherPending = (fresh.body.data ?? []).find((c: any) => c.status === "PENDING" && c.id !== pending.id);
    if (otherPending) {
      const payBefore = await req("POST", `/field/commissions/${otherPending.id}/pay`, T, {});
      check("pay before approve blocked (VAL_004)", payBefore.status === 409 && payBefore.body.code === "VAL_004", `${payBefore.status}/${payBefore.body.code}`);
    }
  }

  // ---------- routes ----------
  const newRoute = await req("POST", "/field/routes", T, { name: "مسار التحقق الآلي", rep_id: 4, day_of_week: 3, customer_ids: [c2.id] });
  check("create route with customer", newRoute.status === 201 && newRoute.body.success, JSON.stringify(newRoute.body).slice(0, 80));
  const routes = await req("GET", "/field/routes", T);
  check("routes list includes ordered customers", routes.status === 200 && (routes.body.data ?? []).some((r: any) => r.customers?.length > 0));

  // ---------- B2B portal ----------
  const wrongPin = await req("POST", "/b2b/auth", undefined, { code: "C-00002", pin: "9999" });
  check("B2B wrong PIN → uniform AUTH_003 (no probing)", wrongPin.status === 401 && wrongPin.body.code === "AUTH_003", `${wrongPin.status}/${wrongPin.body.code}`);

  const b2bLogin = await req("POST", "/b2b/auth", undefined, { code: "C-00002", pin: "2211" });
  check("B2B login C-00002/2211 → customer JWT", b2bLogin.status === 200 && !!b2bLogin.body.data?.token);
  const BT = b2bLogin.body.data?.token as string;

  const cat = await req("GET", "/b2b/catalog", BT);
  const firstP = cat.body.data?.products?.[0];
  const expected = Math.round(firstP?.list_price * (1 - cat.body.data?.customer?.discount_pct / 100) * 100) / 100;
  check("B2B sees OWN prices only (discount applied)", cat.status === 200 && Math.abs(firstP.your_price - expected) < 0.01, `your=${firstP?.your_price} expected=${expected}`);

  const b2bOrder = await req("POST", "/b2b/orders", BT, {
    lines: [{ product_id: firstP.id, qty: 3 }],
    notes: "طلب اختبار آلي",
  });
  check("B2B order submitted at own prices", b2bOrder.status === 201 && b2bOrder.body.data?.grand_total > 0, JSON.stringify(b2bOrder.body).slice(0, 100));
  const orderId = b2bOrder.body.data?.id as number;

  const whs = (await req("GET", "/auth/me", T)).body.data?.warehouses;
  const mainWh = whs?.find((w: any) => w.code === "WH-MAIN")?.id ?? whs?.[0]?.id;

  const prodBefore = (await req("GET", `/inventory/balances?warehouse_id=${mainWh}&per_page=200`, T)).body.data
    ?.find((b: any) => b.product?.id === firstP.id || b.product_id === firstP.id)?.qty ?? null;

  const confirm = await req("POST", `/b2b/admin/orders/${orderId}/confirm`, T, { warehouse_id: mainWh, type: "CASH" });
  check("B2B confirm → real invoice via posting engine", confirm.status === 200 && confirm.body.data?.invoice?.number?.startsWith("INV-"), JSON.stringify(confirm.body).slice(0, 120));

  const confirm2 = await req("POST", `/b2b/admin/orders/${orderId}/confirm`, T, { warehouse_id: mainWh, type: "CASH" });
  check("double confirm blocked (VAL_004)", confirm2.status === 409 && confirm2.body.code === "VAL_004", `${confirm2.status}/${confirm2.body.code}`);

  const stmt = await req("GET", "/b2b/statement", BT);
  check("B2B statement shows own invoices + orders", stmt.status === 200 && (stmt.body.data?.invoices?.length ?? 0) > 0 && (stmt.body.data?.orders?.length ?? 0) > 0);

  const b2bAsStaff = await req("GET", "/b2b/catalog", T);
  check("B2B token types are segregated (staff token rejected on portal)", b2bAsStaff.status === 401, `${b2bAsStaff.status}`);

  // ---------- offline sync ----------
  const op = {
    op_uuid: `verify-${Date.now()}-0001`,
    entity: "sales_invoice",
    action: "create",
    payload: { customer_id: c2.id, warehouse_id: mainWh, type: "CASH", lines: [{ product_id: firstP.id, qty: 1 }] },
  };
  const p1 = await req("POST", "/sync/push", T, { device_id: "verify-suite", operations: [op] });
  const r1 = p1.body.data?.results?.[0];
  check("sync push #1 → APPLIED", p1.status === 200 && r1?.status === "APPLIED" && r1?.result?.number?.startsWith("INV-"), JSON.stringify(p1.body).slice(0, 120));

  const p2 = await req("POST", "/sync/push", T, { device_id: "verify-suite", operations: [op] });
  const r2 = p2.body.data?.results?.[0];
  check(
    "sync push #2 (same op_uuid) → DUPLICATE SYNC_001 with ORIGINAL result",
    p2.status === 200 && r2?.status === "DUPLICATE" && r2?.code === "SYNC_001" && r2?.result?.number === r1?.result?.number,
    `r1=${r1?.result?.number} r2=${r2?.result?.number}`
  );

  const dbSyncDupes = await db.syncLog.count({ where: { opUuid: op.op_uuid } });
  check("sync ledger: exactly ONE row for the op (no re-apply)", dbSyncDupes === 1, `rows=${dbSyncDupes}`);

  const pull1 = await req("GET", "/sync/pull?entities=products,customers,stock_balances", T);
  check("sync pull returns delta + next_cursor", pull1.status === 200 && !!pull1.body.data?.next_cursor && Object.keys(pull1.body.data.counts ?? {}).length >= 1, JSON.stringify(pull1.body.data?.counts));

  const pull2 = await req("GET", `/sync/pull?cursor=${encodeURIComponent(pull1.body.data.next_cursor)}&entities=products`, T);
  check("sync pull with cursor → forward-only walk works", pull2.status === 200);

  // ---------- audit + openapi ----------
  const audits = await req("GET", "/admin/audit-logs?per_page=200", T);
  const modules = new Set((audits.body.data?.rows ?? audits.body.data ?? []).map((a: any) => a.module));
  check("audit trail captured field+b2b+sync actions", audits.status === 200 && modules.has("field") && modules.has("b2b") && modules.has("sync"), [...modules].join(",").slice(0, 80));

  const openapi = await fetch(`${BASE}/openapi`).then((r) => r.json()) as any;
  check("OpenAPI contract published (Phase 9)", !!openapi?.paths && Object.keys(openapi.paths).length >= 30, `paths=${Object.keys(openapi?.paths ?? {}).length}`);

  // ---------- summary ----------
  console.log(results.join("\n"));
  console.log(`\n═══ Result: ${pass} passed · ${fail} failed ═══`);
  await db.$disconnect();
  process.exit(fail === 0 ? 0 : 1);
}

main().catch(async (e) => {
  console.error("SUITE CRASH:", e);
  await db.$disconnect();
  process.exit(1);
});
