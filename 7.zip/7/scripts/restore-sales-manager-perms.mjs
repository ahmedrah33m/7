// Restore company A's SALES_MANAGER permissions to the seeded set
// (damaged by test run #1 against a stale server — self-owned guard was
// unreachable then). List transcribed from src/lib/seed.ts case "SALES_MANAGER".
const BASE = "http://localhost:3000";

async function j(path, init = {}, token) {
  const res = await fetch(BASE + path, {
    ...init,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  });
  return { status: res.status, body: await res.json().catch(() => ({})) };
}

const core = ["system.users", "system.roles", "system.branches", "system.warehouses", "system.company", "system.settings", "audit.audit_logs"];
const coreView = core.map((e) => `${e}.view`);
const sellStack = [
  "sales.invoices.view", "sales.invoices.create",
  "products.products.view",
  "parties.customers.view",
  "inventory.stock.view", "inventory.movements.view",
];

const permissions = [
  ...coreView,
  ...sellStack, "sales.invoices.edit", "sales.invoices.cancel", "sales.invoices.print", "sales.invoices.approve", "sales.invoices.reject", "sales.orders.view", "sales.orders.create", "sales.orders.edit",
  "sales.returns.view", "sales.returns.create",
  "finance.payments.view", "finance.cashboxes.view", "purchasing.purchase_invoices.view",
  "products.products.create", "products.products.edit",
  "parties.customers.create", "parties.customers.edit",
  "reports.reports.view", "reports.reports.export", "reports.reports.print",
  "field.targets.view", "field.targets.create", "field.targets.edit", "field.targets.delete",
  "field.visits.view", "field.visits.create", "field.visits.edit", "field.visits.cancel",
  "field.routes.view", "field.routes.create", "field.routes.edit", "field.routes.delete",
  "field.commissions.view", "field.commissions.approve",
  "b2b.orders.view", "b2b.orders.approve", "b2b.orders.reject", "b2b.orders.cancel",
  "sales.orders.cancel", "products.products.import", "parties.customers.import",
  "sales.quotations.view", "sales.quotations.create", "sales.quotations.edit", "sales.quotations.post", "sales.quotations.cancel",
  "sales.delivery_notes.view", "sales.delivery_notes.create", "sales.delivery_notes.edit", "sales.delivery_notes.cancel",
  "inventory.stocktakes.view",
];

const login = await j("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: "admin", password: "Admin@123" }) });
const token = login.body?.data?.access_token;
const roles = await j("/api/v1/admin/roles", {}, token);
const sm = (roles.body?.data ?? []).find((r) => r.code === "SALES_MANAGER");

const patch = await j("/api/v1/admin/roles", {
  method: "PATCH",
  body: JSON.stringify({ role_id: sm.id, permissions }),
}, token);
console.log("restore status:", patch.status, patch.body?.code ?? "");
const after = patch.body?.data?.permissions ?? [];
console.log("SALES_MANAGER permissions after restore:", after.length);
console.log(after.length === permissions.length && permissions.every((p) => after.includes(p)) ? "RESTORED-OK" : "MISMATCH");
