#!/usr/bin/env python3
"""Double-fork daemonizer for long-running regression — escapes tool-session cleanup."""
import os, sys, subprocess, time

LOG = "/tmp/regression-task27.log"
CMD = ["bash", "/home/z/my-project/scripts/run-full-regression.sh"]

pid = os.fork()
if pid:
    print("regression daemon forked — parent exiting")
    sys.exit(0)
os.setsid()
pid2 = os.fork()
if pid2:
    os._exit(0)
# grandchild: run detached, adopted by PID 1
with open(LOG, "ab", 0) as f:
    f.write(b"\n=== regression (daemonized) started %s ===\n" % str(time.ctime()).encode())
    subprocess.run(CMD, stdout=f, stderr=subprocess.STDOUT)
    f.write(b"\n=== regression finished %s ===\n" % str(time.ctime()).encode())
