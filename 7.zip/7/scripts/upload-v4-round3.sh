#!/usr/bin/env bash
# =============================================================
# upload-v4-round3.sh — gofile (تحقق MD5 من استجابة الخادم) + filebin + temp.sh
# =============================================================
set -uo pipefail
ROOT="/home/z/my-project"
F="$ROOT/download/sds-system-v4.zip"
MD5="b8dda2900a376c325f96f03524f0f655"
UA="Mozilla/5.0 (X11; Linux x86_64) SDS-Uploader/1.0"
VERIFY="$ROOT/backups/verify-download.zip"
say() { echo -e "\n\033[1;36m==> $*\033[0m"; }
ok()  { echo -e "\033[1;32m✔ $*\033[0m"; }
bad() { echo -e "\033[1;31m✘ $*\033[0m"; }

verify_link() {
  rm -f "$VERIFY"
  curl -sL -m 300 -A "$UA" "$1" -o "$VERIFY" 2>/dev/null || return 1
  [ -s "$VERIFY" ] || return 1
  [ "$(md5sum "$VERIFY" | cut -d' ' -f1)" = "$MD5" ]
}

# ---------- 1) gofile: رفع كامل مع التقاط md5 من الخادم ----------
say "gofile.io — رفع مع التقاط الاستجابة الكاملة…"
SRV="$(curl -s -m 30 https://api.gofile.io/servers 2>/dev/null | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"]["servers"][0]["name"])' 2>/dev/null || true)"
echo "  الخادم: ${SRV:-فشل الجلب}"
if [ -n "${SRV:-}" ]; then
  R="$(curl -s -m 300 -A "$UA" -F "file=@${F}" "https://${SRV}.gofile.io/contents/uploadfile" 2>/dev/null || true)"
  echo "$R" | python3 -c '
import sys, json
d = json.load(sys.stdin)
data = d.get("data", {})
print("  status:", d.get("status"))
print("  fileId:", data.get("fileId"))
print("  name:", data.get("name"))
print("  size:", data.get("size"), "(متوقع 5108528)")
print("  server_md5:", data.get("md5"), "(متوقع b8dda2900a376c325f96f03524f0f655)")
print("  downloadPage:", data.get("downloadPage"))
md5 = (data.get("md5") or "").lower()
print("RESULT_MD5_MATCH:", md5 == "b8dda2900a376c325f96f03524f0f655")
' 2>/dev/null || { echo "  فشل تحليل الرد: ${R:0:150}"; }
fi

# ---------- 2) filebin.net (صالح 6 أيام) ----------
say "filebin.net — PUT مجهول…"
BIN="sds-v4-$(date +%s)"
R="$(curl -s -m 300 -A "$UA" -X PUT --data-binary "@${F}" -H "Content-Type: application/octet-stream" "https://filebin.net/${BIN}/sds-system-v4.zip" -o /dev/null -w "%{http_code}" 2>/dev/null || true)"
if [ "$R" = "200" ] || [ "$R" = "201" ]; then
  DL="https://filebin.net/${BIN}/sds-system-v4.zip"
  if verify_link "${DL}/meta" 2>/dev/null; then :; fi
  # تحقق بالتنزيل المباشر
  if verify_link "$DL"; then ok "filebin: $DL (مُتحقق بالتنزيل)"; else ok "filebin: $DL (رفع ناجح HTTP $R — التحقق بالتنزيل غير مؤكد)"; fi
else
  bad "filebin فشل (HTTP $R)"
fi

# ---------- 3) temp.sh بالصيغة الصحيحة ----------
say "temp.sh — curl -T file https://temp.sh/…"
R="$(curl -s -m 300 -A "$UA" -T "${F}" https://temp.sh/ 2>/dev/null || true)"
if [[ "$R" == https://temp.sh/* ]]; then
  if verify_link "$R"; then ok "temp.sh: $R (مُتحقق بالتنزيل)"; else bad "temp.sh رفع لكن MD5 لا يطابق"; fi
else
  bad "temp.sh فشل: ${R:0:100}"
fi

rm -f "$VERIFY"
echo; echo "انتهى"
