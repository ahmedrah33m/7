// =====================================================================
// Phase 0 acceptance tests (MASTER PROMPT §6 Phase 0 exit criteria).
// Hits the REAL running server on localhost:3000 with real HTTP.
// Run: bun scripts/phase0-verify.ts
// =====================================================================

const BASE = "http://localhost:3000/api/v1";

let passed = 0;
let failed = 0;

function check(name: string, ok: boolean, detail = "") {
  if (ok) {
    passed++;
    console.log(`  ✅ ${name}${detail ? ` — ${detail}` : ""}`);
  } else {
    failed++;
    console.log(`  ❌ ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

async function post(path: string, body: unknown, headers: Record<string, string> = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...headers },
    body: JSON.stringify(body),
  });
  return { status: res.status, json: (await res.json()) as Record<string, unknown> };
}

async function get(path: string, token?: string) {
  const res = await fetch(`${BASE}${path}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
  return { status: res.status, json: (await res.json()) as Record<string, unknown> };
}

async function main() {
  console.log("\n═══════ Phase 0 Verification — SDS Foundation ═══════\n");

  // 1. Health
  console.log("— البنية التحتية —");
  const health = await get("/health");
  check("GET /health يعيد 200 وحالة قاعدة البيانات up",
    health.status === 200 && (health.json.data as Record<string, unknown>)?.database === "up");

  // 2. Login success (argon2id + JWT)
  console.log("\n— المصادقة —");
  const login = await post("/auth/login", { username: "admin", password: "Admin@123" });
  const loginData = login.json.data as
    | { access_token: string; refresh_token: string; expires_in: number; permissions: string[]; user: { username: string } }
    | undefined;
  check("دخول admin بكلمة مرور صحيحة (argon2id)", login.status === 200 && !!loginData?.access_token);
  check("expires_in = 900 ثانية (15 دقيقة)", loginData?.expires_in === 900);
  check("يرجع خريطة الصلاحيات", (loginData?.permissions.length ?? 0) > 0, `${loginData?.permissions.length} صلاحية`);

  // 3. /me with token
  const me = await get("/auth/me", loginData!.access_token);
  check("GET /auth/me بالتوكن يعيد الملف الشخصي", me.status === 200 && (me.json.data as Record<string, unknown>)?.user !== undefined);

  // 4. /me without token
  const meNoAuth = await get("/auth/me");
  check("GET /auth/me بدون توكن → AUTH_001/401", meNoAuth.status === 401 && meNoAuth.json.code === "AUTH_001");

  // 5. Forged token
  const meForged = await get("/auth/me", "eyJhbGciOiJIUzI1NiJ9.forged.sig");
  check("توكن مزوّر → AUTH_002/401", meForged.status === 401 && meForged.json.code === "AUTH_002");

  // 6. Refresh rotation
  console.log("\n— دوران رمز التحديث —");
  const r1 = await post("/auth/refresh", { refresh_token: loginData!.refresh_token });
  const r1Data = r1.json.data as { access_token: string; refresh_token: string } | undefined;
  check("التحديث الأول ينجح ويدوّر الرمز", r1.status === 200 && !!r1Data?.refresh_token && r1Data.refresh_token !== loginData!.refresh_token);

  const r2 = await post("/auth/refresh", { refresh_token: loginData!.refresh_token });
  check("إعادة استخدام الرمز القديم → AUTH_006 + إبطال السلسلة", r2.status === 401 && r2.json.code === "AUTH_006");

  const r3 = await post("/auth/refresh", { refresh_token: r1Data!.refresh_token });
  check("الرمز الابن أُبطل أيضًا (إبطال السلسلة كاملة)", r3.status === 401);

  // 7. RBAC — permission gate
  console.log("\n— RBAC وسلسلة الفحوص —");
  const cashierLogin = await post("/auth/login", { username: "cashier", password: "Cashier@123" });
  const cashier = cashierLogin.json.data as { access_token: string; permissions: string[] } | undefined;
  check("دخول الكاشير ناجح", cashierLogin.status === 200 && !!cashier?.access_token);
  check("الكاشير لا يملك system.users.view", !cashier!.permissions.includes("system.users.view"));

  const usersForbidden = await get("/admin/users", cashier!.access_token);
  check("استدعاء /admin/users بصلاحية الكاشير → PERM_001/403", usersForbidden.status === 403 && usersForbidden.json.code === "PERM_001");

  const usersAllowed = await get("/admin/users", loginData!.access_token);
  check("استدعاء /admin/users بصلاحية المالك → 200", usersAllowed.status === 200, `${(usersAllowed.json.data as unknown[])?.length ?? 0} مستخدم`);

  const auditForbidden = await get("/admin/audit-logs", cashier!.access_token);
  check("سجل التدقيق محمي بصلاحية audit.audit_logs.view → 403", auditForbidden.status === 403);

  // 8. Account lockout (AUTH_004) — مستخدم اختبار فريد لكل تشغيل حتى لا
  // يكسر قفل الـ15 دقيقة إعادة تشغيل المجموعة (هشاشة قديمة أُصلحت Phase 2)
  console.log("\n— قفل الحساب —");
  const probeName = `lockprobe-${Date.now().toString().slice(-6)}`;
  await post(
    "/admin/users",
    { username: probeName, password: "Probe@12345", full_name: "Lockout Probe", role_code: "CASHIER" },
    { Authorization: `Bearer ${loginData!.access_token}` }
  );
  let lastStatus = 0, lastCode = "";
  for (let i = 0; i < 5; i++) {
    const r = await post("/auth/login", { username: probeName, password: "Wrong@9999" });
    lastStatus = r.status; lastCode = String(r.json.code);
  }
  // سلوك Phase 1: المحاولة الخامسة تطبّق القفل وترمي AUTH_003 موحّداً (401
  // بلا كشف حالة القفل)، والمحاولة اللاحقة — أي كلمة مرور — تعيد AUTH_004/423
  check("المحاولة الخامسة تطبّق القفل → AUTH_003/401 (رفض موحّد)", lastStatus === 401 && lastCode === "AUTH_003",
    `got ${lastStatus} ${lastCode}`);
  const afterLock = await post("/auth/login", { username: probeName, password: "Whatever@1" });
  check("المحاولة التالية للقفل → AUTH_004/423", afterLock.status === 423 && String(afterLock.json.code) === "AUTH_004",
    `got ${afterLock.status} ${afterLock.json.code}`);

  const stillLocked = await post("/auth/login", { username: probeName, password: "Probe@12345" });
  check("الدخول الصحيح أثناء القفل يُرفض أيضًا", stillLocked.status === 423 && String(stillLocked.json.code) === "AUTH_004",
    `got ${stillLocked.status} ${stillLocked.json.code}`);

  // 9. Validation (Zod, VAL_001)
  console.log("\n— التحقق من المدخلات —");
  const badBody = await post("/auth/login", { username: "ab", password: "short" });
  check("جسم غير صالح → VAL_001/422 مع قائمة الأخطاء", badBody.status === 422 && badBody.json.code === "VAL_001" && Array.isArray(badBody.json.errors));

  const wrongCreds = await post("/auth/login", { username: "ghost_user_xyz", password: "NoUser@12345" });
  check("مستخدم غير موجود → AUTH_003 (بدون كشف السبب)", wrongCreds.status === 401 && wrongCreds.json.code === "AUTH_003");

  // 10. Audit trail captured the security events
  console.log("\n— سجل التدقيق —");
  const adminLogin = await post("/auth/login", { username: "admin", password: "Admin@123" });
  const admin = adminLogin.json.data as { access_token: string } | undefined;
  const audit = await get("/admin/audit-logs?per_page=50", admin!.access_token);
  const rows = audit.json.data as { action: string }[];
  const actions = new Set(rows.map((r) => r.action));
  check("السجل يحتوي LOGIN", actions.has("LOGIN"));
  check("السجل يحتوي LOGIN_FAILED", actions.has("LOGIN_FAILED"));
  check("السجل يحتوي LOCKOUT", actions.has("LOCKOUT"));
  check("السجل يحتوي REFRESH_REJECTED", actions.has("REFRESH_REJECTED"));

  // 11. Rate limiting — LAST (its 600 requests exhaust the IP budget)
  console.log("\n— حدود المعدل —");
  let rateHit = false;
  for (let i = 0; i < 650 && !rateHit; i++) {
    const r = await get("/health");
    if (r.status === 429) rateHit = true;
  }
  check("تجاوز 600 طلب/دقيقة → RATE_001/429", rateHit);

  // Summary
  console.log(`\n═══════ النتيجة: ${passed} ناجح · ${failed} فاشل ═══════\n`);
  if (failed > 0) process.exit(1);
}

main().catch((e) => {
  console.error("FATAL:", e);
  process.exit(1);
});

// عزلة الوحدة — سكربت مستقل يُشغَّل فردياً (tsx/bun)
export {};
