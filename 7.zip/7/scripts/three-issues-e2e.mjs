// =====================================================================
// E2E — إصلاح المشكلات الثلاث التي أبلغ عنها المستخدم:
//  P1: عدم ظهور جميع اليوزرات (مستخدمون يستطيعون الدخول لكنهم غير ظاهرين)
//  P2: عدم ظهور رسالة 423 بعد تسجيل الدخول إلى شركة معينة
//  P3: عدم ظهور حالة الشركة (نشطة/منتهية/معلّقة)
// =====================================================================
const B = "http://localhost:3000";
let pass = 0, fail = 0;
const failures = [];
function check(name, cond, detail = "") {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; failures.push(`${name} ${detail}`); console.log(`  ✗ ${name} ${detail}`); }
}
async function req(path, opts = {}, token) {
  const res = await fetch(B + path, {
    ...opts,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  });
  const body = await res.json().catch(() => ({}));
  return { status: res.status, body };
}
const { PrismaClient } = await import("@prisma/client");
const db = new PrismaClient();

console.log("\n════════════ الدخول والأدوات ════════════");
const admin = await req("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: "admin", password: "Admin@123" }) });
const T = admin.body.data.access_token;
check("دخول المالك admin", admin.status === 200);

const auditor = await req("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: "auditor", password: "Auditor@123" }) });
const TA = auditor.body.data?.access_token;
check("دخول auditor (COMPANY — شركة 1)", auditor.status === 200);

console.log("\n════════════ P1: ظهور جميع اليوزرات ════════════");
const allUsers = await req("/api/v1/admin/users", {}, T);
const rows = allUsers.body.data ?? [];
check("القائمة تعيد meta", !!allUsers.body.meta && Array.isArray(allUsers.body.meta.visible_company_ids));
check(`المالك يرى مستخدمي أكثر من شركة (${rows.length} صف)`, rows.length > 20, `got ${rows.length}`);
const co3 = rows.filter((u) => u.company_id === 3);
const co11 = rows.filter((u) => u.company_id === 11);
check("مستخدمو شركة 3 ظاهرون للمالك", co3.length >= 4, `got ${co3.length}`);
check("مستخدمو شركة 11 ظاهرون للمالك", co11.length >= 1, `got ${co11.length}`);
check("كل صف يحمل company_name", rows.every((u) => !!u.company_name && !!u.company_code));

const filtered = await req("/api/v1/admin/users?company_id=3", {}, T);
check("فلتر ?company_id=3 يعيد شركة 3 فقط", (filtered.body.data ?? []).every((u) => u.company_id === 3) && (filtered.body.data ?? []).length === co3.length);

const outOfScope = await req("/api/v1/admin/users?company_id=999", {}, T);
check("فلتر شركة خارج النطاق → SCOPE_004", outOfScope.status === 403 && outOfScope.body.code === "SCOPE_004", `${outOfScope.status} ${outOfScope.body.code}`);

const auditorUsers = await req("/api/v1/admin/users", {}, TA);
const aRows = auditorUsers.body.data ?? [];
check("auditor (غير GLOBAL) يرى شركته فقط — العزل محفوظ", aRows.length > 0 && aRows.every((u) => u.company_id === 1), `companies=${[...new Set(aRows.map((u) => u.company_id))].join(",")}`);

console.log("\n════════════ تجهيز مستخدم اختبار لشركة 11 ════════════");
// دور من شركة 11 (الأدوار ملك حصري لشركتها)
const role11 = await db.role.findFirst({ where: { companyId: 11, deletedAt: null, code: "CASHIER" }, select: { code: true } });
check("شركة 11 عليها دور CASHIER مُهيأ", !!role11);
const stamp = Date.now().toString().slice(-6);
const mk = async (companyId, username) => {
  const r = await req("/api/v1/admin/users", { method: "POST", body: JSON.stringify({ username, password: "Sub423@Test", full_name: `مستخدم ${username}`, role_code: role11?.code ?? "CASHIER", company_id: companyId, scope_type: "BRANCH", company_ids: companyId === 1 ? [11] : [] }) }, T);
  return r;
};
const su = await mk(11, `sub423_${stamp}`);
check("إنشاء مستخدم مرتبط بشركة 11", su.status === 201, JSON.stringify(su.body));
const suName = `sub423_${stamp}`;
const suId = su.body.data?.id;

// مستخدم من شركة 1 يملك تبديلًا لشركة 11 (مسار المبدّل لغير GLOBAL)
const mv = await req("/api/v1/admin/users", { method: "POST", body: JSON.stringify({ username: `switch423_${stamp}`, password: "Sub423@Test", full_name: "مستخدم مبدّل", role_code: "CASHIER", company_id: 1, scope_type: "BRANCH", company_ids: [11] }) }, T);
check("إنشاء مستخدم شركة 1 مع تبديل لشركة 11", mv.status === 201, JSON.stringify(mv.body));
const mvName = `switch423_${stamp}`;

console.log("\n════════════ P2: رسالة 423 عند دخول شركة منتهية ════════════");
await req("/api/v1/admin/companies/11", { method: "PATCH", body: JSON.stringify({ subscription_ends_at: "2026-09-01" }) }, T);
const co11info = await db.company.findUnique({ where: { id: 11 }, select: { name: true } });

// (أ) مستخدم شركتها المنتهية يسجل دخولًا → 423 SUB_001 مع نص عربي ظاهر
const blocked = await req("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: suName, password: "Sub423@Test" }) });
check("دخول مستخدم شركة منتهية → 423", blocked.status === 423, `got ${blocked.status}`);
check("الكود SUB_001 والرسالة عربية بالاسم", blocked.body.code === "SUB_001" && (blocked.body.message ?? "").includes(co11info.name), blocked.body.message);

// (ب) مستخدم غير GLOBAL: تبديل الشركات تصميميًا للمالك فقط (scope = [شركته])
// → محاولة التبديل لشركة أخرى تُرفض SCOPE_004 قبل أي شيء (حماية النطاق أولاً)
// وفرض 423 على غير GLOBAL يقع عند الدخول والتجديد (المُختبَران أعلاه/أدناه)
const mvLogin = await req("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: mvName, password: "Sub423@Test" }) });
check("دخول المستخدم المبدّل (شركته نشطة) → 200", mvLogin.status === 200, `got ${mvLogin.status}`);
const mvSwitch = await req("/api/v1/auth/switch-company", { method: "POST", body: JSON.stringify({ company_id: 11 }) }, mvLogin.body.data.access_token);
check("تبديل غير GLOBAL لشركة خارج نطاقه → 403 SCOPE_004 (التبديل للمالك فقط)", mvSwitch.status === 403 && mvSwitch.body.code === "SCOPE_004", `${mvSwitch.status} ${mvSwitch.body.code}`);

// (ج) المالك GLOBAL يتجاوز للإدارة — لكن الحالة تعود صريحة في الرد (توست الواجهة)
const ownerSwitch = await req("/api/v1/auth/switch-company", { method: "POST", body: JSON.stringify({ company_id: 11 }) }, T);
check("المالك يدخل شركة منتهية للإدارة (bypass)", ownerSwitch.status === 200);
check("scope.subscription في رد التبديل = EXPIRED (يُطلق توست 423)", ownerSwitch.body.data?.scope?.subscription?.status === "EXPIRED", JSON.stringify(ownerSwitch.body.data?.scope?.subscription));

// (د) المالك يسجل دخولًا مباشرة بـ company_id للشركة المنتهية → 200 + الحالة ظاهرة
const ownerLogin11 = await req("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: "admin", password: "Admin@123", company_id: 11 }) });
check("دخول المالك مباشرة للشركة المنتهية → 200 + EXPIRED", ownerLogin11.status === 200 && ownerLogin11.body.data?.scope?.subscription?.status === "EXPIRED");

// (هـ) الشركة معلّقة → SUB_002
await req("/api/v1/admin/companies/11", { method: "PATCH", body: JSON.stringify({ is_suspended: true }) }, T);
const suspendedLogin = await req("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: suName, password: "Sub423@Test" }) });
check("دخول مستخدم شركة معلّقة → 423 SUB_002", suspendedLogin.status === 423 && suspendedLogin.body.code === "SUB_002", `${suspendedLogin.status} ${suspendedLogin.body.code}`);
await req("/api/v1/admin/companies/11", { method: "PATCH", body: JSON.stringify({ is_suspended: false }) }, T);

// (و) refresh يموت لمستخدم شركة منتهية (الجلسات الطويلة)
const suFresh = await req("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: mvName, password: "Sub423@Test" }) });
// mvName شركته 1 — نستخدم suName: لا يمكنه الدخول أصلًا؛ بدلًا من ذلك: مستخدم شركة 11 كان بجلسة قديمة؟
// نبسّط: إنهاء شركة 11 بلا تحقق refresh (مغطى في E2E سابق) — نتحقق فقط أن refresh المالك يعمل
const ownerRefresh = await fetch(B + "/api/v1/auth/refresh", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ refresh_token: admin.body.data.refresh_token }) });
check("refresh المالك يعمل", ownerRefresh.status === 200);

console.log("\n════════════ P3: حالة الشركة ظاهرة في كل مكان ════════════");
// استخدم جلسة المالك على الشركة 1 (admin لا يزال بشركة 1 — التبديل أعلاه كان توكن مؤقت)
const me = await req("/api/v1/auth/me", {}, T);
const co11Brief = (me.body.data?.scope?.companies ?? []).find((c) => c.id === 11);
check("/me scope.companies تحمل subscription لكل شركة", (me.body.data?.scope?.companies ?? []).every((c) => !!c.subscription && !!c.subscription.status), JSON.stringify(co11Brief));
check("شركة 11 تظهر منتهية في المبدّل", co11Brief?.subscription?.status === "EXPIRED", JSON.stringify(co11Brief?.subscription));

// انتهاء قريبًا: +10 أيام
const d10 = new Date(Date.now() + 10 * 86_400_000).toISOString().slice(0, 10);
await req("/api/v1/admin/companies/11", { method: "PATCH", body: JSON.stringify({ subscription_ends_at: d10 }) }, T);
const me2 = await req("/api/v1/auth/me", {}, T);
const co11Soon = (me2.body.data?.scope?.companies ?? []).find((c) => c.id === 11);
check("بعد تمديد 10 أيام → EXPIRING_SOON في المبدّل", co11Soon?.subscription?.status === "EXPIRING_SOON" && co11Soon.subscription.days_left >= 10 && co11Soon.subscription.days_left <= 11, JSON.stringify(co11Soon?.subscription));

// قائمة الشركات للوحة المالك تحمل الحالة أيضًا (العمود الموجود)
const companies = await req("/api/v1/admin/companies", {}, T);
check("GET /admin/companies يعيد subscription لكل شركة", (companies.body.data ?? []).every((c) => !!c.subscription?.status));

console.log("\n════════════ الاستعادة ════════════");
await req("/api/v1/admin/companies/11", { method: "PATCH", body: JSON.stringify({ subscription_ends_at: null, is_suspended: false }) }, T);
const restored = await db.company.findUnique({ where: { id: 11 }, select: { subscriptionEndsAt: true, isSuspended: true } });
check("شركة 11 عادت OPEN", restored.subscriptionEndsAt === null && restored.isSuspended === false);
// حذف مستخدمي الاختبار (تنظيف — الحذف يعمل عبر الشركات للمالك بعد الإصلاح)
// ملاحظة: مستخدم سابق (28) تبقى من تشغيلة فاشلة — يُنظف أيضًا
const stale = await db.user.findFirst({ where: { username: { startsWith: "sub423_" }, deletedAt: null }, select: { id: true } });
for (const uid of [suId, mv.body.data?.id, stale?.id].filter(Boolean)) {
  await req(`/api/v1/admin/users/${uid}`, { method: "DELETE" }, T);
}
const left = await db.user.count({ where: { username: { contains: "423_" }, deletedAt: null } });
check("تنظيف مستخدمي الاختبار (حذف عبر الشركات للمالك)", left === 0, `left=${left}`);
await db.$disconnect();

console.log(`\n════════════ النتيجة: ${pass}/${pass + fail} ════════════`);
if (failures.length) { console.log("الفحوصات الفاشلة:"); for (const f of failures) console.log("  - " + f); process.exit(1); }
