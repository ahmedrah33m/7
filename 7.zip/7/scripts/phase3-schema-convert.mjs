// =====================================================================
// Phase 3 — schema.prisma Float → Decimal converter
// تصنيف صريح لكل حقل Float في المخطط (لا استنتاج تلقائي):
//   MONEY → Decimal (18,4) · QTY → Decimal (18,6)
//   RATE  → Decimal (18,6) · PCT → Decimal (9,4)
//   GPS (checkinLat/checkinLng) تبقى Float — ليست حقولاً مالية.
// SQLite: العمود DECIMAL (NUMERIC affinity) — الدقة مفروضة على مستوى
// التطبيق عبر src/lib/decimal.ts (سياسة R1-R10). إنتاج PostgreSQL يضيف
// @db.Decimal(18,4)/(18,6)/(9,4) بنفس الأسماء (راجع docs/PHASE3_*).
// =====================================================================
import { readFileSync, writeFileSync } from "node:fs";

const SCHEMA = "/home/z/my-project/prisma/schema.prisma";
const OUT = SCHEMA; // in-place (نسخة أصلية محفوظة في backups/phase3/)

const MONEY = "MONEY", QTY = "QTY", RATE = "RATE", PCT = "PCT", GPS = "GPS";

/** خريطة model.field → التصنيف (الاستنتاج ممنوع — كل حقل موثق صراحة). */
const MAP = {
  Product: { packQty: QTY, packSalePrice: MONEY, costPrice: MONEY, salePrice: MONEY, taxRatePct: PCT, minStock: QTY },
  ProductPrice: { amount: MONEY },
  Customer: { creditLimit: MONEY, balance: MONEY, discountPct: PCT },
  Supplier: { balance: MONEY },
  StockBalance: { qty: QTY },
  StockMovement: { qty: QTY, unitCost: MONEY, balanceAfter: QTY },
  SalesInvoice: { subtotal: MONEY, discountTotal: MONEY, taxTotal: MONEY, grandTotal: MONEY, paidAmount: MONEY, previousBalance: MONEY, newBalance: MONEY, creditLimitSnap: MONEY, exchangeRate: RATE },
  SalesInvoiceLine: { qty: QTY, orderedQty: QTY, packageQty: QTY, looseQty: QTY, packageConversion: QTY, packagePrice: MONEY, unitPrice: MONEY, unitCost: MONEY, discountPct: PCT, discountAmount: MONEY, taxAmount: MONEY, lineTotal: MONEY, stockBefore: QTY, stockAfter: QTY, priceExchangeRate: RATE },
  SalesOrder: { subtotal: MONEY, discountTotal: MONEY, taxTotal: MONEY, grandTotal: MONEY },
  SalesOrderLine: { qty: QTY, unitPrice: MONEY, discountPct: PCT, lineTotal: MONEY },
  Cashbox: { balance: MONEY },
  CashTransaction: { amount: MONEY, balanceAfter: MONEY },
  PurchaseInvoice: { subtotal: MONEY, grandTotal: MONEY, paidAmount: MONEY },
  PurchaseInvoiceLine: { qty: QTY, unitCost: MONEY, lineTotal: MONEY },
  SalesReturn: { totalAmount: MONEY, refundCash: MONEY, creditNote: MONEY },
  SalesReturnLine: { qty: QTY, unitPrice: MONEY, lineTotal: MONEY },
  StockTransferLine: { qty: QTY },
  CommissionRule: { rate: PCT, amount: MONEY, perUnitRate: MONEY, minInvoiceTotal: MONEY },
  Commission: { baseAmount: MONEY, totalQty: QTY, amount: MONEY },
  RepTarget: { targetAmount: MONEY },
  Visit: { checkinLat: GPS, checkinLng: GPS, orderValue: MONEY },
  B2BOrder: { subtotal: MONEY, grandTotal: MONEY },
  B2BOrderLine: { qty: QTY, unitPrice: MONEY, lineTotal: MONEY },
  Stocktake: { diffValue: MONEY },
  StocktakeLine: { systemQty: QTY, countedQty: QTY, diffQty: QTY, unitCost: MONEY },
  Quotation: { subtotal: MONEY, discountTotal: MONEY, taxTotal: MONEY, grandTotal: MONEY },
  QuotationLine: { qty: QTY, unitPrice: MONEY, discountPct: PCT, lineTotal: MONEY },
  Package: { originalQty: QTY, remainingQty: QTY },
  PackagingLedger: { openingQty: QTY, issuedQty: QTY, remainingQty: QTY },
};

const KIND_LABEL = {
  MONEY: "money 18,4",
  QTY: "qty 18,6",
  RATE: "rate 18,6",
  PCT: "pct 9,4",
};

const src = readFileSync(SCHEMA, "utf8");
const lines = src.split("\n");

let model = null;
let converted = 0;
const skipped = [];
const out = lines.map((line) => {
  const m = line.match(/^model\s+(\w+)/);
  if (m) { model = m[1]; return line; }

  if (!model || !/\bFloat\b/.test(line)) return line;

  const f = line.match(/^\s+(\w+)\s+/);
  if (!f) return line;
  const field = f[1];
  const kind = MAP[model]?.[field];
  if (!kind) { skipped.push(`${model}.${field}`); return line; }
  if (kind === GPS) return line; // GPS ليست مالية — تبقى Float

  // Float? → Decimal? · Float → Decimal (يحافظ على ? والباقي كما هو)
  const replaced = line.replace(/\bFloat\?/, `Decimal?`).replace(/\bFloat\b/, `Decimal`);
  converted++;
  const tag = `PG: DECIMAL(${KIND_LABEL[kind]})`;
  // علّق الدقة الهدف لإنتاج PostgreSQL — التعليق يجب أن يبقى داخل //
  const commentIdx = replaced.indexOf("//");
  if (commentIdx === -1) {
    return `${replaced.trimEnd()} // ${tag}`;
  }
  const head = replaced.slice(0, commentIdx).trimEnd();
  const tail = replaced.slice(commentIdx).replace(/^\/\/\s*/, "");
  return `${head} // ${tag} — ${tail}`;
});

let text = out.join("\n");
// حدّث ملاحظة المخطط أيضًا داخل النص النهائي (سطور NOTE الأخرى)
text = text.replace(
  "// NOTE: SQLite subset — money/qty use Float; production PostgreSQL 16\n// schema (deploy package) keeps DECIMAL(18,4) with identical names.",
  "// NOTE: Phase 3 — money/qty/rate/pct are Decimal (policy in src/lib/decimal.ts):\n//   MONEY 18,4 · QTY 18,6 · RATE 18,6 · PCT 9,4 · GPS stays Float.\n// SQLite: DECIMAL column (NUMERIC affinity) — precision enforced by app\n// rounding policy. PostgreSQL deploy adds @db.Decimal(...) same names.",
);

writeFileSync(OUT, text, "utf8");
console.log(`converted Float fields: ${converted}`);
console.log(`kept Float (GPS): 2 (Visit.checkinLat, Visit.checkinLng)`);
if (skipped.length) {
  console.log("SKIPPED (خارج الخريطة — راجع يدويًا):");
  for (const s of skipped) console.log("  -", s);
}
