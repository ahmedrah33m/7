#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""E2E test: create CASH invoice → verify stock → void → verify reversal."""
import json
import urllib.request
import urllib.error

TOKEN = open("/tmp/tok.txt").read().strip()
BASE = "http://localhost:3000"


def req(path, data=None, method="GET"):
    r = urllib.request.Request(BASE + path, method=method)
    r.add_header("Authorization", "Bearer " + TOKEN)
    body = None
    if data is not None:
        r.add_header("Content-Type", "application/json")
        body = json.dumps(data).encode()
    try:
        with urllib.request.urlopen(r, body, timeout=180) as resp:
            return json.load(resp)
    except urllib.error.HTTPError as e:
        return {"http_status": e.code, **json.load(e)}


def main():
    me = req("/api/v1/auth/me")["data"]
    whs = me["warehouses"]
    assert whs, "no warehouses in session"

    # pick a product+warehouse pair that actually holds stock
    balances = req("/api/v1/inventory/balances?per_page=100")["data"]
    bal = next((b for b in balances if b.get("qty", 0) > 3), None)
    assert bal, "no stock balance with qty > 3"
    p = {"id": bal["product_id"], "code": bal["product_code"], "name": bal["product_name"]}
    wh = {"id": bal["warehouse"]["id"], "name": bal["warehouse"]["name"]}
    print(f"product: {p['code']} {p['name']} | warehouse: {wh['id']} {wh['name']} | qty={bal['qty']}")

    custs = req("/api/v1/customers?per_page=10")["data"]
    c = next((x for x in custs if x.get("status", "ACTIVE") != "BLOCKED"), custs[0])
    print(f"customer: {c['code']} {c['name']}")

    # ---- 1. create CASH invoice (1 unit, POSTED immediately) ----
    created = req("/api/v1/sales/invoices", {
        "customer_id": c["id"],
        "warehouse_id": wh["id"],
        "type": "CASH",
        "payment_method": "CASH",
        "lines": [{"product_id": p["id"], "qty": 1}],
    }, "POST")
    assert created.get("success"), f"create failed: {created}"
    inv = created["data"]
    inv_id = inv["id"] if isinstance(inv, dict) and "id" in inv else created["data"].get("invoice", {}).get("id")
    print(f"created invoice: {json.dumps(inv, ensure_ascii=False)[:200]}")

    # ---- 2. check stock decreased ----
    detail = req(f"/api/v1/sales/invoices/{inv_id}")["data"]
    line = detail["lines"][0]
    print(f"detail: number={detail['number']} status={detail['status']} stock {line['stock_before']} -> {line['stock_after']}")
    assert detail["status"] == "POSTED", f"expected POSTED got {detail['status']}"
    assert line["stock_after"] == line["stock_before"] - 1, "stock not decremented"

    # ---- 3. VOID the invoice ----
    voided = req(f"/api/v1/sales/invoices/{inv_id}/void", {"reason": "اختبار وظيفي للإلغاء"}, "POST")
    print(f"void result: {json.dumps(voided, ensure_ascii=False)[:200]}")
    assert voided.get("success"), f"void failed: {voided}"
    assert voided["data"]["status"] == "VOID"
    assert voided["data"]["stock_reversed"] is True

    # ---- 4. verify stock restored + status VOID ----
    detail2 = req(f"/api/v1/sales/invoices/{inv_id}")["data"]
    l2 = detail2["lines"][0]
    print(f"after void: status={detail2['status']} stock {l2['stock_before']} -> {l2['stock_after']}")
    assert detail2["status"] == "VOID"
    assert l2["stock_after"] == l2["stock_before"] + 1, "stock not restored"

    # ---- 5. double-void must fail with VAL_004 ----
    again = req(f"/api/v1/sales/invoices/{inv_id}/void", {"reason": "x"}, "POST")
    print(f"double-void: success={again.get('success')} code={again.get('code')} msg={again.get('message', '')[:60]}")
    assert not again.get("success") and again.get("code") == "VAL_004"

    # ---- 6. VOID filter in list now shows 1 ----
    lst = req("/api/v1/sales/invoices?per_page=5&status=VOID")
    s = lst["meta"]["summary"]
    print(f"VOID summary: {json.dumps(s)}")
    assert s["count"] >= 1

    print("\n=== ALL E2E INVOICE DEVELOPMENT TESTS PASSED ===")


if __name__ == "__main__":
    main()
