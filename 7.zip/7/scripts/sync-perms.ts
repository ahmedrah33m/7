import { db } from "../src/lib/db";
import { allPermissions } from "../src/lib/permissions-catalog";
import { syncOwnerPermissions } from "../src/lib/seed";

async function main() {
  await syncOwnerPermissions((m: string) => console.log(m));
  const all = [...allPermissions()];
  console.log("Total permissions:", all.length);
  const finance = all.filter(p => p.module === "finance");
  console.log("Finance permissions:", finance.length);
  const newOnes = all.filter(p => ["close", "reopen", "reconcile", "allocate"].includes(p.action));
  console.log("New lifecycle permissions:", newOnes.length);
  newOnes.forEach(p => console.log("  ", p.code));
  await db.$disconnect();
}
main().catch((e) => { console.error(e); process.exit(1); });
