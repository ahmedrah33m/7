/**
 * فحص قاعدة البيانات: شركة لوميره + أسعار الصرف المستخدمة + إعدادات
 * Task: USD-COST / product pricing inspection
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  // 1) الشركات
  const companies = await db.company.findMany({
    where: { deletedAt: null },
    select: { id: true, name: true, currencyCode: true },
    orderBy: { id: "asc" },
  });
  console.log("=== الشركات ===");
  for (const c of companies) console.log(`${c.id}\t${c.name}\tcurrency=${c.currencyCode}`);

  // 2) شركة لوميره
  const lum = companies.find((c) => c.name.includes("لومي") || /lum/i.test(c.name));
  console.log("\n=== لوميره ===", lum ?? "غير موجودة");

  if (lum) {
    // 3) فواتير USD السابقة لمعرفة سعر الصرف المتعارف عليه
    const rates = await db.salesInvoice.findMany({
      where: { companyId: lum.id, currencyCode: "USD", exchangeRate: { not: null } },
      select: { exchangeRate: true, createdAt: true },
      orderBy: { id: "desc" },
      take: 10,
    });
    console.log("\n=== آخر أسعار صرف مستخدمة في فواتير الدولار ===");
    for (const r of rates) console.log(`rate=${r.exchangeRate} at ${r.createdAt.toISOString()}`);

    // 4) الإعدادات (بحث عن معدل صرف مخزن)
    const settings = await db.setting.findMany({
      where: { companyId: lum.id },
      select: { key: true, value: true },
    });
    console.log("\n=== إعدادات الشركة ===");
    for (const s of settings) console.log(`${s.key} = ${s.value}`);

    // 5) منتجات موجودة بنفس الاسم (منع التكرار)
    const dup = await db.product.findMany({
      where: { companyId: lum.id, deletedAt: null, name: { contains: "شامبو" } },
      select: { id: true, code: true, name: true, packQty: true, packSalePrice: true, salePrice: true, costPrice: true },
    });
    console.log("\n=== منتجات شامبو موجودة ===", dup.length ? dup : "لا شيء");

    // 6) عيّنة من منتجات الشركة الحالية لمعرفة مستويات الأسعار المعتادة
    const sample = await db.product.findMany({
      where: { companyId: lum.id, deletedAt: null },
      select: { code: true, name: true, salePrice: true, costPrice: true, packUnit: true, packQty: true, packSalePrice: true },
      take: 8,
      orderBy: { id: "desc" },
    });
    console.log("\n=== عينة منتجات لوميره ===");
    for (const p of sample) console.log(JSON.stringify(p));
  }
}

main()
  .catch((e) => {
    console.error("INSPECT_ERROR:", e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
