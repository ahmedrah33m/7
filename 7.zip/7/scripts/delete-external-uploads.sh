#!/usr/bin/env bash
# =============================================================
# delete-external-uploads.sh — محاولة حذف الملفات المرفوعة خارجياً
# gofile: حساب ضيف + DELETE (قد يفشل لأن الرفع كان مجهولاً)
# filebin: DELETE مباشر (قد يفشل — الصلاحية 6 أيام تلقائياً)
# ثم فحص حالة كل الروابط
# =============================================================
set -uo pipefail
UA="Mozilla/5.0 (X11; Linux x86_64) SDS-Uploader/1.0"
say() { echo -e "\n\033[1;36m==> $*\033[0m"; }
ok()  { echo -e "\033[1;32m✔ $*\033[0m"; }
bad() { echo -e "\033[1;31m✘ $*\033[0m"; }

GO_IDS=("0u2GDq7J" "tUNWQI3y" "vjzSJNdE")
FB_BIN="sds-v4-1789514953"

# ---------- gofile: حساب ضيف ثم حذف ----------
say "gofile: إنشاء حساب ضيف للحصول على توكن…"
TOKEN="$(curl -s -m 30 -X POST https://api.gofile.io/accounts 2>/dev/null | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"]["token"])' 2>/dev/null || true)"
if [ -n "${TOKEN:-}" ]; then
  ok "توكن ضيف حُصل عليه"
  for ID in "${GO_IDS[@]}"; do
    say "gofile: محاولة حذف المحتوى $ID…"
    R="$(curl -s -m 30 -X DELETE "https://api.gofile.io/contents/${ID}" \
        -H "Authorization: Bearer ${TOKEN}" \
        -H "Content-Type: application/json" 2>/dev/null || true)"
    echo "  الرد: ${R:0:200}"
    R2="$(curl -s -m 30 -X DELETE "https://api.gofile.io/contents" \
        -H "Authorization: Bearer ${TOKEN}" \
        -H "Content-Type: application/json" \
        -d "{\"contentsIds\":[\"${ID}\"]}" 2>/dev/null || true)"
    echo "  الرد (صيغة الدفعة): ${R2:0:200}"
    if echo "$R$R2" | grep -q '"status": *"ok"'; then ok "gofile: حُذف $ID"; else bad "gofile: تعذر حذف $ID (الرفع كان مجهولاً بلا ملكية)"; fi
  done
else
  bad "gofile: تعذر إنشاء حساب ضيف"
fi

# ---------- filebin: حذف مباشر ----------
say "filebin: محاولة حذف الملف والصندوق…"
R="$(curl -s -m 30 -A "$UA" -X DELETE "https://filebin.net/${FB_BIN}/sds-system-v4.zip" -o /dev/null -w "%{http_code}" 2>/dev/null || true)"
echo "  حذف الملف: HTTP $R"
R2="$(curl -s -m 30 -A "$UA" -X DELETE "https://filebin.net/${FB_BIN}" -o /dev/null -w "%{http_code}" 2>/dev/null || true)"
echo "  حذف الصندوق: HTTP $R"
if [ "$R" = "200" ] || [ "$R" = "204" ]; then ok "filebin: طُلب حذف الملف"; else bad "filebin: لا حذف مباشر (تنتهي صلاحية الصندوق تلقائياً بعد 6 أيام)"; fi

# ---------- فحص حالة الروابط ----------
say "فحص حالة الروابط بعد المحاولات…"
for U in "https://gofile.io/d/0u2GDq7J" "https://gofile.io/d/tUNWQI3y" "https://gofile.io/d/vjzSJNdE" "https://filebin.net/${FB_BIN}/sds-system-v4.zip"; do
  C="$(curl -s -o /dev/null -m 20 -A "$UA" -w "%{http_code}" -L "$U" 2>/dev/null || echo 000)"
  echo "  $U → HTTP $C"
done
