// =====================================================================
// E2E — ربط المستخدم بشركة معينة (Company binding):
//   أ) الإنشاء مع company_id صريح + العزل
//   ب) حواجز النطاق (شركة خارج النطاق SCOPE_004)
//   ج) النقل بين الشركات (تنظيف المنح + إعادة ربط الأدوار)
//   د) حواجز النقل (نقل النفس PERM_001 / فرع شركة أخرى SCOPE_003)
// =====================================================================
const BASE = "http://localhost:3000";
let pass = 0, fail = 0;
const failures: string[] = [];

function check(name: string, cond: boolean, detail = "") {
  if (cond) { pass++; console.log(`  ✅ ${name}`); }
  else { fail++; failures.push(name); console.log(`  ❌ ${name} ${detail}`); }
}

async function api(path: string, token: string, method = "GET", body?: unknown) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: body ? JSON.stringify(body) : undefined,
  });
  let json: any = null;
  try { json = await res.json(); } catch { /* empty */ }
  return { status: res.status, body: json };
}

console.log("🔐 دخول admin...");
const loginRes = await fetch(`${BASE}/api/v1/auth/login`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ username: "admin", password: "Admin@123" }),
});
const login = await loginRes.json();
const token = login?.data?.access_token ?? login?.data?.accessToken;
check("دخول admin ناجح", Boolean(token));
if (!token) process.exit(1);

// ---- أ) GET يحوي بيانات الشركة -------------------------------------
console.log("\n📋 أ) قائمة المستخدمين تعرض الشركة المرتبطة");
const listRes = await api("/api/v1/admin/users", token);
const users = listRes?.body?.data ?? [];
check("GET /admin/users يعمل", listRes.status === 200 && Array.isArray(users));
check("كل صف يحمل company_id + company_name", users.length > 0 && users.every((u: any) => typeof u.company_id === "number" && typeof u.company_name === "string"));
console.log(`     نموذج: ${users[0]?.username} → ${users[0]?.company_name}`);

// الشركات المتاحة للجلسة
const meRes = await api("/api/v1/auth/me", token);
const scope = meRes?.body?.data?.scope ?? {};
const companies: { id: number; code: string; name: string }[] = scope.companies ?? [];
const activeCompanyId: number = scope.active_company_id;
console.log(`     شركات الجلسة: ${companies.map((c) => `${c.id}:${c.code}`).join(", ")} | النشطة: ${activeCompanyId}`);
const targetCompany = companies.find((c) => c.id !== activeCompanyId);
check("توجد شركة ثانية ضمن نطاق الجلسة (للاختبار)", Boolean(targetCompany));

// فروع ومستودعات الشركة النشطة (لإنشاء مستخدم بمنح كاملة ثم نقله)
const brRes = await api("/api/v1/admin/branches", token);
const activeBranches: any[] = (brRes?.body?.data ?? []).map((b: any) => ({ id: b.id, name: b.name }));
const whRes = await api("/api/v1/admin/warehouses", token);
const activeWarehouses: any[] = (whRes?.body?.data ?? []).map((w: any) => ({ id: w.id, name: w.name }));
console.log(`     فروع الشركة النشطة: ${activeBranches.length} | مستودعات: ${activeWarehouses.length}`);

// ---- أ) إنشاء مع ربط صريح لشركة أخرى --------------------------------
console.log(`\n🆕 أ) إنشاء مستخدم مرتبط صريحًا بشركة: ${targetCompany?.name}`);
const stamp = Date.now().toString().slice(-6);
const boundUsername = `e2e_bind_${stamp}`;
const createRes = await api("/api/v1/admin/users", token, "POST", {
  username: boundUsername,
  password: "Bind@12345",
  full_name: "مستخدم مرتبط بشركة أخرى",
  role_code: "VIEWER",
  scope_type: "COMPANY",
  company_id: targetCompany!.id,
});
check("إنشاء مستخدم بـ company_id صريح → 201", createRes.status === 201, JSON.stringify(createRes.body));
check("الاستجابة تحمل company_id = الشركة الهدف", createRes?.body?.data?.company_id === targetCompany!.id);

const listAfterCreate = await api("/api/v1/admin/users", token);
const inActiveList = (listAfterCreate?.body?.data ?? []).some((u: any) => u.username === boundUsername);
check("العزل: لا يظهر في قائمة الشركة النشطة", !inActiveList);

// التبديل للشركة الهدف والتحقق من الظهور
const swRes = await api("/api/v1/auth/switch-company", token, "POST", { company_id: targetCompany!.id });
const tokenB = swRes?.body?.data?.access_token ?? swRes?.body?.data?.accessToken;
check("تبديل الشركة ناجح", Boolean(tokenB));
const listB = await api("/api/v1/admin/users", tokenB ?? token);
const inTargetList = (listB?.body?.data ?? []).find((u: any) => u.username === boundUsername);
check("يظهر في قائمة الشركة الهدف", Boolean(inTargetList));
check("اسم الشركة صحيح في الصف", inTargetList?.company_name === targetCompany!.name);

// ---- ب) حواجز النطاق ------------------------------------------------
console.log("\n🚧 ب) حواجز النطاق");
const outOfScopeCompany = 999; // غير موجودة ولا ضمن النطاق
const forbiddenRes = await api("/api/v1/admin/users", token, "POST", {
  username: `e2e_bad_${stamp}`,
  password: "Bad@12345",
  full_name: "يجب أن يُرفض",
  role_code: "VIEWER",
  company_id: outOfScopeCompany,
});
check("ربط مستخدم بشركة خارج النطاق → SCOPE_004", forbiddenRes.status === 403 && forbiddenRes?.body?.code === "SCOPE_004", `status=${forbiddenRes.status} code=${forbiddenRes?.body?.code}`);

// ---- ج) النقل بين الشركات -------------------------------------------
console.log("\n🔄 ج) نقل مستخدم موجود إلى شركة أخرى");
const moveUsername = `e2e_move_${stamp}`;
const createMove = await api("/api/v1/admin/users", token, "POST", {
  username: moveUsername,
  password: "Move@12345",
  full_name: "مستخدم للنقل بين الشركات",
  role_code: "CASHIER",
  scope_type: "BRANCH",
  branch_ids: activeBranches.slice(0, 1).map((b) => b.id),
  warehouse_ids: activeWarehouses.slice(0, 1).map((w) => w.id),
});
const moveUserId = createMove?.body?.data?.id;
check("إنشاء مستخدم في الشركة النشطة بمنح فروع/مستودعات", createMove.status === 201 && Boolean(moveUserId), JSON.stringify(createMove.body));

const moveRes = await api("/api/v1/admin/users", token, "PATCH", {
  user_id: moveUserId,
  company_id: targetCompany!.id,
  company_ids: [targetCompany!.id],
  branch_ids: [],
  warehouse_ids: [],
});
check("PATCH نقل الشركة → نجاح", moveRes.status === 200, JSON.stringify(moveRes.body));
check("الاستجابة تحمل company_id الجديد", moveRes?.body?.data?.company_id === targetCompany!.id);

const listA2 = await api("/api/v1/admin/users", token);
check("غادر قائمة الشركة الأولى", !(listA2?.body?.data ?? []).some((u: any) => u.username === moveUsername));
const listB2 = await api("/api/v1/admin/users", tokenB ?? token);
const movedRow = (listB2?.body?.data ?? []).find((u: any) => u.username === moveUsername);
check("وصل قائمة الشركة الثانية", Boolean(movedRow));
check("أدواره أعيد ربطها بالشركة الثانية (CASHIER)", Boolean(movedRow?.roles?.some((r: any) => r.code === "CASHIER")));
check("منحه القديم أُلغي (0 فرع/مستودع من الشركة القديمة)", movedRow?.branches?.length === 0 && movedRow?.warehouses?.length === 0);

// ---- د) حواجز النقل --------------------------------------------------
console.log("\n🚧 د) حواجز النقل");
const selfMove = await api("/api/v1/admin/users", token, "PATCH", {
  user_id: 1,
  company_id: targetCompany!.id,
});
check("نقل النفس → PERM_001", selfMove.status === 403 && selfMove?.body?.code === "PERM_001", `status=${selfMove.status} code=${selfMove?.body?.code}`);

// منح فرع لا تملكه الشركة الهدف: جلسة الشركة الثانية + مستخدمها + فرع وهمي
const crossBranch = await api("/api/v1/admin/users", tokenB ?? token, "PATCH", {
  user_id: moveUserId,
  company_id: targetCompany!.id,
  branch_ids: [999999], // فرع وهمي — فحص الملكية يجب أن يرفضه
});
check("منح فرع لا يملكه الشركة الهدف → SCOPE_003", crossBranch.status === 403 && crossBranch?.body?.code === "SCOPE_003", `status=${crossBranch.status} code=${crossBranch?.body?.code}`);

// ---- تنظيف: تعطيل المستخدمين التجريبيين ------------------------------
const t1 = await api("/api/v1/admin/users", tokenB ?? token, "PATCH", { user_id: inTargetList?.id, is_active: false });
const t2 = await api("/api/v1/admin/users", tokenB ?? token, "PATCH", { user_id: moveUserId, is_active: false });
check("تنظيف: تعطيل المستخدمين التجريبيين", t1.status === 200 && t2.status === 200);

console.log("\n" + "=".repeat(50));
console.log(`النتيجة: ${pass} نجاح / ${fail} فشل`);
if (failures.length) { console.log("فشل: " + failures.join(" | ")); process.exit(1); }
