// تشخيص سريع — شكل استجابات admin/companies وadmin/users وadmin/roles
const BASE = "http://localhost:3000";
async function j(path, init = {}, token) {
  const res = await fetch(BASE + path, {
    ...init,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  });
  const body = await res.json().catch(() => ({}));
  return { status: res.status, body };
}
const login = await j("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ username: "admin", password: "Admin@123" }) });
const t = login.body?.data?.access_token;
console.log("login:", login.status, !!t);

const companies = await j("/api/v1/admin/companies", {}, t);
console.log("GET companies:", companies.status, JSON.stringify(companies.body).slice(0, 500));

const create = await j("/api/v1/admin/companies", { method: "POST", body: JSON.stringify({ code: "CO-B", name: "شركة B للتوزيع والتجارة" }) }, t);
console.log("POST companies:", create.status, JSON.stringify(create.body).slice(0, 400));

const users = await j("/api/v1/admin/users?per_page=5", {}, t);
console.log("GET users:", users.status, JSON.stringify(users.body).slice(0, 400));

const roles = await j("/api/v1/admin/roles", {}, t);
console.log("GET roles:", roles.status, JSON.stringify(roles.body).slice(0, 400));
