/** فحص اتساق أسعار منتجات لوميره: sale_price (الحبة) مقابل pack_sale_price ÷ pack_qty */
import { PrismaClient } from "@prisma/client";

const RATE = 1550;

async function main() {
  const db = new PrismaClient();
  const products = await db.product.findMany({
    where: { companyId: 2, deletedAt: null },
    select: { id: true, code: true, name: true, unit: true, packUnit: true, packQty: true, packSalePrice: true, salePrice: true, costPrice: true },
    orderBy: { id: "asc" },
  });
  console.log(`المنتجات: ${products.length}\n`);
  for (const p of products) {
    const derived = p.packQty && p.packSalePrice ? p.packSalePrice / p.packQty : null;
    const consistent = derived != null ? Math.abs(p.salePrice - derived) < 1 : null;
    const flags: string[] = [];
    if (consistent === false) flags.push("سعر الحبة لا يطابق الكارتون÷العدد");
    if (p.salePrice > 0 && p.salePrice < 1000) flags.push("سعر الحبة يبدو رقماً بالدولار (مخزّن دينار!)");
    if (p.packSalePrice != null && p.packSalePrice < 1000) flags.push("سعر العبوة يبدو رقماً بالدولار");
    console.log(
      `${p.code} | ${p.name} | وحدة=${p.unit} | تعبئة=${p.packUnit ?? "-"}×${p.packQty ?? "-"} | ` +
      `عبوة=${p.packSalePrice ?? "-"} ($${p.packSalePrice ? (p.packSalePrice / RATE).toFixed(2) : "-"}) | ` +
      `حبة=${p.salePrice} ($${(p.salePrice / RATE).toFixed(3)}) | ` +
      `مشتق=${derived ? derived.toFixed(2) : "-"} | تكلفة=${p.costPrice} ($${(p.costPrice / RATE).toFixed(2)})` +
      (flags.length ? ` ← ⚠ ${flags.join(" + ")}` : " ✓")
    );
  }
  await db.$disconnect();
}

main();
