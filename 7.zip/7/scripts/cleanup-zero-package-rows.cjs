// تنظيف صفوف الأسعار SALE/PACKAGE الصفرية الموروثة — إغلاقها لا حذفها (تاريخ)
// خلفية: syncProductPrices القديم كان ينشئ صف PACKAGE بمبلغ 0 لكل منتج معبأ
// بلا سعر كرتونة صريح — والخادم كان يفسر 0 كـ«سعر صحيح» فتُباع الكراتين مجانًا.
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();

(async () => {
  const rows = await db.productPrice.findMany({
    where: { priceType: "SALE", unit: "PACKAGE", isActive: true, amount: 0 },
    select: { id: true, productId: true, currency: true },
  });
  console.log(`صفوف SALE/PACKAGE صفرية نشطة: ${rows.length}`);
  if (!rows.length) {
    console.log("لا شيء لتنظيفه ✓");
    return;
  }
  for (const r of rows) {
    const prod = await db.product.findUnique({ where: { id: r.productId }, select: { name: true, code: true } });
    console.log(`  إغلاق #${r.id} — ${prod?.name} (${prod?.code})`);
  }
  const res = await db.productPrice.updateMany({
    where: { id: { in: rows.map((r) => r.id) } },
    data: { isActive: false, effectiveTo: new Date() },
  });
  console.log(`أُغلقت ${res.count} صفًا — الاشتقاق من سعر الحبة يعمل الآن لهذه المنتجات ✓`);
  await db.$disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
