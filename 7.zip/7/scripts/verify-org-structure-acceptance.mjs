// =====================================================================
// PRODUCTION ACCEPTANCE — Multi-Tenant Organizational Structure
// (MASTER PROMPT — الهيكل التنظيمي §65-§77)
//
// Scenario:
//   Company A (لوميره)  : بغداد / البصرة / النجف + مستودعات + مندوب أحمد
//   Company B (CO-B)    : البصرة / النجف / كربلاء + مستودعات + مندوب أحمد
//   ← أسماء متطابقة عمداً: الفروع والمستودعات والمندوبون والعملاء
//
// [§65] Cross-Company   [§66] Same Branch Name    [§67] Same Warehouse Name
// [§68] Same Rep Name   [§69] Same Customer Name [§70] Invoice per company
// [§71] CROSS_COMPANY_TRANSFER                   [§48] SCOPE_006 invoice
// [§61] Search isolation  [§72] Reports isolation [§34] Switcher rule
// =====================================================================
const BASE = "http://localhost:3000";

let pass = 0, fail = 0;
function check(label, ok, extra = "") {
  console.log(`${ok ? "✅" : "❌"} ${label}${extra ? " — " + extra : ""}`);
  ok ? pass++ : fail++;
  if (!ok) process.exitCode = 1;
}

async function j(path, init = {}, token) {
  const res = await fetch(BASE + path, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(init.headers ?? {}),
    },
  });
  const body = await res.json().catch(() => ({}));
  return { status: res.status, body };
}

async function login(username, password) {
  const r = await j("/api/v1/auth/login", {
    method: "POST",
    body: JSON.stringify({ username, password }),
  });
  return r.body?.data?.access_token;
}

// ---------------------------------------------------------------- setup
const tokenA = await login("admin", "Admin@123");
check("دخول admin (شركة A)", !!tokenA);

const meA = await j("/api/v1/auth/me", {}, tokenA);
const companyA = meA.body?.data?.company?.id;
const scopeA = meA.body?.data?.scope ?? {};
const aBranches = scopeA.branches ?? [];
const aWarehouses = scopeA.warehouses ?? [];
const aNajaf = aBranches.find((b) => b.code === "NJF")?.id;
const aMainWh = aWarehouses[0]?.id;

// company B via switch
const companiesList = await j("/api/v1/admin/companies", {}, tokenA);
const compB = (companiesList.body?.data ?? []).find((c) => c.code === "CO-B");
check("شركة B موجودة", !!compB?.id, `id=${compB?.id}`);
const swB = await j("/api/v1/auth/switch-company", {
  method: "POST",
  body: JSON.stringify({ company_id: compB.id }),
}, tokenA);
const tokenB = swB.body?.data?.access_token;
const scopeB = swB.body?.data?.scope ?? {};
const bBranches = scopeB.branches ?? [];
const bWarehouses = scopeB.warehouses ?? [];
const bNajaf = bBranches.find((b) => b.code === "NJF")?.id;
const bMainWh = bWarehouses.find((w) => w.type === "MAIN")?.id;
check("جلسة شركة B جاهزة (فروع/مستودعات)", !!tokenB && bBranches.length > 0 && bWarehouses.length > 0,
  `فروع=${bBranches.length} مستودعات=${bWarehouses.length}`);

// =====================================================================
// [§66] Same branch name — "فرع بغداد" in BOTH companies
// =====================================================================
async function findBranchByCode(token, code) {
  const r = await j("/api/v1/admin/branches", {}, token);
  return (r.body?.data ?? []).find((b) => b.code === code)?.id ?? null;
}
{
  const inA = await j("/api/v1/admin/branches", {
    method: "POST", body: JSON.stringify({ code: "BGW2", name: "فرع بغداد", city: "بغداد" }),
  }, tokenA);
  const idA = inA.status === 201 ? inA.body?.data?.id : await findBranchByCode(tokenA, "BGW2");
  const inB = await j("/api/v1/admin/branches", {
    method: "POST", body: JSON.stringify({ code: "BGW2", name: "فرع بغداد", city: "بغداد" }),
  }, tokenB);
  const idB = inB.status === 201 ? inB.body?.data?.id : await findBranchByCode(tokenB, "BGW2");
  check("§66 — نفس اسم الفرع في الشركتين = سجلان مستقلان", !!idA && !!idB && idA !== idB,
    `A#${idA} B#${idB}`);
}

// =====================================================================
// [§67] Same warehouse name + [§19] chain validation
// =====================================================================
async function findWarehouseByCode(token, code) {
  const r = await j("/api/v1/admin/warehouses", {}, token);
  return (r.body?.data ?? []).find((w) => w.code === code)?.id ?? null;
}
{
  // same name under each company's Najaf branch
  const inA = await j("/api/v1/admin/warehouses", {
    method: "POST",
    body: JSON.stringify({ code: "WH-NJF-A", name: "مستودع النجف", branch_id: aNajaf, type: "BRANCH" }),
  }, tokenA);
  const inB = await j("/api/v1/admin/warehouses", {
    method: "POST",
    body: JSON.stringify({ code: "WH-NJF-B", name: "مستودع النجف", branch_id: bNajaf, type: "BRANCH" }),
  }, tokenB);
  const idA = inA.status === 201 ? inA.body?.data?.id : await findWarehouseByCode(tokenA, "WH-NJF-A");
  const idB = inB.status === 201 ? inB.body?.data?.id : await findWarehouseByCode(tokenB, "WH-NJF-B");
  check("§67 — نفس اسم المستودع في الشركتين = مستودعان مستقلان",
    !!idA && !!idB && idA !== idB, `A#${idA} B#${idB}`);

  // chain violation: create a warehouse in B anchored to A's branch
  const cross = await j("/api/v1/admin/warehouses", {
    method: "POST",
    body: JSON.stringify({ code: "WH-XCO", name: "تسريب", branch_id: aNajaf, type: "BRANCH" }),
  }, tokenB);
  check("§19 — ربط مستودع B بفرع شركة A مرفوض (SCOPE_006)",
    cross.status === 403 && cross.body?.code === "SCOPE_006", `${cross.status} ${cross.body?.code ?? ""}`);

  // warehouse lists stay isolated
  const listA = await j("/api/v1/admin/warehouses", {}, tokenA);
  const listB = await j("/api/v1/admin/warehouses", {}, tokenB);
  const aIds = (listA.body?.data ?? []).map((w) => w.id);
  const bIds = (listB.body?.data ?? []).map((w) => w.id);
  check("§67 — قائمة مستودعات A لا تحوي مستودعات B والعكس",
    aIds.length > 0 && bIds.length > 0 && !aIds.some((id) => bIds.includes(id)),
    `A=${aIds.length} B=${bIds.length}`);
}

// =====================================================================
// [§68] Same rep name — "rep.ahmed / أحمد المندوب" in both companies
// =====================================================================
{
  const dupInB = await j("/api/v1/admin/users", {
    method: "POST",
    body: JSON.stringify({
      username: "rep.ahmed", password: "RepB@12345",
      full_name: "أحمد المندوب", role_code: "SALES_REP", scope_type: "SALES_REP",
      branch_ids: bBranches.map((b) => b.id).slice(0, 1),
    }),
  }, tokenB);
  check("§68 — نفس اسم مستخدم المندوب في B (rep.ahmed) = مستخدم مختلف تماماً",
    dupInB.status === 201 || dupInB.body?.code === "VAL_002", `${dupInB.status}`);

  const usersA = await j("/api/v1/admin/users", {}, tokenA);
  const usersB = await j("/api/v1/admin/users", {}, tokenB);
  const aRep = (usersA.body?.data ?? []).find((u) => u.username === "rep.ahmed");
  const bRep = (usersB.body?.data ?? []).find((u) => u.username === "rep.ahmed");
  check("§68 — المندوبان أحمد (A و B) سجلان منفصلان بمعرفات مختلفة",
    !!aRep && !!bRep && aRep.id !== bRep.id, `A#${aRep?.id} B#${bRep?.id}`);
}

// =====================================================================
// [§69] Same customer name — "متجر النور" in both companies
// =====================================================================
let customerB_id = null, customerB_name = null;
{
  const inA = await j("/api/v1/customers", {
    method: "POST", body: JSON.stringify({ name: "متجر النور" }),
  }, tokenA);
  const inB = await j("/api/v1/customers", {
    method: "POST", body: JSON.stringify({ name: "متجر النور" }),
  }, tokenB);
  customerB_id = inB.body?.data?.id;
  customerB_name = inB.body?.data?.name;
  check("§69 — نفس اسم العميل في الشركتين = عميلان مستقلان",
    inA.status === 201 && inB.status === 201 && inA.body?.data?.id !== customerB_id,
    `A#${inA.body?.data?.id} B#${customerB_id}`);
}

// =====================================================================
// [§70] Invoice numbering restarts per company + invoice isolation
// =====================================================================
let invoiceB_id = null, invoiceB_number = null;
{
  // B has no products yet (fresh tenant) — create one with a name that
  // ALSO exists in A (§37 same-name products are separate records)
  const prodB = await j("/api/v1/products", {
    method: "POST",
    body: JSON.stringify({ name: "زيت دوار الشمس 5 لتر", unit: "كرتون", cost_price: 5000, sale_price: 6000 }),
  }, tokenB);
  check("§37 — نفس اسم المنتج في B = منتج مستقل (بخاصته وسعره ومخزنه)",
    prodB.status === 201 || !!prodB.body?.code, `${prodB.status}`);
  // on re-runs the product already exists → resolve by name from the list
  let productIdB = prodB.body?.data?.id;
  if (!productIdB) {
    const pl = await j("/api/v1/products?per_page=100", {}, tokenB);
    productIdB = (pl.body?.data ?? []).find((p) => p.name === "زيت دوار الشمس 5 لتر")?.id;
  }

  // bring stock in first (purchase 10 units) — only when stock is empty
  const try0 = await j("/api/v1/sales/invoices", {
    method: "POST",
    body: JSON.stringify({
      customer_id: customerB_id, warehouse_id: bMainWh, type: "CASH",
      sale_type: "CASH", payment_method: "CASH", paid_amount: 6000,
      lines: [{ product_id: productIdB, qty: 1 }],
    }),
  }, tokenB);
  if (try0.status === 409 && try0.body?.code === "STOCK_001") {
    const supList = await j("/api/v1/suppliers", {}, tokenB);
    let supId = (supList.body?.data ?? [])[0]?.id;
    if (!supId) {
      const sup = await j("/api/v1/suppliers", {
        method: "POST", body: JSON.stringify({ name: "مورد B الرئيسي" }),
      }, tokenB);
      supId = sup.body?.data?.id;
    }
    const pur = await j("/api/v1/purchases/invoices", {
      method: "POST",
      body: JSON.stringify({
        supplier_id: supId, warehouse_id: bMainWh, type: "CASH", paid_amount: 60000,
        lines: [{ product_id: productIdB, qty: 10, unit_cost: 5000 }],
      }),
    }, tokenB);
    if (pur.status !== 201) console.log(`   ℹ️ شراء المخزون: ${pur.status} ${pur.body?.message ?? ""}`);
  }

  // first-ever invoice in company B → numbering must restart at ...000001
  const inv = try0.status === 201 ? try0 : await j("/api/v1/sales/invoices", {
    method: "POST",
    body: JSON.stringify({
      customer_id: customerB_id, warehouse_id: bMainWh, type: "CASH",
      sale_type: "CASH", payment_method: "CASH", paid_amount: 6000,
      lines: [{ product_id: productIdB, qty: 1 }],
    }),
  }, tokenB);
  invoiceB_id = inv.body?.data?.id;
  invoiceB_number = inv.body?.data?.number;
  check("§70 — أول فاتورة في B تحمل الرقم INV-2026-000001 (ترقيم يبدأ من جديد لكل شركة)",
    inv.status === 201 && /INV-\d{4}-000001$/.test(invoiceB_number ?? ""),
    `${inv.status} ${invoiceB_number ?? inv.body?.message ?? ""}`);

  const listA = await j("/api/v1/sales/invoices?per_page=100", {}, tokenA);
  const aNums = (listA.body?.data ?? []).map((i) => i.number);
  check("§70 — نفس الرقم INV-2026-000001 صالح في A و B دون تعارض (Tenant مختلفان)",
    aNums.includes("INV-2026-000001") && invoiceB_number === "INV-2026-000001",
    `A تحوي 000001: ${aNums.includes("INV-2026-000001")} | B: ${invoiceB_number}`);
}

// =====================================================================
// [§48] Cross-company invoice → SCOPE_006 (CROSS_COMPANY_REFERENCE)
// =====================================================================
{
  const prods = await j("/api/v1/products?per_page=1", {}, tokenA);
  const pid = prods.body?.data?.[0]?.id;
  const cross = await j("/api/v1/sales/invoices", {
    method: "POST",
    body: JSON.stringify({
      customer_id: customerB_id, // B's customer, used from A's session
      warehouse_id: aMainWh, type: "CASH", sale_type: "CASH",
      payment_method: "CASH", paid_amount: 999999999,
      lines: pid ? [{ product_id: pid, qty: 1 }] : [{ product_id: 1, qty: 1 }],
    }),
  }, tokenA);
  check("§48 — فاتورة A بعميل B مرفوضة صراحةً (SCOPE_006)",
    cross.status === 403 && cross.body?.code === "SCOPE_006",
    `${cross.status} ${cross.body?.code ?? ""} ${cross.body?.message ?? ""}`);
}

// =====================================================================
// [§71] CROSS_COMPANY_TRANSFER — A warehouse → B warehouse
// =====================================================================
{
  const prods = await j("/api/v1/products?per_page=1", {}, tokenA);
  const pid = prods.body?.data?.[0]?.id;
  const cross = await j("/api/v1/inventory/transfers", {
    method: "POST",
    body: JSON.stringify({
      from_warehouse_id: aMainWh, to_warehouse_id: bMainWh,
      lines: [{ product_id: pid ?? 1, qty: 1 }],
    }),
  }, tokenA);
  check("§71 — تحويل مستودع A → مستودع B مرفوض (SCOPE_006 CROSS_COMPANY_TRANSFER)",
    cross.status === 403 && cross.body?.code === "SCOPE_006",
    `${cross.status} ${cross.body?.code ?? ""} ${cross.body?.message ?? ""}`);
}

// =====================================================================
// [§25/§61] IDOR + search isolation
// =====================================================================
{
  // A must not read B's invoice directly (no data leak in the 404 either)
  if (invoiceB_id) {
    const idor = await j(`/api/v1/sales/invoices/${invoiceB_id}`, {}, tokenA);
    check("§25 — قراءة فاتورة B (INV-2026-000001) من جلسة A → 404 بلا تسريب",
      idor.status === 404, `${idor.status}`);
    const aNums2 = await j("/api/v1/sales/invoices?per_page=100", {}, tokenA);
    const leaked = (aNums2.body?.data ?? []).some((i) => i.id === invoiceB_id);
    check("§25 — فاتورة B غير ظاهرة في قائمة فواتير A", !leaked);
  } else {
    check("§25 — لا فواتير في B لاختبار IDOR (تخطي)", true);
  }

  // search A for B's exclusive customer name from the earlier isolation run
  const gs = await j("/api/v1/search?q=" + encodeURIComponent(customerB_name ?? "متجر النور"), {}, tokenA);
  // global search groups: { query, groups[{type,title,hits}], total } — A has
  // its OWN "متجر النور" so hits are allowed, but every customer hit id must
  // belong to A's customers only (server-side company filter).
  const sc = await j("/api/v1/customers?q=" + encodeURIComponent("عميل B الحصري"), {}, tokenA);
  const rows = sc.body?.data ?? [];
  check("§61 — بحث A لا يُظهر عملاء B",
    Array.isArray(rows) && rows.length === 0, `نتائج=${Array.isArray(rows) ? rows.length : "?"}`);
  check("§61 — البحث الشامل يعمل ضمن الشركة فقط",
    gs.status === 200 && typeof gs.body?.data?.total === "number", `total=${gs.body?.data?.total}`);
}

// =====================================================================
// [§72] Reports isolation — sales-by-customer-type per company
// =====================================================================
{
  const rA = await j("/api/v1/reports/sales-by-customer-type", {}, tokenA);
  const rB = await j("/api/v1/reports/sales-by-customer-type", {}, tokenB);
  check("§72 — تقارير نوع العميل تعمل لكل شركة بمعزل",
    rA.status === 200 && rB.status === 200, `${rA.status}/${rB.status}`);
}

// =====================================================================
// [§34] Company Switcher rule — single-company user sees ONE company
// =====================================================================
{
  const tokenCashier = await login("cashier", "Cashier@123");
  const me = await j("/api/v1/auth/me", {}, tokenCashier);
  const comps = me.body?.data?.scope?.companies ?? [];
  check("§34 — مستخدم شركة واحدة: قائمة الشركات = شركة واحدة (المبدّل مخفي)",
    comps.length === 1, `companies=${comps.length}`);
}

// =====================================================================
// [§76] No global business entities — every list is company-bound
// =====================================================================
{
  const [prodA, prodB] = await Promise.all([
    j("/api/v1/products?per_page=100", {}, tokenA),
    j("/api/v1/products?per_page=100", {}, tokenB),
  ]);
  const aIds = (prodA.body?.data ?? []).map((p) => p.id);
  const bIds = (prodB.body?.data ?? []).map((p) => p.id);
  const overlap = aIds.filter((id) => bIds.includes(id));
  check("§76 — المنتجات بلا كيانات عالمية (لا تداخل بين A و B)",
    aIds.length > 0 && overlap.length === 0, `A=${aIds.length} B=${bIds.length} متداخل=${overlap.length}`);
}

console.log(`\n==========================================================`);
console.log(`قبول الهيكل التنظيمي (§65-77): ${pass} ناجح / ${fail} فاشل`);
console.log(`==========================================================`);
