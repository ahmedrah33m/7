// تحقق v14 — تشغيل ensureCashKeeperAccounts على قاعدة البيانات الحقيقية
// ثم فحص وجود الدور والمستخدم والصلاحيات.
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const { ensureCashKeeperAccounts } = await import("../src/lib/seed");
  const logs: string[] = [];
  const log = (m: string) => { logs.push(m); console.log(m); };
  await ensureCashKeeperAccounts(log);

  const companies = await db.company.findMany({ where: { deletedAt: null }, select: { id: true, name: true } });
  for (const c of companies) {
    const role = await db.role.findFirst({
      where: { companyId: c.id, code: "CASH_KEEPER", deletedAt: null },
      include: { permissions: { include: { permission: true } } },
    });
    const user = await db.user.findFirst({
      where: { companyId: c.id, username: "cashkeeper", deletedAt: null },
      include: { roles: true },
    });
    console.log(`\n— شركة ${c.id} (${c.name}):`);
    console.log(`  دور CASH_KEEPER: ${role ? "موجود ✓" : "مفقود ✗"} · صلاحياته: ${role?.permissions.map((rp) => rp.permission.code).join(", ")}`);
    console.log(`  مستخدم cashkeeper: ${user ? `موجود ✓ (${user.fullName}, scope=${user.scopeType})` : "مفقود ✗"} · أدواره: ${user?.roles.length ?? 0}`);
  }
}
main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
