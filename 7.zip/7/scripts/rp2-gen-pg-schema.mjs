// =====================================================================
// RP2 — توليد prisma/schema.postgresql.prisma من schema.prisma
// سياسة الدقة المعتمدة (MASTER REPAIR PROMPT — PHASE 2 §2/§4):
//   MONEY          → @db.Decimal(18,4)   (الافتراضي لكل Decimal غير المصنف)
//   QUANTITY       → @db.Decimal(18,6)   (qtys/quantities/remaining…)
//   EXCHANGE_RATE  → @db.Decimal(18,6)   (exchangeRate/usdRate/*Rate)
//   PERCENTAGE     → @db.Decimal(9,4)    (*Pct/percent)
// التصنيف بالاسم (نفس دلالات R1-R10 في التطبيق) — لا تعتمد على comments.
// =====================================================================
import { readFileSync, writeFileSync } from "node:fs";

const SRC = "prisma/schema.prisma";
const OUT = "prisma/schema.postgresql.prisma";
let src = readFileSync(SRC, "utf8");

// 1) المزود
src = src.replace(/provider\s*=\s*"sqlite"/, 'provider = "postgresql"');

// 2) تصنيف كل حقل Decimal وإضافة @db.Decimal(...)
// نعالج سطور الحقول فقط (تبدأ بمسافات + identifier + type)
const classify = (fieldName) => {
  const f = fieldName.toLowerCase();
  if (f.endsWith("pct") || f.includes("pct") || f.includes("percent")) return "9,4";      // PERCENTAGE
  if (f === "exchangerate" || f.endsWith("rate") || f.includes("usdrate")) return "18,6"; // EXCHANGE_RATE
  if (f.includes("qty") || f.includes("quantity") || f === "packqty" || f.endsWith("remaining")) return "18,6"; // QUANTITY
  return "18,4";                                                                          // MONEY
};

const lines = src.split("\n");
const out = [];
let inModel = false;
let fieldCount = 0, classCounts = { "18,4": 0, "18,6": 0, "9,4": 0 };
for (let i = 0; i < lines.length; i++) {
  let line = lines[i];
  if (/^model\s+\w+/.test(line)) inModel = true;
  else if (/^}/.test(line)) inModel = false;

  const fm = inModel && line.match(/^(\s+)(\w+)\s+(.+?)(\s{2,}.*|)$/);
  if (fm && /^\s*(Decimal|Decimal\?)/.test(fm[3]) && !line.includes("@db.Decimal")) {
    const precision = classify(fm[2]);
    classCounts[precision]++;
    fieldCount++;
    // أدخل @db.Decimal(p) بعد النوع مباشرة (قبل باقي الخصائص)
    line = line.replace(/(Decimal\??)/, `$1 @db.Decimal(${precision})`);
  }
  out.push(line);
}
writeFileSync(OUT,
  "// =====================================================================\n" +
  "// RP2 — PostgreSQL PRODUCTION SCHEMA (مولَّد من schema.prisma — لا يُعدَّل يدوياً)\n" +
  "// سياسة الدقة: MONEY Decimal(18,4) · QUANTITY/EXCHANGE_RATE Decimal(18,6) · PERCENTAGE Decimal(9,4)\n" +
  "// الاستخدام: DATABASE_URL=postgresql://… bunx prisma db push --schema prisma/schema.postgresql.prisma\n" +
  "// الترحيل: scripts/rp2-migrate-sqlite-to-pg.mjs (الخطة: docs/RP2_POSTGRESQL_PLAN.md)\n" +
  "// =====================================================================\n\n" +
  out.join("\n"));
console.log(`generated ${OUT}: ${fieldCount} Decimal fields annotated`);
console.log(`  MONEY 18,4  = ${classCounts["18,4"]}`);
console.log(`  QTY/RATE 18,6 = ${classCounts["18,6"]}`);
console.log(`  PCT 9,4 = ${classCounts["9,4"]}`);
