// =====================================================================
// Damage (التالف) acceptance suite — dedicated damage flow:
//   · POST /inventory/damages posts immutable OUT movement refType=DAMAGE
//     valued at cost price with mandatory reason
//   · stock_balances derived only via movement engine (no manual edits)
//   · warehouse scope (SCOPE_002), validation (VAL_002/STOCK_001),
//     damage ledger GET, audit trail
// Exit 0 = all pass.
// =====================================================================

import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000/api/v1";
const db = new PrismaClient();

let pass = 0;
let fail = 0;

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  ✅ ${name}`);
  } else {
    fail++;
    console.log(`  ❌ ${name} ${detail ? "— " + detail : ""}`);
  }
}

async function req(method: string, path: string, token?: string, body?: unknown): Promise<{ status: number; body: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json };
}

async function main() {
  console.log("═══ Damage (التالف) verification ═══");

  // 0) logins
  const admin = await req("POST", "/auth/login", undefined, { username: "admin", password: "Admin@123" });
  check("admin login", admin.status === 200 && admin.body.success);
  const T = admin.body.data?.access_token as string;

  const cashier = await req("POST", "/auth/login", undefined, { username: "cashier", password: "Cashier@123" });
  check("cashier login", cashier.status === 200);
  const CT = cashier.body.data?.access_token as string;

  // 1) pick a product and ensure stock via self-provided intake (idempotent re-runs)
  const products = await req("GET", "/products?per_page=100", T);
  const product = (products.body.data ?? [])[0];
  check("products available", !!product?.id);

  const WH_MAIN = 1;
  const intakeQty = 10;
  await req("POST", "/inventory/movements", T, {
    warehouse_id: WH_MAIN, product_id: product.id, direction: "IN", qty: intakeQty, note: "تزويد اختبار التالف",
  });

  const balBeforeRes = await req("GET", `/inventory/balances?warehouse_id=${WH_MAIN}&per_page=200`, T);
  const balRow = (balBeforeRes.body.data ?? []).find((b: any) => b.product_id === product.id);
  const before = balRow?.qty ?? 0;
  check("balance readable before damage", typeof before === "number", `before=${before}`);

  // 2) post damage — happy path
  const dmgQty = 3;
  const dmg = await req("POST", "/inventory/damages", T, {
    warehouse_id: WH_MAIN, product_id: product.id, qty: dmgQty, reason: "تلف بالتخزين", details: "اختبار قبول",
  });
  check("damage post 201", dmg.status === 201, JSON.stringify(dmg.body).slice(0, 160));
  check("damage balance_after = before − qty", dmg.body.data?.balance_after === before - dmgQty,
    `after=${dmg.body.data?.balance_after} expected=${before - dmgQty}`);
  check("damage cost_value = costPrice × qty",
    dmg.body.data?.cost_value === (product.cost_price ?? 0) * dmgQty,
    `cost_value=${dmg.body.data?.cost_value}`);

  // 3) movement row exists — immutable ledger
  const mv = await db.stockMovement.findFirst({
    where: { productId: product.id, warehouseId: WH_MAIN, refType: "DAMAGE" },
    orderBy: { id: "desc" },
  });
  check("movement row refType=DAMAGE direction=OUT", mv?.refType === "DAMAGE" && mv?.direction === "OUT");
  check("movement unitCost = product cost price", Number(mv?.unitCost) === Number(product.cost_price));
  check("movement note carries reason", (mv?.note ?? "").includes("تلف بالتخزين"));

  // 4) damage ledger GET
  const list = await req("GET", "/inventory/damages", T);
  check("damages list 200 + has row", list.status === 200 && (list.body.data?.length ?? 0) >= 1);
  check("damages list row matches posted qty",
    (list.body.data ?? []).some((r: any) => r.product?.code === product.code && r.qty === dmgQty));

  // 5) validation barriers
  const noReason = await req("POST", "/inventory/damages", T, {
    warehouse_id: WH_MAIN, product_id: product.id, qty: 1, reason: "سبب غير معتمد",
  });
  check("invalid reason → 422 VAL_001", noReason.status === 422 && noReason.body.code === "VAL_001",
    JSON.stringify(noReason.body).slice(0, 120));

  const badQty = await req("POST", "/inventory/damages", T, {
    warehouse_id: WH_MAIN, product_id: product.id, qty: 0, reason: "أخرى",
  });
  check("qty=0 → 422 VAL_001", badQty.status === 422 && badQty.body.code === "VAL_001");

  // huge qty beyond stock → STOCK_001 (409 per errors map, unless negative allowed)
  const huge = await req("POST", "/inventory/damages", T, {
    warehouse_id: WH_MAIN, product_id: product.id, qty: before + 999999, reason: "إتلاف إداري",
  });
  check("qty beyond stock → 409 STOCK_001", huge.status === 409 && huge.body.code === "STOCK_001",
    JSON.stringify(huge.body).slice(0, 120));

  // 6) permission barrier — cashier has movements.view only (no create) → PERM_001
  const cashierDmg = await req("POST", "/inventory/damages", CT, {
    warehouse_id: WH_MAIN, product_id: product.id, qty: 1, reason: "أخرى",
  });
  check("cashier without create perm → 403 PERM_001", cashierDmg.status === 403 && cashierDmg.body.code === "PERM_001",
    JSON.stringify(cashierDmg.body).slice(0, 120));

  const anonDmg = await req("POST", "/inventory/damages", undefined, {
    warehouse_id: WH_MAIN, product_id: product.id, qty: 1, reason: "أخرى",
  });
  check("unauthenticated → 401", anonDmg.status === 401, JSON.stringify(anonDmg.body).slice(0, 120));

  // second damage with different reason (multi-row ledger)
  const dmg2 = await req("POST", "/inventory/damages", T, {
    warehouse_id: WH_MAIN, product_id: product.id, qty: 1, reason: "كسر أثناء النقل",
  });
  check("second damage different reason 201", dmg2.status === 201, JSON.stringify(dmg2.body).slice(0, 120));

  // 7) audit trail
  const audits = await req("GET", "/admin/audit-logs?per_page=20", T);
  const dmgAudit = (audits.body.data?.rows ?? audits.body.data ?? []).find(
    (a: any) => a.entity_type === "damage" && JSON.stringify(a.new_values ?? a.newValues ?? "").includes("تلف بالتخزين")
  );
  check("audit log entityType=damage written", !!dmgAudit);

  // 8) balances reflect damage only through movements (before − 3 − 1)
  const balAfterRes = await req("GET", `/inventory/balances?warehouse_id=${WH_MAIN}&per_page=200`, T);
  const balRowAfter = (balAfterRes.body.data ?? []).find((b: any) => b.product_id === product.id);
  check("final balance = before − dmgQty − 1", balRowAfter?.qty === before - dmgQty - 1,
    `final=${balRowAfter?.qty} expected=${before - dmgQty - 1}`);

  // 9) damages list shows both reasons
  const list2 = await req("GET", "/inventory/damages", T);
  const notes = JSON.stringify(list2.body.data ?? []);
  check("ledger carries both reasons", notes.includes("تلف بالتخزين") && notes.includes("كسر أثناء النقل"));

  console.log(`\n═══ Result: ${pass} passed, ${fail} failed ═══`);
  await db.$disconnect();
  process.exit(fail === 0 ? 0 : 1);
}

main().catch((e) => {
  console.error("FATAL", e);
  process.exit(1);
});
