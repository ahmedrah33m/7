// Test-support: top up company-1 cashboxes so cash-purchase tests can run
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const boxes = await db.cashbox.findMany({ where: { companyId: 1, deletedAt: null }, select: { id: true, code: true, balance: true } });
for (const b of boxes) {
  if (b.balance < 2_000_000) {
    await db.cashbox.update({ where: { id: b.id }, data: { balance: 5_000_000 } });
    console.log(`💰 ${b.code}: ${b.balance.toLocaleString()} → 5,000,000`);
  } else console.log(`✓ ${b.code}: ${b.balance.toLocaleString()} (كافٍ)`);
}
await db.$disconnect();
