#!/bin/bash
# Full regression — 14 suites with 70s cooling between them (rate limit 600/min — lesson RATE_001: 120s cooling, 70s flaked phase47)
# Suite passes = exit code 0 (grep-based detection false-positives on test names like LOGIN_FAILED).
cd "$(dirname "$(readlink -f "$0")/..")"
SUITES=(phase0-verify phase47-verify phase89-verify enhancements-verify enhancements2-verify master-data-verify damage-verify branch-isolation-verify gap-closure-verify gap-closure2-verify doc-states-verify users-branches-verify inventory-valuation-verify reports-suite-verify)
FAILED=0
FAILED_NAMES=()
for i in "${!SUITES[@]}"; do
  S="${SUITES[$i]}"
  echo "=== [$((i+1))/14] $S ==="
  OUT=$(bun "scripts/${S}.ts" 2>&1)
  RC=$?
  RESULT_LINE=$(echo "$OUT" | grep -oE "[0-9]+/[0-9]+ ✅|Result: [0-9]+/[0-9]+" | tail -1)
  echo "exit=$RC result=$RESULT_LINE"
  if [ $RC -ne 0 ]; then
    FAILED=$((FAILED+1))
    FAILED_NAMES+=("$S")
    echo "!!! FAILURES in $S:"
    echo "$OUT" | grep -E "❌|FATAL" | head -10
  fi
  if [ $((i+1)) -lt 14 ]; then
    echo "--- cooling 70s ---"
    sleep 120
  fi
done
echo ""
echo "REGRESSION COMPLETE: suites_with_failures=$FAILED / 14 ${FAILED_NAMES[*]:+— failed: ${FAILED_NAMES[*]}}"
