#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
patch-v42-cost-usd.py — ترقيع v4.2: إدخال سعر تكلفة المنتج بالدولار ($)
يُشغَّل من جذر المشروع (مثال: cd ~/kayan && python3 patch-v42-cost-usd.py)
- يتحقق من كل تعديل (يجب أن يُوجد النص الأصلي مرة واحدة بالضبط) — وإلا يفشل بلا مساس بالملف
- يأخذ نسخة احتياطية products-tab.tsx.bak قبل الكتابة
- آمن للتشغيل المتكرر: إن كان الملف مرقّعاً مسبقاً يخرج دون فعل
"""
import sys, os, shutil

TARGET = sys.argv[1] if len(sys.argv) > 1 else "src/components/sales/products-tab.tsx"

R = []  # (old, new)

# ---- 1) مكوّن مبدّل العملة (بعد inputCls) ----
R.append((
'const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";',
'''const inputCls = "h-9 w-full rounded-md border bg-background px-3 text-sm";

/** مبدّل عملة سعر التكلفة (د.ع / $) — الإدخال بالدولار يُحوَّل للدينار عند الحفظ */
function CostCurrencyToggle({ value, onChange }: { value: "IQD" | "USD"; onChange: (c: "IQD" | "USD") => void }) {
  return (
    <div className="flex rounded-md border overflow-hidden" dir="ltr">
      <button type="button" onClick={() => onChange("IQD")}
        className={`px-2 py-0.5 text-[10px] font-bold transition-colors ${value === "IQD" ? "bg-primary text-primary-foreground" : "bg-background text-muted-foreground hover:bg-muted"}`}>
        د.ع
      </button>
      <button type="button" onClick={() => onChange("USD")}
        className={`px-2 py-0.5 text-[10px] font-bold transition-colors ${value === "USD" ? "bg-primary text-primary-foreground" : "bg-background text-muted-foreground hover:bg-muted"}`}>
        $
      </button>
    </div>
  );
}'''))

# ---- 2) الحالات الجديدة (بعد usdRate) ----
R.append((
'  const [usdRate, setUsdRateState] = React.useState<number | "">("");',
'''  const [usdRate, setUsdRateState] = React.useState<number | "">("");
  // ---- عملة سعر التكلفة (د.ع / $) — الإدخال بالدولار ممكن والتحويل للدينار عند الحفظ (عملة الأساس)
  const [costCur, setCostCur] = React.useState<"IQD" | "USD">("IQD");
  const [costVal, setCostVal] = React.useState<string>("");
  const [costRate, setCostRate] = React.useState<string>("");
  const [editCostCur, setEditCostCur] = React.useState<"IQD" | "USD">("IQD");
  const [editCostVal, setEditCostVal] = React.useState<string>("");
  const [editCostRate, setEditCostRate] = React.useState<string>("");'''))

# ---- 3) دالة الإضافة: تحقق + تحويل قبل الحفظ ----
R.append((
'''  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSaving(true);
    const fd = new FormData(e.currentTarget);
    try {''',
'''  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    // سعر التكلفة: إدخال بالدولار ممكن — يحول للدينار (عملة الأساس) قبل الحفظ
    const costRaw = Number(fd.get("cost_price") || 0);
    const costRateN = Number(costRate || 0);
    if (costCur === "USD" && costRaw > 0 && !(costRateN > 0)) {
      toast.error("أدخل سعر الصرف (د.ع لكل $1) لتحويل التكلفة إلى الدينار");
      return;
    }
    const costIqd = costCur === "USD" ? Math.round(costRaw * costRateN * 100) / 100 : costRaw;
    if (costCur === "USD" && costRateN > 0) { setUsdRate(costRateN); setUsdRateState(costRateN); }
    setSaving(true);
    try {'''))

# ---- 4) جسم الإضافة: costIqd ----
R.append((
'''          cost_price: Number(fd.get("cost_price") || 0),
          sale_price: Number(fd.get("sale_price") || 0),
          min_stock: Number(fd.get("min_stock") || 0),
          barcode: fd.get("barcode") || undefined,''',
'''          cost_price: costIqd,
          sale_price: Number(fd.get("sale_price") || 0),
          min_stock: Number(fd.get("min_stock") || 0),
          barcode: fd.get("barcode") || undefined,'''))

# ---- 5) نجاح الإضافة: تصفير الحقول ----
R.append((
'''        setShowForm(false);
        await load();''',
'''        setShowForm(false);
        setCostCur("IQD"); setCostVal(""); setCostRate("");
        await load();'''))

# ---- 6) دالة التعديل: تحقق + تحويل قبل الحفظ ----
R.append((
'''    if (!editing) return;
    setEditingSaving(true);
    const fd = new FormData(e.currentTarget);
    try {''',
'''    if (!editing) return;
    const fd = new FormData(e.currentTarget);
    // سعر التكلفة: إدخال بالدولار ممكن — يحول للدينار (عملة الأساس) قبل الحفظ
    const costRaw = Number(fd.get("cost_price") || 0);
    const costRateN = Number(editCostRate || 0);
    if (editCostCur === "USD" && costRaw > 0 && !(costRateN > 0)) {
      toast.error("أدخل سعر الصرف (د.ع لكل $1) لتحويل التكلفة إلى الدينار");
      return;
    }
    const costIqd = editCostCur === "USD" ? Math.round(costRaw * costRateN * 100) / 100 : costRaw;
    if (editCostCur === "USD" && costRateN > 0) { setUsdRate(costRateN); setUsdRateState(costRateN); }
    setEditingSaving(true);
    try {'''))

# ---- 7) جسم التعديل: costIqd ----
R.append((
'''          cost_price: Number(fd.get("cost_price") || 0),
          sale_price: Number(fd.get("sale_price") || 0),
          min_stock: Number(fd.get("min_stock") || 0),
          is_active: fd.get("is_active") === "on",''',
'''          cost_price: costIqd,
          sale_price: Number(fd.get("sale_price") || 0),
          min_stock: Number(fd.get("min_stock") || 0),
          is_active: fd.get("is_active") === "on",'''))

# ---- 8) نجاح التعديل: تصفير الحقول ----
R.append((
'''        setEditing(null);
        await load();''',
'''        setEditing(null);
        setEditCostCur("IQD"); setEditCostVal(""); setEditCostRate("");
        await load();'''))

# ---- 9) زر التعديل: تهيئة حقول التكلفة ----
R.append((
'onClick={() => { setEditing(p); setShowForm(false); }} aria-label={`تعديل ${p.name}`} title="تعديل المنتج">',
'onClick={() => { setEditing(p); setShowForm(false); setEditCostCur("IQD"); setEditCostVal(String(p.cost_price)); setEditCostRate(""); }} aria-label={`تعديل ${p.name}`} title="تعديل المنتج">'))

# ---- 10) حقل التكلفة في نموذج الإضافة ----
R.append((
'''              <label className="text-xs font-medium space-y-1">سعر التكلفة (د.ع)
                <input name="cost_price" type="number" min="0" step="any" className={inputCls} dir="ltr" />
              </label>''',
'''              <div className="text-xs font-medium space-y-1">
                <div className="flex items-center justify-between gap-2">
                  <span>سعر التكلفة</span>
                  <CostCurrencyToggle value={costCur} onChange={(c) => { if (c === "USD") setCostRate(usdRate === "" ? "" : String(usdRate)); setCostCur(c); }} />
                </div>
                <input name="cost_price" type="number" min="0" step="any" className={inputCls} dir="ltr"
                  value={costVal} onChange={(e) => setCostVal(e.target.value)}
                  placeholder={costCur === "USD" ? "التكلفة بالدولار" : "التكلفة بالدينار"} />
                {costCur === "USD" ? (
                  <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground flex-wrap">
                    <span>سعر الصرف</span>
                    <input name="cost_rate" type="number" min="1" step="any" dir="ltr" key="cost-rate-add"
                      value={costRate} onChange={(e) => setCostRate(e.target.value)}
                      className="h-6 w-20 rounded-md border bg-background px-1.5 text-[10px]" />
                    <span>د.ع لكل $1</span>
                    {costVal !== "" && Number(costVal) > 0 && Number(costRate) > 0 && (
                      <span className="font-semibold text-sky-700 dark:text-sky-400">≈ {formatIQD(Number(costVal) * Number(costRate))} (تُخزَّن بالدينار)</span>
                    )}
                  </div>
                ) : (Number(costVal) > 0 && Number(usdRate) > 0) ? (
                  <div className="text-[10px] text-muted-foreground" dir="ltr">≈ {formatUSD(usdEquivalent(Number(costVal), Number(usdRate)))}</div>
                ) : null}
              </div>'''))

# ---- 11) حقل التكلفة في نموذج التعديل ----
R.append((
'''              <label className="text-xs font-medium space-y-1">سعر التكلفة (د.ع)
                <input name="cost_price" type="number" min="0" step="any" defaultValue={editing.cost_price} className={inputCls} dir="ltr" />
              </label>''',
'''              <div className="text-xs font-medium space-y-1">
                <div className="flex items-center justify-between gap-2">
                  <span>سعر التكلفة</span>
                  <CostCurrencyToggle value={editCostCur} onChange={(c) => {
                    if (c === "USD") {
                      const r = Number(usdRate) || 0;
                      setEditCostRate(usdRate === "" ? "" : String(usdRate));
                      setEditCostVal(r > 0 && editing.cost_price > 0 ? String(usdEquivalent(editing.cost_price, r)) : "");
                    } else {
                      setEditCostVal(String(editing.cost_price));
                    }
                    setEditCostCur(c);
                  }} />
                </div>
                <input name="cost_price" type="number" min="0" step="any" className={inputCls} dir="ltr"
                  value={editCostVal} onChange={(e) => setEditCostVal(e.target.value)}
                  placeholder={editCostCur === "USD" ? "التكلفة بالدولار" : "التكلفة بالدينار"} />
                {editCostCur === "USD" ? (
                  <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground flex-wrap">
                    <span>سعر الصرف</span>
                    <input name="cost_rate" type="number" min="1" step="any" dir="ltr" key="cost-rate-edit"
                      value={editCostRate} onChange={(e) => setEditCostRate(e.target.value)}
                      className="h-6 w-20 rounded-md border bg-background px-1.5 text-[10px]" />
                    <span>د.ع لكل $1</span>
                    {editCostVal !== "" && Number(editCostVal) > 0 && Number(editCostRate) > 0 && (
                      <span className="font-semibold text-sky-700 dark:text-sky-400">≈ {formatIQD(Number(editCostVal) * Number(editCostRate))} (تُخزَّن بالدينار)</span>
                    )}
                  </div>
                ) : (Number(editCostVal) > 0 && Number(usdRate) > 0) ? (
                  <div className="text-[10px] text-muted-foreground" dir="ltr">≈ {formatUSD(usdEquivalent(Number(editCostVal), Number(usdRate)))}</div>
                ) : null}
              </div>'''))


def main():
    if not os.path.exists(TARGET):
        print("✘ الملف غير موجود: " + TARGET + " — شغّل السكربت من جذر المشروع")
        sys.exit(1)
    src = open(TARGET, encoding="utf-8").read()
    if "CostCurrencyToggle" in src:
        print("✔ الملف مرقّع مسبقاً (v4.2) — لا يوجد ما يُفعل")
        return
    out, errors = src, []
    for i, (old, new) in enumerate(R, 1):
        n = out.count(old)
        if n != 1:
            errors.append("تعديل %d: وُجد النص %d مرة بدلاً من مرة واحدة" % (i, n))
            continue
        out = out.replace(old, new, 1)
    if errors:
        print("✘ فشل الترقيع — لم يُمسّ الملف إطلاقاً. الأسباب:")
        for e in errors:
            print("   - " + e)
        print("تأكد أنك تشغّل السكربت من جذر المشروع وأن النسخة v4.0/v4.1")
        sys.exit(1)
    shutil.copyfile(TARGET, TARGET + ".bak")
    with open(TARGET, "w", encoding="utf-8") as f:
        f.write(out)
    print("✔ تم الترقيع بنجاح (11/11) — نسخة احتياطية: " + TARGET + ".bak")
    print("الخطوة التالية: npm run build ثم أعد تشغيل السيرفر (npm run start)")


if __name__ == "__main__":
    main()
