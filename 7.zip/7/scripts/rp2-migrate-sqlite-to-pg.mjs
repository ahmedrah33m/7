// =====================================================================
// RP2 — ناقل البيانات SQLite → PostgreSQL (MASTER REPAIR PROMPT — PHASE 2 §7)
// الاستخدام على سيرفر الإنتاج (يتطلب PostgreSQL حي):
//   1) DATABASE_URL=postgresql://… bunx prisma db push --schema prisma/schema.postgresql.prisma
//   2) PG_URL=postgresql://… bun scripts/rp2-migrate-sqlite-to-pg.mjs [--source path/to/custom.db]
// الخطوات: فحص تطابق الجداول → TRUNCATE → ترتيب طوبولوجي بالأجنبية → إدراج دفعات
//          مع تحويل bool/datetime → setval للتسلسلات → تحقق عدّادات + بصمات مالية
// ملاحظة صحة: هذا السكربت جُهّز هنا ولم يُشغَّل على PG حقيقي (لا PostgreSQL في بيئة
// التطوير) — يلزم تشغيله على سيرفر الإنتاج وتسجيل نتيجته في تقرير القبول النهائي.
// =====================================================================
import pg from "pg";
import { writeFileSync } from "node:fs";

const SRC_PATH = process.argv.includes("--source") ? process.argv[process.argv.indexOf("--source") + 1] : "db/custom.db";

// فتح المصدر readonly — متكيف مع بيئة التشغيل (bun أو node 22+)
let sq;
if (typeof globalThis.Bun !== "undefined") {
  const { Database } = await import("bun:sqlite");
  sq = new Database(SRC_PATH, { readonly: true });
} else {
  const { DatabaseSync } = await import("node:sqlite");
  sq = new DatabaseSync(`file:${SRC_PATH}?mode=ro`, { uri: true });
}

// وضع الفحص الجاف: قراءة المصدر وعدّاداته فقط (لا PostgreSQL مطلوب)
if (process.env.DRY_RUN) {
  const tables = sq.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_prisma_migrations' ORDER BY name`).all().map((r) => r.name);
  const counts = {};
  for (const t of tables) counts[t] = sq.prepare(`SELECT COUNT(*) c FROM "${t}"`).get().c;
  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  console.log(`DRY_RUN: ${tables.length} tables, ${total} rows`);
  console.log("DRY_RUN_OK");
  process.exit(0);
}

const PG_URL = process.env.PG_URL;
if (!PG_URL) { console.error("PG_URL مطلوب (postgresql://…)"); process.exit(1); }
const pgc = new pg.Client({ connectionString: PG_URL });
await pgc.connect();
const tables = sq.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_prisma_migrations' ORDER BY name`).all().map((r) => r.name);
console.log(`sqlite tables: ${tables.length}`);

// ---- تطابق مع الهدف (لازم db push على سكيما PG أولاً)
const { rows: pgTables } = await pgc.query(`SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE'`);
const pgSet = new Set(pgTables.map((r) => r.table_name));
const missing = tables.filter((t) => !pgSet.has(t));
if (missing.length) { console.error(`جداول مفقودة في PG (شغّل db push على schema.postgresql.prisma): ${missing.join(", ")}`); process.exit(1); }

// ---- أعمدة الهدف + أنواعها
const { rows: pgCols } = await pgc.query(`SELECT table_name, column_name, data_type FROM information_schema.columns WHERE table_schema='public'`);
const colInfo = new Map();
for (const r of pgCols) { const k = r.table_name; (colInfo.get(k) ?? colInfo.set(k, []).get(k)).push(r); }

// ---- ترتيب طوبولوجي حسب الأجنبية (الآباء أولاً)
const { rows: fks } = await pgc.query(`
  SELECT tc.table_name AS t, ccu.table_name AS ref
  FROM information_schema.table_constraints tc
  JOIN information_schema.constraint_column_usage ccu ON ccu.constraint_name = tc.constraint_name AND ccu.constraint_schema = tc.constraint_schema
  WHERE tc.constraint_type='FOREIGN KEY' AND tc.table_schema='public' AND ccu.table_name <> tc.table_name`);
const deps = new Map(tables.map((t) => [t, new Set()]));
for (const f of fks) if (deps.has(f.t) && deps.has(f.ref)) deps.get(f.t).add(f.ref);
const order = [], state = new Map();
const visit = (t, stack = new Set()) => {
  if (state.get(t) === "done") return;
  if (stack.has(t)) return; // دورة — يُقبل (insert تأجيلي أو بلا قيد صارم)
  stack.add(t);
  for (const d of deps.get(t) ?? []) visit(d, stack);
  stack.delete(t);
  state.set(t, "done");
  order.push(t);
};
for (const t of tables) visit(t);
console.log(`insert order: ${order.length} tables (topological)`);

// ---- محول القيم
const conv = (v, dataType) => {
  if (v === null || v === undefined) return null;
  if (dataType === "boolean") return v === 1 || v === "1" || v === true ? true : (v === 0 || v === "0" || v === false ? false : null);
  if (dataType && (dataType.startsWith("timestamp") || dataType === "date" || dataType === "time")) {
    if (typeof v === "number") return new Date(v);
    const d = new Date(v);
    return isNaN(d.getTime()) ? null : d;
  }
  if (dataType === "numeric" || dataType === "decimal") return typeof v === "number" ? String(v) : v; // نص دقيق كما هو
  return v;
};

// ---- تفريغ الهدف (إعادة تشغيل نظيفة)
await pgc.query(`SET session_replication_role = replica`).catch(() => console.log("(session_replication_role غير متاح — سيُستخدم الترتيب الطوبولوجي فقط)"));
await pgc.query(`TRUNCATE TABLE ${order.map((t) => `"${t}"`).join(", ")} RESTART IDENTITY CASCADE`);

// ---- الإدراج
const counts = {};
for (const t of order) {
  const rows = sq.prepare(`SELECT * FROM "${t}"`).all();
  counts[t] = rows.length;
  if (!rows.length) continue;
  const cols = Object.keys(rows[0]);
  const pgTypes = new Map((colInfo.get(t) ?? []).map((c) => [c.column_name, c.data_type]));
  const colList = cols.map((c) => `"${c}"`).join(", ");
  const placeholders = cols.map((_, i) => `$${i + 1}`).join(", ");
  const stmt = `INSERT INTO "${t}" (${colList}) VALUES (${placeholders})`;
  const BATCH = 200;
  for (let i = 0; i < rows.length; i += BATCH) {
    await pgc.query("BEGIN");
    try {
      for (const row of rows.slice(i, i + BATCH)) {
        await pgc.query(stmt, cols.map((c) => conv(row[c], pgTypes.get(c))));
      }
      await pgc.query("COMMIT");
    } catch (e) {
      await pgc.query("ROLLBACK");
      throw new Error(`فشل إدراج ${t} دفعة ${i}: ${e.message}`);
    }
  }
}

// ---- ضبط التسلسلات (id serial)
let seqFixed = 0;
for (const t of tables) {
  if (!counts[t]) continue;
  const hasId = (colInfo.get(t) ?? []).some((c) => c.column_name === "id");
  if (!hasId) continue;
  await pgc.query(`SELECT setval(pg_get_serial_sequence('"${t}"', 'id'), GREATEST((SELECT COALESCE(MAX(id),0) FROM "${t}"), 1))`);
  seqFixed++;
}

// ---- التحقق: العدّادات + بصمات مالية
let mismatches = 0;
for (const t of tables) {
  const { rows: r } = await pgc.query(`SELECT COUNT(*)::int AS c FROM "${t}"`);
  const ok = r[0].c === counts[t];
  if (!ok) { mismatches++; console.log(`MISMATCH ${t}: sqlite=${counts[t]} pg=${r[0].c}`); }
}
const spot = {};
for (const [label, sql] of [
  ["invoices_count", `SELECT COUNT(*)::int c FROM sales_invoices`],
  ["invoices_grand_sum", `SELECT COALESCE(SUM(grand_total),0) s FROM sales_invoices`],
  ["stock_qty_sum", `SELECT COALESCE(SUM(qty),0) s FROM stock_balances`],
  ["cost_layers_open_qty", `SELECT COALESCE(SUM(remaining_quantity),0) s FROM cost_layers WHERE status='OPEN'`],
]) {
  try { const { rows } = await pgc.query(sql); spot[label] = rows[0].c ?? rows[0].s; } catch { spot[label] = "n/a"; }
}

// بصمة SQLite المقابلة للمالية
const sqSpot = {
  invoices_count: sq.prepare(`SELECT COUNT(*) c FROM sales_invoices`).get().c,
  invoices_grand_sum: sq.prepare(`SELECT COALESCE(SUM(grand_total),0) s FROM sales_invoices`).get().s,
  stock_qty_sum: sq.prepare(`SELECT COALESCE(SUM(qty),0) s FROM stock_balances`).get().s,
  cost_layers_open_qty: sq.prepare(`SELECT COALESCE(SUM(remaining_quantity),0) s FROM cost_layers WHERE status='OPEN'`).get().s,
};

const report = { at: new Date().toISOString(), source: SRC_PATH, tables: tables.length, rows: Object.fromEntries(Object.entries(counts).filter(([, v]) => v > 0)), seqFixed, countMismatches: mismatches, pgSpot: spot, sqliteSpot: sqSpot };
writeFileSync("backups/rp2-migration.json", JSON.stringify(report, null, 2));
console.log(JSON.stringify({ tables: tables.length, seqFixed, countMismatches: mismatches, pgSpot: spot, sqliteSpot: sqSpot }, null, 2));
console.log(mismatches === 0 && JSON.stringify(spot) === JSON.stringify(sqSpot) ? "RP2_MOVE_VERIFIED" : "RP2_MOVE_CHECK_REQUIRED");
await pgc.end();
