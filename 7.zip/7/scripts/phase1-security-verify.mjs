// =====================================================================
// PHASE 1 — Multi-Tenant Security, Login & Data Isolation — E2E verify
// حسب وثيقة "Phase 1 — Multi-Tenant Security & Company Isolation Repair"
// يغطي: نفس username في شركتين · عزل الأدوار · cross-company
// (product/customer/invoice/warehouse/transfer/report/search) ·
// عزل الفرع · عزل المستودع · منع تجاوز companyId من العميل.
// =====================================================================
const BASE = "http://localhost:3000";
const TS = Date.now().toString().slice(-6);

const DUAL_USER = "p1.dual";
const DUAL_PW_A = "DualA@12345";
const DUAL_PW_B = "DualB@12345";
const BRANCH_USER = "p1.branch";
const BRANCH_PW = "Branch@12345";
const WH_USER = "p1.wh";
const WH_PW = "Wareh@12345";

let pass = 0, fail = 0;
function check(label, ok, extra = "") {
  console.log(`${ok ? "✅" : "❌"} ${label}${extra ? " — " + extra : ""}`);
  ok ? pass++ : fail++;
  if (!ok) process.exitCode = 1;
}

async function j(path, init = {}, token) {
  const res = await fetch(BASE + path, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(init.headers ?? {}),
    },
  });
  const body = await res.json().catch(() => ({}));
  return { status: res.status, body };
}
const post = (p, data, t) => j(p, { method: "POST", body: JSON.stringify(data) }, t);
const get = (p, t) => j(p, {}, t);
const del = (p, t) => j(p, { method: "DELETE" }, t);
const data = (r) => r.body?.data;

// ---------------- setup: admin + company A/B ----------------
const loginAdmin = await post("/api/v1/auth/login", { username: "admin", password: "Admin@123" });
const tokenA = data(loginAdmin)?.access_token;
check("Setup: دخول admin (شركة A)", !!tokenA, loginAdmin.body?.message ?? "");

const meA = data(await get("/api/v1/auth/me", tokenA));
const idA = meA?.user?.company_id;
check("Setup: /auth/me يعيد شركة A", Number.isFinite(idA), `company_id=${idA}`);

let idB = null;
{
  let list = data(await get("/api/v1/admin/companies", tokenA)) ?? [];
  if (!Array.isArray(list) || list.length === 0) {
    await new Promise((r) => setTimeout(r, 1500)); // انتظار ترجمة السيرفر عند أول تشغيل
    list = data(await get("/api/v1/admin/companies", tokenA)) ?? [];
  }
  const existing = list.find((c) => c.code === "CO-B") // شركة الاختبار المخصصة إن وجدت
    ?? list.find((c) => c.id !== idA && c.code?.startsWith("CO-B"));
  if (existing) idB = existing.id;
  if (!idB) {
    const created = await post("/api/v1/admin/companies", {
      code: `CO-B-${TS}`, name: `شركة B للاختبار ${TS}`, name_en: `Company B ${TS}`,
    }, tokenA);
    idB = data(created)?.id;
  }
}
check("Setup: شركة B جاهزة", Number.isFinite(idB), `id=${idB}`);

const swB = await post("/api/v1/auth/switch-company", { company_id: idB }, tokenA);
const tokenB = data(swB)?.access_token;
check("Setup: تبديل admin إلى شركة B", !!tokenB, swB.body?.message ?? "");

const meB = data(await get("/api/v1/auth/me", tokenB));
const whB = (meB?.warehouses ?? [])[0]?.id;
check("Setup: مستودع شركة B متاح في النطاق", Number.isFinite(whB), `warehouse_id=${whB}`);

// ---------------- cleanup (إعادة تشغيل آمنة) ----------------
async function cleanupUser(token, companyId, username) {
  const users = data(await get(`/api/v1/admin/users?per_page=200`, token)) ?? [];
  const rows = Array.isArray(users) ? users : (users.items ?? []);
  for (const u of rows.filter((x) => x.username === username)) {
    if ((u.company_id ?? u.companyId) === companyId) await del(`/api/v1/admin/users/${u.id}`, token);
  }
}
await cleanupUser(tokenA, idA, DUAL_USER);
await cleanupUser(tokenB, idB, DUAL_USER);
await cleanupUser(tokenA, idA, BRANCH_USER);
await cleanupUser(tokenA, idA, WH_USER);

// ---------------- roles (عزل الأدوار: أدوار مختلفة لكل شركة) ----------------
const rolesA = (data(await get("/api/v1/admin/roles", tokenA)) ?? []);
const rolesB = (data(await get("/api/v1/admin/roles", tokenB)) ?? []);
const pickRole = (roles, want) => roles.find((r) => r.code?.toUpperCase().includes(want)) ?? roles[0];
const roleA = pickRole(rolesA, "ADMIN");
const roleB = pickRole(rolesB, "CASHIER") ?? rolesB[0];
check("Setup: دوران مختلفان للشركتين", !!roleA && !!roleB && roleA.code !== roleB.code,
  `A=${roleA?.code} B=${roleB?.code}`);

// ---------------- كيانات شركة B (لاختبارات cross-company) ----------------
const prodBName = `P1-عزل-منتج-ب-${TS}`;
const prodB = data(await post("/api/v1/products", { name: prodBName, sale_price: 50, cost_price: 30 }, tokenB));
check("Setup: منتج في شركة B", !!prodB?.id, `id=${prodB?.id}`);

const custBName = `عميل عزل B ${TS}`;
const custB = data(await post("/api/v1/customers", { name: custBName, phone: "07700000001" }, tokenB));
check("Setup: عميل في شركة B", !!custB?.id, `id=${custB?.id}`);

const stockB = await post("/api/v1/inventory/movements",
  { warehouse_id: whB, product_id: prodB.id, direction: "IN", qty: 100 }, tokenB);
check("Setup: مخزون منتج B", stockB.status === 201 || stockB.status === 200, `HTTP ${stockB.status}`);

const invB = data(await post("/api/v1/sales/invoices", {
  customer_id: custB.id, warehouse_id: whB, type: "CASH",
  lines: [{ product_id: prodB.id, qty: 2, unit_price: 50 }],
}, tokenB));
check("Setup: فاتورة في شركة B", !!invB?.id, `id=${invB?.id} number=${invB?.number ?? ""}`);

// ---------------- مستخدم بنفس الاسم في الشركتين (§10-1) ----------------
const duA = await post("/api/v1/admin/users", {
  username: DUAL_USER, password: DUAL_PW_A, full_name: "مستخدم مزدوج أ",
  role_code: roleA.code, scope_type: "COMPANY",
}, tokenA);
check("Setup: إنشاء p1.dual في شركة A", duA.status === 201, duA.body?.message ?? "");

const duB = await post("/api/v1/admin/users", {
  username: DUAL_USER, password: DUAL_PW_B, full_name: "مستخدم مزدوج ب",
  role_code: roleB.code, scope_type: "COMPANY",
}, tokenB);
check("Setup: إنشاء نفس username في شركة B", duB.status === 201, duB.body?.message ?? "");

// ================= §10-1 Same username / different companies =================
console.log("\n— 1) نفس اسم المستخدم في شركتين (Login Repair) —");

const noCompany = await post("/api/v1/auth/login", { username: DUAL_USER, password: DUAL_PW_A });
const sel = data(noCompany);
check("login بدون شركة → requires_company_selection (لا توكن)",
  sel?.requires_company_selection === true && sel?.access_token == null,
  JSON.stringify(sel?.companies ?? []));

check("قائمة الشركات تتضمن A وB معاً",
  (sel?.companies ?? []).some((c) => c.id === idA) && (sel?.companies ?? []).some((c) => c.id === idB));

const loginA = await post("/api/v1/auth/login",
  { username: DUAL_USER, password: DUAL_PW_A, company_id: idA });
const tokenDualA = data(loginA)?.access_token;
check("login + selected_company=A → توكن شركة A", !!tokenDualA, loginA.body?.message ?? "");

const meDualA = data(await get("/api/v1/auth/me", tokenDualA));
check("جلسة A تعمل فعلاً داخل شركة A", meDualA?.user?.company_id === idA,
  `company_id=${meDualA?.user?.company_id}`);

const loginB = await post("/api/v1/auth/login",
  { username: DUAL_USER, password: DUAL_PW_B, company_id: idB });
const tokenDualB = data(loginB)?.access_token;
check("login + selected_company=B (كلمة مرور B) → توكن شركة B", !!tokenDualB, loginB.body?.message ?? "");

const meDualB = data(await get("/api/v1/auth/me", tokenDualB));
check("جلسة B تعمل فعلاً داخل شركة B", meDualB?.user?.company_id === idB,
  `company_id=${meDualB?.user?.company_id}`);

const wrongAtoB = await post("/api/v1/auth/login",
  { username: DUAL_USER, password: DUAL_PW_A, company_id: idB });
check("كلمة مرور A مع شركة B → رفض (لا توكن)",
  wrongAtoB.status >= 400 && data(wrongAtoB)?.access_token == null,
  `HTTP ${wrongAtoB.status} ${wrongAtoB.body?.code ?? ""}`);

const wrongBtoA = await post("/api/v1/auth/login",
  { username: DUAL_USER, password: DUAL_PW_B, company_id: idA });
check("كلمة مرور B مع شركة A → رفض (لا توكن)",
  wrongBtoA.status >= 400 && data(wrongBtoA)?.access_token == null,
  `HTTP ${wrongBtoA.status} ${wrongBtoA.body?.code ?? ""}`);

// ================= §10-11 Role isolation =================
console.log("\n— 2) عزل الأدوار (Roles مرتبطة بالشركة النشطة) —");
const permsA = new Set(meDualA?.permissions ?? []);
const permsB = new Set(meDualB?.permissions ?? []);
const diffA = [...permsA].filter((p) => !permsB.has(p));
const diffB = [...permsB].filter((p) => !permsA.has(p));
check("صلاحيات الجلسة تختلف باختلاف الشركة النشطة",
  permsA.size > 0 && permsB.size > 0 && (diffA.length > 0 || diffB.length > 0),
  `A=${permsA.size} B=${permsB.size} فرق=${diffA.length + diffB.length}`);
const roleIsolated = (meDualA?.roles ?? []).every(() => true)
  && (meDualA?.roles ?? []).length > 0
  && (meDualB?.roles ?? []).length > 0
  && (meDualA?.roles ?? [])[0]?.id !== (meDualB?.roles ?? [])[0]?.id;
check("الأدوار المحمولة في الجلسة هي أدوار الشركة النشطة (وليس شركة أخرى)",
  roleIsolated,
  `roleA=${meDualA?.roles?.[0]?.code ?? "-"} roleB=${meDualB?.roles?.[0]?.code ?? "-"}`);

// ---------------- كيانات شركة A (لمحاولات الاختراق العكسية) ----------------
const prodAName = `P1-عزل-منتج-أ-${TS}`;
const prodA = data(await post("/api/v1/products", { name: prodAName, sale_price: 40, cost_price: 25 }, tokenA));
const custA = data(await post("/api/v1/customers", { name: `عميل عزل A ${TS}`, phone: "07700000002" }, tokenA));
check("Setup: منتج وعميل في شركة A", !!prodA?.id && !!custA?.id);

// ================= §10-2..6 Cross-company protection =================
console.log("\n— 3) Cross-Company Protection (توكن A ضد كيانات B) —");

const rProd = await fetch(`${BASE}/api/v1/products/${prodB.id}`, {
  method: "PATCH",
  headers: { "Content-Type": "application/json", Authorization: `Bearer ${tokenA}` },
  body: JSON.stringify({ name: "محاولة تعديل عابرة" }),
});
const rProdBody = await rProd.json().catch(() => ({}));
check("منتج B غير قابل للتعديل من A (404 — عزل IDOR)", rProd.status === 404, `HTTP ${rProd.status} ${rProdBody?.code ?? ""}`);

const rCust = await get(`/api/v1/customers/${custB.id}`, tokenA);
check("عميل B غير مرئي من A (404)", rCust.status === 404, `HTTP ${rCust.status}`);

const rInv = await get(`/api/v1/sales/invoices/${invB.id}`, tokenA);
check("فاتورة B غير مرئية من A (404)", rInv.status === 404, `HTTP ${rInv.status}`);

const xInv = await post("/api/v1/sales/invoices", {
  customer_id: custB.id, warehouse_id: whB, type: "CASH",
  lines: [{ product_id: prodB.id, qty: 1, unit_price: 50 }],
}, tokenA);
check("إنشاء فاتورة A على مراجع B (عميل/مستودع/منتج) → مرفوض",
  xInv.status >= 400, `HTTP ${xInv.status} ${xInv.body?.code ?? ""}`);

const xMove = await post("/api/v1/inventory/movements",
  { warehouse_id: whB, product_id: prodA.id, direction: "IN", qty: 5 }, tokenA);
check("حركة مخزون على مستودع B من جلسة A → مرفوض (SCOPE_002)",
  xMove.status >= 400, `HTTP ${xMove.status} ${xMove.body?.code ?? ""}`);

const xTr = await post("/api/v1/inventory/transfers", {
  from_warehouse_id: whB, to_warehouse_id: (meA?.warehouses ?? [])[0]?.id,
  lines: [{ product_id: prodA.id, qty: 1 }],
}, tokenA);
check("تحويل مخزون من مستودع B إلى مستودع A من جلسة A → مرفوض",
  xTr.status >= 400, `HTTP ${xTr.status} ${xTr.body?.code ?? ""}`);

// ================= §10-7/8 Report + Search isolation =================
console.log("\n— 4) التقارير والبحث —");
const repA = await get("/api/v1/reports/top-products", tokenA);
const repText = JSON.stringify(repA.body ?? {});
check("تقرير top-products لشركة A لا يحتوي منتجات B", repA.status === 200 && !repText.includes(prodBName),
  `HTTP ${repA.status}`);

const repB = await get("/api/v1/reports/top-products", tokenB);
const repBText = JSON.stringify(repB.body ?? {});
check("تقرير top-products لشركة B لا يحتوي منتجات A", repB.status === 200 && !repBText.includes(prodAName),
  `HTTP ${repB.status}`);

const srchA = await get(`/api/v1/search?q=${encodeURIComponent("عزل-منتج-ب-" + TS)}`, tokenA);
const srchAText = JSON.stringify(srchA.body ?? {});
check("البحث الشامل من A لا يُظهر كيانات B", srchA.status === 200 && !srchAText.includes(prodBName),
  `HTTP ${srchA.status}`);

const srchB = await get(`/api/v1/search?q=${encodeURIComponent("عزل-منتج-أ-" + TS)}`, tokenB);
const srchBText = JSON.stringify(srchB.body ?? {});
check("البحث الشامل من B لا يُظهر كيانات A", srchB.status === 200 && !srchBText.includes(prodAName),
  `HTTP ${srchB.status}`);

// ================= §10-9 Branch isolation =================
console.log("\n— 5) عزل الفروع (داخل شركة A) —");
const branchesA = meA?.scope?.branches ?? [];
const whsA = data(await get("/api/v1/admin/warehouses", tokenA)) ?? [];
const whOf = (branchId) => whsA.find((w) => w.branch_id === branchId && w.is_active)?.id;

let b1 = branchesA[0]?.id, b2 = branchesA[1]?.id;
check("شركة A تملك فرعين على الأقل للاختبار", Number.isFinite(b1) && Number.isFinite(b2),
  `b1=${b1} b2=${b2} (عدد فروع A: ${branchesA.length})`);

if (Number.isFinite(b1) && Number.isFinite(b2)) {
  const wh1 = whOf(b1), wh2 = whOf(b2);
  const brUser = await post("/api/v1/admin/users", {
    username: BRANCH_USER, password: BRANCH_PW, full_name: "مستخدم فرع واحد",
    role_code: roleA.code, scope_type: "BRANCH", branch_ids: [b1], branch_id: b1,
  }, tokenA);
  check("Setup: مستخدم نطاقه فرع واحد", brUser.status === 201, brUser.body?.message ?? "");

  const brLogin = await post("/api/v1/auth/login", { username: BRANCH_USER, password: BRANCH_PW });
  const tokenBr = data(brLogin)?.access_token;
  const meBr = data(await get("/api/v1/auth/me", tokenBr));
  check("مستخدم الفرع: فرعه الواحد فقط في النطاق وactiveBranchId مضبوط",
    (meBr?.scope?.branches ?? []).length === 1 && meBr?.scope?.branches?.[0]?.id === b1 && meBr?.user?.branch_id === b1,
    `branches=${JSON.stringify((meBr?.scope?.branches ?? []).map((b) => b.id))}`);

  // فاتورة داخل فرعه (b1) وأخرى في فرع آخر (b2) ثم قارن القوائم
  await post("/api/v1/inventory/movements", { warehouse_id: wh1, product_id: prodA.id, direction: "IN", qty: 50 }, tokenA);
  await post("/api/v1/inventory/movements", { warehouse_id: wh2, product_id: prodA.id, direction: "IN", qty: 50 }, tokenA);

  const invB1 = await post("/api/v1/sales/invoices", {
    customer_id: custA.id, warehouse_id: wh1, type: "CASH",
    lines: [{ product_id: prodA.id, qty: 1, unit_price: 40 }],
  }, tokenBr);
  const sb2 = await post("/api/v1/auth/switch-branch", { branch_id: b2 }, tokenA);
  const tokenB2 = data(sb2)?.access_token;
  const invB2 = await post("/api/v1/sales/invoices", {
    customer_id: custA.id, warehouse_id: wh2, type: "CASH",
    lines: [{ product_id: prodA.id, qty: 1, unit_price: 40 }],
  }, tokenB2);
  check("Setup: فاتورة في فرع المستخدم + فاتورة في فرع آخر",
    !!data(invB1)?.number && !!data(invB2)?.number,
    `${data(invB1)?.number ?? "✗"} / ${data(invB2)?.number ?? "✗"}`);

  const listBr = data(await get("/api/v1/sales/invoices?per_page=200", tokenBr));
  const nums = (listBr ?? []).map((i) => i.number);
  check("قائمة فواتير مستخدم الفرع: يرى فاتورة فرعه ولا يرى فاتورة الفرع الآخر",
    nums.includes(data(invB1)?.number) && !nums.includes(data(invB2)?.number),
    `عدد ما يراه=${nums.length}`);

  const xBrMove = await post("/api/v1/inventory/movements",
    { warehouse_id: wh2, product_id: prodA.id, direction: "IN", qty: 5 }, tokenBr);
  check("كتابة مخزون في مستودع فرع آخر → مرفوض (SCOPE_002)",
    xBrMove.status >= 400, `HTTP ${xBrMove.status} ${xBrMove.body?.code ?? ""}`);
}

// ================= §10-10 Warehouse isolation =================
console.log("\n— 6) عزل المستودعات —");
const whOther = whsA.find((w) => w.is_active && w.id !== whsA.find((x) => x.branch_id === b1)?.id)?.id;
const whUser = await post("/api/v1/admin/users", {
  username: WH_USER, password: WH_PW, full_name: "مستخدم مستودع واحد",
  role_code: roleA.code, scope_type: "WAREHOUSE",
  warehouse_ids: [whOf(b1)].filter(Boolean),
}, tokenA);
check("Setup: مستخدم نطاقه مستودع واحد", whUser.status === 201, whUser.body?.message ?? "");

const whLogin = await post("/api/v1/auth/login", { username: WH_USER, password: WH_PW });
const tokenWh = data(whLogin)?.access_token;
const meWh = data(await get("/api/v1/auth/me", tokenWh));
check("مستخدم المستودع: مستودعه الوحيد في النطاق",
  (meWh?.warehouses ?? []).length === 1 && meWh?.warehouses?.[0]?.id === whOf(b1),
  `warehouses=${JSON.stringify((meWh?.warehouses ?? []).map((w) => w.id))}`);

const xWhMove = await post("/api/v1/inventory/movements",
  { warehouse_id: whOther, product_id: prodA.id, direction: "IN", qty: 5 }, tokenWh);
check("كتابة مخزون في مستودع خارج النطاق → مرفوض (SCOPE_002)",
  xWhMove.status >= 400, `HTTP ${xWhMove.status} ${xWhMove.body?.code ?? ""}`);

// ================= §4 API rule: companyId لا يُؤخذ من العميل =================
console.log("\n— 7) قاعدة الـ API: companyId من الجلسة فقط —");
const hijack = await post("/api/v1/products", {
  name: `P1-محاولة-اختراق-${TS}`, sale_price: 10, company_id: idB,
}, tokenA);
const hijackList = data(await get(`/api/v1/products?q=${encodeURIComponent("P1-محاولة-اختراق-" + TS)}`, tokenA));
const createdInA = (hijackList ?? []).some((p) => p.id === data(hijack)?.id);
check("تمرير company_id=B في POST منتج من جلسة A → يُتجاهل ويُنشأ داخل A",
  hijack.status === 201 && createdInA, `HTTP ${hijack.status}`);

// ---------------- النتيجة ----------------
console.log("\n=================================================");
console.log(`النتيجة النهائية: ✅ ${pass} ناجح | ❌ ${fail} فاشل`);
console.log(fail === 0 ? "🎉 Phase 1 — كل اختبارات الأمن والعزل ناجحة" : "⚠️ توجد اختبارات فاشلة — راجع الأعلى");
