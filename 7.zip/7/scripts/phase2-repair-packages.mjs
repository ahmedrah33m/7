// =====================================================================
// Phase 2 — ترميم تزامن العبوات مع الأرصدة (idempotent, audited):
//   الخلل المؤقت (لقطة قديمة قبل إصلاح §10) خلّف عبوات بكميات وهمية —
//   الأرصدة (stock_balances) صحيحة دائماً لأنها من حركات المخزون.
//   الترميم: لكل (مستودع، منتج معبأ) حيث sum(العبوات غير الفارغة) ≠ الرصيد:
//     · أرشفة الصفوف القديمة إلى JSON (قابل للعكس)
//     · حذف صفوف العبوات وإعادة اشتقاقها من الرصيد (مغلقات + مفتوحة واحدة)
//     · كتابة صف RESTOCK في دفتر التعبئة يوثق الترميم
// الاستخدام: bun run scripts/phase2-repair-packages.mjs [--apply]
//   بلا --apply = تقرير فقط (وضع القراءة).
// =====================================================================
import { PrismaClient } from "@prisma/client";
import { writeFileSync, mkdirSync } from "node:fs";

const db = new PrismaClient();
const APPLY = process.argv.includes("--apply");

async function main() {
  const packed = await db.product.findMany({
    where: { deletedAt: null, packQty: { gt: 1 }, packUnit: { not: null } },
    select: { id: true, companyId: true, name: true, packQty: true },
  });
  console.log(`packed products: ${packed.length}`);

  const repairs = [];
  for (const p of packed) {
    const balances = await db.stockBalance.findMany({ where: { productId: p.id } });
    for (const bal of balances) {
      const rows = await db.package.findMany({
        where: { warehouseId: bal.warehouseId, productId: p.id, status: { not: "EMPTY" } },
      });
      const covered = rows.reduce((s, r) => s + r.remainingQty, 0);
      const drift = Math.round((bal.qty - covered) * 1e6) / 1e6;
      if (Math.abs(drift) < 1e-6) continue;
      repairs.push({
        productId: p.id, companyId: p.companyId, productName: p.name,
        packQty: p.packQty, warehouseId: bal.warehouseId,
        balance: bal.qty, packagesCovered: covered, drift,
        oldRows: rows.map((r) => ({ id: r.id, code: r.code, status: r.status, remaining: r.remainingQty, original: r.originalQty })),
      });
    }
  }
  console.log(`out-of-sync (warehouse, product) pairs: ${repairs.length}`);
  for (const r of repairs) console.log(`  - ${r.productName} (#${r.productId}) WH${r.warehouseId}: balance=${r.balance} packages=${r.packagesCovered} drift=${r.drift}`);

  if (!APPLY) {
    console.log("وضع التقرير فقط — أضف --apply للترميم");
    return;
  }
  if (!repairs.length) {
    console.log("لا شيء للترميم");
    return;
  }

  mkdirSync("backups", { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupPath = `backups/package-repair-${stamp}.json`;
  writeFileSync(backupPath, JSON.stringify({ generated_at: new Date().toISOString(), repairs }, null, 2), "utf8");
  console.log(`backup → ${backupPath}`);

  for (const r of repairs) {
    await db.$transaction(async (tx) => {
      await tx.package.deleteMany({ where: { warehouseId: r.warehouseId, productId: r.productId } });
      const packQty = r.packQty;
      const total = Math.round(r.balance);
      const full = packQty > 0 ? Math.floor(total / packQty) : 0;
      const rest = total - full * packQty;

      const mkCode = async (type) => {
        const agg = await tx.package.aggregate({ where: { companyId: r.companyId }, _max: { id: true } });
        let n = agg._max.id ?? 0;
        for (;;) {
          n += 1;
          const code = `${type}-${String(n).padStart(6, "0")}`;
          const exists = await tx.package.findFirst({ where: { companyId: r.companyId, code }, select: { id: true } });
          if (!exists) return code;
        }
      };
      for (let i = 0; i < full; i++) {
        const code = await mkCode("CARTON");
        const pkg = await tx.package.create({
          data: { companyId: r.companyId, warehouseId: r.warehouseId, productId: r.productId, packageType: "CARTON", code, originalQty: packQty, remainingQty: packQty, status: "SEALED", sourceRefType: "AUTO" },
        });
        await tx.packagingLedger.create({
          data: { companyId: r.companyId, warehouseId: r.warehouseId, productId: r.productId, packageId: pkg.id, packageCode: code, packageType: "CARTON", direction: "RESTOCK", openingQty: 0, issuedQty: packQty, remainingQty: packQty, refType: "ADJUSTMENT", note: "ترميم تزامن العبوات (Phase 2)" },
        });
      }
      if (rest > 0) {
        const code = await mkCode("CARTON");
        const pkg = await tx.package.create({
          data: { companyId: r.companyId, warehouseId: r.warehouseId, productId: r.productId, packageType: "CARTON", code, originalQty: packQty, remainingQty: rest, status: "OPEN", openedAt: new Date(), openedReason: "ترميم تزامن العبوات — كمية غير مكتملة", sourceRefType: "AUTO" },
        });
        await tx.packagingLedger.create({
          data: { companyId: r.companyId, warehouseId: r.warehouseId, productId: r.productId, packageId: pkg.id, packageCode: code, packageType: "CARTON", direction: "RESTOCK", openingQty: 0, issuedQty: rest, remainingQty: rest, refType: "ADJUSTMENT", note: "ترميم تزامن العبوات — عبوة مفتوحة (Phase 2)" },
        });
      }
    });
    console.log(`✓ repaired ${r.productName} WH${r.warehouseId}`);
  }
  console.log("تم الترميم — الأرشفة في", backupPath);
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
