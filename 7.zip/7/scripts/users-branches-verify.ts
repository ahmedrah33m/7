// =====================================================================
// Users & Branches management acceptance suite (Task 25):
//   POST/PATCH /admin/users   — إنشاء مندوب/مدير/كاشير بيوزر خاص
//                               (مستودع سيارة آلي للمندوب + ربط الفرع)
//   POST/PATCH /admin/branches — إنشاء فرع بتجهيز آلي (مستودع + صندوق
//                               + مدير بيوزر) وعزل نطاق مدير الفرع
//   Object-level + branch-scope guards · password policy · audit trail
// Exit 0 = all pass.
// =====================================================================

import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000/api/v1";
const db = new PrismaClient();

let pass = 0;
let fail = 0;
const created: { users: number[]; branches: number[] } = { users: [], branches: [] };

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  ✅ ${name}`);
  } else {
    fail++;
    console.log(`  ❌ ${name} ${detail ? "— " + detail : ""}`);
  }
}

async function req(method: string, path: string, token?: string, body?: unknown): Promise<{ status: number; body: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json };
}

function errCode(r: { body: any }): string {
  return r.body?.error?.code ?? r.body?.code ?? "";
}

async function main() {
  console.log("═══ Users & Branches management verification (Task 25) ═══");
  const rand = Date.now().toString().slice(-6);

  // ─────────── 0) logins ───────────
  console.log("\n— الدخول والتهيئة —");
  const admin = await req("POST", "/auth/login", undefined, { username: "admin", password: "Admin@123" });
  check("admin login", admin.status < 300 && admin.body.success);
  const T = admin.body.data?.access_token as string;

  const cashier = await req("POST", "/auth/login", undefined, { username: "cashier", password: "Cashier@123" });
  check("cashier login", cashier.status < 300);
  const CT = cashier.body.data?.access_token as string;

  const me = await req("GET", "/auth/me", T);
  const branchesList: any[] = me.body.success ? [] : [];
  void branchesList;
  const companyBranches = await db.branch.findMany({ where: { deletedAt: null }, select: { id: true, code: true } });
  const bgw = companyBranches.find((b) => b.code === "BGW");
  const basra = companyBranches.find((b) => b.code === "BSR");
  check("فرعا البذرة حاضران (BGW/BSR)", !!bgw && !!basra, JSON.stringify(companyBranches));

  // cleanup leftovers of the ad-hoc smoke run (idempotent, soft-delete — FK safe)
  const smokeUserIds: number[] = [];
  for (const prefix of ["rep.t", "rep.v", "rep.z", "rep.x", "hq.v", "mgr.t", "mgr.z"]) {
    const rows = await db.user.findMany({ where: { username: { startsWith: prefix } }, select: { id: true } });
    smokeUserIds.push(...rows.map((r) => r.id));
  }
  await db.userRole.deleteMany({ where: { userId: { in: smokeUserIds } } });
  await db.userWarehouseAccess.deleteMany({ where: { userId: { in: smokeUserIds } } });
  if (smokeUserIds.length > 0)
    await db.user.updateMany({ where: { id: { in: smokeUserIds } }, data: { deletedAt: new Date(), isActive: false } });
  const smokeBranches = await db.branch.findMany({
    where: { OR: [{ code: { startsWith: "T" }, name: { contains: "الاختبار" } }, { code: { startsWith: "Z" }, name: { contains: "التحقق" } }] },
    select: { id: true },
  });
  for (const b of smokeBranches) {
    await db.cashbox.updateMany({ where: { branchId: b.id }, data: { deletedAt: new Date(), isActive: false } });
    await db.warehouse.updateMany({ where: { branchId: b.id }, data: { deletedAt: new Date(), isActive: false } });
    await db.branch.update({ where: { id: b.id }, data: { deletedAt: new Date(), isActive: false } });
  }
  check(`تنظيف مخلفات الاختبار الدخاني (${smokeUserIds.length} مستخدمًا، ${smokeBranches.length} فرعًا)`, true);

  // =====================================================================
  console.log("\n— A) إنشاء المستخدمين (المندوبون وغيرهم بيوزرات خاصة) —");

  // A1: مندوب مرتبط بفرع بغداد → مستودع سيارة آلي
  const repUsername = `rep.v${rand}`;
  const rep1 = await req("POST", "/admin/users", T, {
    username: repUsername,
    password: "Rep@12345",
    full_name: "مندوب التحقق الخامس والعشرون",
    phone: "07700000001",
    branch_id: bgw!.id,
    role_codes: ["SALES_REP"],
  });
  check("POST /admin/users مندوب → 2xx", rep1.status < 300, JSON.stringify(rep1.body).slice(0, 200));
  const repId = rep1.body?.data?.id;
  created.users.push(repId);
  check("مستودع سيارة آلي أُنشئ للمندوب", rep1.body?.data?.created_warehouse_id != null, JSON.stringify(rep1.body.data));
  const repVanId = rep1.body?.data?.created_warehouse_id as number | null;
  const van = repVanId ? await db.warehouse.findFirst({ where: { id: repVanId } }) : null;
  check("المستودع الآلي نوعه REP متحرك داخل فرع المندوب", !!van && van.type === "REP" && van.isMobile && van.branchId === bgw!.id, JSON.stringify(van));

  // A2: وصول المندوب محصور بمخزنه
  const repAccess = await db.userWarehouseAccess.findMany({ where: { userId: repId } });
  check("وصول المندوب = مخزن سيارته فقط", repAccess.length === 1 && repAccess[0].warehouseId === repVanId && repAccess[0].canOperate, JSON.stringify(repAccess));

  // A3: الأدوار مربوطة بالفرع (نطاق العزل)
  const repRole = await db.userRole.findFirst({ where: { userId: repId } });
  check("user_roles.branch_id = فرع بغداد", repRole?.branchId === bgw!.id, JSON.stringify(repRole));

  // A4: دخول المندوب بيوزره + صلاحيات البيع بلا إدارة
  const repLogin = await req("POST", "/auth/login", undefined, { username: repUsername, password: "Rep@12345" });
  check("دخول المندوب الجديد 200", repLogin.status === 200, JSON.stringify(repLogin.body).slice(0, 120));
  const RT = repLogin.body.data?.access_token as string;
  const repPerms: string[] = repLogin.body.data?.permissions ?? [];
  check("صلاحيات البيع حاضرة", repPerms.includes("sales.invoices.create") && repPerms.includes("inventory.stock.view"));
  check("صلاحيات الإدارة غائبة", !repPerms.includes("system.users.create") && !repPerms.includes("system.branches.create"));

  // A5: المندوب في قائمة المندوبين (§20)
  const reps = await req("GET", "/users/reps", T);
  check("المندوب يظهر في /users/reps", (reps.body.data ?? []).some((r: any) => r.username === repUsername));

  // A6: المندوب في قائمة المستخدمين مع فرعه
  const ulist = await req("GET", "/admin/users", T);
  const repRow = (ulist.body.data ?? []).find((u: any) => u.username === repUsername);
  check("قائمة المستخدمين تعرض المندوب وفرعه", !!repRow && repRow.branch === "الفرع الرئيسي — بغداد", JSON.stringify(repRow));

  // A7: رفض التكرار والضعف والشوائب
  const dup = await req("POST", "/admin/users", T, { username: "admin", password: "Xx@123456", full_name: "مكرر", role_codes: ["CASHIER"] });
  check("اسم مستخدم مكرر → VAL_002 (409)", dup.status === 409 && errCode(dup) === "VAL_002", `${dup.status} ${errCode(dup)}`);

  const weak = await req("POST", "/admin/users", T, { username: `weak${rand}`, password: "abc", full_name: "ضعيف", role_codes: ["CASHIER"] });
  check("كلمة مرور ضعيفة → VAL_001 (422)", weak.status === 422 && errCode(weak) === "VAL_001", `${weak.status} ${errCode(weak)}`);

  const noRole = await req("POST", "/admin/users", T, { username: `nr${rand}`, password: "Xx@123456", full_name: "بلا دور", role_codes: [] });
  check("بلا أدوار → VAL_001", noRole.status === 422 && errCode(noRole) === "VAL_001", `${noRole.status} ${errCode(noRole)}`);

  const badRole = await req("POST", "/admin/users", T, { username: `br${rand}`, password: "Xx@123456", full_name: "دور وهمي", role_codes: ["NOT_A_ROLE"] });
  check("دور غير موجود → VAL_001", badRole.status === 422 && errCode(badRole) === "VAL_001", `${badRole.status} ${errCode(badRole)}`);

  const badBranch = await req("POST", "/admin/users", T, { username: `bb${rand}`, password: "Xx@123456", full_name: "فرع وهمي", branch_id: 999999, role_codes: ["CASHIER"] });
  check("فرع غير موجود → VAL_001", badBranch.status === 422 && errCode(badBranch) === "VAL_001", `${badBranch.status} ${errCode(badBranch)}`);

  const badName = await req("POST", "/admin/users", T, { username: "اسم عربي!", password: "Xx@123456", full_name: "اسم فاسد", role_codes: ["CASHIER"] });
  check("اسم مستخدم بصيغة فاسدة → VAL_001", badName.status === 422, `${badName.status} ${errCode(badName)}`);

  // A8: من دون صلاحية → 403
  const cashierCreate = await req("POST", "/admin/users", CT, { username: `cc${rand}`, password: "Xx@123456", full_name: "محظور", role_codes: ["CASHIER"] });
  check("كاشير → 403 PERM_001", cashierCreate.status === 403 && errCode(cashierCreate) === "PERM_001", `${cashierCreate.status} ${errCode(cashierCreate)}`);
  const repCreate = await req("POST", "/admin/users", RT, { username: `rr${rand}`, password: "Xx@123456", full_name: "محظور", role_codes: ["CASHIER"] });
  check("مندوب → 403 PERM_001", repCreate.status === 403, `${repCreate.status} ${errCode(repCreate)}`);

  // A9: مستخدم بلا فرع = نطاق كل الفروع (للإدارة المركزية)
  const hqUsername = `hq.v${rand}`;
  const hqUser = await req("POST", "/admin/users", T, { username: hqUsername, password: "Hq@123456", full_name: "إدارة مركزية", role_codes: ["VIEWER"] });
  check("مستخدم بلا فرع → 2xx", hqUser.status < 300, JSON.stringify(hqUser.body).slice(0, 150));
  created.users.push(hqUser.body?.data?.id);
  const hqRole = await db.userRole.findFirst({ where: { userId: hqUser.body?.data?.id } });
  check("أدواره بلا ربط فرع (كل الفروع)", hqRole?.branchId == null, JSON.stringify(hqRole));

  // =====================================================================
  console.log("\n— B) تعديل المستخدمين: تعطيل · تصفير كلمة المرور · تبديل الأدوار —");

  const patch1 = await req("PATCH", `/admin/users/${repId}`, T, { full_name: "مندوب محدث الاسم", phone: "07700000002" });
  check("PATCH بيانات → 2xx", patch1.status < 300, JSON.stringify(patch1.body).slice(0, 150));
  const repRow2 = (await req("GET", "/admin/users", T)).body.data.find((u: any) => u.id === repId);
  check("الاسم المحدث ظاهر في القائمة", repRow2?.full_name === "مندوب محدث الاسم", JSON.stringify(repRow2));

  await req("PATCH", `/admin/users/${repId}`, T, { is_active: false });
  const deact = await req("POST", "/auth/login", undefined, { username: repUsername, password: "Rep@12345" });
  check("تعطيل → دخول 403 AUTH_005", deact.status === 403 && errCode(deact) === "AUTH_005", `${deact.status} ${errCode(deact)}`);

  await req("PATCH", `/admin/users/${repId}`, T, { is_active: true });
  const react = await req("POST", "/auth/login", undefined, { username: repUsername, password: "Rep@12345" });
  check("إعادة تفعيل → دخول 200", react.status === 200, String(react.status));

  await req("PATCH", `/admin/users/${repId}`, T, { password: "Rep@99999" });
  const oldPw = await req("POST", "/auth/login", undefined, { username: repUsername, password: "Rep@12345" });
  const newPw = await req("POST", "/auth/login", undefined, { username: repUsername, password: "Rep@99999" });
  check("كلمة المرور القديمة 401", oldPw.status === 401, String(oldPw.status));
  check("كلمة المرور الجديدة 200", newPw.status === 200, String(newPw.status));

  const weakReset = await req("PATCH", `/admin/users/${repId}`, T, { password: "123" });
  check("تصفير بكلمة مرور ضعيفة → 422", weakReset.status === 422, String(weakReset.status));

  const selfDeact = await req("PATCH", `/admin/users/${admin.body.data?.user?.id ?? 1}`, T, { is_active: false });
  check("منع تعطيل النفس → VAL_001", selfDeact.status === 422, `${selfDeact.status} ${errCode(selfDeact)}`);

  const ghost = await req("PATCH", "/admin/users/999999", T, { full_name: "شبح" });
  check("مستخدم غير موجود → VAL_003 (404)", ghost.status === 404 && errCode(ghost) === "VAL_003", `${ghost.status} ${errCode(ghost)}`);

  // تبديل الأدوار: مندوب → محاسب ثم العودة (الكاشير والمندوب يتشاركان الحزمة نفسها
  // في البذرة، لذا التفريق الصحيح يكون على مستوى الدور المُسند لا الصلاحيات)
  const swap = await req("PATCH", `/admin/users/${repId}`, T, { role_codes: ["ACCOUNTANT"] });
  check("تبديل دور المندوب إلى محاسب → 2xx", swap.status < 300, JSON.stringify(swap.body).slice(0, 150));
  const swappedRole = await db.userRole.findFirst({ where: { userId: repId }, include: { role: { select: { code: true } } } });
  check("الدور في القاعدة أصبح ACCOUNTANT مربوطًا بالفرع", swappedRole?.role.code === "ACCOUNTANT" && swappedRole?.branchId === bgw!.id, JSON.stringify(swappedRole));
  const swapLogin = await req("POST", "/auth/login", undefined, { username: repUsername, password: "Rep@99999" });
  const swapPerms: string[] = swapLogin.body.data?.permissions ?? [];
  check("صلاحيات المحاسب انعكست في الجلسة", swapPerms.includes("finance.expenses.create") && !swapPerms.includes("sales.invoices.create"));
  await req("PATCH", `/admin/users/${repId}`, T, { role_codes: ["SALES_REP"] });
  const backRole = await db.userRole.findFirst({ where: { userId: repId }, include: { role: { select: { code: true } } } });
  const backLogin = await req("POST", "/auth/login", undefined, { username: repUsername, password: "Rep@99999" });
  check("العودة إلى مندوب (قاعدة + جلسة)", backRole?.role.code === "SALES_REP" && (backLogin.body.data?.permissions ?? []).includes("field.visits.create"));

  // =====================================================================
  console.log("\n— C) الفروع: إنشاء بتجهيز آلي + مدير بيوزر + عزل النطاق —");

  const bCode = `Z${rand.slice(0, 4)}`;
  const mgrUsername = `mgr.z${rand}`;
  const newBranch = await req("POST", "/admin/branches", T, {
    code: bCode,
    name: `فرع التحقق ${bCode}`,
    city: "كركوك",
    phone: "07700000003",
    manager: { username: mgrUsername, password: "Mgr@12345", full_name: "مدير فرع التحقق" },
  });
  check("POST /admin/branches + مدير → 201", newBranch.status === 201, JSON.stringify(newBranch.body).slice(0, 250));
  const nbId = newBranch.body?.data?.id;
  created.branches.push(nbId);
  check("مستودع آلي WH-{code}", newBranch.body?.data?.warehouse?.code === `WH-${bCode}`, JSON.stringify(newBranch.body.data?.warehouse));
  check("صندوق آلي CB-{code}", newBranch.body?.data?.cashbox?.code === `CB-${bCode}`, JSON.stringify(newBranch.body.data?.cashbox));
  check("المدير أُنشئ وأعيدت بيانات دخوله", newBranch.body?.data?.manager?.username === mgrUsername && !!newBranch.body?.data?.credentials, JSON.stringify(newBranch.body.data?.manager));

  const dupB = await req("POST", "/admin/branches", T, { code: bCode, name: "مكرر" });
  check("كود فرع مكرر → VAL_002 (409)", dupB.status === 409 && errCode(dupB) === "VAL_002", `${dupB.status} ${errCode(dupB)}`);

  const badCode = await req("POST", "/admin/branches", T, { code: "كود عربي", name: "فاسد" });
  check("كود فرع فاسد → VAL_001", badCode.status === 422, `${badCode.status} ${errCode(badCode)}`);

  // المدير الجديد: دخول + نطاق محصور
  const mgrLogin = await req("POST", "/auth/login", undefined, { username: mgrUsername, password: "Mgr@12345" });
  check("دخول مدير الفرع الجديد 200", mgrLogin.status === 200, JSON.stringify(mgrLogin.body).slice(0, 120));
  const MT = mgrLogin.body.data?.access_token as string;
  const mgrPerms: string[] = mgrLogin.body.data?.permissions ?? [];
  check("مدير الفرع يملك system.users.create و branches.view", mgrPerms.includes("system.users.create") && mgrPerms.includes("system.branches.view"));

  const mgrMe = await req("GET", "/auth/me", MT);
  check("branch_scope في /auth/me: محصور بفرعه", mgrMe.body.data?.branch_scope?.all === false && mgrMe.body.data?.branch_scope?.ids?.[0] === nbId, JSON.stringify(mgrMe.body.data?.branch_scope));

  // قائمة الفروع للمدير = فرعه فقط
  const mgrBranchList = await req("GET", "/admin/branches", MT);
  const mgrListLen = (mgrBranchList.body.data ?? []).length;
  const adminBranchList = await req("GET", "/admin/branches", T);
  const adminListLen = (adminBranchList.body.data ?? []).length;
  check("مدير الفرع يرى فرعه فقط في القائمة", mgrBranchList.status === 200 && mgrListLen === 1 && mgrBranchList.body.data[0].id === nbId, `mgr=${mgrListLen}`);
  check("الإدارة ترى كل الفروع", adminListLen >= 3, `admin=${adminListLen}`);

  // حاجز النطاق على التعديل
  const mgrEditOther = await req("PATCH", `/admin/branches/${bgw!.id}`, MT, { name: "اختراق" });
  check("مدير الفرع لا يعدّل فرعًا آخر → SCOPE_001 (403)", mgrEditOther.status === 403 && errCode(mgrEditOther) === "SCOPE_001", `${mgrEditOther.status} ${errCode(mgrEditOther)}`);
  const mgrEditOwn = await req("PATCH", `/admin/branches/${nbId}`, MT, { phone: "07700000009" });
  check("مدير الفرع يعدّل فرعه → 2xx", mgrEditOwn.status < 300, JSON.stringify(mgrEditOwn.body).slice(0, 120));

  // منع إنشاء فروع من مقيّد
  const mgrNewBranch = await req("POST", "/admin/branches", MT, { code: `Y${rand.slice(0, 4)}`, name: "فرع محظور" });
  check("مدير الفرع لا ينشئ فروعًا → SCOPE_001", mgrNewBranch.status === 403 && errCode(mgrNewBranch) === "SCOPE_001", `${mgrNewBranch.status} ${errCode(mgrNewBranch)}`);

  // إنشاء مستخدم: القيد يفرض فرعه
  const mgrRep = await req("POST", "/admin/users", MT, { username: `rep.z${rand}`, password: "Rep@12345", full_name: "مندوب كركوك", role_codes: ["SALES_REP"] });
  check("مدير الفرع ينشئ مندوبًا → 2xx", mgrRep.status < 300, JSON.stringify(mgrRep.body).slice(0, 150));
  created.users.push(mgrRep.body?.data?.id);
  const mgrRepBranch = await db.user.findFirst({ where: { id: mgrRep.body?.data?.id }, select: { branchId: true } });
  check("المندوب أُسند آليًا لفرع مديره", mgrRepBranch?.branchId === nbId, JSON.stringify(mgrRepBranch));

  const mgrCross = await req("POST", "/admin/users", MT, { username: `rep.x${rand}`, password: "Rep@12345", full_name: "متسلل", branch_id: bgw!.id, role_codes: ["SALES_REP"] });
  check("منع إسناد مستخدم لفرع خارج النطاق → SCOPE_001", mgrCross.status === 403 && errCode(mgrCross) === "SCOPE_001", `${mgrCross.status} ${errCode(mgrCross)}`);

  // حاجز مستوى الكائن على تعديل مستخدم خارج النطاق
  const mgrEditBgwUser = await req("PATCH", `/admin/users/${repId}`, MT, { full_name: "اختراق" });
  check("منع تعديل مستخدم فرع آخر → SCOPE_001", mgrEditBgwUser.status === 403 && errCode(mgrEditBgwUser) === "SCOPE_001", `${mgrEditBgwUser.status} ${errCode(mgrEditBgwUser)}`);

  // تعطيل/تفعيل الفرع
  const disBranch = await req("PATCH", `/admin/branches/${nbId}`, T, { is_active: false });
  check("تعطيل الفرع → 2xx", disBranch.status < 300 && disBranch.body.data?.is_active === false, JSON.stringify(disBranch.body).slice(0, 120));
  const listAfter = await req("GET", "/admin/branches", T);
  const rowAfter = (listAfter.body.data ?? []).find((b: any) => b.id === nbId);
  check("الحالة انعكست في القائمة (معطل)", rowAfter?.is_active === false, JSON.stringify(rowAfter));
  await req("PATCH", `/admin/branches/${nbId}`, T, { is_active: true });

  // عدادات القائمة
  const rowCounts = (await req("GET", "/admin/branches", T)).body.data.find((b: any) => b.id === nbId);
  check("عدادات الفرع (مستخدمون/مستودعات) صحيحة", rowCounts?.users_count >= 2 && rowCounts?.warehouses_count >= 1, JSON.stringify(rowCounts));

  // =====================================================================
  console.log("\n— D) أثر التدقيق والواجهة —");

  const userAudit = await db.auditLog.findFirst({ where: { module: "users", action: "CREATE", entityId: repId } });
  check("تدقيق CREATE:users للمستخدم الجديد", !!userAudit, JSON.stringify(userAudit)?.slice(0, 100));
  const pwAudit = await db.auditLog.findFirst({ where: { module: "users", action: "PASSWORD_RESET", entityId: repId } });
  check("تدقيق PASSWORD_RESET", !!pwAudit);
  const branchAudit = await db.auditLog.findFirst({ where: { module: "branches", action: "CREATE", entityId: nbId } });
  check("تدقيق CREATE:branches للفرع الجديد", !!branchAudit);
  const branchUpdAudit = await db.auditLog.findFirst({ where: { module: "branches", action: "UPDATE", entityId: nbId } });
  check("تدقيق UPDATE:branches", !!branchUpdAudit);

  const home = await fetch("http://localhost:3000/");
  check("الواجهة 200", home.status === 200);

  // ─────────── cleanup (soft-delete test entities, keep db tidy) ───────────
  console.log("\n— التنظيف —");
  for (const uid of created.users) {
    await db.userRole.deleteMany({ where: { userId: uid } });
    await db.userWarehouseAccess.deleteMany({ where: { userId: uid } });
    await db.user.update({ where: { id: uid }, data: { deletedAt: new Date(), isActive: false } });
  }
  for (const bid of created.branches) {
    await db.cashbox.updateMany({ where: { branchId: bid }, data: { deletedAt: new Date(), isActive: false } });
    await db.warehouse.updateMany({ where: { branchId: bid }, data: { deletedAt: new Date(), isActive: false } });
    await db.branch.update({ where: { id: bid }, data: { deletedAt: new Date(), isActive: false } });
  }
  check("تنظيف كيانات الاختبار (حذف ناعم)", true);

  // =====================================================================
  console.log(`\n═══ النتيجة: ${pass} ناجح · ${fail} فاشل ═══`);
  if (fail > 0) process.exit(1);
}

main()
  .catch((e) => {
    console.error("Suite crashed:", e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
