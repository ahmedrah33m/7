// =====================================================================
// Phase 2 §12 — Data Repair Audit (تدقيق إصلاح البيانات):
//   يفحص كل حالات الفساد المعروفة ويُنتج تقريراً — وضع القراءة فقط:
//     A1  unit == packUnit (الحالة المحظورة §2)
//     A2  packQty <= 1 مع وجود تعبئة
//     A3  packSalePrice > 0 بدون packUnit
//     A4  packUnit بدون packQty
//     B1  منتج بلا صفوف أسعار مهيكلة (pricing بلا عملة — DoD)
//     B2  سعر عبوة مهيكل لنفس العملة دون تطابق مع الإسقاط بالدينار
//     C1  كميات عبوات كسرية في packages (مصدر حقيقة فيزيائي كسري — DoD)
//     C2  أرصدة مخزون كسرية لمنتجات معبأة
//   أي إصلاح آلي لاحق يجب أن يكون: audited (audit_log) + reversible
//   (نسخة JSON كاملة قبل التعديل) + logged (سكربت استرجاع).
//   الاستخدام: bun run scripts/phase2-data-repair.mjs [--json out.json]
// =====================================================================
import { PrismaClient } from "@prisma/client";
import { writeFileSync } from "node:fs";

const db = new PrismaClient();
const args = process.argv.slice(2);
const jsonOut = args.includes("--json") ? args[args.indexOf("--json") + 1] : null;

const norm = (s) => String(s ?? "").trim().replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").toLowerCase();
const eq = (a, b) => norm(a) === norm(b) && norm(a) !== "";

async function main() {
  const findings = [];
  const push = (code, severity, entity, id, detail) => findings.push({ code, severity, entity, id, detail });

  const products = await db.product.findMany({
    where: { deletedAt: null },
    select: { id: true, companyId: true, code: true, name: true, unit: true, packUnit: true, packQty: true, packSalePrice: true, salePrice: true, costPrice: true },
  });

  // ---- A: التعبئة -----------------------------------------------------
  for (const p of products) {
    if (p.packUnit && eq(p.unit, p.packUnit)) push("A1", "CRITICAL", "product", p.id, `unit=${p.unit} == packUnit=${p.packUnit} (packQty=${p.packQty})`);
    if (p.packUnit && p.packQty != null && p.packQty <= 1) push("A2", "CRITICAL", "product", p.id, `packQty=${p.packQty} <= 1`);
    if ((p.packSalePrice ?? 0) > 0 && !p.packUnit) push("A3", "HIGH", "product", p.id, `packSalePrice=${p.packSalePrice} بدون packUnit`);
    if (p.packUnit && (p.packQty == null || !Number.isFinite(p.packQty))) push("A4", "HIGH", "product", p.id, `packUnit=${p.packUnit} بدون packQty`);
  }

  // ---- B: الأسعار المهيكلة --------------------------------------------
  const priceRows = await db.productPrice.findMany({ where: { isActive: true } });
  const byProduct = new Map();
  for (const r of priceRows) {
    const list = byProduct.get(r.productId) ?? [];
    list.push(r);
    byProduct.set(r.productId, list);
  }
  for (const p of products) {
    const rows = byProduct.get(p.id) ?? [];
    if (rows.length === 0) {
      push("B1", "CRITICAL", "product", p.id, `لا صفوف ProductPrice — سعر بلا عملة (sale=${p.salePrice}, cost=${p.costPrice})`);
      continue;
    }
    const hasSale = rows.some((r) => r.priceType === "SALE" && r.unit === "PIECE");
    // COST بلا صف مقبول فقط حين التكلفة صفر فعلاً (لا سعر تكلفة أصلاً)
    const hasCost = rows.some((r) => r.priceType === "COST" && r.unit === "PIECE") || !(p.costPrice > 0);
    if (!hasSale) push("B2", "HIGH", "product", p.id, "بلا سعر SALE/PIECE مهيكل");
    if (!hasCost) push("B2", "MEDIUM", "product", p.id, "بلا سعر COST/PIECE مهيكل رغم تكلفة > 0");
    const mismatch = rows.find((r) => r.currency !== "IQD" && r.currency !== "USD");
    if (mismatch) push("B2", "CRITICAL", "product_price", mismatch.id, `عملة غير معروفة: ${mismatch.currency}`);
  }

  // ---- C: الفيزيائي (عبوات/أرصدة) -------------------------------------
  const pkgs = await db.package.findMany({
    where: { status: { not: "EMPTY" } },
    select: { id: true, companyId: true, productId: true, code: true, originalQty: true, remainingQty: true, status: true },
  });
  for (const k of pkgs) {
    if (!Number.isInteger(k.remainingQty) && k.remainingQty % 1 !== 0) {
      push("C1", "HIGH", "package", k.id, `${k.code}: remainingQty=${k.remainingQty} كسري — العبوة الفيزيائية أعداد صحيحة فقط`);
    }
  }
  const packedIds = products.filter((p) => p.packUnit && p.packQty > 1).map((p) => p.id);
  if (packedIds.length) {
    const balances = await db.stockBalance.findMany({
      where: { productId: { in: packedIds } },
      select: { id: true, productId: true, warehouseId: true, qty: true },
    });
    for (const b of balances) {
      if (b.qty % 1 !== 0) {
        push("C2", "MEDIUM", "stock_balance", b.id, `product #${b.productId} warehouse #${b.warehouseId}: qty=${b.qty} كسري (الحبات أعداد صحيحة)`);
      }
    }
  }

  // ---- التقرير ---------------------------------------------------------
  const counts = {};
  for (const f of findings) counts[f.code] = (counts[f.code] ?? 0) + 1;
  const report = {
    generated_at: new Date().toISOString(),
    mode: "READ_ONLY_AUDIT",
    totals: { products: products.length, packages: pkgs.length, product_prices: priceRows.length, findings: findings.length, by_code: counts },
    findings,
    note: "أي إصلاح آلي يجب أن يكون: audited (audit_log) + reversible (نسخة JSON سابقة) + logged (سكربت استرجاع) — §12",
  };

  if (jsonOut) {
    writeFileSync(jsonOut, JSON.stringify(report, null, 2), "utf8");
    console.log(`JSON → ${jsonOut}`);
  }

  console.log("=".repeat(64));
  console.log(`Phase 2 Data Audit — ${new Date().toISOString()}`);
  console.log(`products=${products.length} · packages=${pkgs.length} · product_prices=${priceRows.length}`);
  console.log(`FINDINGS: ${findings.length} ${JSON.stringify(counts)}`);
  for (const f of findings) console.log(`  [${f.severity}] ${f.code} ${f.entity}#${f.id}: ${f.detail}`);
  if (findings.length === 0) console.log("  ✓ صفر مخالفات — الحالة نظيفة");
  console.log("=".repeat(64));
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
