// download-v6-via-browser.mjs — تنزيل أرشيف v6 عبر متصفح حقيقي (تجاوز بوابة البوت)
import { chromium } from "playwright";

const FILE_URL = "https://filebin.net/kayan-backup-v6-20260917153700/kayan-system-full-backup-2026-09-17-v6.zip";
const DEST = "/home/z/my-project/backups/v6-redownloaded.zip";

const browser = await chromium.launch({ headless: true });
try {
  const ctx = await browser.newContext({ acceptDownloads: true });
  const page = await ctx.newPage();
  const [download] = await Promise.all([
    page.waitForEvent("download", { timeout: 240000 }),
    page.goto(FILE_URL, { timeout: 60000 }),
  ]);
  await download.saveAs(DEST);
  console.log("SAVED:", DEST);
} catch (e) {
  console.log("DOWNLOAD_FAILED:", String(e).slice(0, 300));
  process.exitCode = 1;
} finally {
  await browser.close();
}
