#!/usr/bin/env bash
# =============================================================
# create-full-backup-v14-2026-09-23.sh
# أرشيف النظام الكامل v14 — Kayan Financial Cashbox & Receipt
# Finalization (MASTER PROMPT — Kayan Financial Cashbox & Receipt
# Management System).
#
# جولة كاملة لإغلاق فجوات الـ MASTER PROMPT (المراحل 0-73):
#   - Gap1: PATCH /cashboxes/[id] + /transactions + /reopen + /reconcile
#     + standalone /cash-reconciliation (Phase 67 cashbox lifecycle)
#   - Gap2: /finance/payments (GET) + /payments/[id] + /payments/[id]/allocate
#     (Phase 11/67 — allocation of unallocated payments)
#   - Gap3: 4 new finance lifecycle permission actions (close/reopen/
#     reconcile/allocate) restricted to cashboxes + payments
#   - Gap4: cashboxWhere(session) in scope.ts enforces ownerUserId scope
#     for SALES_REP/SELF on REP/CUSTOM cashboxes (Phase 3/38/57)
#   - Gap5: Mixed payment (MIXED) active in createReceiptVoucher +
#     createPaymentVoucher (cash split only moves the cashbox)
#   - Bonus: removed @ts-nocheck from cash-closings/payment-vouchers/
#     cash-transfers routes + fixed branchId from session (Phase 38)
#   - UI: PaymentsPanel + ReconcileModal + CashboxTransactionsModal +
#     Edit cashbox button + Reopen cashbox button
#
# ** جديد جوهري: الأرشيف يتضمن .next/standalone جاهزًا للتشغيل
#    (بناء مسبق) → الخادم لا يحتاج npm run build إطلاقًا — فك +
#    استعادة بيانات + تشغيل
# =============================================================
set -euo pipefail

ROOT="/home/z/my-project"
OUT="$ROOT/download/kayan-system-full-backup-2026-09-23-v14.zip"
SNAP="$ROOT/backups/custom-snapshot-20260923-v14.db"
STAGE="$ROOT/.zstage"
CHK="$ROOT/backups/.dbcheck-v14"

echo "==> 1) لقطة DB متسقة…"
python3 "$ROOT/scripts/snapshot-db.py" "$SNAP"
SNAP_MD5="$(md5sum "$SNAP" | cut -d' ' -f1)"
echo "snapshot_md5=$SNAP_MD5"

echo "==> 2) staging وحقن اللقطة…"
rm -rf "$STAGE"
mkdir -p "$STAGE/db"
cp "$SNAP" "$STAGE/db/custom.db"

echo "==> 3) أرشفة المصدر (بلا node_modules/.next/backups)…"
rm -f "$OUT"
( cd "$STAGE" && zip -q -X "$OUT" db/custom.db )
cd "$ROOT"
zip -qr "$OUT" . \
  -x "node_modules/*" \
  -x ".next/*" \
  -x "backups/*" \
  -x "skills/*" \
  -x "tool-results/*" \
  -x "download/*" \
  -x ".pkg-*/*" \
  -x ".zscripts/*" \
  -x ".zstage/*" \
  -x "repo/*" \
  -x "upload/*" \
  -x "examples/*" \
  -x "mini-services/*" \
  -x "tsconfig.tsbuildinfo" \
  -x "db/custom.db" \
  -x "db/custom.db-journal" \
  -x "db/custom.db-wal" \
  -x "db/custom.db-shm"

echo "==> 4) ضم الـ standalone الجاهز (بناء مسبق) إلى الأرشيف…"
[ -f ".next/standalone/.next/BUILD_ID" ] || { echo "لا يوجد BUILD_ID — البناء ناقص"; exit 1; }
[ -d ".next/standalone/.next/static" ]  || { echo "لا يوجد static داخل standalone"; exit 1; }
[ -d ".next/standalone/public" ]        || { echo "لا يوجد public داخل standalone"; exit 1; }
[ -d ".next/standalone/node_modules/.prisma" ] || { echo "لا يوجد عميل prisma داخل standalone"; exit 1; }
( cd .next && zip -qr "$OUT" standalone )
echo "  BUILD_ID المضمّن: $(cat .next/standalone/.next/BUILD_ID)"

echo "==> 5) التحقق…"
unzip -t "$OUT" > "$ROOT/backups/.unzip-t-v14.txt" 2>&1 \
  && echo "unzip -t: OK ($(tail -1 "$ROOT/backups/.unzip-t-v14.txt"))" \
  || { echo "unzip -t FAILED"; tail -5 "$ROOT/backups/.unzip-t-v14.txt"; exit 1; }

COUNT="$(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
SIZE="$(stat -c%s "$OUT")"
MD5="$(md5sum "$OUT" | cut -d' ' -f1)"
SHA256="$(sha256sum "$OUT" | cut -d' ' -f1)"
NEXT_IN_ZIP="$(unzip -l "$OUT" | grep -c "standalone/.next/" || true)"

rm -rf "$CHK"; mkdir -p "$CHK"
unzip -q "$OUT" "db/custom.db" -d "$CHK"
ARCH_MD5="$(md5sum "$CHK/db/custom.db" | cut -d' ' -f1)"
TABLES="$(python3 -c "
import sqlite3
c = sqlite3.connect('$CHK/db/custom.db')
print(len(c.execute(\"select name from sqlite_master where type='table' and name not like 'sqlite_%'\").fetchall()))
")"
rm -rf "$CHK"
if [ "$ARCH_MD5" = "$SNAP_MD5" ]; then DB_MATCH=YES; else DB_MATCH=NO; fi

echo "=============================================="
echo "OUT     : $OUT"
echo "SIZE    : $SIZE bytes ($((SIZE/1024/1024))MB)"
echo "FILES   : $COUNT"
echo "NEXT    : $NEXT_IN_ZIP ملف standalone داخل الأرشيف"
echo "MD5     : $MD5"
echo "SHA256  : $SHA256"
echo "DB_MATCH: $DB_MATCH"
echo "DB_TABLES: $TABLES"
echo "=============================================="
[ "$DB_MATCH" = "YES" ] || exit 1
[ "$NEXT_IN_ZIP" -gt 100 ] || { echo "الـ standalone ناقص داخل الأرشيف!"; exit 1; }
echo "DONE_OK"
