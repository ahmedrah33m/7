// One-off: add demo sales orders to the CURRENT db (seed gate is
// ruleCount===0 which already passed here). After any env wipe the
// full seedDatabase path seeds them too.
import { PrismaClient } from "@prisma/client";
import { createSalesOrder, confirmSalesOrder } from "../src/lib/sales-order-service";

const db = new PrismaClient();

async function main() {
  const company = await db.company.findFirst({ where: { deletedAt: null } });
  if (!company) throw new Error("no company");
  const admin = await db.user.findFirst({ where: { companyId: company.id, username: "admin", deletedAt: null } });
  if (!admin) throw new Error("no admin");
  const mainWh = await db.warehouse.findFirst({ where: { companyId: company.id, code: "WH-MAIN", deletedAt: null } });
  const repWh = await db.warehouse.findFirst({ where: { companyId: company.id, code: "REP-AHMED", deletedAt: null } });
  if (!mainWh || !repWh) throw new Error("no warehouses");
  const customers = await db.customer.findMany({ where: { companyId: company.id, deletedAt: null }, orderBy: { id: "asc" }, take: 5 });
  const products = await db.product.findMany({ where: { companyId: company.id, deletedAt: null }, orderBy: { id: "asc" }, take: 8 });
  if (customers.length < 3 || products.length < 4) throw new Error("not enough demo data");

  const actor = { userId: admin.id, companyId: company.id, warehouseIds: [mainWh.id, repWh.id] };

  const count = await db.salesOrder.count({ where: { companyId: company.id } });
  if (count > 0) {
    console.log("sales orders already present — skip");
    return;
  }

  const draft = await createSalesOrder(actor, {
    customerId: customers[2].id,
    warehouseId: mainWh.id,
    notes: "أمر بيع تجريبي — مسودة بانتظار التأكيد",
    lines: [
      { productId: products[1].id, qty: 25 },
      { productId: products[2].id, qty: 10 },
    ],
  });
  const confirmed = await createSalesOrder(actor, {
    customerId: customers[0].id,
    warehouseId: mainWh.id,
    notes: "أمر بيع تجريبي مؤكد — جاهز للتحويل إلى فاتورة",
    lines: [
      { productId: products[0].id, qty: 12 },
      { productId: products[3].id, qty: 20, discountPct: 5 },
    ],
  });
  await confirmSalesOrder(actor, confirmed.id);
  console.log(`demo orders: ${draft.number} (DRAFT) + ${confirmed.number} (CONFIRMED)`);
}

main().finally(() => db.$disconnect());
