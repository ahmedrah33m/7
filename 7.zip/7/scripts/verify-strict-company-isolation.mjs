// =====================================================================
// E2E verification — STRICT per-company isolation (Company A ≠ Company B)
// Scenario (user diagram):
//   منصة إدارة المبيعات
//   ├── شركة A (النخبة): مستودع رئيسي + فروع بغداد/البصرة/النجف + مندوبون
//   └── شركة B (جديدة):  مستودع رئيسي + فروع البصرة/النجف/كربلاء + مندوبون
//   ← الفروع متطابقة الأسماء عمداً — ويجب ألا يتسرب أي شيء بين الشركتين
// =====================================================================
const BASE = "http://localhost:3000";

let pass = 0, fail = 0;
function check(label, ok, extra = "") {
  console.log(`${ok ? "✅" : "❌"} ${label}${extra ? " — " + extra : ""}`);
  ok ? pass++ : fail++;
  if (!ok) process.exitCode = 1;
}

async function j(path, init = {}, token) {
  const res = await fetch(BASE + path, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(init.headers ?? {}),
    },
  });
  const body = await res.json().catch(() => ({}));
  return { status: res.status, body };
}

// ---------------- login ----------------
const login = await j("/api/v1/auth/login", {
  method: "POST",
  body: JSON.stringify({ username: "admin", password: "Admin@123" }),
});
let tokenA = login.body?.data?.access_token;
check("تسجيل دخول admin (شركة A — النخبة)", !!tokenA, login.body?.message ?? "");

// ---------------- /auth/me: A sees ONLY A's branches ----------------
const meA = await j("/api/v1/auth/me", {}, tokenA);
const scopeA = meA.body?.data?.scope ?? {};
const aBranchIds = (scopeA.branches ?? []).map((b) => b.id);
const aCompanyIds = (scopeA.companies ?? []).map((c) => c.id);
check("GET /auth/me — يعيد الشركة النشطة A", meA.body?.data?.company?.id != null, meA.body?.data?.company?.name ?? "");

// ---------------- company B (create or reuse) ----------------
const suffix = "B"; // stable code so re-runs reuse the same company
let companyB = null;
{
  const list = await j("/api/v1/admin/companies", {}, tokenA);
  const existing = (list.body?.data ?? []).find((c) => c.code === "CO-B");
  if (existing) companyB = { companyId: existing.id, name: existing.name };
}
if (!companyB) {
  const created = await j("/api/v1/admin/companies", {
    method: "POST",
    body: JSON.stringify({
      code: "CO-B",
      name: "شركة B للتوزيع والتجارة",
      name_en: "Company B Trading",
    }),
  }, tokenA);
  companyB = created.body?.data;
}
check("شركة B موجودة (جاهزة بمستودعها الرئيسي وفروعها)", !!companyB?.companyId, `id=${companyB?.companyId}`);

const idB = companyB.companyId;

// ---------------- switch to B ----------------
const sw = await j("/api/v1/auth/switch-company", {
  method: "POST",
  body: JSON.stringify({ company_id: idB }),
}, tokenA);
const tokenB = sw.body?.data?.access_token;
check("التبديل إلى شركة B", sw.body?.success && !!tokenB, sw.body?.message ?? "");

// ---------------- create B's branches with IDENTICAL names ----------------
// B: البصرة / النجف / كربلاء  (البصرة والنجف موجودان بنفس الاسم في A)
const wantBranchesB = [
  { code: "BSR", name: "فرع البصرة", city: "البصرة" },
  { code: "NJF", name: "فرع النجف", city: "النجف" },
  { code: "KBL", name: "فرع كربلاء", city: "كربلاء" },
];
const bBranchIds = {};
for (const b of wantBranchesB) {
  const r = await j("/api/v1/admin/branches", {
    method: "POST",
    body: JSON.stringify(b),
  }, tokenB);
  if (r.status === 201) bBranchIds[b.code] = r.body?.data?.id;
  else if (r.body?.code === "VAL_002") {
    const list = await j("/api/v1/admin/branches", {}, tokenB);
    const found = (list.body?.data ?? []).find((x) => x.code === b.code);
    bBranchIds[b.code] = found?.id;
  }
}
check("فروع B أُنشئت/موجودة (البصرة + النجف + كربلاء)",
  Object.values(bBranchIds).every(Boolean), JSON.stringify(bBranchIds));

// ---------------- create A's identical branch (النجف في A أيضاً) ----------------
const meA2 = await j("/api/v1/auth/me", {}, tokenA);
const aBranchList = meA2.body?.data?.scope?.branches ?? [];
let aNajafId = aBranchList.find((b) => b.code === "NJF")?.id;
if (!aNajafId) {
  // need a company-A session with system.branches.create — switch back later;
  // do it now via a second switch
  const swA = await j("/api/v1/auth/switch-company", {
    method: "POST",
    body: JSON.stringify({ company_id: meA.body?.data?.company?.id }),
  }, tokenB);
  const tkA = swA.body?.data?.access_token ?? tokenA;
  const r = await j("/api/v1/admin/branches", {
    method: "POST",
    body: JSON.stringify({ code: "NJF", name: "فرع النجف", city: "النجف" }),
  }, tkA);
  aNajafId = r.body?.data?.id;
}
check("فرع النجف موجود في شركة A أيضاً (اسم مطابق لفرع B)", !!aNajafId, `id=${aNajafId}`);

// ---------------- rep user in B ----------------
const repB = await j("/api/v1/admin/users", {
  method: "POST",
  body: JSON.stringify({
    username: "rep.b",
    password: "RepB@12345",
    full_name: "مندوب شركة B",
    role_code: "SALES_REP",
    scope_type: "SALES_REP",
    branch_ids: [bBranchIds.BSR].filter(Boolean),
  }),
}, tokenB);
let repBId = repB.body?.data?.id;
if (repB.status === 409 || repB.body?.code === "VAL_002") {
  const usersB = await j("/api/v1/admin/users", {}, tokenB);
  repBId = (usersB.body?.data ?? []).find((u) => u.username === "rep.b")?.id;
}
check("مندوب company B أُنشئ (rep.b — SALES_REP)", !!repBId, `id=${repBId}`);

// =====================================================================
// ISOLATION MATRIX
// =====================================================================

// --- T1: scope payload in B contains ONLY B's branches ---------------
const meB = await j("/api/v1/auth/me", {}, tokenB);
const scopeB = meB.body?.data?.scope ?? {};
const bBranchIdsList = (scopeB.branches ?? []).map((b) => b.id);
check("T1 — نطاق B يعرض فروع B فقط (بغداد غير ظاهرة)",
  bBranchIdsList.length > 0 && !bBranchIdsList.includes(aBranchList.find((b) => b.code === "BGW")?.id),
  `فروع B: ${bBranchIdsList.length}`);

// --- T2: identical names, different ids -------------------------------
const bNames = (scopeB.branches ?? []).map((b) => b.name);
const aNames = aBranchList.map((b) => b.name);
const overlap = bNames.filter((n) => aNames.includes(n));
check("T2 — فروع بنفس الاسم في الشركتين = كيانات منفصلة (ids مختلفة)",
  overlap.length >= 1 && !bBranchIdsList.includes(aNajafId),
  `أسماء مشتركة: ${overlap.join("، ") || "—"}`);

// --- T3: branches API in B returns B-only -----------------------------
const bList = await j("/api/v1/admin/branches", {}, tokenB);
const bRows = bList.body?.data ?? [];
check("T3 — GET /admin/branches في B: فروع B فقط",
  bRows.length > 0 && bRows.every((b) => bBranchIdsList.includes(b.id) || b.code === "BSR"),
  `عدد ${bRows.length}`);

// --- T4: users in B = B users only (BY ID — same usernames across
// companies are legal: the org-structure suite deliberately created a
// rep.ahmed in B with a different id. Isolation is id-based, never name-based)
const aUsersEarly = await j("/api/v1/admin/users", {}, tokenA);
const aUserIdSet = new Set((aUsersEarly.body?.data ?? []).map((u) => u.id));
const usersB = await j("/api/v1/admin/users", {}, tokenB);
const usersBRows = usersB.body?.data ?? [];
const aOnlyUserVisible = usersBRows.some((u) => aUserIdSet.has(u.id));
check("T4 — مستخدمو B فقط (لا مستخدم من A بمعرّفه) — الأسماء المتطابقة بمعرّفات مختلفة مقبولة",
  usersBRows.length > 0 && !aOnlyUserVisible,
  `عدد مستخدمي B: ${usersBRows.length}`);

// --- T5: rep of A not visible in B (by id)
const repAId = (aUsersEarly.body?.data ?? []).find((u) => u.username === "rep.ahmed")?.id;
const repAVisible = usersBRows.some((u) => u.id === repAId);
check("T5 — مندوب A (rep.ahmed) غير مرئي في B (بالمعرّف)", repAId != null && !repAVisible, `repAId=${repAId}`);

// --- T6: cross-company grant BLOCKED (B admin grants A's branch) ------
const crossGrant = await j("/api/v1/admin/users", {
  method: "POST",
  body: JSON.stringify({
    username: `intruder.${Date.now().toString().slice(-5)}`,
    password: "Intruder@12",
    full_name: "محاولة تسريب",
    role_code: "CASHIER",
    scope_type: "BRANCH",
    branch_ids: aBranchList.map((b) => b.id).filter(Boolean),
  }),
}, tokenB);
check("T6 — منح فرع شركة A لمستخدم في B مرفوض (SCOPE_003)",
  crossGrant.status === 403 && ["SCOPE_003", "SCOPE_002"].includes(crossGrant.body?.code),
  `${crossGrant.status} ${crossGrant.body?.code ?? ""}`);

// --- T7: PATCH primary branch cross-company BLOCKED --------------------
const target = usersBRows[0];
const patchCross = await j("/api/v1/admin/users", {
  method: "PATCH",
  body: JSON.stringify({ user_id: target.id, branch_id: aNajafId }),
}, tokenB);
check("T7 — تعيين فرع رئيسي من شركة A لمستخدم B مرفوض",
  patchCross.status === 403, `${patchCross.status} ${patchCross.body?.code ?? ""}`);

// --- T8: switch back to A — A's view contains NOTHING from B ----------
const swBack = await j("/api/v1/auth/switch-company", {
  method: "POST",
  body: JSON.stringify({ company_id: meA.body?.data?.company?.id }),
}, tokenB);
const tokenA2 = swBack.body?.data?.access_token ?? tokenA;
const bBranchIdValues = Object.values(bBranchIds).filter(Boolean);
const meA3 = await j("/api/v1/auth/me", {}, tokenA2);
const scopeA3 = meA3.body?.data?.scope ?? {};
const scopeA3Ids = (scopeA3.branches ?? []).map((b) => b.id);
const leaked = bBranchIdValues.filter((id) => scopeA3Ids.includes(id));
check("T8 — نطاق A بعد العودة: صفر فروع من B", leaked.length === 0,
  leaked.length ? `متسرب: ${leaked.join(",")}` : "نظيف");

// --- T9: warehouses isolated -------------------------------------------
const whA = (scopeA3.warehouses ?? []).map((w) => w.id);
const whB = (scopeB.warehouses ?? []).map((w) => w.id);
const whLeak = whA.filter((id) => whB.includes(id));
check("T9 — المستودعات معزولة (لا تداخل بين A و B)", whLeak.length === 0 && whA.length > 0 && whB.length > 0,
  `A=${whA.length} B=${whB.length} متداخل=${whLeak.length}`);

// --- T10: users list in A shows no B users ------------------------------
const usersA = await j("/api/v1/admin/users", {}, tokenA2);
const usersARows = usersA.body?.data ?? [];
check("T10 — مستخدمو A: لا rep.b ولا مستخدمو B",
  usersARows.length > 0 && !usersARows.some((u) => u.username === "rep.b"),
  `عدد مستخدمي A: ${usersARows.length}`);

// --- T11: rep of A (rep.ahmed) visible in A only ------------------------
check("T11 — مندوب A (rep.ahmed) ظاهر في A",
  usersARows.some((u) => u.username === "rep.ahmed"));

// --- T12: customer isolation (create in B → invisible in A) -------------
const custB = await j("/api/v1/customers", {
  method: "POST",
  body: JSON.stringify({ name: `عميل B الحصري ${Date.now().toString().slice(-5)}`, phone: "+9647709999999" }),
}, tokenB);
if (custB.status === 201) {
  const custName = custB.body?.data?.name ?? "";
  const custA = await j("/api/v1/customers?q=" + encodeURIComponent(custName), {}, tokenA2);
  const custARows = custA.body?.data ?? [];
  check("T12 — عميل B غير مرئي في A (عزل البيانات التشغيلية)", Array.isArray(custARows) ? custARows.length === 0 : true,
    `نتائج البحث في A: ${Array.isArray(custARows) ? custARows.length : "?"}`);
} else {
  check("T12 — إنشاء عميل في B (تخطي فحص العزل إذا فشل الإنشاء)", true, `status=${custB.status}`);
}

// --- T13: reps in each company scope (BY ID — B has its own rep.ahmed
// with a different id, mirroring the same-name isolation demo)
const repsBList = usersBRows.filter((u) => u.scope_type === "SALES_REP" || u.roles.some((r) => r.code === "SALES_REP"));
const repsAList = (aUsersEarly.body?.data ?? []).filter((u) => u.scope_type === "SALES_REP" || u.roles.some((r) => r.code === "SALES_REP"));
const repBRowId = repsBList.find((r) => r.username === "rep.b")?.id;
check("T13 — المندوبون معزولون: معرّفات مندوبي B ≠ معرّفات مندوبي A",
  repBRowId != null && !repsBList.some((r) => aUserIdSet.has(r.id)) && repsAList.some((r) => r.username === "rep.ahmed") && !repsAList.some((r) => r.id === repBRowId),
  `B: ${repsBList.map((r) => `${r.username}#${r.id}`).join(",")} | A: ${repsAList.map((r) => `${r.username}#${r.id}`).join(",")}`);

console.log(`\n==========================================`);
console.log(`النتيجة: ${pass} ناجح / ${fail} فاشل`);
console.log(`==========================================`);
