// =====================================================================
// Dual Currency (IQD + USD invoices) + Product Edit — E2E verification
// 1) PATCH /products/[id]: name/sale_price/category/packaging/is_active
//    + cross-company category rejection + product isolation (404)
// 2) POST /sales/invoices with currency=USD + exchange_rate (stored IQD base)
//    + USD invoice without rate → VAL_001 + IQD default + GET detail fields
// Run: node scripts/verify-currency-and-product-edit.mjs
// =====================================================================
const BASE = "http://localhost:3000/api/v1";

let PASS = 0, FAIL = 0;
const results = [];
function check(name, cond, extra = "") {
  if (cond) { PASS++; results.push(`  ✓ ${name}`); }
  else { FAIL++; results.push(`  ✗ ${name}${extra ? ` — ${extra}` : ""}`); }
}

async function req(method, path, token, body) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let json = null;
  try { json = await res.json(); } catch { /* empty */ }
  return { status: res.status, body: json };
}

async function login(username, password) {
  const { status, body } = await req("POST", "/auth/login", null, { username, password });
  if (status !== 200 || !body?.data?.access_token) throw new Error(`login failed ${username}: ${status} ${JSON.stringify(body).slice(0, 200)}`);
  return body.data.access_token;
}

// ---- main -------------------------------------------------------------
const owner = await login("admin", "Admin@123");

// شركة B عبر switch-company — تُنشأ إن غابت (بيئة قابلة للتصفير)
const meA0 = (await req("GET", "/auth/me", owner)).body.data;
let coList = (await req("GET", "/admin/companies", owner)).body.data ?? [];
let coB = coList.find((c) => c.code === "CO-B");
if (!coB) {
  const created = await req("POST", "/admin/companies", owner, {
    code: "CO-B", name: "شركة B للتوزيع والتجارة", name_en: "Company B Trading",
  });
  coB = created.body?.data;
  if (!coB) { console.error("تعذر إنشاء شركة CO-B:", JSON.stringify(created.body).slice(0, 200)); process.exit(1); }
}
const coBId = coB.companyId ?? coB.id; // إنشاء جديد يعيد companyId — القائمة تعيد id
const ownerB = (await req("POST", "/auth/switch-company", owner, { company_id: coBId })).body.data.access_token;
const me = meA0;
const companyId = me.company.id;
console.log(`company A = ${me.company.name} (#${companyId}) · company B = ${coB.name} (#${coB.id})`);

const cats = (await req("GET", "/categories", owner)).body.data ?? [];
if (!cats.length) { console.error("لا تصنيفات للاختبار"); process.exit(1); }
const catA = cats[0];

const prods = (await req("GET", "/products?per_page=100", owner)).body.data ?? [];
if (!prods.length) { console.error("لا منتجات للاختبار"); process.exit(1); }
const target = prods.find((p) => p.sale_price > 0) ?? prods[0];
console.log(`target product #${target.id} ${target.code} sale=${target.sale_price}`);

// ---- §1 تعديل المنتج: اسم + سعر + حد تنبيه ---------------------------
{
  const newName = `${target.name} (محدّث ${Date.now() % 10000})`;
  const newPrice = target.sale_price + 250;
  const { status, body } = await req("PATCH", `/products/${target.id}`, owner, {
    name: newName, sale_price: newPrice, min_stock: 7,
  });
  check("PATCH يعدّل الاسم والسعر وحد التنبيه", status === 200 && body?.data?.name === newName && body?.data?.sale_price === newPrice, `status=${status} ${JSON.stringify(body).slice(0, 150)}`);

  const after = (await req("GET", `/products?q=${encodeURIComponent(target.code)}`, owner)).body.data?.find?.((p) => p.id === target.id);
  check("GET بعد التعديل يُظهر القيم الجديدة", !!after && after.sale_price === newPrice && after.min_stock === 7, JSON.stringify(after ?? {}).slice(0, 150));
}

// ---- §2 تعديل: التصنيف + العبوات + التفعيل ---------------------------
{
  // Phase 2 §3: إضافة تعبئة تتطلب وحدة أساس مختلفة عن وحدة التعبئة —
  // نغيّر الوحدة الأساسية إلى «علبة» ثم نربط التعبئة «كرتونة»×12
  const { status, body } = await req("PATCH", `/products/${target.id}`, owner, {
    unit: "علبة",
    category_id: catA.id,
    pack_unit: "كرتونة", pack_qty: 12, pack_sale_price: target.sale_price * 12 - 500,
  });
  check("PATCH يربط التصنيف ويضبط العبوة", status === 200 && body?.data?.category_id === catA.id && body?.data?.pack_unit === "كرتونة" && body?.data?.pack_qty === 12, `status=${status} ${JSON.stringify(body).slice(0, 150)}`);

  // إزالة العبوة (pack_unit فارغ → null)
  const r2 = await req("PATCH", `/products/${target.id}`, owner, { pack_unit: "" });
  check("PATCH يزيل العبوة بحقل فارغ", r2.status === 200 && r2.body?.data?.pack_unit === null && r2.body?.data?.pack_qty === null, JSON.stringify(r2.body).slice(0, 120));

  // تعطيل ثم تفعيل
  const off = await req("PATCH", `/products/${target.id}`, owner, { is_active: false });
  const on = await req("PATCH", `/products/${target.id}`, owner, { is_active: true });
  check("PATCH يبدّل التفعيل/التعطيل", off.status === 200 && off.body?.data?.is_active === false && on.status === 200 && on.body?.data?.is_active === true);
}

// ---- §3 حواجز التعديل: تصنيف عابر للشركات + منتج شركة أخرى -----------
{
  // تصنيف لشركة B — أنشئه عبر جلسة B ثم حاول ربطه من جلسة A
  const cb = await req("POST", "/categories", ownerB, { name: `تصنيف-B-${Date.now() % 100000}` });
  const catBId = cb.body?.data?.id;
  check("شركة B أنشأت تصنيفها", cb.status === 201 && !!catBId, JSON.stringify(cb.body).slice(0, 120));

  const cross = await req("PATCH", `/products/${target.id}`, owner, { category_id: catBId });
  check("ربط منتج A بتصنيف B مرفوض VAL_003 (404 بلا تسريب)", cross.status === 404 && cross.body?.code === "VAL_003", `status=${cross.status} ${JSON.stringify(cross.body).slice(0, 150)}`);

  // منتج شركة B من جلسة A → غير موجود (بلا تسريب). أنشئ منتجًا لـ B إن لم يكن لديها
  let prodsB = (await req("GET", "/products?per_page=100", ownerB)).body.data ?? [];
  if (!prodsB.length) {
    const mkB = await req("POST", "/products", ownerB, {
      name: "منتج B لاختبار العزل", sale_price: 1000, cost_price: 700,
    });
    if (mkB.status === 201) prodsB = [mkB.body.data];
  }
  if (prodsB.length) {
    const idor = await req("PATCH", `/products/${prodsB[0].id}`, owner, { name: "اختراق" });
    check("PATCH منتج شركة أخرى → 404 بلا تسريب", idor.status === 404, `status=${idor.status}`);
  }

  // حقل مرفوض: sale_price سالب
  const neg = await req("PATCH", `/products/${target.id}`, owner, { sale_price: -5 });
  check("سعر سالب مرفوض VAL_002 (422)", neg.status === 422 || neg.status === 400, `status=${neg.status}`);
}

// ---- §4 فاتورة دولارية: تخزين دينار + توثيق العملة والسعر ------------
const customers = (await req("GET", "/customers?per_page=100", owner)).body.data ?? [];
const walkin = customers.find((c) => c.customer_type === "WALKIN" || c.is_walkin) ?? customers[0];
const whs = (await req("GET", "/admin/warehouses", owner)).body?.data ?? [];
const wh = whs.find((w) => w.is_active !== false) ?? whs[0];
const stockProds = (await req("GET", "/products?per_page=100", owner)).body.data ?? [];
const stockP = stockProds.find((p) => p.stock_total > 0 && p.sale_price > 0);
console.log(`walkin=#${walkin?.id} wh=#${wh?.id} stockP=#${stockP?.id} (${stockP?.stock_total})`);

let usdInvoiceId = null;
if (walkin && wh && stockP) {
  const RATE = 1300;
  const create = await req("POST", "/sales/invoices", owner, {
    customer_id: walkin.id, warehouse_id: wh.id, type: "CASH",
    currency: "USD", exchange_rate: RATE,
    lines: [{ product_id: stockP.id, qty: 1 }],
  });
  check("فواتير USD تُرحّل 201", create.status === 201, `status=${create.status} ${JSON.stringify(create.body).slice(0, 200)}`);
  const inv = create.body?.data;
  usdInvoiceId = inv?.id ?? null;
  check("الاستجابة توثق currency_code=USD", inv?.currency_code === "USD", `status=${create.status} ${JSON.stringify(inv ?? create.body ?? "null").slice(0, 200)}`);
  check("الاستجابة توثق exchange_rate=1300", inv?.exchange_rate === RATE, `got=${inv?.exchange_rate}`);
  // الإجمالي المخزن يبقى بالدينار (سعر الحبة دون تحويل — المُدخل دينار)
  check("المخزن يبقى بالدينار (grand_total د.ع)", inv?.grand_total === stockP.sale_price, `got=${inv?.grand_total} expected=${stockP.sale_price}`);

  // التفاصيل تعيد حقول العملة
  const det = await req("GET", `/sales/invoices/${usdInvoiceId}`, owner);
  check("GET التفاصيل تعيد currency_code + exchange_rate", det.status === 200 && det.body?.data?.currency_code === "USD" && det.body?.data?.exchange_rate === RATE, `status=${det.status}`);

  // فاتورة USD بلا سعر صرف → VAL_001
  const noRate = await req("POST", "/sales/invoices", owner, {
    customer_id: walkin.id, warehouse_id: wh.id, type: "CASH",
    currency: "USD",
    lines: [{ product_id: stockP.id, qty: 1 }],
  });
  check("USD بلا سعر صرف → VAL_001 (422)", noRate.status === 422 && noRate.body?.code === "VAL_001", `status=${noRate.status} ${JSON.stringify(noRate.body).slice(0, 150)}`);

  // سعر صرف غير صالح
  const badRate = await req("POST", "/sales/invoices", owner, {
    customer_id: walkin.id, warehouse_id: wh.id, type: "CASH",
    currency: "USD", exchange_rate: -3,
    lines: [{ product_id: stockP.id, qty: 1 }],
  });
  check("سعر صرف سالب مرفوض (422)", badRate.status === 422 || badRate.status === 400, `status=${badRate.status}`);

  // فاتورة IQD عادية: العملة الافتراضية IQD
  const iqd = await req("POST", "/sales/invoices", owner, {
    customer_id: walkin.id, warehouse_id: wh.id, type: "CASH",
    lines: [{ product_id: stockP.id, qty: 1 }],
  });
  check("فاتورة بلا حقل عملة → IQD افتراضيًا", iqd.status === 201 && iqd.body?.data?.currency_code === "IQD" && iqd.body?.data?.exchange_rate === null, `status=${iqd.status} ${JSON.stringify(iqd.body?.data ?? iqd.body ?? "null").slice(0, 120)}`);

  // القائمة تعيد currency_code
  const list = (await req("GET", "/sales/invoices?per_page=5", owner)).body.data ?? [];
  check("قائمة الفواتير تعيد currency_code", list.length > 0 && "currency_code" in list[0]);
}

// ---- §5 عزل عملة/تعديل عبر الشركات -----------------------------------
{
  // جلسة B لا ترى فاتورة A إطلاقًا
  if (usdInvoiceId) {
    const idor = await req("GET", `/sales/invoices/${usdInvoiceId}`, ownerB);
    check("فاتورة A غير مرئية لشركة B (404)", idor.status === 404, `status=${idor.status}`);
  }
}

console.log("\n=== النتائج ===");
for (const r of results) console.log(r);
console.log(`\nPASS=${PASS} FAIL=${FAIL}`);
process.exit(FAIL ? 1 : 0);
