#!/usr/bin/env bash
# =============================================================
# create-full-backup-v15-2026-09-23.sh
# أرشيف النظام الكامل v15 — Kayan ERP Advanced Finance Completion
#
# جولة كاملة لتنفيذ 42 مرحلة (5 أولوية عالية + 5 متوسطة + 5 تقنية + 5 مبتكرة):
#   - RepSettlement (تسليمات المندوبين REP-STL-) + UI panel
#   - OverdueNotification (إشعارات الديون المتأخرة + WhatsApp URL)
#   - ESC/POS thermal printing raw bytes (Xprinter/Epson)
#   - Financial audit log UI tab (filters + diff viewer)
#   - Daily receipts PDF report (المرحلة 42)
#   - CostCenter on CashTransaction + PaymentVoucher (Phase 21)
#   - Budget vs Actual panel + alerts (Phase 23-25)
#   - Email statement via SMTP stub (Phase 26-28)
#   - Exchange rate history + auto fetcher (Phase 29-30)
#   - Enhanced finance dashboard: 5 KPI cards + cash movement chart
#   - Live cashbox balance polling endpoint (Phase 34-35)
#   - FinanceErrorLog centralized log (Phase 37)
#   - BackupLog history (Phase 38)
#   - POS interface for field reps (/pos page)
#   - Interactive visual statement (/statement page)
#   - AI insights (rule-based, ready for LLM enhancement)
#   - Low balance alerts on finance dashboard
#   - E-invoicing stub (ZATCA / Iraqi / EU formats)
#   - 4 new permissions (close/reopen/reconcile/allocate)
#   - 12 new permission codes (rep_settlements, overdue_notifications,
#     exchange_rates, finance_errors, backup_logs)
#
# ** الأرشيف يتضمن .next/standalone جاهزًا للتشغيل (بناء مسبق)
# =============================================================
set -euo pipefail

ROOT="/home/z/my-project"
OUT="$ROOT/download/kayan-system-full-backup-2026-09-23-v15.zip"
SNAP="$ROOT/backups/custom-snapshot-20260923-v15.db"
STAGE="$ROOT/.zstage"
CHK="$ROOT/backups/.dbcheck-v15"

echo "==> 1) لقطة DB متسقة…"
python3 "$ROOT/scripts/snapshot-db.py" "$SNAP"
SNAP_MD5="$(md5sum "$SNAP" | cut -d' ' -f1)"
echo "snapshot_md5=$SNAP_MD5"

echo "==> 2) staging وحقن اللقطة…"
rm -rf "$STAGE"
mkdir -p "$STAGE/db"
cp "$SNAP" "$STAGE/db/custom.db"

echo "==> 3) أرشفة المصدر (بلا node_modules/.next/backups)…"
rm -f "$OUT"
( cd "$STAGE" && zip -q -X "$OUT" db/custom.db )
cd "$ROOT"
zip -qr "$OUT" . \
  -x "node_modules/*" \
  -x ".next/*" \
  -x "backups/*" \
  -x "skills/*" \
  -x "tool-results/*" \
  -x "download/*" \
  -x ".pkg-*/*" \
  -x ".zscripts/*" \
  -x ".zstage/*" \
  -x "repo/*" \
  -x "upload/*" \
  -x "examples/*" \
  -x "mini-services/*" \
  -x "tsconfig.tsbuildinfo" \
  -x "db/custom.db" \
  -x "db/custom.db-journal" \
  -x "db/custom.db-wal" \
  -x "db/custom.db-shm"

echo "==> 4) ضم الـ standalone الجاهز (بناء مسبق)…"
[ -f ".next/standalone/.next/BUILD_ID" ] || { echo "لا يوجد BUILD_ID"; exit 1; }
[ -d ".next/standalone/.next/static" ]  || { echo "لا يوجد static"; exit 1; }
[ -d ".next/standalone/public" ]        || { echo "لا يوجد public"; exit 1; }
[ -d ".next/standalone/node_modules/.prisma" ] || { echo "لا يوجد prisma client"; exit 1; }
( cd .next && zip -qr "$OUT" standalone )
echo "  BUILD_ID المضمّن: $(cat .next/standalone/.next/BUILD_ID)"

echo "==> 5) التحقق…"
unzip -t "$OUT" > "$ROOT/backups/.unzip-t-v15.txt" 2>&1 \
  && echo "unzip -t: OK ($(tail -1 "$ROOT/backups/.unzip-t-v15.txt"))" \
  || { echo "unzip -t FAILED"; tail -5 "$ROOT/backups/.unzip-t-v15.txt"; exit 1; }

COUNT="$(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
SIZE="$(stat -c%s "$OUT")"
MD5="$(md5sum "$OUT" | cut -d' ' -f1)"
SHA256="$(sha256sum "$OUT" | cut -d' ' -f1)"
NEXT_IN_ZIP="$(unzip -l "$OUT" | grep -c "standalone/.next/" || true)"

rm -rf "$CHK"; mkdir -p "$CHK"
unzip -q "$OUT" "db/custom.db" -d "$CHK"
ARCH_MD5="$(md5sum "$CHK/db/custom.db" | cut -d' ' -f1)"
TABLES="$(python3 -c "
import sqlite3
c = sqlite3.connect('$CHK/db/custom.db')
print(len(c.execute(\"select name from sqlite_master where type='table' and name not like 'sqlite_%'\").fetchall()))
")"
rm -rf "$CHK"
if [ "$ARCH_MD5" = "$SNAP_MD5" ]; then DB_MATCH=YES; else DB_MATCH=NO; fi

echo "=============================================="
echo "OUT     : $OUT"
echo "SIZE    : $SIZE bytes ($((SIZE/1024/1024))MB)"
echo "FILES   : $COUNT"
echo "NEXT    : $NEXT_IN_ZIP ملف standalone داخل الأرشيف"
echo "MD5     : $MD5"
echo "SHA256  : $SHA256"
echo "DB_MATCH: $DB_MATCH"
echo "DB_TABLES: $TABLES"
echo "=============================================="
[ "$DB_MATCH" = "YES" ] || exit 1
[ "$NEXT_IN_ZIP" -gt 100 ] || { echo "الـ standalone ناقص!"; exit 1; }
echo "DONE_OK"
