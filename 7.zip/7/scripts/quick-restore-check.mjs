// فحص سريع بعد استعادة الحاوية: تعديل المنتجات + فاتورة دولار
const BASE = "http://localhost:3000/api/v1";
let PASS = 0, FAIL = 0;
const t = (name, ok) => { ok ? PASS++ : FAIL++; console.log(`${ok ? "✓" : "✗"} ${name}`); };

const login = await fetch(`${BASE}/auth/login`, {
  method: "POST", headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ username: "admin", password: "Admin@123" }),
}).then(r => r.json());
const token = login?.data?.access_token;
t("تسجيل الدخول", !!token);
const H = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };

// 1) قائمة المنتجات
const prods = await fetch(`${BASE}/products?per_page=5`, { headers: H }).then(r => r.json());
const p0 = prods?.data?.[0];
t("قائمة المنتجات تعمل", !!p0);

// 2) تعديل منتج (اسم جزئي + سعر)
if (p0) {
  const newName = p0.name + " (محدّث)";
  const patch = await fetch(`${BASE}/products/${p0.id}`, {
    method: "PATCH", headers: H,
    body: JSON.stringify({ name: newName, sale_price: 7250 }),
  }).then(r => r.json());
  t("PATCH تعديل منتج يعمل", patch?.success === true);
  t("الاسم عُدّل فعلاً", patch?.data?.name === newName);
  // إرجاع الاسم الأصلي
  await fetch(`${BASE}/products/${p0.id}`, {
    method: "PATCH", headers: H, body: JSON.stringify({ name: p0.name }),
  }).then(r => r.json());
  t("إرجاع الاسم الأصلي", true);
}

// 3) فاتورة بالدولار
const whs = await fetch(`${BASE}/admin/warehouses`, { headers: H }).then(r => r.json());
const whId = whs?.data?.[0]?.id ?? whs?.data?.items?.[0]?.id;
t("قائمة المستودعات تعمل", !!whId);
const inv = await fetch(`${BASE}/sales/invoices`, {
  method: "POST", headers: H,
  body: JSON.stringify({
    customer_id: 1,
    warehouse_id: whId,
    type: "CASH",
    currency: "USD",
    exchange_rate: 1310,
    lines: [{ product_id: p0?.id ?? 1, qty: 1, unit_price: 5.5 }],
  }),
}).then(r => r.json());
t("إنشاء فاتورة USD يعمل", inv?.success === true && inv?.data?.id > 0);
t("الفاتورة محفوظة بعملة USD وسعر صرف", inv?.data?.currency_code === "USD" && Number(inv?.data?.exchange_rate) === 1310);

// 4) فاتورة دينار عادية (افتراضي)
const inv2 = await fetch(`${BASE}/sales/invoices`, {
  method: "POST", headers: H,
  body: JSON.stringify({
    customer_id: 1,
    warehouse_id: whId,
    type: "CASH",
    lines: [{ product_id: p0?.id ?? 1, qty: 1, unit_price: 5000 }],
  }),
}).then(r => r.json());
t("فاتورة IQD افتراضية تعمل", inv2?.success === true && (inv2?.data?.currency_code ?? "IQD") === "IQD");

console.log(`\n=== ${PASS}/${PASS + FAIL} ===`);
process.exit(FAIL ? 1 : 0);
