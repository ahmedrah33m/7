const Database = require('/home/z/my-project/node_modules/better-sqlite3');
const db = new Database('/home/z/my-project/db/custom.db', {readonly:true});
const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all().map(r=>r.name);
console.log('tables:', tables.length);
console.log(tables.join(','));
try { console.log('users:', db.prepare('SELECT COUNT(*) c FROM users').get().c); } catch(e) { console.log('no users table'); }
try { const s = db.prepare('SELECT key, value FROM settings').all(); console.log('settings:', s.map(r=>r.key+'='+String(r.value).slice(0,24)).join(' | ')); } catch(e){ console.log('settings err', e.message); }
