/**
 * إصلاح أسعار منتج «شامبو لوميرا معالج - 400 مل 1x11» في شركة لوميره (id=2)
 *
 * المشكلة: الأسعار أُدخلت بأرقام الدولار لكن النظام يخزّن الدينار (عملة الأساس):
 *   - pack_sale_price = 26  (تعني 26 د.ع بدل 26$ = 40,300 د.ع بسعر صرف 1550)
 *   - sale_price      = 26  (الحبة!) — الحبة الصحيحة = سعر الكارتون ÷ 11
 *   - cost_price      = 38750 = 25$ × 1550 ✓ صحيحة
 *
 * القيم الجديدة (سعر الصرف المستنتج من التكلفة: 38750 ÷ 25 = 1550 د.ع/$):
 *   - pack_sale_price = 26 × 1550 = 40,300 د.ع  (تظهر $26 بالضبط عند سعر صرف 1550)
 *   - sale_price      = 40300 ÷ 11  = 3,663.636… د.ع (تظهر ≈ $2.36، و11 حبة = كارتون كامل)
 *   - cost_price      = 38,750 د.ع (تبقى = $25)
 */
import * as React from "react";

const BASE = "http://localhost:3000";
const RATE = 1550; // د.ع لكل $1 — مستنتج من التكلفة المخزنة (38750 ÷ 25)
const PACK_QTY = 11;
const PACK_USD = 26;
const COST_USD = 25;
const PRODUCT_ID = 10;

interface LoginResp {
  success: boolean;
  data?: { access_token?: string };
  message?: string;
}

async function main() {
  // 1) تسجيل الدخول
  const loginRes = await fetch(`${BASE}/api/v1/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: "admin", password: "Admin@123" }),
  });
  const login = (await loginRes.json()) as LoginResp;
  if (!login.success || !login.data?.access_token) {
    throw new Error(`LOGIN_FAILED: ${login.message ?? JSON.stringify(login)}`);
  }
  const token1 = login.data.access_token;

  // 2) التبديل إلى شركة لوميره (id=2)
  const swRes = await fetch(`${BASE}/api/v1/auth/switch-company`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token1}` },
    body: JSON.stringify({ company_id: 2 }),
  });
  const sw = (await swRes.json()) as LoginResp;
  if (!sw.success || !sw.data?.access_token) {
    throw new Error(`SWITCH_COMPANY_FAILED: ${sw.message ?? JSON.stringify(sw)}`);
  }
  const token = sw.data.access_token;
  console.log("✓ دخول + تبديل إلى شركة لوميره");

  const H = { "Content-Type": "application/json", Authorization: `Bearer ${token}` };

  // 3) قراءة الوضع الحالي للمنتج
  const curRes = await fetch(`${BASE}/api/v1/products?per_page=100`, { headers: H });
  const cur = (await curRes.json()) as {
    success: boolean;
    data?: { id: number; code: string; name: string; unit: string; pack_unit: string | null; pack_qty: number | null; pack_sale_price: number | null; sale_price: number; cost_price: number }[];
  };
  const products = cur.data ?? [];
  const target = products.find((p) => p.id === PRODUCT_ID) ?? products.find((p) => p.name.includes("شامبو"));
  if (!target) throw new Error("PRODUCT_NOT_FOUND في شركة لوميره");
  console.log("قبل:", JSON.stringify(target, null, 2));

  // 4) الترقيع الصحيح
  const packSalePrice = PACK_USD * RATE; // 40300
  const salePrice = Math.round((packSalePrice / PACK_QTY) * 1e6) / 1e6; // 3663.636364

  const patchRes = await fetch(`${BASE}/api/v1/products/${target.id}`, {
    method: "PATCH",
    headers: H,
    body: JSON.stringify({
      name: "شامبو لوميرا معالج - 400 مل 1x11",
      unit: "علبة",
      pack_unit: "كارتون",
      pack_qty: PACK_QTY,
      pack_sale_price: packSalePrice,
      sale_price: salePrice,
      cost_price: COST_USD * RATE, // 38750 — نفس القيمة (25$)
    }),
  });
  const patched = (await patchRes.json()) as { success: boolean; data?: Record<string, unknown>; message?: string };
  if (!patched.success) throw new Error(`PATCH_FAILED: ${patched.message ?? JSON.stringify(patched)}`);
  console.log("\nبعد:", JSON.stringify(patched.data, null, 2));

  // 5) تحقّق حسابي
  const p = patched.data as { pack_sale_price: number; sale_price: number; cost_price: number };
  console.log("\n=== التحقق ===");
  console.log(`سعر الكارتون: ${p.pack_sale_price} د.ع ÷ ${RATE} = $${(p.pack_sale_price / RATE).toFixed(2)}`);
  console.log(`سعر العلبة:   ${p.sale_price.toFixed(2)} د.ع ÷ ${RATE} = $${(p.sale_price / RATE).toFixed(4)}`);
  console.log(`11 علبة = ${(p.sale_price * PACK_QTY).toFixed(2)} د.ع (يجب أن تساوي الكارتون ${p.pack_sale_price})`);
  console.log(`التكلفة:     ${p.cost_price} د.ع ÷ ${RATE} = $${(p.cost_price / RATE).toFixed(2)}`);
  console.log(`هامش الكارتون: $${(PACK_USD - COST_USD).toFixed(2)} × كارتون`);
}

main().catch((e) => {
  console.error("FIX_ERROR:", e instanceof Error ? e.message : e);
  process.exit(1);
});
