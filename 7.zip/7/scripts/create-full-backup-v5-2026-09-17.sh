#!/usr/bin/env bash
# =============================================================
# create-full-backup-v5-2026-09-17.sh
# إنشاء أرشيف النظام الكامل v5 بأحدث التعديلات (ما بعد إصلاح decimal.js
# وتنظيف Legacy ومزامنة DB):
#   1) لقطة متسقة لقاعدة البيانات الحية (snapshot-db.py — SQLite Backup API)
#   2) حقن اللقطة في الأرشيف مكان db/custom.db عبر staging (.zstage)
#      للحفاظ على المسار الصحيح داخل الأرشيف دون لمس القاعدة الحية
#   3) الاستثناءات (نمط v1/v2): node_modules/.next/skills/tool-results/
#      download/.pkg-v5/.zscripts/.zstage/tsconfig.tsbuildinfo + db/custom.db الحية
#   4) تحقق: unzip -t + عدد الملفات + MD5/SHA256 + مطابقة DB داخل الأرشيف
# =============================================================
set -euo pipefail

ROOT="/home/z/my-project"
OUT="$ROOT/download/kayan-system-full-backup-2026-09-17-v5.zip"
SNAP="$ROOT/backups/custom-snapshot-20260917-v5.db"
STAGE="$ROOT/.zstage"
CHK="$ROOT/backups/.dbcheck-v5"

echo "==> 1) لقطة DB متسقة…"
python3 "$ROOT/scripts/snapshot-db.py" "$SNAP"
SNAP_MD5="$(md5sum "$SNAP" | cut -d' ' -f1)"
echo "snapshot_md5=$SNAP_MD5"

echo "==> 2) staging وحقن اللقطة…"
rm -rf "$STAGE"
mkdir -p "$STAGE/db"
cp "$SNAP" "$STAGE/db/custom.db"

echo "==> 3) بناء الأرشيف…"
rm -f "$OUT"
( cd "$STAGE" && zip -q -X "$OUT" db/custom.db )
cd "$ROOT"
zip -qr "$OUT" . \
  -x "node_modules/*" \
  -x ".next/*" \
  -x "skills/*" \
  -x "tool-results/*" \
  -x "download/*" \
  -x ".pkg-v5/*" \
  -x ".pkg-v4/*" \
  -x ".zscripts/*" \
  -x ".zstage/*" \
  -x "tsconfig.tsbuildinfo" \
  -x "db/custom.db" \
  -x "db/custom.db-journal" \
  -x "db/custom.db-wal" \
  -x "db/custom.db-shm"
rm -rf "$STAGE"

echo "==> 4) التحقق…"
unzip -t "$OUT" > "$ROOT/backups/.unzip-t-v5.txt" 2>&1 \
  && echo "unzip -t: OK ($(tail -1 "$ROOT/backups/.unzip-t-v5.txt"))" \
  || { echo "unzip -t FAILED"; cat "$ROOT/backups/.unzip-t-v5.txt"; exit 1; }

COUNT="$(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
SIZE="$(stat -c%s "$OUT")"
MD5="$(md5sum "$OUT" | cut -d' ' -f1)"
SHA256="$(sha256sum "$OUT" | cut -d' ' -f1)"

rm -rf "$CHK"; mkdir -p "$CHK"
unzip -q "$OUT" "db/custom.db" -d "$CHK"
ARCH_MD5="$(md5sum "$CHK/db/custom.db" | cut -d' ' -f1)"
rm -rf "$CHK"
if [ "$ARCH_MD5" = "$SNAP_MD5" ]; then DB_MATCH=YES; else DB_MATCH=NO; fi

echo "=============================================="
echo "OUT    : $OUT"
echo "SIZE   : $SIZE bytes ($((SIZE/1024/1024))MB)"
echo "FILES  : $COUNT"
echo "MD5    : $MD5"
echo "SHA256 : $SHA256"
echo "DB_MATCH: $DB_MATCH"
echo "=============================================="
[ "$DB_MATCH" = "YES" ] || exit 1
echo "DONE_OK"
