#!/usr/bin/env bash
# رابط ثالث مُتحقق — مزودون إضافيون بعد نجاح gofile وتحفظ filebin
set -uo pipefail
ROOT="/home/z/my-project"
F="$ROOT/download/kayan-system-full-backup-2026-09-17.zip"
NAME="$(basename "$F")"
MD5="$(md5sum "$F" | cut -d' ' -f1)"
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
LOG="$ROOT/backups/upload-2026-09-17-extra.log"
: > "$LOG"
log() { echo "[$(date +%H:%M:%S)] $*" >> "$LOG"; }

verify_dl() {
  local out="$ROOT/backups/verify-x.bin"
  rm -f "$out"
  curl -sL -m 200 --connect-timeout 15 -A "$UA" "$1" -o "$out" 2>/dev/null || { rm -f "$out"; return 1; }
  [ -s "$out" ] || { rm -f "$out"; return 1; }
  local m; m="$(md5sum "$out" | cut -d' ' -f1)"
  rm -f "$out"
  [ "$m" = "$MD5" ]
}

# 1) x0.at (احتفاظ طويل ~سنة، حتى ~100-180MB)
echo "==> x0.at …"
R="$(curl -s -m 420 --connect-timeout 20 -A "$UA" -D - -F "file=@${F}" https://x0.at 2>/dev/null | grep -oE 'https://x0\.at/[A-Za-z0-9._/-]+' | head -1)"
if [ -n "$R" ]; then
  if verify_dl "$R"; then echo "OK x0.at: $R"; log "GOOD|x0.at|$R"; else echo "x0.at رفع لكن MD5 لا يطابق: $R"; log "fail|x0.at|md5|$R"; fi
else echo "x0.at فشل"; log "fail|x0.at|no-url"; fi

# 2) uguu.se (حتى 128MB، ~24-48 ساعة)
if [ ! -s "$LOG" ] || ! grep -q GOOD "$LOG"; then
  echo "==> uguu.se …"
  R="$(curl -s -m 420 --connect-timeout 20 -A "$UA" -F "files[]=@${F}" https://uguu.se/upload 2>/dev/null \
       | python3 -c 'import sys,json;d=json.load(sys.stdin);print(d["files"][0]["url"])' 2>/dev/null || true)"
  if [ -n "${R:-}" ]; then
    if verify_dl "$R"; then echo "OK uguu: $R"; log "GOOD|uguu|$R"; else echo "uguu رفع لكن MD5 لا يطابق: $R"; log "fail|uguu|md5|$R"; fi
  else echo "uguu فشل"; log "fail|uguu|no-url"; fi
fi

# 3) temp.sh (بضعة أيام)
if ! grep -q GOOD "$LOG" 2>/dev/null; then
  echo "==> temp.sh …"
  R="$(curl -s -m 420 --connect-timeout 20 -A "$UA" -T "${F}" https://temp.sh/upload 2>/dev/null | grep -oE 'https://temp\.sh/[A-Za-z0-9]+/' | head -1)"
  if [ -n "${R:-}" ]; then
    DURL="${R}${NAME}"
    if verify_dl "$DURL"; then echo "OK temp.sh: $DURL"; log "GOOD|tempsh|$DURL"; else echo "temp.sh رفع لكن MD5 لا يطابق: $DURL"; log "fail|tempsh|md5|$DURL"; fi
  else echo "temp.sh فشل"; log "fail|tempsh|no-url"; fi
fi

echo "=== RESULT ==="
grep GOOD "$LOG" 2>/dev/null || echo "NO_EXTRA_LINK"
echo "EXTRA_DONE"
