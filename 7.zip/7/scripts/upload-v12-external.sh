#!/usr/bin/env bash
# =============================================================
# upload-v12-external.sh — رفع أرشيف v12 (160MB، يتضمن البناء الجاهز)
# الوصفة المجرّبة: gofile.io (أساسي) + filebin.net (احتياطي) + litterbox 72h
# =============================================================
set -uo pipefail

ROOT="/home/z/my-project"
F="$ROOT/download/kayan-system-full-backup-2026-09-19-v12.zip"
MD5="648ea10f2ca4ec99070cad400b3d14fb"
SHA256="ea0c65f6488f987ac420bbb2ae5458d396cfe277a46823f6562613ef1d845867"
SIZE="$(stat -c%s "$F")"
UA="Mozilla/5.0 (X11; Linux x86_64) Maydan-Uploader/1.0"

echo "== الملف: $F"
echo "== الحجم: $SIZE بايت | MD5: $MD5"
echo

# ---------- 1) gofile.io ----------
echo "==> 1) الرفع عبر gofile.io…"
SRV="$(curl -s -m 30 https://api.gofile.io/servers 2>/dev/null | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"]["servers"][0]["name"])' 2>/dev/null || true)"
if [ -n "${SRV:-}" ]; then
  echo "    الخادم: $SRV — جارٍ رفع $((SIZE/1024/1024))MB (قد يستغرق دقائق)…"
  R="$(curl -s -m 900 -A "$UA" -F "file=@${F}" "https://${SRV}.gofile.io/contents/uploadfile" 2>/dev/null || true)"
  PAGE="$(echo "$R" | python3 -c 'import sys,json;d=json.load(sys.stdin)["data"];print(d.get("downloadPage",""))' 2>/dev/null || true)"
  GMd5="$(echo "$R" | python3 -c 'import sys,json;d=json.load(sys.stdin)["data"];print(d.get("md5","") or d.get("fileMd5",""))' 2>/dev/null || true)"
  if [ -n "${PAGE:-}" ]; then
    echo "    ✔ gofile OK: $PAGE"
    [ -n "${GMd5:-}" ] && { [ "$GMd5" = "$MD5" ] && echo "    ✔ md5 الخادم مطابق: $GMd5" || echo "    ✘ md5 الخادم مختلف: $GMd5"; }
    GOFILE_LINK="$PAGE"
  else
    echo "    ✘ gofile فشل: ${R:0:120}"
    GOFILE_LINK=""
  fi
else
  echo "    ✘ تعذر جلب خادم gofile"
  GOFILE_LINK=""
fi
echo

# ---------- 2) filebin.net ----------
BIN="maydan-backup-v12-$(date +%Y%m%d%H%M%S)"
FN="kayan-system-full-backup-2026-09-19-v12.zip"
echo "==> 2) الرفع عبر filebin.net (bin: $BIN)…"
CODE="$(curl -s -m 1800 -A "$UA" -o /dev/null -w "%{http_code}" -X PUT --upload-file "$F" "https://filebin.net/${BIN}/${FN}" 2>/dev/null || true)"
if [ "$CODE" = "201" ]; then
  echo "    ✔ filebin OK (HTTP 201): https://filebin.net/${BIN}/${FN}"
  FILEBIN_LINK="https://filebin.net/${BIN}/${FN}"
else
  echo "    ✘ filebin فشل (HTTP $CODE)"
  FILEBIN_LINK=""
fi
echo

# ---------- 3) litterbox 72h ----------
echo "==> 3) الرفع عبر litterbox (72 ساعة)…"
R="$(curl -s -m 1800 -A "$UA" -F reqtype=fileupload -F time=72h -F "fileToUpload=@${F}" https://litterbox.catbox.moe/resources/internals/api.php 2>/dev/null || true)"
if [[ "$R" == https://litter.catbox.moe/* ]]; then
  echo "    ✔ litterbox OK: $R"
  LITTER_LINK="$R"
else
  echo "    ✘ litterbox فشل: ${R:0:100}"
  LITTER_LINK=""
fi

echo
echo "==============================================="
echo "النتيجة النهائية:"
[ -n "${GOFILE_LINK:-}" ]   && echo "  gofile  : $GOFILE_LINK"
[ -n "${FILEBIN_LINK:-}" ]  && echo "  filebin : $FILEBIN_LINK"
[ -n "${LITTER_LINK:-}" ]   && echo "  litter  : $LITTER_LINK"
echo "  MD5     : $MD5"
echo "  SHA256  : $SHA256"
echo "==============================================="
