#!/usr/bin/env bash
# =============================================================
# qa-v4-package.sh — اختبار جودة حزمة v4 (محاكاة نشر Ubuntu)
# داخل .pkg-v4: تثبيت نظيف → db push → next build → تشغيل على
# منفذ 3010 (next start) و3011 (standalone) → فحص health + دخول admin
# =============================================================
set -uo pipefail

ROOT="/home/z/my-project"
STAGE="$ROOT/.pkg-v4"
PASS=0; FAIL=0
say() { echo -e "\n\033[1;36m==> $*\033[0m"; }
ok()  { echo -e "\033[1;32m✔ PASS: $*\033[0m"; PASS=$((PASS+1)); }
bad() { echo -e "\033[1;31m✘ FAIL: $*\033[0m"; FAIL=$((FAIL+1)); }

cd "$STAGE"

say "1) تثبيت نظيف للاعتماديات (bun install)…"
if bun install >/tmp/qa-bun-install.log 2>&1; then
  ok "bun install"
else
  bad "bun install — آخر 10 أسطر:"; tail -10 /tmp/qa-bun-install.log
fi

say "2) prisma db push على لقطة القاعدة…"
PUSH_OUT="$(npx prisma db push --skip-generate 2>&1)"
if echo "$PUSH_OUT" | grep -qE "already in sync|in sync|Done"; then
  ok "prisma db push: $(echo "$PUSH_OUT" | grep -E 'already in sync|Done' | head -1)"
else
  bad "prisma db push:"; echo "$PUSH_OUT" | tail -5
fi

say "3) البناء الإنتاجي (next build)…"
if bunx next build > /tmp/qa-build.log 2>&1; then
  ok "next build — $(grep -c 'ƒ\|λ\|○' /tmp/qa-build.log 2>/dev/null || echo '?') مسار"
  grep -E "Compiled successfully|✓" /tmp/qa-build.log | head -2
else
  bad "next build — آخر 25 سطراً:"; tail -25 /tmp/qa-build.log
fi

# ---------- اختبار next start ----------
say "4) تشغيل next start على 3010…"
PORT=3010 bunx next start -p 3010 > /tmp/qa-start.log 2>&1 &
S1=$!
for i in $(seq 1 30); do curl -s -m 2 http://127.0.0.1:3010/api/v1/health >/dev/null 2>&1 && break; sleep 1; done
H1="$(curl -s -m 5 http://127.0.0.1:3010/api/v1/health || echo CURL_FAIL)"
echo "$H1" | grep -q '"database":"up"' && ok "next start → health: database up" || { bad "health على 3010: $H1"; tail -5 /tmp/qa-start.log; }

L1="$(curl -s -m 5 -X POST http://127.0.0.1:3010/api/v1/auth/login -H 'Content-Type: application/json' -d '{"username":"admin","password":"Admin@123"}' || echo CURL_FAIL)"
echo "$L1" | grep -q '"success":true' && ok "دخول admin/Admin@123 على next start ✓" || { bad "دخول admin: $L1"; }
kill $S1 2>/dev/null; wait $S1 2>/dev/null

# ---------- اختبار standalone ----------
say "5) اختبار الخادم المدمج standalone (مخرجات next.config)…"
if [ -f .next/standalone/server.js ]; then
  mkdir -p .next/standalone/.next
  cp -r .next/static .next/standalone/.next/static 2>/dev/null
  DATABASE_URL="file:$STAGE/db/custom.db" PORT=3011 NODE_ENV=production node .next/standalone/server.js > /tmp/qa-standalone.log 2>&1 &
  S2=$!
  for i in $(seq 1 30); do curl -s -m 2 http://127.0.0.1:3011/api/v1/health >/dev/null 2>&1 && break; sleep 1; done
  H2="$(curl -s -m 5 http://127.0.0.1:3011/api/v1/health || echo CURL_FAIL)"
  echo "$H2" | grep -q '"database":"up"' && ok "standalone server.js → health: database up" || { bad "standalone health: $H2"; tail -8 /tmp/qa-standalone.log; }
  kill $S2 2>/dev/null; wait $S2 2>/dev/null
else
  bad "ملف .next/standalone/server.js غير موجود رغم output:standalone"
fi

echo
echo "=============================="
echo "QA النتيجة: PASS=$PASS FAIL=$FAIL"
[ $FAIL -eq 0 ] && echo "الحزمة جاهزة للنشر على Ubuntu ✔" || echo "توجد إخفاقات — يجب المعالجة قبل التسليم"
exit $FAIL
