// مسبار تشخيصي: هل exchangeRate حاضر لحظة القراءة بعد إنشاء فاتورة USD؟
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();
const BASE = "http://localhost:3000/api/v1";
const post = (path, auth, data) => fetch(`${BASE}${path}`, { method: "POST", headers: { ...auth, "content-type": "application/json" }, body: JSON.stringify(data) }).then((r) => r.json());
(async () => {
  const login = await post("/auth/login", {}, { username: "admin", password: "Admin@123" });
  const t1 = login.data?.access_token;
  // أحدث شركة P3D قائمة
  const companies = await fetch(`${BASE}/admin/companies`, { headers: { authorization: `Bearer ${t1}` } }).then((r) => r.json());
  const list = companies.data?.items ?? companies.data ?? [];
  const comp = (Array.isArray(list) ? list : []).filter((c) => String(c.code || "").startsWith("P3D")).pop();
  const sw = await post("/auth/switch-company", { authorization: `Bearer ${t1}` }, { company_id: comp.id });
  const auth = { authorization: `Bearer ${sw.data?.access_token}` };
  const me = await fetch(`${BASE}/auth/me`, { headers: auth }).then((r) => r.json());
  const wh = me.data?.warehouses?.[0];
  const walkin = await fetch(`${BASE}/customers/default-walkin`, { headers: auth }).then((r) => r.json());
  const prods = await fetch(`${BASE}/products?per_page=100`, { headers: auth }).then((r) => r.json());
  const prod = prods.data.find((p) => String(p.name).includes("P3D"));
  console.log("company:", comp.id, "product:", prod?.id);

  const inv = await post("/sales/invoices", auth, {
    customer_id: walkin.data?.id, warehouse_id: wh.id, type: "CASH", currency_code: "USD", exchange_rate: 1300,
    lines: [{ product_id: prod.id, package_qty: 0, loose_qty: 1 }],
  });
  console.log("HTTP ok:", inv.success, "id:", inv.data?.id, "grand:", inv.data?.grand_total);

  const row = await db.salesInvoice.findUnique({ where: { id: inv.data.id }, include: { lines: true } });
  console.log("row exchangeRate:", row?.exchangeRate, "| currencyCode:", row?.currencyCode, "| grand:", row?.grandTotal?.toString());
  console.log("keys:", Object.keys(row || {}).filter((k) => /exch|curr|grand/i.test(k)).join(","));
  const raw = await db.$queryRawUnsafe(`SELECT exchange_rate, currency_code, grand_total FROM sales_invoices WHERE id = ${inv.data.id}`);
  console.log("raw:", JSON.stringify(raw, (k, v) => typeof v === "bigint" ? v.toString() : v));
  await db.$disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
