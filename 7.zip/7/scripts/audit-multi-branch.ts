// =====================================================================
// Phase 0 Audit — فحص الوضع الحالي للنطاقات (شركة/فرع/مستودع) والعملاء
// =====================================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const companies = await db.company.findMany({ where: { deletedAt: null } });
  console.log("== companies ==");
  for (const c of companies) console.log(c.id, c.name);

  const branches = await db.branch.findMany({ where: { deletedAt: null } });
  console.log("== branches ==");
  for (const b of branches) console.log(b.id, "co:", b.companyId, b.code, b.name, "active:", b.isActive);

  const whs = await db.warehouse.findMany({ where: { deletedAt: null } });
  console.log("== warehouses ==");
  for (const w of whs) console.log(w.id, "co:", w.companyId, "br:", w.branchId, w.code, w.name, w.type);

  const users = await db.user.findMany({
    where: { deletedAt: null },
    include: { roles: { include: { role: true } }, warehouseAccess: true },
  });
  console.log("== users ==");
  for (const u of users)
    console.log(
      u.id,
      "co:", u.companyId,
      "br:", u.branchId,
      u.username,
      "roles:", u.roles.map((r) => r.role.code).join("+"),
      "wh:", u.warehouseAccess.map((a) => a.warehouseId).join(",") || "-"
    );

  const uwAcc = await db.userWarehouseAccess.findMany();
  console.log("== user_warehouse_access ==", uwAcc.length, "rows");
  for (const a of uwAcc) console.log("user:", a.userId, "wh:", a.warehouseId, "read:", a.canRead, "op:", a.canOperate);

  // customer situation
  const customers = await db.customer.findMany({ where: { deletedAt: null } });
  console.log("== customers ==", customers.length);
  for (const c of customers.slice(0, 12)) console.log(c.id, "co:", c.companyId, c.code, c.name, "status:", c.status);

  // check if any customer_type-like column exists in invoices
  const inv = await db.salesInvoice.findFirst({ include: { customer: true } });
  console.log("== sample invoice ==", inv ? { id: inv.id, no: inv.number, type: inv.type, saleType: inv.saleType, cust: inv.customer.name } : "none");

  const settings = await db.setting.findMany();
  console.log("== settings ==");
  for (const s of settings) console.log(s.key, "=", s.value?.slice(0, 60));

  // roles
  const roles = await db.role.findMany({ where: { deletedAt: null } });
  console.log("== roles ==", roles.map((r) => `${r.id}:${r.code}`).join(" | "));
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
