// =====================================================================
// Master-data acceptance suite (Task 18) — units of measure ·
// product-unit conversions · price lists · customer assignment ·
// pricing resolution in invoices/orders. Real HTTP + DB assertions.
// Exit 0 = all pass.
// =====================================================================

import { PrismaClient } from "@prisma/client";

const BASE = "http://localhost:3000/api/v1";
const db = new PrismaClient();

let pass = 0;
let fail = 0;

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  ✅ ${name}`);
  } else {
    fail++;
    console.log(`  ❌ ${name} ${detail ? "— " + detail : ""}`);
  }
}

async function req(method: string, path: string, token?: string, body?: unknown): Promise<{ status: number; body: any }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json };
}

async function main() {
  console.log("═══ Master-data verification — units · conversions · price lists ═══");

  // 0) logins
  const admin = await req("POST", "/auth/login", undefined, { username: "admin", password: "Admin@123" });
  check("admin login", admin.status === 200 && admin.body.success);
  const T = admin.body.data?.access_token as string;

  const cashier = await req("POST", "/auth/login", undefined, { username: "cashier", password: "Cashier@123" });
  const CT = cashier.body.data?.access_token as string;
  check("cashier login", cashier.status === 200);

  // 1) units
  const units = await req("GET", "/units", T);
  check("units list (6 seeded)", units.status === 200 && (units.body.data?.length ?? 0) >= 6);
  const ctn = (units.body.data ?? []).find((u: any) => u.code === "CTN");

  const newUnit = await req("POST", "/units", T, { code: `T${Math.floor(Math.random() * 1e9)}`, name: "وحدة اختبار" });
  check("unit create 201", newUnit.status === 201);
  const dupUnit = await req("POST", "/units", T, { code: "CTN", name: "مكرر" });
  check("duplicate unit code → VAL_002", dupUnit.status === 409 && dupUnit.body.code === "VAL_002");
  const unitNoPerm = await req("POST", "/units", CT, { code: "X1", name: "ممنوع" });
  check("cashier blocked from unit create (PERM_001)", unitNoPerm.status === 403);

  // 2) product units
  const products = (await req("GET", "/products?per_page=100", T)).body.data ?? [];
  const paste = products.find((p: any) => p.name.includes("معجون"));
  check("demo paste product exists", !!paste);
  const pasteUnits = await req("GET", `/product-units?product_id=${paste.id}`, T);
  const ctnLink = (pasteUnits.body.data ?? []).find((u: any) => u.unit?.code === "CTN");
  check("paste has CTN conversion (×24)", !!ctnLink && ctnLink.factor === 24, `factor=${ctnLink?.factor}`);
  check("unit price stored (22000)", ctnLink?.computed_price === 22000);

  const attach = await req("POST", "/product-units", T, { product_id: paste.id, unit_id: ctn.id, factor: 10 });
  check("duplicate product-unit → VAL_002", attach.status === 409 && attach.body.code === "VAL_002");

  const allLinks = await req("GET", "/product-units", T);
  check("all product-units list (no filter)", allLinks.status === 200 && (allLinks.body.data?.length ?? 0) >= 2);

  // 3) price lists
  const plists = await req("GET", "/price-lists", T);
  check("price lists list (WHOLESALE)", plists.status === 200 && (plists.body.data ?? []).some((l: any) => l.code === "WHOLESALE"));
  const wholesale = (plists.body.data ?? []).find((l: any) => l.code === "WHOLESALE");
  check("WHOLESALE has 3 items + 1 customer", wholesale.items_count === 3 && wholesale.customers_count >= 1, `${wholesale.items_count}/${wholesale.customers_count}`);

  const newPl = await req("POST", "/price-lists", T, { code: `PL${Math.floor(Math.random() * 1e9)}`, name: "قائمة اختبار" });
  check("price list create 201", newPl.status === 201);
  const plId = newPl.body.data?.id;

  const oil = products.find((p: any) => p.name.includes("زيت"));
  const addItem = await req("POST", `/price-lists/${plId}/items`, T, { product_id: oil.id, unit_price: 8000, min_qty: 5 });
  check("item upsert 201", addItem.status === 201);
  const upsertAgain = await req("POST", `/price-lists/${plId}/items`, T, { product_id: oil.id, unit_price: 8100 });
  check("same product → upsert (not dup)", upsertAgain.status === 201 && upsertAgain.body.data?.unit_price === 8100);

  const plDetail = await req("GET", `/price-lists/${plId}`, T);
  check("detail shows item with base price diff", plDetail.status === 200 && plDetail.body.data?.items?.[0]?.base_price === oil.sale_price);

  const delItem = await req("DELETE", `/price-lists/${plId}/items?product_id=${oil.id}`, T);
  check("item delete", delItem.status === 200 && delItem.body.data?.deleted === 1);

  const cashierPlist = await req("POST", "/price-lists", CT, { code: "NOPE", name: "ممنوع" });
  check("cashier blocked from price list create (PERM_001)", cashierPlist.status === 403);

  // 4) customer assignment
  const customers = (await req("GET", "/customers?per_page=100", T)).body.data ?? [];
  const amana = customers.find((c: any) => c.name.includes("أمانة"));
  check("أمانة assigned to WHOLESALE", amana?.price_list?.code === "WHOLESALE", JSON.stringify(amana?.price_list));

  const badAssign = await req("POST", `/customers/${amana.id}/price-list`, T, { price_list_id: 999999 });
  check("assign to missing list → VAL_003", badAssign.status === 404 && badAssign.body.code === "VAL_003");

  const other = customers.find((c: any) => c.id !== amana.id);
  const assign2 = await req("POST", `/customers/${other.id}/price-list`, T, { price_list_id: plId });
  check("assign list to other customer", assign2.status === 200 && assign2.body.data?.price_list?.id === plId);
  const unassign = await req("DELETE", `/customers/${other.id}/price-list`, T);
  check("unassign customer", unassign.status === 200 && unassign.body.data?.price_list === null);

  // 5) pricing resolution in invoices
  // 5a) assigned customer + list product → list price (8300)
  const wh = 1;
  // replenish stock so the suite is repeatable (pricing tests consume)
  await req("POST", "/inventory/movements", T, { product_id: paste.id, warehouse_id: wh, direction: "IN", qty: 300, unit_cost: paste.cost_price ?? 750, note: "تجهيز مجموعة الاختبار" });
  await req("POST", "/inventory/movements", T, { product_id: oil.id, warehouse_id: wh, direction: "IN", qty: 200, unit_cost: oil.cost_price ?? 7500, note: "تجهيز مجموعة الاختبار" });
  const invA = await req("POST", "/sales/invoices", T, {
    customer_id: amana.id, warehouse_id: wh, type: "CASH",
    lines: [{ product_id: oil.id, qty: 2 }],
  });
  check("list price applied (2×8300=16600)", invA.status === 201 && invA.body.data?.subtotal === 16600, `got ${invA.body.data?.subtotal}`);

  // 5b) unit line → qty converted to base, total = unitQty × unitPrice
  const invB = await req("POST", "/sales/invoices", T, {
    customer_id: amana.id, warehouse_id: wh, type: "CASH",
    lines: [{ product_id: paste.id, qty: 2, unit_id: ctnLink.unit.id }],
  });
  const lineB = invB.status === 201
    ? await db.salesInvoiceLine.findFirst({ where: { invoiceId: invB.body.data.id, productId: paste.id } })
    : null;
  check("unit line: stock qty = 2×24=48 base", lineB?.qty === 48, `qty=${lineB?.qty}`);
  check("unit line: total = 2×22000 (not ×48)", lineB?.lineTotal === 44000, `total=${lineB?.lineTotal}`);
  check("unit line: snapshots (unitId/factor/qtyUnits)", lineB?.unitId != null && lineB?.unitFactor === 24 && lineB?.qtyUnits === 2);

  const balAfter = await db.stockBalance.findUnique({ where: { warehouseId_productId: { warehouseId: wh, productId: paste.id } } });
  check("stock decremented by base units", !!balAfter, `balance=${balAfter?.qty}`);

  // 5c) explicit unit_price overrides everything
  const invC = await req("POST", "/sales/invoices", T, {
    customer_id: amana.id, warehouse_id: wh, type: "CASH",
    lines: [{ product_id: oil.id, qty: 1, unit_price: 9000 }],
  });
  check("explicit price beats list price (9000)", invC.status === 201 && invC.body.data?.subtotal === 9000, `got ${invC.body.data?.subtotal}`);

  // 6) sales order with unit → convert → invoice matches order total
  const so = await req("POST", "/sales/orders", T, {
    customer_id: amana.id, warehouse_id: wh,
    lines: [{ product_id: paste.id, qty: 1, unit_id: ctnLink.unit.id }],
  });
  check("SO with unit line created", so.status === 201, JSON.stringify(so.body));
  const soId = so.body.data?.id;
  const confirm = await req("POST", `/sales/orders/${soId}/confirm`, T);
  check("SO confirmed", confirm.status === 200);
  const convert = await req("POST", `/sales/orders/${soId}/convert`, T, { type: "CASH" });
    check("SO converted to invoice", convert.status === 200 && !!convert.body.data?.invoice_id, JSON.stringify(convert.body).slice(0, 120));
  const invLine = convert.status === 200
    ? await db.salesInvoiceLine.findFirst({ where: { invoiceId: convert.body.data.invoice_id, productId: paste.id } })
    : null;
  check("converted invoice: base 24 × per-base price 22000/24", invLine?.qty === 24 && invLine?.lineTotal === 22000, `qty=${invLine?.qty} total=${invLine?.lineTotal}`);

  // 7) guards
  const delLinkedUnit = await req("DELETE", `/units/${ctn.id}`, T);
  check("unit delete blocked while linked (VAL_001)", delLinkedUnit.status === 422 && delLinkedUnit.body.code === "VAL_001");

  const delAssignedPl = await req("DELETE", "/price-lists/WHOLESALE_ID_PLACEHOLDER", T).catch(() => null);
  void delAssignedPl;
  const wholesaleFresh = (await req("GET", "/price-lists", T)).body.data.find((l: any) => l.code === "WHOLESALE");
  const delAssigned = await req("DELETE", `/price-lists/${wholesaleFresh.id}`, T);
  check("list delete blocked while assigned (VAL_001)", delAssigned.status === 422 && delAssigned.body.code === "VAL_001");

  const cleanupPl = await req("DELETE", `/price-lists/${plId}`, T);
  check("unused list delete works", cleanupPl.status === 200);

  // 8) audit
  const audits = (await req("GET", "/admin/audit-logs?per_page=50", T)).body.data ?? [];
  const types = new Set(audits.map((a: any) => a.entity_type));
  check("audit captured unit + price_list actions", ["unit", "price_list", "price_list_item", "product_unit"].filter((t) => types.has(t)).length >= 2, [...types].join(","));

  console.log(`\n═══ Master-data: ${pass} passed · ${fail} failed ═══`);
  if (fail > 0) process.exitCode = 1;
  await db.$disconnect();
}

main().catch((e) => {
  console.error("suite crashed:", e);
  process.exit(1);
});
