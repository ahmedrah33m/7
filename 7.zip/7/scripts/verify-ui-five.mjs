// =====================================================================
// verify-ui-five.mjs — تحقق بصري: قائمة قابلة للطي + اسم الشركة أعلى
// القائمة فقط + بطاقة الشعار وحذف الشركات في لوحة الإدارة
// المخرجات: لقطات PNG في download/ + تقرير نصي
// =====================================================================
import { chromium } from "playwright";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const OUT = "/home/z/my-project/download";

const results = [];
function check(name, ok, extra = "") {
  results.push(`${ok ? "✓" : "✗"} ${name}${extra ? " — " + extra : ""}`);
  if (!ok) process.exitCode = 1;
}

const browser = await chromium.launch({ headless: true });

try {
  // ---------- 1) دخول ----------
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const consoleErrors = [];
  page.on("console", (m) => { if (m.type() === "error") consoleErrors.push(m.text().slice(0, 140)); });
  page.on("pageerror", (e) => consoleErrors.push(String(e).slice(0, 140)));

  await page.goto(BASE, { waitUntil: "networkidle", timeout: 30000 });
  await page.getByLabel("اسم المستخدم").fill("admin");
  await page.locator("#password").fill("Admin@123");
  await page.getByRole("button", { name: "دخول" }).click();
  await page.waitForSelector("aside", { timeout: 25000 });
  check("الدخول والوصول للوحة (aside ظاهر)", true);

  // ---------- 2) القائمة الجانبية: اسم الشركة فقط ----------
  const aside = page.locator("aside").first();
  const asideText = (await aside.innerText()).trim();
  const asideBrandLine = asideText.split("\n")[0] ?? "";
  check("رأس القائمة يعرض اسم الشركة", asideBrandLine.includes("شركة النخبة"), asideBrandLine);
  check("سطر الهوية في القائمة = اسم الشركة فقط (بلا اسم نظام)", !asideBrandLine.includes("ميدان"), asideBrandLine);
  await page.screenshot({ path: `${OUT}/ui5-dashboard-expanded.png`, fullPage: false });

  // ---------- 3) طي القائمة ----------
  await page.getByRole("banner").getByRole("button", { name: "طي القائمة الجانبية" }).click();
  await page.waitForTimeout(400);
  const collapsedClass = await aside.getAttribute("class");
  check("القائمة مطوية (w-[4.25rem])", collapsedClass?.includes("w-[4.25rem]"), "");
  const asideTextCollapsed = (await aside.innerText()).trim();
  check("أسماء التنقل مخفية عند الطي", !asideTextCollapsed.includes("نظرة عامة"));
  await page.screenshot({ path: `${OUT}/ui5-dashboard-collapsed.png`, fullPage: false });

  // حفظ الحالة: إعادة تحميل → تبقى مطوية
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForSelector("aside", { timeout: 20000 });
  const afterReload = await page.locator("aside").first().getAttribute("class");
  check("حالة الطي محفوظة بعد إعادة التحميل", afterReload?.includes("w-[4.25rem]"), "");

  // ---------- 4) توسيع القائمة ----------
  await page.getByRole("banner").getByRole("button", { name: "توسيع القائمة الجانبية" }).click();
  await page.waitForTimeout(400);
  const expandedClass = await page.locator("aside").first().getAttribute("class");
  check("القائمة توسعت مجددًا (w-64)", expandedClass?.includes("w-64"), "");

  // ---------- 5) لوحة الشركات: بطاقة الشعار + زر الحذف ----------
  await page.getByRole("button", { name: "النظام والأمان" }).click();
  await page.waitForTimeout(600);
  await page.getByRole("tab", { name: /الشركات/ }).click();
  await page.waitForTimeout(800);
  const sysText = await page.locator("body").innerText();
  check("بطاقة «شعار النظام» ظاهرة", sysText.includes("شعار النظام"));
  check("زر حذف الشركة ظاهر (صلاحية المالك)", (await page.locator('button[title*="حذف الشركة"]').count()) > 0);
  await page.screenshot({ path: `${OUT}/ui5-companies-branding.png`, fullPage: false });

  check("لا أخطاء console خلال الجولة", consoleErrors.length === 0, consoleErrors.join(" | "));
} finally {
  await browser.close();
}

console.log("\n===== التحقق البصري — التعديلات الخمسة =====");
console.log(results.join("\n"));
const fails = results.filter((r) => r.startsWith("✗")).length;
console.log(`\nالمجموع: ${results.length} — ناجح: ${results.length - fails} — فاشل: ${fails}`);
