// =====================================================================
// Phase 4 — Backfill: طبقات تكلفة افتتاحية للمخزون القائم (قبل المرحلة 4)
//
// المخزون الموجود بلا طبقات يصبح غير قابل للصرف FIFO — هذا السكربت
// ينشئ طبقة OPENING_BALANCE واحدة لكل (مستودع، منتج) له رصيد بلا أي
// طبقة، بتكلفة منتج.costPrice الساري. idempotent: الزوج الذي له طبقات
// (حتى مستنفدة) لا يُمس.
//
// تشغيل: node scripts/phase4-backfill.mjs
// =====================================================================
import { PrismaClient } from "@prisma/client";
import Decimal from "decimal.js";

Decimal.set({ precision: 40, rounding: Decimal.ROUND_HALF_UP, toExpNeg: -18, toExpPos: 48 });
const db = new PrismaClient();

const dec = (v) => (v == null || v === "" ? new Decimal(0) : v instanceof Decimal ? v : new Decimal(String(v)));
const qtyR = (v) => dec(v).toDecimalPlaces(6, Decimal.ROUND_HALF_UP);
const moneyR = (v) => dec(v).toDecimalPlaces(4, Decimal.ROUND_HALF_UP);

async function main() {
  const balances = await db.stockBalance.findMany({
    where: { qty: { not: 0 } },
    select: { companyId: true, warehouseId: true, productId: true, qty: true },
  });
  console.log(`أرصدة مخزون غير صفرية: ${balances.length}`);

  const productIds = [...new Set(balances.map((b) => b.productId))];
  const products = await db.product.findMany({
    where: { id: { in: productIds } },
    select: { id: true, name: true, costPrice: true },
  });
  const costOf = new Map(products.map((p) => [p.id, moneyR(dec(p.costPrice))]));

  // الأزواج التي لها طبقات مسبقاً (أي حالة) — تُستثنى
  const existing = await db.costLayer.findMany({
    select: { warehouseId: true, productId: true },
    distinct: ["warehouseId", "productId"],
  });
  const hasLayer = new Set(existing.map((l) => `${l.warehouseId}:${l.productId}`));

  let created = 0, skipped = 0, zeroCost = 0;
  for (const b of balances) {
    const key = `${b.warehouseId}:${b.productId}`;
    if (hasLayer.has(key)) { skipped++; continue; }
    const qty = qtyR(dec(b.qty));
    if (!qty.isPositive()) { skipped++; continue; } // رصيد سالب شاذ — لا طبقة افتتاحية
    const cost = costOf.get(b.productId) ?? new Decimal(0);
    if (cost.isZero()) zeroCost++;
    await db.costLayer.create({
      data: {
        companyId: b.companyId,
        warehouseId: b.warehouseId,
        productId: b.productId,
        sourceType: "OPENING_BALANCE",
        quantity: qty,
        remainingQuantity: qty,
        unitCost: cost,
        currency: "IQD",
        status: "ACTIVE",
      },
    });
    created++;
  }

  console.log(`نتيجة Backfill: أُنشئت ${created} طبقة افتتاحية · تخطي ${skipped} (لها طبقات/رصيد غير صالح) · تكلفة صفرية: ${zeroCost}`);
  console.log(`إجمالي الطبقات الآن: ${await db.costLayer.count()}`);
}

main()
  .catch((e) => { console.error(e); process.exitCode = 1; })
  .finally(() => db.$disconnect());
