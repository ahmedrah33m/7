/**
 * اختبار الربط الكامل: شراء بالكراتين → مخزون بالحبات → معاينة الفاتورة تعرض الكراتين
 * 1) دخول admin → تبديل لشركة لوميره (id=2)
 * 2) قراءة مخزون الشامبو (product 10) + حالة العبوات قبل
 * 3) فاتورة شراء: 2 كرتون + 3 علب = 25 حبة بسعر كرتون 40300 (الحبة 40300/11)
 * 4) التحقق: إجمالي السطر = 91590.91 بالضبط (دقة round6) + العبوات في المعاينة 22 كرتون كاملة + 3 علب
 * 5) حذف فاتورة الشراء التجريبية → عكس الأثر والعودة للحالة الأصلية
 */
const BASE = "http://localhost:3000/api/v1";

interface Pkg { has_pack: boolean; closed_packages?: number; open_packages?: number; open_qty?: number; total_pieces?: number; pack_unit?: string }
interface PreviewData { packages: Record<string, Pkg> }

async function jfetch<T>(path: string, init?: RequestInit): Promise<{ ok: boolean; status: number; body: T & { success?: boolean; message?: string; data?: T } }> {
  const res = await fetch(`${BASE}${path}`, init);
  const body = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, body: body as never };
}

async function main() {
  // 1) دخول + تبديل شركة
  const login = await jfetch<{ access_token: string }>("/auth/login", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ username: "admin", password: "Admin@123" }),
  });
  if (!login.body.data?.access_token) throw new Error(`فشل الدخول: ${JSON.stringify(login.body)}`);
  const t1 = login.body.data.access_token;

  const sw = await jfetch<{ access_token: string }>("/auth/switch-company", {
    method: "POST",
    headers: { authorization: `Bearer ${t1}`, "content-type": "application/json" },
    body: JSON.stringify({ company_id: 2 }),
  });
  const token = sw.body.data?.access_token;
  if (!token) throw new Error(`فشل تبديل الشركة: ${JSON.stringify(sw.body)}`);
  const auth = { authorization: `Bearer ${token}`, "content-type": "application/json" };
  console.log("✓ دخول admin + شركة لوميره (2)");

  // 2) المستودعات + الزبون الافتراضي
  const me = await jfetch<{ warehouses: { id: number; name: string }[] }>("/auth/me", { headers: auth });
  const wh = me.body.data?.warehouses?.[0];
  if (!wh) throw new Error("لا مستودعات");
  const walkin = await jfetch<{ id: number }>("/customers/default-walkin", { headers: auth });
  const custId = walkin.body.data?.id;
  if (!custId) throw new Error("لا زبون افتراضي");
  console.log(`✓ مستودع: ${wh.name} (#${wh.id}) · زبون نقدي #${custId}`);

  // 3) المخزون قبل
  const prods = await jfetch<{ stock_total: number; name: string; unit: string }[]>("/products?per_page=100", { headers: auth });
  const p10 = prods.body.data?.find((p) => (p as unknown as { id: number }).id === 10) as unknown as { stock_total: number; name: string; unit: string } | undefined;
  if (!p10) throw new Error("المنتج 10 غير موجود");
  console.log(`✓ قبل الشراء: ${p10.name} — الرصيد الكلي ${p10.stock_total} ${p10.unit}`);

  const previewBefore = await jfetch<PreviewData>("/sales/invoices/preview", {
    method: "POST", headers: auth,
    body: JSON.stringify({ customer_id: custId, warehouse_id: wh.id, product_ids: [10] }),
  });
  const pkgBefore = previewBefore.body.data?.packages?.["10"];
  console.log(`  العبوات قبل: ${JSON.stringify(pkgBefore)}`);

  // 4) فاتورة شراء: 2 كرتون + 3 علب = 25 حبة · سعر الكرتون 40300 → الحبة 40300/11
  const sups = await jfetch<{ id: number; name: string; is_active: boolean }[]>("/suppliers", { headers: auth });
  const sup = sups.body.data?.find((s) => s.is_active) as { id: number; name: string } | undefined;
  if (!sup) throw new Error("لا موردين نشطين في الشركة");
  console.log(`✓ المورد: ${sup.name} (#${sup.id})`);
  const CARTON_COST = 40300;
  const PQ = 11;
  const qty = 2 * PQ + 3; // 25 حبة
  const unitCost = Math.round((CARTON_COST / PQ) * 1e6) / 1e6; // 3663.636364
  const buy = await jfetch<{ id: number; number: string; grand_total: number; due_amount: number }>("/purchases/invoices", {
    method: "POST", headers: auth,
    body: JSON.stringify({
      supplier_id: sup.id,
      warehouse_id: wh.id,
      type: "CASH",
      lines: [{ product_id: 10, qty, unit_cost: unitCost }],
    }),
  });
  console.log(`✓ فاتورة الشراء: ${buy.body.data?.number ?? buy.body.message} · الإجمالي ${buy.body.data?.grand_total}`);
  const expected = Math.round(qty * unitCost * 100) / 100;
  console.log(`  المتوقع ${expected} (${qty} حبة × ${unitCost}) — ${buy.body.data?.grand_total === expected ? "مطابق تماماً ✓ (دقة 6 منازل)" : "❌ انحراف!"}`);

  // 5) المعاينة بعد الشراء
  const previewAfter = await jfetch<PreviewData>("/sales/invoices/preview", {
    method: "POST", headers: auth,
    body: JSON.stringify({ customer_id: custId, warehouse_id: wh.id, product_ids: [10] }),
  });
  const pkgAfter = previewAfter.body.data?.packages?.["10"];
  console.log(`✓ العبوات بعد الشراء: ${JSON.stringify(pkgAfter)}`);
  const expClosed = (pkgBefore?.closed_packages ?? 0) + 2;
  console.log(`  ${pkgAfter?.closed_packages === expClosed ? `✓ الربط مع الفاتورة يعمل: ${pkgAfter.closed_packages} كراتين كاملة + ${pkgAfter.open_qty} علب مفتوحة` : "❌ العبوات لم تتحدث كما هو متوقع"}`);

  // 6) حذف فاتورة الشراء التجريبية (عكس الأثر)
  if (buy.body.data?.id) {
    const del = await jfetch(`/purchases/invoices/${buy.body.data.id}`, { method: "DELETE", headers: auth });
    console.log(`✓ حذف الفاتورة التجريبية: ${del.body.success ? "نجح وعُكس المخزون والصندوق" : del.body.message}`);
  }

  // 7) التحقق النهائي
  const prodsFinal = await jfetch<{ stock_total: number }[]>("/products?per_page=100", { headers: auth });
  const p10f = prodsFinal.body.data?.find((p) => (p as unknown as { id: number }).id === 10) as unknown as { stock_total: number } | undefined;
  console.log(`✓ الرصيد النهائي: ${p10f?.stock_total} (الأصل ${p10.stock_total}) — ${p10f?.stock_total === p10.stock_total ? "عاد كما كان ✓" : "❌ لم يعد للأصل"}`);
}

main().catch((e) => { console.error("فشل الاختبار:", e.message); process.exit(1); });
