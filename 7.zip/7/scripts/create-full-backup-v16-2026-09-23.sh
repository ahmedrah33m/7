#!/usr/bin/env bash
# =============================================================
# create-full-backup-v16-2026-09-23.sh
# أرشيف النظام الكامل v16 — مشتريات محسّنة (USD + بحث + تفاصيل)
#
# جولة لتعديل صفحة المشتريات حسب طلب المستخدم:
#   - أعمدة فاتورة شراء جديدة: المنتج · الكارتونة · الحبة · عدد الحبات
#     · تكاليف الكارتونة · سعر البيع جمله · سعر البيع مفرد
#   - دعم العملة الدولار (USD) + سعر الصرف في فواتير الشراء
#   - البحث عن الفواتير (برقم الفاتورة أو اسم المورد)
#   - فتح الفاتورة عند الضغط عليها (modal يعرض تفاصيل كاملة)
#   - تحديث أسعار البيع (جملة + مفرد) عند الشراء
#   - GET /api/v1/purchases/invoices/[id] — جلب فاتورة واحدة بالتفاصيل
# =============================================================
set -euo pipefail

ROOT="/home/z/my-project"
OUT="$ROOT/download/kayan-system-full-backup-2026-09-23-v16.zip"
SNAP="$ROOT/backups/custom-snapshot-20260923-v16.db"
STAGE="$ROOT/.zstage"
CHK="$ROOT/backups/.dbcheck-v16"

echo "==> 1) لقطة DB متسقة…"
python3 "$ROOT/scripts/snapshot-db.py" "$SNAP"
SNAP_MD5="$(md5sum "$SNAP" | cut -d' ' -f1)"

echo "==> 2) staging وحقن اللقطة…"
rm -rf "$STAGE"
mkdir -p "$STAGE/db"
cp "$SNAP" "$STAGE/db/custom.db"

echo "==> 3) أرشفة المصدر…"
rm -f "$OUT"
( cd "$STAGE" && zip -q -X "$OUT" db/custom.db )
cd "$ROOT"
zip -qr "$OUT" . \
  -x "node_modules/*" \
  -x ".next/*" \
  -x "backups/*" \
  -x "skills/*" \
  -x "tool-results/*" \
  -x "download/*" \
  -x ".pkg-*/*" \
  -x ".zscripts/*" \
  -x ".zstage/*" \
  -x "repo/*" \
  -x "upload/*" \
  -x "examples/*" \
  -x "mini-services/*" \
  -x "tsconfig.tsbuildinfo" \
  -x "db/custom.db" \
  -x "db/custom.db-*"

echo "==> 4) ضم الـ standalone الجاهز…"
[ -f ".next/standalone/.next/BUILD_ID" ] || { echo "لا يوجد BUILD_ID"; exit 1; }
[ -d ".next/standalone/.next/static" ] || { echo "لا يوجد static"; exit 1; }
[ -d ".next/standalone/public" ] || { echo "لا يوجد public"; exit 1; }
[ -d ".next/standalone/node_modules/.prisma" ] || { echo "لا يوجد prisma client"; exit 1; }
( cd .next && zip -qr "$OUT" standalone )
echo "  BUILD_ID المُضمّن: $(cat .next/standalone/.next/BUILD_ID)"

echo "==> 5) التحقق…"
unzip -t "$OUT" > "$ROOT/backups/.unzip-t-v16.txt" 2>&1 \
  && echo "unzip -t: OK" \
  || { echo "unzip -t FAILED"; exit 1; }

COUNT="$(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
SIZE="$(stat -c%s "$OUT")"
MD5="$(md5sum "$OUT" | cut -d' ' -f1)"
NEXT_IN_ZIP="$(unzip -l "$OUT" | grep -c "standalone/.next/" || true)"

rm -rf "$CHK"; mkdir -p "$CHK"
unzip -q "$OUT" "db/custom.db" -d "$CHK"
ARCH_MD5="$(md5sum "$CHK/db/custom.db" | cut -d' ' -f1)"
TABLES="$(python3 -c "
import sqlite3
c = sqlite3.connect('$CHK/db/custom.db')
print(len(c.execute(\"select name from sqlite_master where type='table' and name not like 'sqlite_%'\").fetchall()))
")"
rm -rf "$CHK"
if [ "$ARCH_MD5" = "$SNAP_MD5" ]; then DB_MATCH=YES; else DB_MATCH=NO; fi

echo "=============================================="
echo "OUT     : $OUT"
echo "SIZE    : $SIZE bytes ($((SIZE/1024/1024))MB)"
echo "FILES   : $COUNT"
echo "NEXT    : $NEXT_IN_ZIP ملف standalone"
echo "MD5     : $MD5"
echo "DB_MATCH: $DB_MATCH"
echo "DB_TABLES: $TABLES"
echo "BUILD_ID: $(cat .next/standalone/.next/BUILD_ID)"
echo "=============================================="
[ "$DB_MATCH" = "YES" ] || exit 1
[ "$NEXT_IN_ZIP" -gt 100 ] || { echo "الـ standalone ناقص!"; exit 1; }
echo "DONE_OK"
